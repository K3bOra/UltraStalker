# -*- coding: utf-8 -*-
"""Thin read-only bridge between Ultra Stalker's existing Web UI and core clients.

R200 Web Browse bridge (selected-source independent Stalker catalogue; isolated Web state; clean R151 baseline) exposes sanitized accounts,
resilient categories, paged catalogue items, the existing series hierarchy,
shared Search/Favorites, and mobile-only stream resolution through Ultra Stalker's
existing clients and repositories. It never opens or controls the Enigma2 player.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str, int, open, round, max, min, OSError, us_clear, us_casefold

hashlib = _us_env.hashlib
json = _us_env.json
import math
os = _us_env.os
queue = _us_env.queue
re = _us_env.re
secrets = _us_env.secrets
threading = _us_env.threading
time = _us_env.time
urllib = _us_env.urllib
from .core.call_compat import call_compatible


_MEDIA_TYPES = ("itv", "vod", "series")
_LOCAL_ACCOUNT_ID = "__local__"
_ITEM_CACHE = {}
_ITEM_CACHE_LOCK = threading.RLock()
_ITEM_CACHE_TTL = 30 * 60
_ITEM_CACHE_MAX = 3000
_CATEGORY_RAM = {}
_CATEGORY_RAM_LOCK = threading.RLock()
_CATEGORY_RAM_TTL = 30 * 60
# R200: selected-source only last-good item pages. RAM-only, no background I/O.
_PAGE_RAM = {}
_PAGE_RAM_LOCK = threading.RLock()
_PAGE_RAM_TTL = 30 * 60
_PAGE_RAM_FAST_TTL = 2 * 60
_PAGE_RAM_MAX = 120
_SEARCH_RAM = {}
_SEARCH_RAM_LOCK = threading.RLock()
_SEARCH_RAM_TTL = 90
_SEARCH_RAM_MAX = 24

# R5.229: tiny RAM cache for Web poster-card metadata.  It stores only values
# already present in provider rows or the receiver's local canonical metadata
# cache.  It never triggers TMDb/IMDb/provider network work.
_CARD_META_RAM = {}
_CARD_META_RAM_LOCK = threading.RLock()
_CARD_META_RAM_TTL = 30 * 60
_CARD_META_RAM_MAX = 1200

# R8: browser-direct TMDb backdrop fallback.  Only the tiny TMDb metadata
# lookup crosses the receiver; image bytes are never proxied, downloaded or
# written by Ultra Stalker.  Keep the resolved w1280 URL in RAM so reopening
# the same Details page does not repeat the metadata request.
_REMOTE_BACKDROP_RAM = {}
_REMOTE_BACKDROP_LOCK = threading.RLock()
_REMOTE_BACKDROP_TTL = 30 * 60
_REMOTE_BACKDROP_FAIL_TTL = 60

# R179: one shared phone-player bridge for Live, Movies and Episodes.
# The random ticket is the authorization boundary for external players, which
# cannot carry the Web UI HttpOnly cookie when they fetch the stream.
_PLAY_TICKETS = {}
_PLAY_TICKET_LOCK = threading.RLock()
_PLAY_TICKET_TTL = 20 * 60
_LOCAL_PLAY_TICKET_TTL = 12 * 60 * 60
_PLAY_TICKET_MAX = 256

# R2: Web Browse shares the receiver-owned PortalSession for the selected
# Stalker source. Some middleware permits only one active token per MAC; a
# parallel Web authorization can invalidate the receiver session. The Web proxy
# never owns/closes that shared transport.
_WEB_STALKER_LOCK = threading.RLock()
_WEB_STALKER_ACTIVE_ACCOUNT = ""
_WEB_STALKER_CLIENT = None
_WEB_STALKER_KEY = None

class BrowseError(RuntimeError):
    pass


_WEB_POLICY_LOCK = threading.RLock()
_WEB_POLICY_RETRY = {}

def _web_policy_settings():
    try:
        from .storage import load_settings
        return dict(load_settings() or {})
    except Exception:
        raise BrowseError("Web content policy is unavailable")

def _web_policy_rules(media, settings):
    media = "series" if media in ("season", "episode") else media
    locked = bool(settings.get("parental_lock"))
    protected = {us_casefold(str(x).strip()) for x in (settings.get("protected_categories", {}).get(media, []) or [])} if locked else set()
    words = tuple(us_casefold(str(x).strip()) for x in (settings.get("adult_keywords") or []) if str(x).strip()) if (locked or settings.get("hide_adult", True)) else ()
    return protected, words

def _web_category_blocked(media, category, settings):
    protected, words = _web_policy_rules(media, settings)
    cid = us_casefold(str(category.get("id") or "").strip())
    title = us_casefold(" ".join(str(category.get(k) or "") for k in ("name","title")))
    return cid in protected or any(word in title for word in words)

def _web_policy_catalog(profile, media):
    """Provider-owned aliases only; never trust a request's category_title."""
    media = "series" if media in ("season", "episode") else media
    with _WEB_POLICY_LOCK:
        rows, _age = _category_ram_snapshot(profile, media)
        if not rows:
            rows = _receiver_last_good_categories(profile, media)
        key = (_account_id(profile), media)
        if not rows and time.monotonic() >= _WEB_POLICY_RETRY.get(key, 0):
            client = None
            try:
                client = _new_client(profile, timeout=6)
                rows = client.genres(media) or []
                if rows:_category_ram_put(profile, media, rows)
            except Exception:
                rows = []
            finally:
                if client is not None:
                    try:client.close()
                    except Exception:pass
            if not rows:
                _WEB_POLICY_RETRY[key] = time.monotonic() + 15
                while len(_WEB_POLICY_RETRY)>64:_WEB_POLICY_RETRY.pop(next(iter(_WEB_POLICY_RETRY)))
    aliases = {}
    for row in rows if isinstance(rows, list) else []:
        if not isinstance(row, dict):continue
        category = {"id": _category_id(row).strip(), "title": _category_title(row).strip(), "name": str(row.get("name") or "").strip()}
        if category["id"] in ("", "*", "0", "all"):continue
        for value in (category["id"], category["title"], category["name"]):
            key = us_casefold(value)
            if key and category not in aliases.setdefault(key, []):aliases[key].append(category)
    return aliases

def _web_policy_snapshot(account, media, category, row, parent_id=""):
    if _is_local_account(account):
        return {"known": True, "categories": [], "local": True}
    if parent_id:
        parent = get_cached_item(parent_id)
        if parent["account"] != str(account):raise BrowseError("invalid item context")
        return dict(parent.get("policy") or {})
    profile = _find_profile(account)
    catalog = _web_policy_catalog(profile, media)
    context = catalog.get(us_casefold(str(category or "").strip()), []) if category not in ("*", "favorites", "local") else []
    categories = [dict(x) for x in context]
    known = bool(categories)
    # Xtream retains the numeric category under this private field, whereas
    # category_id can be the visible group name. Match both trusted aliases.
    refs = []
    def folder_ref(value):
        # These are aggregate/unset markers, not a real folder identity. They
        # cannot classify All/Search rows, but must not erase a trusted named
        # folder's provenance (some Stalker VOD rows use genre_id=0).
        text = str(value).strip() if value is not None else ""
        return text if us_casefold(text) not in ("", "*", "0", "all") else ""
    for field in ("_xtream_category_id", "category_id", "genre_id"):
        value = row.get(field)
        for entry in value if isinstance(value, (list, tuple)) else [value]:
            ref = folder_ref(entry)
            if ref:refs.append(ref)
    if not refs:
        # VOD/Series ``genre`` is descriptive film metadata, not the provider's
        # category routing key. Only Live uses it as a folder-name fallback.
        fields = ("category", "category_name", "group", "group_title") + (("genre",) if media == "itv" else ())
        refs = [folder_ref(row[k]) for k in fields if isinstance(row.get(k), (str, int)) and folder_ref(row[k])]
    unknown = False
    for ref in refs:
        matches = catalog.get(us_casefold(ref))
        if matches:
            known = True
            for match in matches:
                if match not in categories:categories.append(dict(match))
        else:
            # Retain unknown IDs/names so a newly protected ID cannot escape a
            # token minted while filtering was disabled.
            categories.append({"id": ref, "title": ref})
            unknown = True
    if refs and unknown:known = False
    return {"known": known, "categories": categories, "local": False, "from_all": category == "*"}

def _web_authorize_snapshot(account, media, policy, settings=None):
    # Local is a separate receiver-owned library; provider category IDs have
    # never applied to it. Its filesystem confinement remains authoritative.
    if _is_local_account(account):return
    _find_profile(account)  # Deleted profiles immediately revoke old tickets.
    settings = _web_policy_settings() if settings is None else settings
    protected, words = _web_policy_rules(media, settings)
    if not (protected or words):return
    if isinstance(policy,dict) and policy.get("from_all") and "*" in protected:
        raise BrowseError("This category is restricted in Web Browse")
    if not isinstance(policy, dict) or not policy.get("known"):
        raise BrowseError("Content category is unavailable under Web parental controls")
    if any(_web_category_blocked(media, x, settings) for x in policy.get("categories", [])):
        raise BrowseError("This category is restricted in Web Browse")


def _account_id(profile):
    p = profile if isinstance(profile, dict) else {}
    raw = "\x1f".join((
        str(p.get("portal") or "").strip().rstrip("/").lower(),
        str(p.get("mac") or "").strip().upper(),
        str(p.get("source_type") or "").strip().lower(),
    ))
    return "acc_" + hashlib.sha256(raw.encode("utf-8", "ignore")).hexdigest()[:24]


def _profile_kind(profile):
    p = profile if isinstance(profile, dict) else {}
    if str(p.get("source_type") or "").strip().lower() != "m3u":
        return "portal"
    raw = str(p.get("portal") or "").strip()
    try:
        parsed = urllib.parse.urlsplit(raw)
        query = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)
        if (parsed.path or "").lower().endswith("/get.php") and query.get("username") and query.get("password"):
            return "xtream"
    except Exception:
        pass
    low = raw.lower()
    if "get.php" in low and "username=" in low and "password=" in low:
        return "xtream"
    return "m3u"


def _safe_default_name(profile, position):
    """Mirror the receiver portal list name: custom rename wins, otherwise its native default label."""
    p = profile if isinstance(profile, dict) else {}
    explicit = str(p.get("name") or "").strip()
    if explicit:
        return explicit[:80]
    kind = _profile_kind(p)
    number = int(position) + 1
    if kind == "portal":
        return "Portal Server %d" % number
    if kind == "xtream":
        return "Xtream Server %d" % number
    if kind == "m3u":
        return "M3U Playlist %d" % number
    return "Source %d" % number


def _clean_titles_enabled():
    try:
        from .storage import load_settings
        return bool((load_settings() or {}).get("clean_titles", True))
    except Exception:
        return True


def _display_name(value, media_type="", enabled=None):
    raw = str(value or "").strip()
    if enabled is None:
        enabled = _clean_titles_enabled()
    if not enabled:
        return raw
    try:
        if str(media_type or "").lower() == "itv":
            from .ui_parts.catalog import clean_live_channel_name
            return str(clean_live_channel_name(raw, True) or raw).strip()
        from .title_clean import display_title
        return str(display_title(raw, enabled=True) or raw).strip()
    except Exception:
        return raw


def _category_cache_key(profile, media_type):
    p = profile if isinstance(profile, dict) else {}
    return (
        str(p.get("portal") or "").rstrip("/").lower(),
        str(p.get("mac") or "").upper(),
        str(media_type or "").lower(),
    )


def _category_cache_marker(row):
    cid = _category_id(row).strip()
    title = us_casefold(_category_title(row).strip())
    return cid or ("title:" + title)


def _category_ram_put(profile, media_type, rows):
    clean = [dict(x) if isinstance(x, dict) else x for x in (rows or [])]
    if not clean:
        return
    key = _category_cache_key(profile, media_type)
    with _CATEGORY_RAM_LOCK:
        _CATEGORY_RAM[key] = {"stored_at": time.time(), "rows": clean}


def _category_ram_snapshot(profile, media_type):
    key = _category_cache_key(profile, media_type)
    now = time.time()
    with _CATEGORY_RAM_LOCK:
        entry = _CATEGORY_RAM.get(key)
        if not entry:
            return [], None
        age = max(0.0, now - float(entry.get("stored_at") or 0))
        if age > _CATEGORY_RAM_TTL:
            _CATEGORY_RAM.pop(key, None)
            return [], None
        rows = [dict(x) if isinstance(x, dict) else x for x in (entry.get("rows") or [])]
        return rows, age


def _page_cache_key(profile, media_type, category, page_no):
    p = profile if isinstance(profile, dict) else {}
    return (
        str(p.get("portal") or "").rstrip("/").lower(),
        str(p.get("mac") or "").upper(),
        str(media_type or "").lower(),
        str(category or "*"),
        int(page_no or 1),
    )


def _page_ram_get(profile, media_type, category, page_no):
    key = _page_cache_key(profile, media_type, category, page_no)
    now = time.time()
    with _PAGE_RAM_LOCK:
        entry = _PAGE_RAM.get(key)
        if not entry:
            return None, [], None
        age = max(0.0, now - float(entry.get("stored_at") or 0))
        if age > _PAGE_RAM_TTL:
            _PAGE_RAM.pop(key, None)
            return None, [], None
        payload = dict(entry.get("payload") or {})
        rows = [dict(x) for x in (entry.get("rows") or []) if isinstance(x, dict)]
        return payload, rows, age


def _page_ram_put(profile, media_type, category, page_no, payload, rows):
    clean = [dict(x) for x in (rows or []) if isinstance(x, dict) and x]
    if not clean:
        return
    key = _page_cache_key(profile, media_type, category, page_no)
    with _PAGE_RAM_LOCK:
        _PAGE_RAM[key] = {
            "stored_at": time.time(),
            "payload": dict(payload or {}),
            "rows": clean,
        }
        # Bound RAM: drop oldest pages beyond the cap (dicts keep insertion order).
        while len(_PAGE_RAM) > _PAGE_RAM_MAX:
            try:
                _PAGE_RAM.pop(next(iter(_PAGE_RAM)))
            except Exception:
                us_clear(_PAGE_RAM)
                break


def _receiver_last_good_categories(profile, media_type):
    """Read the receiver UI's own last-good category snapshot.

    This uses the same tiny JSON cache that the Categories screen writes after a
    successful load.  It keeps Web Browse from replacing a known-complete list
    with a transiently short provider response, without importing Enigma2 UI
    classes or duplicating provider category logic.
    """
    try:
        from . import persistent_cache
        key = _category_cache_key(profile, media_type)
        digest = hashlib.sha1(("|".join(key)).encode("utf-8", "ignore")).hexdigest()
        path = os.path.join(str(persistent_cache.GENERATED or ""), "category_last_good", digest + ".json")
        if not path or not os.path.isfile(path):
            return []
        with open(path, "r", encoding="utf-8") as fh:
            payload = json.load(fh)
        rows = payload.get("rows") if isinstance(payload, dict) else None
        return [dict(x) if isinstance(x, dict) else x for x in rows] if isinstance(rows, list) else []
    except Exception:
        return []


def _prefer_complete_categories(fresh, *fallbacks):
    """Prefer the largest valid last-good catalogue when fresh is shorter."""
    candidates = []
    for rows in (fresh,) + tuple(fallbacks):
        if not isinstance(rows, list):
            continue
        valid = list(x for x in rows if isinstance(x, dict) and (_category_id(x).strip() or _category_title(x).strip()))
        if valid:
            candidates.append(valid)
    if not candidates:
        return []
    # A transient Stalker loader can return a syntactically valid but truncated
    # array.  The receiver's last-good snapshot is stronger evidence of the full
    # routing catalogue than that one short response.
    return max(candidates, key=lambda rows: len({_category_cache_marker(x) for x in rows}))


def _load_profiles():
    from . import storage
    return list(storage.load_profiles() or [])


def _find_profile(account_id):
    wanted = str(account_id or "").strip()
    if not wanted:
        raise BrowseError("missing account")
    for profile in _load_profiles():
        if _account_id(profile) == wanted:
            found = dict(profile)
            kind = _profile_kind(found)
            if kind not in ("portal", "xtream"):
                raise BrowseError("this build currently supports Stalker portals and Xtream only")
            return found
    raise BrowseError("account not found")


def _is_local_account(account_id):
    return str(account_id or "").strip() == _LOCAL_ACCOUNT_ID


def _local_web_context(media_type="vod"):
    """Return receiver Local context from the existing persistent index only.

    Web Local is deliberately read-only and never walks HDD/USB storage. If the
    receiver Local index has not been built yet, the user refreshes Local on the
    receiver first; Web never invents a second scanner/cache.
    """
    media = "series" if str(media_type or "").lower() == "series" else "vod"
    try:
        from .ui_screens_local import (
            LocalMediaClient, _load_local_media_index, _make_local_profile,
            _natural_key, _storage_roots,
        )
        roots = list(_storage_roots() or [])
        index = _load_local_media_index(roots)
    except Exception:
        roots, index = [], {}
    if not roots or not isinstance(index, dict) or not index:
        raise BrowseError("Local library index is not ready; open Local on the receiver and refresh it once")
    client = LocalMediaClient(roots, media)
    # Seed the adapter from the already-loaded index so ordered_page/seasons can
    # never fall through to its lazy storage scan from a Web request.
    client._catalog = index
    if media == "series":
        raw = list(x for x in (index.get("series") or []) if isinstance(x, dict))
        raw.sort(key=lambda x: _natural_key(str(x.get("title") or "")))
        client._ordered_raw = raw
        client._series_raw = {}
        for group in raw:
            title = str(group.get("title") or "").strip()
            series_dir = str(group.get("dir") or "")
            if not title or not series_dir:
                continue
            try:
                from .ui_screens_local import _stable_id, _norm
                sid = _stable_id("local-series", series_dir + "/__ultra_series__/" + _norm(title))
                client._series_raw[sid] = group
            except Exception:
                continue
    else:
        raw = list(x for x in (index.get("movies") or []) if isinstance(x, dict) and x.get("path"))
        raw.sort(key=lambda x: _natural_key(str(x.get("title") or "") or str(x.get("path") or "")))
        client._ordered_raw = raw
    return roots, client, _make_local_profile({})


def _local_profile():
    try:
        _roots, _client, profile = _local_web_context("vod")
        return profile
    except Exception:
        try:
            from .ui_screens_local import _make_local_profile
            return _make_local_profile({})
        except Exception:
            return {"portal": "local://receiver", "mac": "LOCAL", "name": "Local", "source_type": "local", "type": "local"}


def _local_media_path(row):
    """Return one real indexed media file, confined to receiver Local roots."""
    src = row if isinstance(row, dict) else {}
    raw = str(src.get("_local_path") or src.get("cmd") or src.get("url") or "").strip()
    if not raw or "\x00" in raw:
        raise BrowseError("local media path is unavailable")
    try:
        from .ui_screens_local import VIDEO_EXTENSIONS, _storage_roots, _is_under
        real = os.path.realpath(raw)
        if not os.path.isfile(real) or os.path.splitext(real)[1].lower() not in VIDEO_EXTENSIONS:
            raise BrowseError("local media file is unavailable")
        roots = list(_storage_roots() or [])
        if not any(_is_under(real, base) for base in roots):
            raise BrowseError("local media file is outside receiver storage")
        return real
    except BrowseError:
        raise
    except Exception:
        raise BrowseError("local media file is unavailable")


def _safe_local_art_path(value):
    """Allow sidecar art only when it belongs to the receiver Local roots."""
    raw = str(value or "").strip()
    if not raw or "\x00" in raw:
        return ""
    try:
        from .ui_screens_local import IMAGE_EXTENSIONS, _storage_roots, _is_under
        real = os.path.realpath(raw)
        if not os.path.isfile(real) or os.path.splitext(real)[1].lower() not in IMAGE_EXTENSIONS:
            return ""
        if not any(_is_under(real, base) for base in (_storage_roots() or [])):
            return ""
        return real
    except Exception:
        return ""


def list_local(media_type="vod", page=1):
    """Expose the exact receiver Local index to Web, with zero provider traffic."""
    media = str(media_type or "").strip().lower()
    if media == "summary":
        _roots, _client, _profile = _local_web_context("vod")
        index = dict(getattr(_client, "_catalog", {}) or {})
        movies = sum(1 for x in (index.get("movies") or []) if isinstance(x, dict) and x.get("path"))
        series = sum(1 for x in (index.get("series") or []) if isinstance(x, dict) and x.get("title") and x.get("dir"))
        return {"ok": True, "source_kind": "local", "lan_only": True, "movies": movies, "series": series, "total": movies + series}
    if media not in ("vod", "series"):
        raise BrowseError("invalid Local media type")
    try:
        page_no = max(1, min(int(page or 1), 100000))
    except Exception:
        raise BrowseError("invalid page")
    _roots, client, _profile = _local_web_context(media)
    payload = client.ordered_page(media, "*", page_no) or {}
    rows = list(x for x in (payload.get("items") or []) if isinstance(x, dict) and x)
    page_size = max(1, int(payload.get("page_size") or len(rows) or 1))
    total = max(0, int(payload.get("total") or 0))
    clean_enabled = _clean_titles_enabled()
    items = []
    for row in rows:
        token = _store_item(_LOCAL_ACCOUNT_ID, media, "local", "Local", row)
        item = {
            "id": token,
            "title": _item_title(row, media, clean_enabled),
            "favorite": False,
            "source_kind": "local",
            "local": True,
        }
        _apply_public_card_metadata(item, _profile, media, row)
        if media == "series":
            count = row.get("_local_season_count") or row.get("number_of_seasons")
            try:
                count = int(count or 0)
            except Exception:
                count = 0
            if count > 0:
                item["season_count"] = count
        items.append(item)
    pages = int(math.ceil(float(total) / float(page_size))) if total and page_size else 0
    return {
        "ok": True, "account": _LOCAL_ACCOUNT_ID, "media_type": media,
        "items": items, "count": len(items), "page": page_no,
        "page_size": page_size, "total": total, "pages": pages,
        "has_prev": page_no > 1,
        "has_next": bool(total and page_no * page_size < total),
        "source_kind": "local", "lan_only": True,
    }

def _new_client(profile, timeout=10):
    """Return the receiver-owned Stalker session for Web Browse.

    A second MAG/Stalker authorization with the same MAC can invalidate the
    receiver token on middleware that allows only one active token per device.
    Web therefore shares Ultra Stalker's PortalSession client instead of
    authorizing a parallel client.  The small proxy makes Web ``close()`` calls
    harmless: ownership of the transport remains with PortalSession/receiver.
    """
    p = dict(profile or {})
    kind = _profile_kind(p)
    if kind not in ("portal", "xtream"):
        raise BrowseError("this build currently supports Stalker portals and Xtream only")

    from .core.session import PortalSession

    class _WebSharedPortalClient(object):
        _web_shared_stalker = True
        _web_isolated_stalker = False

        def __init__(self, shared):
            object.__setattr__(self, "_shared", shared)

        def __getattr__(self, name):
            return getattr(object.__getattribute__(self, "_shared"), name)

        def __setattr__(self, name, value):
            if name == "_shared":
                object.__setattr__(self, name, value)
            else:
                setattr(object.__getattribute__(self, "_shared"), name, value)

        def close(self):
            # Web never owns the receiver session.
            return None

        def web_hard_close(self):
            # Switching/closing the browser must not tear down Home/Grid.
            return None

    global _WEB_STALKER_ACTIVE_ACCOUNT, _WEB_STALKER_CLIENT, _WEB_STALKER_KEY
    account = _account_id(p)
    key = (
        kind,
        str(p.get("portal") or "").rstrip("/").lower(),
        str(p.get("mac") or "").strip().upper(),
        str(p.get("tls_mode") or "auto").lower(),
        str(p.get("device_profile") or "auto").lower(),
    )
    with _WEB_STALKER_LOCK:
        if _WEB_STALKER_CLIENT is not None and _WEB_STALKER_KEY != key:
            _WEB_STALKER_CLIENT = None
            _WEB_STALKER_KEY = None
        _WEB_STALKER_ACTIVE_ACCOUNT = account
        if _WEB_STALKER_CLIENT is not None and _WEB_STALKER_KEY == key:
            try:
                _WEB_STALKER_CLIENT.timeout = max(3, min(int(timeout or 10), 30))
            except Exception:
                pass
            return _WEB_STALKER_CLIENT
        session = PortalSession(p, timeout=max(3, min(int(timeout or 10), 30)))
        proxy = _WebSharedPortalClient(session.client)
        _WEB_STALKER_CLIENT = proxy
        _WEB_STALKER_KEY = key
        return proxy


def _close_web_stalker_locked():
    global _WEB_STALKER_CLIENT, _WEB_STALKER_KEY
    client = _WEB_STALKER_CLIENT
    _WEB_STALKER_CLIENT = None
    _WEB_STALKER_KEY = None
    if client is not None:
        try:
            client.web_hard_close()
        except Exception:
            pass


def close_all_web_clients():
    global _WEB_STALKER_ACTIVE_ACCOUNT
    with _WEB_STALKER_LOCK:
        _close_web_stalker_locked()
        _WEB_STALKER_ACTIVE_ACCOUNT = ""
    return True


# UI ownership here is intentionally Web-local only. It never mutates receiver
# PortalSession, search scope, circuit state or saved profile health.
def web_claim_source(account_id):
    global _WEB_STALKER_ACTIVE_ACCOUNT
    profile = _find_profile(account_id)
    wanted = _account_id(profile)
    with _WEB_STALKER_LOCK:
        if _WEB_STALKER_ACTIVE_ACCOUNT and _WEB_STALKER_ACTIVE_ACCOUNT != wanted:
            _close_web_stalker_locked()
        _WEB_STALKER_ACTIVE_ACCOUNT = wanted
    return {"ok": True, "account": str(account_id), "owner": "web-ui"}


def web_heartbeat(account_id):
    _find_profile(account_id)
    # Local lease ping only; absolutely no provider request/handshake.
    return {"ok": True, "account": str(account_id), "owner": "web-ui"}


def web_release_source(account_id):
    global _WEB_STALKER_ACTIVE_ACCOUNT
    wanted = str(account_id or "")
    with _WEB_STALKER_LOCK:
        if not wanted or _WEB_STALKER_ACTIVE_ACCOUNT == wanted:
            _close_web_stalker_locked()
            _WEB_STALKER_ACTIVE_ACCOUNT = ""
    return {"ok": True, "account": wanted, "owner": ""}


def web_force_close_profile(profile):
    wanted = _account_id(profile)
    with _WEB_STALKER_LOCK:
        if _WEB_STALKER_ACTIVE_ACCOUNT == wanted:
            _close_web_stalker_locked()
            return True
    return False


def list_accounts():
    profiles = _load_profiles()
    accounts = []
    for index, profile in enumerate(profiles):
        kind = _profile_kind(profile)
        if kind not in ("portal", "xtream"):
            continue
        accounts.append({
            "id": _account_id(profile),
            "name": _safe_default_name(profile, index),
            "kind": kind,
            "position": index + 1,
        })
    return {"ok": True, "count": len(accounts), "accounts": accounts}


def _category_id(row):
    if isinstance(row, dict):
        for key in ("id", "genre_id", "category_id", "category", "value"):
            value = row.get(key)
            if value not in (None, ""):
                return str(value)
    return str(row or "")


def _category_title(row):
    if isinstance(row, dict):
        for key in ("title", "name", "category_name", "genre_name", "label"):
            value = str(row.get(key) or "").strip()
            if value:
                return value
        return _category_id(row)
    return str(row or "").strip()


def _hidden_category_ids_for(profile, media):
    """Folders the user hid on the receiver (same rule as every receiver screen)."""
    try:
        from .category_visibility import hidden_ids
        from .storage import load_settings
        return set(hidden_ids(load_settings() or {}, profile, media) or [])
    except Exception:
        return set()


def list_categories(account_id, media_type):
    media = str(media_type or "").strip().lower()
    if media not in _MEDIA_TYPES:
        raise BrowseError("invalid media type")
    profile = _find_profile(account_id)
    is_stalker = _profile_kind(profile) == "portal"

    # R200 independence rule: Web must be able to populate a Portal even when
    # the receiver has never opened that category/folder. Only Web-owned RAM is
    # an instant source. The receiver's last-good file is fallback-only after a
    # direct provider attempt, never a prerequisite for Web content.
    web_last_good, web_age = _category_ram_snapshot(profile, media)
    receiver_last_good = _receiver_last_good_categories(profile, media)
    cached = False

    if is_stalker and web_last_good and web_age is not None and web_age <= _CATEGORY_RAM_TTL:
        rows = web_last_good
        cached = True
    else:
        client = None
        fresh = []
        provider_failed = False
        try:
            client = _new_client(profile, timeout=9 if is_stalker else 10)
            fresh = client.genres(media) or []
            if not isinstance(fresh, list):
                fresh = []
            # Some MAG middleware returns one transient empty catalogue directly
            # after authorization. Retry once on the SAME Web session. No other
            # portal is touched and no receiver cache is required.
            if is_stalker and not fresh:
                time.sleep(0.20)
                fresh = client.genres(media) or []
                if not isinstance(fresh, list):
                    fresh = []
        except BrowseError:
            raise
        except Exception:
            provider_failed = True
        finally:
            if client is not None:
                try:
                    client.close()
                except Exception:
                    pass

        if fresh:
            rows = _prefer_complete_categories(fresh, web_last_good)
            _category_ram_put(profile, media, rows or fresh)
        else:
            # Last resort only. This preserves usability during a provider hiccup
            # but Web no longer depends on the receiver having visited folders.
            rows = _prefer_complete_categories(web_last_good, receiver_last_good)
            cached = bool(rows)
        if not rows and provider_failed:
            raise BrowseError("provider categories unavailable")

    settings = _web_policy_settings()
    out = []
    seen = set()
    for row in rows if isinstance(rows, list) else []:
        cid = _category_id(row).strip()
        title = _category_title(row).strip()
        if not cid and not title:
            continue
        if not cid:
            cid = title
        if _web_category_blocked(media, {"id":cid,"title":title,"name":str(row.get("name") or "") if isinstance(row,dict) else title}, settings):continue
        marker = (cid, us_casefold(title))
        if marker in seen:
            continue
        seen.add(marker)
        out.append({"id": cid, "title": title or cid})
    # Hidden folders stay out of the list. The "All" row is kept on purpose, so
    # nothing looks missing on the web pages: it opens the whole catalogue.
    hidden = _hidden_category_ids_for(profile, media)
    if hidden:
        out = list(row for row in out if row["id"] not in hidden)
    settings = _web_policy_settings()
    out = list(row for row in out if not _web_category_blocked(media, row, settings))
    return {
        "ok": True,
        "account": str(account_id),
        "media_type": media,
        "count": len(out),
        "categories": out,
        "cached": bool(cached),
    }


def _clean_text(value, limit=180):
    text = str(value or "").replace("\x00", " ")
    text = " ".join(text.split()).strip()
    return text[:max(1, int(limit))]


def _item_title(row, media_type, clean_enabled=None):
    if clean_enabled is None:
        clean_enabled = _clean_titles_enabled()
    if not isinstance(row, dict):
        raw = _clean_text(row)
        return _clean_text(_display_name(raw, media_type, clean_enabled)) or raw or "Item"
    for key in ("name", "title", "series_name", "display_name", "channel_name", "movie_name", "original_name"):
        raw = _clean_text(row.get(key))
        if raw:
            return _clean_text(_display_name(raw, media_type, clean_enabled)) or raw
    for key in ("id", "stream_id", "series_id", "ch_id"):
        text = _clean_text(row.get(key), 80)
        if text:
            return "%s %s" % ({"itv": "Channel", "vod": "Movie", "series": "Series"}.get(media_type, "Item"), text)
    return {"itv": "Live channel", "vod": "Movie", "series": "Series"}.get(media_type, "Item")


def _item_year(row):
    if not isinstance(row, dict):
        return ""
    for key in ("year", "release_year", "releasedate", "release_date", "first_air_date", "added"):
        raw = _clean_text(row.get(key), 40)
        if not raw:
            continue
        # Avoid exposing arbitrary provider metadata. Only a plausible 4-digit year
        # is useful in the compact browser catalogue.
        for part in raw.replace("/", "-").split("-"):
            if len(part) == 4 and part.isdigit() and 1900 <= int(part) <= 2200:
                return part
    # Stalker VOD often omits ``year`` but leaves it in the visible title.
    # Mirror the receiver list by recovering only an unambiguous 19xx/20xx/21xx.
    title = _clean_text(row.get("name") or row.get("title") or row.get("movie_name") or row.get("series_name"), 220)
    matches = re.findall(r"(?<!\d)((?:19|20|21)\d{2})(?!\d)", title)
    if matches:
        return matches[-1]
    return ""


def _item_number(row):
    if not isinstance(row, dict):
        return ""
    for key in ("number", "num", "channel_number", "position"):
        value = row.get(key)
        try:
            number = int(str(value).strip())
        except Exception:
            continue
        if 0 < number < 100000:
            return str(number)
    return ""


def _series_season_count(row, profile=None, client=None):
    """Return the best already-local season total without catalogue fan-out.

    Some Stalker catalogues do not carry ``number_of_seasons`` on the parent
    series row even though Ultra Stalker already knows the hierarchy from the
    receiver series cache or the canonical Details/TMDb snapshot.  R5 consults
    those local stores before giving up, but deliberately never opens one
    provider request per poster.
    """
    if not isinstance(row, dict):
        return None

    def _count_value(value):
        if value in (None, ""):
            return None
        if isinstance(value, (list, tuple)):
            return len([x for x in value if x not in (None, "")]) or None
        if isinstance(value, dict):
            # A provider may key embedded seasons by number/id.
            return len([k for k, v in value.items() if k not in (None, "") and v is not None]) or None
        try:
            count = int(float(str(value).strip()))
        except Exception:
            return None
        return count if count > 0 else None

    for key in (
        "number_of_seasons", "seasons_count", "season_count",
        "total_seasons", "seasons_total", "_local_season_count",
        "_local_max_season", "seasons",
    ):
        count = _count_value(row.get(key))
        if count:
            return count

    # Xtream keeps the authoritative season hierarchy in the already-loaded
    # M3UClient series index.  Reading it here is RAM/HDD-only: ordered_page()
    # has already initialised the client, so this never adds a provider request
    # per poster.  This is especially important for one-season shows where the
    # Xtream list endpoint commonly omits number_of_seasons entirely.
    if client is not None and str(_profile_kind(profile) if isinstance(profile, dict) else "") == "xtream":
        try:
            lookup = getattr(client, "_series_index_lookup", None)
            if callable(lookup):
                _sid, data = lookup(row)
                seasons = (data or {}).get("seasons") if isinstance(data, dict) else None
                if isinstance(seasons, dict):
                    count = len(list(k for k, v in seasons.items() if k not in (None, "") and v is not None))
                    if count > 0:
                        return count
                elif isinstance(seasons, (list, tuple)):
                    count = len(list(x for x in seasons if x not in (None, "")))
                    if count > 0:
                        return count
        except Exception:
            pass

    if isinstance(profile, dict):
        # Receiver-owned persistent season catalogue. This is populated when the
        # series has already been opened/prefetched on the box and costs no network.
        try:
            from .ui_screens_series import _series_cache_read
            rows, _updated = _series_cache_read(profile, row, "seasons")
            valid = list(x for x in (rows or []) if isinstance(x, dict))
            if valid:
                return len(valid)
        except Exception:
            pass

        # Details Authority is also local-first and may already contain the TMDb
        # season total from the shared receiver cache.
        try:
            details = _cached_media_details(profile, "series", row) or {}
            overlay = details.get("item_overlay") if isinstance(details, dict) else {}
            sources = [details, overlay if isinstance(overlay, dict) else {}]
            for source in sources:
                for key in (
                    "number_of_seasons", "seasons_count", "season_count",
                    "total_seasons", "seasons_total",
                ):
                    count = _count_value(source.get(key))
                    if count:
                        return count
        except Exception:
            pass

    return None


# ---------------------------------------------------------------------------
# R165 Web artwork bridge
# ---------------------------------------------------------------------------

def _artwork_fields(media_type):
    media = str(media_type or "").lower()
    if media == "series":
        return ("cover_big", "cover", "cover_url", "poster", "poster_url",
                "movie_image", "cover_tmdb", "stream_icon", "logo", "logo_url",
                "screenshot_uri")
    if media == "vod":
        return ("cover_big", "movie_image", "cover_tmdb", "cover", "cover_url",
                "poster", "poster_url", "screenshot_uri", "stream_icon", "logo",
                "logo_url")
    return ("logo", "logo_url", "picon", "stream_icon", "icon", "image", "img", "pic", "cover", "cover_url")


def _provider_artwork_value(row, media_type):
    if not isinstance(row, dict):
        return ""
    for key in _artwork_fields(media_type):
        value = row.get(key)
        if isinstance(value, (list, tuple)):
            value = next((x for x in value if str(x or "").strip()), "")
        text = str(value or "").strip()
        if text and text.lower() not in ("0", "none", "null", "n/a", "na", "false"):
            return text
    return ""


def _has_provider_artwork(row, media_type):
    return bool(_provider_artwork_value(row, media_type))


def _cached_live_picon_for_web(profile, row):
    """Return the receiver's already-cached Live picon without importing ui.py."""
    try:
        remote = _normalized_provider_artwork_url(profile, row, "itv")
        if not remote:
            return ""
        from .persistent_cache import ROOT as _cache_root
        digest = hashlib.sha1(remote.encode("utf-8", "ignore")).hexdigest()
        root = os.path.join(str(_cache_root or ""), "live_picons")
        for ext in (".png", ".jpg", ".jpeg", ".webp"):
            path = os.path.join(root, digest + ext)
            safe = _safe_cached_art_path(path)
            if safe:
                return safe
    except Exception:
        pass
    return ""


def _safe_cached_art_path(value):
    path = str(value or "").strip()
    if not path or not os.path.isfile(path):
        return ""
    try:
        from .persistent_cache import ROOT as _art_root
        real_path = os.path.realpath(path)
        real_root = os.path.realpath(str(_art_root or ""))
        inside = bool(real_root and (real_path == real_root or real_path.startswith(real_root + os.sep)))
        if inside and os.path.getsize(real_path) > 256:
            return real_path
    except (OSError, ImportError):
        return ""
    except Exception:
        return ""
    return ""


def _normalized_provider_artwork_url(profile, row, media_type):
    raw = _provider_artwork_value(row, media_type)
    if not raw:
        return ""
    try:
        parsed = urllib.parse.urlsplit(raw)
        if parsed.scheme in ("http", "https") and parsed.netloc:
            return raw
        if raw.startswith("//"):
            base = urllib.parse.urlsplit(str((profile or {}).get("portal") or ""))
            scheme = base.scheme if base.scheme in ("http", "https") else "https"
            return scheme + ":" + raw
        base = str((profile or {}).get("portal") or "").strip()
        bp = urllib.parse.urlsplit(base)
        if bp.scheme not in ("http", "https") or not bp.netloc:
            return ""
        if raw.startswith("/"):
            joined = "%s://%s%s" % (bp.scheme, bp.netloc, raw)
        else:
            joined = urllib.parse.urljoin(base.rstrip("/") + "/", raw)
        final = urllib.parse.urlsplit(joined)
        return joined if final.scheme in ("http", "https") and final.netloc else ""
    except Exception:
        return ""


def artwork_source(item_id):
    """Resolve one opaque Web item to already-cached or provider artwork.

    The browser never sees provider artwork URLs or filesystem paths. Cached
    Ultra Stalker artwork wins first; provider-native art is only a fallback and
    is proxied by ``webcleaner.py`` through the authenticated same-origin Web UI.
    """
    entry = get_cached_item(item_id)
    media = str(entry.get("media_type") or "").lower()
    row = dict(entry.get("item") or {})
    account = str(entry.get("account") or "")
    is_local = _is_local_account(account)
    profile = _local_profile() if is_local else _find_profile(account)
    artwork_media = "series" if media == "episode" else media

    if is_local:
        for key in ("poster_local", "_poster_local", "_poster_source_local", "_cin_provider_poster_local"):
            local = _safe_local_art_path(row.get(key))
            if local:
                return {"kind": "file", "value": local, "media_type": artwork_media}

    if artwork_media in ("vod", "series"):
        try:
            from .artwork_v2 import load_fast_local_poster
            cached = load_fast_local_poster(profile, artwork_media, row) or {}
            local = str(cached.get("poster_local") or "").strip() if isinstance(cached, dict) else ""
            local = _safe_cached_art_path(local)
            if local:
                return {"kind": "file", "value": local, "media_type": media}
        except Exception:
            pass
        # Local receiver views can resolve artwork through the canonical
        # title/year -> TMDb cache even when the compact Local index has only a
        # backdrop pointer. Mirror that same HDD-only bridge before showing a
        # placeholder. No provider/TMDb network request is allowed here.
        if is_local:
            details = _cached_media_details(profile, artwork_media, row)
            local = _safe_cached_art_path(
                details.get("poster_local") or details.get("display_poster_local")
            ) if isinstance(details, dict) else ""
            if local:
                return {"kind": "file", "value": local, "media_type": media}
            local = _cached_poster_by_tmdb(artwork_media, row, details=details)
            if local:
                return {"kind": "file", "value": local, "media_type": media}
    elif media == "itv":
        local = _cached_live_picon_for_web(profile, row)
        if local:
            return {"kind": "file", "value": local, "media_type": media}

    if is_local:
        return {"kind": "placeholder", "value": "", "media_type": artwork_media}
    remote = _normalized_provider_artwork_url(profile, row, artwork_media)
    if remote:
        return {"kind": "url", "value": remote, "media_type": artwork_media}
    return {"kind": "placeholder", "value": "", "media_type": artwork_media}


# ---------------------------------------------------------------------------
# R166 cinematic series-details bridge
# ---------------------------------------------------------------------------

def _first_public_text(row, keys, limit=1200):
    src = row if isinstance(row, dict) else {}
    for key in keys:
        value = src.get(key)
        if isinstance(value, (list, tuple, dict)):
            continue
        text = _clean_text(value, limit)
        if text and text.lower() not in ("none", "null", "n/a", "na"):
            return text
    return ""


def _public_genres(value):
    out = []
    if isinstance(value, dict):
        value = list(value.values())
    if isinstance(value, (list, tuple, set)):
        seq = list(value)
    else:
        text = _clean_text(value, 300)
        if not text:
            return []
        seq = re.split(r"\s*(?:,|/|\||•|;)\s*", text)
    for item in seq:
        if isinstance(item, dict):
            text = _clean_text(item.get("name") or item.get("title"), 60)
        else:
            text = _clean_text(item, 60)
        if text and us_casefold(text) not in [us_casefold(x) for x in out]:
            out.append(text)
        if len(out) >= 5:
            break
    return out


def _public_meta_sources(row):
    src = row if isinstance(row, dict) else {}
    out = [src]
    for key in ("item_overlay", "metadata", "info", "details"):
        nested = src.get(key)
        if isinstance(nested, dict):
            out.append(nested)
    return out


def _public_rating(row):
    for src in _public_meta_sources(row):
        for key in ("rating_imdb", "imdb_rating", "rating", "vote_average", "tmdb_rating", "imdb_score"):
            value = src.get(key)
            try:
                rating = float(str(value).strip())
            except Exception:
                continue
            if rating > 10.0 and rating <= 100.0:
                rating = rating / 10.0
            if 0.0 < rating <= 10.0:
                return round(rating, 1)
    return None


def _public_age_rating(row):
    try:
        from .age_rating import display_certification
    except Exception:
        return ""
    for src in _public_meta_sources(row):
        for key in ("certification", "age_rating", "content_rating", "rating_mpaa", "mpaa_rating", "parental_rating", "age_limit", "age"):
            try:
                label = display_certification(src.get(key))
            except Exception:
                label = ""
            if label:
                return str(label)
    return ""


def _public_runtime(row):
    src = row if isinstance(row, dict) else {}
    candidates = [src.get("runtime"), src.get("duration"), src.get("time"), src.get("episode_run_time")]
    for value in candidates:
        if isinstance(value, (list, tuple)):
            value = next((x for x in value if x not in (None, "", 0, "0")), "")
        try:
            minutes = int(float(str(value).strip()))
        except Exception:
            continue
        if 1 <= minutes <= 1000:
            return minutes
    return None


def _cached_media_details(profile, media_type, row):
    media = str(media_type or "").lower()
    if media not in ("vod", "series"):
        return {}
    try:
        from .details_authority import load_canonical
        data = load_canonical(profile, media, row) or {}
        return dict(data) if isinstance(data, dict) else {}
    except Exception:
        return {}


def _card_meta_key(profile, media_type, row):
    src = row if isinstance(row, dict) else {}
    ident = ""
    for key in ("id", "movie_id", "series_id", "stream_id", "tmdb_id", "tmdbid", "imdb_id", "imdb", "cmd", "url", "name", "title"):
        value = src.get(key)
        if value not in (None, ""):
            ident = "%s=%s" % (key, str(value)[:240])
            break
    if not ident:
        ident = str(_item_title(src, media_type, False) or "")[:240]
    return "%s|%s|%s" % (_account_id(profile or {}), str(media_type or "").lower(), ident)


def _public_card_metadata(profile, media_type, row, cache_probe=True):
    """Return lightweight poster-card facts without waking any network path.

    Provider-list metadata wins immediately.  Missing year/rating/age may be
    filled from the receiver's existing canonical HDD metadata only.  The
    result is RAM-cached so infinite-scroll revisits do not keep touching disk.
    """
    media = str(media_type or "").lower()
    src = row if isinstance(row, dict) else {}
    year = _item_year(src)
    rating = _public_rating(src)
    age = _public_age_rating(src)
    if media not in ("vod", "series"):
        return {"year": year, "rating": rating, "age_rating": age}

    key = _card_meta_key(profile, media, src)
    now = time.time()
    cached = None
    with _CARD_META_RAM_LOCK:
        entry = _CARD_META_RAM.get(key)
        if isinstance(entry, tuple) and len(entry) == 2 and now - float(entry[0] or 0) <= _CARD_META_RAM_TTL:
            cached = dict(entry[1] or {})
    if cached is not None:
        return cached

    # Cache-only probe. load_canonical reads local metadata snapshots and never
    # resolves provider/TMDb/IMDb network data.  Probe only when a visible fact
    # is actually missing from the provider row.
    if cache_probe and (not year or rating is None or not age):
        details = _cached_media_details(profile, media, src) or {}
        if isinstance(details, dict) and details:
            if not year:
                year = _item_year(details)
            if rating is None:
                rating = _public_rating(details)
            if not age:
                age = _public_age_rating(details)

    result = {"year": year, "rating": rating, "age_rating": age}
    with _CARD_META_RAM_LOCK:
        _CARD_META_RAM[key] = (now, dict(result))
        if len(_CARD_META_RAM) > _CARD_META_RAM_MAX:
            oldest = sorted(_CARD_META_RAM.items(), key=lambda pair: float((pair[1] or (0,))[0] or 0))[:max(1, len(_CARD_META_RAM) - _CARD_META_RAM_MAX)]
            for old_key, _old in oldest:
                _CARD_META_RAM.pop(old_key, None)
    return result


def _apply_public_card_metadata(item, profile, media_type, row, cache_probe=True):
    if not isinstance(item, dict):
        return item
    meta = _public_card_metadata(profile, media_type, row, cache_probe=cache_probe)
    year = meta.get("year")
    rating = meta.get("rating")
    age = str(meta.get("age_rating") or "").strip()
    if year:
        item["year"] = year
    if rating is not None:
        item["rating"] = rating
    if age:
        item["age_rating"] = age
    return item


def _cached_poster_by_tmdb(media, row, details=None):
    """Return the canonical HDD poster for a numeric TMDb id, local-only."""
    sources = [row if isinstance(row, dict) else {}]
    if isinstance(details, dict):
        sources.append(details)
        overlay = details.get("item_overlay")
        if isinstance(overlay, dict):
            sources.append(overlay)
    tmdb_ids = []
    for source in sources:
        for key in ("_locked_tmdb_id", "_ultra_search_verified_tmdb_id", "tmdb_id", "tmdbid", "tmdb"):
            raw = str(source.get(key) or "").strip()
            if not raw or not raw.isdigit():
                continue
            try:
                value = int(raw)
            except Exception:
                continue
            if value > 0 and value not in tmdb_ids:
                tmdb_ids.append(value)
    if not tmdb_ids:
        return ""
    try:
        from .artwork_v2 import canonical_art_paths
    except Exception:
        return ""
    for tmdb_id in tmdb_ids:
        try:
            paths = canonical_art_paths(media, tmdb_id) or {}
            local = _safe_cached_art_path(paths.get("poster"))
            if local:
                return local
        except Exception:
            continue
    return ""


def _cached_backdrop_by_tmdb(media, row, details=None):
    """Return the canonical HDD backdrop for a numeric TMDb id, local-only.

    Xtream list rows often carry the correct TMDb identity but use a different
    provider/content key than the receiver view that originally populated the
    artwork cache.  The canonical library is keyed by TMDb id, so consult that
    path directly before any details resolver can wake the network.
    """
    sources = [row if isinstance(row, dict) else {}]
    if isinstance(details, dict):
        sources.append(details)
        overlay = details.get("item_overlay")
        if isinstance(overlay, dict):
            sources.append(overlay)
    tmdb_ids = []
    for source in sources:
        for key in ("_locked_tmdb_id", "_ultra_search_verified_tmdb_id", "tmdb_id", "tmdbid", "tmdb"):
            raw = str(source.get(key) or "").strip()
            if not raw or not raw.isdigit():
                continue
            try:
                value = int(raw)
            except Exception:
                continue
            if value > 0 and value not in tmdb_ids:
                tmdb_ids.append(value)
    if not tmdb_ids:
        return ""
    try:
        from .artwork_v2 import canonical_art_paths
    except Exception:
        return ""
    for tmdb_id in tmdb_ids:
        try:
            paths = canonical_art_paths(media, tmdb_id) or {}
            local = _safe_cached_art_path(paths.get("backdrop"))
            if local:
                return local
        except Exception:
            continue
    return ""


def _tmdb_backdrop_path_from_sources(row, details=None):
    """Return a TMDb file_path without accepting arbitrary provider URLs."""
    sources = [row if isinstance(row, dict) else {}]
    if isinstance(details, dict):
        sources.append(details)
        overlay = details.get("item_overlay")
        if isinstance(overlay, dict):
            sources.append(overlay)
    for source in sources:
        for key in ("backdrop_path", "tmdb_backdrop_path", "tmdb_backdrop_url", "backdrop_url", "backdrop"):
            raw = source.get(key)
            if isinstance(raw, (list, tuple)):
                raw = raw[0] if raw else ""
            raw = str(raw or "").strip()
            if not raw:
                continue
            # Native TMDb path, e.g. /abc123.jpg.  Trust it only from fields
            # whose semantics explicitly identify a backdrop path.
            if raw.startswith("/") and key in ("backdrop_path", "tmdb_backdrop_path"):
                match = re.search(r"/t/p/[^/]+(/.+)$", raw)
                return match.group(1) if match else raw
            # If Xtream already returned a TMDb CDN URL, normalize it back to
            # file_path so Web always requests the same w1280 lane.
            try:
                parsed = urllib.parse.urlsplit(raw)
                if parsed.scheme == "https" and (parsed.hostname or "").lower() == "image.tmdb.org":
                    match = re.search(r"/t/p/[^/]+(/.+)$", parsed.path or "")
                    if match:
                        return match.group(1)
            except Exception:
                pass
    return ""


def _tmdb_id_from_sources(row, details=None):
    sources = [row if isinstance(row, dict) else {}]
    if isinstance(details, dict):
        sources.append(details)
        overlay = details.get("item_overlay")
        if isinstance(overlay, dict):
            sources.append(overlay)
    for source in sources:
        for key in ("_locked_tmdb_id", "_ultra_search_verified_tmdb_id", "tmdb_id", "tmdbid", "tmdb"):
            raw = str(source.get(key) or "").strip()
            if raw.isdigit():
                try:
                    value = int(raw)
                except Exception:
                    value = 0
                if value > 0:
                    return value
    return 0


def _remote_tmdb_backdrop_url(profile, media, row, details=None):
    """Resolve a browser-direct TMDb w1280 URL without downloading image bytes.

    Local receiver artwork has already missed when this helper is called.  We
    first reuse any TMDb backdrop_path already present in Xtream/canonical
    metadata.  If only a verified/numeric TMDb id is known, perform one small
    TMDb JSON details request and cache only the resulting URL in RAM.  No image
    download, JPEG conversion or HDD artwork write happens in this lane.
    """
    media = str(media or "").lower()
    if media not in ("vod", "series"):
        return ""
    try:
        from .storage import load_settings
        cfg = dict(load_settings() or {})
    except Exception:
        cfg = {}

    # A known TMDb file_path needs no API call or heavy TMDb implementation at
    # all.  Hand the CDN URL straight to the browser.
    path = _tmdb_backdrop_path_from_sources(row, details=details)
    if path:
        return "https://image.tmdb.org/t/p/w1280" + (path if path.startswith("/") else "/" + path)

    credential = str(cfg.get("tmdb_credential") or "").strip()
    if not credential or not cfg.get("tmdb_enabled", True):
        return ""
    try:
        from .tmdb import TMDBClient
    except Exception:
        return ""

    tmdb_id = _tmdb_id_from_sources(row, details=details)
    if not tmdb_id:
        return ""
    tmdb_kind = "tv" if media == "series" else "movie"
    cache_key = (tmdb_kind, int(tmdb_id))
    now = time.time()
    with _REMOTE_BACKDROP_LOCK:
        cached = _REMOTE_BACKDROP_RAM.get(cache_key)
        # A failed lookup is remembered only briefly: one transient TMDb timeout
        # must not hide the backdrop for the whole 30 minutes.
        if cached and now - float(cached.get("stored_at") or 0) <= (
                _REMOTE_BACKDROP_TTL if cached.get("url") else _REMOTE_BACKDROP_FAIL_TTL):
            return str(cached.get("url") or "")

    try:
        timeout = min(6, max(3, int(cfg.get("timeout", 6) or 6)))
    except Exception:
        timeout = 6
    language = str(cfg.get("tmdb_language") or "ar-EG").strip() or "ar-EG"
    try:
        client = TMDBClient(credential, language, timeout)
        payload = client._get("/%s/%s" % (tmdb_kind, int(tmdb_id)), {"language": language}) or {}
        path = str(payload.get("backdrop_path") or "").strip() if isinstance(payload, dict) else ""
        url = str(TMDBClient.image_url(path, "w1280") or "") if path else ""
    except Exception:
        url = ""
    with _REMOTE_BACKDROP_LOCK:
        _REMOTE_BACKDROP_RAM[cache_key] = {"stored_at": now, "url": url}
        while len(_REMOTE_BACKDROP_RAM) > 256:
            try:
                _REMOTE_BACKDROP_RAM.pop(next(iter(_REMOTE_BACKDROP_RAM)))
            except Exception:
                us_clear(_REMOTE_BACKDROP_RAM)
                break
    return url


def backdrop_source(item_id):
    """Return cached receiver art first, then a browser-direct TMDb fallback.

    R8 keeps the receiver-owned cache authoritative.  On a cache miss, only a
    tiny TMDb JSON lookup may run here; the returned image URL is redirected to
    the phone/browser so backdrop bytes never pass through or persist on the
    receiver.
    """
    entry = get_cached_item(item_id)
    media = str(entry.get("media_type") or "").lower()
    if media not in ("vod", "series"):
        raise BrowseError("item has no cinematic backdrop")
    row = dict(entry.get("item") or {})
    account = str(entry.get("account") or "")
    is_local = _is_local_account(account)
    profile = _local_profile() if is_local else _find_profile(account)

    if is_local:
        for key in ("_backdrop_source_local", "_cin_provider_backdrop_local", "backdrop_local", "display_backdrop_local"):
            local = _safe_local_art_path(row.get(key))
            if local:
                return {"kind": "file", "value": local, "media_type": media}

    # 0) Xtream/cache-key independent fast path: if the catalogue already gives
    # us a verified numeric TMDb id, jump straight to the shared canonical HDD
    # artwork. This avoids waiting for Details to resolve/cache the same title.
    local = _cached_backdrop_by_tmdb(media, row)
    if local:
        return {"kind": "file", "value": local, "media_type": media}

    # 1) Reuse any local hand-off already attached by Cinematic/Details/Grid.
    for key in (
        "_backdrop_source_local", "_cin_provider_backdrop_local",
        "backdrop_local", "display_backdrop_local", "source_backdrop_local",
    ):
        local = _safe_cached_art_path(row.get(key))
        if local:
            return {"kind": "file", "value": local, "media_type": media}

    # 2) HDD-only fast bridge into the one canonical TMDb artwork library.
    # Despite the historic function name it returns both poster_local and
    # backdrop_local and performs no network request or directory scan.
    try:
        from .artwork_v2 import load_fast_local_poster
        cached = load_fast_local_poster(profile, media, row) or {}
        if isinstance(cached, dict):
            local = _safe_cached_art_path(
                cached.get("backdrop_local") or cached.get("display_backdrop_local")
            )
            if local:
                return {"kind": "file", "value": local, "media_type": media}
    except Exception:
        pass

    # 3) Canonical details snapshot, still local-only.
    details = _cached_media_details(profile, media, row)
    local = _safe_cached_art_path(
        details.get("backdrop_local") or details.get("display_backdrop_local")
    )
    if local:
        return {"kind": "file", "value": local, "media_type": media}
    local = _cached_backdrop_by_tmdb(media, row, details=details)
    if local:
        return {"kind": "file", "value": local, "media_type": media}

    # 4) Cache miss: use TMDb only as a browser-direct fallback.  The Web HTTP
    # handler redirects the phone to image.tmdb.org; it must never proxy these
    # image bytes through the receiver.
    if is_local:
        return {"kind": "none", "value": "", "media_type": media}
    remote = _remote_tmdb_backdrop_url(profile, media, row, details=details)
    if remote:
        return {"kind": "url", "value": remote, "media_type": media}
    return {"kind": "none", "value": "", "media_type": media}


def media_details(item_id):
    """Return sanitized provider/TMDb metadata for Movie or Series Web details.

    The same Details Authority used by the receiver remains the source of truth,
    so Web does not create a second TMDb/cache stack.
    """
    token = str(item_id or "").strip()
    entry = get_cached_item(token)
    media = str(entry.get("media_type") or "").lower()
    if media not in ("vod", "series"):
        raise BrowseError("item has no cinematic details")
    account = str(entry.get("account") or "")
    is_local = _is_local_account(account)
    profile = _local_profile() if is_local else _find_profile(account)
    row = dict(entry.get("item") or {})
    try:
        from .storage import load_settings
        settings = dict(load_settings() or {})
    except Exception:
        settings = {}

    details = _cached_media_details(profile, media, row)
    if not is_local:
        _prov_client = None
        try:
            # Provider Web Details may use the existing metadata-only fast path.
            # Local Web never performs metadata/provider/TMDb network work.
            from .details_authority import resolve_metadata_fast, _arabic_description_missing
            if row.get("_xtream") and _arabic_description_missing(settings, details, row):
                try:
                    _prov_client = _new_client(profile, timeout=min(6, int(settings.get("timeout", 10) or 10)))
                except Exception:
                    _prov_client = None
            resolved = resolve_metadata_fast(profile, media, row, current=details, settings=settings, provider_client=_prov_client) or {}
            if isinstance(resolved, dict) and resolved:
                details.update(resolved)
        except Exception:
            pass
        finally:
            if _prov_client is not None:
                try:
                    _prov_client.close()
                except Exception:
                    pass

    merged = dict(row)
    merged.update(details)
    title = _item_title(row, media, _clean_titles_enabled())
    year = _item_year(details) or _item_year(row)
    overview = _first_public_text(merged, (
        "overview", "description_full", "description", "descr", "plot", "plot_outline", "storyline"
    ), 1600)
    try:
        # Arabic description language: the longest Arabic text from any source wins.
        from .details_authority import choose_description_for_settings
        _desc_keys = ("_details_provider_overview", "overview", "description_full", "description",
                      "descr", "plot", "plot_outline", "storyline")
        _desc_candidates = []
        for _src in (row, details, merged):
            if not isinstance(_src, dict):
                continue
            for _k in _desc_keys:
                _txt = _first_public_text(_src, (_k,), 1600)
                if _txt and _txt not in _desc_candidates:
                    _desc_candidates.append(_txt)
        overview = choose_description_for_settings(_desc_candidates, settings) or overview
    except Exception:
        pass
    try:
        # Same synopsis the on-screen Details/Cinematic/grids show (every language).
        from .details_authority import synopsis_text
        _auth_text = synopsis_text(profile, media, row, details)
        if _auth_text:
            overview = _first_public_text({"_s": _auth_text}, ("_s",), 1600) or overview
    except Exception:
        pass
    tagline = _first_public_text(merged, ("tagline", "slogan"), 260)
    genres = _public_genres(merged.get("genres") or merged.get("genre"))
    rating = _public_rating(merged)
    runtime = _public_runtime(merged)
    status = _first_public_text(merged, ("status",), 80)
    date_text = _first_public_text(
        merged,
        ("first_air_date", "release_date", "releasedate") if media == "series" else ("release_date", "releasedate", "first_air_date"),
        40,
    )
    tmdb_id = details.get("tmdb_id") if isinstance(details, dict) else None
    try:
        has_backdrop = backdrop_source(token).get("kind") in ("file", "url")
    except Exception:
        has_backdrop = False
    kind = "Series" if media == "series" else "Movie"
    return {
        "ok": True,
        "item": token,
        "media_type": media,
        "kind": kind,
        "title": _clean_text(title, 180) or kind,
        "year": year,
        "date": date_text,
        "first_air_date": date_text if media == "series" else "",
        "release_date": date_text if media == "vod" else "",
        "overview": overview,
        "tagline": tagline,
        "genres": genres,
        "rating": rating,
        "runtime": runtime,
        "status": status,
        "tmdb_enriched": bool(tmdb_id),
        "has_backdrop": bool(has_backdrop),
        "poster": "/api/browse/artwork?item=" + urllib.parse.quote(token, safe=""),
        "backdrop": ("/api/browse/backdrop?item=" + urllib.parse.quote(token, safe="")) if has_backdrop else "",
    }


def series_details(item_id):
    """Compatibility wrapper for the R166 series-only Web API."""
    result = media_details(item_id)
    if str(result.get("media_type") or "") != "series":
        raise BrowseError("item is not a series")
    return result


def _prune_item_cache(now=None):
    now = float(now if now is not None else time.time())
    with _ITEM_CACHE_LOCK:
        expired = list(token for token, entry in _ITEM_CACHE.items()
                   if now - float(entry.get("stored_at") or 0) > _ITEM_CACHE_TTL)
        for token in expired:
            _ITEM_CACHE.pop(token, None)
        excess = len(_ITEM_CACHE) - _ITEM_CACHE_MAX
        if excess > 0:
            oldest = sorted(_ITEM_CACHE.items(), key=lambda pair: float(pair[1].get("stored_at") or 0))[:excess]
            for token, _entry in oldest:
                _ITEM_CACHE.pop(token, None)


def _store_item(account_id, media_type, category_id, category_title, row, parent_id=""):
    row = dict(row) if isinstance(row, dict) else {"name": _clean_text(row)}
    policy = _web_policy_snapshot(account_id, media_type, category_id, row, parent_id)
    _web_authorize_snapshot(account_id, media_type, policy)
    _prune_item_cache()
    token = "itm_" + secrets.token_urlsafe(18).rstrip("=")
    entry = {
        "stored_at": time.time(),
        "account": str(account_id or ""),
        "media_type": str(media_type or ""),
        "category": str(category_id or ""),
        "category_title": _clean_text(category_title, 180),
        "item": dict(row) if isinstance(row, dict) else {"name": _clean_text(row)},
        "parent": str(parent_id or ""),
        "policy": policy,
    }
    with _ITEM_CACHE_LOCK:
        _ITEM_CACHE[token] = entry
    return token


def get_cached_item(item_id):
    """Return a private server-side item snapshot for later browse phases."""
    token = str(item_id or "").strip()
    if not token:
        raise BrowseError("missing item")
    _prune_item_cache()
    with _ITEM_CACHE_LOCK:
        entry = _ITEM_CACHE.get(token)
        if not entry:
            raise BrowseError("item expired; reopen the category")
        # Refresh active entries while the phone is navigating.
        entry["stored_at"] = time.time()
        snapshot = {
            "account": entry.get("account") or "",
            "media_type": entry.get("media_type") or "",
            "category": entry.get("category") or "",
            "category_title": entry.get("category_title") or "",
            "item": dict(entry.get("item") or {}),
            "parent": entry.get("parent") or "",
            "policy": dict(entry.get("policy") or {}),
        }
    _web_authorize_snapshot(snapshot["account"], snapshot["media_type"], snapshot["policy"])
    return snapshot


def _ordered_page_resilient(client, media, category, page_no):
    payload = client.ordered_page(media, category, page_no) or {}
    rows = list(row for row in (payload.get("items") or []) if isinstance(row, dict) and row)
    try:
        page_size = max(1, int(payload.get("page_size") or len(rows) or 1))
    except Exception:
        page_size = max(1, len(rows) or 1)
    try:
        total = max(0, int(payload.get("total") or 0))
    except Exception:
        total = 0
    offset = max(0, (int(page_no) - 1) * page_size)
    # Match the receiver grid's endurance lane: if provider metadata says this
    # native page should contain more rows, invalidate only the client's content
    # cache generation and retry exactly once. This fixes intermittent empty or
    # short Stalker pages without scanning or duplicating IPTV logic in Web.
    transient_empty = bool(not rows and getattr(client, "_web_isolated_stalker", False))
    unexpectedly_short = bool(total > offset + len(rows) and len(rows) < page_size)
    if (unexpectedly_short or transient_empty) and getattr(client, "_web_isolated_stalker", False):
        try:
            bump = getattr(client, "_bump_content_cache_generation", None)
            if callable(bump):
                bump()
        except Exception:
            pass
        try:
            retry = client.ordered_page(media, category, page_no) or {}
            retry_rows = list(row for row in (retry.get("items") or []) if isinstance(row, dict) and row)
            if len(retry_rows) > len(rows):
                payload = retry
                rows = retry_rows
        except Exception:
            pass
    return payload, rows


def list_items(account_id, media_type, category_id="*", page=1, category_title=""):
    media = str(media_type or "").strip().lower()
    if media not in _MEDIA_TYPES:
        raise BrowseError("invalid media type")
    account = str(account_id or "").strip()
    if not account:
        raise BrowseError("missing account")
    category = str(category_id if category_id not in (None, "") else "*").strip() or "*"
    title = _clean_text(category_title, 180)
    try:
        page_no = max(1, min(int(page or 1), 100000))
    except Exception:
        raise BrowseError("invalid page")

    profile = _find_profile(account)
    is_stalker = _profile_kind(profile) == "portal"
    catalog = _web_policy_catalog(profile, media)
    trusted_categories = catalog.get(us_casefold(category), [])
    settings = _web_policy_settings()
    if _web_category_blocked(media, {"id":category}, settings):
        raise BrowseError("This category is restricted in Web Browse")
    if category != "*":
        if any(_web_category_blocked(media, x, settings) for x in trusted_categories) or _web_category_blocked(media, {"id":category}, settings):
            raise BrowseError("This category is restricted in Web Browse")
        if not trusted_categories and any(_web_policy_rules(media, settings)):
            raise BrowseError("Content category is unavailable under Web parental controls")
    title = trusted_categories[0]["title"] if trusted_categories else ""
    hidden = _hidden_category_ids_for(profile, media)
    if hidden and category in hidden:
        # A hidden folder is never requested, even if an old tab or bookmark
        # still asks for it. "All" (*) stays available.
        return {
            "ok": True, "account": account, "media_type": media,
            "category": category, "category_title": title, "items": [], "count": 0,
            "page": page_no, "page_size": 1, "total": 0, "pages": 0,
            "has_prev": False, "has_next": False,
        }
    cached_payload, cached_rows, cached_age = _page_ram_get(profile, media, category, page_no)
    client = None

    if is_stalker and cached_rows and cached_age is not None and cached_age <= _PAGE_RAM_FAST_TTL:
        payload, rows = cached_payload or {}, cached_rows
    else:
        provider_failed = False
        try:
            # R5.514: one bounded retry with a fresh client and a longer timeout.  A single
            # slow/failed provider call used to end the whole infinite scroll
            # ("Unable to load more items") after the first page.
            for _attempt in (0, 1):
                try:
                    client = _new_client(profile, timeout=(10 if is_stalker else 12) + 8 * _attempt)
                    payload, rows = _ordered_page_resilient(client, media, category, page_no)
                    break
                except BrowseError:
                    raise
                except Exception:
                    if _attempt:
                        raise
                    try:
                        if client is not None:
                            client.close()
                    except Exception:
                        pass
                    client = None
                    time.sleep(0.6)

            # Route fallback for provider category aliases.  Some Stalker Series
            # catalogues expose a numeric folder id in get_categories but expect
            # the visible category title/alias in get_ordered_list.  R199/R200
            # accidentally disabled this fallback for Stalker, which made every
            # Series folder look empty while Live/Movies still worked.  Keep VOD
            # on the proven id path and retry only empty Stalker Series folders.
            aliases = catalog.get(us_casefold(title), []) if title else []
            # An alias shared by several folders cannot prove which folder a
            # category-less result belongs to, even if both are public today.
            unique_alias = len({str(x["id"]) for x in aliases}) == 1
            allow_title_fallback = ((not is_stalker) or media == "series") and unique_alias
            if not rows and allow_title_fallback and media in ("vod", "series") and title and title != category:
                alt, alt_rows = _ordered_page_resilient(client, media, title, page_no)
                if alt_rows:
                    payload = alt
                    rows = alt_rows
        except BrowseError:
            raise
        except Exception:
            provider_failed = True
            payload, rows = {}, []
        finally:
            if client is not None:
                try:
                    client.close()
                except Exception:
                    pass

        if rows:
            _page_ram_put(profile, media, category, page_no, payload, rows)
        elif is_stalker and cached_rows:
            # Never replace a known-good selected-source page with one transient
            # empty/error. _ordered_page_resilient already used one bounded retry.
            payload, rows = cached_payload or {}, cached_rows
        elif provider_failed:
            raise BrowseError("provider items unavailable")

    try:
        current_page = max(1, int(payload.get("page") or page_no))
    except Exception:
        current_page = page_no
    try:
        page_size = max(1, int(payload.get("page_size") or len(rows) or 1))
    except Exception:
        page_size = max(1, len(rows) or 1)
    try:
        total = max(0, int(payload.get("total") or 0))
    except Exception:
        total = 0

    clean_enabled = _clean_titles_enabled()
    try:
        from .storage import load_content_states
        favorite_states = list(load_content_states(profile, media, rows) or [])
    except Exception:
        favorite_states = []
    items = []
    for index, row in enumerate(rows):
        try:token = _store_item(account, media, category, title, row)
        except BrowseError:continue
        state = favorite_states[index] if index < len(favorite_states) and isinstance(favorite_states[index], dict) else {}
        item = {
            "id": token,
            "title": _item_title(row, media, clean_enabled),
            "favorite": bool(state.get("favorite")),
            "source_kind": _profile_kind(profile),
        }
        try:
            _apply_public_card_metadata(item, profile, media, row)
        except Exception:
            pass  # one odd row must never fail the whole page
        if media == "series":
            try:
                season_count = _series_season_count(row, profile, client=client)
            except Exception:
                season_count = None
            if season_count is not None:
                item["season_count"] = season_count
        if media == "itv":
            number = _item_number(row)
            if number:
                item["number"] = number
            item["has_picon"] = bool(_has_provider_artwork(row, "itv") or _cached_live_picon_for_web(profile, row))
        items.append(item)

    pages = int(math.ceil(float(total) / float(page_size))) if total > 0 and page_size > 0 else 0
    has_prev = current_page > 1
    if total > 0:
        # Trust a self-consistent advertised total. If the provider claims fewer
        # rows than it has already returned, keep navigation open for one more
        # bounded request instead of silently hiding the overflow.
        advertised_more = current_page * page_size < total
        under_reported = total < current_page * page_size and bool(rows) and len(rows) >= page_size
        has_next = advertised_more or under_reported
    else:
        # Some Stalker portals omit total_items. A full native page is the best
        # safe signal that another page may exist; the next request remains bounded.
        has_next = bool(rows) and len(rows) >= page_size

    return {
        "ok": True,
        "account": account,
        "media_type": media,
        "category": category,
        "category_title": title,
        "items": items,
        "count": len(items),
        "provider_count": len(rows),
        "filtered_count": len(rows) - len(items),
        "page": current_page,
        "page_size": page_size,
        "total": total,
        "pages": pages,
        "has_prev": has_prev,
        "has_next": has_next,
    }


def _simple_number(value, fallback=""):
    # Preserve numeric zero (Season 0 / Specials). _clean_text(value) used
    # ``value or ""`` and therefore turned integer 0 into an empty string.
    raw = _clean_text(str(value) if value is not None else "", 30)
    if not raw:
        return str(fallback or "")
    try:
        number = int(float(raw))
    except Exception:
        return str(fallback or "")
    if 0 <= number < 100000:
        return str(number)
    return str(fallback or "")


def _season_number(row, fallback=1):
    if not isinstance(row, dict):
        return str(fallback)
    for key in ("season", "season_number", "number"):
        number = _simple_number(row.get(key))
        if number:
            return number
    sid = _clean_text(row.get("season_id") or row.get("id"), 80)
    if ":" in sid:
        number = _simple_number(sid.rsplit(":", 1)[-1])
        if number:
            return number
    number = _simple_number(sid)
    return number or str(fallback)


def _season_title(row, number):
    if isinstance(row, dict):
        for key in ("name", "title", "season_name", "label"):
            text = _clean_text(row.get(key), 140)
            if text:
                return text
    return "Season %s" % (number or "1")


def _episode_number(row, fallback=1):
    if not isinstance(row, dict):
        return str(fallback)
    for key in ("episode_num", "episode_number", "episode", "number"):
        number = _simple_number(row.get(key))
        if number:
            return number
    return str(fallback)


def _episode_title(row, fallback=1, clean_enabled=None):
    if clean_enabled is None:
        clean_enabled = _clean_titles_enabled()
    if isinstance(row, dict):
        for key in ("name", "title", "episode_name", "original_name", "original_title"):
            raw = _clean_text(row.get(key), 180)
            if raw:
                return _clean_text(_display_name(raw, "episode", clean_enabled), 180) or raw
    return "Episode %s" % fallback


def _season_episode_count(row):
    """Return the provider's season episode total without assuming row shape.

    Stalker portals commonly expose ``series`` / ``episodes`` as a list of
    scalar episode ids rather than dictionaries.  The old Web bridge counted
    dictionaries only, which made perfectly populated seasons render as
    ``0 episodes``.  Compare explicit totals with embedded entries and keep the
    richest non-negative value so a stale provider ``0`` cannot hide real ids.
    """
    if not isinstance(row, dict):
        return None

    candidates = []
    for key in (
        "episode_count", "episodes_count", "number_of_episodes",
        "total_episodes", "episodes_total", "count_episodes",
    ):
        value = row.get(key)
        if value in (None, ""):
            continue
        try:
            count = int(float(str(value).strip()))
        except Exception:
            continue
        if count >= 0:
            candidates.append(count)

    embedded = row.get("episodes")
    if embedded in (None, "", []):
        embedded = row.get("series")

    if isinstance(embedded, (list, tuple)):
        candidates.append(sum(1 for value in embedded if value not in (None, "")))
    elif isinstance(embedded, dict):
        # Some adapters key episodes by episode number/id.
        candidates.append(sum(1 for key, value in embedded.items() if key not in (None, "") and value is not None))

    return max(candidates) if candidates else None


def list_seasons(series_item_id):
    series_token = str(series_item_id or "").strip()
    series_entry = get_cached_item(series_token)
    if series_entry.get("media_type") != "series":
        raise BrowseError("item is not a series")

    account = str(series_entry.get("account") or "")
    is_local = _is_local_account(account)
    profile = _local_profile() if is_local else _find_profile(account)
    series_row = dict(series_entry.get("item") or {})
    client = None
    try:
        client = _local_web_context("series")[1] if is_local else _new_client(profile, timeout=15)
        rows = client.series_seasons(series_row) or []
    except BrowseError:
        raise
    except Exception:
        raise BrowseError("provider seasons unavailable")
    finally:
        if client is not None:
            try:
                client.close()
            except Exception:
                pass

    clean_enabled = _clean_titles_enabled()
    series_visible_title = _item_title(series_row, "series", clean_enabled)
    seasons = []
    seen = set()
    for pos, row in enumerate(rows if isinstance(rows, list) else [], 1):
        if not isinstance(row, dict) or not row:
            continue
        number = _season_number(row, pos)
        title = _season_title(row, number)
        marker = (number, us_casefold(title))
        if marker in seen:
            continue
        seen.add(marker)
        token = _store_item(
            account, "season", series_entry.get("category") or "*",
            series_visible_title, row, parent_id=series_token,
        )
        item = {"id": token, "title": title, "number": number, "local": bool(_is_local_account(account))}
        episode_count = _season_episode_count(row)
        if episode_count is not None:
            item["episode_count"] = episode_count
        seasons.append(item)

    # R3: provider order is not presentation order.  Always show numbered
    # seasons naturally from 1 upward.  Specials/Season 0 and unknown values
    # follow the normal numbered seasons, while Python's stable sort preserves
    # provider order for ties.
    def _season_order(item):
        raw = str((item or {}).get("number") or "").strip()
        try:
            number = int(float(raw))
        except Exception:
            return (2, 1000000)
        if number >= 1:
            return (0, number)
        if number == 0:
            return (1, 0)
        return (2, number)

    seasons.sort(key=_season_order)

    return {
        "ok": True,
        "series": series_token,
        "series_title": series_visible_title,
        "count": len(seasons),
        "seasons": seasons,
    }


def list_episodes(series_item_id, season_item_id):
    series_token = str(series_item_id or "").strip()
    season_token = str(season_item_id or "").strip()
    series_entry = get_cached_item(series_token)
    season_entry = get_cached_item(season_token)
    if series_entry.get("media_type") != "series":
        raise BrowseError("item is not a series")
    if season_entry.get("media_type") != "season":
        raise BrowseError("item is not a season")
    if season_entry.get("parent") != series_token:
        raise BrowseError("season does not belong to series")
    if season_entry.get("account") != series_entry.get("account"):
        raise BrowseError("series source mismatch")

    account = str(series_entry.get("account") or "")
    is_local = _is_local_account(account)
    profile = _local_profile() if is_local else _find_profile(account)
    series_row = dict(series_entry.get("item") or {})
    season_row = dict(season_entry.get("item") or {})
    season_no = _season_number(season_row, 1)
    client = None
    try:
        client = _local_web_context("series")[1] if is_local else _new_client(profile, timeout=15)
        rows = client.series_episodes(series_row, season_row) or []
    except BrowseError:
        raise
    except Exception:
        raise BrowseError("provider episodes unavailable")
    finally:
        if client is not None:
            try:
                client.close()
            except Exception:
                pass

    clean_enabled = _clean_titles_enabled()
    series_visible_title = _item_title(series_row, "series", clean_enabled)
    episodes = []
    for pos, row in enumerate(rows if isinstance(rows, list) else [], 1):
        if not isinstance(row, dict) or not row:
            continue
        episode_no = _episode_number(row, pos)
        row_season = _simple_number(row.get("season") or row.get("season_number")) or season_no
        title = _episode_title(row, episode_no, clean_enabled)
        token = _store_item(
            account, "episode", series_entry.get("category") or "*",
            series_visible_title, row, parent_id=season_token,
        )
        item = {
            "id": token,
            "title": title,
            "season": row_season or season_no,
            "episode": episode_no,
            "local": bool(_is_local_account(account)),
        }
        year = _item_year(row)
        if year:
            item["year"] = year
        episodes.append(item)

    return {
        "ok": True,
        "series": series_token,
        "season": season_token,
        "series_title": series_visible_title,
        "season_title": _season_title(season_row, season_no),
        "season_number": season_no,
        "count": len(episodes),
        "episodes": episodes,
    }

# ---------------------------------------------------------------------------
# R163 shared Search + Favorites bridge
# ---------------------------------------------------------------------------

def _favorite_rows_for_profile(profile, media_type=""):
    """Return Favorites owned by this exact saved profile, matching receiver UI."""
    wanted = str(media_type or "").strip().lower()
    portal = str((profile or {}).get("portal") or "").rstrip("/").lower()
    mac = str((profile or {}).get("mac") or "").upper()
    try:
        from .storage import load_favorites
        saved = list(load_favorites() or [])
    except Exception:
        saved = []
    out = []
    for entry in saved:
        if not isinstance(entry, dict) or not isinstance(entry.get("item"), dict):
            continue
        if str(entry.get("portal") or "").rstrip("/").lower() != portal:
            continue
        if str(entry.get("mac") or "").upper() != mac:
            continue
        media = str(entry.get("media_type") or "vod").lower()
        if media not in _MEDIA_TYPES:
            continue
        if wanted and media != wanted:
            continue
        out.append((media, dict(entry.get("item") or {})))
    return out


def _public_cached_item(account, media, row, category="*", category_title="", favorite=False):
    token = _store_item(account, media, category, category_title, row)
    try:
        _profile_for_public = _find_profile(account)
    except Exception:
        _profile_for_public = None
    item = {
        "id": token,
        "media_type": media,
        "title": _item_title(row, media, _clean_titles_enabled()),
        "favorite": bool(favorite),
        "source_kind": _profile_kind(_profile_for_public) if isinstance(_profile_for_public, dict) else "",
    }
    _apply_public_card_metadata(item, _profile_for_public or {}, media, row, cache_probe=False)
    if media == "series":
        _profile_for_count = _profile_for_public
        season_count = _series_season_count(row, _profile_for_count)
        if season_count is not None:
            item["season_count"] = season_count
    if media == "itv":
        number = _item_number(row)
        if number:
            item["number"] = number
        try:
            profile = _find_profile(account)
            item["has_picon"] = bool(_has_provider_artwork(row, "itv") or _cached_live_picon_for_web(profile, row))
        except Exception:
            item["has_picon"] = bool(_has_provider_artwork(row, "itv"))
    return item


def _search_norm(value):
    return " ".join(us_casefold(str(value or "")).replace("_", " ").replace("-", " ").split())


def _search_canonical_title(value):
    """Match the receiver Search grouping identity: raw provider title only.

    Search intentionally ignores Clean Display Names. Quality/language/server
    decorations are part of the visible identity so different provider variants
    remain distinguishable exactly as they are on the receiver Search screen.
    """
    return " ".join(us_casefold(str(value or "").strip()).split())


def _search_raw_title(row):
    row = row if isinstance(row, dict) else {}
    for key in ("_raw_name", "name", "title", "series_name", "movie_name", "original_name", "display_name", "stream_display_name", "channel_name"):
        value = _clean_text(row.get(key), 220)
        if value:
            return value
    return "Result"


def _search_row_category_id(row):
    row = row if isinstance(row, dict) else {}
    return str(row.get("category_id") or row.get("genre_id") or row.get("category") or "").strip()


def _search_source_key(profile):
    p = profile if isinstance(profile, dict) else {}
    return (
        str(p.get("portal") or p.get("url") or p.get("host") or "").rstrip("/").lower(),
        str(p.get("mac") or "").upper(),
        str(p.get("username") or p.get("user") or ""),
        str(p.get("type") or p.get("kind") or p.get("source_type") or "").lower(),
        str(p.get("name") or p.get("title") or ""),
    )


def _search_profile_key(profile):
    p = profile if isinstance(profile, dict) else {}
    return (
        str(p.get("portal") or "").rstrip("/").lower(),
        str(p.get("mac") or "").upper(),
    )


def _search_identity(row):
    row = row if isinstance(row, dict) else {}
    return str(
        row.get("id") or row.get("movie_id") or row.get("series_id") or
        row.get("stream_id") or row.get("cmd") or row.get("url") or
        row.get("name") or row.get("title") or ""
    )


def _search_public_copy(profile, media, row, portal_name, favorite=False):
    account = _account_id(profile)
    token = _store_item(account, media, "search", "Search", row)
    item = {
        "id": token,
        "media_type": media,
        # Deliberately raw, even when Clean Display Names is enabled.
        "title": _search_raw_title(row),
        "raw_title": _search_raw_title(row),
        "source_name": _clean_text(portal_name, 100),
        "source_kind": _profile_kind(profile),
        "favorite": bool(favorite),
    }
    _apply_public_card_metadata(item, profile, media, row, cache_probe=False)
    if media == "series":
        season_count = _series_season_count(row, profile)
        if season_count is not None:
            item["season_count"] = season_count
    return item


def search_items(account_id, query, limit=80, mode="full"):
    """Movies/Series Search with a receiver-like fast first paint.

    ``quick`` searches only the currently selected source with a deliberately
    tiny provider budget, so the Web UI can paint useful results immediately.
    ``full`` deepens the search on that same selected source only. Completed
    payloads are kept briefly in RAM so repeating the same search is instant
    without waking any other saved source.
    """
    account = str(account_id or "").strip()
    if not account:
        raise BrowseError("missing account")
    text = _clean_text(query, 120)
    if not text:
        raise BrowseError("enter a search term")
    mode = "quick" if str(mode or "").strip().lower() == "quick" else "full"
    try:
        limit_key = max(20, min(100, int(limit or 80)))
    except Exception:
        limit_key = 80
    settings = _web_policy_settings()
    policy_key = json.dumps({k:settings.get(k) for k in ("parental_lock","parental_mode","protected_categories","adult_keywords","hide_adult","hidden_categories","hidden_categories_by_profile")},sort_keys=True,default=str)
    cache_key = (account, _search_norm(text), limit_key, mode, policy_key)
    now = time.time()
    with _SEARCH_RAM_LOCK:
        cached = _SEARCH_RAM.get(cache_key)
        if cached and (now - float(cached.get("stored_at") or 0)) < _SEARCH_RAM_TTL:
            payload = dict(cached.get("payload") or {})
            payload["cached"] = True
            return payload
        stale = list(k for k,v in _SEARCH_RAM.items() if (now - float((v or {}).get("stored_at") or 0)) >= _SEARCH_RAM_TTL)
        for k in stale:
            _SEARCH_RAM.pop(k, None)
    anchor = _find_profile(account)
    try:
        from .storage import load_settings
        settings = load_settings() or {}
    except Exception:
        settings = {}
    # R194: Web Browse is deliberately single-source. Search must never wake,
    # authenticate, scan, or cache any saved source except the one the user
    # explicitly selected in the Web UI. Receiver multi-portal search remains
    # unchanged on the receiver itself.
    multi = False
    profiles = [dict(anchor)]
    current_key = _search_profile_key(anchor)

    def source_priority(profile):
        if _search_profile_key(profile) == current_key:
            return (0, 0)
        if str(profile.get("source_type") or "stalker").lower() == "m3u":
            return (1, 0)
        return (2, 0)

    profiles = sorted(profiles, key=source_priority)
    try:
        per_source_limit = limit_key
    except Exception:
        per_source_limit = 80

    try:
        from .category_visibility import hidden_ids as _hidden_category_ids
    except Exception:
        _hidden_category_ids = None

    jobs = queue.Queue()
    for pos, profile in enumerate(profiles):
        jobs.put((pos, profile))
    gathered = []
    errors = []
    result_lock = threading.RLock()
    search_cancel = threading.Event()
    partial_clock = {"first": 0.0, "last": 0.0}
    if mode == "quick":
        # The receiver Search paints progressive native/cache hits immediately.
        # The Web endpoint mirrors that behaviour: return shortly after the first
        # useful batch instead of waiting for an Xtream/M3U catalogue walk.
        deadline = time.monotonic() + 2.75
    else:
        deadline = time.monotonic() + (42.0 if any(str(p.get("source_type") or "").lower() == "m3u" for p in profiles) else 18.0)

    def search_profile(pos, profile):
        source_type = str(profile.get("source_type") or "stalker").lower()
        is_current = _search_profile_key(profile) == current_key
        portal_name = _safe_default_name(profile, pos)
        hidden_vod = set(_hidden_category_ids(settings, profile, "vod") or []) if callable(_hidden_category_ids) else set()
        hidden_series = set(_hidden_category_ids(settings, profile, "series") or []) if callable(_hidden_category_ids) else set()
        if mode == "quick":
            budget = 2.0
            pages = 6
        else:
            budget = 36.0 if source_type == "m3u" else (10.0 if is_current else 6.0)
            pages = 80 if source_type == "m3u" else (24 if is_current else 16)
        client = None
        def tag_rows(rows):
            # Provider-native Search already applied the query. Do not reject a
            # valid hit just because an Xtream/M3U adapter exposes its visible
            # name through a different field than Stalker. The receiver Search
            # trusts this native result set too.
            out = []
            aliases = {
                "movie": "vod", "movies": "vod", "vods": "vod",
                "tv": "series", "show": "series", "shows": "series",
                "serie": "series", "serial": "series",
            }
            for raw in rows if isinstance(rows, list) else []:
                if not isinstance(raw, dict):
                    continue
                media = str(raw.get("_search_media_type") or raw.get("media_type") or raw.get("type") or "vod").lower()
                media = aliases.get(media, media)
                if media not in ("vod", "series"):
                    continue
                cid = _search_row_category_id(raw)
                hidden = hidden_series if media == "series" else hidden_vod
                if cid and cid in hidden:
                    continue
                out.append((dict(profile), portal_name, media, dict(raw)))
            return out

        def publish_partial(rows):
            # M3U/Xtream can spend several seconds enriching uncached folders,
            # but its cache/native matches arrive through on_partial first. Keep
            # those immediately, exactly like the receiver UI does.
            if mode != "quick" or search_cancel.is_set():
                return
            tagged = tag_rows(rows)
            if not tagged:
                return
            now_partial = time.monotonic()
            with result_lock:
                gathered.extend(tagged)
                if not partial_clock["first"]:
                    partial_clock["first"] = now_partial
                partial_clock["last"] = now_partial

        try:
            client = _new_client(profile, timeout=4)
            fn = getattr(client, "search_content_fast", None) or getattr(client, "search_content", None)
            if not callable(fn):
                return []
            try:
                kwargs = dict(media_types=("vod", "series"), limit=per_source_limit,
                              max_pages=pages, time_budget=budget)
                if mode == "quick":
                    kwargs.update(cancel_event=search_cancel, on_partial=publish_partial)
                rows = fn(text, **kwargs) or []
            except TypeError:
                rows = fn(text, media_types=("vod", "series"), limit=per_source_limit) or []
            tagged = tag_rows(rows)
            if tagged or not is_current or search_cancel.is_set():
                return tagged

            # Some providers expose a broken/empty global Search endpoint while
            # browsing works perfectly. Mirror the receiver's detached fallback:
            # scan a small number of ordered catalogue pages on the selected
            # source only. This restores useful Search without making every
            # saved portal pay the fallback cost.
            needle = _search_norm(text)
            fallback = []
            local_deadline = time.monotonic() + (2.0 if mode == "quick" else 5.0)
            max_local_pages = 5 if mode == "quick" else 12
            for fallback_media in ("vod", "series"):
                if len(fallback) >= per_source_limit:
                    break
                for page_no in range(1, max_local_pages + 1):
                    if time.monotonic() >= local_deadline or search_cancel.is_set():
                        break
                    try:
                        payload = client.ordered_page(fallback_media, "*", page_no, cancel_event=search_cancel) or {}
                    except TypeError:
                        try:
                            payload = client.ordered_page(fallback_media, "*", page_no) or {}
                        except Exception:
                            break
                    except Exception:
                        break
                    page_rows = payload.get("items", []) if isinstance(payload, dict) else []
                    if not isinstance(page_rows, list) or not page_rows:
                        break
                    matched = []
                    for raw in page_rows:
                        if not isinstance(raw, dict):
                            continue
                        hay = _search_norm(
                            str(raw.get("name") or raw.get("title") or raw.get("display_name") or "") + " " +
                            str(raw.get("description") or raw.get("descr") or "")
                        )
                        if needle and needle in hay:
                            item = dict(raw)
                            item["_search_media_type"] = fallback_media
                            matched.append(item)
                            if len(fallback) + len(matched) >= per_source_limit:
                                break
                    if matched:
                        fallback.extend(tag_rows(matched))
                        if mode == "quick":
                            publish_partial(matched)
                    if len(fallback) >= per_source_limit:
                        break
            return fallback
        except Exception as exc:
            errors.append(_clean_text("%s: %s" % (portal_name, exc), 180))
            return []
        finally:
            if client is not None:
                try:
                    client.close()
                except Exception:
                    pass

    def worker():
        while time.monotonic() < deadline and not search_cancel.is_set():
            try:
                pos, profile = jobs.get_nowait()
            except queue.Empty:
                return
            rows = search_profile(pos, profile)
            if rows and not search_cancel.is_set():
                with result_lock:
                    gathered.extend(rows)

    threads = []
    for idx in range(min(6, max(1, jobs.qsize()))):
        t = threading.Thread(target=worker, name="ultrastalker-web-search-%d" % idx, daemon=True)
        t.start()
        threads.append(t)

    if mode == "quick":
        # Do not make the browser wait for the provider's enrichment phase once
        # useful rows have arrived. Give Movies + Series a brief chance to both
        # contribute, then cancel this quick pass; the browser may issue a deeper
        # pass against the same selected source only.
        while time.monotonic() < deadline:
            if not any(t.is_alive() for t in threads):
                break
            now_wait = time.monotonic()
            with result_lock:
                count_now = len(gathered)
                media_now = set(str(row[2]) for row in gathered if isinstance(row, tuple) and len(row) > 2)
                first_at = float(partial_clock.get("first") or 0.0)
                last_at = float(partial_clock.get("last") or 0.0)
            if count_now and first_at:
                quiet = now_wait - last_at
                age = now_wait - first_at
                if (len(media_now) >= 2 and quiet >= 0.12) or (age >= 0.85 and quiet >= 0.16):
                    break
            time.sleep(0.035)
        search_cancel.set()
        for t in threads:
            t.join(0.18)
    else:
        for t in threads:
            remain = deadline - time.monotonic()
            if remain <= 0:
                break
            t.join(remain)

    # Stop any straggler worker (a deep pass can outlive its deadline) and work
    # on a snapshot, so late rows can never mutate the list while it is read.
    search_cancel.set()
    with result_lock:
        final_rows = list(gathered)

    # Favorite state is source-owned. Batch repository lookups per profile/media.
    favorite_flags = {}
    by_source_media = {}
    for profile, portal_name, media, row in final_rows:
        key = (_search_source_key(profile), media)
        by_source_media.setdefault(key, {"profile": profile, "rows": []})["rows"].append(row)
    for key, bundle in by_source_media.items():
        profile = bundle["profile"]
        rows = bundle["rows"]
        try:
            from .storage import load_content_states
            states = list(load_content_states(profile, key[1], rows) or [])
        except Exception:
            states = []
        for idx, row in enumerate(rows):
            state = states[idx] if idx < len(states) and isinstance(states[idx], dict) else {}
            favorite_flags[(key[0], key[1], _search_identity(row))] = bool(state.get("favorite"))

    # Receiver parity: dedupe per source-copy, then group by raw title + media.
    seen = set()
    groups = {}
    order = []
    for profile, portal_name, media, row in final_rows:
        skey = _search_source_key(profile)
        identity = _search_identity(row)
        copy_key = (skey, media, identity)
        if copy_key in seen:
            continue
        seen.add(copy_key)
        raw_title = _search_raw_title(row)
        gkey = (media, _search_canonical_title(raw_title) or _search_norm(raw_title))
        if gkey not in groups:
            groups[gkey] = {
                "media_type": media,
                "title": raw_title,
                "raw_title": raw_title,
                "copies": [],
                "_source_keys": set(),
            }
            order.append(gkey)
        favorite = favorite_flags.get((skey, media, identity), False)
        try:public_copy = _search_public_copy(profile, media, row, portal_name, favorite=favorite)
        except BrowseError:continue
        groups[gkey]["copies"].append(public_copy)
        has_art = _has_provider_artwork(row, media)
        if not groups[gkey].get("poster_item") or (has_art and not groups[gkey].get("_poster_has_hint")):
            groups[gkey]["poster_item"] = public_copy.get("id") or ""
            groups[gkey]["_poster_has_hint"] = bool(has_art)
        groups[gkey]["_source_keys"].add(skey)

    public_groups = []
    movie_count = 0
    series_count = 0
    portal_keys = set()
    for gkey in order:
        group = groups[gkey]
        if not group.get("copies"):continue
        source_keys = group.pop("_source_keys", set())
        group.pop("_poster_has_hint", None)
        group["copy_count"] = len(group.get("copies") or [])
        group["portal_count"] = len(source_keys)
        group["id"] = "sg_" + hashlib.sha1((gkey[0] + "\x1f" + gkey[1]).encode("utf-8", "ignore")).hexdigest()[:18]
        public_groups.append(group)
        portal_keys.update(source_keys)
        if group["media_type"] == "series":
            series_count += 1
        else:
            movie_count += 1

    result = {
        "ok": True,
        "account": account,
        "query": text,
        "mode": mode,
        "multi_portal": multi,
        "source_count": len(profiles),
        "matched_portals": len(portal_keys),
        "count": len(public_groups),
        "copy_count": sum(int(g.get("copy_count") or 0) for g in public_groups),
        "buckets": {"vod": movie_count, "series": series_count},
        "groups": public_groups,
        # Keep a generic alias for compatibility with older Web clients.
        "items": public_groups,
        "partial": bool(errors),
        "cached": False,
    }
    # Cache useful hits, not temporary empty/provider-failure states. An empty
    # global result can be caused by a provider timing out or warming its cache;
    # remembering that for 90 seconds makes the Web Search look permanently
    # broken even though the next attempt could succeed.
    if int(result.get("count") or 0) > 0:
        with _SEARCH_RAM_LOCK:
            if len(_SEARCH_RAM) >= _SEARCH_RAM_MAX:
                oldest = sorted(_SEARCH_RAM.items(), key=lambda kv: float((kv[1] or {}).get("stored_at") or 0))[:max(1, len(_SEARCH_RAM)-_SEARCH_RAM_MAX+1)]
                for key, _value in oldest:
                    _SEARCH_RAM.pop(key, None)
            _SEARCH_RAM[cache_key] = {"stored_at": time.time(), "payload": dict(result)}
    return result


def list_favorites(account_id, media_type=""):
    account = str(account_id or "").strip()
    if not account:
        raise BrowseError("missing account")
    wanted = str(media_type or "").strip().lower()
    if wanted and wanted not in _MEDIA_TYPES:
        raise BrowseError("invalid media type")
    profile = _find_profile(account)
    rows = _favorite_rows_for_profile(profile, wanted)
    items = []
    for media,row in rows:
        try:items.append(_public_cached_item(account, media, row, "favorites", "Favorites", favorite=True))
        except BrowseError:continue
    return {
        "ok": True,
        "account": account,
        "media_type": wanted,
        "count": len(items),
        "items": items,
    }


def toggle_web_favorite(item_id):
    entry = get_cached_item(item_id)
    media = str(entry.get("media_type") or "").lower()
    if media not in _MEDIA_TYPES:
        raise BrowseError("this item cannot be saved to Favorites")
    profile = _find_profile(entry.get("account") or "")
    row = dict(entry.get("item") or {})
    try:
        from .storage import toggle_favorite
        favorite = bool(toggle_favorite(profile, media, row))
    except Exception:
        raise BrowseError("Favorites could not be updated")
    return {"ok": True, "item": str(item_id or ""), "favorite": favorite}


# ---------------------------------------------------------------------------
# R162 mobile-only playback bridge
# ---------------------------------------------------------------------------
_PLAYABLE_SCHEMES = frozenset(("http", "https", "rtmp", "rtsp", "udp", "rtp"))


def _provider_series_id(row):
    row = row if isinstance(row, dict) else {}
    for key in ("id", "series_id", "movie_id", "stream_id"):
        value = row.get(key)
        if value not in (None, ""):
            return value
    return None


def _provider_episode_id(row):
    """Match the receiver episode handoff: id -> episode_id -> series -> number."""
    row = row if isinstance(row, dict) else {}
    for key in ("id", "episode_id", "series", "number", "episode", "stream_id"):
        value = row.get(key)
        if value not in (None, ""):
            return value
    return None


def _safe_play_url(value):
    """Return one header/playlist-safe provider URL or reject it.

    create_link() already performs provider-specific validation.  This final web
    boundary only rejects control characters and non-media schemes so a provider
    response can never become a local file/javascript redirect.
    """
    text = str(value or "").strip().strip('"').strip("'")
    if not text or "\r" in text or "\n" in text or "\x00" in text:
        raise BrowseError("provider returned an invalid stream link")
    try:
        parsed = urllib.parse.urlsplit(text)
    except Exception:
        raise BrowseError("provider returned an invalid stream link")
    if str(parsed.scheme or "").lower() not in _PLAYABLE_SCHEMES:
        raise BrowseError("provider returned an unsupported stream link")
    return text


def _resolve_call(client, row, media_type, series_id=None):
    """Compatibility-call the existing resolver without inventing provider logic."""
    return call_compatible(client.create_link,[
        ((row,media_type,series_id),{}),((row,media_type),{}),((row,),{})])


def resolve_playable(item_id):
    """Resolve one cached Web item for playback on the *phone*, never Enigma2.

    Episode resolution mirrors the receiver Series screen exactly: the episode
    row is resolved as ``series`` and the create_link ``series`` argument is the
    episode id (id/episode_id/series/number).  A parent-series id is retained only
    as a compatibility fallback for unusual middleware.
    """
    token = str(item_id or "").strip()
    entry = get_cached_item(token)
    media = str(entry.get("media_type") or "").lower()
    if media not in ("itv", "vod", "episode"):
        raise BrowseError("this item is not directly playable")

    account = str(entry.get("account") or "")
    row = dict(entry.get("item") or {})
    if _is_local_account(account):
        raise BrowseError("local media is served through the LAN playback ticket")
    resolve_media = media
    series_id = None
    episode_fallback_series_id = None

    if media == "episode":
        season_token = str(entry.get("parent") or "")
        series_entry = None
        if season_token:
            season_entry = get_cached_item(season_token)
            if season_entry.get("media_type") != "season" or season_entry.get("account") != account:
                raise BrowseError("episode context expired; reopen the season")
            series_token = str(season_entry.get("parent") or "")
            if not series_token:
                raise BrowseError("episode context expired; reopen the series")
            series_entry = get_cached_item(series_token)
            if series_entry.get("media_type") != "series" or series_entry.get("account") != account:
                raise BrowseError("episode context expired; reopen the series")
        # Normal hierarchy playback and History/Recent playback both use the
        # receiver-proven episode id first.  History already persists the whole
        # episode row, so it does not need to rebuild seasons merely to play it.
        series_id = _provider_episode_id(row)
        if isinstance(series_entry, dict):
            episode_fallback_series_id = _provider_series_id(series_entry.get("item") or {})
        else:
            for key in ("_series_id", "series_id", "parent_id", "series_uid"):
                value = row.get(key)
                if value not in (None, ""):
                    episode_fallback_series_id = value
                    break
        if series_id in (None, ""):
            series_id = episode_fallback_series_id
        resolve_media = "series"

    profile = _find_profile(account)
    client = None
    try:
        client = _new_client(profile, timeout=15)
        try:
            resolved = _resolve_call(client, row, resolve_media, series_id)
            url = _safe_play_url(resolved)
        except Exception:
            # Some middleware expects the older parent-series parameter.  Keep it
            # only as a second attempt; the episode id remains the receiver-proven
            # first choice.
            if media != "episode" or episode_fallback_series_id in (None, "") or str(episode_fallback_series_id) == str(series_id):
                raise
            resolved = _resolve_call(client, row, resolve_media, episode_fallback_series_id)
            url = _safe_play_url(resolved)
    except Exception:
        # Some M3U/Xtream rows already carry the final URL.  Receiver playback
        # accepts that path too, so preserve it as a safe fallback instead of
        # failing the whole player chooser when provider link refresh is optional.
        raw = str(row.get("url") or row.get("cmd") or row.get("command") or "").strip()
        match = re.search(r"(?i)(https?|rtmp|rtsp|udp|rtp)://\S+", raw)
        direct = match.group(0) if match else raw
        try:
            url = _safe_play_url(direct)
        except Exception:
            # Never echo provider exceptions: Xtream URLs can contain credentials.
            raise BrowseError("stream link could not be resolved")
    finally:
        if client is not None:
            try:
                client.close()
            except Exception:
                pass

    clean_enabled = _clean_titles_enabled()
    title_media = "episode" if media == "episode" else media
    title = _item_title(row, title_media, clean_enabled)
    group = _clean_text(entry.get("category_title") or "Ultra Stalker", 160) or "Ultra Stalker"
    return {
        "title": _clean_text(title, 180) or "Ultra Stalker stream",
        "group": group,
        "media_type": media,
        "url": url,
    }


def _prune_play_tickets(now=None):
    now = float(now if now is not None else time.time())
    with _PLAY_TICKET_LOCK:
        expired = list(token for token, entry in _PLAY_TICKETS.items()
                   if now - float(entry.get("stored_at") or 0) > (_LOCAL_PLAY_TICKET_TTL if entry.get("local") else _PLAY_TICKET_TTL))
        for token in expired:
            _PLAY_TICKETS.pop(token, None)
        excess = len(_PLAY_TICKETS) - _PLAY_TICKET_MAX
        if excess > 0:
            oldest = sorted(_PLAY_TICKETS.items(), key=lambda pair: float(pair[1].get("stored_at") or 0))[:excess]
            for token, _entry in oldest:
                _PLAY_TICKETS.pop(token, None)


def prepare_play_ticket(item_id):
    """Mint a cookie-free ticket immediately; resolve only when a player opens it.

    R192 deliberately removes provider latency from the button tap.  Safari gets
    a local LAN ticket in milliseconds, then VLC/Outplayer/MX/native trigger the
    actual create_link through that ticket.  A per-ticket lock guarantees HEAD
    + GET probes cannot resolve the same stream twice.
    """
    token_id = str(item_id or "").strip()
    cached = get_cached_item(token_id)
    media = str(cached.get("media_type") or "").lower()
    if media not in ("itv", "vod", "episode"):
        raise BrowseError("this item is not directly playable")
    row = dict(cached.get("item") or {})
    title_media = "episode" if media == "episode" else media
    title = _item_title(row, title_media, _clean_titles_enabled())
    group = _clean_text(cached.get("category_title") or "Ultra Stalker", 160) or "Ultra Stalker"

    token = "ply_" + secrets.token_urlsafe(24).rstrip("=")
    local_path = _local_media_path(row) if _is_local_account(cached.get("account") or "") else ""
    entry = {
        "stored_at": time.time(),
        "item_id": token_id,
        "url": "",
        "title": _clean_text(title or "Ultra Stalker stream", 180),
        "group": group,
        "media_type": media,
        "local_path": local_path,
        "local": bool(local_path),
        "_resolve_lock": threading.RLock(),
        "policy": dict(cached.get("policy") or {}),
        "account": str(cached.get("account") or ""),
    }
    _prune_play_tickets()
    with _PLAY_TICKET_LOCK:
        _PLAY_TICKETS[token] = entry
    return {
        "ok": True,
        "ticket": token,
        "stream": "/api/browse/ticket?token=" + urllib.parse.quote(token, safe=""),
        "title": entry["title"],
        "media_type": entry["media_type"],
        "local": bool(entry.get("local")),
        "expires_in": (_LOCAL_PLAY_TICKET_TTL if entry.get("local") else _PLAY_TICKET_TTL),
    }


def get_play_ticket(token):
    key = str(token or "").strip()
    if not key:
        raise BrowseError("missing playback ticket")
    _prune_play_tickets()
    with _PLAY_TICKET_LOCK:
        live = _PLAY_TICKETS.get(key)
        if not live:
            raise BrowseError("playback ticket expired; choose Play again")
        live["stored_at"] = time.time()
        resolve_lock = live.get("_resolve_lock")
        if resolve_lock is None:
            resolve_lock = threading.RLock()
            live["_resolve_lock"] = resolve_lock

    with resolve_lock:
        with _PLAY_TICKET_LOCK:
            live = _PLAY_TICKETS.get(key)
            if not live:
                raise BrowseError("playback ticket expired; choose Play again")
            local_path = str(live.get("local_path") or "").strip()
            url = str(live.get("url") or "").strip()
            item_id = str(live.get("item_id") or "").strip()
            policy = dict(live.get("policy") or {})
            account = str(live.get("account") or "")
            media = str(live.get("media_type") or "")
        _web_authorize_snapshot(account, media, policy)
        if local_path:
            with _PLAY_TICKET_LOCK:
                live = _PLAY_TICKETS.get(key)
                if not live:raise BrowseError("playback ticket expired; choose Play again")
                live["stored_at"] = time.time()
                return {k:v for k,v in live.items() if not str(k).startswith("_") and k not in ("item_id","policy","account")}
        if not url:
            resolved = resolve_playable(item_id)
            url = str(resolved.get("url") or "").strip()
            with _PLAY_TICKET_LOCK:
                live = _PLAY_TICKETS.get(key)
                if not live:
                    raise BrowseError("playback ticket expired; choose Play again")
                live["url"] = url
                live["title"] = _clean_text(resolved.get("title") or live.get("title") or "Ultra Stalker stream", 180)
                live["group"] = _clean_text(resolved.get("group") or live.get("group") or "Ultra Stalker", 160)
                live["media_type"] = str(resolved.get("media_type") or live.get("media_type") or "")
                live["stored_at"] = time.time()
        with _PLAY_TICKET_LOCK:
            live = _PLAY_TICKETS.get(key)
            if not live:
                raise BrowseError("playback ticket expired; choose Play again")
            return {k: v for k, v in live.items() if not str(k).startswith("_") and k not in ("item_id","policy","account")}


def single_item_m3u(item_id=None, resolved=None):
    """Build an in-memory one-item M3U using the existing export formatter."""
    if not isinstance(resolved, dict):
        resolved = resolve_playable(item_id)
    from .m3u_export import build_extinf, safe_m3u_filename
    entry = {
        "name": resolved.get("title") or "Ultra Stalker stream",
        "tvg_name": resolved.get("title") or "Ultra Stalker stream",
        "group": resolved.get("group") or "Ultra Stalker",
        "url": resolved.get("url") or "",
    }
    text = "#EXTM3U\n%s\n%s\n" % (
        build_extinf(entry, resolved.get("group") or "Ultra Stalker"),
        resolved.get("url") or "",
    )
    filename = safe_m3u_filename(resolved.get("title") or "Ultra Stalker", fallback="UltraStalker") + ".m3u"
    return filename, text.encode("utf-8")

