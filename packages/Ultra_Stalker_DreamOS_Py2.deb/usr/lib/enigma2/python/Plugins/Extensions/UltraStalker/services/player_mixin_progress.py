# -*- coding: utf-8 -*-
"""Resume, progress bar, numeric seek keys and aspect chooser.

Methods moved verbatim out of ``UltraStalkerPlayer`` (player_native.py); behaviour is unchanged.
This module is imported by player_native.py once its module-level helpers exist, so the
names below are taken from that module (partially initialised at this point) on purpose.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from ..us_env import str, int, round, max, min, us_func
from .player_native import sane_play_pts, InfoBarSeek, LASER_H, LASER_W, MessageBox, Screen, UltraInfobarVisibility, _, _asset, apply_aspect_mode, aspect_mode_label, capture_aspect_mode, eAVSwitch, eSize, optional_failure, time

class PlayerProgressSeekMixin(object):
    """Resume, progress bar, numeric seek keys and aspect chooser."""

    def _transport_is_playing(self):
        try:
            state = getattr(self, 'seekstate', None)
            play_state = getattr(InfoBarSeek, 'SEEK_STATE_PLAY', None)
            if play_state is not None and state == play_state:
                return True
            if isinstance(state, (tuple, list)) and len(state) > 3:
                value = str(state[3] or '')
                return value == '>' or value.startswith('>>') or value.startswith('<<') or value.startswith('/')
        except Exception:
            pass
        value = str(getattr(self, '_last_play_state_value', '') or '')
        return value == '>' or value.startswith('>>') or value.startswith('<<') or value.startswith('/')

    def _set_transport_paused(self, paused):
        try:
            eof_state = getattr(InfoBarSeek, 'SEEK_STATE_EOF', None)
            cur_state = getattr(self, 'seekstate', None)
            setter = getattr(self, 'setSeekState', None)
            target = getattr(InfoBarSeek, 'SEEK_STATE_PAUSE' if paused else 'SEEK_STATE_PLAY', None)
            if callable(setter) and target is not None and (eof_state is None or cur_state != eof_state):
                setter(target)
                return True
        except Exception as exc:
            optional_failure('player.external_subtitle_seekstate', exc)
        try:
            service = self.session.nav.getCurrentService()
            pauseable = service.pause() if service else None
            if pauseable is None:
                return False
            if paused:
                pauseable.pause()
            else:
                pauseable.unpause()
            return True
        except Exception as exc:
            optional_failure('player.external_subtitle_pause', exc)
            return False

    def _cancel_pending_resume_for_manual_seek(self):
        """A viewer seek permanently cancels any pending automatic Resume seek."""
        self._resume_failed_bookmark = 0
        self._native_resume_started = True
        self._resume_target = 0
        self._resume_grace_until = 0.0
        self.resume_prompted = True
        try:
            self.resume_timer.stop()
        except Exception as exc:
            optional_failure('player.optional_guard', exc)
        try:
            self.resume_verify_timer.stop()
        except Exception as exc:
            optional_failure('player.optional_guard', exc)
        try:
            self._release_resume_shield()
        except Exception as exc:
            optional_failure('player.optional_guard', exc)

    def _play_state_changed(self, state):
        try:
            value = state[3] or ''
        except Exception:
            value = ''
        self._last_play_state_value = str(value or '')
        try:
            self._external_subtitle_play_state(value)
        except Exception as exc:
            optional_failure('player.external_subtitle_playstate_hook', exc)
        if self.media_type in ('vod', 'series', 'episode', 'catchup'):
            if value.startswith('>>') or value.startswith('<<') or value.startswith('/'):
                self._cancel_pending_resume_for_manual_seek()
            elif value in ('||', '>'):
                self._save_history_progress(force=True)

    def _schedule_resume_probe(self):
        attempt = max(0, int(self._resume_verify_attempts or 0))
        delay = min(250, 50 * (attempt + 1))
        self.resume_verify_timer.stop()
        self.resume_verify_timer.start(delay, True)

    def _perform_resume_seek(self):
        if not self._resume_target or self.restored or self._closing_playback:
            return None
        if self._resume_seek_count > 0:
            return None
        if time.monotonic() >= self._resume_grace_until:
            self._resume_unavailable()
            return None
        try:
            if not self.started or not self._event_matches_current_reference():
                self._resume_verify_attempts += 1
                self._schedule_resume_probe()
                return None
            service = self.session.nav.getCurrentService()
            seekable = service.seek() if service else None
            if seekable is None:
                self._resume_verify_attempts += 1
                self._schedule_resume_probe()
                return None
            length = seekable.getLength()
            target = int(self._resume_target)
            _sane_len = sane_play_pts(length[1]) if length and (not length[0]) else 0
            if _sane_len > 0:
                target = min(target, max(0, _sane_len - 10 * 90000))
            if target <= 0:
                self._resume_verify_attempts += 1
                self._schedule_resume_probe()
                return None
            result = seekable.seekTo(target)
            if result not in (None, 0):
                self._resume_verify_attempts += 1
                self._schedule_resume_probe()
                return None
            self._resume_target = target
            self._resume_seek_count = 1
            self._resume_seek_total = int(getattr(self, '_resume_seek_total', 0) or 0) + 1
            self._resume_probe_last = -1
            self._resume_probe_advances = 0
            self._resume_started_at = time.monotonic()
            self._resume_verify_cycles = 0
            self['connection'].setText(_('RESUMING • %d:%02d') % (target // 90000 // 60, target // 90000 % 60))
            self.resume_verify_timer.stop()
            self.resume_verify_timer.start(100, True)
        except Exception as exc:
            optional_failure('player.resume_seek', exc)
            self._resume_verify_attempts += 1
            self._schedule_resume_probe()

    def _verify_resume_position(self):
        if not self._resume_target or self.restored or self._closing_playback:
            return None
        if time.monotonic() >= self._resume_grace_until:
            self._resume_unavailable()
            return None
        if self._resume_seek_count == 0:
            self._perform_resume_seek()
            return None
        try:
            service = self.session.nav.getCurrentService()
            seekable = service.seek() if service else None
            result = seekable.getPlayPosition() if seekable else None
            current = sane_play_pts(result[1]) if result and (not result[0]) else -1
        except Exception as exc:
            optional_failure('player.resume_verify', exc)
            current = -1
        seek_elapsed = max(0.0, time.monotonic() - float(self._resume_started_at or time.monotonic()))
        if current >= 0 and self._resume_target - 3 * 90000 <= current <= self._resume_target + int((seek_elapsed + 3.0) * 90000):
            self._last_progress_position = current
            self._resume_target = 0
            self._resume_failed_bookmark = 0
            self._native_resume_started = True
            self.resume_prompted = True
            self._recovery_resume_pending = False
            self._recovery_resume_snapshot = None
            self._release_resume_shield()
            self['connection'].setText('')
            try:
                self._external_subtitle_after_seek()
                self._schedule_subtitle_session_restore(240)
            except Exception as exc:
                optional_failure('player.resume_subtitles', exc)
            return None
        previous = int(getattr(self, '_resume_probe_last', -1))
        advances = int(getattr(self, '_resume_probe_advances', 0) or 0)
        advances = advances + 1 if previous >= 0 and current > previous + 9000 else 0
        self._resume_probe_last = current
        self._resume_probe_advances = advances
        if seek_elapsed >= 3.0 and advances >= 2 and (int(getattr(self, '_resume_seek_total', 1)) < 2):
            try:
                ready = getattr(seekable, 'isCurrentlySeekable', None)
                ready = bool(ready()) if callable(ready) else True
            except Exception:
                ready = False
            if ready:
                self._resume_seek_count = 0
                self._perform_resume_seek()
                return None
        self._resume_verify_cycles += 1
        self.resume_verify_timer.stop()
        self.resume_verify_timer.start(200, True)

    def _native_resume_updated(self):
        if not bool(getattr(self, '_subtitle_user_override', False)):
            try:
                self._enforce_default_subtitles_off()
            except Exception as exc:
                optional_failure('player.subtitle_default_event_fence', exc)
        self._vod_quality_updated_info_event()
        self._vod_audio_updated_info_event()
        if self.restored or self._closing_playback or self.media_type not in ('vod', 'series', 'episode', 'catchup'):
            return
        if self._resume_target:
            if self._resume_seek_count == 0:
                self._perform_resume_seek()
            return
        if not self._native_resume_started and (not self._resume_prompt_open):
            from .. import us_env as _us_env
            if _us_env.IS_DREAMOS and self.start_attempt and (time.monotonic() - float(self.start_attempt) < 1.2):
                try:
                    self.resume_timer.stop()
                    self.resume_timer.start(1200, True)
                except Exception:
                    self._reference_resume()
                return
            self._reference_resume()

    def _reference_resume(self):
        if self.restored or self._closing_playback or self.media_type not in ('vod', 'series', 'episode', 'catchup'):
            return
        if self._resume_target:
            if self._resume_seek_count == 0:
                self._perform_resume_seek()
            return
        if self._native_resume_started or self._resume_prompt_open:
            return
        behavior = self._cfg_resume_behavior
        bookmark = self._resume_bookmark()
        handoff = bool(getattr(self, '_recovery_resume_pending', False))
        if not bookmark or (behavior == 'start' and (not handoff)):
            self._native_resume_started = True
            self.resume_prompted = True
            return
        if behavior == 'ask' and (not handoff):
            self._resume_prompt_open = True
            seconds = bookmark // 90000
            message = _('Resume playback from %d:%02d:%02d?') % (seconds // 3600, seconds % 3600 // 60, seconds % 60)
            try:
                self.session.openWithCallback(lambda answer: self._reference_resume_answer(answer, bookmark), MessageBox, message, MessageBox.TYPE_YESNO, timeout=10)
                return
            except Exception as exc:
                optional_failure('player.resume_prompt', exc)
        self._reference_resume_answer(True, bookmark)

    def _reference_resume_answer(self, answer, position):
        self._resume_prompt_open = False
        if not answer or self.restored or self._closing_playback:
            self._native_resume_started = True
            self.resume_prompted = True
            return
        self._resume_retries = 0
        self._queue_verified_resume(position)
        self._perform_resume_seek()

    def _periodic_progress_save(self):
        if self.restored or self.media_type not in ('vod', 'series', 'episode', 'catchup'):
            return
        self._save_history_progress()

    @staticmethod
    def _format_player_pts(value):
        try:
            seconds = max(0, int(value or 0) // 90000)
        except Exception:
            seconds = 0
        hours = seconds // 3600
        minutes = seconds % 3600 // 60
        secs = seconds % 60
        return '%d:%02d:%02d' % (hours, minutes, secs)

    def _update_player_time_labels(self, position, duration):
        try:
            position = max(0, int(position or 0))
            duration = max(0, int(duration or 0))
            if duration > 0:
                position = min(position, duration)
                remaining = max(0, duration - position)
                self['elapsed_time'].setText(self._format_player_pts(position))
                self['total_time'].setText(self._format_player_pts(duration))
                self['remaining_time'].setText(self._format_player_pts(remaining))
            else:
                self['elapsed_time'].setText(self._format_player_pts(position) if position > 0 else '')
                self['total_time'].setText('')
                self['remaining_time'].setText('')
        except Exception as exc:
            optional_failure('player.time_labels', exc)
        if self._lb_mode() == 'vod':
            self._lb_vod_tick(position, duration)

    def _update_progress_visual(self):
        if not getattr(self, '_player_infobar_visible', True):
            try:
                self.progress_visual_timer.stop()
            except Exception as exc:
                optional_failure('player.hidden_progress_visual_guard', exc)
            return
        if self.restored or self.media_type not in ('vod', 'series', 'episode', 'catchup', 'trailer'):
            try:
                self['progress_neon'].hide()
                self['progress_head'].hide()
                self._buffer_status_clear()
                self['buffer_glass'].hide()
                self['skip_hint'].setText('')
                self['elapsed_time'].setText('')
                self['total_time'].setText('')
                self['remaining_time'].setText('')
            except Exception as exc:
                optional_failure('player.progress_visual_hide', exc)
            return
        position, duration = self._service_progress_snapshot()
        self._update_buffer_status(duration)
        if getattr(self, '_buffer_job', None) is not None and position > 0 and (duration > 0):
            self._buffer_watch_position = int(position)
            self._buffer_note_position(position, duration)
        self._retry_visual_note_vod_progress(position)
        position, duration = self._progress_visual_snapshot(position, duration)
        position = self._seek_display_position(position, duration)
        self._update_player_time_labels(position, duration)
        if self._lb_mode() == 'vod':
            self._update_skip_hint(position, duration)
            return
        if duration <= 0:
            try:
                self['vod_progress'].setValue(0)
                self['vod_progress'].show()
                self['buffer_glass'].hide()
                self['progress_neon'].hide()
            except Exception:
                pass
            self._update_skip_hint(position, duration)
            return
        ratio = max(0.0, min(1.0, float(position) / float(duration)))
        try:
            value = max(0, min(100, int(round(ratio * 100.0))))
            self['vod_progress'].setValue(value)
            self['vod_progress'].show()
            self._apply_laser_progress(ratio)
        except Exception as exc:
            optional_failure('player.progress_visual', exc)
        self._update_skip_hint(position, duration)

    def _apply_laser_progress(self, ratio):
        """Frosted bar is the download. Solid white on top is the movie."""
        try:
            play = max(0.0, min(1.0, float(ratio or 0.0)))
            glass = _asset(("player_progress_glass_1800x11.png" if _wqhd_wh(LASER_W,LASER_H)[0]==1800 else "player_progress_glass_1350x8.png"))
            self._apply_buffer_glass(play)
            binst = self['progress_neon'].instance
            hinst = self['progress_head'].instance
            if binst is None:
                return
            if glass != self._laser_beam_path:
                binst.setPixmapFromFile(glass)
                self._laser_beam_path = glass
                self._laser_end = -1
            fill = self._buffer_fill_ratio(play)
            draw = int(round(_wqhd_wh(LASER_W, LASER_H)[0] * fill)) if fill is not None else 0
            if draw != self._laser_end:
                self._laser_end = draw
                if draw > 3:
                    binst.resize(eSize(max(1, draw), _wqhd_wh(LASER_W, LASER_H)[1]))
            if draw > 3:
                self['progress_neon'].show()
            else:
                self['progress_neon'].hide()
            if hinst is not None and self._laser_head_path != 'hide':
                try:
                    hinst.hide()
                except Exception:
                    pass
                self._laser_head_path = 'hide'
            try:
                self['progress_head'].hide()
            except Exception:
                pass
        except Exception as exc:
            optional_failure('player.laser_progress', exc)

    def _seek_unavailable_notice(self):
        """Tell the viewer a 1/3/4/6/7/9 press was ignored because the stream cannot seek
        yet. Movies/series only (the number keys mean nothing for Live), once per second."""
        try:
            if self.media_type not in ('vod', 'series', 'episode', 'catchup'):
                return
            now = time.monotonic()
            if now - float(getattr(self, '_seek_notice_at', 0.0) or 0.0) < 1.0:
                return
            self._seek_notice_at = now
            self['connection'].setText(_(self._SEEK_UNAVAILABLE_TEXT))
            us_func(UltraInfobarVisibility.doShow)(self)
        except Exception as exc:
            optional_failure('player.seek_unavailable_notice', exc)

    def _seek_unavailable_clear(self):
        try:
            if str(self['connection'].getText() or '') == _(self._SEEK_UNAVAILABLE_TEXT):
                self['connection'].setText('')
        except Exception as exc:
            optional_failure('player.seek_unavailable_clear', exc)

    def _seek_engine_arrived(self, position):
        """True once the engine position shows the last numeric seek really landed.

        A fixed 20 s tolerance was wrong for the 10 s step: the stale position from
        BEFORE the seek is already within 20 s of the target, so the bar jumped back
        and the next press was computed from the old place. The tolerance now scales
        with the seek distance, and moving most of the way also counts as arrived
        (the engine may land on a keyframe away from the exact target)."""
        target = getattr(self, '_seek_display_target', None)
        try:
            position = int(position or 0)
            if target is None or position <= 0:
                return False
            target = int(target)
            origin = getattr(self, '_seek_display_origin', None)
            err = abs(position - target)
            if origin is None:
                return err <= 20 * 90000
            origin = int(origin)
            dist = abs(target - origin)
            if err <= min(20 * 90000, max(3 * 90000, dist // 3)):
                return True
            moved = position - origin if target >= origin else origin - position
            return moved >= int(dist * 0.6)
        except Exception:
            return False

    def _seek_display_position(self, position, duration):
        """Presentation only: after a numeric seek keep showing the target until the engine
        reports arrival using the current step's tolerance (or 12 s pass). Raw PTS is untouched."""
        target = getattr(self, '_seek_display_target', None)
        if target is None:
            return position
        try:
            if time.monotonic() > float(getattr(self, '_seek_display_until', 0.0) or 0.0):
                self._seek_display_target = None
                return position
            if getattr(self, '_seek_pending_target', None) is not None:
                return target
            if self._seek_engine_arrived(position):
                self._seek_display_target = None
                return position
            return target
        except Exception:
            self._seek_display_target = None
            return position

    def _progress_visual_snapshot(self, position, duration):
        job = getattr(self, '_buffer_job', None)
        enabled = job is not None and (not getattr(self, '_closing_playback', False)) and getattr(job, 'prefetch_enabled', True) and (not getattr(job, 'direct_only', False)) and (not getattr(job, 'failed', ''))
        if not enabled:
            self._progress_visual_last = None
            return (position, duration)
        now = time.monotonic()
        marker = (job, str(getattr(self, 'streamurl', '') or ''))
        previous = getattr(self, '_progress_visual_last', None)
        if duration > 0:
            self._progress_visual_last = (marker, position, duration, now)
            return (position, duration)
        if previous and previous[0] == marker and (now - previous[3] <= 3.0):
            return (previous[1], previous[2])
        return (position, duration)

    def _update_skip_hint(self, position, duration):
        try:
            self['skip_hint'].setText('')
        except Exception as exc:
            optional_failure('player.optional_guard', exc)

    def _seek_relative_seconds(self, seconds):
        """Reliable repeated numeric seek: 1=-10s, 3=+10s.

        ServiceApp/exteplayer3 can report the PREVIOUS play position for a short
        window after a seek.  A second relative seek then starts from stale PTS
        and appears to jump forward/back to the same place.  Keep a short-lived
        absolute target and accumulate each key press on that target instead.
        """
        seconds = int(seconds or 0)
        if not seconds:
            return False
        now = time.monotonic()
        if now - float(getattr(self, '_last_manual_seek_at', 0.0) or 0.0) < 0.055:
            return False
        self._last_manual_seek_at = now
        delta = int(seconds * 90000)
        try:
            service = self.session.nav.getCurrentService()
            seekable = service.seek() if service else None
            if seekable is None:
                self._seek_unavailable_notice()
                return False
            check = getattr(seekable, 'isCurrentlySeekable', None)
            if callable(check):
                try:
                    if not check():
                        self._seek_unavailable_notice()
                        return False
                except Exception as exc:
                    optional_failure('player.optional_guard', exc)
            self._cancel_pending_resume_for_manual_seek()
            self._seek_unavailable_clear()
            pos = seekable.getPlayPosition()
            current = int(pos[1]) if pos and (not pos[0]) else int(getattr(self, '_last_progress_position', 0) or 0)
            length = seekable.getLength()
            total = int(length[1]) if length and (not length[0]) else 0
            known = int(getattr(self, '_last_progress_duration', 0) or 0)
            if known > 5 * 60 * 90000 and (total <= 0 or known > total * 2):
                total = known
            cached = getattr(self, '_manual_seek_target_pts', None)
            cached_at = float(getattr(self, '_manual_seek_target_at', 0.0) or 0.0)
            display_target = getattr(self, '_seek_display_target', None)
            display_live = display_target is not None and now < float(getattr(self, '_seek_display_until', 0.0) or 0.0)
            if display_live and (not self._seek_engine_arrived(current)):
                base = int(display_target)
            elif cached is not None and now - cached_at < 2.5:
                base = int(cached)
            else:
                base = max(0, current)
            target = max(0, base + delta)
            if total > 0:
                if delta > 0 and total > 120 * 90000:
                    limit = max(0, total - 15 * 90000)
                    if base >= limit:
                        return False
                    target = min(target, limit)
                else:
                    target = min(target, max(0, total - 90000))
            self._seek_display_origin = int(base)
            self._manual_seek_target_pts = int(target)
            self._manual_seek_target_at = now
            self._last_progress_position = int(target)
            self._seek_display_target = int(target)
            self._seek_display_until = now + 12.0
            self._seek_pending_target = int(target)
            self._update_player_time_labels(target, total)
            try:
                self._update_progress_visual()
            except Exception as exc:
                optional_failure('player.seek_visual_refresh', exc)
            if now - float(getattr(self, '_seek_applied_at', 0.0) or 0.0) >= 0.8 and (not getattr(self, '_seek_timer_armed', False)):
                self._apply_pending_seek()
            else:
                try:
                    self.seek_apply_timer.stop()
                except Exception as exc:
                    optional_failure('player.seek.timer_stop', exc)
                self._seek_timer_armed = True
                self.seek_apply_timer.start(350, True)
            return True
        except Exception as exc:
            try:
                service = self.session.nav.getCurrentService()
                seekable = service.seek() if service else None
                if seekable is not None:
                    self._cancel_pending_resume_for_manual_seek()
                    seekable.seekRelative(1 if seconds > 0 else -1, abs(delta))
                    self._external_subtitle_after_seek()
                    return True
            except Exception as fallback_exc:
                optional_failure('player.seek.relative_fallback', fallback_exc)
            optional_failure('player.numeric_seek_10', exc)
            return False

    def _apply_pending_seek(self):
        target = getattr(self, '_seek_pending_target', None)
        self._seek_pending_target = None
        self._seek_timer_armed = False
        if target is None or self._closing_playback:
            return None
        try:
            self.seek_apply_timer.stop()
        except Exception as exc:
            optional_failure('player.seek.apply_timer_stop', exc)
        try:
            service = self.session.nav.getCurrentService()
            seekable = service.seek() if service else None
            if seekable is None:
                return None
            seekable.seekTo(int(target))
            self._seek_applied_at = time.monotonic()
            self._external_subtitle_after_seek()
            timer = getattr(self, '_next_episode_timer', None)
            if timer is not None and (not getattr(self, '_next_episode_cancelled', False)):
                timer.start(250, True)
        except Exception as exc:
            optional_failure('player.numeric_seek_apply', exc)

    def seekBack10(self):
        return self._seek_relative_seconds(-10)

    def seekForward10(self):
        return self._seek_relative_seconds(10)

    def seekBack60(self):
        return self._seek_relative_seconds(-60)

    def seekForward60(self):
        return self._seek_relative_seconds(60)

    def seekBack300(self):
        return self._seek_relative_seconds(-300)

    def seekForward300(self):
        return self._seek_relative_seconds(300)

    def doSeekRelative(self, pts):
        try:
            seconds = int(round(float(pts) / 90000.0))
        except Exception:
            return
        if seconds:
            self._seek_relative_seconds(seconds)

    def seekBack(self):
        return self.seekBack10()

    def seekFwd(self):
        return self.seekForward10()

    def seekBackManual(self):
        return self.seekBack60()

    def seekFwdManual(self):
        return self.seekForward60()

    def seekBackDef(self):
        return self.seekBack300()

    def seekFwdDef(self):
        return self.seekForward300()

    def _seek_bridge_allowed(self):
        return self.media_type in ('vod', 'series', 'episode', 'catchup')

    def seekBridgeBack10(self):
        if not self._seek_bridge_allowed():
            return False
        return self.seekBack10()

    def seekBridgeForward10(self):
        if not self._seek_bridge_allowed():
            return False
        return self.seekForward10()

    def cycleDisplayAspect(self):
        """Open an inline Aspect Ratio chooser instead of cycling with delays."""
        choices = [(_(aspect_mode_label(0)), 0), (_(aspect_mode_label(1)), 1), (_(aspect_mode_label(2)), 2), (_(aspect_mode_label(3)), 3), (_(aspect_mode_label(4)), 4), (_(aspect_mode_label(5)), 5), (_(aspect_mode_label(6)), 6)]
        current = capture_aspect_mode(switch_cls=eAVSwitch)
        selected = 0
        for idx, row in enumerate(choices):
            if len(row) > 1 and row[1] == current:
                selected = idx
                break
        try:
            return self._subtitle_inline_show(choices, selected, self._aspect_ratio_selected, self._subtitle_inline_finish, 'aspect_ratio')
        except Exception as exc:
            optional_failure('player.aspect_menu', exc)
            self._subtitle_inline_finish()
            return False

    def _aspect_ratio_selected(self, choice=None):
        if not choice:
            return self._subtitle_inline_finish()
        value = choice[1] if isinstance(choice, (tuple, list)) and len(choice) > 1 else choice
        if apply_aspect_mode(value, switch_cls=eAVSwitch):
            self._aspect_cycle_cursor = value
        else:
            try:
                self['connection'].setText(_('Aspect-ratio change failed'))
            except Exception:
                pass
        self._subtitle_inline_finish()
        return True

    def _set_infobar_visuals(self, visible):
        """Show/hide the Player chrome around the Media Info overlay (was a missing method)."""
        try:
            if visible:
                self.doShow()
            else:
                try:
                    self.doHide()
                except Exception:
                    us_func(Screen.hide)(self)
        except Exception as exc:
            optional_failure('player.infobar_visuals', exc)

    def _queue_verified_resume(self, position):
        if self.restored or self._closing_playback or int(position or 0) <= 0:
            return
        self._resume_target = int(position)
        self._resume_seek_count = 0
        self._resume_seek_total = 0
        self._resume_probe_last = -1
        self._resume_probe_advances = 0
        self._resume_verify_attempts = 0
        self._resume_verify_cycles = 0
        self._resume_grace_until = time.monotonic() + 20.0
        self._resume_prompt_open = False
        self.resume_prompted = True
        self._native_resume_started = False
        self._schedule_resume_probe()

    def _resume_unavailable(self):
        self._resume_failed_bookmark = int(self._resume_target or self._resume_bookmark() or 0)
        self._resume_target = 0
        self._native_resume_started = True
        self.resume_prompted = True
        self._release_resume_shield()
        self['connection'].setText(_('Resume unavailable • saved position kept'))
from ..wqhd_layout import wh as _wqhd_wh
