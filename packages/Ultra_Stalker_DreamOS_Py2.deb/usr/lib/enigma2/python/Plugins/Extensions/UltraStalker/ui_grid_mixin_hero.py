# -*- coding: utf-8 -*-
"""Pinning the selected item as the home hero.

Methods moved verbatim out of ``PremiumGridBase`` (ui_grid_base.py); behaviour is unchanged.
This module is imported by ui_grid_base.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, open, OSError
from .ui_grid_base import (
    _,
    cleanup_legacy_application_outputs,
    fixed_home_assets,
    json,
    os,
    reactor,
    tempfile,
    time,
)


class GridHeroMixin(object):
    """Pinning the selected item as the home hero."""

    @staticmethod
    def _home_hero_old_generated_paths(hero):
        paths=[]
        if not isinstance(hero,dict):return paths
        value=str(hero.get("prepared") or "")
        if value:paths.append(value)
        for key in ("home_mood","adaptive_focus"):
            block=hero.get(key) if isinstance(hero.get(key),dict) else {}
            for candidate in block.values():
                candidate=str(candidate or "")
                if candidate:paths.append(candidate)
        return paths

    def _selected_cached_backdrop_for_hero(self):
        """Return the current selected item's already-cached HDD backdrop only."""
        if not self.grid_items:return "",{}
        item=self.grid_items[self.index] if 0 <= int(self.index) < len(self.grid_items) else None
        if not isinstance(item,dict):return "",{}
        candidates=[]
        for key in ("_backdrop_source_local","_cin_provider_backdrop_local","backdrop_local","display_backdrop_local","source_backdrop_local"):
            candidates.append(item.get(key))
        # Cinematic keeps the canonical row/package for the focused item in RAM.
        try:
            row=(getattr(self,"_cin_page_records",{}) or {}).get(int(self.index)) or {}
            if isinstance(row,dict):
                candidates.extend([row.get("backdrop_local"),row.get("display_backdrop_local")])
        except Exception:pass
        # HDD manifest is read-only here; MENU must never trigger a network resolve.
        manifest={}
        try:manifest=load_artwork_v2_manifest(self.profile,self.media_type,item) or {}
        except Exception:manifest={}
        if isinstance(manifest,dict):
            candidates.extend([manifest.get("backdrop_local"),manifest.get("display_backdrop_local"),manifest.get("source_backdrop_local")])
        for candidate in candidates:
            try:
                candidate=str(candidate or "")
                if candidate and os.path.isfile(candidate) and os.path.getsize(candidate)>4096:
                    return os.path.realpath(candidate),manifest
            except Exception:pass
        return "",manifest

    def _pin_selected_as_home_hero(self):
        """Pin the focused Cinematic/Backdrop item as Home Hero from cached art only.

        This is the same manual-Hero contract used by Details: no TMDb/network work
        is started by MENU, and only the selected canonical HDD backdrop is used.
        """
        if self.media_type not in ("vod","series") or not self.grid_items:return
        item=self.grid_items[self.index]
        if not isinstance(item,dict):return
        source,manifest=self._selected_cached_backdrop_for_hero()
        if not source:
            try:self["status"].setText(_("Hero not set • selected backdrop is not cached on HDD"))
            except Exception:pass
            return
        item_snapshot=dict(item);media_type=str(self.media_type or "")
        raw_id=str(item_snapshot.get("tmdb_id") or item_snapshot.get("id") or item_snapshot.get("stream_id") or item_snapshot.get("series_id") or "")
        tmdb_id=item_snapshot.get("_locked_tmdb_id") or item_snapshot.get("_ultra_search_verified_tmdb_id")
        if not tmdb_id and isinstance(manifest,dict) and (manifest.get("identity_verified") or manifest.get("identity_pointer_verified")):
            tmdb_id=manifest.get("tmdb_id")
        title=str(item_snapshot.get("name") or item_snapshot.get("title") or item_snapshot.get("series_name") or "")
        overview=str(item_snapshot.get("plot") or item_snapshot.get("description") or item_snapshot.get("overview") or "")
        try:
            text=self["description"].getText() or ""
            if text:overview=text
        except Exception:pass
        try:
            text=self["bd_overview"].getText() or ""
            if text:overview=text
        except Exception:pass
        title_logo_local=""
        for candidate in (getattr(self,"_cin_logo_path",""),getattr(self,"_bd_logo_path",""),item_snapshot.get("title_logo_local")):
            try:
                candidate=str(candidate or "")
                if candidate and os.path.isfile(candidate) and os.path.getsize(candidate)>256:
                    title_logo_local=os.path.realpath(candidate);break
            except Exception:pass

        request_token=str(int(time.time()*1000000));hero_dir=os.path.dirname(str(HOME_HERO_FILE or ""))
        marker=os.path.join("/tmp","ultrastalker_home_hero_pending")
        try:
            with open(marker,"w",encoding="ascii") as fh:fh.write(request_token)
        except Exception:pass
        try:self["status"].setText(_("Hero selected • preparing adaptive materials…"))
        except Exception:pass

        def token_current():
            try:
                with open(marker,"r",encoding="ascii") as fh:return fh.read().strip()==request_token
            except Exception:return False

        def safe_unlink_generated(path,keep=()):
            try:
                path=str(path or "");base=os.path.basename(path)
                if not path or path in keep or not os.path.isfile(path):return
                if (os.path.realpath(path).startswith(os.path.realpath(hero_dir)+os.sep) or
                    base.startswith("dyn228home_") or base.startswith("dyn280home_")):
                    os.unlink(path)
            except OSError:pass
            except Exception:pass

        def worker():
            temp_home="";created=[]
            try:
                os.makedirs(hero_dir,mode=0o700,exist_ok=True)
                stamp=os.stat(source)
                digest=hashlib.sha1((source+"|%s|%s|manual-hero-v78-contract"%(int(stamp.st_mtime),int(stamp.st_size))).encode("utf-8","ignore")).hexdigest()[:20]
                temp_home=os.path.join(hero_dir,".hero.%s.%s.png"%(os.getpid(),request_token))
                prepared=_prepare_single_home_hero(source,temp_home,(1920,1080))
                if not prepared or not os.path.isfile(prepared) or os.path.getsize(prepared)<=1024:return False
                if not token_current():return False
                # R64: Set Hero changes artwork only.  Application chrome is
                # frozen and no legacy Home adaptive writer may run here.
                try:cleanup_legacy_application_outputs()
                except Exception:pass
                fixed=fixed_home_assets() or {}
                if not fixed:
                    return False
                adaptive_focus=dict(fixed.get("focus") or {})
                home_mood=dict(fixed.get("mood") or {})

                required=[adaptive_focus.get("menu"),adaptive_focus.get("recent"),home_mood.get("ambient"),home_mood.get("menu"),home_mood.get("recent")]
                if not all(x and os.path.isfile(str(x)) and os.path.getsize(str(x))>100 for x in required):return False
                old_hero={}
                try:
                    with open(HOME_HERO_FILE,"r",encoding="utf-8") as fh:
                        old=json.load(fh);old_hero=old.get("hero") if isinstance(old,dict) and isinstance(old.get("hero"),dict) else {}
                except Exception:old_hero={}
                with _HOME_HERO_LOCK:
                    if not token_current():return False
                    final_home=os.path.join(hero_dir,"hero.png")
                    os.replace(temp_home,final_home);temp_home=""
                    hero={
                        "id":"manual-"+(raw_id or digest),"media_type":media_type,"tmdb_id":tmdb_id,
                        "title":title,"overview":overview,"rating":0,"language":"","collection":"ULTRA STALKER",
                        "prepared":final_home,"backdrop_local":source,"display_backdrop_local":source,
                        "source_backdrop_local":source,"adaptive_focus":adaptive_focus,"home_mood":home_mood,
                        "title_logo_local":title_logo_local,"title_logo_lang":"en" if title_logo_local else "",
                        "manual_pin":True,"manual_pin_token":int(request_token),
                    }
                    payload={"schema":HOME_HERO_SCHEMA,"expires":0,"persistent":True,"manual_pin":True,
                             "manual_pin_token":int(request_token),"hero":hero}
                    fd,tmp=tempfile.mkstemp(prefix=".hero-state.",suffix=".tmp",dir=hero_dir)
                    try:
                        with os.fdopen(fd,"w",encoding="utf-8") as fh:
                            json.dump(payload,fh,ensure_ascii=False,separators=(",",":"));fh.flush();os.fsync(fh.fileno())
                        os.chmod(tmp,0o600);os.replace(tmp,HOME_HERO_FILE)
                    finally:
                        if os.path.exists(tmp):
                            try:os.unlink(tmp)
                            except OSError:pass
                keep=set([final_home]+list(str(x or "") for x in required))
                for old_path in self._home_hero_old_generated_paths(old_hero):safe_unlink_generated(old_path,keep)
                try:
                    if token_current():os.unlink(marker)
                except OSError:pass
                return True
            except Exception as exc:
                optional_failure("ui.grid_set_home_hero",exc);return False
            finally:
                if temp_home and os.path.exists(temp_home):
                    try:os.unlink(temp_home)
                    except OSError:pass
                if not token_current():
                    for path in created:safe_unlink_generated(path)

        try:
            future=_IMAGE_EXECUTOR.submit(worker)
            def done(_f):
                try:ok=bool(_f.result())
                except Exception:ok=False
                def paint():
                    if getattr(self,"_screen_closed",False):return
                    try:self["status"].setText(_("Hero pinned • active across Ultra Stalker") if ok else _("Hero failed"))
                    except Exception:pass
                try:reactor.callFromThread(paint)
                except Exception:pass
            future.add_done_callback(done)
        except Exception as exc:
            optional_failure("ui.grid_set_home_hero_submit",exc)
            try:self["status"].setText(_("Hero failed: %s")%str(exc)[:90])
            except Exception:pass
