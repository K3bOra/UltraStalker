# -*- coding: utf-8 -*-
"""Origin clues kept separately from display/search title normalization."""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str
re = _us_env.re

_COUNTRIES = {
    "KR": ("KOR", "KOREA", "SOUTH KOREA", "KOREAN", "كوريا", "كوري", "كورية"),
    "VN": ("VNM", "VIETNAM", "VIET NAM", "VIETNAMESE", "فيتنام", "فيتنامي", "فيتنامية"),
    "TH": ("THA", "THAILAND", "THAI", "تايلاند", "تايلندي"),
    "TR": ("TUR", "TURKEY", "TURKIYE", "TURKISH", "تركيا", "تركي"),
    "JP": ("JPN", "JAPAN", "JAPANESE", "اليابان", "ياباني"),
    "CN": ("CHN", "CHINA", "CHINESE", "الصين", "صيني"),
    "IN": ("IND", "INDIA", "INDIAN", "الهند", "هندي"),
    "ID": ("IDN", "INDONESIA", "INDONESIAN"), "MY": ("MYS", "MALAYSIA", "MALAYSIAN"),
    "SG": ("SGP", "SINGAPORE"), "PH": ("PHL", "PHILIPPINES", "FILIPINO"),
    "US": ("USA", "UNITED STATES", "UNITED STATES OF AMERICA", "AMERICAN"),
    "GB": ("UK", "GBR", "UNITED KINGDOM", "BRITISH"),
    "EG": ("EGY", "EGYPT", "EGYPTIAN", "مصر", "مصري"),
    "SA": ("KSA", "SAUDI ARABIA", "السعودية"), "AE": ("UAE", "UNITED ARAB EMIRATES"),
    "FR": ("FRA", "FRANCE", "FRENCH"), "DE": ("DEU", "GERMANY", "GERMAN"),
    "ES": ("ESP", "SPAIN", "SPANISH"), "IT": ("ITA", "ITALY", "ITALIAN"),
    "RU": ("RUS", "RUSSIA", "RUSSIAN"), "BR": ("BRA", "BRAZIL", "BRAZILIAN"),
}
_ALIASES = {value.upper():code for code, values in _COUNTRIES.items() for value in (code,) + values}
_LANGUAGES = {"KR":"ko", "VN":"vi", "TH":"th", "TR":"tr", "JP":"ja", "CN":"zh", "IN":"hi", "ID":"id", "MY":"ms", "SG":"en", "PH":"tl", "US":"en", "GB":"en", "EG":"ar", "SA":"ar", "AE":"ar", "FR":"fr", "DE":"de", "ES":"es", "IT":"it", "RU":"ru", "BR":"pt"}
_COUNTRY_LANGUAGES = {
    "KR": ("ko",), "VN": ("vi",), "TH": ("th",), "TR": ("tr",), "JP": ("ja",),
    "CN": ("zh", "cn", "yue", "bo"),
    "IN": ("hi", "ta", "te", "ml", "kn", "bn", "mr", "pa", "gu", "ur", "en"),
    "ID": ("id", "ms"), "MY": ("ms", "zh", "ta", "en"), "SG": ("en", "zh", "ms", "ta"),
    "PH": ("tl", "en"), "US": ("en",), "GB": ("en",),
    "EG": ("ar",), "SA": ("ar",), "AE": ("ar",),
    "FR": ("fr",), "DE": ("de",), "ES": ("es", "ca", "eu", "gl"), "IT": ("it",),
    "RU": ("ru",), "BR": ("pt",),
}
# Short 2-3 letter prefixes like "FR - Invictus (2009)" or "DE - ..." on IPTV VOD
# rows denote the audio/subtitle bouquet, not the film's country of production.
# Only Asian/Middle-Eastern drama catalogue tags are treated as origin clues when
# written as short 2-3 letter prefixes/brackets in stream names.
_TITLE_ORIGIN_CODES = frozenset(("KR", "VN", "TH", "TR", "JP", "CN", "IN", "ID", "MY", "SG", "PH", "EG", "SA", "AE"))


def _codes(value):
    if isinstance(value, dict):
        return _codes(value.get("iso_3166_1") or value.get("country_code") or value.get("name"))
    if isinstance(value, (tuple,list)):
        return list(code for part in value for code in _codes(part))
    text = str(value or "").strip().upper()
    if text in _ALIASES:
        return [_ALIASES[text]]
    if len(text)==2 and all(ord(ch) < 128 for ch in text) and text.isalpha():
        return [text]
    return [_ALIASES[part.strip()] for part in re.split(r"[,/;|]", text) if _ALIASES.get(part.strip())]


def origin_codes(item):
    item = item if isinstance(item, dict) else {}
    values = []
    for key in ("country_code", "origin_country", "production_countries", "production_country", "country", "countries", "region"):
        values.extend(_codes(item.get(key)))
    return list(dict.fromkeys(values))


def _title_token_country(token):
    tok = str(token or "").strip().upper()
    code = _ALIASES.get(tok, "")
    if not code:
        return ""
    if code in _TITLE_ORIGIN_CODES or len(tok) >= 4:
        return code
    return ""


def country_hint(item, raw=""):
    item = item if isinstance(item, dict) else {}
    known = origin_codes(item)
    if known:
        return known[0]
    sources = [item.get("_raw_name"), item.get("_provider_name"), raw, item.get("name"), item.get("title")]
    for source in sources:
        text = str(source or "").strip()
        groups = re.findall(r"[([{]([^)\]}]+)[)\]}]", text)
        for token in reversed(groups):
            found = _title_token_country(token)
            if found:
                return found
        head = re.split(r"\s+[-|:┃]\s+", text, maxsplit=1)
        if len(head)>1:
            found = _title_token_country(head[0])
            if found:
                return found
        tail = re.split(r"\s+[-|:┃]\s+", text)
        if len(tail)>1:
            found = _title_token_country(tail[-1])
            if found:
                return found
    return ""


def original_language(item):
    item = item if isinstance(item, dict) else {}
    value = str(item.get("original_language") or item.get("_origin_language") or "").lower().strip()
    return value.split("-")[0] if value else ""


def language_for_country(code):
    return _LANGUAGES.get(str(code or "").upper(), "")


def hint_scope(item):
    return country_hint(item), original_language(item)


def hint_fields(item):
    country, language = hint_scope(item)
    return {key:value for key,value in (("country_code",country),("original_language",language)) if value}


def hints_compatible(item, record, require_known=False):
    explicit_origins = origin_codes(item)
    country, language = hint_scope(item)
    origins = origin_codes(record)
    actual_language = original_language(record)
    expected = language_for_country(country)
    allowed_langs = _COUNTRY_LANGUAGES.get(str(country or "").upper(), (expected,) if expected else ())
    if country and origins and country not in origins:
        if explicit_origins or country in _TITLE_ORIGIN_CODES or not (allowed_langs and actual_language in allowed_langs):
            return False
    if country and not origins and allowed_langs and actual_language and actual_language not in allowed_langs:
        if explicit_origins or country in _TITLE_ORIGIN_CODES:
            return False
    if language and actual_language and language != actual_language:
        return False
    if require_known and explicit_origins and country and not origins and not (allowed_langs and actual_language in allowed_langs):
        return False
    if require_known and language and not actual_language:
        return False
    return True
