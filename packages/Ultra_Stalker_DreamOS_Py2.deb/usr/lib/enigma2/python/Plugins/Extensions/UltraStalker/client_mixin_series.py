# -*- coding: utf-8 -*-
"""Series seasons and episodes.

Methods moved verbatim out of ``StalkerClient`` (client.py); behaviour is unchanged.
This module is imported by client.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int
from .client import (
    CACHE,
    LOG,
    OrderedDict,
    time,
)


class ClientSeriesMixin(object):
    """Series seasons and episodes."""

    # ------------------------------------------------------------------
    # Series hierarchy (same API shape used by working MAG clients)
    # ------------------------------------------------------------------
    @staticmethod
    def _series_id(item):
        if not isinstance(item, dict):
            return None
        # PERFLAB9: provider series_id is the authoritative portal hierarchy
        # key.  Artwork/metadata enrichment can coexist with a generic ``id``;
        # never let that shadow the provider series id when asking for seasons.
        return item.get("series_id") or item.get("id") or item.get("movie_id")

    @classmethod
    def _merge_series_rows(cls, *collections):
        """Merge portal responses without allowing a smaller retry to erase rows."""
        merged = OrderedDict()
        for rows in collections:
            for index, row in enumerate(rows or []):
                if not isinstance(row, dict) or not row:
                    continue
                key = cls._series_row_identity(row, index)
                previous = merged.get(key)
                if previous is None:
                    merged[key] = dict(row)
                else:
                    combined = dict(previous)
                    for field, value in row.items():
                        if value not in (None, "", [], {}):
                            combined[field] = value
                    merged[key] = combined
        return list(merged.values())

    @classmethod
    def _series_response_suspicious(cls, rows):
        """Detect the common partial-series response without rejecting valid S1-only shows."""
        if not rows:
            return True
        if any((r.get("episode_id") or r.get("episode")) for r in rows if isinstance(r, dict)):
            return False
        numbers = []
        for index, row in enumerate(rows, 1):
            try:
                raw = cls._season_number(row, index)
                text = str(raw).strip()
                if ":" in text:
                    text = text.rsplit(":", 1)[-1]
                numbers.append(int(text))
            except Exception:
                continue
        if not numbers:
            return False
        unique = sorted(set(numbers))
        if unique[0] > 1:
            return True
        return unique != list(range(unique[0], unique[-1] + 1))

    def _series_stable_cache_key(self, movie_id):
        return self._cache_key({
            "action": "stable_series_hierarchy",
            "movie_id": str(movie_id),
        })

    def _series_rows_once(self, movie_id, page=None, cancel_event=None):
        params = {
            "type": "series", "action": "get_ordered_list", "movie_id": movie_id,
            "season_id": "0", "episode_id": "0", "JsHttpRequest": "1-xml",
        }
        if page is not None:
            params["p"] = str(page)
            params["page"] = str(page)
        js = self._unwrap(self._get(params, use_cache=False, cancel_event=cancel_event))
        if cancel_event is not None and getattr(cancel_event, "is_set", lambda: False)():
            return []
        return [row for row in self._as_list(js) if isinstance(row, dict) and row]

    def _series_rows(self, movie_id, cancel_event=None):
        """Resolve the richest available hierarchy for a series."""
        cache_key = self._series_stable_cache_key(movie_id)
        with self._series_hierarchy_lock:
            remembered = list(self._series_hierarchy_memory.get(str(movie_id), []) or [])
            remembered_at=float(getattr(self,"_series_hierarchy_memory_at",{}).get(str(movie_id),0) or 0)
        if remembered and (time.monotonic()-remembered_at) < 120.0:
            return remembered
        persisted = CACHE.get(cache_key)
        if isinstance(persisted, list):
            remembered = self._merge_series_rows(remembered, persisted)

        if cancel_event is not None and getattr(cancel_event, "is_set", lambda: False)():
            return remembered
        fresh = self._series_rows_once(movie_id, cancel_event=cancel_event)
        if cancel_event is not None and getattr(cancel_event, "is_set", lambda: False)():
            return remembered
        combined = self._merge_series_rows(remembered, fresh)

        suspicious = self._series_response_suspicious(fresh)
        if remembered and len(fresh) < len(remembered):
            suspicious = True
        if suspicious:
            try:
                retry = self._series_rows_once(movie_id, cancel_event=cancel_event)
                combined = self._merge_series_rows(combined, retry)
            except Exception:
                LOG.exception("series hierarchy retry failed for movie_id=%s", movie_id)

            seen_count = len(combined)
            for page in range(1, 5):
                if cancel_event is not None and getattr(cancel_event, "is_set", lambda: False)():
                    break
                try:
                    page_rows = self._series_rows_once(movie_id, page=page, cancel_event=cancel_event)
                except Exception:
                    break
                if not page_rows:
                    break
                merged = self._merge_series_rows(combined, page_rows)
                if len(merged) <= seen_count:
                    break
                combined = merged
                seen_count = len(combined)
                if not self._series_response_suspicious(combined):
                    break

        richest = combined or fresh or remembered
        if richest:
            with self._series_hierarchy_lock:
                current = self._series_hierarchy_memory.get(str(movie_id), [])
                if len(richest) >= len(current or []):
                    self._series_hierarchy_memory[str(movie_id)] = list(richest)
                    self._series_hierarchy_memory_at[str(movie_id)] = time.monotonic()
                else:
                    richest = list(current)
                    self._series_hierarchy_memory_at[str(movie_id)] = time.monotonic()
                self._trim_series_hierarchy_memory()
            try:
                CACHE.put(cache_key, richest, 1800)
            except Exception:
                LOG.exception("unable to persist stable series hierarchy")
        return richest

    SERIES_MEMORY_LIMIT = 48

    def _trim_series_hierarchy_memory(self):
        """Keep the in-RAM series hierarchy bounded (caller holds the lock).

        Every opened series stored its full season/episode tree for the whole
        session; browsing many series grew without limit. The persistent cache
        still serves anything evicted here."""
        memory = self._series_hierarchy_memory
        stamps = self._series_hierarchy_memory_at
        extra = len(memory) - self.SERIES_MEMORY_LIMIT
        if extra <= 0:
            return
        for key in sorted(memory, key=lambda k: float(stamps.get(k, 0) or 0))[:extra]:
            memory.pop(key, None)
            stamps.pop(key, None)

    @staticmethod
    def _season_number(season, fallback=1):
        sid = str(season.get("id") or season.get("season_id") or "") if isinstance(season, dict) else ""
        if ":" in sid:
            tail = sid.rsplit(":", 1)[-1]
            if tail:
                return tail
        if isinstance(season, dict):
            return season.get("season") or season.get("season_number") or fallback
        return fallback

    def series_seasons(self, series_item, cancel_event=None):
        if not isinstance(series_item, dict):
            return []
        series_id = self._series_id(series_item)
        if series_id in (None, ""):
            return []
        rows = self._series_rows(series_id, cancel_event=cancel_event)
        result = []
        for index, row in enumerate(rows, 1):
            season = dict(row)
            sid = season.get("id") or season.get("season_id") or "%s:%s" % (series_id, index)
            number = self._season_number(season, index)
            season["id"] = sid
            season["season_id"] = sid
            season["season"] = number
            season["parent_series_id"] = series_id
            season.setdefault("name", "Season %s" % number)
            result.append(season)

        # A minority of portals return flat episode dictionaries. Group those
        # without inventing extra API actions that may repeat the series list.
        if result and not any(isinstance(x.get("series"), list) for x in result):
            if any(x.get("episode") or x.get("episode_id") for x in result):
                grouped = OrderedDict()
                for episode in result:
                    number = str(episode.get("season") or episode.get("season_id") or "1")
                    grouped.setdefault(number, []).append(episode)
                return list({
                    "id": "%s:%s" % (series_id, number),
                    "season_id": "%s:%s" % (series_id, number),
                    "season": number,
                    "name": "Season %s" % number,
                    "episodes": episodes,
                    "parent_series_id": series_id,
                } for number, episodes in grouped.items())
        return result

    def _build_episode_rows(self, series_item, season):
        series_id = self._series_id(series_item)
        season_id = season.get("id") or season.get("season_id") or "%s:1" % series_id
        season_number = self._season_number(season, 1)
        embedded = season.get("episodes")
        if isinstance(embedded, list) and embedded:
            episode_values = embedded
        else:
            episode_values = season.get("series")
        if not isinstance(episode_values, list):
            return []

        command = season.get("cmd") or season.get("command") or season.get("url") or ""
        result = []
        for index, value in enumerate(episode_values, 1):
            if isinstance(value, dict):
                episode = dict(value)
                episode_id = episode.get("episode_id") or episode.get("episode") or episode.get("number") or episode.get("episode_num") or episode.get("episode_number") or episode.get("id") or index
                episode.setdefault("cmd", command)
            else:
                episode_id = value
                episode = {"cmd": command}
            episode["id"] = episode_id
            episode["episode_id"] = episode_id
            episode["episode"] = episode_id
            episode["number"] = episode_id
            episode["season"] = season_number
            episode["season_id"] = season_id
            episode["stream_id"] = season_id
            episode["movie_id"] = series_id
            episode.setdefault("name", "Episode %s" % episode_id)
            for key in ("description", "actors", "director", "writer", "genres_str", "rating_imdb", "year", "country", "country_code", "original_name", "original_title", "imdb_id", "tmdb_id", "tmdbid", "tmdb_type", "screenshot_uri", "cover", "cover_url", "poster", "poster_url", "backdrop", "backdrop_url", "backdrop_path", "fanart"):
                if key not in episode and season.get(key) not in (None, ""):
                    episode[key] = season.get(key)
            result.append(episode)
        return result

    def series_episodes(self, series_item, season_item, cancel_event=None):
        if not isinstance(series_item, dict) or not isinstance(season_item, dict):
            return []
        rows = self._build_episode_rows(series_item, season_item)
        if rows:
            return rows

        series_id = self._series_id(series_item)
        if series_id in (None, ""):
            return []
        requested_id = str(season_item.get("id") or season_item.get("season_id") or "")
        fresh = self._series_rows(series_id, cancel_event=cancel_event)
        target = None
        for row in fresh:
            candidate_id = str(row.get("id") or row.get("season_id") or "")
            if candidate_id == requested_id:
                target = row
                break
        if target is None:
            requested_number = str(self._season_number(season_item, ""))
            for row in fresh:
                if str(self._season_number(row, "")) == requested_number:
                    target = row
                    break
        return self._build_episode_rows(series_item, target or season_item)
