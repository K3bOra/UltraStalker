# -*- coding: utf-8 -*-
"""Layout readiness, title and description font fitting, adaptive fonts.

Methods moved verbatim out of ``ContentDetailsScreen`` (ui_screens_details.py); behaviour is unchanged.
This module is imported by ui_screens_details.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, round, max, min
from .ui_screens_details import (
    _,
    _details_backdrop_truth,
    _lbl_h,
    _ui_diag,
    _visual_source_fingerprint,
    diagnostic_failure,
    os,
    time,
    ultra_title_logo_cached,
    valid_ultra_title_logo,
)


class DetailsLayoutMixin(object):
    """Layout readiness, title and description font fitting, adaptive fonts."""

    def _layout_ready(self):
        try:
            if self["title_logo"].instance:
                self._title_logo_target_size=(self["title_logo"].instance.size().width(),self["title_logo"].instance.size().height())
        except Exception:
            self._title_logo_target_size=None
        # HDD-only title-logo first paint. Search may already carry a verified
        # TMDb id from the result card; do not wait for the resolver callback to
        # rediscover a logo variant that is already cached on disk.
        try:
            _logo_cached=ultra_title_logo_cached(
                self.media_type,
                getattr(self,"_portal_item",self.item),
                getattr(self,"_local_detail_cache",{}) or {},
                self._title_logo_target_size or (432,210),
                str(getattr(self,"_server_display_name","") or ""),
            )
            if _logo_cached and valid_ultra_title_logo(_logo_cached) and self["title_logo"].instance is not None:
                self._title_logo_cache_target=_logo_cached
                self["title_logo"].instance.setPixmapFromFile(_logo_cached);self["title_logo"].show()
            else:
                _seed_row=getattr(self,"_local_detail_cache",None) or getattr(self,"_portal_item",self.item)
                if isinstance(_seed_row,dict) and (_seed_row.get("tmdb_id") or _seed_row.get("_locked_tmdb_id")):
                    self._schedule_details_title_logo(_seed_row,str(getattr(self,"_server_display_name","") or ""))
        except Exception as exc:optional_failure("ui.details_cached_logo_first_paint",exc)
        if self.media_type=="series" and not getattr(self,"_is_series_browser_child",False):
            try:self._series_count_timer.start(120,True)
            except Exception as exc:optional_failure("ui.series_count_timer_start",exc)
        try:_ui_diag("ui_ready",screen="details",media_type=self.media_type,elapsed_ms=int((time.monotonic()-self._ui_diag_open_mono)*1000.0))
        except Exception as exc:diagnostic_failure("ui.details.failsoft.606",exc)
        _runtime_endurance_log("details_layout",media_type=self.media_type,cache=bool(getattr(self,"_local_detail_cache",{})))
        self._image_layout_ready()
        self._transition_init(("title", "subtitle", "name", "description", "dynamic_bg", "cinematic_bg", "cinematic_edge", "poster", "title_logo", "poster_footer_bg", "panel_bg", "overview_bg", "quality_pill_bg", "year_pill_bg", "runtime_pill_bg", "country_pill_bg", "genre_pill_bg", "tmdb_pill_bg", "imdb_pill_bg", "rating_ring", "poster_imdb_logo", "poster_imdb_value", "poster_match_text", "quality_logo", "country_flag", "runtime_icon", "rating_score", "rating_source", "imdb_text", "quality_text", "year_text", "runtime_text", "country_text", "genre_text", "age_rating_text", "cast_text", "status", "red", "green", "yellow", "blue"))
        self._layout_detail_actions()
        ph="grid_placeholder_movie_921.png" if self.media_type=="vod" else "grid_placeholder_series_921.png"
        cached=getattr(self,"_local_detail_cache",{})
        bundle=getattr(self,"_persistent_visual_bundle",{}) or {}
        # Migrate an older HDD backdrop source to one final 1620x620 presentation
        # locally, before any provider/TMDB work.  This is a one-time local
        # conversion; subsequent opens use backdrop_present directly.
        if not str(bundle.get("backdrop_present") or ""):
            local_backdrop=str(bundle.get("backdrop") or "")
            if local_backdrop and _details_backdrop_truth(local_backdrop):
                try:
                    local_present=self._schedule_backdrop_presentation(local_backdrop,5)
                    if local_present and os.path.isfile(local_present):
                        bundle=dict(bundle);bundle["backdrop_present"]=local_present
                        self._persistent_visual_bundle=bundle;self._persistent_backdrop_locked=True
                except Exception as exc:optional_failure("ui.details_local_backdrop_migrate",exc)
        cfg_now=load_settings();external_ready=bool(cfg_now.get("tmdb_enabled",True) and str(cfg_now.get("tmdb_credential") or "").strip())
        cached_source=str((cached or {}).get("identity_source") or "") if isinstance(cached,dict) else ""
        cached_poster=_verified_external_art(cached,"poster")
        # Apply the grid's exact palette immediately on entry. The displayed
        # Details poster may be upgraded later, but it must never repaint the
        # screen with a different adaptive identity.
        authoritative=getattr(self,"_adaptive_authoritative_source","")
        poster_authority=getattr(self,"_poster_authoritative_source","")
        if authoritative and os.path.isfile(authoritative) and not getattr(self,"_persistent_visual_frozen",False):
            self._schedule_poster_visuals(authoritative)
        bundled_poster=str(bundle.get("poster") or "")
        bundled_detail_poster=str(bundle.get("detail_poster") or "")
        # The exact poster handed off by the currently selected Cinematic/Grid
        # item is authoritative for this Details open.  A historical Details
        # derivative from another similarly-named title must never win simply
        # because it exists on HDD.  Use the cached derivative only when it is
        # fingerprint-bound to the same source poster.  Otherwise show the
        # authoritative source directly; Details does NO poster/adaptive build.
        authority_fp=_visual_source_fingerprint(poster_authority) if poster_authority and os.path.isfile(poster_authority) else ""
        detail_fp=str(bundle.get("detail_poster_source_fp") or "")
        detail_matches_authority=bool(authority_fp and bundled_detail_poster and os.path.isfile(bundled_detail_poster) and detail_fp==authority_fp)
        if poster_authority and os.path.isfile(poster_authority):
            if detail_matches_authority:
                try:
                    if self["poster"].instance is not None:
                        self["poster"].instance.setPixmapFromFile(bundled_detail_poster);self["poster"].show()
                        self._image_displayed_path=bundled_detail_poster
                    self._details_visual_state["poster"]=poster_authority
                    self._details_visual_state["detail_poster"]=bundled_detail_poster
                    self._persistent_detail_poster_locked=True
                except Exception as exc:optional_failure("ui.details_final_poster_apply",exc)
            else:
                self._details_visual_state["poster"]=poster_authority
                self._details_visual_state.pop("detail_poster",None)
                self._persistent_detail_poster_locked=False
                self._decode_picture(poster_authority)
        elif bundled_detail_poster and os.path.isfile(bundled_detail_poster):
            try:
                if self["poster"].instance is not None:
                    self["poster"].instance.setPixmapFromFile(bundled_detail_poster);self["poster"].show()
                    self._image_displayed_path=bundled_detail_poster
                self._details_visual_state["poster"]=bundled_poster or bundled_detail_poster
                self._details_visual_state["detail_poster"]=bundled_detail_poster
                self._persistent_detail_poster_locked=True
            except Exception as exc:optional_failure("ui.details_final_poster_apply",exc)
        elif bundled_poster and os.path.isfile(bundled_poster):
            self._details_visual_state["poster"]=bundled_poster
            self._decode_picture(bundled_poster)
        elif cached_poster:
            self._details_visual_state["poster"]=cached_poster
            self._decode_picture(cached_poster)
        else:
            # Xtream provider art loads asynchronously immediately after layout.
            # Stalker retains the neutral placeholder/external-only policy.
            self._decode_picture(asset(ph))
        try:
            self["dynamic_bg"].hide();self["cinematic_bg"].hide();self["cinematic_edge"].hide()
        except Exception as exc:optional_failure("ui",exc)
        self._apply_detail_chrome(None)
        try:
            if bundle:
                active_poster=(poster_authority if poster_authority and os.path.isfile(poster_authority) else str(bundle.get("poster") or ""))
                active_detail=(str(bundle.get("detail_poster") or "") if (not poster_authority or detail_matches_authority) else "")
                self._details_visual_state.update({
                    "poster":active_poster,
                    "backdrop":str(bundle.get("backdrop") or ""),
                    "backdrop_present":str(bundle.get("backdrop_present") or ""),
                    "detail_poster":active_detail,
                    "theme":str(bundle.get("theme") or ""),
                    "accent":str(bundle.get("accent") or ""),
                    "edge":str(bundle.get("edge") or ""),
                    "chrome":dict(bundle.get("chrome") or {}),
                })
                self._restore_details_visual_state(reload_disk=False)
                if active_poster:self._adaptive_source_local=str(active_poster)
                if getattr(self,"_persistent_adaptive_locked",False):self._adaptive_palette_locked=True
                if getattr(self,"_persistent_poster_locked",False) and not (poster_authority and os.path.isfile(poster_authority)):
                    self._poster_authoritative_source=str(bundle.get("poster") or self._poster_authoritative_source or "")
                    self._adaptive_authoritative_source=str(bundle.get("poster") or self._adaptive_authoritative_source or "")
                if getattr(self,"_persistent_backdrop_locked",False):
                    self._backdrop_rank=max(5,int(getattr(self,"_backdrop_rank",0) or 0))
        except Exception as exc:optional_failure("ui.details_bundle_restore",exc)
        if isinstance(cached,dict) and cached.get("matched") and cached.get("identity_verified") and cached_source!="portal_payload":
            try:
                self._apply_tmdb_metadata(dict(cached));self["status"].setText(_("Cached • HDD"))
            except Exception as exc:optional_failure("ui.local_detail_cache_apply",exc)
        try:self._schedule_search_visual_peer_sync(cached if isinstance(cached,dict) else None)
        except Exception as exc:optional_failure("ui.search_peer_layout_sync",exc)
        self._load_cinematic_backdrop(False)
        # Dual-source details: server/provider first, TMDB enriches the merged row.
        self._load_provider_metadata()
        try:self._backdrop_watch_timer.start(1400,True)
        except Exception as exc:optional_failure("ui.silent_guard",exc)
        self._sync_detail_text_direction();self._refresh_detail_visuals();self._schedule_description_scroll();self._ensure_description_visible()
        try:self._desc_guard_timer.start(700,True)
        except Exception as exc:optional_failure("ui",exc)
        try:self["accent_frame"].hide()
        except Exception as exc:optional_failure("ui",exc)
        try:self._apply_adaptive_detail_fonts()
        except Exception as exc:optional_failure("ui.detail_initial_adaptive_fonts",exc)

    def _stop_title_fit_timer(self):
        try:self._title_fit_timer.stop()
        except Exception as exc:optional_failure("ui.detail_title_timer_stop",exc)
        try:
            if self._title_fit_conn is not None:
                self._title_fit_conn.disconnect();self._title_fit_conn=None
        except Exception as exc:optional_failure("ui.detail_title_timer_disconnect",exc)

    def _schedule_title_fit(self):
        # R262: one stable title-fit sequence per actual title.  The old timer
        # called _schedule_title_fit() from inside its own tick, resetting the
        # pass counter forever; late provider/TMDb paints could then alternate
        # 42px and 46px fits and make the visible name pulse.
        try:
            value=" ".join(str(self["name"].getText() or "").replace("\n"," ").split()).strip()
        except Exception:
            value=""
        key=value
        if key and key==getattr(self,"_title_fit_key","") and int(getattr(self,"_title_fit_pass",0) or 0)>=2:
            return
        self._title_fit_key=key
        self._title_fit_pass=0
        try:
            self._title_fit_timer.stop()
            self._title_fit_timer.start(45,True)
        except Exception as exc:optional_failure("ui.detail_title_timer_start",exc)

    def _title_fit_tick(self):
        try:self._fit_single_line_font("name",self["name"].getText(),42,14)
        except Exception as exc:optional_failure("ui.detail_title_tick",exc)
        self._title_fit_pass=int(getattr(self,"_title_fit_pass",0) or 0)+1
        if self._title_fit_pass<2:
            try:self._title_fit_timer.start(120,True)
            except Exception as exc:optional_failure("ui.detail_title_timer_retry",exc)

    def _fit_single_line_font(self, widget_name, text, max_size=42, min_size=16):
        value=" ".join(str(text or "").replace("\n"," ").split()).strip()
        try:
            widget=self[widget_name]
            inst=widget.instance
            if inst is None:return
            fixed_width = 1318 if widget_name == "name" else (680 if widget_name == "genre_text" else (1318 if widget_name == "cast_text" else 0))
            width=max(80,(int(round(fixed_width * _ultra_osd_scale()))-int(round(28 * _ultra_osd_scale()))) if fixed_width else (int(inst.size().width())-int(round(28 * _ultra_osd_scale()))))
            try:
                if hasattr(inst,"setNoWrap"):inst.setNoWrap(1)
            except Exception as exc:optional_failure("ui.detail_title_nowrap",exc)

            def glyph_units():
                units=0.0;has_ar=False;has_latin=False
                for ch in value:
                    code=ord(ch)
                    if 0x0600<=code<=0x06ff:
                        has_ar=True;units+=0.78
                    elif "A"<=ch<="Z":
                        has_latin=True;units+=0.72
                    elif "a"<=ch<="z":
                        has_latin=True;units+=0.59
                    elif ch.isdigit():units+=0.58
                    elif ch.isspace():units+=0.34
                    elif ch in ".,:;!?'`-_/()[]{}":units+=0.36
                    else:units+=0.66
                return units*(1.16 if has_ar and has_latin else 1.08)

            fcache=getattr(self,"_detail_font_fit_cache",None)
            if not isinstance(fcache,dict) or len(fcache)>512:
                fcache={};self._detail_font_fit_cache=fcache
            ckey=("single",widget_name,width,value,int(max_size),int(min_size))
            chosen=fcache.get(ckey)
            if chosen is None:
                units=max(1.0,glyph_units())
                estimated=int(float(width)/(_ultra_osd_scale()*units))
                chosen=max(int(min_size),min(int(max_size),estimated))
                probe=_get_shared_probe()
                for size in range(chosen,int(min_size)-1,-1):
                    try:
                        if probe is not None:
                            probe.setFont(_ultra_rfont("Regular",size));probe.setText(value)
                            native=int(probe.calculateSize().width())
                        else:native=0
                    except Exception:native=0
                    if native<=0 or native<=width:
                        chosen=size;break
                fcache[ckey]=chosen
            inst.setFont(_ultra_rfont("Regular",chosen))
            if widget_name in ("name","genre_text","cast_text") and hasattr(inst,"setHAlign"):
                inst.setHAlign(_lbl_h("center"))
            if widget_name=="name":self._center_detail_label_geometry("name",547,1318,10)
        except Exception as exc:
            optional_failure("ui.detail_title_adaptive_font",exc)

    def _fit_description_font(self):
        """Use the largest requested overview font that keeps the full text visible.

        R71 makes the setting visually meaningful.  Enigma2's own wrapped text
        height is the primary authority; the old character-count estimate was too
        conservative for Arabic and could shrink an ``Extra Large`` overview back
        near the normal size while most of the glass stayed empty.
        """
        try:
            value=str(self["description"].getText() or "").strip()
            widget=self["description"]
            inst=widget.instance
            try:
                from .ui_smooth_text import scroller as _smooth_scroller
                _scr=_smooth_scroller(self,"description","auto")
            except Exception:_scr=None
            if not value and _scr is not None:_scr.stop()
            if inst is None or not value:return
            width=max(200,int(inst.size().width()))
            height=max(40,int(inst.size().height()))
            try:mode=str(load_settings().get("overview_font_scale") or "normal").strip().lower()
            except Exception:mode="normal"
            preferred={"normal":26,"large":34,"larger":42,"xlarge":52}.get(mode,26)
            desc_sig=(value,width,height,preferred)
            if getattr(self,"_detail_desc_fit_sig",None)==desc_sig:
                return
            self._detail_desc_fit_sig=desc_sig
            min_size=13
            is_ar=bool(self._contains_arabic(value))
            safe_height=max(36,int(height*(0.98 if is_ar else 0.99)))
            # Only use a conservative width estimate when the receiver gives no
            # useful wrapped-height measurement.  This keeps short summaries big.
            fallback_factor=0.50 if is_ar else 0.54
            chosen=min_size;fit_size=None
            for size in range(int(preferred),int(min_size)-1,-1):
                try:
                    inst.setFont(_ultra_rfont("Regular",size))
                    native_h=int(inst.calculateSize().height())
                except Exception:
                    native_h=0
                if native_h>0:
                    needed=int(native_h*(1.06 if is_ar else 1.03))
                else:
                    chars_per_line=max(10,int(width/max(1.0,size*_ultra_osd_scale()*fallback_factor)))
                    explicit=value.count("\n")
                    weighted=len(value)+explicit*chars_per_line
                    lines=max(1,int(math.ceil(float(weighted)/float(chars_per_line))))
                    needed=lines*int(size*_ultra_osd_scale()*1.18)
                if needed<=safe_height:
                    chosen=size;fit_size=size
                    break
            # Long text: instead of shrinking below a comfortable size, keep
            # a readable font and scroll it slowly (pixel-smooth).
            comfort=22
            if _scr is not None:
                if fit_size is None or fit_size<comfort:
                    inst.setFont(_ultra_rfont("Regular",comfort))
                    if _scr.start(value,comfort):return
                _scr.stop()
            inst.setFont(_ultra_rfont("Regular",int(chosen)))
            try:widget.show()
            except Exception:pass
        except Exception as exc:
            optional_failure("ui.detail_description_adaptive_font",exc)

    def _fit_compact_text(self, widget_name, text=None, max_size=22, min_size=10, padding=14):
        """Fit a single-line fixed-width Details label to the largest safe font.

        This is deliberately visual-only: it never edits provider/TMDB text. It
        measures the exact rendered label when possible, then falls back to a
        conservative glyph-width estimate so long translated strings shrink
        before they clip while short values keep the larger native size.
        """
        try:
            widget=self[widget_name]
            inst=widget.instance
            if inst is None:return
            value=str(widget.getText() if text is None else text or "").replace("\n"," ").strip()
            if not value:return
            try:
                if hasattr(inst,"setNoWrap"):inst.setNoWrap(1)
            except Exception:pass
            fixed_width = 680 if widget_name == "genre_text" else (1318 if widget_name == "cast_text" else 0)
            width=max(24,(int(round(fixed_width * _ultra_osd_scale()))-int(round(padding * _ultra_osd_scale()))) if fixed_width else (int(inst.size().width())-int(round(padding * _ultra_osd_scale()))))
            units=0.0
            has_ar=False
            for ch in value:
                code=ord(ch)
                if 0x0600<=code<=0x06ff:
                    has_ar=True;units+=0.80
                elif "A"<=ch<="Z":units+=0.72
                elif "a"<=ch<="z":units+=0.59
                elif ch.isdigit():units+=0.58
                elif ch.isspace():units+=0.34
                elif ch in ".,:;!?'`-_/()[]{}•":units+=0.36
                else:units+=0.68
            fcache=getattr(self,"_detail_font_fit_cache",None)
            if not isinstance(fcache,dict) or len(fcache)>512:
                fcache={};self._detail_font_fit_cache=fcache
            ckey=("compact",widget_name,width,value,int(max_size),int(min_size),int(padding))
            chosen=fcache.get(ckey)
            if chosen is None:
                estimate_factor=1.17 if has_ar else 1.10
                estimated=max(int(min_size),min(int(max_size),int(float(width)/max(1.0,_ultra_osd_scale()*units*estimate_factor))))
                chosen=int(min_size)
                probe=_get_shared_probe()
                for size in range(int(max_size),int(min_size)-1,-1):
                    if size>estimated+2:
                        continue
                    try:
                        if probe is not None:
                            probe.setFont(_ultra_rfont("Regular",size));probe.setText(value)
                            native=int(probe.calculateSize().width())
                        else:native=0
                    except Exception:
                        native=0
                    painted=max(native,int(units*size*estimate_factor*_ultra_osd_scale())) if native>0 else int(units*size*estimate_factor*_ultra_osd_scale())
                    if painted<=width:
                        chosen=size;break
                fcache[ckey]=chosen
            inst.setFont(_ultra_rfont("Regular",chosen))
            if widget_name in ("name","genre_text","cast_text") and hasattr(inst,"setHAlign"):
                inst.setHAlign(_lbl_h("center"))
            if widget_name=="genre_text":self._center_detail_label_geometry("genre_text",1185,680,14)
            elif widget_name=="cast_text":self._center_detail_label_geometry("cast_text",547,1318,14)
            elif widget_name=="name":self._center_detail_label_geometry("name",547,1318,10)
        except Exception as exc:
            optional_failure("ui.detail_compact_adaptive_font",exc)

    @staticmethod
    def _season_count_text(count):
        try:
            number=int(count)
            return ((_('%d season') if number==1 else _('%d seasons')) % number)
        except Exception:
            return _('%s seasons') % str(count or '')

    def _fit_country_font(self):
        """Fit the country name to its pill without changing any other detail UI."""
        try:
            widget=self["country_text"]
            inst=widget.instance
            if inst is None:return
            value=str(widget.getText() or "").strip()
            if not value:return
            # Use the same adaptive principle as the other fitted labels, but
            # reserve real breathing room inside the compact country pill.
            # Receiver font metrics are optimistic here, so combine the native
            # measurement with a glyph-width estimate and choose the safer one.
            width=max(30,int(inst.size().width())-int(round(20 * _ultra_osd_scale())))
            units=0.0
            for ch in value:
                if "A"<=ch<="Z":units+=0.72
                elif "a"<=ch<="z":units+=0.59
                elif ch.isdigit():units+=0.58
                elif ch.isspace():units+=0.34
                elif ch in ".,:;!?'`-_/()[]{}":units+=0.36
                else:units+=0.66
            fcache=getattr(self,"_detail_font_fit_cache",None)
            if not isinstance(fcache,dict) or len(fcache)>512:
                fcache={};self._detail_font_fit_cache=fcache
            ckey=("country",width,value)
            chosen=fcache.get(ckey)
            if chosen is None:
                estimated=max(11,min(22,int(float(width)/max(1.0,_ultra_osd_scale()*units*1.10))))
                chosen=11
                probe=_get_shared_probe()
                for size in range(estimated,10,-1):
                    try:
                        if probe is not None:
                            probe.setFont(_ultra_rfont("Regular",size));probe.setText(value)
                            native=int(probe.calculateSize().width())
                        else:native=0
                    except Exception:
                        native=0
                    painted=int(native*1.20)+6 if native>0 else 0
                    if painted<=0 or painted<=width:
                        chosen=size;break
                fcache[ckey]=chosen
            inst.setFont(_ultra_rfont("Regular",chosen))
        except Exception as exc:
            optional_failure("ui.detail_country_adaptive_font",exc)

    def _apply_adaptive_detail_fonts(self):
        self._fit_single_line_font("name",self["name"].getText(),46,24)
        self._fit_description_font()
        # Every fixed metadata pill follows the same rule: short text keeps the
        # generous native size; longer/localized text shrinks only as much as
        # needed to remain inside its existing box. No layout positions change.
        self._fit_compact_text("quality_text",max_size=21,min_size=11,padding=12)
        self._fit_compact_text("year_text",max_size=22,min_size=12,padding=8)
        self._fit_compact_text("runtime_text",max_size=24,min_size=18,padding=4)
        self._fit_country_font()
        self._fit_compact_text("genre_text",max_size=26,min_size=17,padding=16)
from .wqhd_layout import responsive_font as _ultra_rfont, factors as _ultra_factors, _get_shared_probe

def _ultra_osd_scale():
    return _ultra_factors()[1]
