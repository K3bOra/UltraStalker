# -*- coding: utf-8 -*-
"""Playback link creation and live/VOD command handling.

Methods moved verbatim out of ``StalkerClient`` (client.py); behaviour is unchanged.
This module is imported by client.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int
from .client import LOG, PortalCancelledError, PortalError, PortalLinkError, re, time, urllib

class ClientLinksMixin(object):
    """Playback link creation and live/VOD command handling."""

    @staticmethod
    def _extract_command(item_or_cmd):
        if isinstance(item_or_cmd, dict):
            return item_or_cmd.get('cmd') or item_or_cmd.get('command') or item_or_cmd.get('url') or ''
        return item_or_cmd or ''

    @staticmethod
    def _strip_player_wrapper(value):
        text = str(value or '').strip().strip('"').strip("'")
        if not text:
            return ''
        first, sep, remainder = text.partition(' ')
        if sep and first.lower() in ('ffmpeg', 'auto'):
            text = remainder.lstrip()
        match = re.search('(?i)(https?|rtmp|rtsp|udp|rtp)://\\S+', text)
        if match:
            text = match.group(0)
        return text.strip().strip('"').strip("'")

    @staticmethod
    def _needs_create_link(raw):
        low = str(raw or '').lower()
        return 'localhost' in low or '///' in low or '/ch/' in low or ('http' not in low)

    @staticmethod
    def _live_flag(value):
        return str(value if value is not None else '0').strip().lower() in ('1', 'true', 'yes', 'on')

    def _remember_live_link_policy(self, payload):
        """Learn portal-level link policy from already-authenticated responses.

        Different Ministra/Stalker builds expose the switch in slightly different
        response shapes.  Read only the known policy field and never infer it from
        a stream URL.
        """
        if not isinstance(payload, dict):
            return
        candidates = [payload]
        for key in ('data', 'settings', 'profile', 'config'):
            child = payload.get(key)
            if isinstance(child, dict):
                candidates.append(child)
        for row in candidates:
            if 'force_ch_link_check' in row:
                self._live_force_link_check = self._live_flag(row.get('force_ch_link_check'))
                return

    def _live_link_decision(self, item, raw):
        """Return (needs_refresh, disable_ad, force_check) for one Live row."""
        row = item if isinstance(item, dict) else {}
        metadata_keys = ('use_http_tmp_link', 'use_load_balancing', 'disable_ad')
        metadata_available = any((key in row for key in metadata_keys))
        force_check = bool(self._live_force_link_check or self._live_flag(row.get('force_ch_link_check')))
        disable_ad = self._live_flag(row.get('disable_ad'))
        if metadata_available:
            needs = bool(self._live_flag(row.get('use_http_tmp_link')) or self._live_flag(row.get('use_load_balancing')) or force_check)
        else:
            low = str(raw or '').lower()
            needs = bool(force_check or 'localhost' in low or '///' in low or ('/ch/' in low) or ('http' not in low))
        return (needs, disable_ad, force_check)

    def _clean_live_url(self, value):
        text = self._strip_player_wrapper(value)
        if not text:
            return ''
        text = re.sub('%mac%', self.mac, text, flags=re.IGNORECASE)
        try:
            parsed = urllib.parse.urlsplit(text)
        except Exception:
            return ''
        if parsed.scheme.lower() not in self._PLAYABLE_SCHEMES:
            return ''
        host = str(parsed.hostname or '').lower()
        low = text.lower()
        if host in ('localhost', '127.0.0.1', '::1') or '///' in low:
            return ''
        return text

    def _vod_media_command(self, item, media_type, cancel_event=None):
        command = str(self._extract_command(item) or '')
        if not command.startswith('/media/'):
            return command
        stream_id = None
        if isinstance(item, dict):
            stream_id = item.get('stream_id') or item.get('season_id') or item.get('id') or item.get('movie_id')
        if stream_id in (None, ''):
            return command
        request_type = 'series' if media_type in ('series', 'episode') else 'vod'
        params = {'type': request_type, 'action': 'get_ordered_list', 'movie_id': stream_id, 'season_id': '0', 'episode_id': '0', 'category': '1', 'sortby': '', 'p': '1', 'JsHttpRequest': '1-xml'}
        try:
            rows = self._as_list(self._unwrap(self._get(params, cancel_event=cancel_event)))
            media_id = rows[0].get('id') if rows and isinstance(rows[0], dict) else None
            if media_id not in (None, ''):
                parsed_path = urllib.parse.urlsplit(command).path or command
                extension = ''
                last = parsed_path.rsplit('/', 1)[-1]
                if '.' in last:
                    extension = '.' + last.rsplit('.', 1)[-1]
                return '/media/file_%s%s' % (media_id, extension)
        except PortalError:
            pass
        return command

    def create_link(self, item_or_cmd, media_type='itv', series_id=None, cancel_event=None):
        with self._auth_lock:
            previous = bool(getattr(self._priority_local, 'playback', False))
            previous_endpoint = str(getattr(self._priority_local, 'playback_endpoint', '') or '')
            self._priority_local.playback = True
            pinned = ''
            candidates = list(self._candidate_endpoints())
            for candidate in (self.endpoint, self._compat_cached_endpoint):
                candidate = str(candidate or '').strip()
                if candidate and candidate in candidates:
                    pinned = candidate
                    break
            self._priority_local.playback_endpoint = pinned
            started = time.monotonic()
            try:
                try:
                    self._drop_current_transport(close=True)
                except Exception:
                    pass
                value = self._create_link_impl(item_or_cmd, media_type=media_type, series_id=series_id, cancel_event=cancel_event)
                LOG.info('Playback link ready media=%s elapsed_ms=%d', str(media_type or 'itv'), int((time.monotonic() - started) * 1000.0))
                return value
            except PortalCancelledError:
                raise
            except Exception as exc:
                LOG.warning('Playback link failed media=%s elapsed_ms=%d error=%s', str(media_type or 'itv'), int((time.monotonic() - started) * 1000.0), exc.__class__.__name__)
                raise
            finally:
                self._priority_local.playback = previous
                self._priority_local.playback_endpoint = previous_endpoint

    def _create_link_impl(self, item_or_cmd, media_type='itv', series_id=None, cancel_event=None):
        """Resolve provider playback without changing any UI/navigation behavior.

        Live Stalker rows use channel metadata to decide whether middleware must
        mint a temporary/load-balanced URL.  Direct remote commands stay direct;
        middleware-local commands are resolved once, with one auth refresh retry.
        VOD/series retain the established Ultra Stalker path.
        """
        if not self.token:
            self.authorize(cancel_event=cancel_event)
        seen_token = self.token
        media_type = str(media_type or 'itv').lower()
        row = item_or_cmd if isinstance(item_or_cmd, dict) else {}
        command = self._extract_command(item_or_cmd)
        if media_type in ('vod', 'series', 'episode') and isinstance(item_or_cmd, dict):
            command = self._vod_media_command(item_or_cmd, media_type, cancel_event=cancel_event)
        raw = str(command or '').strip().strip('"').strip("'")
        if not raw:
            raise PortalError('Empty stream command')
        if media_type == 'itv':
            needs_refresh, disable_ad, force_check = self._live_link_decision(row, raw)
            direct = self._clean_live_url(raw)
            if not needs_refresh:
                if direct:
                    return direct
                needs_refresh = True
            params = {'type': 'itv', 'action': 'create_link', 'cmd': raw, 'series': '0', 'forced_storage': '0', 'disable_ad': '1' if disable_ad else '0', 'download': '0', 'force_ch_link_check': '1' if force_check else '0', 'JsHttpRequest': '1-xml'}

            def resolve_once():

                def request_payload():
                    return self._unwrap(self._get(params, retry_auth=False, cancel_event=cancel_event))
                data = self._playback_request_once_more_on_fresh_transport(request_payload)
                if isinstance(data, dict):
                    value = data.get('cmd') or data.get('url') or data.get('link')
                    if not value and data.get('error'):
                        raise PortalLinkError('Live link error: %s' % str(data.get('error')))
                else:
                    value = data if isinstance(data, str) else ''
                return self._clean_live_url(value)
            last_error = None
            try:
                resolved = resolve_once()
                if resolved:
                    LOG.info('Live link resolved via portal policy')
                    return resolved
            except PortalCancelledError:
                raise
            except PortalError as exc:
                last_error = exc
            if last_error is not None and self._is_auth_playback_error(last_error):
                try:
                    self._reauthorize(seen_token, cancel_event=cancel_event)
                    resolved = resolve_once()
                    if resolved:
                        LOG.info('Live link resolved after authorization refresh')
                        return resolved
                except PortalCancelledError:
                    raise
                except PortalError as exc:
                    last_error = exc
            if last_error:
                raise last_error
            raise PortalLinkError('Portal did not return a playable live stream link')
        direct_fallback = self._strip_player_wrapper(raw)
        direct_scheme = urllib.parse.urlsplit(direct_fallback).scheme.lower() if direct_fallback else ''
        direct_playable = direct_scheme in self._PLAYABLE_SCHEMES
        portal_command = bool(isinstance(item_or_cmd, dict) and (item_or_cmd.get('cmd') not in (None, '') or item_or_cmd.get('command') not in (None, '')))
        if not portal_command and (not self._needs_create_link(raw)) and direct_playable:
            return direct_fallback
        api_type = 'vod' if media_type in ('series', 'episode') else media_type
        params = {'type': api_type, 'action': 'create_link', 'cmd': raw, 'series': str(series_id if series_id is not None else ''), 'forced_storage': '', 'disable_ad': '0', 'download': '0', 'force_ch_link_check': '0', 'JsHttpRequest': '1-xml'}

        def request_link():

            def request_payload():
                return self._unwrap(self._get(params, retry_auth=False, cancel_event=cancel_event))
            js = self._playback_request_once_more_on_fresh_transport(request_payload)
            if isinstance(js, dict):
                value = js.get('cmd') or js.get('url') or js.get('link')
                if not value and js.get('error'):
                    raise PortalLinkError('Playback link error: %s' % str(js.get('error')))
                return value
            return js if isinstance(js, str) else None
        value = None
        last_error = None
        try:
            value = request_link()
        except PortalError as exc:
            last_error = exc
        if not value and last_error is not None and self._is_auth_playback_error(last_error):
            try:
                self._reauthorize(seen_token, cancel_event=cancel_event)
                value = request_link()
            except PortalError as exc:
                last_error = exc
        clean = self._strip_player_wrapper(value)
        parsed = urllib.parse.urlsplit(clean) if clean else None
        if clean and parsed.scheme.lower() in self._PLAYABLE_SCHEMES:
            LOG.info('create_link refreshed')
            return clean
        if direct_playable:
            return direct_fallback
        if last_error:
            raise last_error
        if not clean:
            raise PortalLinkError('Portal did not return a stream link')
        raise PortalLinkError('Portal returned an unsupported stream URL')
