# -*- coding: utf-8 -*-
"""Favorite toggle, menu scrim, download menu and title logo.

Methods moved verbatim out of ``ContentDetailsScreen`` (ui_screens_details.py); behaviour is unchanged.
This module is imported by ui_screens_details.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str
from .ui_screens_details import (
    _,
    os,
    reactor,
    resolve_ultra_title_logo,
    ultra_title_logo_cached,
    valid_ultra_title_logo,
    weakref,
)


class DetailsMenusMixin(object):
    """Favorite toggle, menu scrim, download menu and title logo."""

    def toggle_favorite(self):
        added = toggle_favorite(self.profile, self.media_type, self.item)
        self["green"].setText(_("Unfavorite") if added else _("Favorite"))
        self._layout_detail_actions()
        self["status"].setText(_("Added to favorites") if added else _("Removed from favorites"))

    def _details_menu_scrim_show(self):
        try:
            path=asset("us88_focus_dim_scrim.png")
            if path and os.path.isfile(path) and self["settings_menu_scrim"].instance is not None:
                self["settings_menu_scrim"].instance.setPixmapFromFile(path)
            self["settings_menu_scrim"].show()
        except Exception as exc:optional_failure("ui.details_menu_scrim_show",exc)

    def _details_menu_scrim_hide(self):
        try:self["settings_menu_scrim"].hide()
        except Exception as exc:optional_failure("ui.details_menu_scrim_hide",exc)

    def _details_menu_selected_with_scrim(self,choice):
        self._details_menu_scrim_hide()
        return self._download_menu_selected(choice)

    def open_download_menu(self):
        choices=[(_("Set as Home Hero"),"set_home_hero"),(_("Reload external artwork"),"reload")]
        if self.media_type in ('vod','series'):
            from .ui_manual_match import menu_choices
            choices=menu_choices()+choices
        if self.media_type=="vod":
            choices.insert(1,(_("Download Movie"),"movie"))
            choices.insert(2,(_("Downloads Manager"),"manager"))
        elif self.media_type=="series":
            choices.insert(1,(_("Downloads Manager"),"manager"))
        # R168 menu-light pass: same Details actions/anchor, now pure floating
        # text.  No adaptive/glass assets are generated or rebound on MENU open.
        # BACK still removes only the rows and leaves the Details page untouched.
        self._details_menu_scrim_show()
        self._settings_inline_menu.show(choices,selection=0,right=1850,region_top=240,region_h=400,
            on_accept=self._details_menu_selected_with_scrim,on_close=self._details_menu_scrim_hide,
            min_card_w=260,max_card_w=680,padding=54,anchor_bottom=670,
            visual_style="text_only",row_h=66,max_visible=5,text_font=30)

    def _schedule_details_title_logo(self, data, visible_title):
        """Use the one Ultra-owned background title-logo service."""
        try:
            # R181: identity first-paint and final metadata may report the exact
            # same logo milliseconds apart. Never cancel/restart that same job.
            row=dict(data or {}) if isinstance(data,dict) else {}
            size=self._title_logo_target_size or (432,210)
            item=dict(getattr(self,"_portal_item",{}) or getattr(self,"item",{}) or {})
            request_key=(str(row.get("tmdb_id") or ""),str(row.get("logo_url") or ""),str(row.get("logo_language") or ""),str(visible_title or ""),tuple(size))
            previous=getattr(self,"_title_logo_future",None)
            if request_key==getattr(self,"_title_logo_request_key",None) and previous is not None and not previous.done():
                return
            self._title_logo_request_key=request_key
            self._title_logo_token += 1;req_id=self._title_logo_token
            # R101: keep the last good title logo visible while a refreshed
            # identity/logo is resolving. Cached hits below swap immediately.
            cached=ultra_title_logo_cached(self.media_type,item,row,size,visible_title)
            self._title_logo_cache_target=cached
            if cached:
                self._apply_ultra_details_title_logo(cached,req_id);return
            if previous is not None and not previous.done():
                try:previous.cancel()
                except Exception:pass
            cfg=load_settings() or {};self_ref=weakref.ref(self);row_copy=dict(row);item_copy=dict(item)
            def worker():
                owner=self_ref()
                if owner is None or owner._screen_closed or owner._details_cancel_event.is_set() or req_id!=owner._title_logo_token:return
                try:
                    path,_resolved=resolve_ultra_title_logo(owner.profile,owner.media_type,item_copy,row_copy,canvas_size=size,visible_title=visible_title,cancel_event=owner._details_cancel_event,settings=cfg)
                    owner=self_ref()
                    if owner is not None and not owner._screen_closed and req_id==owner._title_logo_token:
                        reactor.callFromThread(owner._apply_ultra_details_title_logo,path or "",req_id,True)
                except Exception as exc:optional_failure("ui.details_title_logo_worker",exc)
            future=_DETAIL_LOGO_EXECUTOR.submit(worker,_task_key="details-title-logo:%x"%id(self),_replace_task_key=True)
            self._title_logo_future=future;self._track_details_future(future)
        except Exception as exc:optional_failure("ui.details_title_logo_schedule",exc)

    def _apply_ultra_details_title_logo(self,path,req_id,final=False):
        try:
            if req_id!=self._title_logo_token or self._screen_closed:return
            path=str(path or "")
            if valid_ultra_title_logo(path):
                self._title_logo_cache_target=path
                if self["title_logo"].instance is not None:
                    self["title_logo"].instance.setPixmapFromFile(path);self["title_logo"].show()
                return
            if final:
                self._title_logo_cache_target=""
                try:
                    self["title_logo"].hide()
                    if self["title_logo"].instance is not None:self["title_logo"].instance.setPixmap(None)
                except Exception:pass
        except Exception as exc:optional_failure("ui.details_title_logo_apply",exc)
