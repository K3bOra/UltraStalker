# -*- coding: utf-8 -*-
"""Player overlay, subtitle-choice and live-zap screens.

Player overlay and chooser screens split from the main native player module.
Their public behavior remains owned by the Ultra Stalker player contract.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .. import us_env as _us_env
from ..us_env import str, int, round, max, min, us_clear, us_func, native_str
from ..asset_paths import canonical_asset as _canonical_asset
from ..wqhd_layout import scale_skin as _wqhd_scale_skin, responsive_font as _ultra_rfont, factors as _ultra_factors, xy as _wqhd_xy, wh as _wqhd_wh, font_size as _wqhd_font, register_pixmap_path as _register_pixmap_path

def _ultra_osd_scale():
    return _ultra_factors()[1]

try:
    import colorsys
except Exception:
    from .. import compat_colorsys as colorsys

hashlib = _us_env.hashlib
os = _us_env.os
queue = _us_env.queue
re = _us_env.re
threading = _us_env.threading
time = _us_env.time
import unicodedata

try:
    from PIL import Image as _PILImage, ImageDraw as _ImageDraw, ImageFilter as _ImageFilter
except Exception:
    _PILImage = None
    _ImageDraw = None
    _ImageFilter = None

from .. import _
from ..core.image_budget import image_budgeted
from ..securefs import secure_private_dir
from ..persistent_cache import GENERATED as PERSISTENT_GENERATED_DIR
from ..ui_clean_glass import glass as _cg_glass
from ..log import optional_failure
from ..storage import load_settings
from ..adaptive_mode import adaptive_enabled
from ..ui_dynamic_chrome import _build_dynamic_details_chrome, canonical_dynamic_details_key
from .player_core import _PLAYER_BG_EXECUTOR
from .player_artwork import _asset, _adaptive_info_frames, _item_library_palette

from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.MenuList import MenuList
from Components.MultiContent import MultiContentEntryText, MultiContentEntryPixmapAlphaTest
try:
    from Components.MultiContent import MultiContentEntryPixmapAlphaBlend
except Exception:
    MultiContentEntryPixmapAlphaBlend = MultiContentEntryPixmapAlphaTest
from Components.Pixmap import Pixmap
from Components.ProgressBar import ProgressBar
from Components.ServiceEventTracker import ServiceEventTracker
from Screens.Screen import Screen
from enigma import eTimer, iPlayableService, gFont, eListboxPythonMultiContent, RT_HALIGN_LEFT, RT_VALIGN_CENTER, loadPNG

SUBTITLE_STYLE_COLORS = (
    ("White", "#FFFFFF"), ("Cream", "#FFF1C1"), ("Yellow", "#FFD84D"),
    ("Gold", "#FFB300"), ("Orange", "#FF9A4D"), ("Lime", "#D9FF57"),
    ("Green", "#69F0AE"), ("Mint", "#64FFD8"), ("Cyan", "#5DEBFF"),
    ("Sky Blue", "#63B8FF"), ("Blue", "#7D93FF"), ("Lavender", "#C3A6FF"),
    ("Purple", "#DA9BFF"), ("Pink", "#FF95D8"), ("Coral", "#FF958C"),
)
SUBTITLE_POSITION_PRESETS = (
    ("Very High", 180), ("High", 120), ("Upper", 60), ("Default", 0),
    ("Lower", -60), ("Low", -120), ("Very Low", -180),
)
def _subtitle_color_name(value):
    value=str(value or "#FFFFFF").upper()
    for name,hex_value in SUBTITLE_STYLE_COLORS:
        if hex_value.upper()==value:return name
    return "White"
def _subtitle_position_name(value):
    try:value=int(value or 0)
    except Exception:value=0
    for name,offset in SUBTITLE_POSITION_PRESETS:
        if int(offset)==value:return name
    return ("%+d px"%value) if value else "Default"


@image_budgeted
def _subtitle_glass_assets(source_path, width=1120, row_width=1010, row_height=72, player_frames=None):
    # source_path stays in the API for callers; artwork is never a colour authority.
    from ..player_premium_overlays import premium_assets
    try:
        return premium_assets((("frame",1280,800,False),("inner",1180,590,False),
                               ("row",row_width,row_height,False),
                               ("row_selected",row_width,row_height,True)), player_frames,
                              material=_asset("live_list_premium_r5423/master.png"))
    except Exception as exc:
        optional_failure("player.subtitle_glass_assets",exc)
        return {}


class SubtitleGlassList(MenuList):
    def __init__(self, choices=None, width=1010, item_height=72):
        self.row_width=int(width)
        self.row_height=int(item_height)
        self._rows=list(choices or [])
        self._row_asset=""
        self._row_selected_asset=""
        self._rendering=False
        us_func(MenuList.__init__)(self,[],enableWrapAround=True,content=eListboxPythonMultiContent)
        # Per-row adaptive fonts: each title selects the largest size that fits.
        for idx,size in enumerate((25,23,21,19,17)):
            self.l.setFont(idx,_ultra_rfont("Regular",size))
        self.l.setItemHeight(_wqhd_font(self.row_height))

    def _font_index(self,text):
        n=len(str(text or ""))
        if n<=30:return 0
        if n<=44:return 1
        if n<=62:return 2
        if n<=82:return 3
        return 4

    def set_assets(self,row_asset,row_selected_asset):
        self._row_asset=str(row_asset or "")
        self._row_selected_asset=str(row_selected_asset or "")

    def set_choices(self,choices,selected=0):
        self._rows=list(choices or [])
        self._render(selected)

    def _render(self,selected=None):
        if self._rendering:return
        self._rendering=True
        if selected is None:
            selected=self.getSelectedIndex() if self._rows else 0
        rows=[]
        for idx,choice in enumerate(self._rows):
            label=str(choice[0] if isinstance(choice,(tuple,list)) and choice else choice or "")
            payload=choice
            row=[payload]
            frame_path=self._row_selected_asset if idx==selected else self._row_asset
            try:
                png=loadPNG(frame_path) if frame_path and os.path.isfile(frame_path) else None
                if png is not None:
                    _register_pixmap_path(png, frame_path)
            except Exception:
                png=None
            if png is not None:
                row.append(MultiContentEntryPixmapAlphaBlend(pos=(0,5),size=(self.row_width,66),png=png))
            font_idx=self._font_index(label)
            row.append(MultiContentEntryText(
                pos=(28,7),size=(self.row_width-56,58),
                font=font_idx,flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER,text=label
            ))
            rows.append(row)
        try:
            from ..wqhd_layout import scale_multicontent_row as _wqhd_list_row
            self.setList([_wqhd_list_row(r) for r in rows])
            if rows:
                try:self.moveToIndex(max(0,min(int(selected),len(rows)-1)))
                except Exception:pass
        finally:
            self._rendering=False

    def selection_changed(self):
        if not self._rendering:self._render(self.getSelectedIndex())

    def selected_choice(self):
        idx=self.getSelectedIndex()
        return self._rows[idx] if 0<=idx<len(self._rows) else None



# The obsolete standalone Search portal chooser was removed in R5.441.
# The shared SubtitleGlassList/_subtitle_glass_assets stay for Details.

PLAYER_INFO_SKIN = """
<screen name="PlayerInformationOverlay" position="0,0" size="1920,1080" backgroundColor="#ffffffff" flags="wfNoBorder">
 <ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/us78_details_info_scrim.png" alphatest="blend" scale="1" transparent="1" zPosition="1"/>
 <widget name="adaptive_main" position="210,175" size="1500,690" alphatest="blend" transparent="1" zPosition="2"/>
 <widget name="adaptive_poster" position="235,225" size="280,400" alphatest="blend" transparent="1" zPosition="3"/>
 <widget name="poster" position="250,240" size="250,370" alphatest="blend" scale="1" zPosition="4"/>
 <widget name="title" position="575,214" size="1035,58" font="Regular;38" foregroundColor="#ffffff" transparent="1" zPosition="5"/>

 <widget name="adaptive_facts" position="555,278" size="1080,102" alphatest="blend" transparent="1" zPosition="3"/>
 <widget name="meta" position="575,289" size="1040,28" font="Regular;19" foregroundColor="#a2e1c6" transparent="1" zPosition="5"/>
 <widget name="facts" position="575,320" size="885,48" font="Regular;17" foregroundColor="#dcebf2" transparent="1" valign="center" zPosition="5"/>

 <widget name="adaptive_desc" position="555,392" size="1080,222" alphatest="blend" transparent="1" zPosition="3"/>
 <widget name="description" position="570,406" size="1050,194" font="Regular;26" foregroundColor="#f7f9fb" transparent="1" valign="top" zPosition="5"/>
 <widget name="page" position="1500,582" size="100,20" font="Regular;15" halign="right" foregroundColor="#a2e1c6" transparent="1" zPosition="5"/>

 <widget name="adaptive_cast" position="555,628" size="600,126" alphatest="blend" transparent="1" zPosition="3"/>
 <widget name="cast_label" position="575,643" size="130,26" font="Regular;18" foregroundColor="#a2e1c6" transparent="1" zPosition="5"/>
 <widget name="cast" position="570,669" size="570,72" font="Regular;19" halign="center" valign="center" foregroundColor="#ffffff" transparent="1" zPosition="5"/>

 <widget name="adaptive_director" position="1168,628" size="220,126" alphatest="blend" transparent="1" zPosition="3"/>
 <widget name="director_label" position="1180,643" size="196,26" font="Regular;18" halign="center" foregroundColor="#a2e1c6" transparent="1" zPosition="5"/>
 <widget name="director" position="1180,669" size="196,72" font="Regular;18" halign="center" valign="center" foregroundColor="#ffffff" transparent="1" zPosition="5"/>

 <widget name="adaptive_writer" position="1401,628" size="234,126" alphatest="blend" transparent="1" zPosition="3"/>
 <widget name="writer_label" position="1413,643" size="210,26" font="Regular;18" halign="center" foregroundColor="#a2e1c6" transparent="1" zPosition="5"/>
 <widget name="writer" position="1413,669" size="210,72" font="Regular;18" halign="center" valign="center" foregroundColor="#ffffff" transparent="1" zPosition="5"/>

 <widget name="poster_rating_bg" position="235,640" size="280,82" alphatest="blend" transparent="1" zPosition="3"/>
 <ePixmap position="252,657" size="74,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/us65_logo_imdb_94x36.png" alphatest="blend" scale="1" zPosition="6"/>
 <widget name="imdb_value" position="326,651" size="58,40" font="Regular;25" halign="center" valign="center" foregroundColor="#ffffff" transparent="1" zPosition="7"/>
 <ePixmap position="390,657" size="74,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/us62_icon_tmdb.png" alphatest="blend" scale="1" zPosition="6"/>
 <widget name="tmdb_value" position="464,651" size="44,40" font="Regular;25" halign="center" valign="center" foregroundColor="#ffffff" transparent="1" zPosition="7"/>

 <widget name="adaptive_extra" position="555,770" size="1080,78" alphatest="blend" transparent="1" zPosition="3"/>
 <widget name="info_left" position="575,779" size="1040,28" font="Regular;15" foregroundColor="#a2e1c6" transparent="1" valign="center" zPosition="5"/>
 <widget name="info_right" position="575,811" size="1040,28" font="Regular;15" foregroundColor="#dcebf2" transparent="1" valign="center" zPosition="5"/>
</screen>
"""

class PlayerInformationOverlay(Screen):
    skin=_wqhd_scale_skin(PLAYER_INFO_SKIN)
    def __init__(self,session,name,item,media_type,meta,poster_path=None,backdrop_path=None):
        us_func(Screen.__init__)(self,session);self.item=dict(item) if isinstance(item,dict) else {}
        try:
            _tid=self.item.get("_locked_tmdb_id") or self.item.get("_ultra_search_verified_tmdb_id") or self.item.get("tmdb_id")
            if _tid:
                from ..media_library import load as _ml_load
                _mt="tv" if str(media_type or "").lower() in ("series","tv","episode") else "movie"
                _canon=_ml_load(_mt,_tid) or {}
                for _ck,_cv in _canon.items():
                    if _cv not in (None,"",[],{}) and self.item.get(_ck) in (None,"",[],{}):
                        self.item[_ck]=_cv
                if not poster_path and _canon.get("poster_local") and os.path.isfile(str(_canon.get("poster_local"))):
                    poster_path=str(_canon.get("poster_local"))
        except Exception:pass
        self["poster"]=Pixmap();self["adaptive_main"]=Pixmap();self["adaptive_poster"]=Pixmap();self["poster_rating_bg"]=Pixmap();self["adaptive_facts"]=Pixmap();self["adaptive_desc"]=Pixmap();self["adaptive_cast"]=Pixmap();self["adaptive_director"]=Pixmap();self["adaptive_writer"]=Pixmap();self["adaptive_extra"]=Pixmap();self["imdb_value"]=Label("");self["tmdb_value"]=Label("")
        self["title"]=Label(str(name or _("Media information"))[:105]);self["meta"]=Label(str(meta or "")[:160]);self["facts"]=Label("")
        desc=""
        try:
            from ..details_authority import loaded_description_for_display
            desc=loaded_description_for_display(self.item,self.item,load_settings() or {}) or ""
        except Exception:desc=""
        if not desc:
            desc=self.item.get("description") or self.item.get("descr") or self.item.get("plot") or self.item.get("overview") or _("No additional description is available.")
        # Details Information uses the complete overview, just like Cinematic/Details.
        # Geometry stays fixed; only the text font adapts to the authored box.
        self._pages=[str(desc or "")];self._page=0;self["description"]=Label(self._pages[0]);self["page"]=Label("")
        cast=self.item.get("actors") or self.item.get("cast") or self.item.get("actor") or "";director=self.item.get("director") or self.item.get("directors") or "";writer=self.item.get("writer") or self.item.get("writers") or self.item.get("creator") or ""
        self["cast_label"]=Label(_("Cast") if cast else "");self["cast"]=Label(str(cast));self["director_label"]=Label(_("Director") if director else "");self["director"]=Label(str(director));self["writer_label"]=Label(_("Writer") if writer else "");self["writer"]=Label(str(writer))
        def _txt(value):
            if value in (None,"",[],{}): return ""
            if isinstance(value,(list,tuple)): return ", ".join(str(x) for x in value if str(x or "").strip())
            return str(value).strip()
        genres=_txt(self.item.get("genres") or self.item.get("genre")); countries=_txt(self.item.get("countries") or self.item.get("country")); production=_txt(self.item.get("production_companies") or self.item.get("production"))
        rating_raw=self.item.get("rating") or self.item.get("vote_average") or self.item.get("imdb_rating") or ""; votes=self.item.get("vote_count") or ""
        try:
            rating_num=float(rating_raw); rating=("%.1f/10"%rating_num) if rating_num>0 else ""
            score=("%d%%"%int(round(rating_num*10))) if rating_num>0 else ""
        except Exception:
            rating_num=0.0; rating=_txt(rating_raw); score=""
        age=_txt(self.item.get("age_rating") or self.item.get("certification")); release=_txt(self.item.get("release_date") or self.item.get("first_air_date")); status=_txt(self.item.get("status")); lang=_txt(self.item.get("original_language")); original=_txt(self.item.get("original_title") or self.item.get("original_name")); tagline=_txt(self.item.get("tagline"))
        seasons=_txt(self.item.get("number_of_seasons")); episodes=_txt(self.item.get("number_of_episodes")); last_air=_txt(self.item.get("last_air_date"))
        imdb_rating=_txt(self.item.get("imdb_rating") or self.item.get("imdb_score")); tmdb_rating=_txt(self.item.get("vote_average") or self.item.get("tmdb_rating") or self.item.get("rating"))
        def _rating_value(v):
            try:
                n=float(v); return ("%.1f"%n) if n>0 else "-"
            except Exception:return str(v or "-")[:5]
        self["imdb_value"].setText(_rating_value(imdb_rating)); self["tmdb_value"].setText(_rating_value(tmdb_rating))
        budget=_txt(self.item.get("budget")); revenue=_txt(self.item.get("revenue")); networks=_txt(self.item.get("networks") or self.item.get("network")); created_by=_txt(self.item.get("created_by") or self.item.get("creators")); show_type=_txt(self.item.get("type")); in_prod=self.item.get("in_production")
        prod_countries=_txt(self.item.get("production_countries")); homepage=_txt(self.item.get("homepage"))
        # Premium facts: important facts live directly below the title instead of being dumped at the foot of the card.
        # Suppress provider-internal numeric status flags; only human-readable status belongs in the UI.
        if status.isdigit(): status=""
        top=[]; extra=[]; tail=[]
        if genres:top.append(_("Genre")+": "+genres)
        if age:top.append(_("Age Rating")+": "+age)
        if rating:top.append(_("Rating")+": "+rating+((" ("+str(votes)+" votes)") if votes else ""))
        if release:top.append(_("Release Date")+": "+release)
        if status:top.append(_("Status")+": "+status)
        if original:extra.append(_("Original Title")+": "+original)
        if lang:extra.append(_("Original Language")+": "+lang.upper())
        if countries:extra.append(_("Country")+": "+countries)
        if production:extra.append(_("Production")+": "+production)
        if prod_countries and prod_countries != countries: extra.append(_("Production Countries")+": "+prod_countries)
        if media_type in ("series","tv"):
            if seasons:extra.append(_("Seasons")+": "+seasons)
            if episodes:extra.append(_("Episodes")+": "+episodes)
            if last_air:extra.append(_("Last Air Date")+": "+last_air)
            if networks:tail.append(_("Networks")+": "+networks)
            if created_by:tail.append(_("Created By")+": "+created_by)
            if show_type:tail.append(_("Type")+": "+show_type)
            if isinstance(in_prod,bool):tail.append(_("In Production")+": "+(_("Yes") if in_prod else _("No")))
        else:
            def _money(v):
                try:
                    n=int(float(v)); return ("$%s"%format(n,",")) if n>0 else ""
                except Exception:return ""
            b=_money(budget); r=_money(revenue)
            if b:tail.append(_("Budget")+": "+b)
            if r:tail.append(_("Revenue")+": "+r)
        if tagline:tail.append(_("Tagline")+": "+tagline)
        def _runtime_hm(v):
            try:
                n=int(float(v or 0))
                if n<=0:return ""
                h,m=divmod(n,60)
                return ((str(h)+"h ") if h else "")+(str(m)+"m" if m else "")
            except Exception:return ""
        runtime_hm=_runtime_hm(self.item.get("runtime") or self.item.get("duration") or self.item.get("time"))
        meta_bits=[]
        if age: meta_bits.append(age)
        if release: meta_bits.append(release + ((" ("+countries.split(",")[0].strip()+")") if countries else ""))
        if runtime_hm: meta_bits.append(runtime_hm)
        if genres: meta_bits.append(genres)
        if meta_bits:self["meta"].setText("   •   ".join(meta_bits))
        self["facts"].setText("   •   ".join(top))
        self["info_left"]=Label("   •   ".join(extra));self["info_right"]=Label("   •   ".join(tail))
        self._poster_path=poster_path;self._media_type=media_type;self.onLayoutFinish.append(self._layout_ready);self._sync_page()
        self["actions"]=ActionMap(["OkCancelActions","ColorActions","DirectionActions"],{"cancel":self.close,"ok":self.close,"yellow":self.close,"up":self.page_up,"down":self.page_down},-1000)
    def _sync_page(self):
        try:self["description"].setText(self._pages[self._page]);self["page"].setText(("%d / %d"%(self._page+1,len(self._pages))) if len(self._pages)>1 else "")
        except Exception as exc:optional_failure("player",exc)
    def _layout_ready(self):
        try:
            if self._poster_path and os.path.isfile(self._poster_path):
                self["poster"].instance.setPixmapFromFile(self._poster_path);self["poster"].show()
            frames=_adaptive_info_frames(self._poster_path if (self._poster_path and os.path.isfile(self._poster_path)) else "",_item_library_palette(self.item,getattr(self,"_media_type","")))
            for widget_name,key in (("adaptive_main","main"),("adaptive_poster","poster"),("poster_rating_bg","rating"),("adaptive_facts","facts"),("adaptive_desc","desc"),("adaptive_cast","cast"),("adaptive_director","director"),("adaptive_writer","writer"),("adaptive_extra","extra")):
                path=frames.get(key)
                widget=self[widget_name]
                if path and os.path.isfile(path) and widget.instance is not None:
                    widget.instance.setPixmapFromFile(path);widget.show()
        except Exception as exc:optional_failure("player.info_layout",exc)
        self._fit_overview_font()
        for _name,_max in (("facts",17),("cast",19),("director",18),("writer",18),("info_left",16),("info_right",16)):
            self._fit_box_text(_name,_max,11)

    def _fit_overview_font(self):
        try:
            value=str(self["description"].getText() or "").strip();inst=self["description"].instance
            if not value or inst is None:return
            try:mode=str(load_settings().get("overview_font_scale") or "normal").strip().lower()
            except Exception:mode="normal"
            preferred={"normal":26,"large":34,"larger":42,"xlarge":52}.get(mode,26)
            safe_h=max(40,int(inst.size().height()*0.98))
            chosen=13
            for size in range(int(preferred),12,-1):
                try:
                    inst.setFont(_ultra_rfont("Regular",size));needed=int(inst.calculateSize().height()*1.06)
                except Exception:needed=safe_h+1
                if needed<=safe_h:
                    chosen=size;break
            inst.setFont(_ultra_rfont("Regular",chosen))
        except Exception as exc:optional_failure("player.info_overview_autofit",exc)

    def _fit_box_text(self,name,max_size,min_size):
        try:
            value=str(self[name].getText() or "").strip();inst=self[name].instance
            if not value or inst is None:return
            safe_h=max(24,int(inst.size().height()*0.96));chosen=min_size
            for size in range(int(max_size),int(min_size)-1,-1):
                try:
                    inst.setFont(_ultra_rfont("Regular",size));needed=int(inst.calculateSize().height()*1.05)
                except Exception:needed=safe_h+1
                if needed<=safe_h:
                    chosen=size;break
            inst.setFont(_ultra_rfont("Regular",chosen))
        except Exception as exc:optional_failure("player.info_text_autofit",exc)
    def page_up(self):
        if self._pages:self._page=(self._page-1)%len(self._pages);self._sync_page()
    def page_down(self):
        if self._pages:self._page=(self._page+1)%len(self._pages);self._sync_page()


LIVE_ZAP_SKIN = """
<screen name="UltraStalkerLiveZapList" position="0,0" size="590,1080" backgroundColor="#02070b" flags="wfNoBorder">
    <widget name="panel" position="0,0" size="590,1080" zPosition="-6" alphatest="blend" />
    <widget name="folder_bg" position="204,18" size="358,46" zPosition="3" alphatest="blend" />
    <widget name="channel_bg" position="204,72" size="358,38" zPosition="3" alphatest="blend" />
    <widget name="picon" position="28,18" size="166,100" zPosition="7" alphatest="blend" />
    <widget name="title" position="218,20" size="330,42" font="Regular;24" foregroundColor="#ffffff" transparent="1" zPosition="8" valign="center" />
    <widget name="subtitle" position="218,73" size="330,36" font="Regular;19" foregroundColor="#e8f6fb" transparent="1" zPosition="8" valign="center" />
    <widget name="bg0" position="18,143" size="554,52" zPosition="2" alphatest="blend" />
    <widget name="num0" position="24,143" size="44,52" font="Regular;18" halign="center" valign="center" foregroundColor="#9fc7d9" transparent="1" zPosition="7" />
    <widget name="row0" position="102,143" size="446,52" font="Regular;22" halign="left" valign="center" foregroundColor="#eef8fc" transparent="1" zPosition="7" />
    <widget name="bg1" position="18,199" size="554,52" zPosition="2" alphatest="blend" />
    <widget name="num1" position="24,199" size="44,52" font="Regular;18" halign="center" valign="center" foregroundColor="#9fc7d9" transparent="1" zPosition="7" />
    <widget name="row1" position="102,199" size="446,52" font="Regular;22" halign="left" valign="center" foregroundColor="#eef8fc" transparent="1" zPosition="7" />
    <widget name="bg2" position="18,255" size="554,52" zPosition="2" alphatest="blend" />
    <widget name="num2" position="24,255" size="44,52" font="Regular;18" halign="center" valign="center" foregroundColor="#9fc7d9" transparent="1" zPosition="7" />
    <widget name="row2" position="102,255" size="446,52" font="Regular;22" halign="left" valign="center" foregroundColor="#eef8fc" transparent="1" zPosition="7" />
    <widget name="bg3" position="18,311" size="554,52" zPosition="2" alphatest="blend" />
    <widget name="num3" position="24,311" size="44,52" font="Regular;18" halign="center" valign="center" foregroundColor="#9fc7d9" transparent="1" zPosition="7" />
    <widget name="row3" position="102,311" size="446,52" font="Regular;22" halign="left" valign="center" foregroundColor="#eef8fc" transparent="1" zPosition="7" />
    <widget name="bg4" position="18,367" size="554,52" zPosition="2" alphatest="blend" />
    <widget name="num4" position="24,367" size="44,52" font="Regular;18" halign="center" valign="center" foregroundColor="#9fc7d9" transparent="1" zPosition="7" />
    <widget name="row4" position="102,367" size="446,52" font="Regular;22" halign="left" valign="center" foregroundColor="#eef8fc" transparent="1" zPosition="7" />
    <widget name="bg5" position="18,423" size="554,52" zPosition="2" alphatest="blend" />
    <widget name="num5" position="24,423" size="44,52" font="Regular;18" halign="center" valign="center" foregroundColor="#9fc7d9" transparent="1" zPosition="7" />
    <widget name="row5" position="102,423" size="446,52" font="Regular;22" halign="left" valign="center" foregroundColor="#eef8fc" transparent="1" zPosition="7" />
    <widget name="bg6" position="18,479" size="554,52" zPosition="2" alphatest="blend" />
    <widget name="num6" position="24,479" size="44,52" font="Regular;18" halign="center" valign="center" foregroundColor="#9fc7d9" transparent="1" zPosition="7" />
    <widget name="row6" position="102,479" size="446,52" font="Regular;22" halign="left" valign="center" foregroundColor="#eef8fc" transparent="1" zPosition="7" />
    <widget name="bg7" position="18,535" size="554,52" zPosition="2" alphatest="blend" />
    <widget name="num7" position="24,535" size="44,52" font="Regular;18" halign="center" valign="center" foregroundColor="#9fc7d9" transparent="1" zPosition="7" />
    <widget name="row7" position="102,535" size="446,52" font="Regular;22" halign="left" valign="center" foregroundColor="#eef8fc" transparent="1" zPosition="7" />
    <widget name="bg8" position="18,591" size="554,52" zPosition="2" alphatest="blend" />
    <widget name="num8" position="24,591" size="44,52" font="Regular;18" halign="center" valign="center" foregroundColor="#9fc7d9" transparent="1" zPosition="7" />
    <widget name="row8" position="102,591" size="446,52" font="Regular;22" halign="left" valign="center" foregroundColor="#eef8fc" transparent="1" zPosition="7" />
    <widget name="bg9" position="18,647" size="554,52" zPosition="2" alphatest="blend" />
    <widget name="num9" position="24,647" size="44,52" font="Regular;18" halign="center" valign="center" foregroundColor="#9fc7d9" transparent="1" zPosition="7" />
    <widget name="row9" position="102,647" size="446,52" font="Regular;22" halign="left" valign="center" foregroundColor="#eef8fc" transparent="1" zPosition="7" />
    <widget name="bg10" position="18,703" size="554,52" zPosition="2" alphatest="blend" />
    <widget name="num10" position="24,703" size="44,52" font="Regular;18" halign="center" valign="center" foregroundColor="#9fc7d9" transparent="1" zPosition="7" />
    <widget name="row10" position="102,703" size="446,52" font="Regular;22" halign="left" valign="center" foregroundColor="#eef8fc" transparent="1" zPosition="7" />
    <widget name="bg11" position="18,759" size="554,52" zPosition="2" alphatest="blend" />
    <widget name="num11" position="24,759" size="44,52" font="Regular;18" halign="center" valign="center" foregroundColor="#9fc7d9" transparent="1" zPosition="7" />
    <widget name="row11" position="102,759" size="446,52" font="Regular;22" halign="left" valign="center" foregroundColor="#eef8fc" transparent="1" zPosition="7" />
    <widget name="bg12" position="18,815" size="554,52" zPosition="2" alphatest="blend" />
    <widget name="num12" position="24,815" size="44,52" font="Regular;18" halign="center" valign="center" foregroundColor="#9fc7d9" transparent="1" zPosition="7" />
    <widget name="row12" position="102,815" size="446,52" font="Regular;22" halign="left" valign="center" foregroundColor="#eef8fc" transparent="1" zPosition="7" />
    <widget name="bg13" position="18,871" size="554,52" zPosition="2" alphatest="blend" />
    <widget name="num13" position="24,871" size="44,52" font="Regular;18" halign="center" valign="center" foregroundColor="#9fc7d9" transparent="1" zPosition="7" />
    <widget name="row13" position="102,871" size="446,52" font="Regular;22" halign="left" valign="center" foregroundColor="#eef8fc" transparent="1" zPosition="7" />
    <widget name="bg14" position="18,927" size="554,52" zPosition="2" alphatest="blend" />
    <widget name="num14" position="24,927" size="44,52" font="Regular;18" halign="center" valign="center" foregroundColor="#9fc7d9" transparent="1" zPosition="7" />
    <widget name="row14" position="102,927" size="446,52" font="Regular;22" halign="left" valign="center" foregroundColor="#eef8fc" transparent="1" zPosition="7" />
    <widget name="footer_count_bg" position="18,1000" size="118,42" zPosition="3" alphatest="blend" />
    <widget name="footer_page_bg" position="142,1000" size="126,42" zPosition="3" alphatest="blend" />
    <widget name="footer_play_bg" position="274,1000" size="126,42" zPosition="3" alphatest="blend" />
    <widget name="footer_close_bg" position="406,1000" size="166,42" zPosition="3" alphatest="blend" />
    <widget name="counter" position="22,1001" size="110,40" font="Regular;15" halign="center" valign="center" foregroundColor="#eaf8ff" transparent="1" zPosition="8" />
    <widget name="footer_page" position="146,1001" size="118,40" font="Regular;15" halign="center" valign="center" foregroundColor="#eaf8ff" transparent="1" zPosition="8" />
    <widget name="footer_play" position="278,1001" size="118,40" font="Regular;15" halign="center" valign="center" foregroundColor="#eaf8ff" transparent="1" zPosition="8" />
    <widget name="footer_close" position="410,1001" size="158,40" font="Regular;15" halign="center" valign="center" foregroundColor="#eaf8ff" transparent="1" zPosition="8" />
</screen>
"""

def _clean_live_name(value, enabled=True):
    raw=str(value or "").strip()
    if not enabled:
        return raw or "Channel"
    text=raw
    try:text=unicodedata.normalize("NFKC",text)
    except Exception as exc:optional_failure("player.optional_guard",exc)
    text=re.sub(r"^\s*#+\s*","",text);text=re.sub(r"\s*#+\s*$","",text)
    text=re.sub(r"^\s*[A-Z]{2,3}\s*[:|•/_-]\s*","",text)
    text=re.sub(r"(?i)\(\s*(?:EVENT\s*ONLY|BACKUP|TEST|VIP)\s*\)"," ",text)
    tokens=("3840P","2160P","1440P","1080P","720P","576P","480P","FULL HD","FULLHD","FHD","ULTRA HD","ULTRAHD","UHD","HDR10+","HDR10","HDR","DOLBY VISION","DOLBYVISION","HEVC","H.265","H265","H.264","H264","60FPS","50FPS","30FPS","8K","4K")
    for _ in range(5):
        old=text
        for token in sorted(tokens,key=len,reverse=True):
            text=re.sub(r"(?i)(?<![A-Z0-9])"+re.escape(token)+r"(?![A-Z0-9])"," ",text)
        text=re.sub(r"\s*[\[\]{}<>|•·▶►◀◄]+\s*"," ",text)
        text=re.sub(r"\s*[:;,_/\\]+\s*"," ",text)
        text=re.sub(r"\s{2,}"," ",text).strip(" -:|•·_")
        _t=re.sub(r"(?i)\s+RAW$","",text)
        if _t.strip():text=_t
        if text==old:break
    return text or str(value or "Channel").strip()

@image_budgeted
def _zap_palette(path):
    if _PILImage is None or not path or not os.path.isfile(str(path)):
        return (52,148,202),(104,210,255)
    try:
        with _PILImage.open(path) as im:
            im=im.convert("RGB"); im.thumbnail((80,80))
            pixels=list(im.getdata())
        useful=list(c for c in pixels if max(c)>42 and (max(c)-min(c))>12)
        if not useful:
            return (52,148,202),(104,210,255)
        useful.sort(key=lambda c:(max(c)-min(c))*1.6+sum(c)/3.0,reverse=True)
        top=useful[:max(8,len(useful)//5)]
        accent=tuple(int(sum(c[i] for c in top)/len(top)) for i in range(3))
        hot=tuple(min(255,int(v*.68+255*.32)) for v in accent)
        return accent,hot
    except Exception:
        return (52,148,202),(104,210,255)

# R5.367: all nine native drawer slots use Poster Grid 3 Spotlight material.
_ZAP_CINEMATIC_SPECS = (
    ("panel", 590, 1080, "spotlight", False),
    ("folder", 358, 46, "spotlight", False),
    ("channel", 358, 38, "spotlight", False),
    ("normal", 554, 52, "spotlight", False),
    ("selected", 554, 52, "spotlight", True),
    ("footer_count", 118, 42, "spotlight", False),
    ("footer_page", 126, 42, "spotlight", False),
    ("footer_play", 126, 42, "spotlight", False),
    ("footer_close", 166, 42, "spotlight", False),
)

def _zap_fixed_master_assets():
    """First paint uses prebuilt Poster Grid 3 Spotlight surfaces."""
    out = {}
    for name, w, h, _source_key, selected in _ZAP_CINEMATIC_SPECS:
        try:
            bundled = os.path.join(os.path.dirname(os.path.dirname(__file__)), "assets_fhd",
                                   "fixed_master_r63", "surfaces",
                                   "live_zap_%s_%dx%d.png" % (name, w, h))
            bundled = _canonical_asset(bundled)
            # Never fall back to the unrelated Settings/fixed row material.
            path = bundled
            if not (path and os.path.isfile(path) and os.path.getsize(path) > 64):
                return {}
            out[name] = path
        except Exception as exc:
            optional_failure("player.zap_cinematic_fixed", exc)
            return {}
    return out


def _zap_resize_master_surface(source, target, size, corner=18):
    """Resize the source Cinematic *pixels* with preserved corners/rims.

    This only adjusts geometry: no new gradient, palette or frame is drawn.
    """
    if _PILImage is None:
        return False
    if os.path.isfile(target) and os.path.getsize(target) > 128:
        return True
    temp = target + ".tmp.%d.%d" % (os.getpid(), __import__(native_str("threading")).get_ident())
    try:
        with _PILImage.open(source) as original:
            src = original.convert("RGBA")
        sw, sh = src.size
        w, h = int(size[0]), int(size[1])
        c = max(6, min(int(corner), sw // 3, sh // 3, w // 3, h // 3))
        output = _PILImage.new("RGBA", (w, h), (0, 0, 0, 0))
        xcuts = ((0, c, 0, c), (c, sw-c, c, w-c), (sw-c, sw, w-c, w))
        ycuts = ((0, c, 0, c), (c, sh-c, c, h-c), (sh-c, sh, h-c, h))
        resample = getattr(getattr(_PILImage, "Resampling", _PILImage), "BILINEAR", 2)
        for sx0, sx1, dx0, dx1 in xcuts:
            for sy0, sy1, dy0, dy1 in ycuts:
                section = src.crop((sx0, sy0, sx1, sy1))
                section = section.resize((max(1, dx1-dx0), max(1, dy1-dy0)), resample)
                output.paste(section, (dx0, dy0))
        output.save(temp, "PNG", optimize=False)
        os.replace(temp, target)
        return True
    except Exception as exc:
        optional_failure("player.zap_cinematic_resize", exc)
        return False
    finally:
        try:
            if os.path.exists(temp): os.unlink(temp)
        except Exception:
            pass


@image_budgeted
def _zap_adaptive_master_assets(picon_path, player_frames=None):
    # Picon remains artwork only; colour authority is the bound Player, never the logo.
    try:
        from ..player_premium_overlays import premium_assets
        specs=tuple((name,w,h,selected) for name,w,h,_key,selected in _ZAP_CINEMATIC_SPECS)
        return premium_assets(specs,player_frames,material=_asset("live_list_premium_r5423/master.png"))
    except Exception as exc:
        optional_failure("player.zap_spotlight_adaptive",exc)
        return {}


# Kept as a stable callable for any legacy importer, but the old adaptive
# glass generator has been removed. Its old cached PNGs are never selected.
def _zap_assets(picon_path=None):
    return _zap_fixed_master_assets()

@image_budgeted
def _fit_zap_picon(path):
    if _PILImage is None or not path or not os.path.isfile(str(path)):
        return path
    try:
        cache=os.path.join(PERSISTENT_GENERATED_DIR,"live_zap_glass")
        secure_private_dir(cache)
        stamp="%s|%s|162x96"%(path,os.path.getmtime(path))
        target=os.path.join(cache,hashlib.sha1(stamp.encode("utf-8","ignore")).hexdigest()[:16]+"_picon.png")
        if os.path.isfile(target) and os.path.getsize(target)>100:return target
        with _PILImage.open(path) as im:
            im=im.convert("RGBA")
            im.thumbnail((154,88),getattr(getattr(_PILImage,"Resampling",_PILImage),"LANCZOS",1))
            canvas=_PILImage.new("RGBA",(162,96),(0,0,0,0))
            x=(162-im.width)//2;y=(96-im.height)//2
            canvas.alpha_composite(im,(x,y))
            tmp=target+".tmp.%d.%d"%(os.getpid(),threading.get_ident())
            try:
                canvas.save(tmp,"PNG");os.replace(tmp,target)
            finally:
                try:
                    if os.path.exists(tmp):os.unlink(tmp)
                except Exception:pass
        return target
    except Exception:
        return path

class UltraStalkerLiveZapList(Screen):
    """One in-player Live browser with two in-place modes.

    R66 keeps the proven drawer and simply swaps its row model:
      channels --BACK/EXIT--> categories --OK--> channels
    No new screen is opened for category browsing, and playback keeps running.
    """
    skin=_wqhd_scale_skin(LIVE_ZAP_SKIN)
    VISIBLE=15

    def __init__(self,session,channels,current_index=0,title="Live Channels",picon_path=None,
                 page_loader=None,page_size=10,total=0,categories=None,current_category_id="",
                 categories_loader=None,category_page_loader=None,clean_titles=True,player_frames=None):
        us_func(Screen.__init__)(self,session)
        self.channels=list(channels or [])
        self.total=max(len(self.channels),int(total or 0))
        if self.total and len(self.channels)<self.total:self.channels.extend([None]*(self.total-len(self.channels)))
        self.cursor=max(0,min(int(current_index or 0),max(0,len(self.channels)-1))) if self.channels else 0
        self.offset=max(0,min(self.cursor,max(0,len(self.channels)-self.VISIBLE)))
        self._channel_cursor=self.cursor;self._channel_offset=self.offset
        self.current_category_id=str(current_category_id or "")
        self.current_category_title=str((_("Live Channels") if title == "Live Channels" else title) or _("Live TV"))
        self.clean_titles=bool(clean_titles)
        self.title_text=_clean_live_name(self.current_category_title,self.clean_titles)
        self.picon_path=_fit_zap_picon(picon_path)
        self.page_loader=page_loader if callable(page_loader) else None
        self.page_size=max(1,int(page_size or 10))
        self.categories=[dict(x) for x in (categories or []) if isinstance(x,dict)]
        self.categories_loader=categories_loader if callable(categories_loader) else None
        self.category_page_loader=category_page_loader if callable(category_page_loader) else None
        self.category_cursor=0;self.category_offset=0
        self.mode="channels"

        self.jobs=queue.Queue();self.loading=False;self._pending_pages=set();self._page_attempts={};self._page_retry_after={};self._render_cache={}
        self._page_futures={};self._channel_generation=0;self._last_move_direction=1
        self.nav_jobs=queue.Queue();self._nav_future=None;self._nav_pending=False;self._nav_generation=0

        self._player_frames=dict(player_frames or {})
        self._zap_use_adaptive = bool(adaptive_enabled())
        self._zap_surface_jobs = queue.Queue()
        self._zap_surface_future = None
        self._zap_surface_pending = False
        self["panel"]=Pixmap();self["folder_bg"]=Pixmap();self["channel_bg"]=Pixmap();self["picon"]=Pixmap()
        self["footer_count_bg"]=Pixmap();self["footer_page_bg"]=Pixmap();self["footer_play_bg"]=Pixmap();self["footer_close_bg"]=Pixmap()
        self["title"]=Label(self.title_text);self["subtitle"]=Label("")
        self["counter"]=Label("");self["footer_page"]=Label(_("◀▶  Page"));self["footer_play"]=Label(_("OK  Play"));self["footer_close"]=Label(_("Back") + "  " + _("Categories"))
        for i in range(self.VISIBLE):
            self["bg%d"%i]=Pixmap();self["num%d"%i]=Label("");self["row%d"%i]=Label("")
        self["actions"]=ActionMap(["OkCancelActions","DirectionActions"],{
            "ok":self.keyOK,"cancel":self._cancel,"up":lambda:self._move(-1),"down":lambda:self._move(1),
            "left":self.page_up,"right":self.page_down,
        },-1000)
        self.timer=eTimer();self.timer_conn=None
        try:self.timer_conn=self.timer.timeout.connect(self._drain)
        except Exception:self.timer.callback.append(self._drain)
        self.onLayoutFinish.append(self._ready);self.onClose.append(self._cleanup)

    @staticmethod
    def _category_id(item):
        if not isinstance(item,dict):return ""
        return str(item.get("id") or item.get("genre_id") or item.get("category_id") or item.get("name") or item.get("title") or "").strip()

    @staticmethod
    def _category_name(item):
        if not isinstance(item,dict):return ""
        value=str(item.get("title") or item.get("name") or item.get("category_name") or item.get("genre_name") or item.get("label") or "").strip()
        try:value=unicodedata.normalize("NFKC",value)
        except Exception:pass
        return value or UltraStalkerLiveZapList._category_id(item) or _("LIVE")

    def _fit_folder_title_font(self):
        """Fit the complete drawer heading without clipping long provider names."""
        try:
            value=str(self.title_text or _("Live TV"))
            units=sum(1.28 if ord(ch)>0x2ff else (0.55 if ch in " ilI1|.,:'" else 1.0) for ch in value)
            size=int(max(14,min(24,round(24.0*min(1.0,20.5/max(1.0,units))))))
            if self["title"].instance is not None:self["title"].instance.setFont(_ultra_rfont("Regular",size))
        except Exception as exc:
            optional_failure("player.zap_folder_font_fit",exc)

    def _set_mode_labels(self):
        if self.mode=="categories":
            self.title_text=_("Categories")
            self["footer_play"].setText("OK  " + _("Open"));self["footer_close"].setText(_("BACK  Close"))
        else:
            self.title_text=_clean_live_name(self.current_category_title or _("Live TV"),self.clean_titles)
            self["footer_play"].setText(_("OK  Play"));self["footer_close"].setText(_("Back") + "  " + _("Categories"))
        self["title"].setText(self.title_text)
        self._fit_folder_title_font()

    def _apply_zap_surface_set(self, assets):
        """Swap pixmaps in the existing nine slots; never overlay the old skin."""
        if not isinstance(assets, dict):
            return False
        required = ("panel", "folder", "channel", "normal", "selected",
                    "footer_count", "footer_page", "footer_play", "footer_close")
        if not all(assets.get(k) and os.path.isfile(assets[k]) for k in required):
            return False
        try:
            for key, name in (("panel", "panel"), ("folder", "folder_bg"),
                              ("channel", "channel_bg"),
                              ("footer_count", "footer_count_bg"),
                              ("footer_page", "footer_page_bg"),
                              ("footer_play", "footer_play_bg"),
                              ("footer_close", "footer_close_bg")):
                self[name].instance.setPixmapFromFile(assets[key])
                self[name].show()
            self.assets = dict(assets)
            us_clear(self._render_cache)
            self._render(force=True)
            return True
        except Exception as exc:
            optional_failure("player.zap_master_apply", exc)
            return False

    def _begin_adaptive_zap_assets(self):
        if not self._zap_use_adaptive:
            return
        jobs = self._zap_surface_jobs
        path = self.picon_path
        try:
            self._zap_surface_pending = True
            future = _PLAYER_BG_EXECUTOR.submit(
                _zap_adaptive_master_assets, path, self._player_frames,
                _task_key="live-zap-spotlight:%s" % hashlib.sha1(
                    str(path).encode("utf-8", "ignore")).hexdigest()[:16]
            )
            self._zap_surface_future = future
            def finished(result):
                try: assets = result.result() or {}
                except Exception: assets = {}
                jobs.put(assets)
            future.add_done_callback(finished)
            self._ensure_timer()
        except Exception as exc:
            self._zap_surface_pending = False
            optional_failure("player.zap_master_schedule", exc)

    def _ready(self):
        self._fit_folder_title_font()
        self.assets = _zap_fixed_master_assets()
        self._apply_zap_surface_set(self.assets)
        try:
            if self.picon_path and os.path.isfile(self.picon_path):
                self["picon"].instance.setPixmapFromFile(self.picon_path)
                self["picon"].show()
            else:
                self["picon"].hide()
        except Exception as exc:
            optional_failure("player.zap_picon", exc)
        self._set_mode_labels()
        self._render(force=True)
        self._load_all()
        self._begin_adaptive_zap_assets()

    def _ensure_timer(self):
        try:
            if not self.timer.isActive():self.timer.start(120,False)
        except Exception:
            try:self.timer.start(120,False)
            except Exception:pass

    def _load_page_for_index(self,index,urgent=False):
        """Load a missing drawer page without ever making a transient miss permanent.

        The channel drawer is a navigation surface, not a catalogue crawler.  A
        temporary empty/failed provider page must therefore remain retryable,
        while the page under the cursor wins over speculative neighbour warm-up.
        """
        if self.mode!="channels" or self.page_loader is None or not self.total:return
        page=max(1,int(index)//self.page_size+1)
        base=(page-1)*self.page_size
        end=min(len(self.channels),base+self.page_size)
        if base<end and all(isinstance(x,dict) for x in self.channels[base:end]):return
        pending=getattr(self,"_pending_pages",set())
        if page in pending:return
        now=time.monotonic()
        retry_after=getattr(self,"_page_retry_after",{})
        ready_at=float(retry_after.get(page,0.0) or 0.0)
        # Even an urgent cursor request respects a tiny anti-hammer window.
        if now<ready_at and (not urgent or ready_at-now>0.20):return
        attempts=getattr(self,"_page_attempts",{})
        attempts[page]=int(attempts.get(page,0) or 0)+1;self._page_attempts=attempts
        pending.add(page);self._pending_pages=pending
        page_loader=self.page_loader;jobs=self.jobs;generation=self._channel_generation
        def worker():
            rows=[];error=None
            try:
                try:rows=page_loader(page)
                except TypeError:rows=page_loader(page,None)
                except Exception as exc:error=exc;rows=[]
                jobs.put((page,[dict(x) for x in (rows or []) if isinstance(x,dict)],generation,error))
            finally:
                jobs.put((-page,[],generation,None))
        future=None
        try:
            # Duplicate suppression keeps rapid remote repeats from queueing the
            # same provider page more than once.
            future=_PLAYER_BG_EXECUTOR.submit(worker,_task_key="live-drawer-page:%s:%s"%(generation,page))
            self._page_futures[page]=future;self._ensure_timer()
        except Exception:
            pending.discard(page);self._page_futures.pop(page,None)
            if future is not None:
                try:future.cancel()
                except Exception:pass

    def _window_pages(self,start,end):
        if end<start:return []
        first=max(1,int(start)//self.page_size+1);last=max(first,int(end)//self.page_size+1)
        return list(range(first,last+1))

    def _warm_visible_pages(self,include_adjacent=True):
        if self.mode!="channels" or self.page_loader is None or not self.channels:return
        total=len(self.channels);last=max(0,total-1)
        # Selected page first, then the rest of the visible window.  Neighbour
        # pages follow the last navigation direction so speculative work can
        # never sit in front of the row the viewer is actually moving onto.
        selected=max(1,int(self.cursor)//self.page_size+1)
        current=self._window_pages(self.offset,min(last,self.offset+self.VISIBLE-1))
        forward_start=self.offset+self.VISIBLE
        backward_start=max(0,self.offset-self.VISIBLE)
        forward=self._window_pages(forward_start,min(last,forward_start+self.VISIBLE-1)) if forward_start<total else []
        backward=self._window_pages(backward_start,min(last,backward_start+self.VISIBLE-1)) if self.offset>0 else []
        ordered=[selected]+[p for p in current if p!=selected]
        if include_adjacent:
            neighbours=(forward+backward) if int(getattr(self,"_last_move_direction",1) or 1)>0 else (backward+forward)
            ordered.extend(neighbours)
        seen=set()
        for page in ordered:
            if page in seen:continue
            seen.add(page)
            self._load_page_for_index((page-1)*self.page_size,urgent=(page==selected))

    def _load_all(self):
        self._warm_visible_pages(include_adjacent=True)

    def _cancel_channel_page_workers(self):
        self._channel_generation+=1
        for future in list(getattr(self,"_page_futures",{}).values()):
            try:future.cancel()
            except Exception:pass
        us_clear(self._page_futures);us_clear(self._pending_pages);us_clear(self._page_attempts);us_clear(self._page_retry_after)

    def _request_categories(self):
        if self.categories or not callable(self.categories_loader) or self._nav_pending:return
        self._nav_generation+=1;generation=self._nav_generation;self._nav_pending=True
        loader=self.categories_loader;jobs=self.nav_jobs
        def worker():
            try:rows=[dict(x) for x in (loader() or []) if isinstance(x,dict)];jobs.put(("categories",generation,rows,None))
            except Exception as exc:jobs.put(("categories",generation,[],exc))
        try:self._nav_future=_PLAYER_BG_EXECUTOR.submit(worker);self._ensure_timer()
        except Exception as exc:
            self._nav_pending=False;optional_failure("player.zap_categories_worker",exc)

    def _make_category_page_loader(self,category_id):
        loader=self.category_page_loader;cid=str(category_id or "")
        if not callable(loader):return None
        def page_loader(page):
            data=loader(cid,page)
            if isinstance(data,dict):return list(dict(x) for x in (data.get("items") or []) if isinstance(x,dict))
            return list(dict(x) for x in (data or []) if isinstance(x,dict))
        return page_loader

    def _request_category_first_page(self,category):
        if not isinstance(category,dict) or not callable(self.category_page_loader):return
        cid=self._category_id(category);title=self._category_name(category)
        if not cid:return
        self._cancel_channel_page_workers()
        self._nav_generation+=1;generation=self._nav_generation;self._nav_pending=True
        self.current_category_id=cid;self.current_category_title=title;self.mode="channels"
        self.channels=[];self.total=0;self.cursor=0;self.offset=0;self._channel_cursor=0;self._channel_offset=0
        self.page_loader=None;us_clear(self._render_cache);self._set_mode_labels();self._render(force=True)
        loader=self.category_page_loader;jobs=self.nav_jobs
        def worker():
            try:
                data=loader(cid,1)
                if isinstance(data,dict):
                    rows=list(dict(x) for x in (data.get("items") or []) if isinstance(x,dict))
                    meta={"items":rows,"page":int(data.get("page") or 1),"page_size":int(data.get("page_size") or len(rows) or 1),"total":int(data.get("total") or len(rows))}
                else:
                    rows=list(dict(x) for x in (data or []) if isinstance(x,dict))
                    meta={"items":rows,"page":1,"page_size":max(1,len(rows)),"total":len(rows)}
                jobs.put(("category_page",generation,cid,title,meta,None))
            except Exception as exc:jobs.put(("category_page",generation,cid,title,{},exc))
        try:self._nav_future=_PLAYER_BG_EXECUTOR.submit(worker);self._ensure_timer()
        except Exception as exc:
            self._nav_pending=False;optional_failure("player.zap_category_worker",exc);self._render(force=True)

    def _drain_nav(self):
        changed=False
        while True:
            try:job=self.nav_jobs.get_nowait()
            except queue.Empty:break
            except Exception:break
            tag=job[0] if job else ""
            generation=job[1] if len(job)>1 else -1
            if generation!=self._nav_generation:continue
            self._nav_pending=False;self._nav_future=None
            if tag=="categories":
                rows=job[2] if len(job)>2 else [];error=job[3] if len(job)>3 else None
                if error:optional_failure("player.zap_categories_load",error)
                self.categories=list(dict(x) for x in (rows or []) if isinstance(x,dict))
                self._select_current_category();changed=True
            elif tag=="category_page":
                cid=job[2] if len(job)>2 else "";title=job[3] if len(job)>3 else "Live Channels"
                meta=job[4] if len(job)>4 and isinstance(job[4],dict) else {};error=job[5] if len(job)>5 else None
                if error:
                    optional_failure("player.zap_category_page_load",error);self.channels=[];self.total=0;self.page_loader=None;changed=True;continue
                rows=list(dict(x) for x in (meta.get("items") or []) if isinstance(x,dict))
                try:page_size=max(1,int(meta.get("page_size") or len(rows) or 1))
                except Exception:page_size=max(1,len(rows) or 1)
                try:total=max(len(rows),int(meta.get("total") or len(rows)))
                except Exception:total=len(rows)
                self.page_size=page_size;self.total=total;self.channels=[None]*total
                for i,row in enumerate(rows):
                    if i<len(self.channels):self.channels[i]=row
                self.page_loader=self._make_category_page_loader(cid)
                self.current_category_id=str(cid);self.current_category_title=str(title or _("Live TV"))
                self.cursor=0;self.offset=0;self._channel_cursor=0;self._channel_offset=0
                us_clear(self._render_cache);self._set_mode_labels();changed=True
                self._warm_visible_pages(include_adjacent=True)
        return changed

    def _drain(self):
        try:
            ready_assets = self._zap_surface_jobs.get_nowait()
            self._zap_surface_pending = False
        except queue.Empty:
            ready_assets = None
        if ready_assets:
            self._apply_zap_surface_set(ready_assets if adaptive_enabled() else _zap_fixed_master_assets())
        nav_changed=self._drain_nav();changed_visible=False
        while True:
            try:job=self.jobs.get_nowait()
            except queue.Empty:break
            if not isinstance(job,(tuple,list)) or len(job)<2:continue
            page,rows=job[:2];generation=job[2] if len(job)>2 else self._channel_generation
            error=job[3] if len(job)>3 else None
            if generation!=self._channel_generation:continue
            if page<0:
                try:self._pending_pages.discard(-page);self._page_futures.pop(-page,None)
                except Exception as exc:optional_failure("player.silent_guard",exc)
                continue
            if page==0:continue
            base=(page-1)*self.page_size
            if rows:
                try:
                    self._page_attempts.pop(page,None);self._page_retry_after.pop(page,None)
                except Exception as exc:optional_failure("player.silent_guard",exc)
            else:
                # A transient provider miss is never frozen into the drawer.
                # Back off gently, then let visible/cursor demand retry it.
                try:
                    attempts=max(1,int(self._page_attempts.get(page,1) or 1))
                    self._page_retry_after[page]=time.monotonic()+min(2.0,0.45*(2**min(2,attempts-1)))
                except Exception:pass
                if error:optional_failure("player.zap_page_load",error)
            for i,row in enumerate(rows):
                pos=base+i
                if 0<=pos<len(self.channels):
                    self.channels[pos]=row
                    if self.mode=="channels" and self.offset<=pos<self.offset+self.VISIBLE:changed_visible=True
        if nav_changed:self._render(force=True)
        elif changed_visible:self._render(force=False)
        if self.mode=="channels" and not getattr(self,"_pending_pages",set()):self._warm_visible_pages(include_adjacent=True)
        if not getattr(self,"_pending_pages",set()) and not self._nav_pending and not self._zap_surface_pending:
            try:self.timer.stop()
            except Exception as exc:optional_failure("player.zap_timer_idle_stop",exc)

    def _name(self,item,index):
        # Missing rows are transient lazy-page state, not real channels.  Keep
        # the drawer visually quiet while the selected page is filled.
        if not isinstance(item,dict):return "…"
        return _clean_live_name(item.get("name") or item.get("title") or (_("Channel %d")%(index+1)),self.clean_titles)

    @staticmethod
    def _row_font_size(value):
        """Adaptive category-row font: preserve the complete name, never ellipsize."""
        text=str(value or "")
        units=sum(1.62 if ord(ch)>0x2ff else (0.56 if ch in " ilI1|.,:'" else 1.0) for ch in text)
        if units<=25:return 22
        if units<=31:return 20
        if units<=38:return 18
        if units<=47:return 16
        if units<=58:return 14
        if units<=70:return 12
        return 10

    def _render(self,force=False):
        is_categories=(self.mode=="categories")
        rows=self.categories if is_categories else self.channels
        total=len(rows)
        item=rows[self.cursor] if 0<=self.cursor<total else None
        if is_categories:
            subtitle=self._category_name(item) if isinstance(item,dict) else (_("Loading categories...") if self._nav_pending else _("No Live categories"))
        else:
            subtitle=self._name(item,self.cursor)[:64] if total else (_("Loading channels...") if self._nav_pending else _("No channels"))
        counter="%d / %d"%(self.cursor+1,total) if total else "0 / 0"
        cache=self._render_cache
        if force or cache.get("subtitle")!=subtitle:
            self["subtitle"].setText(subtitle)
            try:
                units=sum(1.65 if ord(ch)>0x2ff else (0.58 if ch in " ilI1|.,:'" else 1.0) for ch in subtitle)
                size=19 if units<=27 else (17 if units<=34 else (15 if units<=43 else (13 if units<=54 else 11)))
                if self["subtitle"].instance is not None:self["subtitle"].instance.setFont(_ultra_rfont("Regular",size))
            except Exception as exc:optional_failure("player.zap_header_font",exc)
            cache["subtitle"]=subtitle
        if force or cache.get("counter")!=counter:
            self["counter"].setText(counter);cache["counter"]=counter
        normal=(getattr(self,"assets",{}) or {}).get("normal");selected=(getattr(self,"assets",{}) or {}).get("selected")
        for row in range(self.VISIBLE):
            idx=self.offset+row
            if 0<=idx<total:
                if is_categories:
                    label=self._category_name(rows[idx])
                    display=("▶  "+label) if idx==self.cursor and label else label
                    row_font=self._row_font_size(display)
                else:
                    label=self._name(rows[idx],idx)[:45]
                    display=("▶  "+label) if idx==self.cursor and label else label
                    row_font=22
                number=str(idx+1)
            else:
                display="";number="";row_font=22
            bg=selected if idx==self.cursor and idx<total else normal
            state=(self.mode,idx,display,number,bg,row_font)
            if not force and cache.get(("row",row))==state:continue
            self["row%d"%row].setText(display);self["num%d"%row].setText(number)
            try:
                if self["row%d"%row].instance is not None:self["row%d"%row].instance.setFont(_ultra_rfont("Regular",row_font))
            except Exception as exc:optional_failure("player.zap_row_font",exc)
            try:
                if bg and os.path.isfile(bg):self["bg%d"%row].instance.setPixmapFromFile(bg);self["bg%d"%row].show()
                else:self["bg%d"%row].hide()
            except Exception as exc:optional_failure("player.optional_guard",exc)
            cache[("row",row)]=state

    def _move(self,delta):
        rows=self.categories if self.mode=="categories" else self.channels
        if not rows:return
        total=len(rows);old=self.cursor
        self._last_move_direction=1 if int(delta)>0 else -1
        self.cursor=(self.cursor+1)%total if int(delta)>0 else (self.cursor-1)%total
        if self.cursor==0 and old==total-1:self.offset=0
        elif self.cursor==total-1 and old==0:self.offset=max(0,total-self.VISIBLE)
        elif self.cursor<self.offset:self.offset=self.cursor
        elif self.cursor>=self.offset+self.VISIBLE:self.offset=max(0,min(self.cursor-self.VISIBLE+1,total-self.VISIBLE))
        if self.mode=="channels":
            self._channel_cursor=self.cursor;self._channel_offset=self.offset
            self._load_page_for_index(self.cursor,urgent=True);self._warm_visible_pages(include_adjacent=True)
        else:
            self.category_cursor=self.cursor;self.category_offset=self.offset
        # Cache-aware repaint: within the same window only the old/new selected
        # rows plus header/counter change.  Do not rebind all 15 row pixmaps on
        # every remote repeat.
        self._render(force=False)

    def _page_shift(self,direction):
        rows=self.categories if self.mode=="categories" else self.channels
        if not rows:return
        total=len(rows);row=max(0,self.cursor-self.offset);max_offset=max(0,total-self.VISIBLE)
        if int(direction)>0:
            if self.offset>=max_offset:self.cursor=total-1;self.offset=max_offset
            else:self.offset=min(max_offset,self.offset+self.VISIBLE);self.cursor=min(total-1,self.offset+row)
        else:
            if self.offset<=0:self.offset=0;self.cursor=0
            else:self.offset=max(0,self.offset-self.VISIBLE);self.cursor=min(total-1,self.offset+row)
        if self.mode=="channels":
            self._last_move_direction=1 if int(direction)>0 else -1
            self._channel_cursor=self.cursor;self._channel_offset=self.offset
            self._load_page_for_index(self.cursor,urgent=True);self._warm_visible_pages(include_adjacent=True)
        else:
            self.category_cursor=self.cursor;self.category_offset=self.offset
        self._render(force=False)

    def page_up(self):self._page_shift(-1)
    def page_down(self):self._page_shift(1)

    def _select_current_category(self):
        if not self.categories:
            self.cursor=0;self.offset=0;return
        target=str(self.current_category_id or "")
        found=None
        for i,row in enumerate(self.categories):
            if target and self._category_id(row)==target:found=i;break
        if found is None:found=max(0,min(int(self.category_cursor or 0),len(self.categories)-1))
        self.cursor=found;self.offset=max(0,min(found,max(0,len(self.categories)-self.VISIBLE)))
        self.category_cursor=self.cursor;self.category_offset=self.offset

    def _show_categories(self):
        if self.mode=="categories":return
        self._channel_cursor=self.cursor;self._channel_offset=self.offset
        # Any category-page request becomes stale the instant BACK returns to the
        # category model. Existing channel page cache itself stays warm.
        if self._nav_pending:self._nav_generation+=1;self._nav_pending=False
        self.mode="categories";self._select_current_category();us_clear(self._render_cache);self._set_mode_labels()
        if not self.categories:self._request_categories()
        self._render(force=True)

    def _enter_category(self,category):
        if not isinstance(category,dict):return
        cid=self._category_id(category);title=self._category_name(category)
        if not cid:return
        if cid==str(self.current_category_id or "") and self.channels:
            self.mode="channels";self.current_category_title=title or self.current_category_title
            self.cursor=max(0,min(self._channel_cursor,max(0,len(self.channels)-1)))
            self.offset=max(0,min(self._channel_offset,max(0,len(self.channels)-self.VISIBLE)))
            us_clear(self._render_cache);self._set_mode_labels();self._render(force=True);self._warm_visible_pages(include_adjacent=True);return
        self._request_category_first_page(category)

    def keyOK(self):
        if self.mode=="categories":
            if 0<=self.cursor<len(self.categories):self._enter_category(self.categories[self.cursor])
            return
        if 0<=self.cursor<len(self.channels) and isinstance(self.channels[self.cursor],dict):
            self._channel_cursor=self.cursor;self._channel_offset=self.offset
            self.close({
                "type":"channel","index":int(self.cursor),"item":dict(self.channels[self.cursor]),
                "category_id":str(self.current_category_id or ""),"category_title":str(self.current_category_title or _("Live TV")),
                "channels":list(self.channels),"page_size":int(self.page_size or 1),"total":int(self.total or len(self.channels)),
                "categories":[dict(x) for x in (self.categories or []) if isinstance(x,dict)],
            })

    def _cancel(self):
        if self.mode=="channels":self._show_categories()
        else:self.close(None)

    def _cleanup(self):
        try:self.timer.stop()
        except Exception as exc:optional_failure("player.optional_guard",exc)
        future=getattr(self,"_nav_future",None)
        if future is not None:
            try:future.cancel()
            except Exception:pass
        for future in list(getattr(self,"_page_futures",{}).values()):
            try:future.cancel()
            except Exception as exc:optional_failure("player.zap_page_future_cancel",exc)
        try:us_clear(self._page_futures);us_clear(self._pending_pages)
        except Exception:pass
        try:
            if self.timer_conn is not None:self.timer_conn.disconnect()
        except Exception as exc:optional_failure("player.optional_guard",exc)
        try:
            if self._drain in self.timer.callback:self.timer.callback.remove(self._drain)
        except Exception as exc:optional_failure("player.zap_timer_callback_remove",exc)


class UltraInfobarVisibility(object):
    """Ultra Stalker InfoBar visibility policy.

    The Screen itself remains the rendering authority.  This controller owns
    only three pieces of state: whether the bar is visible, how many callers
    are holding it open, and the one-shot hide timer.
    """

    HIDE_DELAY_MS = 10000

    def _us_infobar_delay_ms(self):
        """Info bar timeout from Settings: 0 = Always On, otherwise seconds (default 10)."""
        try:
            sec = int(load_settings().get("infobar_timeout", 10))
        except Exception:
            sec = 10
        if sec not in (0, 3, 6, 10, 15, 30):
            sec = 10
        return sec * 1000

    def __init__(self):
        self._us_infobar_visible = True
        self._us_infobar_hold_depth = 0
        self._us_infobar_skip_toggle_once = False
        self._us_infobar_tracker = ServiceEventTracker(
            screen=self,
            eventmap={iPlayableService.evStart: self.serviceStarted},
        )
        self.hideTimer = eTimer()
        try:
            self.hideTimer_conn = self.hideTimer.timeout.connect(self.doTimerHide)
        except Exception:
            self.hideTimer.callback.append(self.doTimerHide)
        self.onShow.append(self._us_infobar_on_show)
        self.onHide.append(self._us_infobar_on_hide)
        self.startHideTimer()

    def _us_infobar_on_show(self):
        self._us_infobar_visible = True
        self.startHideTimer()

    def _us_infobar_on_hide(self):
        self._us_infobar_visible = False
        try:
            self.hideTimer.stop()
        except Exception:
            pass

    def infobarVisible(self):
        return bool(self._us_infobar_visible)

    def serviceStarted(self):
        # A new service should surface the playback controls just like a fresh
        # player entry, but only while this Screen is the active dialog.
        if getattr(self, "execing", False):
            self.doShow()

    def _us_infobar_modal_hold_active(self):
        """Return True while a Player-owned modal overlay must keep the InfoBar visible.

        The explicit hold depth remains the primary authority.  The subtitle
        flags are also checked directly so a queued Enigma2 hide event cannot
        win a race between stopping the timer and painting the inline picker.
        """
        if int(getattr(self, "_us_infobar_hold_depth", 0) or 0) > 0:
            return True
        if bool(getattr(self, "_subtitle_inline_locked", False)):
            return True
        if bool(getattr(self, "_subtitle_native_selector_hold", False)):
            return True
        if bool(getattr(self, "_server_search_locked", False)):
            return True
        if bool(getattr(self, "_server_search_mode_active", False)):
            return True
        if bool(getattr(self, "_buffer_menu_locked", False)):
            return True
        try:
            overlay = getattr(self, "_subtitle_inline_overlay", None)
            if overlay is not None and bool(getattr(overlay, "active", False)):
                return True
            search_overlay = getattr(self, "_server_search_inline_overlay", None)
            if search_overlay is not None and bool(getattr(search_overlay, "active", False)):
                return True
            buffer_overlay = getattr(self, "_buffer_inline_overlay", None)
            if buffer_overlay is not None and bool(getattr(buffer_overlay, "active", False)):
                return True
        except Exception:
            pass
        return False

    def startHideTimer(self):
        try:
            self.hideTimer.stop()
        except Exception:
            pass
        delay = self._us_infobar_delay_ms()
        if delay > 0 and self._us_infobar_visible and not self._us_infobar_modal_hold_active():
            try:
                self.hideTimer.start(delay, True)
            except Exception:
                pass
        self._us_infobar_skip_toggle_once = False

    def doShow(self):
        try:
            self.hideTimer.stop()
        except Exception:
            pass
        self._us_infobar_visible = True
        self.show()
        self.startHideTimer()

    def doTimerHide(self):
        try:
            self.hideTimer.stop()
        except Exception:
            pass
        # Subtitle selection is modal inside the Player.  Never let an already
        # queued one-shot timer make the picker invisible while it still owns
        # navigation/OK.
        if self._us_infobar_modal_hold_active():
            self._us_infobar_visible = True
            try: us_func(Screen.show)(self)
            except Exception: pass
            return
        if self._us_infobar_visible:
            self._us_infobar_visible = False
            self.hide()

    def _toggle_infobar(self):
        if self._us_infobar_skip_toggle_once:
            self._us_infobar_skip_toggle_once = False
            return
        # Do not allow a second InfoBar action map to hide the Player while a
        # subtitle picker is consuming OK/arrow keys.
        if self._us_infobar_modal_hold_active():
            try:self.hideTimer.stop()
            except Exception:pass
            self._us_infobar_visible = True
            try:us_func(Screen.show)(self)
            except Exception:pass
            return
        if self._us_infobar_visible:
            try:
                self.hideTimer.stop()
            except Exception:
                pass
            self._us_infobar_visible = False
            self.hide()
            return
        self.doShow()

    def OkPressed(self):
        self._toggle_infobar()

    def lockShow(self):
        self._us_infobar_hold_depth += 1
        try:
            self.hideTimer.stop()
        except Exception:
            pass
        if getattr(self, "execing", False) and not self._us_infobar_visible:
            self._us_infobar_visible = True
            self.show()

    def unlockShow(self):
        if self._us_infobar_hold_depth > 0:
            self._us_infobar_hold_depth -= 1
        if getattr(self, "execing", False) and self._us_infobar_visible:
            self.startHideTimer()


_NE_ASSET="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/player/"
# Fix21: the card art has 24 px of transparent glow on every side (visible card = 24..804 x
# 24..344 of the 828x368 image). Position it so the VISIBLE card ends 2 px from the right
# and 2 px from the bottom of the 1920x1080 screen: x = 1920-804-2, y = 1080-344-2. The
# transparent glow margin therefore lies just outside the screen edge and is clipped.
NEXT_EPISODE_SKIN = """
<screen name="UltraStalkerNextEpisodePrompt" position="1114,734" size="828,368" backgroundColor="#ff000000" flags="wfNoBorder">
    <ePixmap position="0,0" size="828,368" pixmap="%(a)snext_ep_card_828x368.png" alphatest="blend" zPosition="1" />
    <widget name="poster" position="52,54" size="170,258" scale="1" alphatest="blend" transparent="1" zPosition="3" />
    <widget name="head" position="252,54" size="522,32" font="Regular;16" halign="left" valign="center" foregroundColor="#e2be6e" backgroundColor="#ff111112" transparent="1" noWrap="1" zPosition="4" />
    <widget name="title" position="252,86" size="522,50" font="Regular;34" halign="left" valign="center" foregroundColor="#ffffff" transparent="1" noWrap="1" zPosition="4" />
    <widget name="episode" position="252,132" size="522,38" font="Regular;22" halign="left" valign="center" foregroundColor="#b0b8c2" transparent="1" noWrap="1" zPosition="4" />
    <widget name="countdown" position="252,176" size="522,38" font="Regular;22" halign="left" valign="center" foregroundColor="#e2be6e" transparent="1" noWrap="1" zPosition="4" />
    <widget name="bar" pixmap="%(a)snext_ep_bar_522x6.png" position="252,236" size="522,6" borderWidth="0" transparent="1" zPosition="3" />
    <widget name="head_dot" pixmap="%(h)s" position="245,232" size="14,14" alphatest="blend" transparent="1" zPosition="5" />
    <widget name="key_play" position="286,274" size="124,38" font="Regular;17" halign="left" valign="center" foregroundColor="#e4e8ec" transparent="1" noWrap="1" zPosition="4" />
    <widget name="key_cancel" position="460,274" size="124,38" font="Regular;17" halign="left" valign="center" foregroundColor="#e4e8ec" transparent="1" noWrap="1" zPosition="4" />
    <widget name="key_off" position="634,274" size="124,38" font="Regular;17" halign="left" valign="center" foregroundColor="#e4e8ec" transparent="1" noWrap="1" zPosition="4" />
</screen>
""" % {"a": _NE_ASSET, "h": _asset("livebar/head_14x14.png")}


class UltraStalkerNextEpisodePrompt(Screen):
    """Next-episode card shown after a natural episode EOF (Player New style).

    Result passed to ``close``: True = play now / countdown finished,
    False = cancel, "session_off" = disable autoplay for this session.
    """

    skin = _wqhd_scale_skin(NEXT_EPISODE_SKIN)
    BAR_W = 522

    def __init__(self, session, next_item, seconds=10, poster="", series_title="", playback_clock=None, playback_controls=None):
        us_func(Screen.__init__)(self, session)
        self.total = max(1, int(seconds or 10))
        self._playback_clock=playback_clock if callable(playback_clock) else None
        self._finished=False
        self._t0 = None
        self._last_remaining = None
        self._poster = str(poster or "")
        item = next_item if isinstance(next_item, dict) else {}
        name = str(item.get("name") or item.get("title") or item.get("episode_name") or "").strip()
        number = item.get("episode") or item.get("number") or item.get("episode_id") or item.get("episode_number") or ""
        series = str(series_title or "").strip() or name or _("Next Episode")
        # V9.2.2-r6: only a real episode name is shown after the number
        # ("01" / "Episode 3" style portal names are not names).
        try:
            from ..episode_labels import episode_name as _real_episode_name
            real_name = _real_episode_name(item)
        except Exception:
            real_name = ""
        if number and real_name and real_name != series:
            episode = _("Episode %s  •  %s") % (number, real_name)
        elif number:
            episode = _("Episode %s") % number
        else:
            episode = real_name if real_name != series else ""
        self._texts = {
            "head": str(_("Next Episode")).upper(),
            "title": series,
            "episode": episode,
            "key_play": _("Play now"),
            "key_cancel": _("Cancel"),
            "key_off": _("Autoplay off"),
        }
        for widget_name in ("head", "title", "episode", "countdown", "key_play", "key_cancel", "key_off"):
            self[widget_name] = Label("")
        self["poster"] = Pixmap()
        self["head_dot"] = Pixmap()
        self["bar"] = ProgressBar()
        self["bar"].setRange((0, 100))
        self["bar"].setValue(0)
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "UltraStalkerPlayerActions"], {
            "ok": self._accept, "green": self._accept,
            "cancel": self._cancel, "red": self._cancel, "stop": self._cancel,
            "yellow": self._disable_session,
        }, -1000)
        if playback_controls:
            self["playback_actions"]=ActionMap(
                ["InfobarSeekActions","UltraStalkerPlayerActions","NumberActions"],dict(playback_controls),-1100)
        self.timer = eTimer()
        self.timer_conn = None
        try:
            self.timer_conn = self.timer.timeout.connect(self._tick)
        except Exception:
            self.timer.callback.append(self._tick)
        self.onLayoutFinish.append(self._start)
        self.onClose.append(self._cleanup_timer)

    # -- text fitting: shrink first, then end with an ellipsis (never wrap) ----
    def _fit(self, name, text, max_w, big, small):
        widget = self[name]
        inst = widget.instance
        text = " ".join(str(text or "").split())
        widget.setText(text)
        if inst is None or not text:
            return
        try:
            inst.setNoWrap(1)
        except Exception:
            pass

        max_w = float(max_w) * _ultra_osd_scale()
        def width(value, size):
            widget.setText(value)
            inst.setFont(_ultra_rfont("Regular", int(size)))
            try:
                return float(inst.calculateSize().width())
            except Exception:
                return 0.0

        for size in range(int(big), int(small) - 1, -1):
            if width(text, size) <= max_w:
                return
        strip = " -–•|,:;"
        lo, hi = 0, len(text)
        while lo < hi:
            mid = (lo + hi + 1) // 2
            if width(text[:mid].rstrip(strip) + "…", small) <= max_w:
                lo = mid
            else:
                hi = mid - 1
        widget.setText((text[:lo].rstrip(strip) + "…") if lo > 0 else "…")

    def _align(self, name, horizontal="left"):
        inst = self[name].instance
        if inst is None:
            return
        try:
            from ..label_align import halign as _h, valign as _v
            inst.setHAlign(_h(horizontal))
            inst.setVAlign(_v("center"))
        except Exception as exc:
            optional_failure("player.next_episode_align", exc)

    def _start(self):
        try:
            rtl = False
            try:
                from ..localization import current_language as _cur_lang
                rtl = str(_cur_lang() or "").lower().split("-")[0] in ("ar", "fa", "he", "ur")
            except Exception:
                rtl = False
            for name in ("head", "title", "episode", "countdown"):
                self._align(name, "right" if rtl else "left")
            for name in ("key_play", "key_cancel", "key_off"):
                self._align(name, "left")
            self._fit("head", self._texts["head"], 522, 16, 12)
            self._fit("title", self._texts["title"], 522, 34, 20)
            self._fit("episode", self._texts["episode"], 522, 22, 14)
            for name in ("key_play", "key_cancel", "key_off"):
                self._fit(name, self._texts[name], 124, 17, 11)
            if self._poster and os.path.isfile(self._poster) and self["poster"].instance is not None:
                self["poster"].instance.setPixmapFromFile(self._poster)
                self["poster"].show()
            else:
                self["poster"].hide()
        except Exception as exc:
            optional_failure("player.next_episode_layout", exc)
        self._t0 = time.monotonic()
        if self._playback_clock is None:self._render(0.0)
        else:self._tick()
        if self._finished:return
        try:
            self.timer.start(200, False)
        except Exception as exc:
            optional_failure("player.optional_guard", exc)

    def _render(self, elapsed):
        remaining = max(0, int(self.total - elapsed + 0.999))
        if remaining != self._last_remaining:
            self._last_remaining = remaining
            self._fit("countdown", _("Next episode starts in %d seconds") % remaining, 522, 22, 14)
        frac = max(0.0, min(1.0, elapsed / float(self.total)))
        try:
            self["bar"].setValue(int(round(frac * 100)))
        except Exception:
            pass
        try:
            inst = self["head_dot"].instance
            if inst is not None:
                from enigma import ePoint
                inst.move(ePoint(*_wqhd_xy(int(252 + frac * self.BAR_W - 7), 232)))
        except Exception:
            pass

    def _tick(self):
        if self._finished:return
        if self._playback_clock is not None:
            try:state=self._playback_clock()
            except Exception:return
            if isinstance(state,str):
                self._finish(state);return
            if not isinstance(state,dict):return
            remaining=max(0.0,min(float(self.total),float(state.get("remaining",self.total))))
            self._render(float(self.total)-remaining)
            if remaining<=0 and not state.get("paused",False):self._accept()
            return
        now=time.monotonic()
        elapsed=now-(self._t0 if self._t0 is not None else now)
        if elapsed>=self.total:
            self._accept();return
        self._render(elapsed)

    def _finish(self,result):
        if self._finished:return
        self._finished=True
        self._cleanup_timer()
        self.close(result)

    def _accept(self):
        self._finish(True)

    def _cancel(self):
        self._finish(False)

    def _disable_session(self):
        self._finish("session_off")

    def _cleanup_timer(self):
        try: self.timer.stop()
        except Exception as exc: optional_failure("player.optional_guard", exc)
        try:
            if self.timer_conn is not None: self.timer_conn.disconnect()
        except Exception as exc: optional_failure("player.optional_guard", exc)
        try:
            if self._tick in self.timer.callback:self.timer.callback.remove(self._tick)
        except Exception as exc:optional_failure("player.optional_guard",exc)
