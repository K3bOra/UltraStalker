# -*- coding: utf-8 -*-
"""Scale the authored Ultra Stalker 1920x1080 UI on WQHD receivers.

Never changes playback media resolution, portaling, stream engines, storage,
or existing user options.  Evaluated at screen creation/import (not per frame).
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str, int, round, max, min, lru_cache
os = _us_env.os
re = _us_env.re

_BASE_W, _BASE_H = 1920, 1080
_WQHD_SWAPS = (
    'pt_card_560x350.png',
    'pt_tile_380x148.png',
    'pt_tile_sel_380x148.png',
    'ultra_bg_clean_1920x1080.png',
    'ultra_bg_flag_1920x1080.png',
    'fixed_master_r63/home_ambient.png',
    'home_hero_fade_1920x1080.png',
    'us194_cinematic_presentation_overlay.png',
    'us88_focus_dim_scrim.png',
    'us78_details_info_scrim.png',
    'us20_player_info_scrim.png',
    'pt_veil_1400x1080.png',
    'cat_scrim_1000x1080.png',
    'wall_epg_seamless_shade_1920x180.png',
    'grid_bottom_bar_1840x64.png',
    'poster_grid2_premium/footer_1872x64.png',
    'grid3_spotlight_panel_glow_590x1020.png',
)

_PIXMAP_PATHS = {}
_FIT_ORIGINS = {}
_IMG_DIMS_CACHE = {}
_WQHD_PIXMAP_CACHE = {}


def register_pixmap_path(ptr, path):
    if ptr is not None and path:
        try:
            if len(_PIXMAP_PATHS) > 1024:
                _PIXMAP_PATHS.clear()
            _PIXMAP_PATHS[id(ptr)] = (ptr, str(path))
        except Exception:
            pass
    return ptr


def register_fit_origin(dst_path, src_path, nine=False):
    if dst_path and src_path:
        try:
            if len(_FIT_ORIGINS) > 1024:
                _FIT_ORIGINS.clear()
            _FIT_ORIGINS[str(dst_path)] = (str(src_path), bool(nine))
        except Exception:
            pass


try:
    from enigma import getDesktop as _enigma_getDesktop
except Exception:
    _enigma_getDesktop = None


@lru_cache(maxsize=1)
def factors():
    try:
        gd = _enigma_getDesktop
        if gd is None:
            from enigma import getDesktop as gd
        sz = gd(0).size()
        w, h = int(sz.width()), int(sz.height())
        # Limit to the supported WQHD target; unchanged on existing FHD boxes.
        if w == 2560 and h == 1440:
            return 4.0 / 3.0, 4.0 / 3.0
    except Exception:
        pass
    return 1.0, 1.0


def xy(x, y):
    sx, sy = factors()
    return int(round(float(x) * sx)), int(round(float(y) * sy))


def wh(w, h):
    sx, sy = factors()
    return max(1, int(round(float(w) * sx))), max(1, int(round(float(h) * sy)))


def font_size(n):
    return max(1, int(round(float(n) * factors()[1])))


def scale_skin(xml):
    sx, sy = factors()
    if sx == 1.0 and sy == 1.0:
        return xml
    xml = str(xml or '')
    # Treat each ePixmap as an image; Enigma2 otherwise clips the original
    # FHD source rather than fitting it to its WQHD-sized rectangle.
    # Pixmap widgets using alphatest and no text/font are likewise pixel art,
    # not labels. Leave every FHD render byte-for-byte unchanged.
    def enable_pixmap_scaling(m):
        tag = m.group(0)
        if re.search(r'\bscale\s*=', tag):
            return tag
        if tag.startswith('<widget'):
            if not re.search(r'\balphatest\s*=', tag):
                return tag
            if re.search(r'\b(?:render|font|text|source)\s*=', tag):
                return tag
        return re.sub(r'/\s*>$', ' scale="1"/>', tag)
    xml = re.sub(r'<(?:ePixmap|widget)\b[^<>]*?/>', enable_pixmap_scaling, xml)
    # Pre-sized static chrome and fullscreen overlays: swap paths inside WQHD
    # skin markup so Enigma2 blits 1:1 without per-frame software blitScale.
    # This is never run when desktop resolution is 1920x1080.
    _base = "/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/"
    _local_base = os.path.dirname(os.path.abspath(__file__)) + "/"
    for name in _WQHD_SWAPS:
        xml = xml.replace(_base + "assets_fhd/" + name,
                          _base + "assets_wqhd/" + name)
        if _local_base != _base:
            xml = xml.replace(_local_base + "assets_fhd/" + name,
                              _local_base + "assets_wqhd/" + name)
    def rect(m):
        x, y = int(m.group(2)), int(m.group(3))
        sc = xy(x, y) if m.group(1) in ('position', 'shadowOffset') else wh(x, y)
        return '%s="%d,%d"' % (m.group(1), sc[0], sc[1])
    xml = re.sub(r'(position|size|shadowOffset)="(-?\d+),(-?\d+)"', rect, xml)
    def font(m):
        n = int(m.group(2))
        return 'font="%s;%d"' % (m.group(1), font_size(n) if n >= 12 else n)
    return re.sub(r'font="([^;]+);\s*(\d+)"', font, xml)


def _image_dims(path):
    hit = _IMG_DIMS_CACHE.get(path)
    if hit is not None:
        return hit
    try:
        from PIL import Image as _PILImg
        with _PILImg.open(path) as im:
            dims = (int(im.size[0]), int(im.size[1]))
    except Exception:
        dims = (0, 0)
    if len(_IMG_DIMS_CACHE) > 512:
        _IMG_DIMS_CACHE.clear()
    _IMG_DIMS_CACHE[path] = dims
    return dims


def _scale_dreamos_multicontent_pixmap(ptr, orig_w, orig_h, target_w, target_h):
    try:
        entry = _PIXMAP_PATHS.get(id(ptr))
        if not entry or entry[0] is not ptr:
            return ptr
        path = entry[1]
        ckey = (path, int(orig_w), int(orig_h), int(target_w), int(target_h))
        cached = _WQHD_PIXMAP_CACHE.get(ckey)
        if cached is not None:
            return cached
        origin = _FIT_ORIGINS.get(path)
        if origin is not None:
            base_path, nine = origin
        else:
            base_path = path
            nine = bool(orig_w >= 64 and orig_h >= 22 and orig_w != orig_h)
        if not base_path or not os.path.isfile(base_path):
            return ptr
        src_w, src_h = _image_dims(base_path)
        low_base = base_path.lower()
        if (src_w > orig_w and orig_h <= 40 and
                any(k in low_base for k in ("pbar", "laser", "fill", "track", "neon"))):
            fit_w, fit_h = wh(src_w, src_h)
            nine = False
        else:
            fit_w, fit_h = int(target_w), int(target_h)
        from .ui_icon_menu import _us_fit_png
        from enigma import loadPNG
        fitted_path = _us_fit_png(base_path, fit_w, fit_h, nine)
        if not fitted_path or not os.path.isfile(fitted_path):
            return ptr
        new_ptr = loadPNG(fitted_path)
        if new_ptr is None:
            return ptr
        if len(_WQHD_PIXMAP_CACHE) > 256:
            _WQHD_PIXMAP_CACHE.clear()
        _WQHD_PIXMAP_CACHE[ckey] = new_ptr
        register_pixmap_path(new_ptr, fitted_path)
        return new_ptr
    except Exception:
        return ptr


def scale_multicontent_row(entries):
    """Scale an FHD MultiContent row into the current OSD resolution.

    Never mutate caller-provided row or scale twice. The data payload in slot
    zero, text flags/font indices and image pointers remain unchanged on FHD.
    """
    sx, sy = factors()
    if sx == 1.0 and sy == 1.0:
        return entries
    pix_types, scale_flag = _pixmap_flags()
    ret = [entries[0]]
    for entry in entries[1:]:
        if not isinstance(entry, tuple) or len(entry) < 5 or not isinstance(entry[0], int):
            ret.append(entry)
            continue
        e = list(entry)
        orig_w, orig_h = int(e[3]), int(e[4])
        e[1] = int(round(e[1] * sx))
        e[2] = int(round(e[2] * sy))
        e[3] = max(1, int(round(orig_w * sx)))
        e[4] = max(1, int(round(orig_h * sy)))
        if e[0] in pix_types:
            if scale_flag and len(e) >= 9:
                e[8] = (e[8] or 0) | scale_flag
            if (not scale_flag or _us_env.IS_DREAMOS) and len(e) >= 6 and e[5] is not None:
                e[5] = _scale_dreamos_multicontent_pixmap(e[5], orig_w, orig_h, e[3], e[4])
        ret.append(tuple(e))
    return ret


def responsive_font(name, px):
    """Runtime font geometry for Enigma2-created labels and fit probes.

    Static XML has already been scaled by scale_skin(). This function must
    only wrap direct Python gFont() calls, never values read from scaled XML.
    The FHD path calls gFont with the original value without any alteration.
    """
    from enigma import gFont
    return gFont(name, font_size(px))


def design_pixels(value):
    """Convert a physical screen dimension back into the authored FHD grid."""
    sx, _ = factors()
    return float(value) / sx


@lru_cache(maxsize=1)
def _pixmap_flags():
    try:
        from enigma import eListboxPythonMultiContent
        pix_types = tuple(
            getattr(eListboxPythonMultiContent, attr)
            for attr in ("TYPE_PIXMAP", "TYPE_PIXMAP_ALPHATEST", "TYPE_PIXMAP_ALPHABLEND")
            if hasattr(eListboxPythonMultiContent, attr)
        )
    except Exception:
        pix_types = ()
    try:
        from enigma import BT_SCALE
    except Exception:
        BT_SCALE = 0
    return (pix_types, BT_SCALE)


_SHARED_PROBE = None
_SHARED_PROBE_FAILED = False


def _get_shared_probe():
    global _SHARED_PROBE, _SHARED_PROBE_FAILED
    if _SHARED_PROBE is not None:
        return _SHARED_PROBE
    if _SHARED_PROBE_FAILED:
        return None
    try:
        from enigma import eLabel
        _SHARED_PROBE = eLabel()
        return _SHARED_PROBE
    except Exception:
        _SHARED_PROBE_FAILED = True
        return None


@lru_cache(maxsize=2048)
def measure_text_width(text, px, font_name="Regular", responsive=True):
    """Measure rendered single-line text width without repeatedly allocating eLabel().

    Cached across calls so scrolling/opening menus never churns C++ eWidget
    allocations on the Enigma2 GUI thread.
    """
    value = str(text or "")
    if not value:
        return 0
    actual_px = font_size(px) if responsive else max(1, int(px))
    try:
        from enigma import gFont
        probe = _get_shared_probe()
        if probe is not None:
            probe.setFont(gFont(font_name, actual_px))
            probe.setText(value)
            w = int(probe.calculateSize().width())
            if w > 0:
                if _us_env.IS_DREAMOS:
                    w += int(2 + 0.25 * float(actual_px))
                return w
    except Exception:
        pass
    units = 0.0
    for ch in value:
        code = ord(ch)
        if 0x0600 <= code <= 0x06ff:
            units += 0.82
        elif ch.isupper():
            units += 0.72
        elif ch.isdigit():
            units += 0.58
        elif ch.isspace():
            units += 0.34
        else:
            units += 0.58
    return max(0, int(units * actual_px))
