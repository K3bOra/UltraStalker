# -*- coding: utf-8 -*-
"""Xtream credentials, live art index, requests, category cache and row normalisation.

Methods moved verbatim out of ``M3UClient`` (m3u_adapter.py); behaviour is unchanged.
This module is imported by m3u_adapter.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, open, max, min, OSError, us_casefold, us_acquire
from .m3u_adapter import LOG, M3UCancelledError, _CACHE_ROOT, _MEM_LOCK, _cat_lru_drop, _cat_lru_get, _cat_lru_put, _ensure_cache_root, _mode_hint_set, _portal_clean_title, _prepare_private_read, _private_replace, _safe_pickle_load, _unique_tmp, diagnostic_failure, hashlib, json, os, pickle, provider_urlopen, re, threading, time, urllib

class M3UXtreamMixin(object):
    """Xtream credentials, live art index, requests, category cache and row normalisation."""

    def _parse_xtream_credentials(self):
        """Extract Xtream-style credentials from a get.php URL without logging secrets."""
        try:
            parsed = urllib.parse.urlsplit(self._normalized_url())
            query = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)
            username = str((query.get('username') or [''])[0] or '')
            password = str((query.get('password') or [''])[0] or '')
            if not username or not password:
                return {}
            path = parsed.path or '/'
            directory = path.rsplit('/', 1)[0] if '/' in path else ''
            base = urllib.parse.urlunsplit((parsed.scheme, parsed.netloc, directory.rstrip('/'), '', '')).rstrip('/')
            if not base:
                base = '%s://%s' % (parsed.scheme, parsed.netloc)
            return {'base': base, 'username': username, 'password': password}
        except Exception:
            return {}

    def _xtream_stream_identity(self, url):
        """Return (kind, stream_id) for a stream URL belonging to this Xtream account.

        This never returns or logs credentials. It is used only to enrich M3U rows
        with metadata from player_api.php while preserving the playlist routing.
        """
        if not self._xtream:
            return ('', '')
        try:
            parts = urllib.parse.urlsplit(str(url or '').strip())
            base = urllib.parse.urlsplit(self._xtream.get('base', ''))
            if not parts.hostname or parts.hostname.lower() != (base.hostname or '').lower():
                return ('', '')
            seg = [urllib.parse.unquote(x) for x in (parts.path or '').split('/') if x]
            if len(seg) < 2:
                return ('', '')
            kind = str(seg[-4] if len(seg) >= 4 else '').lower()
            if kind not in ('live', 'movie', 'series'):
                kind = ''
            tail = seg[-1].rsplit('.', 1)[0].strip()
            if not tail or not tail.isdigit():
                return ('', '')
            return ({'live': 'itv', 'movie': 'vod', 'series': 'series'}.get(kind, kind), tail)
        except Exception:
            return ('', '')

    @staticmethod
    def _live_match_key(value):
        """Conservative channel-name key used only as an artwork fallback.

        Xtream panels sometimes expose a proxy id in get.php while player_api
        returns a different stream_id.  In that case the same channel is still
        identifiable by epg_channel_id or its display name.  Keep Unicode
        letters/digits so Arabic channel names remain matchable.
        """
        text = us_casefold(str(value or '')).strip()
        if not text:
            return ''
        text = re.sub('(?i)\\b(?:uhd|fhd|full[ ._-]?hd|hd|sd|4k|2160p?|1080p?|720p?|576p?|480p?|hevc|h265|h264)\\b', ' ', text)
        text = re.sub('[\\[\\]{}()|:_./\\\\-]+', ' ', text)
        return ' '.join(text.split())

    def _ensure_xtream_live_art_index(self, cancel_event=None):
        while not us_acquire(self._live_art_index_lock, 0.05):
            if cancel_event is not None and cancel_event.is_set():
                return {'sid': {}, 'epg': {}, 'name': {}}
        try:
            if isinstance(self._xtream_live_art_index, dict):
                return self._xtream_live_art_index
            index = {'sid': {}, 'epg': {}, 'name': {}}
            if not self._xtream:
                self._xtream_live_art_index = index
                return index
            try:
                rows = self._xtream_request('get_live_streams', timeout=self.full_timeout, cancel_event=cancel_event, background=True)
                for row in rows if isinstance(rows, list) else []:
                    if not isinstance(row, dict):
                        continue
                    sid = str(row.get('stream_id') or '').strip()
                    epg = us_casefold(str(row.get('epg_channel_id') or row.get('tvg_id') or '').strip())
                    name = self._live_match_key(row.get('name') or row.get('title') or '')
                    if sid:
                        index['sid'][sid] = row
                    if epg:
                        index['epg'].setdefault(epg, []).append(row)
                    if name:
                        index['name'].setdefault(name, []).append(row)
            except Exception as exc:
                LOG.warning('Xtream live artwork index failed: %s', exc)
                self._live_art_index_retry_at = time.monotonic() + 30
                return index
            self._xtream_live_art_index = index
            return index
        finally:
            self._live_art_index_lock.release()

    def _enrich_m3u_live_rows(self, rows, cancel_event=None, cache_only=False):
        if not self._xtream or not isinstance(rows, list):
            return rows
        if cache_only and (not isinstance(self._xtream_live_art_index, dict)):
            return rows
        index = self._ensure_xtream_live_art_index(cancel_event)
        sid_index = index.get('sid', {}) if isinstance(index, dict) else {}
        epg_index = index.get('epg', {}) if isinstance(index, dict) else {}
        name_index = index.get('name', {}) if isinstance(index, dict) else {}
        matched = 0
        for item in rows:
            if not isinstance(item, dict):
                continue
            src = sid_index.get(str(item.get('stream_id') or '').strip()) or {}
            match_by = 'stream_id' if src else ''
            if not src:
                epg = us_casefold(str(item.get('tvg_id') or item.get('epg_channel_id') or '').strip())
                choices = epg_index.get(epg, []) if epg else []
                if len(choices) == 1:
                    src = choices[0]
                    match_by = 'epg_channel_id'
            if not src:
                key = self._live_match_key(item.get('name') or item.get('title') or '')
                choices = name_index.get(key, []) if key else []
                if len(choices) == 1:
                    src = choices[0]
                    match_by = 'channel_name'
            from .provider_art import picon_urls
            icons = picon_urls(item)
            for url in picon_urls(dict(src, _art_base=self._xtream.get('base', ''))):
                if url not in icons:
                    icons.append(url)
            item['_picon_candidates'] = icons[:6]
            icon = icons[0] if icons else ''
            if icon:
                for key in ('logo', 'logo_url', 'picon', 'stream_icon'):
                    item[key] = icon
                if src.get('stream_id') is not None:
                    item['_xtream_stream_id'] = str(src.get('stream_id'))
                item['_xtream'] = True
                item['_xtream_kind'] = 'itv'
                item['_art_base'] = self._xtream.get('base', '')
                matched += 1
                try:
                    LOG.info('M3U live picon matched channel=%r by=%s stream_icon=%r', str(item.get('name') or ''), match_by, icon)
                except Exception as exc:
                    diagnostic_failure('m3u.failsoft', exc)
            else:
                try:
                    LOG.warning('M3U live picon no Xtream match channel=%r stream_id=%r tvg_id=%r', str(item.get('name') or ''), str(item.get('stream_id') or ''), str(item.get('tvg_id') or ''))
                except Exception as exc:
                    diagnostic_failure('m3u.failsoft', exc)
        try:
            LOG.info('M3U live Xtream artwork enrichment matched=%d total=%d', matched, len(rows))
        except Exception as exc:
            diagnostic_failure('m3u.failsoft', exc)
        return rows

    def _schedule_m3u_live_enrichment(self, rows):
        if not rows or not self._xtream:
            return
        from .core.shared_executors import CATALOGUE_EXECUTOR
        with self._live_art_prepare_lock:
            if isinstance(self._xtream_live_art_index, dict):
                self._enrich_m3u_live_rows(rows, cache_only=True)
                return
            if time.monotonic() < getattr(self, '_live_art_index_retry_at', 0):
                return
            previous = getattr(self, '_live_art_future', None)
            if previous is not None and (not previous.done()):
                self._live_art_waiters.append(rows)
                self._live_art_waiters = self._live_art_waiters[-4:]
                return
            event = self._epg_stop
            self._live_art_waiters = [rows]

            def worker():
                self._ensure_xtream_live_art_index(event)
                with self._live_art_prepare_lock:
                    waiters = self._live_art_waiters
                    self._live_art_waiters = []
                    if not event.is_set() and isinstance(self._xtream_live_art_index, dict):
                        for items in waiters:
                            self._enrich_m3u_live_rows(items, event, cache_only=True)
                        all_itv = (getattr(self, '_items', {}) or {}).get('itv')
                        if isinstance(all_itv, list) and all_itv and (not getattr(self, '_m3u_all_itv_enriched', False)):
                            self._m3u_all_itv_enriched = True
                            self._enrich_m3u_live_rows(all_itv, event, cache_only=True)
            self._live_art_future = CATALOGUE_EXECUTOR.submit(worker, _task_key='m3u-logos:%x' % id(self))

    def _ensure_xtream_series_name_index(self, cancel_event=None):
        if isinstance(self._xtream_series_name_index, dict):
            return self._xtream_series_name_index
        index = {}
        if self._xtream:
            try:
                rows = self._xtream_request('get_series', timeout=self.full_timeout, cancel_event=cancel_event)
                for row in rows if isinstance(rows, list) else []:
                    if not isinstance(row, dict):
                        continue
                    name = us_casefold(_portal_clean_title(row.get('name') or '')).strip()
                    if name and name not in index:
                        index[name] = row
            except Exception as exc:
                LOG.warning('Xtream series artwork index failed: %s', exc)
        self._xtream_series_name_index = index
        return index

    def _xtream_url(self, action=None, extra=None):
        if not self._xtream:
            return ''
        params = {'username': self._xtream['username'], 'password': self._xtream['password']}
        if action:
            params['action'] = str(action)
        for key, value in (extra or {}).items():
            if value is not None:
                params[str(key)] = str(value)
        return self._xtream['base'] + '/player_api.php?' + urllib.parse.urlencode(params)

    def _xtream_request(self, action=None, extra=None, timeout=None, cancel_event=None, background=False):
        from .provider_requests import account_gate, Events, ProviderCancelled, ProviderBusyError
        if not self._xtream:
            raise ValueError('Xtream credentials are not available in this M3U URL.')
        event = Events(getattr(self, '_epg_stop', None), cancel_event)
        gate = account_gate(self)
        url = self._xtream_url(action, extra)
        priority = 2 if background or action in ('get_short_epg', 'get_simple_data_table', 'get_vod_info', 'get_series_info') else 0
        epg_request = action in ('get_short_epg', 'get_simple_data_table')
        if epg_request or background:
            gate.raise_if_deferred()
        for attempt in range(2):
            lease = None
            try:
                lease = gate.acquire(event, priority=priority, preemptible=priority > 0, timeout=25)
                lease.event.provider_lease = lease
                return self._xtream_request_locked(action, url, timeout, lease.event)
            except ProviderCancelled as exc:
                raise M3UCancelledError(str(exc))
            except ProviderBusyError as exc:
                gate.defer(exc.retry_after, exc.code)
                if epg_request or background or attempt:
                    raise
            finally:
                if lease is not None:
                    lease.release()

    def _xtream_request_locked(self, action, url, timeout, cancel_event):
        last_exc = None
        for browser in (False, True):
            response = None
            try:
                if cancel_event is not None and cancel_event.is_set():
                    raise M3UCancelledError('Xtream request cancelled')
                headers = self._request_headers(browser=browser, range_prefix=False)
                headers['Accept'] = 'application/json,text/plain,*/*'
                req = urllib.request.Request(url, headers=headers)
                response = self._track_response(provider_urlopen(req, timeout=max(5, int(timeout or self.full_timeout))))
                lease = getattr(cancel_event, 'provider_lease', None)
                if lease is not None:
                    lease.bind(response)
                try:
                    chunks = []
                    total = 0
                    limit = 32 * 1024 * 1024
                    while total < limit:
                        if cancel_event is not None and cancel_event.is_set():
                            raise M3UCancelledError('Xtream request cancelled')
                        chunk = getattr(response, 'read1', response.read)(min(256 * 1024, limit - total))
                        if not chunk:
                            break
                        chunks.append(chunk)
                        total += len(chunk)
                    raw = b''.join(chunks)
                    encoding = str(response.info().get('Content-Encoding') or '')
                finally:
                    self._untrack_response(response)
                    try:
                        response.close()
                    except Exception:
                        pass
                    response = None
                if cancel_event is not None and cancel_event.is_set():
                    raise M3UCancelledError('Xtream request cancelled')
                text = self._decode_body(raw, encoding).strip()
                data = json.loads(text)
                LOG.info('Xtream API action=%s bytes=%s', action or 'account', len(raw))
                return data
            except M3UCancelledError:
                raise
            except urllib.error.HTTPError as exc:
                code = int(getattr(exc, 'code', 0) or 0)
                last_exc = exc
                if code in (429, 469):
                    from .provider_requests import ProviderBusyError, retry_delay
                    delay = retry_delay(getattr(exc, 'headers', None))
                    exc.close()
                    raise ProviderBusyError(code, delay)
                exc.close()
                if code not in (403, 406, 408, 500, 502, 503, 504):
                    break
            except Exception as exc:
                last_exc = exc
            finally:
                if response is not None:
                    self._untrack_response(response)
                    try:
                        response.close()
                    except Exception:
                        pass
        if isinstance(last_exc, urllib.error.HTTPError):
            code = int(getattr(last_exc, 'code', 0) or 0)
            if code in (429, 469):
                raise RuntimeError('The portal is busy (HTTP %s). Wait a moment and open the section again.' % code)
        raise last_exc or RuntimeError('Xtream API request failed')

    def _xtream_probe(self, cancel_event=None):
        if cancel_event is not None and cancel_event.is_set():
            raise M3UCancelledError('Xtream probe cancelled')
        data = self._xtream_request(timeout=max(15, self.probe_timeout), cancel_event=cancel_event)
        if not isinstance(data, dict):
            raise ValueError('Xtream API returned an invalid account response.')
        user = data.get('user_info') if isinstance(data.get('user_info'), dict) else {}
        auth = str(user.get('auth', '')).strip().lower()
        status = str(user.get('status') or '').strip()
        if auth not in ('1', 'true') and status.lower() not in ('active', 'enabled'):
            raise ValueError('Xtream account was not authenticated%s.' % (' (' + status + ')' if status else ''))
        self._xtream_account = data
        self._mode = 'xtream'
        with _MEM_LOCK:
            _mode_hint_set(self._cache_key(), 'xtream')
        self._write_mode_hint('xtream')
        self._last_error = ''
        self._last_success = time.time()
        return {'ok': True, 'mode': 'xtream', 'status': 200}

    def _xtream_stream_url(self, kind, stream_id, extension=''):
        if not self._xtream:
            return ''
        base = self._xtream['base']
        username = urllib.parse.quote(self._xtream['username'], safe='')
        password = urllib.parse.quote(self._xtream['password'], safe='')
        sid = str(stream_id or '')
        ext = str(extension or '').strip().lstrip('.')
        if kind == 'itv':
            ext = ext or 'ts'
            return '%s/live/%s/%s/%s.%s' % (base, username, password, sid, ext)
        if kind == 'vod':
            ext = ext or 'mp4'
            return '%s/movie/%s/%s/%s.%s' % (base, username, password, sid, ext)
        ext = ext or 'mp4'
        return '%s/series/%s/%s/%s.%s' % (base, username, password, sid, ext)

    def _category_rows_to_map(self, rows):
        mapping = {}
        order = []
        for row in rows if isinstance(rows, list) else []:
            if not isinstance(row, dict):
                continue
            cid = str(row.get('category_id') or '')
            name = str(row.get('category_name') or row.get('name') or 'Other').strip() or 'Other'
            if cid:
                mapping[cid] = name
                if name not in order:
                    order.append(name)
        return (mapping, order)

    def _xtream_category_cache_path(self, kind, category_id):
        raw = '%s|%s' % (str(kind or 'itv').lower(), str(category_id or '*'))
        suffix = hashlib.sha1(raw.encode('utf-8', 'ignore')).hexdigest()
        return os.path.join(_CACHE_ROOT, '%s.cat.%s.pkl' % (self._cache_key(), suffix))

    def _read_xtream_category_cache(self, kind, category_id):
        """Return a private copy of the cached rows (callers may mutate it)."""
        rows = self._read_xtream_category_cache_shared(kind, category_id)
        if rows is None:
            return None
        return [dict(x) if isinstance(x, dict) else x for x in rows]

    def _read_xtream_category_cache_shared(self, kind, category_id, accept_legacy=False):
        """Return the cached rows list SHARED with the in-RAM LRU (read-only!).

        Callers must copy any row they keep or mutate.  The LRU is keyed by the
        cache file path and validated against the file signature on each hit, so
        a rewritten cache is never served stale.
        """
        path = self._xtream_category_cache_path(kind, category_id)
        try:
            st = os.stat(path)
            sig = (getattr(st, 'st_mtime_ns', int(st.st_mtime * 1000000000)), st.st_size)
        except OSError:
            _cat_lru_drop(path)
            return None
        hit = _cat_lru_get(path, sig)
        if hit is not None:
            saved = hit[0]
            if saved > 0 and time.time() - saved > 12 * 3600:
                _cat_lru_drop(path)
                return None
            epoch = float(getattr(self, '_xtream_menu_epoch', 0) or 0)
            if epoch and saved and (saved + 1 < epoch):
                _cat_lru_drop(path)
                return None
            if not accept_legacy and str(kind).lower() == 'itv' and (not all(('_picon_candidates' in row for row in hit[1] if isinstance(row, dict)))):
                return None
            return hit[1]
        try:
            if not os.path.isfile(path) or not _prepare_private_read(path):
                return None
            with open(path, 'rb') as f:
                data = _safe_pickle_load(f)
            if not isinstance(data, dict) or int(data.get('schema') or 0) != 1:
                return None
            if not accept_legacy and str(kind).lower() == 'itv' and (data.get('live_art_schema') != 2):
                return None
            rows = data.get('rows')
            if not isinstance(rows, list) or not rows:
                return None
            try:
                saved = float(data.get('saved_at') or 0)
            except (TypeError, ValueError):
                saved = 0.0
            if saved <= 0:
                try:
                    saved = os.path.getmtime(path)
                except OSError:
                    saved = 0.0
            if saved > 0 and time.time() - saved > 12 * 3600:
                return None
            epoch = float(getattr(self, '_xtream_menu_epoch', 0) or 0)
            if epoch and saved and (saved + 1 < epoch):
                return None
            _cat_lru_put(path, sig, saved, rows)
            return rows
        except (OSError, pickle.PickleError, EOFError, TypeError, ValueError) as exc:
            LOG.debug('Xtream category cache read failed %s/%s: %s', kind, category_id, exc)
            return None

    def _write_xtream_category_cache(self, kind, category_id, rows):
        if not isinstance(rows, list):
            return False
        tmp = ''
        try:
            if not _ensure_cache_root():
                return False
            path = self._xtream_category_cache_path(kind, category_id)
            tmp = _unique_tmp(path)
            _cat_lru_drop(path)
            with open(tmp, 'wb') as f:
                pickle.dump({'schema': 1, 'live_art_schema': 2, 'saved_at': int(time.time()), 'rows': rows}, f, protocol=pickle.HIGHEST_PROTOCOL)
                f.flush()
                os.fsync(f.fileno())
            _private_replace(tmp, path)
            _cat_lru_drop(path)
            return True
        except (OSError, pickle.PickleError, TypeError, ValueError) as exc:
            LOG.warning('Xtream category cache write failed %s/%s: %s', kind, category_id, exc)
            try:
                if tmp and os.path.exists(tmp):
                    os.unlink(tmp)
            except OSError:
                pass
            return False

    def _normalise_xtream_rows(self, kind, rows, category_id='', cancel_event=None):
        kind = str(kind or 'itv').lower()
        out = []
        mapping = self._xtream_categories.get(kind, {})
        forced_cid = str(category_id or '')
        for pos, row in enumerate(rows if isinstance(rows, list) else []):
            if cancel_event is not None and cancel_event.is_set():
                return out
            if pos and pos & 63 == 0:
                time.sleep(0)
            if not isinstance(row, dict):
                continue
            cid = str(row.get('category_id') or forced_cid or '')
            group = mapping.get(cid) or str(row.get('category_name') or 'Other')
            if kind == 'itv':
                sid = row.get('stream_id')
                name = str(row.get('name') or 'Channel')
                ext = str(row.get('container_extension') or 'ts')
                from .provider_art import picon_urls
                icons = picon_urls(dict(row, _art_base=self._xtream.get('base', '')))
                icon = icons[0] if icons else ''
                url = self._xtream_stream_url('itv', sid, ext)
                from .receiver_epg import reference_from_row
                out.append({'id': 'xt-live-%s' % sid, 'ch_id': 'xt-live-%s' % sid, 'stream_id': sid, 'name': name, 'title': name, 'number': pos + 1, 'service_ref': reference_from_row(row), '_picon_candidates': icons, 'cmd': url, 'url': url, 'logo': icon, 'logo_url': icon, 'picon': icon, 'stream_icon': icon, 'genre': group, 'category': group, 'category_id': group, '_xtream_category_id': cid, 'tvg_id': str(row.get('epg_channel_id') or ''), 'epg_channel_id': str(row.get('epg_channel_id') or ''), 'allow_archive': row.get('tv_archive') or row.get('archive') or 0, 'tv_archive_duration': row.get('tv_archive_duration') or 0, '_xtream': True, '_xtream_kind': 'itv', '_art_base': self._xtream.get('base', '')})
                continue
            if kind == 'vod':
                sid = row.get('stream_id')
                raw_name = str(row.get('name') or 'Movie')
                name = _portal_clean_title(raw_name) or raw_name
                ext = str(row.get('container_extension') or 'mp4')
                cover = str(row.get('cover_big') or row.get('movie_image') or row.get('cover_tmdb') or row.get('stream_icon') or row.get('cover') or '')
                backdrop = row.get('backdrop_path') or row.get('backdrop') or ''
                if isinstance(backdrop, (list, tuple)):
                    backdrop = backdrop[0] if backdrop else ''
                url = self._xtream_stream_url('vod', sid, ext)
                out.append({'id': 'xt-vod-%s' % sid, 'movie_id': 'xt-vod-%s' % sid, 'stream_id': sid, 'name': name, 'title': name, '_raw_name': raw_name, 'cmd': url, 'url': url, 'logo': cover, 'logo_url': cover, 'cover': cover, 'cover_url': cover, 'poster': cover, 'poster_url': cover, 'backdrop': str(backdrop or ''), 'backdrop_url': str(backdrop or ''), 'genre': group, 'category': group, 'category_id': group, '_xtream_category_id': cid, 'rating': row.get('rating') or row.get('rating_5based') or '', 'year': row.get('year') or row.get('releaseDate') or row.get('release_date') or '', 'tmdb_id': row.get('tmdb_id') or row.get('tmdb') or '', 'imdb_id': row.get('imdb_id') or row.get('imdb') or '', 'plot': row.get('plot') or row.get('description') or '', 'container_extension': ext, '_xtream': True, '_xtream_kind': 'vod', '_art_base': self._xtream.get('base', '')})
                continue
            sid = row.get('series_id')
            raw_name = str(row.get('name') or 'Series')
            name = _portal_clean_title(raw_name) or raw_name
            cover = str(row.get('cover_tmdb') or row.get('cover_big') or row.get('cover') or row.get('stream_icon') or row.get('movie_image') or '')
            backdrop = row.get('backdrop_path') or row.get('backdrop') or ''
            if isinstance(backdrop, (list, tuple)):
                backdrop = backdrop[0] if backdrop else ''
            item = {'id': 'xt-series-%s' % sid, 'series_id': str(sid), 'movie_id': 'xt-series-%s' % sid, 'name': name, 'title': name, '_raw_name': raw_name, 'genre': group, 'category': group, 'category_id': group, '_xtream_category_id': cid, 'logo': cover, 'cover': cover, 'cover_url': cover, 'poster': cover, 'poster_url': cover, 'backdrop': str(backdrop or ''), 'backdrop_url': str(backdrop or ''), 'rating': row.get('rating') or row.get('rating_5based') or '', 'year': row.get('year') or row.get('releaseDate') or row.get('release_date') or '', 'tmdb_id': row.get('tmdb_id') or row.get('tmdb') or '', 'imdb_id': row.get('imdb_id') or row.get('imdb') or '', 'plot': row.get('plot') or '', '_m3u_series': True, '_xtream': True, '_xtream_kind': 'series', '_art_base': self._xtream.get('base', '')}
            out.append(item)
            self._series_index.setdefault(item['id'], {'item': item, 'seasons': {}, 'xtream_series_id': str(sid)})
        return out
