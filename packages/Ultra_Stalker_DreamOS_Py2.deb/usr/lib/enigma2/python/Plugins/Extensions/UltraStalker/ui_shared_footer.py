"""The Poster Grid 3 footer, shared by the six alternate browse views.

Skin preparation owns the bar and keylines. Runtime rebinds keep the native
labels in these same rectangles after page changes and return from playback.
This module performs no artwork generation, disk lookup or network request.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str, int, round, map, max, us_et_fromstring, us_et_tostring
import copy
re = _us_env.re
import xml.etree.ElementTree as ET

_ASSETS = '/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/'
# Bottom bars sit 2 px above the screen edge: the bar PNG has 1 transparent row at each
# end, so a bar at y=1015 ends its visible pixels on row 1077 (rows 1078-1079 stay free).
BAR_Y = 1015
OLD_BAR_Y = 1000
BAR_SHIFT = BAR_Y - OLD_BAR_Y
LABELS = {
    'section': (66, 1027, 520, 40, 20, 'left'),
    'page_label': (1490, 1027, 364, 40, 19, 'right'),
    'red': (644, 1026, 170, 42, 20, 'left'),
    'green': (870, 1026, 170, 42, 20, 'left'),
    'yellow': (1096, 1026, 170, 42, 20, 'left'),
    'blue': (1322, 1026, 170, 42, 20, 'left'),
}
_FOOTER_NAMES = frozenset(LABELS) | {'portal_page', 'check_progress'}


def _footer_nodes():
    nodes = [ET.Element('ePixmap', {
        'position': '40,%d' % BAR_Y, 'size': '1840,64',
        'pixmap': _ASSETS + 'grid_bottom_bar_1840x64.png',
        'alphatest': 'blend', 'zPosition': '24',
    })]
    for name, (x, y, w, h, font, align) in LABELS.items():
        nodes.append(ET.Element('widget', {
            'name': name, 'position': '%d,%d' % (x, y), 'size': '%d,%d' % (w, h),
            'font': 'Regular;%d' % font, 'halign': align, 'valign': 'center',
            'foregroundColor': '#f0ece2' if name in ('section', 'page_label') else '#ffffff',
            'transparent': '1', 'zPosition': '26', 'noWrap': '1',
            'shadowColor': '#000000', 'shadowOffset': '1,1',
        }))
    for name, x in (('red', 586), ('green', 812), ('yellow', 1038), ('blue', 1264)):
        nodes.append(ET.Element('ePixmap', {
            'position': '%d,%d' % (x, LABELS['red'][1]), 'size': '56,42',
            'pixmap': _ASSETS + 'player_keyline_%s_dash_56x42.png' % name,
            'alphatest': 'blend', 'zPosition': '25',
        }))
    return nodes


def _reserve_bottom(root):
    """Keep all existing cards/rows above y=1000, without shrinking posters."""
    screen = root.get('name', '')
    for node in root:
        name = node.get('name', '')
        x, y = map(int, node.get('position', '0,0').split(','))
        w, h = map(int, node.get('size', '1,1').split(','))
        visible = x < 1920 and w > 1 and h > 1
        if not visible:
            continue
        delta = 0
        if screen == 'PremiumLiveGridScreen':
            match = re.fullmatch(r'(?:art|item_title|item_meta|row_adaptive)(\d+)', name)
            if match and int(match.group(1)) < 17:
                delta = -2 * int(match.group(1))
            elif any(n in node.get('pixmap', '') for n in ('us205_live_row_glass.png', 'live_clean_r376/row_748x58.png')):
                delta = -2 * ((y - 8) // 60)
        elif screen == 'PremiumLiveColumnsScreen':
            match = re.search(r'(\d+)$', name)
            if match:
                i = int(match.group(1))
                if 350 <= x < 1060 and i < 17 and 30 <= y - i * 60 < 86:
                    delta = -3 * i
                elif name.startswith('cat_name') and i < 15:
                    delta = -i
            elif any(n in node.get('pixmap', '') for n in ('live3_row_690x56.png', 'live_clean_r376/row_690x56.png')):
                delta = -3 * ((y - 30) // 60)
            if x < 340 and y == 30 and y + h > 1000:
                node.set('size', '%d,%d' % (w, 1000 - y))
                node.set('scale', '1')
        elif screen in ('PremiumBackdropGridScreen', 'PremiumBackdropGrid2Screen'):
            rail_y = 708 if screen == 'PremiumBackdropGridScreen' else 679
            if name == 'status':
                node.set('position', '650,650' if screen == 'PremiumBackdropGridScreen' else '650,615')
            elif y >= rail_y and name not in LABELS:
                delta = -26 if screen == 'PremiumBackdropGridScreen' else -28
        elif screen == 'PremiumGlobalCinematicScreen':
            if name == 'cin_list':
                node.set('size', '%d,840' % w)
            elif x >= 500 and y >= 600 and y < 1000:
                delta = -16
        if delta:
            node.set('position', '%d,%d' % (x, y + delta))


def _shift_node(node, dy):
    x, y = map(int, node.get('position', '0,0').split(','))
    node.set('position', '%d,%d' % (x, y + dy))


def lower_existing_footer(xml):
    """Move a skin that already carries the grid bar down to BAR_Y (idempotent).

    Only the bar, its keylines and its labels move; everything above stays put.
    """
    root = us_et_fromstring(xml)
    bar = list(n for n in root if n.get('pixmap', '').endswith('grid_bottom_bar_1840x64.png'))
    if not bar:
        return xml
    if all(int(n.get('position', '0,0').split(',')[1]) >= BAR_Y for n in bar):
        return xml
    for node in root:
        pixmap = node.get('pixmap', '')
        is_footer = (node in bar or node.get('name', '') in _FOOTER_NAMES
                     or any(pixmap.endswith('player_keyline_%s_dash_56x42.png' % c) for c in ('red', 'green', 'yellow', 'blue')))
        if not is_footer:
            continue
        x, y = map(int, node.get('position', '0,0').split(','))
        if OLD_BAR_Y <= y < OLD_BAR_Y + 64:
            _shift_node(node, BAR_SHIFT)
    return us_et_tostring(root)


def lower_poster_v2_footer(xml):
    """Poster Grid V2 bar: its PNG is opaque to the last row, so it moves 1016 -> 1014 (2 px free)."""
    root = us_et_fromstring(xml)
    bar = list(n for n in root if n.get('pixmap', '').endswith('poster_grid2_premium/footer_1872x64.png'))
    if not bar or all(int(n.get('position', '0,0').split(',')[1]) <= 1014 for n in bar):
        return xml
    names = frozenset(('section', 'page_label', 'red', 'green', 'yellow', 'blue'))
    for node in root:
        pixmap = node.get('pixmap', '')
        is_footer = (node in bar or node.get('name', '') in names
                     or any(pixmap.endswith('player_keyline_%s_dash_56x42.png' % c) for c in ('red', 'green', 'yellow', 'blue')))
        if not is_footer:
            continue
        x, y = map(int, node.get('position', '0,0').split(','))
        if 1016 <= y < 1080:
            _shift_node(node, -2 if node in bar else -2)
    return us_et_tostring(root)


def shared_footer_skin(xml):
    root = us_et_fromstring(xml)
    # Re-running a preparation step must not re-space rows or duplicate a bar.
    if any(node.get('pixmap', '').endswith('grid_bottom_bar_1840x64.png') for node in root):
        return lower_existing_footer(xml)
    _reserve_bottom(root)
    for node in list(root):
        name = node.get('name', '')
        pixmap = node.get('pixmap', '')
        if name in LABELS or any(pixmap.endswith('player_keyline_%s_dash_56x42.png' % color) for color in ('red', 'green', 'yellow', 'blue')):
            root.remove(node)
        elif name == 'page_label_bg':
            node.set('position', '2000,0'); node.set('size', '1,1')
        elif root.get('name') == 'PremiumLiveWallScreen' and name == 'status':
            node.set('position', '66,154'); node.set('size', '800,24')
    for node in _footer_nodes():
        root.append(copy.deepcopy(node))
    return us_et_tostring(root)


def apply_footer_geometry(screen):
    if not getattr(screen, 'shared_footer', False):
        return
    sx = float(getattr(screen, '_grid_sx', 1.0) or 1.0)
    sy = float(getattr(screen, '_grid_sy', 1.0) or 1.0)
    try:
        geom_sig = (sx, sy, tuple(id(screen[name].instance) for name in LABELS))
    except Exception:
        geom_sig = None
    if geom_sig is None or getattr(screen, '_shared_footer_geom_sig', None) != geom_sig:
        from enigma import ePoint, eSize, gFont
        all_ready = True
        for name, (x, y, w, h, font, align) in LABELS.items():
            inst = screen[name].instance
            if inst is None:
                all_ready = False
                continue
            inst.move(ePoint(int(round(x * sx)), int(round(y * sy))))
            inst.resize(eSize(int(round(w * sx)), int(round(h * sy))))
            inst.setFont(gFont('Regular', max(1, int(round(font * sy)))))
        if all_ready and geom_sig is not None:
            screen._shared_footer_geom_sig = geom_sig
    sec_text = str(screen.category_title or '')
    try:
        if str(screen['section'].getText() or '') != sec_text:
            screen['section'].setText(sec_text)
    except Exception:
        screen['section'].setText(sec_text)
