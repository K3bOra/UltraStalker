# -*- coding: utf-8 -*-
"""Poll interval and HDD polling.

Methods moved verbatim out of ``PremiumGlobalCinematicScreen`` (ui_cinematic_global.py); behaviour is unchanged.
This module is imported by ui_cinematic_global.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import int, max
from .ui_cinematic_global import (
    optional_failure,
    time,
)


class CinePollMixin(object):
    """Poll interval and HDD polling."""

    def _cin_set_poll_interval(self,interval_ms,force=False):
        if self._screen_closed:return
        try:
            requested=int(interval_ms or 0)
            if requested<=0:
                self._cin_poll.stop();self._cin_poll_interval=0;return
            interval=max(80,requested)
            if not force and int(getattr(self,"_cin_poll_interval",0) or 0)==interval:return
            self._cin_poll.stop();self._cin_poll_interval=interval;self._cin_poll.start(interval,False)
        except Exception as exc:optional_failure("cinematic.poll_interval",exc)

    def _cin_poll_has_pending_work(self):
        if self._screen_closed:return False
        try:
            if not self._cin_jobs.empty():return True
        except Exception:pass
        # Stage 9: adaptive visual work is a first-class delivery source.  The
        # old poller ignored it, allowing a completed current-title adaptive to
        # remain stranded in _cin_jobs until some unrelated later event.
        try:
            if getattr(self,"_cin_pending",None):return True
        except Exception:pass
        visual_future=getattr(self,"_cin_visual_future",None)
        try:
            if visual_future is not None and not visual_future.done():return True
        except Exception:return True
        for future in (getattr(self,"_cin_fast_info_future",None),getattr(self,"_cin_focus_future",None),getattr(self,"_cin_background_future",None)):
            try:
                if future is not None and not future.done():return True
            except Exception:return True
        if getattr(self,"_cin_logo_pending",None):return True
        if getattr(self,"_fast_bd_meta_pending",None) or getattr(self,"_fast_bd_inflight",False):return True
        # Backdrop Grid 1/2 reuse this poller for their page-local adaptive HUD
        # and selector workers.  Keep delivery alive only while those jobs exist.
        if getattr(self,"_bd_hud_pending",None):return True
        if getattr(self,"_grid_accent_pending",None):return True
        try:
            if hasattr(self,"_bd_hud_jobs") and not self._bd_hud_jobs.empty():return True
        except Exception:pass
        return bool(self._async_poll_has_pending_work())

    def _cin_kick_poll(self):
        try:self._cin_set_poll_interval(100)
        except Exception:pass

    def _cin_poll_hdd(self):
        # Queue delivery only. No HDD scans, visible-row refresh, missed-title
        # recovery, prefetch or speculative work is permitted in the poll loop.
        if self._screen_closed:return
        try:
            quiet=max(0.0,time.monotonic()-float(getattr(self,"_cin_last_nav_at",0.0) or 0.0))
            if quiet < 0.16:
                self._cin_set_poll_interval(100,force=True)
                return
        except Exception:
            return
        self._cin_drain_jobs()
        self._cin_set_poll_interval(120 if self._cin_poll_has_pending_work() else 0)
