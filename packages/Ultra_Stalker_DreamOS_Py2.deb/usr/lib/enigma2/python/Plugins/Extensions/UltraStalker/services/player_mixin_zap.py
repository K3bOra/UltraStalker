# -*- coding: utf-8 -*-
"""Live zap list, channel switching and stream type toggle.

Methods moved verbatim out of ``UltraStalkerPlayer`` (player_native.py); behaviour is unchanged.
This module is imported by player_native.py once its module-level helpers exist, so the
names below are taken from that module (partially initialised at this point) on purpose.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from ..us_env import str, int, max, min, us_clear, us_func
from .player_native import (
    Screen,
    UltraInfobarVisibility,
    UltraStalkerLiveZapList,
    _,
    _PLAYER_BG_EXECUTOR,
    _asset,
    _cached_poster,
    _clean_live_name,
    _engine_label,
    _fallback_player_frames,
    force_session_silence,
    optional_failure,
    queue,
    time,
)


class PlayerZapMixin(object):
    """Live zap list, channel switching and stream type toggle."""

    def toggleStreamType(self):
        from .. import us_env as _us_env
        from ..storage import save_settings
        if _us_env.IS_DREAMOS:
            pool = [8193, 4097, 1] if self.media_type in ("itv", "live") else [8193, 4097]
            if _us_env.os.path.exists("/usr/bin/gstplayer") and 5001 not in pool: pool.append(5001)
            if _us_env.os.path.exists("/usr/bin/exteplayer3") and 5002 not in pool: pool.append(5002)
        else:
            pool = [4097, 5002, 5001, 8193, 1] if self.media_type in ("itv", "live") else [4097, 5002, 5001, 8193]
        try:cur = int(self.servicetype or 4097)
        except Exception:cur = 4097
        nxt = pool[(pool.index(cur) + 1) % len(pool)] if cur in pool else pool[0]
        self._cfg_service_type = nxt
        self.servicetype = nxt
        self.engines = [nxt]
        try:save_settings({"service_type": int(nxt)})
        except Exception:pass
        try:self["engine"].setText(_engine_label(nxt))
        except Exception:pass
        self["connection"].setText(_("ENGINE  •  %s") % _engine_label(nxt))
        try:self.doShow()
        except Exception as exc:optional_failure("player.optional_guard",exc)
        try:self.restartStream()
        except Exception as exc:optional_failure("player.toggle_engine_restart",exc)

    def hide(self):
        """Never let receiver InfoBar plumbing hide an active subtitle workflow.

        This is deliberately the last visibility authority: some Enigma2 images
        can call Screen.hide() through their own InfoBar mixins even after our
        one-shot timer has been stopped.  Playback close/restore always wins.
        """
        if not self.restored and not self._closing_playback:
            try:
                if us_func(UltraInfobarVisibility._us_infobar_modal_hold_active)(self):
                    try:self.hideTimer.stop()
                    except Exception:pass
                    self._us_infobar_visible=True
                    try:us_func(Screen.show)(self)
                    except Exception:pass
                    return
            except Exception as exc:
                optional_failure("player.subtitle_visibility_guard",exc)
        return us_func(Screen.hide)(self)

    def _infobar_is_shown(self):
        try:
            return bool(self.infobarVisible())
        except Exception:
            return False

    def OKButton(self):
        if self.media_type in ("itv","live") and self._zap_channels:
            # First OK is always reserved for the InfoBar. Only a subsequent OK
            # while that InfoBar is actually visible opens the channel drawer.
            if (not self._zap_infobar_armed) or (not self._infobar_is_shown()):
                self._zap_infobar_armed=True
                try:self.doShow()
                except Exception:us_func(UltraInfobarVisibility.OkPressed)(self)
                return
            self._zap_infobar_armed=False
            self._openZapList()
            return
        us_func(UltraInfobarVisibility.OkPressed)(self)

    def _openZapList(self):
        if self._zap_open or self.media_type not in ("itv","live") or not self._zap_channels:
            return
        self._zap_open=True
        try:self.hideTimer.stop()
        except Exception as exc:optional_failure("player.optional_guard",exc)
        channels=list(self._zap_channels)
        current_row=None
        try:
            if 0<=int(self._zap_index)<len(channels) and isinstance(channels[int(self._zap_index)],dict):
                current_row=channels[int(self._zap_index)]
        except Exception:
            current_row=None
        picon=_cached_poster(current_row or self.item,self.name,self.media_type)
        if self._zap_total>len(channels):channels.extend([None]*(self._zap_total-len(channels)))

        client=self.item.get("_live_client_ref")
        categories=list(getattr(self,"_zap_categories",[]) or [])
        def categories_loader():
            if categories:return [dict(x) for x in categories if isinstance(x,dict)]
            if client is None:return []
            return self._visible_live_categories(client.genres("itv") or [])
        def category_page_loader(category_id,page):
            if client is None:return {"items":[],"page":int(page or 1),"page_size":max(1,int(self._zap_page_size or 1)),"total":0}
            return client.ordered_page("itv",str(category_id or "*"),int(page or 1)) or {}
        try:
            self.session.openWithCallback(
                self._onZapSelected, UltraStalkerLiveZapList, channels, self._zap_index,
                self._zap_title, picon, self._zap_page_loader, self._zap_page_size, self._zap_total,
                categories, self._zap_category_id, categories_loader, category_page_loader, self._cfg_clean_titles,
                player_frames=dict(getattr(self,"_player_chrome_frames",{}) or _fallback_player_frames())
            )
        except Exception as exc:
            self._zap_open=False
            optional_failure("player.open_zap_list",exc)
            try:self.doShow()
            except Exception as exc:optional_failure("player.optional_guard",exc)

    def _recent_live_context_tick(self):
        loader=self.item.get("_recent_live_context_loader")
        if not callable(loader) or self.media_type not in ("itv","live") or not self.started:return
        pending=getattr(self,"_recent_live_context_future",None)
        if not getattr(self,"_recent_live_context_started",False):
            self._recent_live_context_started=True
            try:
                pending=(self._play_generation,getattr(self,"_zap_switch_generation",0),_PLAYER_BG_EXECUTOR.submit(loader,self._recent_next_cancel))
                self._recent_live_context_future=pending
            except Exception as exc:optional_failure("player.recent_live_context_start",exc)
        if not pending or not pending[-1].done():return
        self._recent_live_context_future=None
        if pending[0]!=self._play_generation or (len(pending)>2 and pending[1]!=getattr(self,"_zap_switch_generation",0)):return
        pending=(pending[0],pending[-1])
        try:context=pending[1].result()
        except Exception as exc:
            optional_failure("player.recent_live_context_result",exc);return
        if not isinstance(context,dict):return
        size=max(1,int(context["page_size"]));total=max(1,int(context["total"]))
        channels=[None]*total;base=(int(context["page"])-1)*size
        for index,row in enumerate(context["channels"]):
            if 0<=base+index<total:channels[base+index]=row
        self._zap_channels=channels;self._zap_total=total;self._zap_page_size=size
        self._zap_index=int(context["absolute_index"])

    def _visible_live_categories(self,rows):
        """Drop the folders the user hid in Settings (the 'All' row stays)."""
        out=[dict(x) for x in (rows or []) if isinstance(x,dict)]
        try:
            hidden=set(str(v) for v in ((self.item or {}).get("_hidden_live_category_ids") or []) if str(v).strip())
        except Exception:
            hidden=set()
        if not hidden:return out
        def _cid(e):return str(e.get("id") or e.get("genre_id") or e.get("category_id") or e.get("name") or e.get("title") or "").strip()
        return list(e for e in out if _cid(e) not in hidden)

    def _onZapSelected(self,result=None):
        self._zap_open=False
        self._zap_infobar_armed=False
        if not result:
            try:self.doShow()
            except Exception as exc:optional_failure("player.optional_guard",exc)
            return
        context=None
        if isinstance(result,dict):
            try:index=int(result.get("index") or 0);item=result.get("item")
            except Exception:return
            if not isinstance(item,dict):return
            context=dict(result)
        else:
            try:index,item=result
            except Exception:return
        self._zap_pending_drawer_context=context
        self._switchChannel(index,item)

    def _quickZap(self,delta):
        """Switch previous/next Live channel without opening the drawer."""
        if self.media_type not in ("itv","live") or self._zap_open:
            return
        # Inline pickers own their arrows until they close, whichever zap axis is chosen.
        if any(bool(getattr(self, name, False)) for name in (
                "_subtitle_inline_locked", "_subtitle_native_selector_hold",
                "_server_search_locked", "_buffer_menu_locked", "_resume_prompt_open")):
            return
        total=max(int(getattr(self,"_zap_total",0) or 0),len(getattr(self,"_zap_channels",[]) or []))
        if total<=1:
            return
        if self._zap_switch_inflight:
            return
        step=-1 if int(delta or 0)<0 else 1
        target=(int(getattr(self,"_zap_index",0) or 0)+step)%total
        self._zap_infobar_armed=False
        channels=getattr(self,"_zap_channels",[]) or []
        row=channels[target] if 0<=target<len(channels) else None
        if isinstance(row,dict):
            self._switchChannel(target,row)
            return
        self._switchChannelByIndex(target)

    def _switchChannelByIndex(self,index):
        """Resolve an unloaded folder row lazily, then reuse the normal zap path."""
        client=self.item.get("_live_client_ref")
        if client is None:
            self["connection"].setText(_("CHANNEL SWITCH UNAVAILABLE"))
            return
        if self._zap_switch_inflight:
            return
        total=max(int(getattr(self,"_zap_total",0) or 0),len(getattr(self,"_zap_channels",[]) or []))
        if total<=0:
            return
        index=max(0,min(int(index),total-1))
        self._zap_pending_drawer_context=None
        self._zap_switch_context=None
        self._zap_switch_generation+=1
        generation=self._zap_switch_generation
        self._zap_switch_inflight=True
        self._zap_switch_started_at=time.monotonic()
        self["connection"].setText(_("SWITCHING CHANNEL..."))
        page_loader=self._zap_page_loader
        page_size=max(1,int(self._zap_page_size or 1))
        channels=getattr(self,"_zap_channels",[]) or []
        cached=channels[index] if 0<=index<len(channels) and isinstance(channels[index],dict) else None
        result_queue=self._zap_switch_queue
        def worker():
            page=0;rows=[];item=dict(cached) if isinstance(cached,dict) else None
            try:
                if item is None and callable(page_loader):
                    page=max(1,index//page_size+1)
                    try:loaded=page_loader(page)
                    except TypeError:loaded=page_loader(page,None)
                    rows=[dict(x) for x in (loaded or []) if isinstance(x,dict)]
                    base=(page-1)*page_size
                    rel=index-base
                    if 0<=rel<len(rows):item=dict(rows[rel])
                if not isinstance(item,dict):
                    raise ValueError("target channel row unavailable")
                url=client.create_link(item,"itv")
                result_queue.put((generation,index,item,str(url or ""),None,page,rows))
            except Exception as exc:
                result_queue.put((generation,index,item or {},"",exc,page,rows))
        try:
            self._zap_switch_future=_PLAYER_BG_EXECUTOR.submit(worker)
            self.zap_switch_timer.start(120,False)
        except Exception as exc:
            self._zap_switch_generation+=1;self._zap_switch_inflight=False;self._zap_switch_started_at=0.0
            future=getattr(self,"_zap_switch_future",None)
            if future is not None:
                try:future.cancel()
                except Exception:pass
            self._zap_switch_future=None
            optional_failure("player.quick_zap_worker_start",exc)
            self["connection"].setText(_("CHANNEL SWITCH FAILED"))

    def _switchChannel(self,index,item):
        if not isinstance(item,dict):
            return
        client=self.item.get("_live_client_ref")
        if client is None:
            self["connection"].setText(_("CHANNEL SWITCH UNAVAILABLE"))
            try:self.doShow()
            except Exception as exc:optional_failure("player.optional_guard",exc)
            return
        if self._zap_switch_inflight:
            self["connection"].setText(_("CHANNEL SWITCH IN PROGRESS..."))
            return
        self._zap_switch_generation += 1
        generation=self._zap_switch_generation
        drawer_context=getattr(self,"_zap_pending_drawer_context",None)
        self._zap_pending_drawer_context=None
        self._zap_switch_context=(generation,drawer_context) if isinstance(drawer_context,dict) else None
        self._zap_switch_inflight=True
        self._zap_switch_started_at=time.monotonic()
        self["connection"].setText(_("SWITCHING CHANNEL..."))
        result_queue=self._zap_switch_queue
        item_snapshot=dict(item)
        def worker():
            try:
                url=client.create_link(item_snapshot,"itv")
                result_queue.put((generation,index,item_snapshot,str(url or ""),None))
            except Exception as exc:
                result_queue.put((generation,index,item_snapshot,"",exc))
        try:
            self._zap_switch_future=_PLAYER_BG_EXECUTOR.submit(worker)
            self.zap_switch_timer.start(120,False)
        except Exception as exc:
            self._zap_switch_generation+=1;self._zap_switch_inflight=False;self._zap_switch_started_at=0.0
            future=getattr(self,"_zap_switch_future",None)
            if future is not None:
                try:future.cancel()
                except Exception:pass
            self._zap_switch_future=None
            optional_failure("player.zap_worker_start",exc)
            self["connection"].setText(_("CHANNEL SWITCH FAILED"))

    def _drain_zap_switch_result(self):
        if self.restored or self._closing_playback:
            try:self.zap_switch_timer.stop()
            except Exception as exc:optional_failure("player.optional_guard",exc)
            return
        try:
            result=self._zap_switch_queue.get_nowait()
            generation,index,item,url,error=result[:5]
            loaded_page=(result[5] if len(result)>5 else 0)
            loaded_rows=(result[6] if len(result)>6 else [])
        except queue.Empty:
            # A pathological portal/library call must not leave channel switching
            # permanently locked. Invalidate the generation; a late worker result
            # will be ignored safely.
            try:timeout=self._cfg_timeout
            except Exception:timeout=15.0
            if self._zap_switch_inflight and self._zap_switch_started_at and time.monotonic()-self._zap_switch_started_at>timeout:
                self._zap_switch_generation+=1;self._zap_switch_inflight=False;self._zap_switch_started_at=0.0
                self._zap_switch_context=None;self._zap_pending_drawer_context=None
                try:self.zap_switch_timer.stop()
                except Exception as exc:optional_failure("player.optional_guard",exc)
                self["connection"].setText(_("CHANNEL SWITCH TIMED OUT"))
                try:self.doShow()
                except Exception as exc:optional_failure("player.optional_guard",exc)
            return
        if generation != self._zap_switch_generation:
            return
        self._zap_switch_future=None
        # Quick-zap may have lazily fetched the target portal page. Merge those
        # rows into the player folder snapshot on the GUI thread so subsequent
        # UP/DOWN presses are instant and the drawer sees the same warmed data.
        if loaded_page and loaded_rows:
            try:
                base=(int(loaded_page)-1)*max(1,int(self._zap_page_size or 1))
                if len(self._zap_channels)<self._zap_total:self._zap_channels.extend([None]*(self._zap_total-len(self._zap_channels)))
                for pos,row in enumerate(loaded_rows):
                    absolute=base+pos
                    if 0<=absolute<len(self._zap_channels) and isinstance(row,dict):self._zap_channels[absolute]=row
            except Exception as exc:optional_failure("player.quick_zap_merge_page",exc)
        self._zap_switch_inflight=False
        self._zap_switch_started_at=0.0
        try:self.zap_switch_timer.stop()
        except Exception as exc:optional_failure("player.optional_guard",exc)
        if error or not url:
            if getattr(self,"_zap_switch_context",None) and self._zap_switch_context[0]==generation:self._zap_switch_context=None
            self["connection"].setText(_("CHANNEL SWITCH FAILED"))
            try:self.doShow()
            except Exception as exc:optional_failure("player.optional_guard",exc)
            return

        # R66: a channel selected from a different in-player category becomes
        # the new authoritative drawer context only after its link was resolved
        # successfully. A failed zap therefore never strands the viewer in a
        # category/channel snapshot that is not actually playing.
        switch_context=getattr(self,"_zap_switch_context",None)
        context=(switch_context[1] if switch_context and switch_context[0]==generation and isinstance(switch_context[1],dict) else None)
        self._zap_switch_context=None
        if context is not None:
            try:
                category_id=str(context.get("category_id") or "")
                category_title=str(context.get("category_title") or _("Live TV"))
                channels=list(context.get("channels") or [])
                page_size=max(1,int(context.get("page_size") or self._zap_page_size or 1))
                total=max(len(channels),int(context.get("total") or len(channels)))
                if total and len(channels)<total:channels.extend([None]*(total-len(channels)))
                self._zap_category_id=category_id
                self._zap_title=category_title
                if isinstance(context.get("categories"),list):
                    self._zap_categories=list(dict(x) for x in context.get("categories") if isinstance(x,dict))
                self._zap_channels=channels
                self._zap_page_size=page_size
                self._zap_total=total
                client=self.item.get("_live_client_ref")
                if client is not None and category_id:
                    def _category_page(page,_client=client,_category=category_id):
                        data=_client.ordered_page("itv",_category,int(page or 1)) or {}
                        return list(dict(x) for x in (data.get("items") or []) if isinstance(x,dict)) if isinstance(data,dict) else list(dict(x) for x in (data or []) if isinstance(x,dict))
                    self._zap_page_loader=_category_page
                self.item["_live_category_id"]=category_id
                self.item["_live_folder_title"]=category_title
                self.item["_live_folder_total"]=total
                self.item["_live_page_size"]=page_size
            except Exception as exc:
                optional_failure("player.zap_category_context",exc)

        old_url=self.streamurl
        self._suppress_service_events(1.25)
        try:force_session_silence(self.session,old_url,force=True,stop_native=True,exclude_pids=self._external_player_baseline,owned_pids=self._owned_external_pids)
        except Exception as exc:optional_failure("player.zap_stop_owned",exc)
        us_clear(self._owned_external_pids)

        self._zap_index=max(0,int(index))
        # R67: a successful category/channel switch must never inherit the old
        # channel artwork.  ``dict.update`` alone leaves stale _player_picon/logo
        # keys behind when the new catalogue row does not carry those exact keys,
        # which is why the InfoBar kept showing the first channel picon.
        for _art_key in ("_player_picon","_player_picon_url","_player_poster",
                         "stream_icon","picon","logo","poster","poster_url",
                         "cover","cover_url","icon","image","img",
                         "_receiver_picon_local","picon_local","logo_local","image_local"):
            try:self.item.pop(_art_key,None)
            except Exception:pass
        # A channel selected from the OKx2 drawer must never inherit EPG text
        # from the previous channel. Runtime client refs stay on self.item, but
        # all programme fields are replaced by the new row/network result.
        for _epg_key in ("now","program","epg_title","next","next_program","epg_next"):
            try:self.item.pop(_epg_key,None)
            except Exception:pass
        self._front_live_picon_path=""
        self.item.update(item)
        self.name=_clean_live_name(str(item.get("name") or item.get("title") or "Live channel"),self._cfg_clean_titles)
        try:
            recent_item=dict(item)
            # Never persist Player-only runtime objects or a whole folder snapshot.
            for _runtime_key in ("_live_folder_channels","_live_page_loader","_live_client_ref"):
                recent_item.pop(_runtime_key,None)
            recent_item["_live_category_id"]=str(self._zap_category_id or "")
            recent_item["_live_folder_title"]=str(self._zap_title or _("Live TV"))
            recent_item["_live_absolute_index"]=int(self._zap_index or 0)
            recent_item["_live_page_size"]=max(1,int(self._zap_page_size or 1))
            recent_item["_live_folder_page"]=(int(self._zap_index or 0)//max(1,int(self._zap_page_size or 1)))+1
            recent_item["_live_folder_total"]=max(int(self._zap_total or 0),int(self._zap_index or 0)+1)
            self._pending_live_recent_item=recent_item
        except Exception as exc:
            self._pending_live_recent_item=None
            optional_failure("player.live_recent_prepare",exc)
        # R68: picon identity is provider-only.  Reuse a local provider picon
        # immediately; otherwise show the neutral placeholder while a background
        # worker downloads the selected channel's stream_icon into live_picons.
        # This works even when its category was never opened in the Live grid.
        try:
            _new_picon=self._provider_live_picon_cached(self.item)
            if _new_picon:
                self.item["_player_picon"]=_new_picon
                self._load_live_picon(_new_picon)
            else:
                self._load_live_picon(_asset("us168_live_placeholder_220x132.png"))
                self._request_provider_live_picon(self.item)
        except Exception as exc:
            optional_failure("player.zap_picon_refresh",exc)
        self.streamurl=url
        try:self._cancel_smart_recovery()
        except Exception as exc:optional_failure("player.zap_cancel_recovery",exc)
        self._recovery_attempts=0
        self._retry_visual_clear(force=True)
        self._apply_live_channel_title()
        try:self["now"].setText(self._now_text());self["category"].setText(self._category_label())
        except Exception as exc:optional_failure("player.optional_guard",exc)
        try:self._refresh_live_epg()
        except Exception as exc:optional_failure("player.optional_guard",exc)
        try:
            engine=int(self._cfg_service_type)
        except (TypeError,ValueError):
            engine=int(self.servicetype or 4097)
        if engine not in (1,4097,5001,5002,8193):engine=4097
        self.engines=[engine];self.engine_index=0;self.servicetype=engine
        self.playStream(engine,url)
        # Re-run EPG ownership after the selected service handoff. Some images
        # clear/rebuild Player widgets during playService(), so a pre-handoff
        # refresh alone can disappear after an OKx2 channel selection.
        try:self._refresh_live_epg()
        except Exception as exc:optional_failure("player.live_epg_post_zap",exc)
        try:self.doShow()
        except Exception as exc:optional_failure("player.optional_guard",exc)
