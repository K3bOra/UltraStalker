# -*- coding: utf-8 -*-
from __future__ import absolute_import
from collections import OrderedDict
class PixmapBudget(OrderedDict):
    def __init__(self, byte_limit, count_limit):
        OrderedDict.__init__(self)
        self.byte_limit = int(byte_limit)
        self.count_limit = int(count_limit)
        self.costs = {}
        self.bytes_used = 0
    def __setitem__(self, key, value):
        if key in self:self.pop(key)
        ptr = value[0] if isinstance(value, tuple) else value
        try:
            size = ptr.size()
            cost = max(1, int(size.width()) * int(size.height()) * 4)
        except Exception:
            try:
                import struct
                path=value[1] if isinstance(value,tuple) else key
                with open(path,"rb") as handle:header=handle.read(24)
                if header[:8] != b"\x89PNG\r\n\x1a\n":raise ValueError("not PNG")
                width,height=struct.unpack(">II",header[16:24])
                cost=max(1,int(width)*int(height)*4)
            except Exception:
                try:
                    cost=max(1,int(key[-2])*int(key[-1])*4) if isinstance(key,tuple) and len(key)>=5 else 4*1024*1024
                except Exception:cost=4*1024*1024
        if cost > self.byte_limit:return
        while self and (len(self) >= self.count_limit or self.bytes_used + cost > self.byte_limit):
            self.popitem(last=False)
        OrderedDict.__setitem__(self,key,value)
        self.costs[key] = cost
        self.bytes_used += cost
    def pop(self,key,*default):
        if key not in self:
            if default:return default[0]
            raise KeyError(key)
        value=OrderedDict.pop(self,key)
        self.bytes_used -= self.costs.pop(key,0)
        return value
    def popitem(self,last=True):
        key,value=OrderedDict.popitem(self,last=last)
        self.bytes_used -= self.costs.pop(key,0)
        return key,value
    def move_to_end(self,key,last=True):
        value=OrderedDict.pop(self,key)
        if last:OrderedDict.__setitem__(self,key,value)
        else:
            items=list(OrderedDict.items(self))
            OrderedDict.clear(self)
            OrderedDict.__setitem__(self,key,value)
            for k,v in items:OrderedDict.__setitem__(self,k,v)
    def clear(self):
        OrderedDict.clear(self)
        self.costs.clear()
        self.bytes_used=0
