# -*- coding: utf-8 -*-
"""List positioning, level chrome, option rows, panes and descriptions.

Methods moved verbatim out of ``NovaSettingsScreen`` (ui_screens_settings.py); behaviour is unchanged.
This module is imported by ui_screens_settings.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, max, min
from .ui_screens_settings import (
    _settings_classify,
    _settings_group_icon,
    gFont,
)


class SettingsLayoutMixin(object):
    """List positioning, level chrome, option rows, panes and descriptions."""

    def _position_settings_list(self):
        """Compact group rail with an exact native-pixel row capacity."""
        try:
            count=max(1,min(int(len(getattr(self,"entries",[]) or [])),int(self.SETTINGS_VISIBLE_ROWS)))
            self["list"].row_width=440
            self._context_geom("list",48,50,440,count*int(self.SETTINGS_ROW_H))
            self["list"].fit_visible_rows(count)
        except Exception as exc:
            optional_failure("ui.settings_glass_list_geom",exc)

    def _settings_connection_state(self):
        state=getattr(self,"_conn_state",None)
        if state is None:
            state="online"
            try:
                from . import ui as _ui_mod
                warm=_ui_mod.splash_home_warm_state(self.profile)
                if isinstance(warm,dict) and str(warm.get("connection_state") or "").lower()=="offline":state="offline"
            except Exception:pass
            self._conn_state=state
        return state

    def _apply_level_chrome(self):
        """Header + key hints; called when the focused pane changes."""
        options=(getattr(self,"_pane","groups")=="options")
        self._position_settings_list()
        # Both focus states use the same six full-size 66px rows. The 560x680
        # Settings glass must never resize on OK or according to help length.
        # Header, both divider lines and help footer have fixed screen slots.
        profile=self.profile or {}
        name=str(profile.get("name") or profile.get("title") or "Ultra Stalker").strip() or "Ultra Stalker"
        offline=(self._settings_connection_state()=="offline")
        sub="%s  \u2022  V%s  \u2022"%(name[:28],PLUGIN_VERSION)
        self["page_title"].setText(_("Settings")); self["page_sub"].setText(sub)
        self["page_state"].setText(_("Offline") if offline else _("Connected"))
        for n in ("page_title","page_sub","page_dot","page_state"):
            try:self[n].hide()
            except Exception:pass
        if options:
            self["red"].setText(_("Back")); self["green"].setText(_("Change"))
        else:
            self["red"].setText(_("Home")); self["green"].setText(_("Open"))
        for n in ("pv_panel","pv_tile","pv_icon","pv_title","pv_desc","pv_hair","pv_hair_bottom","opt_list"):
            try:self[n].show()
            except Exception:pass
        # Always show the selected option's description, even while navigating
        # the group rail; OK only changes focus, not the geometry or footer.
        if not getattr(self,"_context_active",False):
            try:self["description"].show()
            except Exception:pass
        self._level_applied=options

    def _settings_bind_static_assets(self):
        for name,fn in (("pv_panel","settings_d_r5392/panel_560x680.png"),("pv_tile","set_tile_64.png"),("pv_hair","settings_d_r5392/hair_500x2.png"),("pv_hair_bottom","settings_d_r5392/hair_500x2.png")):
            try:
                inst=self[name].instance
                if inst is not None:inst.setPixmapFromFile(asset(fn))
            except Exception as exc:optional_failure("ui.settings_glass_static",exc)
        try:
            inst=self["opt_list"].instance
            if inst is not None:inst.setSelectionEnable(0)
        except Exception as exc:optional_failure("ui.settings_glass_pv_sel",exc)

    def _update_preview(self,idx):
        """Right card header + option rows for group ``idx`` (cached until refresh())."""
        if not (0<=idx<len(self.entries)):return
        try:
            key=str(self.entries[idx][1]).split(":",1)[1]
            meta=next((x for x in getattr(self,"_settings_sections",[]) if x[0]==key),None)
            if meta is None:return
            if self._pv_shown!=key:
                self._settings_section=key
                self.opt_entries=list(self._settings_entries_by_section.get(key,[]))
                self._opt_idx=max(0,min(int(self._settings_section_last_idx.get(key,0) or 0),max(0,len(self.opt_entries)-1)))
                self["pv_title"].setText(meta[1]); self["pv_desc"].setText(str(meta[2])[:100])
                self._render_option_rows(self._opt_idx)
                # The footer also works while the user is still on the left rail.
                self._set_setting_description(self.opt_entries[self._opt_idx][3] if self.opt_entries else "")
                self._pv_shown=key
                try:
                    inst=self["pv_icon"].instance
                    if inst is not None:inst.setPixmapFromFile(_settings_group_icon(key))
                except Exception as exc:optional_failure("ui.settings_glass_pv_icon",exc)
        except Exception as exc:optional_failure("ui.settings_glass_preview",exc)

    def _render_option_rows(self,selected=None):
        entries=list(getattr(self,"opt_entries",[]) or [])
        if selected is None:selected=getattr(self,"_opt_idx",0)
        selected=max(0,min(int(selected or 0),max(0,len(entries)-1))) if entries else 0
        focus=(getattr(self,"_pane","groups")=="options")
        on_text=_("ON")
        rows=[]
        for i,(title,action,value,_desc) in enumerate(entries):
            kind=_settings_classify(action)
            meta={"level":"options","selected":bool(focus and i==selected),"kind":kind,"value":str(value)}
            if kind=="bool":meta["on"]=bool(str(value)==on_text)
            rows.append((title,"",action,meta))
        self._opt_rebuilding=True
        try:
            self["opt_list"].set_icon_rows(rows)
            if entries:self["opt_list"].moveToIndex(selected)
        finally:
            self._opt_rebuilding=False
        self._opt_visual=selected;self._opt_idx=selected

    def _set_pane(self,pane):
        self._pane=pane
        if pane=="options":
            if not self.opt_entries:
                self._pane="groups";return
            self._opt_idx=max(0,min(int(self._settings_section_last_idx.get(self._settings_section,0) or 0),len(self.opt_entries)-1))
        self._render_settings_rows()
        self._render_option_rows(self._opt_idx)
        self._apply_level_chrome()
        if pane=="options":self._opt_selection_changed(force=True)
        else:self._selection_changed()

    def _opt_step(self,step):
        n=len(self.opt_entries)
        if n<=0:return
        self._opt_goto((int(self._opt_idx)+int(step))%n)

    def _opt_goto(self,idx):
        n=len(self.opt_entries)
        if not (0<=idx<n):return
        self._render_option_rows(idx)
        self._opt_idx=idx
        self._settings_section_last_idx[self._settings_section]=idx
        title,_action,value,desc=self.opt_entries[idx]
        self._set_setting_description(desc)
        self["status"].setText(_("Current: %s") % str(value)[:40])

    def _opt_selection_changed(self,force=False):
        if getattr(self,"_opt_rebuilding",False) or getattr(self,"_pane","groups")!="options":return
        try:idx=int(self["opt_list"].getSelectedIndex() or 0)
        except Exception:return
        if not (0<=idx<len(self.opt_entries)):return
        if force:idx=max(0,min(int(self._opt_idx),len(self.opt_entries)-1))
        self._opt_goto(idx)

    def _render_settings_rows(self, selected=None):
        self._position_settings_list()
        if selected is None:
            try:selected=self["list"].getSelectedIndex()
            except Exception:selected=0
        selected=max(0,min(int(selected or 0),max(0,len(self.entries)-1))) if self.entries else 0
        rows=[]
        for idx,(title,action,value,_desc) in enumerate(self.entries):
            meta={"level":"groups","selected":bool(idx==selected),"kind":"group","value":str(value),"count":str(value)}
            icon=_settings_group_icon(str(action).split(":",1)[1])
            rows.append((title,icon,action,meta))
        self._settings_rebuilding=True
        try:
            self["list"].set_icon_rows(rows)
            if self.entries:self["list"].moveToIndex(selected)
        finally:
            self._settings_rebuilding=False
        self._settings_visual_index=selected
        self._settings_last_idx=selected

    def _setting_description_layout(self,text):
        text=" ".join(str(text or "").split())
        # Match the actual 500px widget, keeping a small shaping safety margin.
        # Do not shrink the font or discard the end of the explanation.
        lines=[];current=""
        for word in text.split():
            trial=(current+" "+word).strip()
            if _settings_text_width_px(trial,20)<=480:
                current=trial;continue
            if current:lines.append(current)
            current=word
            while _settings_text_width_px(current,20)>480:
                take=len(current)-1
                while take>1 and _settings_text_width_px(current[:take],20)>480:take-=1
                lines.append(current[:take]);current=current[take:]
        if current:lines.append(current)
        return "\n".join(lines),20

    def _set_setting_description(self,text):
        rendered,size=self._setting_description_layout(text)
        try:self["description"].setText(rendered)
        except Exception:return
        # Six rows always occupy 547..943, regardless of help length or focus.
        # Footer stays below the 949px separator (at 959..1048). Keep Regular20
        # and word-wrap long lines; never shrink or displace the option list.
        try:
            inst=self["description"].instance
            if inst is not None:inst.setFont(_ultra_rfont("Regular",20))
        except Exception as exc:optional_failure("ui.settings_description_font",exc)
        if not getattr(self,"_context_active",False):
            try:self["description"].show()
            except Exception:pass

    def _selection_changed(self):
        if getattr(self,"_settings_rebuilding",False):return
        if getattr(self,"_pane","groups")=="options":return
        try:idx=int(self["list"].getSelectedIndex() or 0)
        except Exception:return
        if not (0<=idx<len(self.entries)):return
        if getattr(self,"_level_applied",None) is not False:self._apply_level_chrome()
        if idx!=getattr(self,"_settings_visual_index",-1):
            self._render_settings_rows(idx)
        self._settings_last_idx=idx
        self._settings_root_last_idx=idx
        title,_action,value,desc=self.entries[idx]
        self["info_title"].setText(title);self["info"].setText(str(desc)[:120])
        self._update_preview(idx)
        self["status"].setText("")

from .wqhd_layout import responsive_font as _ultra_rfont, factors as _ultra_factors

def _ultra_osd_scale():
    return _ultra_factors()[1]
