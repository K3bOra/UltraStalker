# -*- coding: utf-8 -*-
"""Package paths, legacy package adoption and asset storage.

Methods moved verbatim out of ``PremiumGlobalCinematicScreen`` (ui_cinematic_global.py); behaviour is unchanged.
This module is imported by ui_cinematic_global.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, open
from .ui_cinematic_global import (
    ADAPTIVE,
    GENERATED,
    ROOT,
    _CIN_PACKAGE_DIR,
    accent_hex,
    durable_view_path,
    ensure_persistent_dirs,
    hashlib,
    json,
    optional_failure,
    os,
    re,
    shutil,
    threading,
    time,
)


class CineAssetsMixin(object):
    """Package paths, legacy package adoption and asset storage."""

    def _cin_safe_key(self,key):
        value=str(key or "").strip()
        if not value:return ""
        value=re.sub(r"[^A-Za-z0-9._-]+","_",value)[:160]
        return value or hashlib.sha1(str(key).encode("utf-8","ignore")).hexdigest()[:24]

    def _cin_package_root(self,key):
        # V9.1.2-r2: durable package store (was the per-session GENERATED dir).
        return _CIN_PACKAGE_DIR if self._cin_safe_key(key) else ""

    def _cin_package_path(self,key):
        safe=self._cin_safe_key(key)
        return durable_view_path("cinematic_%s_package.json"%safe,"cinematic_packages") if safe else ""

    def _cin_legacy_roots(self,key):
        safe=str(key or "")
        if not safe:return []
        old_derived=os.path.join(ROOT,"derived")
        old_library=os.path.join(ROOT,"library")
        roots=[
            os.path.join(old_derived,"cinematic_hybrid",safe),
            os.path.join(old_derived,"cinematic_offline",safe),
            os.path.join(old_derived,"cinematic",safe),
        ]
        # Test74-76 may have written package folders under library/movie-id/cinematic.
        if safe.startswith(("movie-","tv-")):
            roots.append(os.path.join(old_library,safe,"cinematic"))
        else:
            roots.append(os.path.join(old_library,"local-"+safe,"cinematic"))
        return roots

    def _cin_store_asset(self,source,root,role,key=""):
        source=str(source or "")
        if not source or not os.path.isfile(source):return ""
        safe=self._cin_safe_key(key) or hashlib.sha1(source.encode("utf-8","ignore")).hexdigest()[:18]
        try:
            # Builders already write into the one fixed GENERATED folder. Keep
            # that exact file instead of duplicating it under another name.
            if os.path.commonpath((os.path.abspath(source),os.path.abspath(GENERATED)))==os.path.abspath(GENERATED):
                return source
            # V9.1.2-r2: durable view/adaptive files are already permanent and
            # shared; reference them directly, never copy or hard-link them.
            _adaptive_root=os.path.abspath(ADAPTIVE)
            if os.path.commonpath((os.path.abspath(source),_adaptive_root))==_adaptive_root:
                return source
        except Exception:pass
        ext=os.path.splitext(source)[1].lower() or ".png"
        if ext not in (".png",".jpg",".jpeg",".webp"):ext=".png"
        target=durable_view_path("cinematic_%s_%s%s"%(safe,role,ext),"cinematic_packages",source=source)
        try:
            if not ensure_persistent_dirs(os.path.dirname(target)):return ""
            if os.path.isfile(target):
                try:
                    if os.path.getsize(target)==os.path.getsize(source) and os.path.getsize(target)>0:return target
                except Exception:pass
            temp=target+".tmp.%d.%d"%(os.getpid(),threading.get_ident())
            try:
                if os.path.exists(temp):os.unlink(temp)
                os.link(source,temp)
            except Exception:
                shutil.copy2(source,temp)
            os.replace(temp,target)
            return target if os.path.isfile(target) and os.path.getsize(target)>0 else ""
        except Exception as exc:
            optional_failure("cinematic.flat_store_asset",exc);return ""

    def _cin_nav_alias_path(self,item):
        try:
            visual=self._page_visual_key(item);safe=self._cin_safe_key(visual)
            return durable_view_path("cinematic_nav_%s.json"%safe,"cinematic_nav") if safe else ""
        except Exception:return ""

    def _cin_publish_nav_alias(self,item,row,package):
        """Persist a tiny provider-key -> final prepared backdrop pointer."""
        if not isinstance(package,dict) or not package:return False
        try:
            backdrop=str(package.get("backdrop_fast") or package.get("backdrop") or "")
            if not backdrop or not os.path.isfile(backdrop):return False
            visual=self._page_visual_key(item);path=self._cin_nav_alias_path(item)
            if not visual or not path:return False
            payload={"schema":1,"visual_key":visual,"package_key":str(package.get("key") or self._record_key(row if isinstance(row,dict) else {},item) or ""),"backdrop":backdrop}
            if (getattr(self,'_cin_nav_alias_ram',{}) or {}).get(visual)==payload:return True
            if not ensure_persistent_dirs(os.path.dirname(path)):return False
            tmp=path+".tmp.%d.%d"%(os.getpid(),threading.get_ident())
            with open(tmp,"w",encoding="utf-8") as h:json.dump(payload,h,separators=(",",":"),ensure_ascii=False)
            os.replace(tmp,path);self._cin_nav_alias_ram[visual]=dict(payload);return True
        except Exception as exc:
            optional_failure("cinematic.nav_alias_write",exc)
            try:
                if 'tmp' in locals() and os.path.exists(tmp):os.unlink(tmp)
            except Exception:pass
            return False

    def _cin_load_nav_alias(self,item):
        """RAM/tiny-JSON only. No metadata, adaptive, Pillow or network work."""
        try:
            visual=self._page_visual_key(item)
            if not visual:return {}
            cached=(getattr(self,"_cin_nav_alias_ram",{}) or {}).get(visual) or {}
            bd=str(cached.get("backdrop") or "") if isinstance(cached,dict) else ""
            if bd and os.path.isfile(bd):return cached
            path=self._cin_nav_alias_path(item)
            if not path or not os.path.isfile(path):return {}
            with open(path,"r",encoding="utf-8") as h:data=json.load(h)
            if not isinstance(data,dict) or int(data.get("schema") or 0)!=1:return {}
            bd=str(data.get("backdrop") or "")
            if not bd or not os.path.isfile(bd):return {}
            self._cin_nav_alias_ram[visual]=data;return data
        except Exception:return {}

    def _cin_normalize_legacy_package(self,data):
        if not isinstance(data,dict):return {}
        rows=data.get("settings_rows") if isinstance(data.get("settings_rows"),dict) else {}
        chrome=data.get("chrome") if isinstance(data.get("chrome"),dict) else {}
        out=dict(data)
        if not out.get("row_normal"):out["row_normal"]=rows.get("normal")
        if not out.get("row_selected"):out["row_selected"]=rows.get("selected")
        for name in ("panel","overview","quality","year","runtime","country","genre"):
            if not out.get(name):out[name]=chrome.get(name)
        return out

    def _cin_adopt_legacy_package(self,item,row):
        """Adopt only old catalogue row material into the current package.

        R149 deliberately refuses legacy backdrop/chrome surfaces here. Native
        Details is the sole information-chrome authority and the shared prepared
        Cinematic JPEG is the sole full-screen backdrop authority. Keeping only
        row assets preserves cheap cache reuse without reviving old visual paths.
        """
        key=self._record_key(row,item);root=self._cin_package_root(key)
        if not key or not root:return {}
        for legacy_root in self._cin_legacy_roots(key):
            for path in (os.path.join(legacy_root,"package.json"),os.path.join(legacy_root,"cinematic_package.json")):
                if not os.path.isfile(path):continue
                try:
                    with open(path,"r",encoding="utf-8") as h:data=self._cin_normalize_legacy_package(json.load(h))
                except Exception:
                    continue
                normal=str(data.get("row_normal") or "");selected=str(data.get("row_selected") or "")
                if not (normal and selected and os.path.isfile(normal) and os.path.isfile(selected)):continue
                adopted_normal=self._cin_store_asset(normal,root,"row_normal",key)
                adopted_selected=self._cin_store_asset(selected,root,"row_selected",key)
                if not (adopted_normal and adopted_selected):continue
                payload={
                    "schema":self._cin_package_schema,"complete":True,"key":key,
                    "signature":self._cin_package_signature(item,row),
                    "accent":str(accent_hex(data.get("accent") or row.get("adaptive_accent") or row.get("adaptive_primary") or "#c99141")),
                    "created_at":int(data.get("created_at") or data.get("completed_at") or time.time()),
                    "row_normal":adopted_normal,"row_selected":adopted_selected,
                    "backdrop_source_sig":self._cin_file_sig(row.get("backdrop_local")),
                    "clean_backdrop_selector_version":int(row.get("clean_backdrop_selector_version") or 0),
                }
                if self._cin_write_package(self._cin_package_path(key),payload):return payload
        return {}
