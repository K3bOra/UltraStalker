# -*- coding: utf-8 -*-
"""Short and full EPG requests.

Methods moved verbatim out of ``StalkerClient`` (client.py); behaviour is unchanged.
This module is imported by client.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str, int, max, min
from .client import (
    LOG,
    PortalCancelledError,
    PortalError,
)


class ClientEpgMixin(object):
    """Short and full EPG requests."""

    def epg(self, channel_id, hours=4, cancel_event=None, use_cache=True):
        # use_cache=False: bulk XMLTV refresh - do not read/write the RAM + flash
        # SQLite cache (nobody re-reads those per-channel rows).
        if not self.token:
            self.authorize(cancel_event=cancel_event)
        js = self._unwrap(self._get({
            "type": "itv", "action": "get_short_epg", "ch_id": channel_id,
            "size": max(1, min(24, int(hours or 4))), "JsHttpRequest": "1-xml",
        }, use_cache=bool(use_cache), cancel_event=cancel_event))
        return self._as_list(js)

    def epg_many(self, channel_ids, hours=10, cancel_event=None, on_each=None):
        """Fetch the visible short guide with bounded, independent network lanes.

        MAG short EPG is a per-channel request.  Serially waiting on 24 requests
        made the later rows look as if they had no guide.  A page now uses at
        most six dedicated HTTP worker sockets; a malformed/foreign response is
        never attributed to the requested channel.  Portal/session errors get
        one final isolated replay after the concurrent wave.
        """
        ThreadPoolExecutor = _us_env.concurrent_futures.ThreadPoolExecutor; as_completed = _us_env.concurrent_futures.as_completed

        ids = []
        seen = set()
        for raw in channel_ids or []:
            cid = str(raw or "").strip()
            if cid and cid not in seen:
                ids.append(cid)
                seen.add(cid)
        if not ids:
            return {}

        def cancelled():
            return cancel_event is not None and getattr(cancel_event, "is_set", lambda: False)()

        if cancelled():
            return {}
        if not self.token:
            try:
                self.authorize(cancel_event=cancel_event)
            except PortalError:
                return {}

        def request_one(cid):
            if cancelled():
                return cid, None, False
            try:
                # The GUI has its own 15-minute positive EPG cache.  Bypass
                # the HTTP/SQLite cache so an intermittent empty portal reply
                # is not kept for ten minutes by the generic API cache.
                rows = self.epg(cid, hours, cancel_event=cancel_event, use_cache=False)
                if not isinstance(rows, list):
                    return cid, None, True
                # Some middleware versions omit ch_id per entry.  If it is
                # supplied, ensure we never show another channel's programme.
                returned_ids = set(
                    str(row.get("ch_id")).strip()
                    for row in rows if isinstance(row, dict) and row.get("ch_id") not in (None, "", 0, "0")
                )
                if returned_ids and returned_ids != {cid}:
                    LOG.debug("Short EPG channel-id mismatch; retrying requested channel")
                    return cid, None, True
                return cid, rows, False
            except PortalCancelledError:
                return cid, None, False
            except PortalError as exc:
                LOG.debug("Short EPG request failed (%s)", exc.__class__.__name__)
                return cid, None, True
            except Exception as exc:
                LOG.debug("Short EPG unexpected failure (%s)", exc.__class__.__name__)
                return cid, None, True
            finally:
                # Each lane owns its socket; never leave parallel sockets in
                # the pool for unrelated playback or a later page.
                try:
                    self._drop_current_transport(close=True)
                except Exception:
                    pass

        def completed(cid, rows):
            out[cid] = rows
            if callable(on_each) and not cancelled():
                try:
                    on_each(cid, rows)
                except Exception:
                    pass

        out = {}
        retry_ids = set()
        pool = ThreadPoolExecutor(max_workers=min(6, len(ids)))
        try:
            futures = {pool.submit(request_one, cid): cid for cid in ids}
            for future in as_completed(futures):
                if cancelled():
                    break
                cid = futures[future]
                try:
                    _cid, rows, needs_retry = future.result()
                except Exception:
                    rows, needs_retry = None, True
                if needs_retry:
                    retry_ids.add(cid)
                elif rows is not None:
                    completed(cid, rows)
        finally:
            # A cancelled/abandoned guide request must not keep queueing
            # portal requests for the remaining channels.
            try:
                pool.shutdown(wait=False, cancel_futures=True)
            except TypeError:
                pool.shutdown(wait=False)

        # Back off to one-at-a-time only for requests that failed validation
        # or transport.  Valid empty guides remain valid empty guides.
        for cid in ids:
            if cancelled():
                break
            if cid not in retry_ids:
                continue
            _cid, rows, needs_retry = request_one(cid)
            if not needs_retry and rows is not None:
                completed(cid, rows)
        return out

    def full_epg(self, channel_id, from_ts=None, to_ts=None, page=1, max_pages=120, cancel_event=None):
        """Return EPG rows across all portal pages, with repeated-page protection."""
        if not self.token:
            self.authorize(cancel_event=cancel_event)
        errors = []
        start_page = max(1, self._int_value(page, 1))
        max_pages = max(1, min(self._int_value(max_pages, 120), self.MAX_CATALOG_PAGES))
        for action in ("get_epg_info", "get_epg", "get_short_epg"):
            collected, seen = [], set()
            current_page = start_page
            for _ in range(max_pages):
                if cancel_event is not None and getattr(cancel_event, "is_set", lambda: False)():
                    return collected
                params = {
                    "type": "itv", "action": action, "ch_id": channel_id,
                    "p": int(current_page), "JsHttpRequest": "1-xml",
                }
                if from_ts is not None:
                    params["from"] = int(from_ts)
                if to_ts is not None:
                    params["to"] = int(to_ts)
                try:
                    js = self._unwrap(self._get(params, use_cache=True, cancel_event=cancel_event))
                except PortalError as exc:
                    errors.append(str(exc))
                    break
                rows = list(row for row in self._as_list(js) if isinstance(row, dict))
                if not rows:
                    break
                added = 0
                for row in rows:
                    start_value = self._int_value(row.get("start_timestamp") or row.get("start") or row.get("time"), 0)
                    duration = self._int_value(row.get("duration") or row.get("length"), 0)
                    if from_ts is not None and start_value and (start_value + max(0, duration)) < int(from_ts):
                        continue
                    if to_ts is not None and start_value and start_value > int(to_ts):
                        continue
                    marker = str(row.get("id") or "") + "|" + str(start_value) + "|" + str(row.get("name") or row.get("title") or row.get("descr") or "")
                    if marker in seen:
                        continue
                    seen.add(marker)
                    collected.append(row)
                    added += 1
                if not added:
                    # A portal ignoring the page number returns the same rows.
                    break
                meta = js if isinstance(js, dict) else {}
                total = max(0, self._int_value(meta.get("total_items") or meta.get("total"), 0))
                page_size = max(1, self._int_value(meta.get("max_page_items") or meta.get("page_size"), len(rows) or 1))
                if total and len(seen) >= total:
                    break
                if not total and len(rows) < page_size:
                    break
                current_page += 1
            if collected:
                return collected
        if errors:
            raise PortalError(errors[-1])
        return []
