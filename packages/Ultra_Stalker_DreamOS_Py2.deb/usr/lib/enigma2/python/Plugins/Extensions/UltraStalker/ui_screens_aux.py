# -*- coding: utf-8 -*-
"""Auxiliary UI screens extracted from ui.py without changing behavior."""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str, int, round, max, min, us_func

from . import _
from .ui_floating_notice import show_notice
hashlib = _us_env.hashlib
os = _us_env.os

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap
from enigma import eTimer, ePoint, eSize, getDesktop

# PERF45: the Downloads screen is imported during normal UI startup, but the
# download engine itself is only needed when this screen is actually opened.
# Keep a tiny facade here so importing auxiliary screens stays side-effect free.
class _LazyDownloadsFacade(object):
    def _manager(self):
        from .downloads import MANAGER as _MANAGER
        return _MANAGER
    def snapshot(self): return self._manager().snapshot()
    def cancel(self, jid): return self._manager().cancel(jid)
    def retry(self, jid, resolver=None): return self._manager().retry(jid, resolver)
    def remove(self, jid): return self._manager().remove(jid)

DOWNLOADS = _LazyDownloadsFacade()
from .log import optional_failure
from .ui_parts.catalog import clean_display_text as _clean_display_text
from .ui_dynamic_chrome import _build_aux_adaptive_chrome

IconMenuList = None
_information_sections = None

def configure_aux_screens(icon_menu_list, information_sections):
    global IconMenuList, _information_sections
    IconMenuList = icon_menu_list
    _information_sections = information_sections

class AdaptiveInformationScreen(Screen):
    skin = '<screen name="AdaptiveInformationScreen" position="0,0" size="1920,1080" backgroundColor="#02060b" flags="wfNoBorder">\n        <widget name="frame" position="300,120" size="1320,820" alphatest="blend" zPosition="1" />\n        <widget name="header" position="365,155" size="1180,52" font="Regular;36" foregroundColor="#ffffff" transparent="1" zPosition="5"  shadowColor="#000000" shadowOffset="1,1"/>\n        <widget name="title" position="365,205" size="1180,36" font="Regular;22" foregroundColor="#9ec9dc" transparent="1" zPosition="5"  shadowColor="#000000" shadowOffset="1,1"/>\n\n        <widget name="overview_bg" position="350,255" size="1220,300" alphatest="blend" zPosition="2" />\n        <widget name="overview_title" position="375,270" size="1170,34" font="Regular;19" foregroundColor="#9fd8ed" transparent="1" zPosition="5"  shadowColor="#000000" shadowOffset="1,1"/>\n        <widget name="overview" position="385,310" size="1150,225" font="Regular;23" foregroundColor="#f3f5f7" transparent="1" zPosition="6"  shadowColor="#000000" shadowOffset="1,1"/>\n\n        <widget name="cast_bg" position="350,575" size="560,150" alphatest="blend" zPosition="2" />\n        <widget name="cast_title" position="370,588" size="520,30" font="Regular;18" halign="center" valign="center" foregroundColor="#9fd8ed" transparent="1" zPosition="5"  shadowColor="#000000" shadowOffset="1,1"/>\n        <widget name="cast" position="375,620" size="510,90" font="Regular;20" halign="center" valign="center" foregroundColor="#f3f5f7" transparent="1" zPosition="6"  shadowColor="#000000" shadowOffset="1,1"/>\n\n        <widget name="director_bg" position="930,575" size="280,150" alphatest="blend" zPosition="2" />\n        <widget name="director_title" position="945,588" size="250,30" font="Regular;18" halign="center" valign="center" foregroundColor="#9fd8ed" transparent="1" zPosition="5"  shadowColor="#000000" shadowOffset="1,1"/>\n        <widget name="director" position="945,620" size="250,90" font="Regular;20" halign="center" valign="center" foregroundColor="#f3f5f7" transparent="1" zPosition="6"  shadowColor="#000000" shadowOffset="1,1"/>\n\n        <widget name="writer_bg" position="1230,575" size="340,150" alphatest="blend" zPosition="2" />\n        <widget name="writer_title" position="1245,588" size="310,30" font="Regular;18" halign="center" valign="center" foregroundColor="#9fd8ed" transparent="1" zPosition="5"  shadowColor="#000000" shadowOffset="1,1"/>\n        <widget name="writer" position="1245,620" size="310,90" font="Regular;20" halign="center" valign="center" foregroundColor="#f3f5f7" transparent="1" zPosition="6"  shadowColor="#000000" shadowOffset="1,1"/>\n\n        \n<ePixmap position="412,793" size="56,42" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/player_keyline_red_dash_56x42.png" alphatest="blend" scale="1" zPosition="4"/>\n<widget name="red" position="470,793" size="126,42" font="Regular;20" halign="left" valign="center" foregroundColor="#ffffff" transparent="1" zPosition="5" noWrap="1" shadowColor="#000000" shadowOffset="1,1"/>\n        \n        <widget name="scroll_hint" position="700,795" size="650,38" font="Regular;19" foregroundColor="#9fb0c0" transparent="1" zPosition="5"  shadowColor="#000000" shadowOffset="1,1"/>\n    </screen>'
    def __init__(self,session,title,text,source_path="",info_item=None,info_parent=None):
        us_func(Screen.__init__)(self,session); self._source_path=str(source_path or "")
        self._sections=_information_sections(info_item,info_parent,text)
        self["frame"]=Pixmap(); self["header"]=Label(_("INFORMATION"))
        self["title"]=Label(_clean_display_text(title,120))
        for n in ("overview_bg","cast_bg","director_bg","writer_bg"): self[n]=Pixmap()
        self["overview_title"]=Label(_("OVERVIEW"))
        self["overview"]=Label(_clean_display_text(self._sections.get("overview"),1200))
        self["cast_title"]=Label(_("Cast"))
        self["cast"]=Label(_clean_display_text(self._sections.get("cast"),350))
        self["director_title"]=Label(_("Director"))
        self["director"]=Label(_clean_display_text(self._sections.get("director"),160))
        self["writer_title"]=Label(_("Writer"))
        self["writer"]=Label(_clean_display_text(self._sections.get("writer"),200))
        self["red"]=Label(_("Close"))
        self["scroll_hint"]=Label(_("UP / DOWN  Scroll"))
        self["actions"]=ActionMap(["OkCancelActions","ColorActions","DirectionActions"],{"cancel":self.close,"red":self.close,"ok":self.close},-1)
        self.onLayoutFinish.append(self._finish_layout)
    def _finish_layout(self):
        self._apply_chrome()
        # Labels are used deliberately here instead of ScrollLabel: OpenBH can
        # leave an empty ScrollLabel instance on some skins even when text is set.
        for n in ("overview","cast","director","writer"):
            try:self[n].show()
            except Exception as exc:optional_failure("ui.silent_guard",exc)
    def _apply_chrome(self):
        key=hashlib.sha1((self._source_path+"|info175").encode("utf-8","ignore")).hexdigest()[:16]
        chrome=_build_aux_adaptive_chrome(self._source_path,key)
        mapping=(("frame","info_panel"),("overview_bg","info_overview"),("cast_bg","info_cast"),("director_bg","info_director"),("writer_bg","info_writer"))
        for name,asset_key in mapping:
            path=chrome.get(asset_key)
            try:
                if path and os.path.isfile(path) and self[name].instance is not None:
                    self[name].instance.setPixmapFromFile(path); self[name].show()
            except Exception as exc:optional_failure("ui.adaptive_info_chrome",exc)


class DownloadsManagerScreen(Screen):
    # R5.237: transparent same-page-style overlay. The caller remains visible
    # underneath exactly like the yellow-key Information treatment. Downloads
    # use fixed package-owned chrome only; no adaptive artwork sampling.
    skin = """<screen name="DownloadsManagerScreen" position="0,0" size="1920,1080" backgroundColor="#00000000" flags="wfNoBorder">
        <ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/us20_player_info_scrim.png" alphatest="blend" scale="1" zPosition="1"/>
        <widget name="frame" position="300,205" size="1320,670" alphatest="blend" scale="1" transparent="1" zPosition="2"/>
        <widget name="title" position="365,242" size="1190,50" font="Regular;36" foregroundColor="#ffffff" transparent="1" zPosition="5" shadowColor="#000000" shadowOffset="1,1"/>
        <widget name="summary" position="367,294" size="1186,30" font="Regular;19" foregroundColor="#b8c2cb" transparent="1" zPosition="5" shadowColor="#000000" shadowOffset="1,1"/>
        <widget name="list" position="415,347" size="1090,400" scrollbarMode="showNever" transparent="1" zPosition="6"/>

        <widget name="red_dash" position="510,804" size="56,42" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/player_keyline_red_dash_56x42.png" alphatest="blend" scale="1" transparent="1" zPosition="6"/>
        <widget name="red" position="568,804" size="150,42" font="Regular;20" halign="left" valign="center" foregroundColor="#ffffff" transparent="1" zPosition="7" noWrap="1" shadowColor="#000000" shadowOffset="1,1"/>
        <widget name="yellow_dash" position="752,804" size="56,42" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/player_keyline_yellow_dash_56x42.png" alphatest="blend" scale="1" transparent="1" zPosition="6"/>
        <widget name="yellow" position="810,804" size="205,42" font="Regular;20" halign="left" valign="center" foregroundColor="#ffffff" transparent="1" zPosition="7" noWrap="1" shadowColor="#000000" shadowOffset="1,1"/>
        <widget name="green_dash" position="1050,804" size="56,42" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/player_keyline_green_dash_56x42.png" alphatest="blend" scale="1" transparent="1" zPosition="6"/>
        <widget name="green" position="1108,804" size="190,42" font="Regular;20" halign="left" valign="center" foregroundColor="#ffffff" transparent="1" zPosition="7" noWrap="1" shadowColor="#000000" shadowOffset="1,1"/>
        <widget name="blue_dash" position="1318,804" size="56,42" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/player_keyline_blue_dash_56x42.png" alphatest="blend" scale="1" transparent="1" zPosition="6"/>
        <widget name="blue" position="1376,804" size="180,42" font="Regular;20" halign="left" valign="center" foregroundColor="#ffffff" transparent="1" zPosition="7" noWrap="1" shadowColor="#000000" shadowOffset="1,1"/>
    </screen>"""
    def __init__(self,session,source_path=""):
        us_func(Screen.__init__)(self,session); self.setTitle(_("Downloads")); self._source_path=""; self._chrome={}
        self["frame"]=Pixmap(); self["red_dash"]=Pixmap(); self["yellow_dash"]=Pixmap(); self["green_dash"]=Pixmap(); self["blue_dash"]=Pixmap(); self["title"]=Label(_("Downloads")); self["summary"]=Label("")
        self["list"]=IconMenuList([],width=880,item_height=80,icon_size=40,primary_font=23,secondary_font=17,row_style="download_glass")
        self["red"]=Label(_("Close")); self["yellow"]=Label(_("Cancel selected")); self["green"]=Label(_("Retry failed")); self["blue"]=Label(_("Remove"))
        self["actions"]=ActionMap(["OkCancelActions","ColorActions","DirectionActions"],{"cancel":self.close,"red":self.close,"yellow":self.cancel_selected,"green":self.retry_selected,"blue":self.delete_selected,"up":lambda:self["list"].wrap_up(),"down":lambda:self["list"].wrap_down(),"left":lambda:self["list"].page_left(),"right":lambda:self["list"].page_right()},-1)
        self._rows=[]; self._rendering=False; self._last_layout_count=-1; self._timer=eTimer(); self._timer_conn=None
        try:self._timer_conn=self._timer.timeout.connect(self.refresh)
        except Exception:self._timer.callback.append(self.refresh)
        self["list"].onSelectionChanged.append(self._selection_changed); self.onLayoutFinish.append(self._start); self.onClose.append(self._stop)
    def _geom(self,name,x,y,w,h):
        try:
            desktop=getDesktop(0).size(); sx=float(desktop.width())/1920.0; sy=float(desktop.height())/1080.0
            inst=self[name].instance
            if inst is not None:
                inst.move(ePoint(int(round(x*sx)),int(round(y*sy))))
                inst.resize(eSize(max(1,int(round(w*sx))),max(1,int(round(h*sy)))))
        except Exception as exc:optional_failure("ui.download_overlay_geom",exc)
    def _layout_overlay(self):
        count=max(1,min(4,len(self._rows or [])))
        list_h=count*80
        panel_x=480;panel_w=960;panel_h=190+list_h
        panel_y=(1080-panel_h)//2
        try:
            from .ui_icon_menu import _us_fit_png
            desktop=getDesktop(0).size();sx=float(desktop.width())/1920.0;sy=float(desktop.height())/1080.0
            path=(getattr(self,"_chrome",None) or {}).get("download_panel")
            if path and os.path.isfile(path) and self["frame"].instance is not None:
                fpath=_us_fit_png(path,max(1,int(round(panel_w*sx))),max(1,int(round(panel_h*sy))),True)
                if fpath and os.path.isfile(fpath):
                    self["frame"].instance.setPixmapFromFile(fpath)
        except Exception as exc:optional_failure("ui.download_overlay_panel_fit",exc)
        self._geom("frame",panel_x,panel_y,panel_w,panel_h)
        self._geom("title",panel_x+40,panel_y+24,880,46)
        self._geom("summary",panel_x+40,panel_y+74,880,30)
        self._geom("list",panel_x+40,panel_y+112,880,max(1,list_h))
        footer_y=panel_y+panel_h-56
        self._geom("red_dash",panel_x+24,footer_y-2,56,42)
        self._geom("red",panel_x+80,footer_y,115,38)
        self._geom("yellow_dash",panel_x+202,footer_y-2,56,42)
        self._geom("yellow",panel_x+258,footer_y,220,38)
        self._geom("green_dash",panel_x+470,footer_y-2,56,42)
        self._geom("green",panel_x+526,footer_y,190,38)
        self._geom("blue_dash",panel_x+716,footer_y-2,56,42)
        self._geom("blue",panel_x+772,footer_y,150,38)

    @staticmethod
    def _human_bytes(value):
        try:value=max(0,int(value or 0))
        except Exception:value=0
        units=((1024.0**3,"GB"),(1024.0**2,"MB"),(1024.0,"KB"))
        for base,label in units:
            if value>=base:
                return ("%.2f %s"%(value/base,label)) if label=="GB" else ("%.1f %s"%(value/base,label))
        return "%d B"%value
    def _apply_chrome(self):
        # Package-owned Home material only. Downloads never samples artwork,
        # builds a palette or changes colour with the selected movie/episode.
        base=os.path.join(os.path.dirname(__file__),"assets_fhd","fixed_master_r63","downloads")
        self._chrome={
            "download_panel":os.path.join(base,"downloads_overlay_panel_1320x670.png"),
            "download_row":os.path.join(base,"downloads_overlay_row_1090x72.png"),
            "download_focus":os.path.join(os.path.dirname(os.path.dirname(base)),"poster_cursor_row_1090x72.png"),
            "progress_track":os.path.join(os.path.dirname(base),"home_recent_pbar_track.png"),
            "progress_fill":os.path.join(os.path.dirname(base),"home_recent_pbar_fill.png"),
        }
        try:
            from .ui_icon_menu import _us_fit_png
            desktop=getDesktop(0).size();sx=float(desktop.width())/1920.0;sy=float(desktop.height())/1080.0
            count=max(1,min(4,len(self._rows or [])))
            path=self._chrome.get("download_panel")
            if path and os.path.isfile(path) and self["frame"].instance is not None:
                fpath=_us_fit_png(path,max(1,int(round(960*sx))),max(1,int(round((190+count*80)*sy))),True)
                self["frame"].instance.setPixmapFromFile(fpath or path);self["frame"].show()
        except Exception as exc:optional_failure("ui.download_panel_chrome",exc)
    def _start(self):
        self._apply_chrome()
        try:
            if self["list"].instance is not None:
                self["list"].instance.setSelectionEnable(0);self["list"].instance.setTransparent(1)
        except Exception as exc:optional_failure("ui.download_selection_native_off",exc)
        self.refresh();self._timer.start(1000,False)
    def _stop(self):
        try:self._timer.stop()
        except Exception as exc:optional_failure("ui.download_timer_stop",exc)
        try:
            if getattr(self,"_timer_conn",None) is not None:self._timer_conn.disconnect()
        except Exception as exc:optional_failure("ui.download_timer_disconnect",exc)
        self._timer_conn=None
        try:
            if self.refresh in self._timer.callback:self._timer.callback.remove(self.refresh)
        except Exception as exc:optional_failure("ui.download_timer_callback",exc)
        try:
            callbacks=self["list"].onSelectionChanged
            if self._selection_changed in callbacks:callbacks.remove(self._selection_changed)
        except Exception as exc:optional_failure("ui.download_selection_callback",exc)
    def _selection_changed(self):
        if not self._rendering:self._render_rows()
    def _update_summary(self):
        counts={"active":0,"queued":0,"completed":0,"failed":0}
        for row in self._rows:
            status=str(row.get("status") or "queued").lower()
            if status in ("resolving","downloading"):counts["active"]+=1
            elif status in ("queued","paused"):counts["queued"]+=1
            elif status=="completed":counts["completed"]+=1
            elif status in ("failed","cancelled"):counts["failed"]+=1
        parts=[]
        if counts["active"]:parts.append(_("Active")+" %d"%counts["active"])
        if counts["queued"]:parts.append(_("Pending")+" %d"%counts["queued"])
        if counts["completed"]:parts.append(_("Completed")+" %d"%counts["completed"])
        if counts["failed"]:parts.append(_("Failed")+" %d"%counts["failed"])
        if not parts:parts=[_("No downloads yet")]
        try:self["summary"].setText("  •  ".join(parts))
        except Exception:pass
    def _render_rows(self):
        if self._rendering:return
        self._rendering=True
        selected=self["list"].getSelectedIndex() if self._rows else 0
        rows=[]
        for i,row in enumerate(self._rows):
            try:done=max(0,int(row.get("downloaded") or 0))
            except Exception:done=0
            try:total=max(0,int(row.get("total") or 0))
            except Exception:total=0
            pct=min(100,int(done*100.0/total)) if total else 0
            raw_status=str(row.get("status") or "queued").lower(); status=_(raw_status.upper())
            done_text=self._human_bytes(done)
            total_text=self._human_bytes(total) if total else ""
            size_text=(done_text+" / "+total_text) if total_text else done_text
            progress=("%d%%"%pct) if total else (("100%") if raw_status=="completed" else "")
            meta={"selected":bool(i==selected),"status":status,"progress":progress,"size_text":size_text,"progress_pct":pct,
                  "progress_track":self._chrome.get("progress_track"),"progress_fill":self._chrome.get("progress_fill"),
                  "row_asset":self._chrome.get("download_row"),
                  "focus_asset":self._chrome.get("download_focus")}
            rows.append((_clean_display_text(row.get("title") or _("Download"),100),"",row,meta))
        try:
            self["list"].set_icon_rows(rows)
            if self._rows:
                try:self["list"].moveToIndex(min(selected,len(self._rows)-1))
                except Exception as exc:optional_failure("ui.silent_guard",exc)
        finally:
            self._rendering=False
        self._update_summary()
    def refresh(self):
        selected=self["list"].getSelectedIndex() if self._rows else 0
        self._rows=DOWNLOADS.snapshot()
        layout_count=min(4,len(self._rows or []))
        if layout_count!=self._last_layout_count:
            self._last_layout_count=layout_count; self._layout_overlay()
        self._render_rows()
        if self._rows:
            try:self["list"].moveToIndex(min(selected,len(self._rows)-1))
            except Exception as exc:optional_failure("ui.silent_guard",exc)
    def _selected_job(self):
        idx=self["list"].getSelectedIndex(); return self._rows[idx] if 0<=idx<len(self._rows) else None
    def cancel_selected(self):
        row=self._selected_job()
        if row:DOWNLOADS.cancel(row.get("id"));self.refresh()
    def retry_selected(self):
        row=self._selected_job()
        if row and row.get("status") in ("failed","cancelled","paused"):
            if hasattr(DOWNLOADS, "retry"):
                ok, msg = DOWNLOADS.retry(row.get("id"))
                self.refresh()
                if not ok:
                    show_notice(self.session, _(msg), timeout=6, owner=self)
                return
            show_notice(self.session, _("Re-open the movie/episode and choose Download again to refresh its portal link."), timeout=7, owner=self)
    def delete_selected(self):
        row=self._selected_job()
        if row:DOWNLOADS.remove(row.get("id"));self.refresh()

# R5.245: plugin-owned front-panel identity.
try:
    from .frontpanel_plugin import bind_plugin_front_summary as _bind_plugin_front_summary
    _bind_plugin_front_summary(AdaptiveInformationScreen, DownloadsManagerScreen)
except Exception:
    pass

