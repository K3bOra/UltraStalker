"""Read existing Enigma EPG only for an explicitly supplied channel reference.

No channel-name searches, fabricated DVB ids, cache imports or network calls.
Native cache access is dispatched to Enigma's main loop when called by a worker.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str, int, max, min
re = _us_env.re
threading = _us_env.threading
time = _us_env.time


def confirmed_reference(value):
    if not isinstance(value,str) or len(value)>4096:return ''
    parts=value.strip().split(':')
    if len(parts)<11:return ''
    identity=parts[:10]
    if not all(re.fullmatch(r'[0-9a-fA-F]{1,8}',part) for part in identity):return ''
    try:
        if not 0<int(identity[0])<=65535:return ''
        if not any(int(part,16) for part in identity[3:7]):return ''
    except ValueError:return ''
    return ':'.join(identity)+':'


def reference_from_row(row):
    if not isinstance(row,dict):return ''
    for key in ('service_ref','service_reference','serviceref','service-ref','custom_sid'):
        ref=confirmed_reference(row.get(key))
        if ref:return ref
    return ''


def _read(reference,hours,event,now):
    if event is not None and event.is_set():return []
    try:
        from enigma import eEPGCache
        cache=eEPGCache.getInstance()
        # Native lookup format: begin, duration, title, short and extended text.
        data=cache.lookupEvent(['BDTSE',(reference,0,-1,hours*60)]) or []
    except Exception:return []
    out=[]
    for entry in data[:512]:
        if event is not None and event.is_set():return []
        if not isinstance(entry,(list,tuple)) or len(entry)<5:continue
        try:start=int(entry[0]);duration=int(entry[1])
        except (ValueError,TypeError,OverflowError):continue
        title=str(entry[2] or '').strip()[:512]
        stop=start+duration
        if not title or start<=0 or duration<=0 or stop<=now or start>now+hours*3600:continue
        short=str(entry[3] or '').strip();extended=str(entry[4] or '').strip()
        desc=(short+'\n'+extended if short and extended and short!=extended else extended or short)[:4096]
        out.append({'title':title,'name':title,'description':desc,'descr':desc,
                    'start_timestamp':start,'stop_timestamp':stop,'time':start,'time_to':stop,'duration':duration})
    out.sort(key=lambda row:row['start_timestamp'])
    return out


def guide_rows(reference,hours=10,cancel_event=None):
    reference=confirmed_reference(reference)
    if not reference or (cancel_event is not None and cancel_event.is_set()):return []
    try:hours=max(1,min(72,int(hours or 10)))
    except (ValueError,TypeError):hours=10
    now=int(time.time())
    if threading.current_thread() is threading.main_thread():
        return _read(reference,hours,cancel_event,now)
    try:
        from twisted.internet import reactor
        if not reactor.running:return []
    except Exception:return []
    done=threading.Event();expired=threading.Event();result=[]
    def read_on_gui():
        try:
            if not expired.is_set():result.extend(_read(reference,hours,cancel_event,now))
        finally:done.set()
    try:reactor.callFromThread(read_on_gui)
    except Exception:return []
    deadline=time.monotonic()+1.5
    while not done.wait(0.05):
        if time.monotonic()>=deadline or (cancel_event is not None and cancel_event.is_set()):
            expired.set();return []
    if cancel_event is not None and cancel_event.is_set():return []
    return result
