# -*- coding: utf-8 -*-
"""Page visual and age caches, memory-settle timers and player poster paths.

Methods moved verbatim out of ``PremiumGridBase`` (ui_grid_base.py); behaviour is unchanged.
This module is imported by ui_grid_base.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int
from .ui_grid_base import (
    _mem34,
    display_certification,
    os,
)


class GridCacheMixin(object):
    """Page visual and age caches, memory-settle timers and player poster paths."""

    def _mem34_stop_timer(self):
        try:self._mem34_timer.stop()
        except Exception:pass
        try:
            if self._mem34_timer_conn is not None:self._mem34_timer_conn.disconnect()
        except Exception:pass
        try:
            if self._mem34_grid_settled in self._mem34_timer.callback:self._mem34_timer.callback.remove(self._mem34_grid_settled)
        except Exception:pass

    def _mem34_schedule_settled(self):
        try:self._mem34_timer.stop();self._mem34_timer.start(2500,True)
        except Exception:self._mem34_grid_settled()

    def _mem34_grid_settled(self):
        try:self._mem34_timer.stop()
        except Exception:pass
        _mem34(
            "grid_settled", mode=self.__class__.__name__, media=str(getattr(self,"media_type","") or ""),
            page=int(getattr(self,"page",0) or 0), items=len(getattr(self,"grid_items",[]) or []),
            visual_ram=len(getattr(self,"_page_visual_ram",{}) or {}), slot_paths=len(getattr(self,"_grid_slot_paths",{}) or {}),
            inflight=len(getattr(self,"_grid_download_inflight",{}) or {})
        )

    def _grid_is_m3u_source(self):
        try:
            source=str((self.profile or {}).get("source_type") or "").lower().strip()
            portal=str((self.profile or {}).get("portal") or "").lower()
            return source=="m3u" or ".m3u" in portal or "type=m3u" in portal or "output=m3u" in portal
        except Exception:
            return False

    def _page_visual_key(self,item):
        try:
            from .persistent_cache import content_cache_key
            return str(content_cache_key(self.profile,self.media_type,item) or "")
        except Exception:
            try:return hashlib.sha1(repr(sorted((item or {}).items())).encode("utf-8","ignore")).hexdigest()
            except Exception:return ""

    def _age_tmdb_key(self,item):
        if not isinstance(item,dict):return ""
        tid=item.get("_locked_tmdb_id") or item.get("_ultra_search_verified_tmdb_id") or item.get("tmdb_id")
        if tid not in (None,""):
            mt="tv" if str(self.media_type or "").lower() in ("series","tv") else "movie"
            return "tmdb:%s:%s"%(mt,str(tid).strip())
        return ""

    def _age_cache_get(self,item):
        if self.media_type not in ("vod","series") or not isinstance(item,dict):
            return (False,"")
        key=self._page_visual_key(item)
        tkey=self._age_tmdb_key(item)
        try:
            cache=getattr(self,"_visible_age_cache",{}) or {}
            for k in (key,tkey):
                if not k:continue
                row=dict(cache.get(k) or {})
                if row:
                    try:self._visible_age_cache.move_to_end(k)
                    except Exception:pass
                    return (bool(row.get("checked")),str(row.get("raw") or "").strip())
            return (False,"")
        except Exception as exc:
            optional_failure("ui.age_cache_get",exc);return (False,"")

    def _age_cache_put(self,item,raw="",checked=False):
        if self.media_type not in ("vod","series") or not isinstance(item,dict):return
        value=str(raw or "").strip();done=bool(checked or value)
        if not done:return
        key=self._page_visual_key(item)
        tkey=self._age_tmdb_key(item)
        try:
            for k in (key,tkey):
                if not k:continue
                self._visible_age_cache[k]={"raw":value,"checked":done}
                self._visible_age_cache.move_to_end(k)
            while len(self._visible_age_cache)>int(getattr(self,"_visible_age_cache_limit",1024) or 1024):
                self._visible_age_cache.popitem(last=False)
        except Exception as exc:optional_failure("ui.age_cache_put",exc)

    def _age_cache_seed_item(self,item):
        """Publish only a resolved/displayable age result before first paint.

        Old/provider rows can carry text tokens (NR, Unrated, unknown regional
        vocab) together with a stale `_age_rating_checked` marker.  Such a token
        must stay raw for provenance but must NOT close the canonical TMDb age
        lane.  A checked blank, on the other hand, is a valid cached negative
        result and prevents useless repeat lookups when we already proved that
        no +N badge exists.
        """
        if self.media_type not in ("vod","series") or not isinstance(item,dict):return False
        raw=str(item.get("certification") or item.get("age_rating") or "").strip()
        shown=display_certification(raw) if raw else ""
        if raw:
            item["certification"]=raw;item["age_rating"]=raw
            if shown:
                item["_age_rating_checked"]=True
                self._age_cache_put(item,raw,True)
                return True
            # Non-displayable text is unresolved, even if an older build marked
            # it checked.  Do not persist that stale terminal state into R227.
            item.pop("_age_rating_checked",None)
        elif item.get("_age_rating_checked"):
            self._age_cache_put(item,"",True)
            return True
        checked,cached=self._age_cache_get(item)
        if not checked:return False
        item["_age_rating_checked"]=True
        if cached:
            item["certification"]=cached;item["age_rating"]=cached
        else:
            # A cached canonical negative must not resurrect an old provider NR.
            item.pop("certification",None);item.pop("age_rating",None)
        return True

    def _page_visual_valid_path(self,path):
        value=str(path or "")
        if not value or not os.path.isfile(value):
            return ""
        name=os.path.basename(value).lower()
        if "placeholder" in name or name.startswith(("poster_movie","poster_series","placeholder_live")):
            return ""
        try:
            if os.path.getsize(value)<=100:return ""
        except Exception:return ""
        return value

    def _page_visual_get(self,item):
        if self.media_type not in ("vod","series") or not isinstance(item,dict):
            return {}
        key=self._page_visual_key(item)
        if not key:return {}
        try:
            row=dict(self._page_visual_ram.get(key) or {})
            if not row:return {}
            display=self._page_visual_valid_path(row.get("display"))
            poster=self._page_visual_valid_path(row.get("poster"))
            palette=self._page_visual_valid_path(row.get("palette"))
            card=self._page_visual_valid_path(row.get("card"))
            backdrop=self._page_visual_valid_path(row.get("backdrop"))
            if not (display or poster or backdrop):
                self._page_visual_ram.pop(key,None)
                return {}
            out={}
            if display:out["display"]=display
            if poster:out["poster"]=poster
            if palette:out["palette"]=palette
            if card:out["card"]=card
            if backdrop:out["backdrop"]=backdrop
            if row.get("provider_locked"):out["provider_locked"]=True
            self._page_visual_ram.move_to_end(key)
            return out
        except Exception as exc:
            optional_failure("ui.page_visual_get",exc)
            return {}

    def _page_visual_put(self,item,display=None,poster=None,palette=None,card=None,backdrop=None,provider_locked=None):
        if self.media_type not in ("vod","series") or not isinstance(item,dict):
            return
        key=self._page_visual_key(item)
        if not key:return
        try:
            row=dict(self._page_visual_ram.get(key) or {})
            for field,value in (("display",display),("poster",poster),("palette",palette),("card",card),("backdrop",backdrop)):
                valid=self._page_visual_valid_path(value)
                if valid:row[field]=valid
            if provider_locked is not None:
                row["provider_locked"]=bool(provider_locked)
            if not (self._page_visual_valid_path(row.get("display")) or self._page_visual_valid_path(row.get("poster")) or self._page_visual_valid_path(row.get("backdrop"))):
                return
            self._page_visual_ram[key]=row
            self._page_visual_ram.move_to_end(key)
            while len(self._page_visual_ram)>int(self._page_visual_ram_limit or 512):
                self._page_visual_ram.popitem(last=False)
        except Exception as exc:
            optional_failure("ui.page_visual_put",exc)

    def _remember_grid_visual(self,slot,display=None,poster=None,palette=None,card=None,backdrop=None,provider_locked=None):
        try:
            pos=int(slot)
            if pos<0 or pos>=len(self.grid_items):return
            item=self.grid_items[pos]
            if display is None:display=(getattr(self,"_grid_slot_paths",{}) or {}).get(pos)
            if palette is None:palette=(getattr(self,"_grid_palette_sources",{}) or {}).get(pos)
            if card is None:card=(getattr(self,"_grid_card_paths",{}) or {}).get(pos)
            # R37: a visual slot is not an identity.  Stamp the exact portal +
            # content key that owns the pixels currently painted in this slot so
            # Player can never inherit a stale poster from an earlier title.
            key=self._page_visual_key(item)
            if key:
                if not isinstance(getattr(self,"_grid_slot_identities",None),dict):self._grid_slot_identities={}
                self._grid_slot_identities[pos]=key
            self._page_visual_put(item,display=display,poster=poster,palette=palette,card=card,backdrop=backdrop,provider_locked=provider_locked)
        except Exception as exc:
            optional_failure("ui.page_visual_remember",exc)

    def _visible_player_poster_path(self,item=None,index=None):
        """Return a poster that is proven to belong to the selected content.

        R37 identity lock: slot numbers are recycled while the user navigates.
        A path from slot N is therefore accepted only when that slot is stamped
        with the same portal-scoped content key as the item being played.
        """
        try:
            pos=int(self.index if index is None else index)
        except Exception:
            pos=0
        try:
            current=item if isinstance(item,dict) else (self.grid_items[pos] if 0<=pos<len(self.grid_items) else {})
            visual=self._page_visual_get(current) if isinstance(current,dict) else {}
            current_key=self._page_visual_key(current) if isinstance(current,dict) else ""
            slot_key=str((getattr(self,"_grid_slot_identities",{}) or {}).get(pos) or "")
            candidates=[
                (visual or {}).get("poster"),
                (visual or {}).get("display"),
            ]
            if isinstance(current,dict):
                handed_key=str(current.get("_player_poster_identity") or "")
                if not handed_key or handed_key==current_key:
                    candidates.extend((current.get("_player_poster"),current.get("_ultra_poster_source"),current.get("_adaptive_source_local")))
            if current_key and slot_key==current_key:
                candidates.extend(((getattr(self,"_grid_slot_paths",{}) or {}).get(pos),(getattr(self,"_grid_palette_sources",{}) or {}).get(pos)))
            for candidate in candidates:
                path=str(candidate or "").strip()
                if not path or not os.path.isfile(path):continue
                try:
                    if os.path.getsize(path)<=256:continue
                except Exception:
                    continue
                bn=os.path.basename(path).lower()
                if "placeholder" in bn or bn.startswith("poster_movie") or bn.startswith("poster_series"):continue
                if isinstance(current,dict) and current_key:
                    current["_player_poster_identity"]=current_key
                return path
        except Exception as exc:
            optional_failure("ui.visible_player_poster",exc)
        return ""
