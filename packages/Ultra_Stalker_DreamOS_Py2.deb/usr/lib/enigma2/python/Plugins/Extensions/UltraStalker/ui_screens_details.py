# -*- coding: utf-8 -*-
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str, int, max, min, us_casefold, us_func
threading = _us_env.threading
re = _us_env.re
"""Content details screen extracted from ui.py without changing class behavior."""

from .performance_trace import trace as _perf_trace
from .adaptive_mode import accent_hex
from .detail_poster import square_poster_bundle
from . import _
from .ui_floating_notice import show_notice
from .age_rating import display_certification
from .localization import current_language
from Screens.Screen import Screen
from .ui_async import AsyncScreenMixin
from .ui_image_loader import ImageLoaderMixin
from .ui_transition import TransitionMixin
from .ui_fixed_adaptive import fixed_home_assets, cleanup_legacy_application_outputs
time = _us_env.time
json = _us_env.json
import tempfile
os = _us_env.os
hashlib = _us_env.hashlib
import gc
import unicodedata
import weakref
from .core.runtime_log import diagnostic_breadcrumb as _ui_diag
from .core.call_compat import call_compatible
from .log import diagnostic_failure
from .persistent_cache import durable_view_path
from .tmdb import TMDBClient
from .trailer_runtime import trailer_from_rows, resolve_youtube_trailer
from .fanart import fetch_artwork as _fanart_fetch
from .storage import load_api_keys
from .ui_dynamic_chrome import canonical_dynamic_details_key
from .ui_settings_inline_choice import SettingsInlineChoiceOverlay
from .ui_parts.catalog import strip_arabic_tashkeel as _shared_strip_arabic_tashkeel
from .ui_parts.catalog import clean_person_name as _clean_person_name

from twisted.internet import reactor
_DETAILS_TITLE_LOGO_API = None
from .label_align import halign as _lbl_h, valign as _lbl_v

def _details_title_logo_api():
    global _DETAILS_TITLE_LOGO_API
    if _DETAILS_TITLE_LOGO_API is None:
        from .title_logo_runtime import valid_ultra_title_logo
        from .title_logo_ultra import resolve_ultra_title_logo, ultra_title_logo_cached
        _DETAILS_TITLE_LOGO_API = (valid_ultra_title_logo, resolve_ultra_title_logo, ultra_title_logo_cached)
    return _DETAILS_TITLE_LOGO_API

def valid_ultra_title_logo(*args, **kwargs):
    return _details_title_logo_api()[0](*args, **kwargs)
def resolve_ultra_title_logo(*args, **kwargs):
    return _details_title_logo_api()[1](*args, **kwargs)
def ultra_title_logo_cached(*args, **kwargs):
    return _details_title_logo_api()[2](*args, **kwargs)

DETAIL_SKIN = ""


def _details_backdrop_truth(path):
    """Physical Details truth: a real validated landscape HDD master only."""
    try:
        from .artwork_v2 import _valid_backdrop
        return bool(_valid_backdrop(str(path or "")))
    except Exception:
        return False

def _details_menu_scrim_skin(skin):
    from .wqhd_layout import scale_skin as _scale_fragment
    value=str(skin or "")
    if 'name="hero_note"' not in value:
        note='\n <widget name="hero_note" position="850,620" size="1018,38" font="Regular;21" halign="right" valign="center" foregroundColor="#ffffff" shadowColor="#000000" shadowOffset="2,2" transparent="1" zPosition="30" noWrap="1"/>\n'
        value=value.replace('</screen>',_scale_fragment(note)+'</screen>',1)
    if 'name="settings_menu_list"' not in value:
        menu='\n <widget name="settings_menu_list" position="2000,0" size="1,1" foregroundColor="#ffffff" foregroundColorSelected="#ffffff" selectionPixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/portal_selection_clear.png" scrollbarMode="showNever" transparent="1" zPosition="30" />\n'
        value=value.replace('</screen>',_scale_fragment(menu)+'</screen>',1)
    if 'name="settings_menu_scrim"' in value:
        return value
    widget='\n <widget name="settings_menu_scrim" position="0,0" size="1920,1080" alphatest="blend" scale="1" transparent="1" zPosition="29"/>\n'
    marker='<widget name="settings_menu_list"'
    pos=value.find(marker)
    if pos>=0:
        return value[:pos]+_scale_fragment(widget)+value[pos:]
    return value.replace('</screen>',_scale_fragment(widget)+'</screen>',1)


def configure_details_screen(**deps):
    globals().update(deps)
    for _mixin_module in _MIXIN_MODULES:
        _mixin_module.__dict__.update(deps)
    if "DETAIL_SKIN" in deps:
        ContentDetailsScreen.skin = _details_menu_scrim_skin(deps["DETAIL_SKIN"])


def _visual_source_fingerprint(path):
    """Cheap binding for reproducible Details derivatives to their poster source."""
    try:
        path=os.path.realpath(str(path or ""))
        if not path or not os.path.isfile(path):
            return ""
        st=os.stat(path)
        mtime_ns=getattr(st,"st_mtime_ns",int(float(st.st_mtime)*1000000000))
        return hashlib.sha1((path+"|%s|%s"%(int(mtime_ns),int(st.st_size))).encode("utf-8","ignore")).hexdigest()
    except Exception:
        return ""


_ARAB_CAST_COUNTRY_TOKENS = {
    "EG","LB","SA","AE","KW","QA","BH","OM","JO","SY","IQ","PS","YE","MA","DZ","TN","LY","SD"
}


def _details_is_arabic_work(data, visible_title=""):
    row=data if isinstance(data,dict) else {}
    if re.search(r"[\u0600-\u06ff]",str(visible_title or "")):
        return True
    for key in ("original_language","language","lang","audio_language"):
        raw=str(row.get(key) or "").strip().lower().replace("_","-")
        if raw=="ar" or raw.startswith("ar-"):
            return True
    country=row.get("origin_country") or row.get("country_code") or row.get("country") or row.get("production_countries") or ""
    values=[]
    if isinstance(country,(list,tuple,set)):
        values=list(country)
    else:
        values=[country]
    aliases=("egypt","lebanon","saudi","emirates","kuwait","qatar","bahrain","oman","jordan","syria","iraq","palestine","yemen","morocco","algeria","tunisia","libya","sudan")
    for value in values:
        if isinstance(value,dict):
            value=value.get("iso_3166_1") or value.get("code") or value.get("name") or ""
        raw=str(value or "").strip();upper=raw.upper();low=us_casefold(raw)
        if upper in _ARAB_CAST_COUNTRY_TOKENS or any(x in low for x in aliases):
            return True
    return False


def _clean_year_value(value):
    raw=str(value or "").strip()
    m=re.search(r"(?:19|20)\d{2}",raw)
    return m.group(0) if m else raw[:4]


def _age_rating_display(value):
    return display_certification(value)

def _detail_genre_value(item):
    """Return real content genre, never an Xtream/M3U category label in disguise."""
    row=item if isinstance(item,dict) else {}
    value=row.get("genre") or row.get("genres") or ""
    if isinstance(value,(list,tuple)):
        value=" / ".join(str(x) for x in value[:3] if str(x or "").strip())
    value=str(value or "").strip()
    # Raw M3U/Xtream catalogue rows commonly copy group/category into ``genre``.
    # That is navigation metadata, not movie/series metadata, and must not paint
    # the Details genre pill while the canonical HDD record is loading.
    if value and (row.get("_m3u_series") or row.get("_xtream")):
        norm=lambda x:re.sub(r"\s+"," ",us_casefold(str(x or "").strip()))
        current=norm(value)
        categories={norm(row.get(k)) for k in ("category_name","category","category_id","group","group_title") if row.get(k) not in (None,"")}
        if current and current in categories:
            value=""
    if not value and not (row.get("_m3u_series") or row.get("_xtream")):
        value=str(row.get("category_name") or "").strip()
    return value


DETAILS_GLASS_MENU_SKIN = """
<screen name="DetailsAdaptiveMenuScreen" position="0,0" size="1920,1080" backgroundColor="#00000000" flags="wfNoBorder">
 <widget name="frame" position="488,242" size="944,596" alphatest="blend" scale="1" transparent="1" zPosition="1"/>
 <widget name="inner" position="526,342" size="868,372" alphatest="blend" scale="1" transparent="1" zPosition="2"/>
 <widget name="title" position="552,282" size="816,48" font="Regular;32" foregroundColor="#ffffff" transparent="1" zPosition="4" shadowColor="#000000" shadowOffset="1,1"/>
 <widget name="list" position="558,360" size="804,336" scrollbarMode="showNever" transparent="1" zPosition="5"/>
 <widget name="hint" position="552,766" size="816,30" font="Regular;17" halign="center" foregroundColor="#a9c5d3" transparent="1" zPosition="5" shadowColor="#000000" shadowOffset="1,1"/>
</screen>
"""

def _strip_arabic_tashkeel(value):
    """Details description display-only Arabic tashkeel cleanup."""
    return _shared_strip_arabic_tashkeel(value)


class DetailsAdaptiveMenuScreen(Screen):
    """Compact copy of the adaptive subtitle chooser, sized for Details actions."""
    skin=DETAILS_GLASS_MENU_SKIN
    def __init__(self,session,title,choices,source_path=""):
        us_func(Screen.__init__)(self,session)
        from .services.player_native import SubtitleGlassList, _subtitle_glass_assets
        self._glass_builder=_subtitle_glass_assets
        self._choices=[(_(str(c[0])),c[1]) if isinstance(c,(tuple,list)) and len(c)>1 else c for c in list(choices or [])]
        self._source_path=str(source_path or "")
        self["frame"]=Pixmap();self["inner"]=Pixmap()
        self["title"]=Label(_(str(title or "Options")))
        self["hint"]=Label(_("OK  Select   •   BACK  Close   •   UP / DOWN  Navigate"))
        self["list"]=SubtitleGlassList(self._choices,width=804,item_height=84)
        self["actions"]=ActionMap(["OkCancelActions","DirectionActions"],{
            "ok":self.accept,"cancel":self.cancel_close,"up":self.up,"down":self.down,
            "left":self.page_up,"right":self.page_down},-2)
        self["list"].onSelectionChanged.append(self._selection_changed)
        _perf_trace("details_components_ready")
        self.onLayoutFinish.append(self._layout_ready)

    def _layout_ready(self):
        # Reuse the subtitle chooser recipe, but render exact native popup sizes.
        # Details actions deliberately use 66px cards inside 84px list rows: the
        # 18px breathing room keeps all four options visually separated and
        # evenly aligned without changing the shared subtitle/player renderer.
        # The old Details menu clipped 1280x800 subtitle panels into 940x560 widgets,
        # which produced the broken/discontinuous borders visible on receiver.
        base=self._glass_builder(self._source_path,944,804,66)
        assets=dict(base or {})
        try:
            from PIL import Image as _DImg
            cache=os.path.join(PERSISTENT_GENERATED_DIR,"details_menu_exact")
            os.makedirs(cache,mode=0o700,exist_ok=True)
            for key,size in (("frame",(944,596)),("inner",(868,372))):
                src=str((base or {}).get(key) or "")
                if not src or not os.path.isfile(src):continue
                stamp=str(int(os.path.getmtime(src)))
                target=os.path.join(cache,hashlib.sha1((src+"|"+stamp+"|"+key+"|exact-v1").encode("utf-8","ignore")).hexdigest()[:20]+".png")
                if not (os.path.isfile(target) and os.path.getsize(target)>256):
                    with _DImg.open(src) as im:
                        im=im.convert("RGBA").resize(size,getattr(getattr(_DImg,"Resampling",_DImg),"LANCZOS",getattr(_DImg,"LANCZOS",1)))
                        # Atomic write: a cut-off save must never leave a corrupt PNG
                        # that the isfile() check above would then trust forever.
                        _tmp=target+".tmp.%d.%d"%(os.getpid(),threading.get_ident())
                        try:
                            im.save(_tmp,"PNG");os.replace(_tmp,target)
                        finally:
                            try:
                                if os.path.exists(_tmp):os.unlink(_tmp)
                            except Exception:pass
                assets[key]=target
        except Exception as exc:optional_failure("ui.details_menu_exact_assets",exc)
        for name,key in (("frame","frame"),("inner","inner")):
            try:
                path=assets.get(key)
                if path and self[name].instance is not None:
                    self[name].instance.setPixmapFromFile(path);self[name].show()
            except Exception as exc:optional_failure("ui.details_menu_panel",exc)
        self["list"].set_assets(assets.get("row"),assets.get("row_selected"))
        try:
            if self["list"].instance is not None:self["list"].instance.setSelectionEnable(0)
        except Exception:pass
        self["list"].set_choices(self._choices,0)

    def _selection_changed(self):
        try:self["list"].selection_changed()
        except Exception as exc:optional_failure("ui.details_menu_selection",exc)
    def up(self):
        try:self["list"].up()
        except Exception:pass
    def down(self):
        try:self["list"].down()
        except Exception:pass
    def page_up(self):
        try:self["list"].pageUp()
        except Exception:pass
    def page_down(self):
        try:self["list"].pageDown()
        except Exception:pass
    def accept(self):
        choice=self["list"].selected_choice()
        if choice is not None:self.close(choice)
    def cancel_close(self):self.close(None)


HERO_PIN_TOAST_SKIN = """
<screen name="HeroPinToastScreen" position="0,0" size="1920,1080" backgroundColor="#00000000" flags="wfNoBorder">
 <widget name="panel" position="580,420" size="760,214" alphatest="blend" scale="1" transparent="1" zPosition="1"/>
 <widget name="check" position="624,486" size="64,64" alphatest="blend" scale="1" transparent="1" zPosition="3"/>
 <widget name="title" position="716,468" size="560,40" font="Regular;28" foregroundColor="#ffffff" transparent="1" zPosition="4" shadowColor="#000000" shadowOffset="1,1"/>
 <widget name="message" position="716,516" size="560,58" font="Regular;19" foregroundColor="#b9d7e6" transparent="1" valign="top" zPosition="4" shadowColor="#000000" shadowOffset="1,1"/>
</screen>
"""

class HeroPinToastScreen(Screen):
    """Small self-closing Ultra Stalker notice for explicit Hero selection."""
    skin=HERO_PIN_TOAST_SKIN
    def __init__(self,session,title,message,timeout_ms=1800):
        us_func(Screen.__init__)(self,session)
        self["panel"]=Pixmap();self["check"]=Pixmap()
        self["title"]=Label(_(str(title or "Hero selected")))
        self["message"]=Label(_(str(message or "")))
        self["actions"]=ActionMap(["OkCancelActions"],{"ok":self.close,"cancel":self.close},-2)
        self._timeout=max(900,int(timeout_ms or 1800));self._timer=eTimer();self._timer_conn=None
        try:self._timer_conn=self._timer.timeout.connect(self.close)
        except Exception:self._timer.callback.append(self.close)
        self.onLayoutFinish.append(self._ready)
        self.onClose.append(self._cleanup)
    def _ready(self):
        try:
            from .ui_icon_menu import _us_fit_png
            from .wqhd_layout import wh as _wqhd_wh
            pw,ph=_wqhd_wh(760,214)
            panel=_us_fit_png(asset("us66_neutral_panel.png"),pw,ph,True)
            if panel and os.path.isfile(panel) and self["panel"].instance is not None:
                self["panel"].instance.setPixmapFromFile(panel);self["panel"].show()
        except Exception:pass
        try:
            from .ui_icon_menu import _us_fit_png
            from .wqhd_layout import wh as _wqhd_wh
            iw,ih=_wqhd_wh(64,64)
            icon=_us_fit_png(asset("settings_icons_40/progress_safe.png"),iw,ih,False)
            if icon and os.path.isfile(icon) and self["check"].instance is not None:
                self["check"].instance.setPixmapFromFile(icon);self["check"].show()
        except Exception:pass
        try:self._timer.start(self._timeout,True)
        except Exception:pass
    def _cleanup(self):
        try:self._timer.stop()
        except Exception:pass
        try:
            if self._timer_conn is not None:self._timer_conn.disconnect()
        except Exception:pass

# Split: related method groups live in ui_details_mixin_*.py modules. They are imported here, after every module-level helper above exists,
# and listed BEFORE the other bases so they override them exactly like the methods that used to sit in this class body.
from .ui_details_mixin_lifecycle import DetailsLifecycleMixin
from .ui_details_mixin_description import DetailsDescriptionMixin
from .ui_details_mixin_provider import DetailsProviderMixin
from .ui_details_mixin_layout import DetailsLayoutMixin
from .ui_details_mixin_text import DetailsTextMixin
from .ui_details_mixin_chrome import DetailsChromeMixin
from .ui_details_mixin_jobs import DetailsJobsMixin
from .ui_details_mixin_tmdb import DetailsTmdbMixin
from .ui_details_mixin_menus import DetailsMenusMixin
from .ui_details_mixin_hero import DetailsHeroMixin
from .ui_details_mixin_downloads import DetailsDownloadsMixin
from .ui_details_mixin_info import DetailsInfoMixin
from .ui_details_mixin_trailer import DetailsTrailerMixin
from .ui_details_mixin_play import DetailsPlayMixin
import sys as _split_sys
_MIXIN_MODULES = tuple(_split_sys.modules[_m.__module__] for _m in (DetailsLifecycleMixin, DetailsDescriptionMixin, DetailsProviderMixin, DetailsLayoutMixin, DetailsTextMixin, DetailsChromeMixin, DetailsJobsMixin, DetailsTmdbMixin, DetailsMenusMixin, DetailsHeroMixin, DetailsDownloadsMixin, DetailsInfoMixin, DetailsTrailerMixin, DetailsPlayMixin,))


class ContentDetailsScreen(
    DetailsLifecycleMixin,
    DetailsDescriptionMixin,
    DetailsProviderMixin,
    DetailsLayoutMixin,
    DetailsTextMixin,
    DetailsChromeMixin,
    DetailsJobsMixin,
    DetailsTmdbMixin,
    DetailsMenusMixin,
    DetailsHeroMixin,
    DetailsDownloadsMixin,
    DetailsInfoMixin,
    DetailsTrailerMixin,
    DetailsPlayMixin,
    Screen,
    AsyncScreenMixin,
    ImageLoaderMixin,
    TransitionMixin,
):
    skin = DETAIL_SKIN

    def __init__(self, session, profile, client, media_type, item):
        _perf_trace("details_constructor_begin")
        from .manual_identity import apply_choice
        item=apply_choice(profile,media_type,item)
        us_func(Screen.__init__)(self, session)
        self._async_init(); self.onClose.append(self._stop_async); self.onClose.append(self._image_stop); self.onClose.append(self._release_details_pixmaps); self.onClose.append(self._runtime_details_close)
        # R123: trailer resolution owns its own worker lane. Details uses the
        # shared _busy flag for provider/TMDb/series enrichment, so tying the red
        # Trailer key to that flag can make the key appear dead while harmless
        # background metadata work is still running.
        self._trailer_busy=False
        self._trailer_token=0
        self._trailer_cancel_event=threading.Event()
        self.onClose.append(self._cancel_trailer_request)
        self._ui_diag_open_mono=time.monotonic();_ui_diag("ui_open",screen="details",media_type=media_type)
        self.profile=profile; self.client=client; self.media_type=media_type
        self._runtime_artwork_logged=False
        _runtime_endurance_log("details_open",media_type=self.media_type)
        _raw_item=dict(item) if isinstance(item,dict) else {}
        _fast_open=bool(_raw_item.pop("_ultra_fast_open",False))
        _fast_bundle=_raw_item.pop("_ultra_fast_bundle",{}) if isinstance(_raw_item,dict) else {}
        _handoff_detail_snapshot=_raw_item.pop("_ultra_detail_snapshot",{}) if isinstance(_raw_item,dict) else {}
        _search_seed_snapshot=_raw_item.pop("_search_seed_snapshot",{}) if isinstance(_raw_item,dict) else {}
        _search_seed_trusted=bool(_raw_item.pop("_search_seed_trusted",False)) if isinstance(_raw_item,dict) else False
        self._search_visual_peers=_raw_item.pop("_search_visual_peers",[]) if isinstance(_raw_item,dict) else []
        self._search_force_complete=bool(_raw_item.pop("_search_force_complete",False)) if isinstance(_raw_item,dict) else False
        self._search_peer_sync_fp=""
        self._is_xtream_item=bool(_raw_item.get("_xtream"))
        _handoff_clean_backdrop=str(_raw_item.get("_details_clean_backdrop_source") or "")
        _handoff_clean_locked=bool(_raw_item.get("_details_clean_backdrop_locked") and _handoff_clean_backdrop and os.path.isfile(_handoff_clean_backdrop))
        # Dual-source policy: preserve raw provider artwork/metadata for every
        # Movies/Series provider. TMDB may upgrade it later, but never erase it.
        self._portal_item = dict(_raw_item)
        item = dict(_raw_item)
        # release: Series entered from Poster Grid gets an immediate shell from
        # the already-visible card/backdrop. Persistent metadata is allowed to
        # enrich after layout instead of blocking Screen construction on HDD I/O.
        # Metadata is tiny compared with artwork.  Even the fast-open path reads
        # the one shared HDD snapshot so Portal/Xtream/M3U paint identical fields
        # on first frame instead of waiting for a later provider/network pass.
        # R99 maintenance: Cinematic/BG can hand the exact already-indexed
        # canonical record into Details.  Reuse it on the first frame and touch
        # HDD only when there is no compatible RAM handoff.
        if isinstance(_handoff_detail_snapshot,dict) and _handoff_detail_snapshot:
            try:
                self._local_detail_cache=(dict(_handoff_detail_snapshot) if identity_cache_compatible(self._portal_item,_handoff_detail_snapshot) else {})
            except Exception:
                self._local_detail_cache={}
        else:
            self._local_detail_cache={}
        if not self._local_detail_cache:
            self._local_detail_cache = load_shared_detail_snapshot(profile,media_type,self._portal_item)
        if isinstance(self._local_detail_cache,dict) and self._local_detail_cache and not identity_cache_compatible(self._portal_item,self._local_detail_cache):
            self._local_detail_cache=dict(self._local_detail_cache)
            self._local_detail_cache["_identity_stale"]=True
            self._local_detail_cache.pop("tmdb_id",None)
            self._local_detail_cache.pop("poster_local",None)
            self._local_detail_cache.pop("backdrop_local",None)
            # A rejected identity must not keep poisoning Details through its old
            # UK/cast/genre/overview overlay after the id itself was discarded.
            self._local_detail_cache.pop("item_overlay",None)
        if isinstance(_search_seed_snapshot,dict) and _search_seed_snapshot.get("tmdb_id"):
            try:
                if _search_seed_trusted or identity_cache_compatible(self._portal_item,_search_seed_snapshot):
                    current=dict(self._local_detail_cache or {})
                    # Search already proved title/year/media compatibility. Keep
                    # that trust scoped to presentation/cache identity only; the
                    # selected copy still owns its profile/id/cmd for playback.
                    merged=dict(current);merged.update(_search_seed_snapshot)
                    self._local_detail_cache=merged
                    if _search_seed_trusted:
                        self._portal_item["_ultra_search_verified_tmdb_id"]=_search_seed_snapshot.get("tmdb_id")
            except Exception as exc:optional_failure("ui.search_peer_seed",exc)
        self._persistent_visual_bundle = square_poster_bundle(
            _fast_bundle if _fast_open and isinstance(_fast_bundle,dict)
            else _load_visual_bundle(profile,media_type,self._portal_item,self._local_detail_cache))
        _pvb=self._persistent_visual_bundle if isinstance(self._persistent_visual_bundle,dict) else {}
        # Component-level hard locks.  Each visual becomes immutable as soon as
        # its final HDD file exists; we never wait for every other component.
        self._persistent_poster_locked=bool(_pvb.get("poster_final") or (_pvb.get("poster") and os.path.isfile(str(_pvb.get("poster") or ""))))
        self._persistent_detail_poster_locked=bool(_pvb.get("detail_poster_final") or (_pvb.get("detail_poster") and os.path.isfile(str(_pvb.get("detail_poster") or ""))))
        self._persistent_backdrop_source_locked=bool(_pvb.get("backdrop_source_final") or (_pvb.get("backdrop") and os.path.isfile(str(_pvb.get("backdrop") or ""))))
        self._persistent_backdrop_locked=bool(_pvb.get("backdrop_final") or (_pvb.get("backdrop_present") and os.path.isfile(str(_pvb.get("backdrop_present") or ""))))
        # release: a legacy/prepared presentation backdrop is never allowed to
        # freeze Details against a newer verified canonical TMDB/Fanart backdrop.
        # Poster locks remain untouched. Backdrop presentation may be refreshed
        # from the same canonical master whenever the resolver produces one.
        if self.media_type in ("vod","series") and not _handoff_clean_locked:
            self._persistent_backdrop_source_locked=False
            self._persistent_backdrop_locked=False
        _pvb_chrome=_pvb.get("chrome") if isinstance(_pvb.get("chrome"),dict) else {}
        self._persistent_adaptive_locked=bool(
            _pvb.get("adaptive_final") or _pvb.get("details_adaptive_ready") or
            (_pvb.get("theme") and os.path.isfile(str(_pvb.get("theme") or "")) and
             _pvb_chrome.get("panel_detail") and _pvb_chrome.get("overview_detail"))
        )
        self._persistent_visual_frozen=bool(self._persistent_poster_locked and self._persistent_backdrop_locked and self._persistent_adaptive_locked)
        if isinstance(self._local_detail_cache,dict) and self._local_detail_cache:
            merged=dict(self._portal_item)
            # Metadata/artwork IDs are local-first, but playback command and the
            # portal display identity always remain authoritative.
            cached_item=self._local_detail_cache.get("item_overlay") or {}
            if self._local_detail_cache.get("_details_authority_ready"):
                # First frame uses the canonical raw TMDb fields directly.  The
                # legacy item_overlay was a compatibility copy and could retain
                # stale/cleaned values from an older language policy.
                cached_item={}
                _genres=self._local_detail_cache.get("genres") or []
                _cast=self._local_detail_cache.get("cast") or []
                _directors=self._local_detail_cache.get("directors") or []
                _writers=self._local_detail_cache.get("writers") or []
                if self._local_detail_cache.get("overview"):cached_item["description"]=self._local_detail_cache.get("overview")
                if self._local_detail_cache.get("year") not in (None,""):cached_item["year"]=self._local_detail_cache.get("year")
                if self._local_detail_cache.get("runtime") not in (None,""):cached_item["time"]=self._local_detail_cache.get("runtime")
                if self._local_detail_cache.get("number_of_seasons") not in (None,""):cached_item["number_of_seasons"]=self._local_detail_cache.get("number_of_seasons")
                if self._local_detail_cache.get("number_of_episodes") not in (None,""):cached_item["number_of_episodes"]=self._local_detail_cache.get("number_of_episodes")
                if _genres:cached_item["genre"]=" / ".join(str(x) for x in _genres[:3] if str(x or "").strip())
                if _cast:cached_item["actors"]=(", ".join(str(x) for x in _cast[:8]) if isinstance(_cast,(list,tuple)) else str(_cast))
                if _directors:cached_item["director"]=(", ".join(str(x) for x in _directors[:3]) if isinstance(_directors,(list,tuple)) else str(_directors))
                if _writers:cached_item["writer"]=(", ".join(str(x) for x in _writers[:4]) if isinstance(_writers,(list,tuple)) else str(_writers))
                _countries=self._local_detail_cache.get("countries") or []
                if _countries:cached_item["country"]=(str(_countries[0]) if isinstance(_countries,(list,tuple)) else str(_countries))
            if isinstance(cached_item,dict):
                for k,v in cached_item.items():
                    if v not in (None,"",[],{}): merged[k]=v
            if self._local_detail_cache.get("tmdb_id"):
                merged["_locked_tmdb_id"]=self._local_detail_cache.get("tmdb_id")
                merged["_locked_tmdb_type"]=self._local_detail_cache.get("media_type")
            item=merged
        self.item=item
        self._backdrop_token=0; self._backdrop_jobs=queue.Queue()
        self._backdrop_rank=0; self._backdrop_displayed_path=""; self._backdrop_present_pending=""
        self._portal_backdrop_loaded=False
        self._portal_backdrop_source_local=str(item.get("_backdrop_source_local") or item.get("_cin_provider_backdrop_local") or "") if isinstance(item,dict) else ""
        self._portal_backdrop_present_local=str(item.get("_backdrop_present_local") or "") if isinstance(item,dict) else ""
        self._details_backdrop_authority_source=_handoff_clean_backdrop if _handoff_clean_locked else ""
        self._details_backdrop_authority_locked=bool(_handoff_clean_locked)
        if self._details_backdrop_authority_locked:
            try:
                _authority_fp=_visual_source_fingerprint(self._details_backdrop_authority_source)
                if str(self._persistent_visual_bundle.get("backdrop_present_source_fp") or "")!=_authority_fp:
                    self._persistent_visual_bundle.pop("backdrop_present",None)
                    self._persistent_visual_bundle.pop("backdrop_present_source_fp",None)
                self._persistent_visual_bundle["backdrop"]=self._details_backdrop_authority_source
            except Exception as exc:optional_failure("ui.r197_handoff_backdrop_bundle_guard",exc)
        if self._portal_backdrop_source_local and not os.path.isfile(self._portal_backdrop_source_local):self._portal_backdrop_source_local=""
        if self._portal_backdrop_present_local and not os.path.isfile(self._portal_backdrop_present_local):self._portal_backdrop_present_local=""
        # Older handoff code sometimes passed the already-prepared 1620x620 file
        # back as if it were a canonical source.  That path then got cropped a
        # second time after Player return.  Keep prepared and canonical identities
        # separate from the moment this screen is constructed.
        if self._portal_backdrop_source_local and os.path.basename(self._portal_backdrop_source_local).startswith("us221_detail_"):
            if not self._portal_backdrop_present_local:self._portal_backdrop_present_local=self._portal_backdrop_source_local
            self._portal_backdrop_source_local=""
        self._details_cancel_event=threading.Event()
        self._details_worker_futures=set()
        self._adaptive_palette_locked=False; self._adaptive_source_local=""; self._details_visual_state={}
        self._poster_laser_color_hint=str(accent_hex(item.get("adaptive_accent") or item.get("adaptive_primary") or item.get("_adaptive_accent") or "")) if isinstance(item,dict) else ""
        self._adaptive_authoritative_source=str(item.get("_ultra_palette_source") or item.get("_adaptive_source_local") or item.get("_player_poster") or "") if isinstance(item,dict) else ""
        if self._adaptive_authoritative_source and not os.path.isfile(self._adaptive_authoritative_source):
            self._adaptive_authoritative_source=""
        self._poster_authoritative_source=str(item.get("_ultra_poster_source") or item.get("_player_poster") or item.get("_cin_provider_poster_local") or self._adaptive_authoritative_source or "") if isinstance(item,dict) else ""
        if self._poster_authoritative_source and not os.path.isfile(self._poster_authoritative_source):
            self._poster_authoritative_source=""
        self._entry_visible_poster_locked=bool(
            isinstance(item,dict) and item.get("_ultra_visible_poster_locked") and
            self._poster_authoritative_source and os.path.isfile(self._poster_authoritative_source)
        )
        self._adaptive_token=0; self._adaptive_jobs=queue.Queue(); self._adaptive_pending_source=""
        self._sharp_detail_pending=set(); self._sharp_detail_exact_sources=set()
        self._tmdb_token=0; self._tmdb_jobs=queue.Queue(); self._tmdb_data=None
        # Stage 1: remember which verified external identity currently owns the
        # visual package. Provider/Grid art may paint first, but it is provisional.
        self._canonical_visual_tmdb_id=""; self._canonical_visual_media_type=""
        self._xtream_auto_retry_count=0;self._xtream_auto_retry_timer=eTimer();self._xtream_auto_retry_conn=None
        try:self._xtream_auto_retry_conn=self._xtream_auto_retry_timer.timeout.connect(self._xtream_auto_retry)
        except Exception:self._xtream_auto_retry_timer.callback.append(self._xtream_auto_retry)
        self.onClose.append(self._stop_xtream_auto_retry)
        # Ultra-owned title-logo path. Network requests are display-sized and decoded only after safety guards.
        self._title_logo_token=0; self._title_logo_jobs=queue.Queue(); self._title_logo_pending=""
        self._title_logo_future=None;self._title_logo_target_size=None;self._title_logo_cache_target="";self._cast_language_token=0
        self._artwork_gap_retry=set()
        # Explicit Hero pin follows the proven release retry behaviour: one press
        # waits briefly for the already-running backdrop cache to expose its HDD
        # file, then prepares the Hero in background.
        self._hero_pin_token=0;self._hero_pin_future=None
        self._hero_pin_attempts=0;self._hero_pin_timer=eTimer();self._hero_pin_conn=None
        try:self._hero_pin_conn=self._hero_pin_timer.timeout.connect(self._pin_current_as_home_hero_retry)
        except Exception:self._hero_pin_timer.callback.append(self._pin_current_as_home_hero_retry)
        self.onClose.append(self._stop_hero_pin_timer)
        self._backdrop_watch_timer=eTimer(); self._backdrop_watch_conn=None
        try:self._backdrop_watch_conn=self._backdrop_watch_timer.timeout.connect(self._poll_recovered_backdrop)
        except Exception:self._backdrop_watch_timer.callback.append(self._poll_recovered_backdrop)
        self.onClose.append(self._stop_backdrop_watch)
        self.onClose.append(self._stop_details_ui_hooks)
        _clean_titles=bool(load_settings().get("clean_titles",True))
        raw_name=str(item.get("_raw_name") or item.get("name") or item.get("title") or "Content")
        cleaned_name=_catalogue_title(raw_name) if _clean_titles else raw_name.strip()
        self._server_display_name=_clean_display_text(cleaned_name or raw_name,120)
        name=self._server_display_name
        self["title"] = Label(_("MOVIE") if media_type=="vod" else _("SERIES"))
        self["subtitle"] = Label(str(item.get("genre") or item.get("category_name") or (_("Movies") if media_type=="vod" else _("Series"))).strip()[:70])
        self["name"] = Label(name)
        self._title_fit_timer=eTimer();self._title_fit_conn=None;self._title_fit_pass=0
        self._series_count_timer=eTimer();self._series_count_conn=None;self._series_count_pending=False
        try:self._series_count_conn=self._series_count_timer.timeout.connect(self._ensure_series_count_late)
        except Exception:self._series_count_timer.callback.append(self._ensure_series_count_late)
        self.onClose.append(self._stop_series_count_timer)
        try:self._title_fit_conn=self._title_fit_timer.timeout.connect(self._title_fit_tick)
        except Exception:self._title_fit_timer.callback.append(self._title_fit_tick)
        self.onClose.append(self._stop_title_fit_timer)
        meta=[]
        for label,key in ((_('Year'),"year"),(_('Rating'),"rating"),(_('Genre'),"genre"),(_('Duration'),"time"),(_('Season'),"season")):
            if item.get(key): meta.append("%s: %s"%(label,item.get(key)))
        progress=load_playback_progress(profile,media_type,item)
        if is_favorite(profile,media_type,item): meta.append(_("Favorite"))
        if progress.get("completed"): meta.append(_("Watched"))
        elif progress.get("duration") and progress.get("position"): meta.append(_("Resume %d%%")%min(99,int(progress["position"]*100.0/progress["duration"])))
        quality_source = " ".join(str(item.get(k) or "") for k in ("quality","resolution","format","video_quality","name","title"))
        badges=quality_badges(quality_source)
        if badges: meta.insert(0,badges)
        self["meta"] = Label("   •   ".join(meta)[:120])
        _initial_provider_desc=item.get("description") or item.get("descr") or item.get("plot") or ""
        try:
            # Same Arabic-first pick Cinematic/grids/Search use for provider text.
            from .details_authority import provider_description_for_display as _provider_desc_pick
            _initial_provider_desc=_provider_desc_pick(item) or _initial_provider_desc
        except Exception as exc:optional_failure("ui.details_initial_description_authority",exc)
        desc=_initial_provider_desc or _("Loading metadata…")
        # R262: provider synopsis is first-paint only. Provider info callbacks
        # may enrich ids/quality, but they must not alternate the visible box
        # between two provider languages while TMDb authority is resolving.
        self._provider_description_painted=bool(str(_initial_provider_desc or "").strip())
        self._description_source=str(desc or "").strip()[:2200];self._description_pages=self._make_description_pages(self._description_source);self._desc_page=0
        self["description"] = Label(self._description_pages[0] if self._description_pages else self._description_source)
        self._desc_scroll_timer=eTimer();self._desc_scroll_conn=None
        self._desc_guard_timer=eTimer();self._desc_guard_conn=None
        try:self._desc_guard_conn=self._desc_guard_timer.timeout.connect(self._ensure_description_visible)
        except Exception:self._desc_guard_timer.callback.append(self._ensure_description_visible)
        try:self._desc_scroll_conn=self._desc_scroll_timer.timeout.connect(self._auto_scroll_description)
        except Exception:self._desc_scroll_timer.callback.append(self._auto_scroll_description)
        self.onClose.append(self._stop_description_scroll)
        self.onClose.append(self._ui_diag_details_close)
        self["status"] = Label("")
        self["hero_note"] = Label("");self._hero_note_timer=eTimer();self._hero_note_conn=None
        try:self._hero_note_conn=self._hero_note_timer.timeout.connect(self._hero_note_clear)
        except Exception:self._hero_note_timer.callback.append(self._hero_note_clear)
        self.onClose.append(self._stop_hero_note_timer)
        self["dynamic_bg"] = Pixmap()
        self["cinematic_bg"] = Pixmap()
        self["cinematic_edge"] = Pixmap()
        self["poster"] = Pixmap()
        self["title_logo"] = Pixmap()
        self["settings_menu_scrim"] = Pixmap()
        try:self["settings_menu_scrim"].hide()
        except Exception:pass
        self._settings_inline_menu=SettingsInlineChoiceOverlay(self,"settings_menu_list","settings_menu_actions",asset,_,optional_failure)
        # Legacy accent_frame remains as a hidden compatibility target for old
        # cached bundles.  The visible Details border is now four tiny Labels,
        # so no 380x580 frame surface is allocated or scaled over the poster.
        self["accent_frame"] = Pixmap()
        self["poster_laser_top"] = Label("")
        self["poster_laser_bottom"] = Label("")
        self["poster_laser_left"] = Label("")
        self["poster_laser_right"] = Label("")
        self["poster_card_bg"] = Pixmap()
        self["poster_border_overlay"] = Pixmap()
        self["poster_footer_bg"] = Pixmap()
        self["panel_bg"] = Pixmap()
        self["overview_bg"] = Pixmap()
        self["cast_card_bg"] = Pixmap()
        self["quality_pill_bg"] = Pixmap()
        self["year_pill_bg"] = Pixmap()
        self["runtime_pill_bg"] = Pixmap()
        self["country_pill_bg"] = Pixmap()
        self["genre_pill_bg"] = Pixmap()
        self["tmdb_pill_bg"] = Pixmap()
        self["imdb_pill_bg"] = Pixmap()
        self["rating_ring"] = Pixmap()
        self["poster_imdb_logo"] = Pixmap()
        self["quality_logo"] = Pixmap()
        self["country_flag"] = Pixmap()
        self["runtime_icon"] = Pixmap()

        # R80: Information is rendered inside this same Details Screen, exactly
        # like the Settings inline context panel.  No child Screen/dialog is
        # created, so the real Details artwork remains visible underneath.
        for _name in ("info_scrim","info_adaptive_main","info_adaptive_poster","info_poster",
                      "info_adaptive_desc","info_adaptive_cast",
                      "info_adaptive_director","info_adaptive_writer","info_poster_rating_bg",
                      "info_imdb_logo","info_tmdb_logo","info_adaptive_extra"):
            self[_name] = Pixmap()
        self["info_title"] = Label("")
        self["info_meta"] = Label("")
        self["info_desc_label"] = Label("")
        self["info_votes"] = Label("")
        self["info_description"] = Label("")
        self["info_page"] = Label("")
        self["info_cast_label"] = Label("")
        self["info_cast"] = Label("")
        self["info_director_label"] = Label("")
        self["info_director"] = Label("")
        self["info_writer_label"] = Label("")
        self["info_writer"] = Label("")
        self["info_imdb_value"] = Label("")
        self["info_tmdb_value"] = Label("")
        self["info_left"] = Label("")
        self["info_right"] = Label("")
        self._info_inline_widgets=(
            "info_scrim","info_adaptive_main","info_adaptive_poster","info_poster","info_title",
            "info_meta","info_adaptive_desc","info_desc_label","info_description","info_page",
            "info_adaptive_cast","info_cast_label","info_cast","info_adaptive_director","info_director_label","info_director",
            "info_adaptive_writer","info_writer_label","info_writer","info_poster_rating_bg","info_imdb_logo","info_imdb_value",
            "info_tmdb_logo","info_tmdb_value","info_votes","info_adaptive_extra","info_left","info_right")
        self._info_inline_active=False
        self._info_inline_poster_path=""
        self._info_desc_pages=[]
        self._info_desc_index=0
        self._hide_information_inline(initial=True)

        # R5.239: exact Information presentation principle. These Downloads
        # widgets belong to THIS Details/Series Screen; opening the manager never
        # replaces or hides the page underneath.
        for _name in ("downloads_scrim","downloads_frame","downloads_red_dash","downloads_yellow_dash","downloads_green_dash","downloads_blue_dash"):
            self[_name]=Pixmap()
        self["downloads_title"]=Label(_("Downloads"))
        self["downloads_summary"]=Label("")
        self["downloads_list"]=IconMenuList([],width=880,item_height=80,icon_size=40,primary_font=23,secondary_font=17,row_style="download_glass")
        self["downloads_red"]=Label(_("Close"))
        self["downloads_yellow"]=Label(_("Cancel selected"))
        self["downloads_green"]=Label(_("Retry failed"))
        self["downloads_blue"]=Label(_("Remove"))
        self._downloads_inline_widgets=(
            "downloads_scrim","downloads_frame","downloads_title","downloads_summary","downloads_list",
            "downloads_red_dash","downloads_red","downloads_yellow_dash","downloads_yellow","downloads_green_dash","downloads_green",
            "downloads_blue_dash","downloads_blue")
        self._downloads_inline_active=False
        self._downloads_rows=[]
        self._downloads_rendering=False
        self._downloads_last_layout_count=-1
        self._downloads_chrome={}
        self._downloads_timer=eTimer()
        try:self._downloads_timer_conn=self._downloads_timer.timeout.connect(self._refresh_downloads_inline)
        except Exception:
            self._downloads_timer_conn=None;self._downloads_timer.callback.append(self._refresh_downloads_inline)
        self["downloads_list"].onSelectionChanged.append(self._downloads_selection_changed)
        self._hide_downloads_inline(initial=True)

        self["red_dash"] = Pixmap()
        self["green_dash"] = Pixmap()
        self["yellow_dash"] = Pixmap()
        self["blue_dash"] = Pixmap()
        self["red"] = Label(_("Trailer"))
        self["green"] = Label(_("Unfavorite") if is_favorite(profile, media_type, item) else _("Favorite"))
        self["yellow"] = Label(_("Information"))
        play_label = _("Play") if media_type == "vod" else _("Episodes")
        if media_type == "vod" and progress.get("position") and not progress.get("completed"):
            play_label = _("Resume")
        self["blue"] = Label(play_label)
        portal_imdb=item.get("rating_imdb") or item.get("imdb_rating") or ""
        _cached_tmdb_rating=(self._local_detail_cache.get("rating") if isinstance(getattr(self,"_local_detail_cache",None),dict) else "")
        try:
            _cached_tmdb_text=("%.1f"%float(_cached_tmdb_rating)) if float(_cached_tmdb_rating or 0)>0 else "--"
        except Exception:
            _cached_tmdb_text="--"
        self["rating_score"] = Label(_cached_tmdb_text)
        self["rating_source"] = Label(_("TMDB rating") if _cached_tmdb_text!="--" else _("Metadata"))
        self["imdb_text"] = Label(("★ %s"%str(portal_imdb)[:4]) if portal_imdb else "N/A")
        self["poster_imdb_value"] = Label(str(portal_imdb)[:4] if portal_imdb else "--")
        self["poster_match_text"] = Label(_("TMDb • portal metadata"))
        portal_cast=item.get("actors") or item.get("cast") or item.get("actor") or ""
        self["cast_text"] = Label(_clean_person_name(portal_cast)[:220])
        # Fast-path explicit quality before any network/runtime lookup. Scan the
        # whole portal payload (title, description, metadata, nested stream info).
        # AUTO is reserved only for genuinely unknown items.
        explicit_quality = self._detail_quality_value()
        self["quality_text"] = Label(explicit_quality or "")
        _year_raw=str(item.get("year") or item.get("release_year") or "")
        _year_match=re.search(r"(?:19|20)\d{2}",_year_raw)
        self["year_text"] = Label(_clean_year_value(_year_raw))
        duration=item.get("time") or item.get("duration") or item.get("length") or ""
        if media_type == "series":
            # Series overview shows the season count only. Episode count belongs
            # inside the season/episode browser after the user opens the series.
            seasons=item.get("number_of_seasons") or item.get("seasons_count") or item.get("season_count") or item.get("seasons") or item.get("season") or ""
            if isinstance(seasons,(list,tuple)):seasons=len(seasons)
            if seasons:self["runtime_text"] = Label(self._season_count_text(seasons))
            else:self["runtime_text"] = Label("—")
        else:
            self["runtime_text"] = Label(str(duration)[:14])
        self._country_raw=str(item.get("country_code") or item.get("country") or "").strip(); self["country_text"] = Label(self._normalized_country(self._country_raw))
        self["genre_text"] = Label((str(item.get("genre") or "").strip() or _detail_genre_value(item))[:54])
        _age_seed=(self._local_detail_cache.get("certification") or self._local_detail_cache.get("age_rating") or item.get("certification") or item.get("age_rating")) if isinstance(getattr(self,"_local_detail_cache",None),dict) else (item.get("certification") or item.get("age_rating"))
        self["age_rating_text"] = Label(_age_rating_display(_age_seed))
        self._image_init("poster",(352,552),profile,client)
        _perf_trace("details_components_ready")
        self.onLayoutFinish.append(self._layout_ready)
        try:self.onHide.append(self._details_hidden_release)
        except Exception as exc:optional_failure("ui.details_hide_hook",exc)
        try:self.onShown.append(self._details_shown_resume)
        except Exception as exc:optional_failure("ui.details_show_hook",exc)
        self["actions"] = ActionMap(["OkCancelActions","ColorActions","MenuActions","UltraStalkerMenuActions","DirectionActions"],{
            "cancel":self._fast_close,"red":self.play_trailer,"ok":self.play,"blue":self.play,
            "green":self.toggle_favorite,"yellow":self.show_information,"menu":self.open_download_menu,
            "up":self.description_up,"down":self.description_down,
        },-1)
        # R80: same-Screen inline Information, matching Settings context panels.
        # The base Details screen never closes/hides and therefore remains the
        # actual background behind the translucent scrim + adaptive card.
        self._info_overlay_dialog = None  # legacy compatibility marker only
        self["info_overlay_actions"] = ActionMap(["OkCancelActions","ColorActions","DirectionActions"],{
            "cancel":self._close_information_overlay,"ok":self._close_information_overlay,
            "yellow":self._close_information_overlay,"red":self._close_information_overlay,
            "up":self._information_page_up,"down":self._information_page_down,
        },-1000)
        try:self["info_overlay_actions"].setEnabled(False)
        except Exception:pass
        self.onClose.append(self._close_information_overlay)

        # Same modal key ownership as Information, still inside this Screen.
        self["downloads_overlay_actions"] = ActionMap(["OkCancelActions","ColorActions","DirectionActions"],{
            "cancel":self._close_downloads_overlay,"red":self._close_downloads_overlay,
            "yellow":self._downloads_cancel_selected,"green":self._downloads_retry_selected,"blue":self._downloads_delete_selected,
            "up":lambda:self["downloads_list"].wrap_up(),"down":lambda:self["downloads_list"].wrap_down(),
            "left":lambda:self["downloads_list"].page_left(),"right":lambda:self["downloads_list"].page_right(),
        },-1000)
        try:self["downloads_overlay_actions"].setEnabled(False)
        except Exception:pass
        self.onClose.append(self._close_downloads_overlay)
        self.onClose.append(self._stop_downloads_inline)


    _COUNTRY_NAMES = {
        "EG":"مصر","LB":"لبنان","SA":"السعودية","AE":"الإمارات","KW":"الكويت","QA":"قطر","BH":"البحرين","OM":"عُمان","JO":"الأردن","SY":"سوريا","IQ":"العراق","PS":"فلسطين","YE":"اليمن","MA":"المغرب","DZ":"الجزائر","TN":"تونس","LY":"ليبيا","SD":"السودان","US":"USA","GB":"UK","FR":"France","DE":"Germany","IT":"Italy","ES":"Spain","TR":"Turkey","IN":"India","KR":"Korea","JP":"Japan","CN":"China","CA":"Canada","MX":"Mexico","BR":"Brazil","AR":"Argentina","RU":"Russia","AU":"Australia"
    }
    # Compact English display codes beside flags.  These are UI labels only;
    # provider/TMDB country data remains untouched.  Keep the familiar receiver
    # abbreviations requested by users (EG, KSA, UAE, UK, USA, ...).
    _COUNTRY_CODES_EN = {
        "EG":"EG","LB":"LB","SA":"KSA","AE":"UAE","KW":"KW","QA":"QA","BH":"BH","OM":"OM","JO":"JO","SY":"SY","IQ":"IQ","PS":"PS","YE":"YE","MA":"MA","DZ":"DZ","TN":"TN","LY":"LY","SD":"SD",
        "US":"USA","GB":"UK","FR":"FR","DE":"DE","IT":"IT","ES":"ES","TR":"TR","IN":"IN","KR":"KR","JP":"JP","CN":"CN","CA":"CA","MX":"MX","BR":"BR","AR":"AR","RU":"RU","AU":"AU"
    }

    _poster_laser_color_cache = {}


# R5.245: plugin-owned front-panel identity.
try:
    from .frontpanel_plugin import bind_plugin_front_summary as _bind_plugin_front_summary
    _bind_plugin_front_summary(DetailsAdaptiveMenuScreen, HeroPinToastScreen, ContentDetailsScreen)
except Exception:
    pass


from .wqhd_layout import scale_skin as _us_wqhd_skin
DetailsAdaptiveMenuScreen.skin = _us_wqhd_skin(DetailsAdaptiveMenuScreen.skin)
HeroPinToastScreen.skin = _us_wqhd_skin(HeroPinToastScreen.skin)
