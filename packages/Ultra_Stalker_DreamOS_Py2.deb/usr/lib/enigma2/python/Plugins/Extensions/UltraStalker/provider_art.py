"""Provider artwork URL handling; preserve signed URLs and each image's origin."""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str, RecursionError, us_casefold
html = _us_env.html
json = _us_env.json
re = _us_env.re
urllib = _us_env.urllib


def normalize_url(value):
    text=str(value or '').strip().replace('\\/','/')
    # Decode complete HTML entities only. A query such as &copy=value is not HTML.
    text=re.sub(r'&(?:#[0-9]+|#x[0-9a-fA-F]+|[a-zA-Z][a-zA-Z0-9]+);',
                lambda match:html.unescape(match[0]),text)
    if len(text)>=2 and text[0]==text[-1] and text[0] in ('"',"'"):text=text[1:-1].strip()
    if not text:return ''
    try:
        parts=urllib.parse.urlsplit(text)
        # Keep percent escapes byte-for-byte. Decoding %26/%2B/%2F before
        # quoting corrupts signed CDN query values and encoded path segments.
        path=urllib.parse.quote(parts.path,safe="/%:@-._~!$&'()*+,;=")
        query=urllib.parse.quote(parts.query,safe="%=&:@/?-._~!$'()*+,;[]+")
        fragment=urllib.parse.quote(parts.fragment,safe='%=&:@/?-._~')
        return urllib.parse.urlunsplit((parts.scheme,parts.netloc,path,query,fragment))
    except (ValueError,UnicodeError):return ''


def _portal_base_dir(profile=None,item=None):
    base=str((item or {}).get('_art_base') or (profile or {}).get('portal') or (profile or {}).get('url') or '').strip()
    if not base:return '','',''
    try:
        parts=urllib.parse.urlsplit(base)
        scheme=parts.scheme or 'http'
        netloc=parts.netloc
        if not netloc:return '','',''
        path=parts.path or '/'
        if not path.endswith('/'):
            if re.search(r'\.(?:php|m3u8?|xml)(?:$)',path,re.I):path=path.rsplit('/',1)[0]+'/'
            else:path+='/'
        full_base=urllib.parse.urlunsplit((scheme,netloc,path,'',''))
        root_path=re.sub(r'/(?:c|server|portal)/+$','/',path,flags=re.I)
        root_base=urllib.parse.urlunsplit((scheme,netloc,root_path,'',''))
        origin_base=urllib.parse.urlunsplit((scheme,netloc,'/','',''))
        return full_base,root_base,origin_base
    except Exception:
        return '','',''


def absolute_url(value,profile=None,item=None):
    value=normalize_url(value)
    if not value or len(value)>8192:return ''
    if value.startswith('//'):value='https:'+value
    if value.lower().startswith(('http://','https://')):
        parsed=urllib.parse.urlsplit(value)
        return value if parsed.hostname else ''
    full_base,root_base,_origin_base=_portal_base_dir(profile,item)
    base=root_base if (root_base and (value.lstrip('/').startswith(('misc/','stalker_portal/')) or ('/' not in value and not (item or {}).get('_xtream')))) else (full_base or root_base)
    if not base:return ''
    try:
        if '/' not in value and not (item or {}).get('_xtream') and re.search(r'\.(?:png|jpe?g|webp|gif)$',value,re.I):
            url=normalize_url(urllib.parse.urljoin(base,'misc/logos/320/'+value))
        else:
            url=normalize_url(urllib.parse.urljoin(base,value))
        parsed=urllib.parse.urlsplit(url)
        if parsed.scheme not in ('http','https') or not parsed.hostname:return ''
        return url
    except (ValueError,UnicodeError):return ''


def _values(value):
    if isinstance(value,(list,tuple)):
        for child in value[:8]:
            for _v in _values(child):yield _v
    elif isinstance(value,dict):
        for key in ('url','src','path','image'):
            if key in value:
                for _v in _values(value[key]):yield _v
    elif isinstance(value,str):
        text=value.strip()
        if text.startswith(('[','{')):
            try:
                for _v in _values(json.loads(text)):yield _v
                return
            except (ValueError,TypeError,RecursionError):pass
        yield text


def picon_urls(item,profile=None):
    if not isinstance(item,dict):return []
    out=[]
    full_base,root_base,origin_base=_portal_base_dir(profile,item)
    is_stalker=not bool(item.get('_xtream'))
    for key in ('_picon_candidates','stream_icon','picon','logo','logo_url','icon','tvg-logo','tvg_logo','channel-logo','image','img','pic','cover','cover_url'):
        for value in _values(item.get(key)):
            low=us_casefold(value)
            if not value or low in ('0','null','none','[]','{}'):continue
            if any(tag in low for tag in ('placeholder','noimage','no_image','default_poster','default-cover')):continue
            norm=normalize_url(value)
            if not norm:continue
            if norm.startswith('//'):norm='https:'+norm
            if not norm.lower().startswith(('http://','https://')) and is_stalker and (root_base or origin_base):
                clean_rel=norm.lstrip('/')
                if '/' not in clean_rel and re.search(r'\.(?:png|jpe?g|webp|gif)$',clean_rel,re.I):
                    for candidate_base in (root_base,origin_base+'stalker_portal/' if origin_base else '',origin_base):
                        if not candidate_base:continue
                        for sub in ('misc/logos/320/','misc/logos/240/',''):
                            u=normalize_url(urllib.parse.urljoin(candidate_base,sub+clean_rel))
                            if u and u not in out:out.append(u)
                            if len(out)>=6:return out
                    continue
                elif clean_rel.startswith('misc/logos/') and root_base:
                    for candidate_base in (root_base,origin_base+'stalker_portal/' if origin_base else '',origin_base):
                        if not candidate_base:continue
                        u=normalize_url(urllib.parse.urljoin(candidate_base,clean_rel))
                        if u and u not in out:out.append(u)
                        if len(out)>=6:return out
            url=absolute_url(value,profile,item)
            if url and url not in out:out.append(url)
            if len(out)>=6:return out
    return out
