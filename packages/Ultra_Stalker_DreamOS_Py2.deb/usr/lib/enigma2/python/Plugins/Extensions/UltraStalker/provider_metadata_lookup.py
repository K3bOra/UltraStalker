"""Automatic Arabic sibling lookup for a focused, verified movie/series.

No category visit, manual cache action or pre-existing HDD record is required.
Provider text is shared only after independently resolving the donor to the exact
same media/TMDb identity. No artwork or playback fields are copied.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str, int, max, min, us_casefold, us_acquire
OrderedDict = _us_env.collections.OrderedDict
hashlib = _us_env.hashlib
threading = _us_env.threading
time = _us_env.time

from .verified_identity import media_kind, positive_id, verified_id

_LOCKS=tuple(threading.Lock() for _ in range(16))
_ATTEMPTS=OrderedDict()
_ATTEMPT_LOCK=threading.Lock()


class MetadataCandidates(list):
    def __init__(self,rows,complete=True):
        super(MetadataCandidates,self).__init__(rows)
        self.complete=bool(complete)


class Deadline(object):
    def __init__(self,parent,seconds=3.2):
        self.parent=parent;self.until=time.monotonic()+seconds
    def is_set(self):
        return time.monotonic()>=self.until or bool(self.parent is not None and self.parent.is_set())


def find_arabic_copy(profile,media_type,item,current,client,cfg,cancel_event=None):
    """Best-effort bounded lookup; a cancelled lookup remains eligible to retry."""
    from . import details_authority as authority
    item=item if isinstance(item,dict) else {}
    if client is None or not callable(getattr(client,'search_metadata_copies',None)):return ''
    if authority._base_metadata_target(cfg).split('-',1)[0]!='ar':return ''
    row=current if isinstance(current,dict) else {}
    ident=verified_id(row)
    if not ident and row.get('_details_authority_ready'):ident=positive_id(row.get('tmdb_id'))
    kind=media_kind(row.get('media_type') or media_type)
    if not ident or kind!=media_kind(media_type):return ''
    if authority._cancelled(cancel_event):return ''
    if authority._own_real_arabic(authority._provider_overview_values(item)+authority._provider_overview_values(row)):return ''
    saved=authority._shared_arabic_for(kind,ident,cfg)
    if saved:return saved

    # Different accounts stay separate. No source secrets are logged or stored.
    source='|'.join(str(x or '') for x in (getattr(client,'endpoint',''),getattr(client,'url',''),
                    getattr(client,'mac',''),repr(profile or {})))
    scope=hashlib.sha256(source.encode('utf-8')).hexdigest()
    key=(scope,kind,ident)
    lock=_LOCKS[int(scope[:8],16)%len(_LOCKS)]
    while not us_acquire(lock, 0.1):
        if authority._cancelled(cancel_event):return ''
    try:
        saved=authority._shared_arabic_for(kind,ident,cfg)
        if saved:return saved
        with _ATTEMPT_LOCK:
            if time.monotonic()<float(_ATTEMPTS.get(key,0)):return ''
        deadline=Deadline(cancel_event)
        query_values=[row.get('original_title'),row.get('original_name'),item.get('original_title'),
                      item.get('original_name'),item.get('name'),item.get('title'),row.get('title'),row.get('name')]
        queries=[]
        for value in query_values:
            text=authority._catalogue_title(value or '').strip()
            if len(text)>=2 and us_casefold(text) not in {us_casefold(q) for q in queries}:queries.append(text)
        typ='series' if kind=='tv' else 'vod'
        candidates=[];seen=set();completed=True
        for query in queries[:2]:
            if deadline.is_set():break
            found=client.search_metadata_copies(query,typ,cancel_event=deadline,
                                               time_budget=min(2.0,max(0.1,deadline.until-time.monotonic())))
            if getattr(found,'complete',True) is False:completed=False
            found=found or []
            for value in found:
                if not isinstance(value,dict):continue
                marker=(str(value.get('id') or value.get('stream_id') or value.get('series_id') or value.get('name') or ''),
                        str(value.get('category_id') or value.get('genre_id') or ''),
                        tuple(authority._provider_overview_values(value)))
                if marker in seen:continue
                seen.add(marker);candidates.append(dict(value))
            # A second alias is only useful if the first query had no Arabic hit.
            if any(authority._own_real_arabic(authority._provider_overview_values(c)) for c in candidates):break
        candidates.sort(key=lambda c:len(authority._own_real_arabic(authority._provider_overview_values(c))),reverse=True)
        resolver=None;checked=0;enriched=0
        for candidate in candidates[:24]:
            if deadline.is_set():break
            declared=media_kind(candidate.get('_search_media_type') or candidate.get('_xtream_kind') or candidate.get('media_type'))
            if declared and declared!=kind:continue
            # Search catalogue metadata is untrusted. Never stamp the expected
            # id onto the donor or let a provider-supplied lock prove itself.
            for name in ('_locked_tmdb_id','_locked_tmdb_type','_ultra_search_verified_tmdb_id',
                         'identity_verified','identity_pointer_verified','_details_authority_ready'):
                candidate.pop(name,None)
            text=authority._own_real_arabic(authority._provider_overview_values(candidate))
            if not text and candidate.get('_xtream') and enriched<2 and hasattr(client,'enrich_provider_artwork'):
                enriched+=1
                from .core.call_compat import call_compatible
                rich=call_compatible(client.enrich_provider_artwork,
                    (((dict(candidate),typ,deadline),{'force':False}),((dict(candidate),typ,deadline),{})))
                if isinstance(rich,dict):candidate.update(rich)
                text=authority._own_real_arabic(authority._provider_overview_values(candidate))
            for name in ('_locked_tmdb_id','_locked_tmdb_type','_ultra_search_verified_tmdb_id',
                         'identity_verified','identity_pointer_verified','_details_authority_ready'):
                candidate.pop(name,None)
            if not text:continue
            if checked>=3:break
            checked+=1
            known=authority.load_canonical(profile,typ,candidate) or {}
            donor_id=verified_id(known)
            if not donor_id and known.get('_details_authority_ready'):donor_id=positive_id(known.get('tmdb_id'))
            donor_kind=media_kind(known.get('media_type'))
            if not donor_id:
                credential=str(cfg.get('tmdb_credential') or '').strip()
                if not credential or not cfg.get('tmdb_enabled',True):continue
                if resolver is None:resolver=authority.ArtworkV2(credential,cfg.get('tmdb_language','ar-EG'),3)
                donor_kind,donor_id,_confidence,_source,_seed=resolver._resolve_identity(typ,candidate,hot={})
                donor_id=positive_id(donor_id);donor_kind=media_kind(donor_kind)
            if deadline.is_set():break
            if donor_id!=ident or donor_kind!=kind:continue
            # A donor can fill whitelisted missing fields as well as its prose.
            authority.remember_catalogue_metadata(typ,candidate,{
                'tmdb_id':int(ident),'media_type':kind,'identity_verified':True})
            saved=authority._shared_arabic_for(kind,ident,cfg)
            if saved:return saved
        # Cache only completed misses. Focus changes and transient request errors
        # do not block a new automatic attempt, especially after a cold start.
        if not deadline.is_set() and completed:
            with _ATTEMPT_LOCK:
                _ATTEMPTS[key]=time.monotonic()+120
                _ATTEMPTS.move_to_end(key)
                while len(_ATTEMPTS)>256:_ATTEMPTS.popitem(last=False)
        return ''
    except Exception as exc:
        authority.optional_failure('details_authority.auto_arabic_copy',exc)
        return ''
    finally:lock.release()
