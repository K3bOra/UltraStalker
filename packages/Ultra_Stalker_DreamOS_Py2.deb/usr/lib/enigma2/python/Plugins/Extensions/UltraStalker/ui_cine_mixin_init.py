# -*- coding: utf-8 -*-
"""Authority state/widget initialisation and action installation.

Methods moved verbatim out of ``PremiumGlobalCinematicScreen`` (ui_cinematic_global.py); behaviour is unchanged.
This module is imported by ui_cinematic_global.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .ui_cinematic_global import (
    FastBackdropTransport,
    IconMenuList,
    SettingsInlineChoiceOverlay,
    _,
    _FAST_BACKDROP_ENABLED,
    deque,
    optional_failure,
    queue,
    time,
)


class CineInitMixin(object):
    """Authority state/widget initialisation and action installation."""

    def _cin_init_authority_state(self):
        """Single selected-title runtime state for Cinematic, BG1 and BG2."""
        self._cin_record_key="";self._cin_visual_key="";self._cin_jobs=queue.Queue();self._cin_pending=set();self._cin_last_record={};self._cin_row_refresh_cursor=0;self._cin_row_complete=set();self._cin_page_records={};self._cin_committed_adaptive_key="";self._settings_row_asset=asset("series_floating_row.png");self._settings_row_selected_asset=self._settings_row_asset;self._cin_progress_accent="#75d2ab"
        # Stage 9: selected-title adaptive work is generation-owned.  Navigation
        # invalidates the previous generation immediately, but keeps its already
        # committed surfaces visible until the current title has a COMPLETE pair
        # of row + details chrome surfaces ready to atomically replace them.
        self._cin_adaptive_generation=0;self._cin_adaptive_target_sig="";self._cin_adaptive_cancel=None;self._cin_visual_future=None
        # R224 Stage 3: visible adaptive material has explicit selection ownership.
        # Navigation may never keep another title's palette on screen. The fixed
        # green master is the neutral bridge while the new title settles.
        self._cin_display_adaptive_owner_sig="";self._cin_nav_adaptive_pending_sig=""
        self._cin_fixed_progress_accent="#75d2ab"
        self._cin_package_schema=5
        self._cin_focus_cancel=None;self._cin_focus_future=None;self._cin_focus_sig=""
        self._cin_fast_info_cancel=None;self._cin_fast_info_future=None;self._cin_fast_info_sig=""
        self._cin_background_cancel=None;self._cin_background_future=None
        self._cin_missed=deque();self._cin_missed_keys=set();self._cin_last_focus_item=None
        self._cin_last_nav_at=time.monotonic();self._cin_hidden=False
        self._cin_active_pixmap={"cin_backdrop":"cin_backdrop"};self._cin_pixmap_paths={};self._cin_widget_paths={};self._cin_suspended_visual_paths={}
        self._cin_shared_backdrop_retry=0
        self._cin_page_packages={};self._cin_page_backdrops={};self._cin_nav_alias_ram={}
        self._cin_logo_pending=set();self._cin_logo_path="";self._cin_logo_cancel=None;self._cin_logo_active_sig=""
        self._fast_bd_enabled=bool(_FAST_BACKDROP_ENABLED)
        self._fast_bd_req_id=0;self._fast_bd_deferred=None;self._fast_bd_path="";self._fast_bd_sig="";self._fast_bd_started_at=0.0;self._fast_bd_inflight=False
        self._fast_bd_meta_pending=set();self._fast_bd_meta_latest_sig="";self._fast_bd_fast_cache={};self._fast_bd_fast_order=deque();self._fast_bd_fast_limit=12;self._fast_bd_locked_sig="";self._fast_bd_locked_path=""
        self._fast_bd_transport=None
        if self._fast_bd_enabled:
            try:self._fast_bd_transport=FastBackdropTransport()
            except Exception as exc:optional_failure("cinematic.fast_backdrop_transport",exc)
        self._folder_artwork_worker_window=1
        self._cin_cache_exclusive=False
        self._folder_artwork_fast_art_only=False

    def _cin_init_authority_widgets(self):
        """Single HUD/backdrop/logo/timer lifecycle used by all three views."""
        self["cin_backdrop"]=Pixmap();self["cin_backdrop_stage"]=Pixmap();self["title_logo"]=Pixmap();self["artwork_status_bg"]=Pixmap()
        for name in ("panel_bg","overview_bg","cast_card_bg","quality_pill_bg","year_pill_bg","runtime_pill_bg","country_pill_bg","genre_pill_bg","quality_logo","runtime_icon","country_flag"):
            self[name]=Pixmap()
        for name in ("name","quality_text","year_text","runtime_text","country_text","genre_text","age_rating_text","cast_text","description"):
            self[name]=Label("")
        self["cin_list"]=IconMenuList([], width=430, item_height=70, icon_size=40, primary_font=21, secondary_font=15, row_style="settings_episode")
        self["settings_menu_scrim"]=Pixmap()
        try:self["settings_menu_scrim"].hide()
        except Exception:pass
        self._settings_inline_menu=SettingsInlineChoiceOverlay(self,"settings_menu_list","settings_menu_actions",asset,_,optional_failure)
        self._cin_list_icon=asset("settings_icons_40/artwork.png")
        self._cin_poll=eTimer();self._cin_poll_conn=None;self._cin_poll_interval=600
        try:self._cin_poll_conn=self._cin_poll.timeout.connect(self._cin_poll_hdd)
        except Exception:self._cin_poll.callback.append(self._cin_poll_hdd)
        self._cin_nav_backdrop_timer=eTimer();self._cin_nav_backdrop_conn=None
        try:self._cin_nav_backdrop_conn=self._cin_nav_backdrop_timer.timeout.connect(self._cin_apply_debounced_backdrop)
        except Exception:self._cin_nav_backdrop_timer.callback.append(self._cin_apply_debounced_backdrop)
        self._cin_nav_adaptive_timer=eTimer();self._cin_nav_adaptive_conn=None
        try:self._cin_nav_adaptive_conn=self._cin_nav_adaptive_timer.timeout.connect(self._cin_apply_nav_adaptive_baseline)
        except Exception:self._cin_nav_adaptive_timer.callback.append(self._cin_apply_nav_adaptive_baseline)
        self._cin_fast_info_timer=eTimer();self._cin_fast_info_conn=None
        try:self._cin_fast_info_conn=self._cin_fast_info_timer.timeout.connect(self._cin_apply_fast_info)
        except Exception:self._cin_fast_info_timer.callback.append(self._cin_apply_fast_info)
        self._cin_fast_logo_timer=eTimer();self._cin_fast_logo_conn=None
        try:self._cin_fast_logo_conn=self._cin_fast_logo_timer.timeout.connect(self._cin_apply_fast_logo)
        except Exception:self._cin_fast_logo_timer.callback.append(self._cin_apply_fast_logo)
        self._cin_page_nav_timer=eTimer();self._cin_page_nav_conn=None
        try:self._cin_page_nav_conn=self._cin_page_nav_timer.timeout.connect(self._cin_commit_page_nav)
        except Exception:self._cin_page_nav_timer.callback.append(self._cin_commit_page_nav)
        if not hasattr(self,"_bg_layout_ready"):self.onLayoutFinish.append(self._cin_layout_ready)
        self.onClose.append(self._cin_stop)
        try:self.onHide.append(self._cin_hidden_start)
        except Exception:pass
        self._refresh_search_sort_controls()
        self["blue"].setText(_("Cache Artwork"))

    def _cin_install_actions(self,left,right,up,down):
        """Same action surface; only the navigator functions differ for poster rails."""
        self["actions"] = ActionMap(["OkCancelActions","ColorActions","DirectionActions","MenuActions","UltraStalkerMenuActions","InfoActions"], {
            "cancel":self.close,"red":self.open_folder_search,"ok":self.open_selected,
            "left":left,"right":right,"up":up,"down":down,
            "green":self.toggle_selected_favorite,"yellow":self.cycle_folder_sort,
            "blue":self.cache_folder_artwork,"menu":self.open_menu,"info":self.show_information},-1)
