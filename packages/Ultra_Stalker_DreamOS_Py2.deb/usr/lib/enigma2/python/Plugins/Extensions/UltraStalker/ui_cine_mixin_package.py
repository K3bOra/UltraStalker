# -*- coding: utf-8 -*-
"""Canonical package loading, backdrop cache and package application.

Methods moved verbatim out of ``PremiumGlobalCinematicScreen`` (ui_cinematic_global.py); behaviour is unchanged.
This module is imported by ui_cinematic_global.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, open, max
from .ui_cinematic_global import (
    _prepare_shared_cinematic_backdrop,
    ensure_persistent_dirs,
    hashlib,
    json,
    optional_failure,
    os,
    threading,
    time,
)


class CinePackageMixin(object):
    """Canonical package loading, backdrop cache and package application."""

    def _cin_file_sig(self,path):
        try:
            if path and os.path.isfile(str(path)):
                st=os.stat(str(path));return "%s:%s:%s"%(str(path),int(st.st_mtime),int(st.st_size))
        except Exception:pass
        return ""

    def _cin_package_signature(self,item,row):
        row=row if isinstance(row,dict) else {}
        raw="|".join((str(self._cin_package_schema),self._record_key(row,item),self._cin_file_sig(row.get("backdrop_local")),str(row.get("adaptive_fingerprint") or "")))
        return hashlib.sha1(raw.encode("utf-8","ignore")).hexdigest()

    def _cin_load_canonical_package_fast(self,item,row):
        """Read only the canonical package JSON; never migrate, resolve or build.

        This is the navigation-safe index path used while painting a catalogue
        page.  It intentionally performs no legacy adoption and no artwork work.
        """
        row=row if isinstance(row,dict) else {}
        key=self._record_key(row,item);path=self._cin_package_path(key)
        if not path or not os.path.isfile(path):return {}
        try:
            with open(path,"r",encoding="utf-8") as h:data=json.load(h)
            if not isinstance(data,dict) or int(data.get("schema") or 0)!=self._cin_package_schema or not data.get("complete"):return {}
            if int(row.get("clean_backdrop_selector_version") or 0)>=3:
                current_sig=self._cin_file_sig(row.get("backdrop_local"))
                if current_sig and str(data.get("backdrop_source_sig") or "")!=current_sig:return {}
            # R149 package is row metadata only. ArtworkV2 backdrop_local is
            # the canonical source/master; the shared prepared Cinematic JPEG is
            # the sole full-screen display authority for Cinematic/BG1/BG2.
            return data
        except Exception as exc:
            optional_failure("cinematic.fast_package_index",exc);return {}

    def _cin_instant_cached_backdrop(self,item,row):
        """Bind only the shared prepared presentation for the CURRENT title.

        Missing/new artwork never clears the committed backdrop.  The selection
        signature is checked both before lookup and at commit so a late cache hit
        from a skipped title cannot leak into Cinematic, BG1 or BG2.
        """
        try:
            row=row if isinstance(row,dict) else {}
            expected_sig=self._page_visual_key(item)
            if not expected_sig or expected_sig!=self._fast_bd_current_sig():return False
            path=str((getattr(self,"_cin_page_backdrops",{}) or {}).get(int(self.index)) or "")
            if not (path and os.path.isfile(path)):
                source=str(row.get("backdrop_local") or "")
                key=self._record_key(row,item)
                path=_prepare_shared_cinematic_backdrop(source,key,row,build=False) if source else ""
                if path and os.path.isfile(path) and expected_sig==self._fast_bd_current_sig():
                    self._cin_page_backdrops[int(self.index)]=path
            if expected_sig!=self._fast_bd_current_sig():return False
            if not path or not os.path.isfile(path):return False
            if not self._cin_buffered_handoff("cin_backdrop","cin_backdrop_stage",path,expected_sig=expected_sig):return False
            self._cin_visual_key=self._record_key(row,item)
            self._cin_nav_backdrop_ready_key=self._cin_backdrop_ready_token(item,row,{},path)
            self._cin_shared_backdrop_retry=0
            return True
        except Exception as exc:
            optional_failure("cinematic.shared_cached_backdrop",exc);return False

    def _cin_cached_backdrop_delay_ms(self):
        """R5.47: cached backdrops settle at 450 ms; cold titles keep 550 ms.

        Cache detection is the same bounded R200 lookup: page-local prepared
        presentation, the direct warm cache, a clean local row backdrop, or the
        persistent ORIGINAL cache.  Nothing is built here.  Arrow navigation
        only chooses the quiet-window; actual decode/paint remains deferred.
        """
        try:
            path=str((getattr(self,"_cin_page_backdrops",{}) or {}).get(int(self.index)) or "")
            if getattr(self,"_fast_bd_enabled",False) and self.grid_items:
                item=self.grid_items[self.index];sig=self._page_visual_key(item)
                entry=(getattr(self,"_fast_bd_fast_cache",{}) or {}).get(sig) or {}
                direct=str(entry.get("backdrop") or "")
                row=(getattr(self,"_cin_page_records",{}) or {}).get(int(self.index),{}) or {}
                if not (direct and os.path.isfile(direct)):
                    direct=self._fast_bd_clean_local_from_row(row)
                if not (direct and os.path.isfile(direct)):
                    url=self._fast_bd_url_from_row(row)
                    direct=self._fast_bd_cached_original(url) if url else ""
                if direct and os.path.isfile(direct):path=direct
            low=path.lower()
            if path and (low.endswith(".jpg") or low.endswith(".jpeg") or low.endswith(".webp")):
                return 450
        except Exception:
            pass
        return 550

    def _cin_apply_debounced_backdrop(self):
        """R5.47 backdrop timing law shared by Cinematic, BG1 and BG2.

        A ready local/cache backdrop binds after 450 ms quiet. A cold title starts
        its backdrop request after 550 ms. Arrow repeat remains presentation-only.
        """
        if self._screen_closed or getattr(self,"_cin_hidden",False) or getattr(self,"_cin_cache_exclusive",False):return
        if not self.grid_items:return
        try:
            target=max(0.45,float(self._cin_cached_backdrop_delay_ms())/1000.0)
            quiet=max(0.0,time.monotonic()-float(getattr(self,"_cin_last_nav_at",0.0) or 0.0))
            if quiet < target:
                self._cin_nav_backdrop_timer.stop();self._cin_nav_backdrop_timer.start(max(60,int((target-quiet)*1000)),True)
                return
            item=self.grid_items[self.index]
            row=self._cin_page_records.get(self.index,{}) or {}
            if getattr(self,"_fast_bd_enabled",False):
                # Same R196/R199 quality/clean-image authority, now allowed to
                # start only after R81's navigation quiet gate has actually won.
                self._fast_bd_schedule(item,row)
                return
            self._cin_instant_cached_backdrop(item,row)
        except Exception as exc:optional_failure("cinematic.r200_r81_nav_backdrop",exc)

    def _cin_load_package(self,item,row):
        row=row if isinstance(row,dict) else {}
        key=self._record_key(row,item);path=self._cin_package_path(key)
        def valid(data):
            # Trusted Local Cache Path: a completed canonical package is the
            # authority for presentation. Metadata timestamps/fingerprints may
            # change independently and must never force a cached 5-6GB library
            # back through Pillow/TMDB processing during navigation.
            if not isinstance(data,dict) or int(data.get("schema") or 0)!=self._cin_package_schema or not data.get("complete"):return False
            if int(row.get("clean_backdrop_selector_version") or 0)>=3:
                current_sig=self._cin_file_sig(row.get("backdrop_local"))
                if current_sig and str(data.get("backdrop_source_sig") or "")!=current_sig:return False
            # R149 packages own catalogue row material only. Backdrop display
            # belongs to the shared presentation cache and information chrome
            # belongs to Native Details, so neither can participate in package
            # validity or silently become a competing visual authority.
            essential=("row_normal","row_selected")
            for field in essential:
                fp=str(data.get(field) or "")
                if not fp or not os.path.isfile(fp):return False
            # V9.1.2-r2: packages are now durable, so the adaptive rows must follow
            # an in-place poster upgrade instead of keeping the old colour forever.
            stored_art=str(data.get("adaptive_source_sig") or "")
            if stored_art:
                _p=str(row.get("poster_local") or "")
                _src=_p if (_p and os.path.isfile(_p)) else str(row.get("backdrop_local") or "")
                current_art=self._cin_file_sig(_src)
                if current_art and current_art!=stored_art:return False
            return True
        try:
            if path and os.path.isfile(path):
                with open(path,"r",encoding="utf-8") as h:data=json.load(h)
                if valid(data):return data
            # Canonical miss does NOT mean artwork miss. Try the already-saved
            # pre-V7 package before any resolver/build path is allowed to run.
            adopted=self._cin_adopt_legacy_package(item,row)
            if valid(adopted):return adopted
            return {}
        except Exception as exc:optional_failure("cinematic.canonical_package_load",exc);return {}

    def _cin_write_package(self,path,data):
        temp=""
        try:
            if not ensure_persistent_dirs(os.path.dirname(path)):return False
            temp=path+".tmp.%d.%d"%(os.getpid(),threading.get_ident())
            with open(temp,"w",encoding="utf-8") as h:
                json.dump(data,h,ensure_ascii=False,separators=(",",":"))  # derived cinematic cache metadata
            os.replace(temp,path);return True
        except Exception as exc:
            optional_failure("cinematic.hybrid_package_write",exc)
            try:
                if temp and os.path.exists(temp):os.unlink(temp)
            except Exception:pass
            return False

    def _cin_backdrop_ready_token(self,item,row,package=None,path=""):
        package=package if isinstance(package,dict) else {}
        key=str(package.get("key") or self._record_key(row if isinstance(row,dict) else {},item) or "")
        sig=str(package.get("backdrop_source_sig") or "")
        if not sig:
            source=str((row or {}).get("backdrop_local") or path or "") if isinstance(row,dict) else str(path or "")
            sig=self._cin_file_sig(source) if source else ""
        return key+"|"+sig if sig else key

    def _cin_apply_package(self,item,row,package=None):
        package=package if isinstance(package,dict) and package else self._cin_load_package(item,row)
        if not package:return False
        normal=str(package.get("row_normal") or "");selected=str(package.get("row_selected") or "")
        acc=str(package.get("accent") or "")
        package_key=str(package.get("key") or self._record_key(row,item))
        # Backdrop and Adaptive are independent layers. If navigation already
        # painted this title's final cached backdrop, focus/package hydration is
        # forbidden from decoding or replacing it again.
        if not getattr(self,"_fast_bd_enabled",False) and str(getattr(self,"_cin_nav_backdrop_ready_key","") or "") != package_key:
            bd=str(package.get("backdrop_fast") or package.get("backdrop") or "")
            expected_sig=self._page_visual_key(item)
            if bd and os.path.isfile(bd) and expected_sig==self._fast_bd_current_sig():
                if self._cin_buffered_handoff("cin_backdrop","cin_backdrop_stage",bd,expected_sig=expected_sig):
                    self._cin_nav_backdrop_ready_key=package_key
        # R199 strict authority split: R81 package owns only the left-row material.
        # The information box can paint adaptive chrome only from the exact
        # persisted Native Details visual bundle for this title.
        details_chrome={}
        try:
            bundle=_load_visual_bundle(self.profile,self.media_type,item,row) or {}
            details_chrome=bundle.get("chrome") if isinstance(bundle.get("chrome"),dict) else {}
        except Exception as exc:optional_failure("cinematic.r199_details_chrome",exc)
        # R5.13: a stored package carries rows from one build and the Details
        # bundle may come from another source -> mismatched colours.  Never
        # commit the pair from here; the visual worker builds both from ONE source
        # (cache hits are instant) and commits them together.
        adaptive_committed=False
        # Publish one authoritative local visual identity to Details + Player.
        # These are private runtime handoff fields, not provider metadata.
        try:
            poster=str((row or {}).get("poster_local") or "");backdrop=str((row or {}).get("backdrop_local") or "")
            if poster and os.path.isfile(poster):
                if isinstance(item,dict):
                    item["_cin_provider_poster_local"]=poster
                    item["_ultra_palette_source"]=poster
                    item["_ultra_poster_source"]=poster
                    item["_player_poster"]=poster
                    item["_adaptive_source_local"]=poster
                try:self._grid_palette_sources[self.index]=poster
                except Exception:pass
            if backdrop and os.path.isfile(backdrop) and isinstance(item,dict):
                item["_cin_provider_backdrop_local"]=backdrop
                item["_backdrop_source_local"]=backdrop
        except Exception as exc:optional_failure("cinematic.visual_handoff",exc)
        self._cin_visual_key=str(package.get("key") or self._record_key(row,item))
        return bool(adaptive_committed)

    def _cin_resolve_and_package(self,item,cancel_event=None):
        """Consume Details Authority metadata; Cinematic owns presentation only.

        R92 performs one targeted clean-backdrop check here, inside the existing
        stable-focus worker.  It uses the already-verified TMDb id only and never
        runs on arrow navigation or the Enigma2 UI thread.
        """
        if cancel_event is not None and cancel_event.is_set():return ({}, {})
        row=self._record(item) or {}
        def valid_file(value):
            try:return bool(value and os.path.isfile(str(value)) and os.path.getsize(str(value))>100)
            except Exception:return False
        backdrop=str(row.get("backdrop_local") or "")
        try:
            from .details_authority import resolve_canonical
            authoritative=resolve_canonical(self.profile,self.media_type,item,cancel_event=cancel_event,settings=(self._grid_settings or {}),provider_client=self.client,provider_downloader=_download_portal_artwork) or {}
            if authoritative:
                merged=dict(row)
                if authoritative.get("_replace_localized_metadata"):
                    for _meta_key in ('overview','overview_language','description','plot','descr','genres','genre','cast','actors','actor','crew','directors','director','writers','writer','runtime','duration','time','length','number_of_seasons','seasons_count','season_count','number_of_episodes','episodes_count','episode_count','release_date','first_air_date','year','release_year','releaseDate','countries','country','country_code','production_country','production_countries','origin_country','rating','vote_count','original_language','certification','age_rating'):
                        merged.pop(_meta_key,None)
                for key,value in authoritative.items():
                    if value not in (None,"",[],{}):merged[key]=value
                row=merged
        except Exception as exc:optional_failure("cinematic.details_authority",exc)
        if not valid_file(row.get("backdrop_local")) and valid_file(backdrop):row["backdrop_local"]=backdrop
        if cancel_event is not None and cancel_event.is_set():return (row,{})
        try:
            from .backdrop_clean_runtime import upgrade as _upgrade_clean_backdrop
            clean=_upgrade_clean_backdrop(self.profile,self.media_type,item,settings=(self._grid_settings or {}),cancel_event=cancel_event) or {}
            fresh=clean.get("data") if isinstance(clean,dict) else {}
            if isinstance(fresh,dict) and fresh:
                # backdrop_clean_runtime is a visual repair lane.  Never let its
                # manifest snapshot overwrite the raw Details-Authority metadata
                # that was selected/fallback-resolved just above.
                visual_keys=(
                    "tmdb_id","media_type","poster_local","backdrop_local",
                    "poster_path","backdrop_path","poster_url","backdrop_url","_backdrop_url","tmdb_backdrop_url",
                    "adaptive_primary","adaptive_secondary","adaptive_dark","adaptive_accent","adaptive_fingerprint",
                    "clean_backdrop_choice","clean_backdrop_iso","clean_backdrop_selector_version",
                    "backdrop_source","backdrop_state","identity_verified","identity_pointer_verified",
                )
                merged=dict(row)
                for key in visual_keys:
                    value=fresh.get(key)
                    if value not in (None,"",[],{}):merged[key]=value
                row=merged
        except Exception as exc:optional_failure("cinematic.clean_backdrop_upgrade",exc)
        if cancel_event is not None and cancel_event.is_set():return (row,{})
        # R193 radical split: stable focus owns metadata/canonical persistence only.
        # Visible backdrop and adaptive chrome are already complete through the
        # direct-clean + HDD adaptive-colour lane. Never build shared backdrops, row
        # PNGs or final adaptive bundles here. Those were the measured 8-10s tail.
        package=self._cin_load_package(item,row) or {}
        return (row,package)

    def _cin_enqueue_missed(self,item):
        # Focus-driven law: skipped titles are never recovered in background.
        return
