# -*- coding: utf-8 -*-
"""Text direction/alignment, country and quality assets, widget pixmaps.

Methods moved verbatim out of ``ContentDetailsScreen`` (ui_screens_details.py); behaviour is unchanged.
This module is imported by ui_screens_details.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, round, max, min
from .ui_screens_details import (
    _lbl_h,
    _lbl_v,
    current_language,
    os,
    re,
)


class DetailsTextMixin(object):
    """Text direction/alignment, country and quality assets, widget pixmaps."""

    @staticmethod
    def _contains_arabic(value):
        return bool(re.search(r"[\u0600-\u06ff]", str(value or "")))

    def _align_detail_widget(self,name,value):
        try:
            inst=self[name].instance
            if inst is not None and hasattr(inst,"setHAlign"):
                inst.setHAlign(_lbl_h("right") if self._contains_arabic(value) else _lbl_h("left"))
        except Exception as exc:optional_failure("ui",exc)

    def _center_detail_label_geometry(self, name, box_x, box_width, pad=8):
        """Center the *rendered label box* inside its visual container.

        OpenBH/eLabel can re-interpret halign when BiDi text is updated at
        runtime. V6.5.20 keeps the V6.5.19 geometric centering and does not trust halign alone: it measures the
        actual rendered text, shrinks the label widget to that width, then moves
        the widget so its geometric center equals the container center. This
        makes English, Arabic, German and mixed Arabic/Latin strings land at the
        same physical center on the receiver.
        """
        try:
            widget=self[name]
            inst=widget.instance
            if inst is None:return
            value=str(widget.getText() or "").replace("\n"," ").strip()
            if not value:return
            try:
                measured=int(inst.calculateSize().width())
            except Exception:
                measured=0
            from .wqhd_layout import factors
            ratio=factors()[0]
            box_x=float(box_x)*ratio
            box_width=float(box_width)*ratio
            pad=float(pad)*ratio
            max_width=max(24,int(round(box_width))-int(round(pad))*2)
            target=max(24,min(max_width,(measured+int(round(pad))*2) if measured>0 else max_width))
            pos=inst.position();size=inst.size()
            y=int(pos.y());height=int(size.height())
            x=int(round(float(box_x)+(float(box_width)-float(target))/2.0))
            inst.resize(eSize(int(target),height))
            inst.move(ePoint(x,y))
            if hasattr(inst,"setHAlign"):inst.setHAlign(_lbl_h("center"))
            if hasattr(inst,"setVAlign"):inst.setVAlign(_lbl_v("center"))
            if hasattr(inst,"setNoWrap"):inst.setNoWrap(1)
        except Exception as exc:
            optional_failure("ui.detail_geometric_center",exc)

    def _sync_detail_text_direction(self):
        # release: retain release physical centering while compacting the vertical Details cluster.
        # The three visual containers are fixed in the Details skin:
        # title/overview span, genre pill, and full-width cast glass strip.
        for name in ("name","genre_text","cast_text"):
            try:
                inst=self[name].instance
                if inst is not None:
                    if hasattr(inst,"setHAlign"): inst.setHAlign(_lbl_h("center"))
                    if hasattr(inst,"setVAlign"): inst.setVAlign(_lbl_v("center"))
                    if hasattr(inst,"setNoWrap"): inst.setNoWrap(1)
            except Exception as exc:optional_failure("ui.detail_force_center",exc)
        self._center_detail_label_geometry("name",547,1318,10)
        self._center_detail_label_geometry("genre_text",1185,680,14)
        self._center_detail_label_geometry("cast_text",547,1318,14)
        try:self._align_detail_widget("description",self["description"].getText())
        except Exception as exc:optional_failure("ui",exc)

    @staticmethod
    def _extract_numeric_rating(text):
        m=re.search(r"(\d+(?:\.\d+)?)", str(text or ""))
        return m.group(1) if m else ""

    @staticmethod
    def _quality_asset_name(value):
        """Legacy quality artwork retired; metadata shows age certification."""
        return None

    @classmethod
    def _country_code(cls,value):
        # Accept provider/TMDb country values in all shapes we actually receive:
        # ISO code, localized/English name, dict, list/tuple, or stringified data.
        if isinstance(value,(list,tuple,set)):
            for row in value:
                code=cls._country_code(row)
                if code:return code
            return ""
        if isinstance(value,dict):
            for key in ("iso_3166_1","country_code","code","name"):
                code=cls._country_code(value.get(key))
                if code:return code
            return ""
        raw=str(value or "").strip()
        if not raw:return ""
        upper=raw.upper().strip()
        if upper=="IL":return ""
        aliases={
            "EGYPT":"EG","ARAB REPUBLIC OF EGYPT":"EG","مصر":"EG","جمهورية مصر العربية":"EG",
            "LEBANON":"LB","لبنان":"LB","SAUDI ARABIA":"SA","السعودية":"SA",
            "UNITED ARAB EMIRATES":"AE","UAE":"AE","الإمارات":"AE",
            "UNITED STATES":"US","UNITED STATES OF AMERICA":"US","USA":"US",
            "UNITED KINGDOM":"GB","GREAT BRITAIN":"GB","UK":"GB",
            "TURKEY":"TR","TÜRKIYE":"TR","TURKIYE":"TR",
            "SOUTH KOREA":"KR","REPUBLIC OF KOREA":"KR","KOREA":"KR",
            "NORTH KOREA":"KP","JAPAN":"JP","CHINA":"CN","INDIA":"IN",
            "FRANCE":"FR","GERMANY":"DE","ITALY":"IT","SPAIN":"ES",
            "CANADA":"CA","MEXICO":"MX","BRAZIL":"BR","ARGENTINA":"AR",
            "RUSSIA":"RU","RUSSIAN FEDERATION":"RU","AUSTRALIA":"AU",
            "KUWAIT":"KW","QATAR":"QA","BAHRAIN":"BH","OMAN":"OM",
            "JORDAN":"JO","SYRIA":"SY","IRAQ":"IQ","PALESTINE":"PS",
            "MOROCCO":"MA","ALGERIA":"DZ","TUNISIA":"TN","LIBYA":"LY","SUDAN":"SD"
        }
        if upper in aliases:return aliases[upper]
        # Reverse-map the labels already supported by the UI.
        for code,name in cls._COUNTRY_NAMES.items():
            if upper==str(name).upper():return code
        if len(upper)==2 and upper.isalpha():return upper
        # Handle stringified provider objects/lists, e.g. {'iso_3166_1': 'EG'}.
        m=re.search(r"(?:ISO_3166_1|COUNTRY_CODE|CODE)[^A-Z]{0,12}['\"]?([A-Z]{2})\b",upper)
        if m:return m.group(1)
        m=re.search(r"\b([A-Z]{2})\b",upper)
        if m and os.path.isfile(asset("flags_iso/%s.png"%m.group(1).lower())):return m.group(1)
        return ""

    @classmethod
    def _normalized_country(cls,value):
        raw=str(value or "").strip()
        code=cls._country_code(raw)
        if current_language()=="en":
            return cls._COUNTRY_CODES_EN.get(code, code or (raw[:12] if raw else ""))
        return cls._COUNTRY_NAMES.get(code, raw[:12] if raw else "")

    @classmethod
    def _country_flag_asset(cls,value):
        code=cls._country_code(value)
        if not code:return None
        name="flags_iso/%s.png"%code.lower()
        return name if os.path.isfile(asset(name)) else None

    def _set_widget_pixmap(self, name, asset_name):
        try:
            inst=self[name].instance
            path=asset(asset_name) if asset_name else None
            if inst is not None and path and os.path.isfile(path):
                inst.setPixmapFromFile(path)
                self[name].show()
            else:
                self[name].hide()
        except Exception as exc:optional_failure("ui",exc)
