# -*- coding: utf-8 -*-
"""Pausing/resuming the grid around child screens, details return, live play and favourites.

Methods moved verbatim out of ``PremiumGridBase`` (ui_grid_base.py); behaviour is unchanged.
This module is imported by ui_grid_base.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, zip, max, min
from .ui_grid_base import (
    _,
    adaptive_enabled,
    diagnostic_failure,
    logging,
    threading,
    time,
)


class GridChildMixin(object):
    """Pausing/resuming the grid around child screens, details return, live play and favourites."""

    def _pause_grid_background_for_child(self):
        try:self._stop_focus_heavy_artwork()
        except Exception:pass
        for name in ("_grid_focus_timer","_detail_prefetch_timer","_grid_idle_warm_timer"):
            timer=getattr(self,name,None)
            if timer is not None:
                try:timer.stop()
                except Exception as exc:diagnostic_failure("ui.grid.failsoft.1974",exc)
        try:
            cancel=getattr(self,"_page_prefetch_cancel",None)
            if cancel is not None:cancel.set()
        except Exception as exc:diagnostic_failure("ui.grid.failsoft.1978",exc)
        self._cancel_detached_page_prefetch_futures()
        for future in list(getattr(self,"_page_prefetch_futures",[]) or []):
            try:future.cancel()
            except Exception as exc:diagnostic_failure("ui.grid.failsoft.1981",exc)
        self._page_prefetch_futures=[]

    def _resume_grid_background_after_child(self):
        try:self._reset_focus_heavy_artwork()
        except Exception:pass
        self._page_prefetch_generation=int(getattr(self,"_page_prefetch_generation",0) or 0)+1
        self._page_prefetch_cancel=threading.Event()
        self._page_prefetch_seen=set()
        self._visible_tmdb_pending=set()
        try:self._detail_prefetch_timer.start(700,True)
        except Exception as exc:diagnostic_failure("ui.grid.failsoft.1991",exc)
        try:self._start_progressive_poster_prefetch()
        except Exception:pass
        try:self._schedule_visible_rating_sweeps()
        except Exception:pass

    def _details_returned(self,result=None):
        # Return to the exact poster and page that opened the details screen.
        _r57_return_mono=time.monotonic()
        target_page=max(1,int(getattr(self,"_restore_page",self.page) or 1))
        target_index=max(0,int(getattr(self,"_restore_index",self.index) or 0))
        if self.page != target_page or not self.grid_items:
            self.load_page(target_page,target_index)
            return
        self.index=max(0,min(target_index,len(self.grid_items)-1)) if self.grid_items else 0
        if self.grid_items:
            states=load_content_states(self.profile,self.media_type,self.grid_items)
            qualities=load_content_qualities(self.profile,self.media_type,self.grid_items) if self.media_type in ("vod","series") else ["" for _ in self.grid_items]
            self._grid_item_state={}
            for item,state,quality in zip(self.grid_items,states,qualities):
                row=dict(state or {});row["quality"]=quality or "";self._grid_item_state[id(item)]=row
            self._card_prog_shown={}
            try:self._apply_card_progress()
            except Exception as exc:optional_failure("ui.card_progress_return",exc)
            # Refresh text/state in place.  BACK from Details/Player must stay
            # RAM-only: Stage 3 already remembers the exact decoded visual for
            # every hydrated slot in _page_visual_ram.  Older code reopened a
            # detail snapshot + artwork bundle for every visible card here,
            # turning one BACK key into 14/27 synchronous HDD reads.
            for pos,item in enumerate(self.grid_items[:self.page_size]):
                try:
                    _meta=self._card_meta(item,pos)
                    self["item_meta%d"%pos].setText(_meta)
                    if self.media_type in ("vod","series"):
                        self._card_rating_layout(item,pos,_meta)
                except Exception as exc:optional_failure("ui.grid_return_meta",exc)
                try:
                    visual=self._page_visual_get(item) or {}
                    display=str(visual.get("display") or "")
                    poster=str(visual.get("poster") or display or "")
                    palette=str(visual.get("palette") or poster or "")
                    card=str(visual.get("card") or "")
                    if display:
                        self._grid_slot_paths[pos]=display
                        if palette:self._grid_palette_sources[pos]=palette
                        self._grid_visual_locks[pos]=display
                        self._grid_queue_decode(self._grid_generation,pos,display)
                    if card and adaptive_enabled():
                        self._grid_card_paths[pos]=card
                        try:
                            chrome=self["card_chrome%d"%pos]
                            if chrome.instance is not None:chrome.instance.setPixmapFromFile(card)
                            chrome.show()
                        except Exception as card_exc:optional_failure("ui.grid_return_card_ram",card_exc)
                except Exception as exc:optional_failure("ui.grid_return_ram_visual",exc)
            # R57: Cinematic is not a poster-card grid.  Its native surfaces are
            # restored by PremiumGlobalCinematicScreen._grid_shown_resume(), so
            # never probe poster-only card_chrome/_grid_card_paths on BACK.
            _r57_cinematic=(self.__class__.__name__=="PremiumGlobalCinematicScreen")
            if not _r57_cinematic:
                # Enigma2 can leave the previously focused pixmap surface stale
                # after the child screen closes. Rebind/show the selected slot now,
                # instead of waiting for a RIGHT/LEFT key to trigger a repaint.
                try:
                    slot=self.index
                    for name in ("art%d"%slot,"item_title%d"%slot,"card_chrome%d"%slot):
                        try:self[name].show()
                        except Exception as exc:diagnostic_failure("ui.grid.failsoft.2031",exc)
                    try:
                        _meta=self._card_meta(self.grid_items[slot],slot)
                        self["item_meta%d"%slot].setText(_meta)
                        self._card_rating_layout(self.grid_items[slot],slot,_meta)
                    except Exception as exc:optional_failure("ui.grid_return_rating_repaint",exc)
                    visual=self._page_visual_get(self.grid_items[slot]) or {}
                    art_path=str(visual.get("display") or self._grid_slot_paths.get(slot) or "")
                    if art_path:
                        art=self["art%d"%slot]
                        if art.instance is not None:art.instance.setPixmapFromFile(art_path)
                        art.show()
                    card=str(visual.get("card") or (getattr(self,"_grid_card_paths",{}) or {}).get(slot) or "")
                    if card and adaptive_enabled():
                        chrome=self["card_chrome%d"%slot]
                        if chrome.instance is not None:chrome.instance.setPixmapFromFile(card)
                        chrome.show()
                    self._grid_focus_chrome_slot=slot
                except Exception as exc:optional_failure("ui.grid_return_repaint",exc)
                try:self._grid_apply_current_selector()
                except Exception as exc:optional_failure("ui.grid_return_selector",exc)
            self._update_selection()
            self._resume_grid_background_after_child()
            try:
                logging.getLogger("UltraStalker").info(
                    "PERF57 series_child_return media=%s mode=%s page=%s index=%s cinematic=%s elapsed_ms=%s",
                    self.media_type,self.__class__.__name__,self.page,self.index,_r57_cinematic,
                    int((time.monotonic()-_r57_return_mono)*1000.0))
            except Exception:pass
        else:
            self._update_selection()
            self._resume_grid_background_after_child()

    def _play_live(self,item):
        command=item.get("cmd") or item.get("command") or item.get("url")
        if not command:self["status"].setText(_("No stream command"));return
        self["status"].setText(_("Creating stream link..."))
        def ok(url):
            url=url if isinstance(url,str) else ""
            if not url.strip():
                from .ui_helpers import report_stream_link_failure
                report_stream_link_failure(self);return
            name=str(item.get("name") or item.get("title") or "Live channel");add_recently_played(self.profile,"itv",item)
            engine=_configured_playback_engine(self._grid_settings or {})
            selected_page=self.page; selected_index=self.index
            def returned(result=None):
                self["status"].setText(_("Player closed"))
                # Keep the channel selected and make sure no player service is
                # resurrected behind the grid.
                if self.page != selected_page or not self.grid_items:
                    self.load_page(selected_page,selected_index)
                else:
                    self.index=max(0,min(selected_index,len(self.grid_items)-1))
                    self._update_selection()
            payload=_player_payload(item,self.profile,media_type="itv")
            payload["_player_client_ref"]=self.client;payload["_live_client_ref"]=self.client
            self.session.openWithCallback(returned,UltraStalkerPlayer,url.strip(),name,"itv",engine,payload)
        def link_failed(error):
            from .ui_helpers import report_stream_link_failure
            report_stream_link_failure(self,error)
        self._run_async(lambda handle:self.client.create_link(item,"itv",cancel_event=handle.cancel_event),ok,link_failed)

    def toggle_selected_favorite(self):
        if not self.grid_items:return
        item=self.grid_items[self.index];state=toggle_favorite(self.profile,self.media_type,item);self["status"].setText(_("Added to favorites") if state else _("Removed from favorites"))
        cached=self._grid_item_state.setdefault(id(item),{'favorite':False,'position':0,'duration':0,'completed':0});cached['favorite']=bool(state)
        self._refresh_favorite_button(item,cached)
        try:
            self["item_meta%d" % self.index].setText(self._card_meta(self.grid_items[self.index], self.index))
        except Exception as exc:
            optional_failure("ui", exc)
        self._update_header(self.grid_items[self.index])
