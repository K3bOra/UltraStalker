"""Persistent native series launchers and receiver season navigation."""
from __future__ import absolute_import, division, print_function, unicode_literals
from .. import us_env as _us_env
from ..us_env import str, int, open, OSError, FileNotFoundError
hashlib = _us_env.hashlib


def launcher_row(category_id, name, metadata_key, poster, seasons):
    identity = hashlib.sha1((str(category_id) + "|" + str(name)).encode("utf-8")).hexdigest()
    return {"id": "export-series-" + identity, "name": name,
            "cmd": "ultrastalker-series:" + identity,
            "_receiver_media_type": "series", "_receiver_metadata_key": metadata_key,
            "_receiver_picon_local": poster,
            "_receiver_series_launcher": {"format": 1, "seasons": seasons}}


def native_series_filename(profile, channel_key):
    from .bouquets import _profile_key
    return "userbouquet.ultrastalker_%s_native_series_%s.tv" % (_profile_key(profile), hashlib.sha1(str(channel_key).encode("utf-8")).hexdigest()[:16])


def native_bouquet_ref(filename, hidden=False):
    return '1:%d:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % (519 if hidden else 7, filename)


def native_series_ref(entry, key):
    """Native directory with the launcher's stable DVB metadata identity."""
    from . import bouquets as b
    profile = entry.get("profile") or {}
    proxy = b._service_ref(b._proxy_url(b._profile_key(profile), key,
                entry.get("proxy_port") or b._registry_port(), entry.get("proxy_token") or ""),
                entry.get("service_type") or 4097, identity=key)
    parts = proxy.split(":", 10)[:10]
    parts[0], parts[1] = "1", "7"
    return ":".join(parts) + ':FROM BOUQUET "%s" ORDER BY bouquet' % native_series_filename(profile, key)


def prepare_native_series_bouquets(entry):
    """One receiver list per series: season markers followed by episodes.

    Upgrade saved exports using disk data only. Visible series keep ordinary
    poster-bearing service entries; OK is routed before any playback request.
    """
    os = _us_env.os
    import glob
    from . import bouquets as b
    profile = entry.get("profile") or {}
    channels = entry.get("channels") or {}
    exports = entry.get("series_category_exports") or {}
    active = {c.get("launcher_key") for export in exports.values()
              for c in export.get("children") or [] if c.get("launcher_key")}
    writes, deletes, hidden_refs, targets = {}, set(), [], {}
    replacements, episode_picons = {}, {}
    for key in sorted(active):
        channel = channels.get(key) or {}
        hierarchy = channel.get("_receiver_series_launcher") or {}
        if not hierarchy: continue
        filename = native_series_filename(profile, key)
        root_lines = ["#NAME " + b._safe_name(channel.get("name") or "Series")]
        picons = []
        for index, season in enumerate(hierarchy.get("seasons") or [], 1):
            try: number = int(season.get("season_number") or index)
            except (ValueError, TypeError): number = index
            season_name = "S%02d" % number
            root_lines.extend(["#SERVICE 1:64:0:0:0:0:0:0:0:0::" + season_name,
                               "#DESCRIPTION " + season_name])
            for ep_key in season.get("episode_keys") or []:
                row = channels.get(ep_key)
                if not isinstance(row, dict): continue
                ref = b._service_ref(b._proxy_url(b._profile_key(profile), ep_key, entry.get("proxy_port") or b._registry_port(), entry.get("proxy_token") or ""), entry.get("service_type") or 4097, identity=ep_key)
                name = b._receiver_name(row, "episode")
                root_lines.extend(["#SERVICE %s:%s" % (ref, name), "#DESCRIPTION " + name])
                poster = row.get("_receiver_picon_local") or channel.get("_receiver_picon_local")
                if poster: picons.append((ref, poster, name))
        writes[os.path.join(b.ENIGMA2_DIR, filename)] = "\n".join(root_lines) + "\n"
        episode_picons[os.path.join(b.ENIGMA2_DIR, filename)] = picons
        # R413's season files must go: unreferenced userbouquets can be
        # rediscovered by Enigma and otherwise appear as extra top-level folders.
        deletes.update(glob.glob(os.path.join(b.ENIGMA2_DIR, filename[:-3] + "_season_*.tv")))
        hidden_refs.append((native_bouquet_ref(filename, hidden=True), channel.get("name") or "Series"))
        proxy = b._service_ref(b._proxy_url(b._profile_key(profile), key, entry.get("proxy_port") or b._registry_port(), entry.get("proxy_token") or ""), entry.get("service_type") or 4097, identity=key)
        directory = native_series_ref(entry, key)
        replacements[directory] = proxy
        targets[proxy] = directory
    if not writes: return False
    index_path = os.path.join(b.ENIGMA2_DIR, "bouquets.tv")
    with b._REGISTRY_LOCK:
        for export in exports.values():
            name = export.get("bouquet_name") or ""
            if not name or os.path.basename(name) != name: continue
            path = os.path.join(b.ENIGMA2_DIR, name)
            try:
                with open(path, "r", encoding="utf-8") as handle: original = handle.read()
            except OSError as exc:
                if not isinstance(exc, FileNotFoundError): raise
                continue
            lines = []
            for line in original.splitlines(True):
                if line.startswith("#SERVICE "):
                    # Proxy URLs are fully percent-encoded, so the first eleven
                    # fields identify the ref; preserve names containing colons.
                    fields = line[len("#SERVICE "):].split(":", 11)
                    if len(fields) == 12:
                        proxy = ":".join(fields[:11])
                        restored = replacements.get(proxy)
                        if restored:
                            line = "#SERVICE " + restored + ":" + fields[11]
                lines.append(line)
            text = "".join(lines)
            if text != original: writes[path] = text
        try:
            with open(index_path, "r", encoding="utf-8") as handle: index_text = handle.read()
        except OSError as exc:
            if not isinstance(exc, FileNotFoundError): raise
            index_text = "#NAME Bouquets (TV)\n"
        for ref, name in hidden_refs:
            if "#SERVICE " + ref not in index_text:
                index_text = index_text.rstrip("\n") + "\n#SERVICE " + ref + "\n#DESCRIPTION " + b._safe_name(name) + "\n"
        writes[index_path] = index_text
        snapshots = {}
        try:
            for path, text in writes.items():
                snapshot = b._snapshot_file(path)
                if snapshot[0] and snapshot[1] == text.encode("utf-8"): continue
                snapshots[path] = snapshot
                b._atomic_text(path, text, 0o644)
            for path in sorted(deletes):
                snapshots[path] = b._snapshot_file(path)
                os.unlink(path)
                b._fsync_parent_dir(path)
        except Exception:
            for path, snapshot in reversed(list(snapshots.items())):
                b._restore_snapshot(path, snapshot)
            raise
    # Register cached OK targets on the GUI thread. File building and all
    # registry reads have already finished in the export/boot worker.
    # During upgrade, restore R419 episode picon aliases only for rewritten
    # lists. Poster conversion is grouped by source in the existing publisher.
    # This runs in the boot/export worker, never inside an OK callback.
    changed_picons = list(item for path, items in episode_picons.items()
                      if path in snapshots for item in items)
    if changed_picons:
        try: b._publish_shared_picons(changed_picons)
        except Exception as exc:
            b.LOG.warning("Series episode poster aliases deferred: %s", exc.__class__.__name__)
    try:
        from twisted.internet import reactor
        reactor.callFromThread(register_series_selection, b._profile_key(profile), targets)
    except Exception as exc:
        b.LOG.warning("Series selection registration deferred: %s", exc.__class__.__name__)
    return bool(snapshots)


_SERIES_TARGETS_BY_PROFILE = {}
_SERIES_TARGETS = {}
_SERIES_VISIBLE_REFS = {}


def _series_selection_key(reference):
    """Enigma reserializes refs: hex case, zero padding and URL escaping vary.

    Match numeric service identity plus decoded path, not the original text.
    Names/providers are display-only and are deliberately excluded.
    """
    unquote = _us_env.urllib_parse.unquote
    try:
        text = reference.toString() if hasattr(reference, "toString") else str(reference)
        parts = text.split(":", 11)
        if len(parts) < 11: return None
        numbers = tuple(int(value, 10 if index < 2 else 16)
                        for index, value in enumerate(parts[:10]))
        return numbers, unquote(parts[10])
    except (ValueError, TypeError, AttributeError):
        return None


def _series_ok_handler(native, original):
    def selected(*args, **kwargs):
        # Receiver edit/move/PiP modes and all ordinary services retain their
        # existing action. The normal Series OK path performs no disk/network IO.
        if (getattr(native, "movemode", False) or
                getattr(native, "bouquet_mark_edit", 0) or
                getattr(native, "dopipzap", False)):
            return original(*args, **kwargs)
        try:
            current = native.getCurrentSelection()
            key = _series_selection_key(current)
            target = _SERIES_TARGETS.get(key)
        except Exception:
            return original(*args, **kwargs)
        if not target:
            return original(*args, **kwargs)
        from enigma import eServiceReference
        destination = eServiceReference(target)
        def enter(*unused, **ignored):
            native.enterPath(destination)
            goto = getattr(native, "gotoCurrentServiceOrProvider", None)
            if callable(goto): goto(destination)
        # Preserve the image's native parental-control prompt/check.
        try:
            from Components.ParentalControl import parentalControl
        except ImportError:
            parentalControl = None
        if parentalControl is None or parentalControl.isServicePlayable(current, enter, native.session):
            enter()
        return None
    selected._ultrastalker_series_ok = True
    return selected


def _register_series_paths(native):
    """Resolve managed rows at the native path boundary, including +/-.

    Keep the image's changeBouquet, pathUp, history and key bindings intact.
    pathUp restores a directory selection in its parent; that parent displays
    the corresponding poster service, so translate that selection back too.
    """
    original = getattr(native, "enterPath", None)
    if callable(original) and not getattr(original, "_ultrastalker_series_path", False):
        def enter_path(reference, *args, **kwargs):
            target = _SERIES_TARGETS.get(_series_selection_key(reference))
            if target:
                from enigma import eServiceReference
                reference = eServiceReference(target)
            return original(reference, *args, **kwargs)
        enter_path._ultrastalker_series_path = True
        native.enterPath = enter_path
    selection = getattr(native, "setCurrentSelection", None)
    if callable(selection) and not getattr(selection, "_ultrastalker_series_selection", False):
        def set_selection(reference, *args, **kwargs):
            visible = _SERIES_VISIBLE_REFS.get(_series_selection_key(reference))
            if visible:
                from enigma import eServiceReference
                reference = eServiceReference(visible)
            return selection(reference, *args, **kwargs)
        set_selection._ultrastalker_series_selection = True
        native.setCurrentSelection = set_selection


def register_series_selection(profile_key, targets):
    """Adapt the current image's existing OK binding, once per native list.

    No new Screen, skin, global class patch or polling timer. OpenATV Helpable
    ActionMaps and OpenBH/plain ActionMaps both dispatch through actions['ok'].
    """
    global _SERIES_TARGETS, _SERIES_VISIBLE_REFS
    _SERIES_TARGETS_BY_PROFILE[profile_key] = dict(targets)
    _SERIES_TARGETS = {key: path for rows in _SERIES_TARGETS_BY_PROFILE.values()
                       for ref, path in rows.items()
                       for key in [_series_selection_key(ref)] if key is not None}
    _SERIES_VISIBLE_REFS = {key: ref for rows in _SERIES_TARGETS_BY_PROFILE.values()
                            for ref, path in rows.items()
                            for key in [_series_selection_key(path)] if key is not None}
    try:
        from Screens.InfoBar import InfoBar
        native = getattr(getattr(InfoBar, "instance", None), "servicelist", None)
        if native is None:
            from Screens.ChannelSelection import ChannelSelection
            native = getattr(ChannelSelection, "instance", None)
        if native is None: return False
        _register_series_paths(native)
        installed = False
        for component in list(native.values()):
            actions = getattr(component, "actions", None)
            if not isinstance(actions, dict): continue
            original = actions.get("ok")
            if getattr(original, "_ultrastalker_series_ok", False):
                installed = True
            elif (getattr(original, "__self__", None) is native and
                    getattr(original, "__name__", "") == "channelSelected"):
                actions["ok"] = _series_ok_handler(native, original)
                installed = True
        if not installed:
            from . import bouquets as b
            b.LOG.warning("Series OK binding not yet available on native service list")
        return installed
    except Exception as exc:
        from . import bouquets as b
        b.LOG.warning("Series OK binding deferred: %s", exc.__class__.__name__)
        return False


def open_series(session, entry, channel, provider_factory=None, on_close=None):
    """Enter Enigma's existing ChannelSelection; no plugin screen or skin."""
    os = _us_env.os
    from . import bouquets as b
    from enigma import eServiceReference
    from Screens.InfoBar import InfoBar
    key = b._channel_key(channel)
    path = native_series_filename(entry.get("profile") or {}, key)
    if not os.path.isfile(os.path.join(b.ENIGMA2_DIR, path)):
        raise RuntimeError("Native series hierarchy is not ready")
    owner = getattr(InfoBar, "instance", None)
    native = getattr(owner, "servicelist", None)
    if native is None:
        from Screens.ChannelSelection import ChannelSelection
        native = session.instantiateDialog(ChannelSelection)
    prior = b._export_return_service(session)
    if prior: session.nav.playService(eServiceReference(prior))
    ref = eServiceReference(native_bouquet_ref(path))
    native.enterPath(ref)
    try: native.gotoCurrentServiceOrProvider(ref)
    except AttributeError: pass
    if session.current_dialog is native:
        if on_close: on_close()
        return
    def closed():
        try:
            if on_close: on_close()
        finally:
            if closed in native.onClose: native.onClose.remove(closed)
    native.onClose.append(closed)
    try:
        session.execDialog(native)
    except Exception:
        closed()
        raise
