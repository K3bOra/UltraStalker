# -*- coding: utf-8 -*-
"""Missing-poster and backdrop cache workers and folder artwork caching.

Methods moved verbatim out of ``PremiumGridBase`` (ui_grid_base.py); behaviour is unchanged.
This module is imported by ui_grid_base.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, open, max, min, us_casefold
from .ui_grid_base import (
    CACHE_IO_EXECUTOR,
    _,
    _page_backdrop_fetch_original_q60,
    _page_backdrop_original_url,
    _page_backdrop_q60_path,
    _page_backdrop_q60_valid,
    os,
    time,
)


class GridPostersMixin(object):
    """Missing-poster and backdrop cache workers and folder artwork caching."""

    def _check_missing_posters_worker(self, rows, cancel_event=None):
        """TMDB-first two-pass artwork audit.

        Pass 1: TMDB gets first chance to fill highest-quality masters.
        Pass 2: provider/Xtream fills any component still physically missing.
        Existing TMDB files are immutable and provider rescue never overwrites them.
        """
        cfg=self._grid_settings or {};profile=self.profile;media_type=self.media_type
        credential=str(cfg.get("tmdb_credential") or "").strip()
        tmdb_available=bool(cfg.get("tmdb_enabled",True) and credential)
        language=cfg.get("tmdb_language","ar-EG");timeout=min(9,max(4,int(cfg.get("timeout",10) or 10)))
        rows=[dict(x) for x in (rows or []) if isinstance(x,dict)]
        try:
            if not cfg.get("diagnostic_logging"):raise RuntimeError("trace stays in RAM unless diagnostics are on")
            from .persistent_cache import LOGS as _BLUE_LOG_DIR
            trace_path=os.path.join(_BLUE_LOG_DIR,"blue_artwork_trace.log")
        except Exception:
            # Keep routine traces off the HDD (no spin-up / writes during browsing).
            trace_path="/tmp/UltraStalker_blue_artwork_trace.log"
        def blue_trace(message):
            try:
                parent=os.path.dirname(trace_path)
                if parent and not os.path.isdir(parent):os.makedirs(parent,exist_ok=True)
                with open(trace_path,"a",encoding="utf-8") as fh:
                    fh.write("%s %s\n"%(time.strftime("%Y-%m-%d %H:%M:%S"),str(message or "")))
            except Exception:
                pass
        try:
            parent=os.path.dirname(trace_path)
            if parent and not os.path.isdir(parent):os.makedirs(parent,exist_ok=True)
            with open(trace_path,"w",encoding="utf-8") as fh:
                fh.write("Ultra Stalker BLUE artwork trace FIRST VALID ARTWORK WINS\n")
        except Exception:
            pass
        blue_trace("START media=%s rows=%d tmdb_available=%s genre=%r"%(media_type,len(rows),tmdb_available,str(getattr(self,"genre","") or "")))
        def cancelled():return bool(cancel_event is not None and cancel_event.is_set())
        def valid_file(path,min_size=512):
            try:return bool(path and os.path.isfile(str(path)) and os.path.getsize(str(path))>min_size)
            except Exception:return False
        def backdrop_truth(path):
            # release: a backdrop is cached only when the actual HDD file passes
            # the same landscape/dimension validation used by ArtworkV2. A JSON
            # pointer or any existing JPEG is not enough. This is the single truth
            # used by BLUE for preflight, commit verification and final counting.
            try:
                from .artwork_v2 import _valid_backdrop
                return bool(_valid_backdrop(str(path or "")))
            except Exception:
                return False
        def state(item):
            try:data=load_artwork_v2_manifest(profile,media_type,item) or {}
            except Exception:data={}
            poster=str(data.get("poster_local") or "")
            backdrop=str(data.get("backdrop_local") or "")
            return data,poster,(backdrop if backdrop_truth(backdrop) else "")
        def tmdb_master_state(data):
            """Return canonical TMDB component readiness, ignoring BLUE/provider fallbacks."""
            try:
                tid=(data or {}).get("tmdb_id")
                if not tid:return None,None
                paths=canonical_art_paths((data or {}).get("media_type") or media_type,tid) or {}
                return valid_file(paths.get("poster")),backdrop_truth(paths.get("backdrop"))
            except Exception:return None,None
        def _uniq_urls(values):
            out=[]
            for value in values or []:
                text=str(value or "").strip()
                if text and text not in out:out.append(text)
            return out
        provider_enriched={}
        def provider_candidates(item):
            # BLUE/provider rescue must inspect every provider artwork field, not
            # just _image_url()'s first hit.  Some Stalker rows put a generic
            # placeholder in screenshot_uri/movie_image while the exact cover is
            # present in poster/cover (or only in the richer search row).  Using
            # the first field made a real provider poster effectively invisible.
            posters=[];backs=[]
            if not item.get("_rescue_provider_art_generic"):
                posters.extend((item.get("_rescue_provider_art_url"),item.get("_visible_provider_art_url")))
            if not item.get("_rescue_provider_backdrop_generic"):
                backs.extend(item.get("_rescue_provider_backdrop_candidates") or [])
                backs.extend((item.get("_rescue_provider_backdrop_url"),item.get("_visible_provider_backdrop_url")))
            for key in ("poster","poster_url","cover","cover_url","movie_image","image","img","hd","pic","screenshot_uri","screenshot","stream_icon","logo","logo_url","picon"):
                value=item.get(key)
                values=value if isinstance(value,(list,tuple)) else [value]
                for entry in values:
                    text=str(entry or "").strip()
                    low=us_casefold(text)
                    if not text or low in ("null","none","[]","{}") or any(tag in low for tag in ("placeholder","noimage","no_image","default_poster","default-cover")):
                        continue
                    posters.append(text)
            try:
                from .ui_artwork_helpers import _backdrop_candidates as _manual_backdrop_candidates
                backs.extend(_manual_backdrop_candidates(item) or [])
            except Exception:pass
            return _uniq_urls(posters),_uniq_urls(backs)
        def enrich_provider(item,need_p,need_b):
            # Provider search is intentionally disabled here. Pass 2 may only
            # reuse artwork already present on the catalogue row.
            return dict(item)
        try:
            from .artwork_v2 import save_manual_rescue_art
        except Exception:
            save_manual_rescue_art=None

        def adopt_existing_hdd(item):
            """Promote already-cached local artwork into the shared master store.

            Old builds can have perfectly usable poster/backdrop files referenced by
            detail snapshots/visual bundles but not yet represented in artwork_v2.
            BLUE must treat those HDD files as hits instead of re-downloading them.
            """
            if not callable(save_manual_rescue_art):
                return False,False
            try:
                data,p,b=state(item)
                need_p=not valid_file(p);need_b=not valid_file(b)
                if not (need_p or need_b):
                    return False,False
                snap=(load_shared_detail_snapshot(self.profile,self.media_type,item)
                      if isinstance(item,dict) and item.get("_xtream")
                      else load_detail_snapshot(self.profile,self.media_type,item))
                bundle=_load_visual_bundle(self.profile,self.media_type,item,snap) or {}
                local_p=str(bundle.get("poster") or "")
                local_b=str(bundle.get("backdrop") or "")
                use_p=local_p if need_p and valid_file(local_p) else None
                use_b=local_b if need_b and backdrop_truth(local_b) else None
                if not (use_p or use_b):
                    return False,False
                saved=save_manual_rescue_art(profile,media_type,item,poster=use_p,backdrop=use_b,source="existing_hdd_adopt") or {}
                got_p=bool(use_p and valid_file(saved.get("poster_local")))
                got_b=bool(use_b and backdrop_truth(saved.get("backdrop_local")))
                blue_trace("HDD_ADOPT title=%r poster=%s backdrop=%s"%(str(item.get("name") or item.get("title") or "")[:120],got_p,got_b))
                return got_p,got_b
            except Exception as exc:
                optional_failure("ui.artwork_existing_hdd_adopt",exc)
                return False,False

        # R171: release BLUE is strictly missing-only.  The old forced title
        # diagnostic performed TMDB/provider probes before preflight even when every
        # asset was already hot.  Diagnostics do not belong in the user cache lane.

        # Preflight: immutable existing masters never enter any worker. First
        # adopt artwork that older builds already cached on HDD but never indexed.
        # Keep the initial physical state so the final UI counter can report TMDB
        # recoveries too (older code counted provider rescue only).
        initial_state={}
        missing=[];hot=0
        clean_upgrade_candidates=0;clean_backdrop_upgraded=0
        # release unified BLUE pass. The visible counter belongs to TITLES, not
        # internal stages. A cached title is checked/finalised once here; a title
        # missing artwork is finalised once after its artwork rescue below. This
        # prevents the old 1..N artwork pass followed by another 1..N Cinematic
        # pass that looked like the cache had restarted from zero.
        blue_done=0
        blue_total=len(rows)
        try:self._folder_artwork_progress.put((0,blue_total))
        except Exception:pass

        def _blue_finish_title(item):
            """Finish one title inside the same BLUE lifecycle.

            Poster/backdrop are the hard prerequisites. Optional screen-specific
            presentation hooks (Cinematic final backdrop/adaptive/details) are
            executed here, before this title advances the single folder counter.
            """
            if cancelled():raise _ArtworkCancelled()
            data,p,b=state(item)
            try:
                from .details_authority import remember_catalogue_metadata
                remember_catalogue_metadata(media_type,item,data)
            except Exception as exc:optional_failure("ui.blue_catalogue_metadata",exc)
            if not (valid_file(p) and backdrop_truth(b)):
                return False
            ready_hook=getattr(self,"_folder_artwork_ready_hook",None)
            if callable(ready_hook):
                try:
                    if ready_hook(item,data):
                        return True
                except Exception as exc:
                    optional_failure("ui.artwork_blue_ready_hook",exc)
            finalize_hook=getattr(self,"_folder_artwork_finalize_hook",None)
            if callable(finalize_hook):
                try:
                    return bool(finalize_hook(item,p,b,data,data,cancel_event))
                except Exception as exc:
                    optional_failure("ui.artwork_blue_finalize_hook",exc)
                    return False
            return True

        for item in rows:
            try:
                _d0,_p0,_b0=state(item)
                initial_state[self._page_visual_key(item)]=(not valid_file(_p0),not valid_file(_b0))
            except Exception:
                initial_state[self._page_visual_key(item)]=(True,True)
            if cancelled():raise _ArtworkCancelled()
            adopt_existing_hdd(item)
            data,p,b=state(item)

            # R92 clean-backdrop maintenance is a separate, targeted lane inside
            # the explicit BLUE worker. Existing poster/backdrop readiness no
            # longer suppresses the upgrade. It uses only the verified TMDb id,
            # never title search, and leaves the old backdrop in place on error.
            # R171 missing-only contract: a physically valid backdrop is already hot.
            # BLUE never spends network/CPU replacing valid existing artwork merely
            # because an older selector version produced it. Explicit cache fills
            # missing components; it does not refresh finished titles from scratch.

            # release persistent BLUE contract: a screen-specific completed vault
            # is authoritative before any TMDB/provider canonical-master retry.
            # Once Cinematic has successfully persisted poster/backdrop/final
            # backdrop/adaptive/details for a title, pressing BLUE again must be
            # a read-only verification. It must never invalidate, rewrite, touch
            # timestamps, resolve identity or re-download that title merely
            # because the canonical TMDB master path differs from the trusted HDD
            # vault. Missing/corrupt physical files still fall through to repair.
            ready_hook=getattr(self,"_folder_artwork_ready_hook",None)
            persistent_ready=False
            if callable(ready_hook):
                try:persistent_ready=bool(ready_hook(item,data))
                except Exception as exc:optional_failure("ui.artwork_blue_persistent_ready",exc)
            if persistent_ready:
                hot+=1
                blue_done+=1
                try:self._folder_artwork_progress.put((blue_done,blue_total))
                except Exception:pass
                continue

            cp,cb=tmdb_master_state(data)
            p_ready=bool(valid_file(p) or cp)
            b_ready=bool(backdrop_truth(b) or cb)
            needs_art=not (p_ready and b_ready)
            if not needs_art:
                hot+=1
            if needs_art:
                missing.append(item)
            else:
                _blue_finish_title(item)
                blue_done+=1
                try:self._folder_artwork_progress.put((blue_done,blue_total))
                except Exception:pass
        # PERFLAB8: process every missing title end-to-end before moving to the
        # next one.  The old two-pass worker resolved TMDB for the entire folder
        # first, then provider rescue, then finalisation.  When the first visible
        # page (typically 14 titles) was already cached, the BLUE counter sat at
        # 14 for minutes while hundreds of missing titles were silently processed.
        # Keep the same TMDB-first/provider-second policy, but make progress
        # title-granular so Cache Artwork never looks frozen and each completed
        # title is durable before the next one starts.
        resolver=ArtworkV2(credential,language,timeout) if tmdb_available else None
        if resolver is not None:
            try: resolver.trace_cb=blue_trace
            except Exception: pass
        poster_recovered=0;backdrop_recovered=0
        for item in missing:
            if cancelled():raise _ArtworkCancelled()
            data={}
            resolve_item=dict(item)
            # Xtream info may contribute identity/metadata only.  Provider art
            # itself still waits until TMDB has had first refusal for this title.
            if item.get("_xtream") and hasattr(self.client,"enrich_provider_artwork"):
                try:
                    try: rich=self.client.enrich_provider_artwork(dict(item),media_type,cancel_event,force=True) or {}
                    except TypeError: rich=self.client.enrich_provider_artwork(dict(item),media_type,cancel_event) or {}
                    identity_keys=("tmdb_id","tmdb","imdb_id","imdb","year","releaseDate","release_date","releasedate",
                                   "_provider_name","original_name","original_title","o_name","english_name","english_title")
                    for key in identity_keys:
                        value=rich.get(key) if isinstance(rich,dict) else None
                        if value not in (None,"",[],{}): resolve_item[key]=value
                    blue_trace("IDENTITY_INFO title=%r tmdb_id=%r imdb_id=%r year=%r"%(
                        str(item.get("name") or item.get("title") or "")[:120],resolve_item.get("tmdb_id") or resolve_item.get("tmdb"),
                        resolve_item.get("imdb_id") or resolve_item.get("imdb"),resolve_item.get("year")))
                except Exception as exc:
                    optional_failure("ui.artwork_identity_xtream_info",exc)
                    blue_trace("IDENTITY_INFO_ERROR title=%r error=%r"%(str(item.get("name") or item.get("title") or "")[:120],str(exc)[:140]))

            if resolver is not None:
                _blue_fast_art_only=bool(getattr(self,"_folder_artwork_fast_art_only",False))
                # Preserve the release-only Generation War identity diagnostics.
                # These probes never alter the selected identity or artwork; they
                # are trace-only and intentionally remain unchanged in PERFLAB8.
                try:
                    _focus_title=str(item.get("name") or item.get("title") or "").strip()
                    if "generation war" in us_casefold(_focus_title):
                        _id_fields=("name","title","_raw_name","_provider_name","original_name","original_title","o_name","english_name","english_title","tmdb_id","tmdb","imdb_id","imdb","year","release_date","first_air_date")
                        _parts=[]
                        for _k in _id_fields:
                            _v=resolve_item.get(_k)
                            if _v not in (None,"",[],{}): _parts.append("%s=%r"%(_k,str(_v)[:160]))
                        blue_trace("IDENTITY_FOCUS_INPUT "+" ".join(_parts))
                        _direct=str(resolve_item.get("tmdb_id") or resolve_item.get("tmdb") or "").strip()
                        if _direct.isdigit():
                            try:
                                _det=resolver.tmdb._get("/tv/%s"%_direct,{"language":"en-US"}) or {}
                                blue_trace("IDENTITY_FOCUS_DIRECT id=%s name=%r original=%r year=%r"%(_direct,str(_det.get("name") or "")[:120],str(_det.get("original_name") or "")[:120],str(_det.get("first_air_date") or "")[:10]))
                            except Exception as _exc:
                                blue_trace("IDENTITY_FOCUS_DIRECT_ERROR id=%s error=%r"%(_direct,str(_exc)[:160]))
                        _queries=[]
                        for _k in ("name","title","_raw_name","_provider_name","original_name","original_title","o_name","english_name","english_title"):
                            _q=str(resolve_item.get(_k) or "").strip()
                            if _q and _q not in _queries: _queries.append(_q)
                        _yr=str(resolve_item.get("year") or resolve_item.get("first_air_date") or resolve_item.get("release_date") or "")[:4]
                        for _q in _queries[:8]:
                            for _lang in (language,"en-US"):
                                try:
                                    _params={"query":_q,"language":_lang,"include_adult":"false"}
                                    if _yr.isdigit(): _params["first_air_date_year"]=_yr
                                    _pay=resolver.tmdb._get("/search/tv",_params) or {}
                                    _rs=[]
                                    for _r in (_pay.get("results") or [])[:3]:
                                        _rs.append("%s:%s|%s|%s"%(str(_r.get("id") or ""),str(_r.get("name") or "")[:70],str(_r.get("original_name") or "")[:70],str(_r.get("first_air_date") or "")[:10]))
                                    blue_trace("IDENTITY_FOCUS_SEARCH q=%r lang=%s year=%r top=%r"%(_q,_lang,_yr,_rs))
                                except Exception as _exc:
                                    blue_trace("IDENTITY_FOCUS_SEARCH_ERROR q=%r lang=%s error=%r"%(_q,_lang,str(_exc)[:160]))
                except Exception as _exc:
                    blue_trace("IDENTITY_FOCUS_TRACE_ERROR error=%r"%str(_exc)[:180])
                try:
                    data=resolver.resolve(profile,media_type,resolve_item,full=(not _blue_fast_art_only),cancel_event=cancel_event) or {}
                    if _blue_fast_art_only and not cancelled():
                        # BLUE remains poster/backdrop focused.  If full=False left
                        # the landscape master absent, fetch that exact component
                        # without hydrating credits/cast profiles.
                        try:
                            _fresh,_fp,_fb=state(item)
                            if not backdrop_truth(_fb):
                                # Issue 4: BLUE already has a verified identity from
                                # resolve().  Hand that exact id to the backdrop-only
                                # lane instead of making a difficult/translated title
                                # prove itself through search again after its HDD
                                # backdrop bytes were cleaned or moved.
                                _backdrop_item=dict(resolve_item)
                                _verified_id=str((data or {}).get("tmdb_id") or "").strip()
                                if _verified_id.isdigit():
                                    _backdrop_item["_locked_tmdb_id"]=_verified_id
                                    _backdrop_item["_locked_tmdb_type"]=(data or {}).get("media_type") or media_type
                                _back=resolver.resolve_backdrop_only(profile,media_type,_backdrop_item,cancel_event=cancel_event) or {}
                                if isinstance(_back,dict) and _back:
                                    merged=dict(data);merged.update(_back);data=merged
                        except Exception as _exc:
                            optional_failure("ui.artwork_blue_backdrop_only",_exc)
                except Exception as exc:
                    optional_failure("ui.artwork_tmdb_master",exc);data={}

            # resolve() normally persists the canonical files; re-commit the
            # lightweight per-row pointer when identity was matched.
            if isinstance(data,dict) and data.get("matched") and data.get("tmdb_id"):
                try:
                    from .artwork_v2 import save_manifest as _save_artwork_v2_manifest
                    _save_artwork_v2_manifest(profile,media_type,item,data)
                except Exception as exc: optional_failure("ui.artwork_tmdb_pointer_commit",exc)
            try:
                title=str(item.get("name") or item.get("title") or "")[:120]
                _fresh,_fp,_fb=state(item)
                blue_trace("TMDB title=%r matched=%s tmdb_id=%r poster=%s backdrop=%s committed_poster=%s committed_backdrop=%s error=%r"%(title,bool(data.get("matched")),data.get("tmdb_id"),bool(valid_file(data.get("poster_local"))),bool(valid_file(data.get("backdrop_local"))),bool(valid_file(_fp)),bool(backdrop_truth(_fb)),str(data.get("error") or "")[:100]))
            except Exception:pass

            # Provider fallback is evaluated immediately for this title, only for
            # components that are still physically missing after TMDB/Fanart.
            _state_data,_state_p,_state_b=state(item)
            need_p=not valid_file(_state_p);need_b=not backdrop_truth(_state_b)
            if need_p or need_b:
                enriched=enrich_provider(item,need_p,need_b)
                purls,burls=provider_candidates(enriched)
                try:
                    title=str(item.get("name") or item.get("title") or "")[:120]
                    blue_trace("PROVIDER title=%r need_p=%s need_b=%s p_candidates=%d b_candidates=%d xtream=%s"%(title,need_p,need_b,len(purls),len(burls),bool(item.get("_xtream"))))
                except Exception:pass
                provider_p="";provider_b=""
                if need_p:
                    for purl in purls:
                        if cancelled():raise _ArtworkCancelled()
                        try:provider_p=_download_portal_artwork(purl,profile,self.client,False,6.0,cancel_event,item=enriched,trace_cb=blue_trace,force_attempt=True) or ""
                        except Exception as exc:optional_failure("ui.artwork_provider_poster_rescue",exc);provider_p=""
                        if valid_file(provider_p):break
                    try:blue_trace("PROVIDER_POSTER title=%r success=%s tried=%d"%(str(item.get("name") or item.get("title") or "")[:120],bool(valid_file(provider_p)),len(purls)))
                    except Exception:pass
                if need_b:
                    for burl in burls:
                        if cancelled():raise _ArtworkCancelled()
                        try:provider_b=_download_portal_artwork(burl,profile,self.client,True,6.5,cancel_event,item=enriched,trace_cb=blue_trace,force_attempt=True) or ""
                        except Exception as exc:optional_failure("ui.artwork_provider_backdrop_rescue",exc);provider_b=""
                        if valid_file(provider_b):break
                    try:blue_trace("PROVIDER_BACKDROP title=%r success=%s tried=%d"%(str(item.get("name") or item.get("title") or "")[:120],bool(valid_file(provider_b)),len(burls)))
                    except Exception:pass
                if callable(save_manual_rescue_art) and (valid_file(provider_p) or valid_file(provider_b)):
                    try:
                        saved=save_manual_rescue_art(profile,media_type,item,
                            poster=(provider_p if need_p and valid_file(provider_p) else None),
                            backdrop=(provider_b if need_b and valid_file(provider_b) else None),
                            source="provider_missing_only") or {}
                        if need_p and valid_file(saved.get("poster_local")):poster_recovered+=1
                        if need_b and valid_file(saved.get("backdrop_local")):backdrop_recovered+=1
                        try:blue_trace("SAVE title=%r poster_saved=%s backdrop_saved=%s"%(str(item.get("name") or item.get("title") or "")[:120],bool(valid_file(saved.get("poster_local"))),bool(valid_file(saved.get("backdrop_local")))))
                        except Exception:pass
                        # The provider downloader is transport only.  Once copied
                        # into the canonical/fallback master, discard the URL-hash
                        # transport file so one component has one persistent copy.
                        for source,target in ((provider_p,saved.get("poster_local")),(provider_b,saved.get("backdrop_local"))):
                            try:
                                source=str(source or "");target=str(target or "")
                                base=os.path.basename(source)
                                if source and target and source!=target and os.path.isfile(source) and not (base.startswith("movie_") or base.startswith("tv_") or base.startswith("fallback_")):
                                    os.unlink(source)
                            except Exception:pass
                    except Exception as exc:optional_failure("ui.artwork_provider_rescue_save",exc)

            # Finish the screen-specific readiness for this title now, then move
            # the one user-facing counter exactly once.  No hidden folder-wide
            # second pass means 14/N can no longer sit frozen while work continues.
            try:_blue_finish_title(item)
            except _ArtworkCancelled:raise
            except Exception as exc:optional_failure("ui.artwork_blue_finish_missing",exc)
            blue_done+=1
            try:self._folder_artwork_progress.put((blue_done,blue_total))
            except Exception:pass
            try:blue_trace("ITEM_DONE %d/%d title=%r"%(blue_done,blue_total,str(item.get("name") or item.get("title") or "")[:120]))
            except Exception:pass

        # Final count from the single shared store; no source is allowed to replace a hit.
        # Count *all* physical recoveries, including TMDB/Fanart, not just provider
        # fallback. This makes the BLUE status agree with what the user can see.
        complete=0;still_p=0;still_b=0;all_p_recovered=0;all_b_recovered=0
        for item in rows:
            data,p,b=state(item)
            p_ok=valid_file(p);b_ok=backdrop_truth(b)
            was_p_missing,was_b_missing=initial_state.get(self._page_visual_key(item),(True,True))
            if was_p_missing and p_ok:all_p_recovered+=1
            if was_b_missing and b_ok:all_b_recovered+=1
            if p_ok and b_ok:
                complete+=1
            else:
                if not p_ok:still_p+=1
                if not b_ok:still_b+=1
        poster_recovered=all_p_recovered
        backdrop_recovered=all_b_recovered
        poster_target=poster_recovered+still_p
        backdrop_target=backdrop_recovered+still_b
        result={"total":len(rows),"done":complete,"work_total":len(missing),"downloaded":poster_recovered+backdrop_recovered,"hot":hot,"failed":still_p+still_b,"poster_missing":poster_target,"backdrop_missing":backdrop_target,"poster_recovered":poster_recovered,"backdrop_recovered":backdrop_recovered,"poster_failed":still_p,"backdrop_failed":still_b,"backdrop_upgrade_candidates":clean_upgrade_candidates,"backdrop_upgraded":clean_backdrop_upgraded,"recovered":poster_recovered}
        try:blue_trace("FINAL total=%d poster_recovered=%d poster_left=%d backdrop_recovered=%d backdrop_left=%d clean_candidates=%d clean_upgraded=%d"%(len(rows),poster_recovered,still_p,backdrop_recovered,still_b,clean_upgrade_candidates,clean_backdrop_upgraded))
        except Exception:pass
        return result

    def _cache_backdrop_category_rows(self, cancel_event=None):
        """Materialize the complete current category before BLUE starts artwork work."""
        if bool(getattr(self,"_view_active",False)):
            rows=list(getattr(self,"_view_items",[]) or [])
            if not rows:
                try:rows=list(self._build_folder_view() or [])
                except Exception:rows=[]
            return list(dict(row) for row in rows if isinstance(row,dict))

        target=max(0,int(self._cache_backdrop_category_total() or 0))
        existing=getattr(self,"_folder_catalog",None)
        if isinstance(existing,list) and existing and (not target or len(existing)>=target):
            return list(dict(row) for row in existing if isinstance(row,dict))[:target or None]

        cat_key=(
            str((getattr(self,"profile",None) or {}).get("portal") or "").rstrip("/").lower(),
            str(getattr(self,"media_type","") or ""),
            str(getattr(self,"genre","") or "*"),
        )
        client_cache=getattr(self.client,"_blue_category_rows_cache",None)
        if isinstance(client_cache,dict):
            cached_rows=client_cache.get(cat_key)
            if isinstance(cached_rows,list) and cached_rows and (not target or len(cached_rows)>=target):
                self._folder_catalog=list(dict(r) for r in cached_rows if isinstance(r,dict))
                return list(dict(r) for r in cached_rows if isinstance(r,dict))[:target or None]

        rows=[];seen=set();previous_signature=None
        first=[]
        try:first=self._portal_page(1,cancel_event=cancel_event) or []
        except Exception as exc:
            optional_failure("ui.blue_category_first_page",exc)
            first=[]
        if not first:return rows

        native=max(1,int(getattr(self,"_portal_page_size",0) or len(first) or self.page_size or 1))
        target=max(target,max(0,int(getattr(self,"_portal_total",0) or 0)))
        expected_pages=((target+native-1)//native) if target else 500
        expected_pages=max(1,min(int(expected_pages or 1),500))

        def fetch_page(page):
            if page==1:return list(first)
            last_error=None
            for attempt in range(4):
                if cancel_event is not None and cancel_event.is_set():raise _ArtworkCancelled()
                try:
                    page_rows=self._portal_page(page,cancel_event=cancel_event) or []
                    if page_rows:return page_rows
                except Exception as exc:
                    last_error=exc
                    optional_failure("ui.blue_category_page",exc)
                try:
                    bump=getattr(self.client,"_bump_content_cache_generation",None)
                    if callable(bump):bump()
                except Exception:pass
                try:time.sleep(0.10*(attempt+1))
                except Exception:pass
            if last_error is not None:
                optional_failure("ui.blue_category_page_final",last_error)
            return []

        incomplete_enum=False
        for native_page in range(1,expected_pages+1):
            if cancel_event is not None and cancel_event.is_set():raise _ArtworkCancelled()
            page_rows=fetch_page(native_page)
            if not page_rows:
                if target and len(rows)<target:incomplete_enum=True
                break

            try:signature=tuple(self._blue_item_sig(row) for row in page_rows[:6] if isinstance(row,dict))
            except Exception:signature=()
            if native_page>1 and signature and signature==previous_signature:
                break
            previous_signature=signature

            added=0
            for row in page_rows:
                if cancel_event is not None and cancel_event.is_set():raise _ArtworkCancelled()
                if not isinstance(row,dict):continue
                sig=self._blue_item_sig(row)
                if sig in seen:continue
                seen.add(sig);rows.append(dict(row));added+=1
                if target and len(rows)>=target:break
            if target and len(rows)>=target:break
            if not added:break
            if not target and len(page_rows)<native:break

        if rows and not incomplete_enum and not (cancel_event is not None and cancel_event.is_set()):
            try:
                self._folder_catalog=list(dict(r) for r in rows)
                if self.client is not None:
                    if not isinstance(getattr(self.client,"_blue_category_rows_cache",None),dict):
                        self.client._blue_category_rows_cache={}
                    if len(self.client._blue_category_rows_cache)>=24:
                        self.client._blue_category_rows_cache.clear()
                    self.client._blue_category_rows_cache[cat_key]=list(dict(r) for r in rows)
            except Exception:
                pass

        return rows

    def _cache_backdrop_category_total(self):
        """Best GUI-safe total for BLUE Cache Artwork without network work."""
        if bool(getattr(self,"_view_active",False)):
            try:return len(list(getattr(self,"_view_items",[]) or []))
            except Exception:return 0
        existing=getattr(self,"_folder_catalog",None)
        if isinstance(existing,list) and existing:
            return len(existing)
        try:return max(0,int(getattr(self,"_portal_total",0) or 0))
        except Exception:return 0

    def _page_backdrop_existing_q60(self, item, hot=None):
        """Return a verified existing Q60 or canonical backdrop for this item without downloading."""
        row=item if isinstance(item,dict) else {};hot=hot if isinstance(hot,dict) else {}
        candidates=[]
        for src in (hot,row):
            for key in ("backdrop_local","backdrop_fast","backdrop_display"):
                value=str(src.get(key) or "").strip()
                if value:candidates.append(value)
        try:
            from .persistent_cache import BACKDROPS
            root=os.path.realpath(str(BACKDROPS or ""))
        except Exception:root=""
        for path in candidates:
            try:
                real=os.path.realpath(path)
                if root and (real==root or real.startswith(root+os.sep)) and _page_backdrop_q60_valid(real):return real
                if os.path.isfile(real) and os.path.getsize(real)>4096:
                    from .artwork_v2 import _valid_backdrop
                    if _valid_backdrop(real):return real
            except Exception:pass
        for src in (hot,row):
            for key in ("backdrop_path","tmdb_backdrop_path","_backdrop_path",
                        "backdrop_url","_backdrop_url","tmdb_backdrop_url"):
                url=_page_backdrop_original_url(src.get(key))
                destination=_page_backdrop_q60_path(url)
                if destination and _page_backdrop_q60_valid(destination):return destination
        tid=hot.get("tmdb_id") or row.get("_locked_tmdb_id") or row.get("_ultra_search_verified_tmdb_id") or row.get("tmdb_id")
        if tid not in (None,"") and str(tid).strip().isdigit():
            try:
                mt=str(hot.get("media_type") or row.get("media_type") or self.media_type or "")
                c_paths=canonical_art_paths(mt,int(str(tid).strip())) or {}
                c_bd=str(c_paths.get("backdrop") or "")
                if c_bd and _page_backdrop_q60_valid(c_bd):return c_bd
            except Exception:
                pass
        return ""

    def _cache_current_page_backdrops_worker(self, rows=None, cancel_event=None):
        """BLUE button: cache ONLY missing screen artwork across the current category.

        Already-downloaded items are detected in a fast local HDD preflight pass
        and skipped immediately without re-downloading or running network extras.
        """
        need_backdrop=bool(getattr(self,"artwork_cache_backdrops",False))
        cache_label=_("Backdrop cache") if need_backdrop else _("Poster cache")
        details_ready=0;logos_ready=0;extras_seen=set()
        changed_items=set()
        from .core.executor import threading as _cache_threading
        import shutil as _shutil
        changed_guard=_cache_threading.Lock()
        def was_changed(item):
            with changed_guard:return id(item) in changed_items
        def mark_changed(item):
            with changed_guard:changed_items.add(id(item))
        cfg=dict(getattr(self,"_grid_settings",None) or load_settings() or {})
        credential=str(cfg.get("tmdb_credential") or "").strip()
        language=str(cfg.get("tmdb_language") or "ar-EG").strip() or "ar-EG"
        try:timeout=min(10,max(4,int(cfg.get("timeout",10) or 10)))
        except Exception:timeout=8

        supplied=list(dict(x) for x in (rows or []) if isinstance(x,dict)) if rows is not None else None
        planned=len(supplied) if supplied is not None else self._cache_backdrop_category_total()
        done=0;cached=0;downloaded=0;failed=0;gallery=0;primary=0
        result={"backdrop_page_cache":True,"cache_label":cache_label,"total":planned,"done":0,"cached":0,"downloaded":0,"failed":0,"gallery":0,"primary":0}
        if not (cfg.get("tmdb_enabled",True) and credential):
            result["failed"]=0;result["reason"]="tmdb_unavailable";result["incomplete"]=True;return result
        try:
            from .artwork_v2_impl import (ArtworkV2 as _ArtworkV2Impl, save_manifest as _save_manifest,
                _valid, _download, _write_marker, _ranked_posters,
                _load_canonical, _lock)
            from .artwork_v2 import load_fast_local_poster, save_manual_rescue_art
            from .tmdb import TMDBClient
            from .backdrop_clean_runtime import rank_clean_backdrops
            resolver=_ArtworkV2Impl(credential,language,timeout)
        except Exception as exc:
            optional_failure("ui.page_backdrop_cache_import",exc)
            result["failed"]=0;result["reason"]="resolver_unavailable";result["incomplete"]=True;return result

        def poster_ready(data):
            path=str((data or {}).get("poster_local") or "")
            return bool(_valid(path))

        def emit_progress(force=False):
            display_total=max(int(planned or 0),int(done or 0))
            try:self._folder_artwork_progress.put(("__page_backdrop_progress__",{"cache_label":cache_label,"done":done,"total":display_total,"cached":cached,"downloaded":downloaded,"failed":failed}))
            except Exception:pass

        try:
            catalogue=supplied if supplied is not None else self._cache_backdrop_category_rows(cancel_event)
        except _ArtworkCancelled:
            catalogue=[]
        except Exception as exc:
            optional_failure("ui.blue_category_enumeration",exc);catalogue=[]
        catalogue=list(dict(x) for x in (catalogue or []) if isinstance(x,dict))
        from .manual_identity import apply_choice
        catalogue=list(apply_choice(self.profile,self.media_type,item) for item in catalogue)
        if not planned:planned=len(catalogue)
        if len(catalogue)>planned:planned=len(catalogue)
        result["total"]=planned

        def _preflight_item_cached(item):
            """Pure local HDD/RAM check. Returns (is_cached, manifest_dict)."""
            try:
                vis=self._page_visual_get(item)
                if isinstance(vis,dict) and vis:
                    if not need_backdrop and poster_ready(vis):
                        return True,vis
                    if need_backdrop and self._page_backdrop_existing_q60(item,vis):
                        return True,vis
            except Exception:
                pass
            try:
                fast=load_fast_local_poster(self.profile,self.media_type,item)
                if isinstance(fast,dict) and fast:
                    if not need_backdrop and poster_ready(fast):
                        return True,fast
                    if need_backdrop and self._page_backdrop_existing_q60(item,fast):
                        return True,fast
            except Exception:
                pass
            hot={}
            try:
                hot=load_artwork_v2_manifest(self.profile,self.media_type,item) or {}
            except Exception:
                hot={}
            if not need_backdrop:
                if poster_ready(hot):
                    return True,hot
                try:
                    sp,ss=self._shared_tmdb_poster(item)
                    if sp and _valid(sp):
                        merged=dict(hot);merged.update(ss or {});merged["poster_local"]=sp
                        return True,merged
                except Exception:
                    pass
                tid=hot.get("tmdb_id") or item.get("_locked_tmdb_id") or item.get("_ultra_search_verified_tmdb_id") or item.get("tmdb_id")
                if tid not in (None,"") and str(tid).strip().isdigit():
                    try:
                        mt=str(hot.get("media_type") or ("tv" if self.media_type=="series" else "movie"))
                        c_paths=canonical_art_paths(mt,int(str(tid).strip())) or {}
                        cp=str(c_paths.get("poster") or "")
                        if cp and _valid(cp):
                            merged=dict(hot);merged["poster_local"]=cp
                            return True,merged
                    except Exception:
                        pass
                try:
                    snap=(load_shared_detail_snapshot(self.profile,self.media_type,item)
                          if isinstance(item,dict) and item.get("_xtream")
                          else load_detail_snapshot(self.profile,self.media_type,item))
                    bundle=_load_visual_bundle(self.profile,self.media_type,item,snap) or {}
                    lp=str(bundle.get("poster") or "")
                    if lp and _valid(lp):
                        if callable(save_manual_rescue_art):
                            saved=save_manual_rescue_art(self.profile,self.media_type,item,poster=lp,source="existing_hdd_adopt") or {}
                            if poster_ready(saved):return True,saved
                        merged=dict(hot);merged["poster_local"]=lp
                        return True,merged
                except Exception:
                    pass
                return False,hot
            else:
                b_hit=self._page_backdrop_existing_q60(item,hot)
                if b_hit:
                    merged=dict(hot);merged["backdrop_local"]=b_hit
                    return True,merged
                try:
                    sb,ss=self._shared_tmdb_backdrop(item)
                    if sb and _page_backdrop_q60_valid(sb):
                        merged=dict(hot);merged.update(ss or {});merged["backdrop_local"]=sb
                        return True,merged
                except Exception:
                    pass
                try:
                    snap=(load_shared_detail_snapshot(self.profile,self.media_type,item)
                          if isinstance(item,dict) and item.get("_xtream")
                          else load_detail_snapshot(self.profile,self.media_type,item))
                    bundle=_load_visual_bundle(self.profile,self.media_type,item,snap) or {}
                    lb=str(bundle.get("backdrop") or "")
                    if lb and _page_backdrop_q60_valid(lb):
                        merged=dict(hot);merged["backdrop_local"]=lb
                        return True,merged
                except Exception:
                    pass
                return False,hot

        # Fast preflight: skip every already-downloaded item immediately!
        pending=[]
        for item in catalogue:
            if cancel_event is not None and cancel_event.is_set():break
            is_cached,hot_snap=_preflight_item_cached(item)
            if is_cached:
                cached+=1
                done+=1
                if hot_snap.get("tmdb_id") or hot_snap.get("overview"):
                    details_ready+=1
                try:
                    from .title_logo_ultra import ultra_title_logo_cached
                    if ultra_title_logo_cached(self.media_type,item,hot_snap,(900,210)):
                        logos_ready+=1
                except Exception:
                    pass
            else:
                pending.append((item,hot_snap))
        emit_progress(True)

        # If every item in the folder is already cached on HDD, finish immediately!
        if not pending:
            result.update({
                "total":planned,"done":done,"cached":cached,"downloaded":0,"failed":0,
                "gallery":0,"primary":0,"details_ready":details_ready,"logos_ready":logos_ready,
            })
            return result

        def _try_provider_rescue(item,need_p,need_b):
            """Fallback to provider artwork when TMDb has no match or no image."""
            if not callable(save_manual_rescue_art):
                return False
            posters=[];backs=[]
            if not item.get("_rescue_provider_art_generic"):
                for k in ("_rescue_provider_art_url","_visible_provider_art_url"):
                    v=str(item.get(k) or "").strip()
                    if v and v not in posters:posters.append(v)
            if not item.get("_rescue_provider_backdrop_generic"):
                for v in (item.get("_rescue_provider_backdrop_candidates") or []):
                    v=str(v or "").strip()
                    if v and v not in backs:backs.append(v)
                for k in ("_rescue_provider_backdrop_url","_visible_provider_backdrop_url"):
                    v=str(item.get(k) or "").strip()
                    if v and v not in backs:backs.append(v)
            for key in ("poster","poster_url","cover","cover_url","movie_image","image","img","hd","pic","screenshot_uri","screenshot","stream_icon","logo","logo_url","picon"):
                value=item.get(key)
                values=value if isinstance(value,(list,tuple)) else [value]
                for entry in values:
                    text=str(entry or "").strip()
                    low=us_casefold(text)
                    if not text or low in ("null","none","[]","{}") or any(tag in low for tag in ("placeholder","noimage","no_image","default_poster","default-cover")):
                        continue
                    if text not in posters:posters.append(text)
            try:
                from .ui_artwork_helpers import _backdrop_candidates as _manual_backdrop_candidates
                for v in (_manual_backdrop_candidates(item) or []):
                    v=str(v or "").strip()
                    if v and v not in backs:backs.append(v)
            except Exception:
                pass
            got_p="";got_b=""
            if need_p:
                for purl in posters[:4]:
                    if cancel_event is not None and cancel_event.is_set():return False
                    try:
                        cand=_download_portal_artwork(purl,self.profile,self.client,False,5.0,cancel_event,item=item,force_attempt=True) or ""
                        if _valid(cand):
                            got_p=cand;break
                    except Exception:
                        pass
            if need_b:
                for burl in backs[:4]:
                    if cancel_event is not None and cancel_event.is_set():return False
                    try:
                        cand=_download_portal_artwork(burl,self.profile,self.client,True,5.5,cancel_event,item=item,force_attempt=True) or ""
                        if _valid(cand):
                            got_b=cand;break
                    except Exception:
                        pass
            if got_p or got_b:
                try:
                    saved=save_manual_rescue_art(
                        self.profile,self.media_type,item,
                        poster=(got_p if need_p and _valid(got_p) else None),
                        backdrop=(got_b if need_b and _valid(got_b) else None),
                        source="provider_missing_only",
                    ) or {}
                    if not need_backdrop and poster_ready(saved):
                        mark_changed(item)
                        return True
                    if need_backdrop and self._page_backdrop_existing_q60(item,saved):
                        mark_changed(item)
                        return True
                except Exception:
                    pass
            return False

        def process_missing(item,hot):
            if cancel_event is not None and cancel_event.is_set():return False,"",""
            if getattr(self,"_screen_closed",False) or getattr(self,"media_type",None) is None or getattr(self,"profile",None) is None:
                return False,"closed",""
            try:hot=load_artwork_v2_manifest(self.profile,self.media_type,item) or hot or {}
            except Exception:pass
            if not need_backdrop:
                if poster_ready(hot):return True,"cached",""
            elif self._page_backdrop_existing_q60(item,hot):
                return True,"cached",""
            ok=False;choice="";iso="";tmdb_id=None;mt=""
            try:
                mt,tmdb_id,_confidence,_identity_source,_candidate=resolver._resolve_identity(self.media_type,item,hot)
                if not tmdb_id:
                    rmt,rid,_rconf,_rseed,rtrusted=resolver._resolve_poster_rescue(self.media_type,item)
                    if rid and rtrusted:
                        mt,tmdb_id,_candidate=rmt,rid,_rseed
                if not tmdb_id:
                    if _try_provider_rescue(item,not need_backdrop,need_backdrop):
                        return True,"downloaded","provider_rescue"
                    return False,"no_art",""
                try:
                    from .details_authority import remember_catalogue_metadata
                    remember_catalogue_metadata(self.media_type,item,{
                        "tmdb_id":int(tmdb_id),"media_type":mt,"identity_verified":True})
                except Exception as exc:optional_failure("ui.blue_catalogue_metadata",exc)
                current=dict(hot) if str(hot.get("tmdb_id") or "")==str(tmdb_id) else {}
                canonical=_load_canonical(mt,tmdb_id) or {}
                for key in ("poster_local","poster_path","poster_url","backdrop_local","backdrop_path","backdrop_url"):
                    if not current.get(key) and canonical.get(key):current[key]=canonical[key]
                try:
                    c_paths_init=canonical_art_paths(mt,tmdb_id) or {}
                    if not current.get("poster_local") and _valid(c_paths_init.get("poster")):
                        current["poster_local"]=str(c_paths_init.get("poster"))
                    if not current.get("backdrop_local") and _page_backdrop_q60_valid(c_paths_init.get("backdrop")):
                        current["backdrop_local"]=str(c_paths_init.get("backdrop"))
                except Exception:
                    pass
                p_ok=True if need_backdrop else poster_ready(current)
                b_existing_path=self._page_backdrop_existing_q60(item,current) if need_backdrop else ""
                b_existing=bool(b_existing_path) if need_backdrop else True
                if need_backdrop and b_existing_path and not current.get("backdrop_local"):
                    current["backdrop_local"]=b_existing_path
                if p_ok and b_existing:
                    linked=dict(current);linked.update({"matched":True,"identity_verified":True,"tmdb_id":int(tmdb_id),"media_type":str(mt)})
                    if _save_manifest(self.profile,self.media_type,item,linked) is False:return False,"",""
                    hot.update(linked)
                    return True,("downloaded" if was_changed(item) else "cached"),""
                lang_short=str(language or "en").split("-")[0].lower() or "en"
                seed=_candidate if isinstance(_candidate,dict) else {}
                quick_path=str(current.get("poster_path") or seed.get("poster_path") or "").strip()
                if not need_backdrop and quick_path:
                    details={"poster_path":quick_path}
                else:
                    try:
                        details=resolver.tmdb._get("/%s/%s"%(mt,int(tmdb_id)),{
                            "append_to_response":"images",
                            "include_image_language":"null,en,%s"%lang_short,
                        }) or {}
                    except Exception:
                        if need_backdrop:
                            raise
                        # The verified title ID is already known. Continue to
                        # its image gallery if the details endpoint fails.
                        details={}
                if not p_ok and not (cancel_event is not None and cancel_event.is_set()):
                    p_path=str(current.get("poster_path") or details.get("poster_path") or "").strip()
                    if not p_path:
                        ranked_p=_ranked_posters((details.get("images") or {}).get("posters") or [],lang_short,1)
                        p_path=str((ranked_p[0] if ranked_p else {}).get("file_path") or "")
                    p_target=str((canonical_art_paths(mt,tmdb_id) or {}).get("poster") or "")
                    paths=[p_path] if p_path else []
                    for gallery_pass in range(2):
                        if gallery_pass:
                            images=details.get("images") if isinstance(details.get("images"),dict) else {}
                            if not images.get("posters"):
                                images=resolver.tmdb._get("/%s/%s/images"%(mt,int(tmdb_id)),{}) or {}
                            paths=[str(x.get("file_path") or "") for x in _ranked_posters(images.get("posters") or [],lang_short,4)
                                   if x.get("file_path") and str(x.get("file_path"))!=p_path]
                        for candidate_path in paths:
                            if cancel_event is not None and cancel_event.is_set():return False,"",""
                            p_url=TMDBClient.image_url(candidate_path,"w780")
                            if not (p_url and p_target):continue
                            with _lock(p_target):
                                already=poster_ready({"poster_local":p_target})
                                got=p_target if already else _download(p_url,p_target,timeout,normalize_poster=True,refresh_poster=False)
                                if got and _valid(got):
                                    _write_marker(got+".hq780")
                                    pointer={"matched":True,"identity_verified":True,"tmdb_id":int(tmdb_id),"media_type":str(mt),
                                             "poster_local":got,"poster_path":candidate_path,"poster_url":p_url}
                                    if _save_manifest(self.profile,self.media_type,item,pointer) is not False:
                                        hot.update(pointer);p_ok=True
                                        if not already:mark_changed(item)
                            if p_ok:break
                        if p_ok:break
                    if not p_ok:
                        if _try_provider_rescue(item,True,False):
                            p_ok=True
                if not need_backdrop or b_existing:
                    if p_ok:
                        return True,("downloaded" if was_changed(item) else "cached"),""
                    return False,"no_art",""
                if cancel_event is not None and cancel_event.is_set():return False,"",""
                fp=str(details.get("backdrop_path") or "").strip()
                if fp:
                    choice="tmdb_primary"
                else:
                    images=details.get("images") if isinstance(details.get("images"),dict) else {}
                    ranked=rank_clean_backdrops(images.get("backdrops") or [],language,16)
                    if not ranked:
                        images=resolver.tmdb._get("/%s/%s/images"%(mt,int(tmdb_id)),{}) or {}
                        ranked=rank_clean_backdrops(images.get("backdrops") or [],language,16)
                    if ranked:
                        pick=ranked[0];fp=str(pick.get("file_path") or "").strip();iso=str(pick.get("iso_639_1") or "")
                        choice="gallery_fallback"
                if not fp:
                    if _try_provider_rescue(item,False,True):
                        return True,"downloaded","provider_rescue"
                    return False,"no_art",""
                url=str(TMDBClient.image_url(fp,"original") or "")
                destination=_page_backdrop_q60_path(url)
                if not destination:
                    raise RuntimeError("Q60 destination unavailable")
                if _page_backdrop_q60_valid(destination):
                    ok=True;state="cached"
                else:
                    built=_page_backdrop_fetch_original_q60(url,destination,timeout,cancel_event)
                    ok=bool(_page_backdrop_q60_valid(built));state="downloaded" if ok else ""
                if ok:
                    canonical_bd = destination
                    try:
                        c_paths = canonical_art_paths(mt, tmdb_id) or {}
                        c_target = str(c_paths.get("backdrop") or "")
                        if c_target:
                            if not _page_backdrop_q60_valid(c_target) and os.path.abspath(destination)!=os.path.abspath(c_target):
                                tmp_c = c_target + ".tmp.%s.%s"%(os.getpid(), _cache_threading.get_ident())
                                try:
                                    _shutil.copyfile(destination, tmp_c)
                                    os.replace(tmp_c, c_target)
                                except Exception:
                                    try:
                                        if os.path.exists(tmp_c):os.unlink(tmp_c)
                                    except Exception:pass
                            if _page_backdrop_q60_valid(c_target):
                                canonical_bd = c_target
                    except Exception:
                        pass
                    pointer={
                        "matched":True,"identity_verified":True,"tmdb_id":int(tmdb_id),"media_type":str(mt),
                        "backdrop_local":canonical_bd,"backdrop_path":fp,"backdrop_url":url,"backdrop_source":choice+":q60",
                        "clean_backdrop_selector_version":3,"clean_backdrop_choice":choice,"clean_backdrop_iso":iso,
                    }
                    try:
                        if _save_manifest(self.profile,self.media_type,item,pointer) is False:return False,"",""
                        hot.update(pointer)
                    except Exception as exc:
                        optional_failure("ui.page_backdrop_pointer",exc);return False,"",""
                    if state=="downloaded":mark_changed(item)
                    return p_ok,("downloaded" if was_changed(item) else "cached"),choice
            except Exception as exc:
                optional_failure("ui.page_backdrop_cache_item",exc)
            return False,"",""

        def finish_title(item,hot):
            try:outcome=process_missing(item,hot)
            except Exception as exc:
                optional_failure("ui.blue_title",exc);outcome=(False,"","")
            extra={}
            ok_flag=bool(outcome[0]) if isinstance(outcome,(tuple,list)) and outcome else False
            if ok_flag and id(item) not in extras_seen and not (cancel_event is not None and cancel_event.is_set()):
                extras_seen.add(id(item))
                try:
                    from .blue_cache_extras import cache_blue_extras
                    latest=load_artwork_v2_manifest(self.profile,self.media_type,item) or hot or {}
                    extra=cache_blue_extras(self.profile,self.media_type,item,latest,cfg,
                        cancel_event=cancel_event,provider_client=None) or {}
                except Exception as exc:optional_failure("ui.blue_extras",exc)
            return outcome,extra

        def results_for(pairs):
            if not need_backdrop:
                from .core.shared_executors import iter_poster_cache_results
                for pair,payload in iter_poster_cache_results(pairs,finish_title,cancel_event):
                    if not isinstance(payload,(tuple,list)) or len(payload)!=2:
                        payload=((False,"",""),{})
                    yield pair,payload
            else:
                for item,hot in pairs:
                    if cancel_event is not None and cancel_event.is_set():break
                    yield (item,hot),finish_title(item,hot)

        retry_pending=[]
        for (item,hot),((ok,state,choice),extra) in results_for(pending):
            details_ready+=int(bool(extra.get("details_ready")));logos_ready+=int(bool(extra.get("logo_ready")))
            if cancel_event is not None and cancel_event.is_set():break
            if ok:
                if state=="cached":cached+=1
                else:downloaded+=1
                if choice=="tmdb_primary":primary+=1
                elif choice=="gallery_fallback":gallery+=1
                done+=1;emit_progress(True)
            elif state=="no_art":
                failed+=1
                done+=1;emit_progress(True)
            else:
                retry_pending.append((item,hot))

        def retry_rows():
            for item,hot in retry_pending:
                if cancel_event is not None and cancel_event.is_set():break
                try:hot=load_artwork_v2_manifest(self.profile,self.media_type,item) or hot or {}
                except Exception:pass
                yield item,hot
        for (item,hot),((ok,state,choice),extra) in results_for(retry_rows()):
            details_ready+=int(bool(extra.get("details_ready")));logos_ready+=int(bool(extra.get("logo_ready")))
            if cancel_event is not None and cancel_event.is_set():break
            if ok:
                if state=="cached":cached+=1
                else:downloaded+=1
                if choice=="tmdb_primary":primary+=1
                elif choice=="gallery_fallback":gallery+=1
            else:
                failed+=1
            done+=1;emit_progress(True)

        result.update({"total":planned,"done":done,"cached":cached,"downloaded":downloaded,"failed":failed,"gallery":gallery,"primary":primary,"details_ready":details_ready,"logos_ready":logos_ready})
        if planned and len(catalogue)<planned and not (cancel_event is not None and cancel_event.is_set()):
            result["incomplete"]=True
            result["reason"]="category_enumeration_incomplete"
        elif cancel_event is not None and cancel_event.is_set():
            result["incomplete"]=True;result["reason"]="cancelled"
        return result

    def cache_folder_artwork(self):
        """Cache every title in the current category in one continuous run."""
        if self.media_type not in ("vod","series") or getattr(self,"_folder_artwork_cache_running",False):return False
        cfg=dict(getattr(self,"_grid_settings",None) or load_settings() or {})
        if not (cfg.get("tmdb_enabled",True) and str(cfg.get("tmdb_credential") or "").strip()):
            try:self["status"].setText(_("Enable TMDb and configure its key to cache artwork"))
            except Exception:pass
            return False
        # GUI-safe count only: the already-open category owns its catalogue total.
        # Fifty is deliberately *not* a cap; it is only the worker chunk size.
        planned=self._cache_backdrop_category_total()
        if planned<=0:
            try:planned=len(list(getattr(self,"grid_items",[]) or []))
            except Exception:planned=0
        if planned<=0:
            try:self["status"].setText(_("No content"))
            except Exception:pass
            return False
        self._folder_artwork_cache_running=True;self._folder_artwork_ui_finalized=False
        self._folder_artwork_cache_done=0;self._folder_artwork_cache_total=planned
        try:self._folder_artwork_idle_label=str(self["blue"].getText() or _("Cache Artwork"))
        except Exception:self._folder_artwork_idle_label=_("Cache Artwork")
        try:
            self["status"].setText(_("%s • checking %d/%d • new %d • already %d")%(_("Backdrop cache") if getattr(self,"artwork_cache_backdrops",False) else _("Poster cache"),0,planned,0,0))
            self["blue"].setText("0 / %d"%planned)
            if self["blue"].instance is not None:self["blue"].instance.setFont(_ultra_rfont("Regular",22))
        except Exception:pass
        try:self._async_set_poll_interval(120)
        except Exception:pass
        from .core.executor import threading as _blue_threading
        cancel_event=_blue_threading.Event()
        self._folder_artwork_cancel=cancel_event
        if not getattr(self,"_blue_close_cancel_bound",False):
            def cancel_blue():
                event=getattr(self,"_folder_artwork_cancel",None)
                if event is not None:event.set()
            try:
                self.onClose.append(cancel_blue)
                self._blue_close_cancel_bound=True
            except Exception:pass
        def worker():return self._cache_current_page_backdrops_worker(None,cancel_event)
        try:
            future=CACHE_IO_EXECUTOR.submit(worker,_task_key="page-q60:%x"%id(self),_replace_task_key=True)
            self._folder_artwork_future=future
            def finished(done_future):
                try:payload=done_future.result() or {"backdrop_page_cache":True,"total":planned,"done":0,"cached":0,"downloaded":0,"failed":planned}
                except Exception as exc:
                    optional_failure("ui.page_backdrop_cache_future",exc);payload={"backdrop_page_cache":True,"total":planned,"done":0,"cached":0,"downloaded":0,"failed":planned}
                try:self._folder_artwork_progress.put(("__complete__",payload))
                except Exception:pass
            future.add_done_callback(finished)
            return True
        except Exception as exc:
            self._folder_artwork_cache_running=False;optional_failure("ui.page_backdrop_cache_submit",exc)
            try:self["blue"].setText(getattr(self,"_folder_artwork_idle_label",_("Cache Artwork")))
            except Exception:pass
            return False
from .wqhd_layout import responsive_font as _ultra_rfont, factors as _ultra_factors

def _ultra_osd_scale():
    return _ultra_factors()[1]
