# -*- coding: utf-8 -*-
"""Keys, grouping, totals, labels and result merging.

Methods moved verbatim out of ``PortalGlobalSearchScreen`` (ui_screens_search.py); behaviour is unchanged.
This module is imported by ui_screens_search.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, max, us_casefold
from enigma import eSize
from .ui_screens_search import (
    OrderedDict,
    _,
    _canonical_search_title,
    _image_url,
    _norm_search,
)


class SearchRowsMixin(object):
    """Keys, grouping, totals, labels and result merging."""

    @staticmethod
    def _profile_key(profile):
        return (
            str((profile or {}).get("portal") or "").rstrip("/").lower(),
            str((profile or {}).get("mac") or "").upper(),
        )

    @staticmethod
    def _norm(value):
        return " ".join(us_casefold(str(value or "")).replace("_", " ").replace("-", " ").split())

    @staticmethod
    def _source_key(profile):
        p = profile if isinstance(profile, dict) else {}
        return (
            str(p.get("portal") or p.get("url") or p.get("host") or "").rstrip("/").lower(),
            str(p.get("mac") or "").upper(),
            str(p.get("username") or p.get("user") or ""),
            str(p.get("type") or p.get("kind") or "").lower(),
            str(p.get("name") or p.get("title") or ""),
        )

    def _group_key(self, item):
        typ = str((item or {}).get("_search_media_type") or "vod").lower()
        raw = (item or {}).get("name") or (item or {}).get("title") or ""
        title = _canonical_search_title(raw) or _norm_search(raw)
        return (typ, title)

    def _group_copies(self, item):
        rows = (item or {}).get("_search_copies") if isinstance(item, dict) else None
        if isinstance(rows, list) and rows:
            return [row for row in rows if isinstance(row, dict)]
        return [item] if isinstance(item, dict) else []

    def _group_stats(self, item):
        copies = self._group_copies(item)
        servers = {self._source_key(row.get("_search_profile") or {}) for row in copies}
        return len(copies), len(servers)

    def _search_totals(self):
        copies = 0
        servers = set()
        for group in self.results:
            rows = self._group_copies(group)
            copies += len(rows)
            for row in rows:
                servers.add(self._source_key(row.get("_search_profile") or {}))
        return len(self.results), copies, len(servers)

    def _search_status_text(self, searching=False):
        titles, copies, servers = self._search_totals()
        if searching:
            completed = int(getattr(self, "_search_done_sources", 0) or 0)
            total = int(getattr(self, "_search_portal_count", 0) or 0)
            prefix = (_("Searching...") + " %d/%d %s" % (completed, total, _("sources"))) if total else _("Searching...")
            if not titles: return prefix
            return prefix + "  •  " + (_("%d results") % titles) + " • " + (_("%d sources") % servers)
        if not titles: return _("No matching content")
        return (_("%d results") % titles) + " • " + (_("%d sources") % servers)

    def _search_family_result_counts(self):
        """Count displayed result cards by family, with no double count.

        A federated card can own copies from both families. Search already paints
        such a card with the Xtream/M3U metadata colour, so the same rule owns
        it here. The two numbers therefore always add up to the visible result
        total instead of inflating the count when a title exists on both sides.
        """
        portal=0;xtream=0
        for group in list(getattr(self,"results",[]) or []):
            has_xtream=False
            for row in self._group_copies(group):
                profile=(row or {}).get("_search_profile") or {}
                source_type=str((row or {}).get("_search_source_type") or profile.get("source_type") or "").strip().lower()
                if source_type in ("xtream","m3u"):
                    has_xtream=True;break
            if has_xtream:xtream+=1
            else:portal+=1
        return portal,xtream

    @staticmethod
    def _clean_search_copy(row):
        clean=dict(row or {})
        for key in ("_search_profile","_search_portal_name","_search_source_type","_search_group","_search_group_key","_search_group_title","_search_copies","_search_visual_peers","_search_seed_snapshot","_search_seed_trusted","_search_force_complete"):
            clean.pop(key,None)
        return clean

    def _set_source_mix_labels(self):
        mix=getattr(self,"_search_source_mix",{}) or {}
        pcount=int(mix.get("portal",0) or 0);xcount=int(mix.get("xtream",0) or 0)
        visible=bool(pcount or xcount)
        portal_text=("%d PORTAL" % pcount) if visible else ""
        dot_text="•" if visible else ""
        xtream_text=("%d XTREAM" % xcount) if visible else ""
        portal_hits,xtream_hits=self._search_family_result_counts()
        have_results=bool(getattr(self,"results",None))
        self._set_label_if_changed(self["search_portal_hits"],str(portal_hits) if (have_results and pcount) else "")
        self._set_label_if_changed(self["search_xtream_hits"],str(xtream_hits) if (have_results and xcount) else "")
        self._set_label_if_changed(self["search_portal_mix"],portal_text)
        self._set_label_if_changed(self["search_mix_dot"],dot_text)
        self._set_label_if_changed(self["search_xtream_mix"],xtream_text)
        # Keep the family summary as three independent colour lanes. Result-card
        # counts sit exactly above their family labels with a 2px vertical gap.
        try:
            width=int(self._history_overlay._measure(portal_text,17)) if portal_text else 0
        except Exception:
            width=max(0,len(portal_text)*9)
        try:
            xwidth=int(self._history_overlay._measure(xtream_text,17)) if xtream_text else 0
        except Exception:
            xwidth=max(0,len(xtream_text)*9)
        # Measured widths under-report on the device; never go below a safe per-glyph width.
        width=max(width,int(len(portal_text)*12.5)) if portal_text else 0
        xwidth=max(xwidth,int(len(xtream_text)*12.5)) if xtream_text else 0
        try:
            portal_x=560
            dot_x=portal_x+max(0,width)+22
            xtream_x=dot_x+34
            dot_inst=self["search_mix_dot"].instance
            xtream_inst=self["search_xtream_mix"].instance
            ph_inst=self["search_portal_hits"].instance
            xh_inst=self["search_xtream_hits"].instance
            pm_inst=self["search_portal_mix"].instance
            from .wqhd_layout import xy as _wqhd_xy, wh as _wqhd_wh
            if pm_inst is not None:
                pm_inst.resize(eSize(*_wqhd_wh(max(40,width+10),28)))
            if xtream_inst is not None:
                xtream_inst.resize(eSize(*_wqhd_wh(max(40,xwidth+14),28)))
            if dot_inst is not None:dot_inst.move(ePoint(*_wqhd_xy(dot_x,518)))
            if xtream_inst is not None:xtream_inst.move(ePoint(*_wqhd_xy(xtream_x,518)))
            if ph_inst is not None:ph_inst.move(ePoint(*_wqhd_xy(max(0,portal_x+max(0,width)//2-45),488)))
            if xh_inst is not None:xh_inst.move(ePoint(*_wqhd_xy(max(0,xtream_x+max(0,xwidth)//2-45),488)))
        except Exception as exc:
            optional_failure("ui.search_source_mix_position",exc)

    def _cancel_xtream_warm(self):
        try:self._xtream_warm_cancel_event.set()
        except Exception:pass
        future=getattr(self,"_xtream_warm_future",None)
        if future is not None and not future.done():
            try:future.cancel()
            except Exception:pass
        self._xtream_warm_future=None

    def _merge_search_rows(self, rows):
        changed = 0
        groups = getattr(self, "_search_groups", None)
        if not isinstance(groups, OrderedDict):
            groups = OrderedDict(); self._search_groups = groups
        for item in rows or []:
            if not isinstance(item, dict):
                continue
            p = item.get("_search_profile") or {}
            typ = item.get("_search_media_type") or "vod"
            identity = (
                item.get("id")
                or item.get("movie_id")
                or item.get("series_id")
                or item.get("cmd")
                or item.get("url")
                or item.get("name")
                or item.get("title")
            )
            copy_key = (self._source_key(p), typ, str(identity))
            if copy_key in self._search_seen:
                continue
            self._search_seen.add(copy_key)
            gkey = self._group_key(item)
            group = groups.get(gkey)
            if group is None:
                group = dict(item)
                group["_search_group"] = True
                group["_search_group_key"] = gkey
                group["_search_group_title"] = str(item.get("_raw_name") or item.get("name") or item.get("title") or "").strip()
                group["_search_copies"] = []
                groups[gkey] = group
                self.results.append(group)
                buckets = self._ensure_search_buckets()
                bucket_type = "series" if str(typ or "vod").lower() == "series" else "vod"
                buckets[bucket_type].append(group)
            group["_search_copies"].append(item)
            # If the first source lacked artwork but a later copy has it, let the
            # single grouped card inherit only the artwork-related fields.
            try:
                if not _image_url(group) and _image_url(item):
                    # Promote the later copy to representative so relative artwork
                    # URLs stay paired with the profile they came from.
                    copies_ref = group.get("_search_copies")
                    group_title = group.get("_search_group_title")
                    group_key = group.get("_search_group_key")
                    group.update(item)
                    group["_search_group"] = True
                    group["_search_group_key"] = group_key
                    group["_search_group_title"] = group_title
                    group["_search_copies"] = copies_ref
            except Exception:
                pass
            changed += 1
        return changed
