# -*- coding: utf-8 -*-
"""Player-owned colour on the approved Spotlight glass; never sample artwork."""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str, int, max, min
from .asset_paths import canonical_asset as _canonical_asset
hashlib = _us_env.hashlib
os = _us_env.os
threading = _us_env.threading
from .adaptive_mode import adaptive_enabled
from .persistent_cache import GENERATED
from .core.image_budget import image_budgeted
from .ui_zap_spotlight import build_surface

_MASTER = os.path.join(os.path.dirname(__file__), "assets_fhd", "player", "player_overlay_dark_530x920.png")

def _rgb(value):
    try:
        if isinstance(value, (tuple, list)) and len(value) == 3:
            return tuple(max(0, min(255, int(v))) for v in value)
        text = str(value or "").strip().lstrip("#")
        if len(text) == 8: text = text[-6:]
        if len(text) != 6: return None
        return tuple(int(text[i:i+2], 16) for i in (0, 2, 4))
    except (TypeError, ValueError):
        return None

def overlay_colours(frames=None):
    """OFF is the authored material. ON follows the bound Player frame colours."""
    if not adaptive_enabled() or not isinstance(frames, dict): return None, None
    accent = _rgb(frames.get("accent"))
    hot = _rgb(frames.get("accent_soft")) or accent
    return accent, hot

@image_budgeted
def premium_assets(specs, frames=None, material=None):
    accent, hot = overlay_colours(frames)
    scope = (accent, hot)
    master = material or _MASTER
    cache = os.path.join(GENERATED, "player_overlay_category_r5423" if material else "player_overlay_spotlight_r5437")
    os.makedirs(cache, mode=0o700, exist_ok=True)
    out = {}
    stamp = os.stat(master)
    for name, width, height, selected in specs:
        if name.startswith("footer_"):
            bundled = os.path.join(os.path.dirname(__file__), "assets_fhd", "fixed_master_r63", "surfaces",
                                   "live_zap_%s_%dx%d.png" % (name, int(width), int(height)))
            bundled = _canonical_asset(bundled)
            if os.path.isfile(bundled):
                out[name] = bundled
                continue
        signature = repr((scope, int(width), int(height), bool(selected), getattr(stamp, "st_mtime_ns", int(stamp.st_mtime * 1000000000)), stamp.st_size))
        key = hashlib.sha1(signature.encode("utf-8")).hexdigest()[:24]
        target = os.path.join(cache, key + ".png")
        if not (os.path.isfile(target) and os.path.getsize(target) > 128):
            tmp = target + ".tmp.%d.%d" % (os.getpid(), threading.get_ident())
            try:
                build_surface(master, (int(width), int(height)), bool(selected), accent, hot).save(tmp, "PNG")
                os.replace(tmp, target)
            finally:
                if os.path.exists(tmp): os.unlink(tmp)
        out[name] = target
    return out
