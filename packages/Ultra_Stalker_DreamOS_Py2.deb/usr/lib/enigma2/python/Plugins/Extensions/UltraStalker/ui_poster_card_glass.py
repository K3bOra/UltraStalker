"""R5.457 unified Premium poster shells, square above and rounded below.

The poster opening and title base share one silhouette and one continuous rim.
Only Poster Grid 1/3 geometries use this recipe. Fixed shells are bundled PNGs;
adaptive shells use the existing background worker and durable cache.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import int, max, min
import math

from PIL import Image, ImageChops, ImageDraw, ImageFilter
from .ui_clean_glass import _expand_mask, layer, _mix

GEOMETRIES = ((236, 418, 354), (240, 424, 362))
CACHE_TAG = "v9premium"


def poster_shell(geometry, accent=None):
    w, h, poster_h = [int(v) for v in geometry]
    size = (w, h)
    edges = (0, 0, w, h)
    radius = 16
    # One square-top, rounded-bottom silhouette for every material layer.
    outer = _expand_mask(size, edges, 0, radius, 3, square_top=True)
    inner = _expand_mask(size, edges, -1.25, radius, 3, square_top=True)
    core = _expand_mask(size, edges, -3.0, radius, 3, square_top=True)
    rim = ImageChops.subtract(outer, inner)
    bevel = ImageChops.subtract(inner, core)
    tint = tuple(accent or (120, 126, 128))

    # Same neutral translucent Premium material; Adaptive adds a restrained tint.
    base = (19, 19, 19)
    body_top = _mix((37, 39, 40), tint, .10 if accent else 0)
    body_low = _mix(base, tint, .08 if accent else 0)
    title_mask = Image.new("L", size, 0)
    ImageDraw.Draw(title_mask).rectangle((0, poster_h, w - 1, h - 1), fill=255)
    title_mask = ImageChops.multiply(title_mask, core)
    out = Image.new("RGBA", size, (0, 0, 0, 0))
    # Material is painted inside the common silhouette, never as a footer box.
    tray = Image.new("RGBA", size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(tray)
    span = float(max(1, h - poster_h - 1))
    for y in range(poster_h, h):
        t = (y - poster_h) / span
        color = _mix(body_top, body_low, min(1.0, t * 1.5))
        draw.line((0, y, w - 1, y), fill=color + (86,))
    tray.putalpha(ImageChops.multiply(tray.getchannel("A"), title_mask))
    out = Image.alpha_composite(out, tray)

    # A soft reflection flows into the title base without a separator/top lip.
    reflection = Image.new("L", size, 0)
    rd = ImageDraw.Draw(reflection)
    for y in range(poster_h, h):
        a = int(18 * math.exp(-(y - poster_h) / 16.0))
        rd.line((0, y, w - 1, y), fill=a)
    reflection = ImageChops.multiply(reflection, title_mask)
    sheen = Image.new("RGBA", size, _mix((200, 206, 208), tint, .06) + (0,))
    sheen.putalpha(reflection)
    out = Image.alpha_composite(out, sheen)

    # A single continuous silver glass edge follows the whole card, including
    # straight top corners. No separate outline is drawn around the name.
    rim_top = _mix((205, 213, 217), tint, .10 if accent else 0)
    rim_low = _mix((142, 152, 155), tint, .10 if accent else 0)
    halo = ImageChops.multiply(rim.filter(ImageFilter.GaussianBlur(1.5)), outer)
    out = Image.alpha_composite(out, layer(halo, rim_top, rim_low, 40, 30))
    out = Image.alpha_composite(out, layer(bevel, rim_top, rim_low, 26, 18))
    out = Image.alpha_composite(out, layer(rim, rim_top, rim_low, 132, 94))
    return out
