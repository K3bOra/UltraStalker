# -*- coding: utf-8 -*-
"""Genre/item loading, content rows and live EPG rows/preview.

Methods moved verbatim out of ``PortalBrowserScreen`` (ui_screens_browser.py); behaviour is unchanged.
This module is imported by ui_screens_browser.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, zip, max, min, us_casefold
from .ui_screens_browser import (
    LOG,
    _,
    _live_screen_class,
    _poster_grid3_screen,
    _profile_hidden_ids,
    _provider_display_raw,
    _visibility_category_id,
    time,
    weakref,
)


class BrowserContentMixin(object):
    """Genre/item loading, content rows and live EPG rows/preview."""

    def load_genres(self, media_type, force_refresh=False):
        if self._busy:return
        _perf29_genres_t0=time.monotonic()
        LOG.info("PERF29 genres begin media=%s force=%s",str(media_type),bool(force_refresh))
        # Preserve category focus across manual/background catalogue rebuilds.
        # A stale-cache refresh used to repaint the list and force index 0, so a
        # viewer navigating the middle of Categories could suddenly jump to the
        # first folder when the silent provider refresh completed.
        restore_category_id = ""
        restore_category_index = 0
        try:
            if self.level == "genres" and self.media_type == media_type and self.content_items:
                restore_category_index = max(0, int(self["list"].getSelectedIndex() or 0))
                if restore_category_index < len(self.content_items):
                    restore_category_id = _visibility_category_id(self.content_items[restore_category_index])
        except Exception as exc:
            optional_failure("ui.category_focus_snapshot", exc)
        # Enter the final Categories surface before any network/cache wait.
        self.media_type = media_type
        self.level = "genres_loading"
        self._apply_category_portal_geometry()
        if self._category_dynamic_visuals_enabled():
            self._load_category_backdrop()
        else:
            # Movies/Series Categories use the same static page immediately; no Hero/Adaptive
            # work is launched while category cache/network is in flight.
            self._category_chrome = self._movies_static_category_chrome()
            self._restore_category_side_identity()
        self._set_list_density("genres")
        cached = None if force_refresh else _category_cache_get(self.profile, media_type)
        LOG.info("PERF29 genres cache media=%s hit=%s lookup_elapsed_ms=%d",str(media_type),bool(cached is not None),int((time.monotonic()-_perf29_genres_t0)*1000))
        # Hot/last-good cache entry needs no portal transport mutation at all.
        # Touching client backoff/socket state on every cached category open was
        # wasted work and could contend with Home's background prefetch.
        if cached is None or force_refresh:
            try:self.client.reset_failure_backoff()
            except Exception as exc:optional_failure("ui.silent_guard",exc)
        # Hot/last-good Categories are already usable truth.  Do not hide the
        # existing list for a cache hit and manufacture a blank transition frame.
        if cached is None:
            try:self["list"].hide()
            except Exception as exc:optional_failure("ui.category_loading_list_hide", exc)
            self["status"].setText(_("Loading categories..."))
            self._show_skeleton("Loading categories")
        def ok(genres,persist=True):
            # Snapshot the *current* focus too. This matters for the second,
            # silent in-place refresh after cached Categories are already usable.
            # It overrides the entry snapshot if the viewer has moved meanwhile.
            focus_id = restore_category_id
            focus_index = restore_category_index
            try:
                if self.level == "genres" and self.media_type == media_type and self.content_items:
                    focus_index = max(0, int(self["list"].getSelectedIndex() or 0))
                    if focus_index < len(self.content_items):
                        focus_id = _visibility_category_id(self.content_items[focus_index])
            except Exception as exc:
                optional_failure("ui.category_focus_refresh_snapshot", exc)
            if persist and isinstance(genres, list):
                _category_cache_put(self.profile, media_type, genres)
            provider_rows=list(e for e in genres if isinstance(e,dict)) if isinstance(genres, list) else []
            if media_type in ("itv","vod","series") and not any(str((e or {}).get("id") or (e or {}).get("category_id") or "")=="*" for e in provider_rows):
                provider_rows.insert(0, {"id":"*","genre_id":"*","category_id":"*","name":_("All"),"title":_("All")})
            cfg=load_settings(); hidden=_profile_hidden_ids(cfg,self.profile,media_type); protected=set(cfg.get("protected_categories",{}).get(media_type,[])); words=cfg.get("adult_keywords",[])
            def gid(e): return _visibility_category_id(e)
            def adult(e):
                text=us_casefold(str(e.get("name") or e.get("title") or ""));return any(w in text for w in words)
            empty=set(cfg.get("empty_categories",{}).get(media_type,[]))
            manageable=[]
            for e in provider_rows:
                sensitive=(gid(e) in protected or adult(e))
                if cfg.get("parental_lock") and cfg.get("parental_mode","pin")=="hide" and sensitive: continue
                if (not cfg.get("parental_lock")) and cfg.get("hide_adult",True) and adult(e): continue
                manageable.append(e)
            self._category_known_items=list(manageable)
            valid=list(e for e in manageable if gid(e) not in hidden)
            # Hidden folders stay out of the list, but the provider's "All" row is
            # kept on purpose so nothing looks missing: it opens the whole catalogue.
            if not valid and not manageable:
                if media_type == "itv":
                    screen = _live_screen_class(PremiumLiveGridScreen)
                else:
                    view_key="movies_view_mode" if media_type=="vod" else "series_view_mode"
                    view_mode=str(cfg.get(view_key) or "cinematic").lower()
                    screen=PremiumGlobalCinematicScreen if view_mode=="cinematic" else (PremiumBackdropGrid2Screen if view_mode=="backdrop2" else (PremiumBackdropGridScreen if view_mode=="backdrop" else (PremiumPosterGridScreen if view_mode=="poster_legacy" else (_poster_grid3_screen() if view_mode=="poster3" else PremiumPosterGridV2Screen))))
                self.session.openWithCallback(self._grid_returned, screen, self.profile, self.client, media_type, "*", self._mode_name(media_type))
                return
            if not valid and manageable:
                self.media_type=media_type; self.content_items=[]; self.level="genres"
                self._category_chrome = {}
                self._apply_category_portal_geometry(); self._load_category_chrome()
                self["section"].setText(_("%s  /  Categories") % self._mode_name(media_type))
                self["list"].set_icon_rows([]); self._reveal_browser_content()
                self["counter"].setText(_("Categories: %d") % 0); self["status"].setText(_("All categories are hidden • MENU to restore")); self._apply_browser_status_color()
                return
            pinned=set(cfg.get("pinned_categories",{}).get(media_type,[]))
            # Preserve the exact order returned by the portal. Pinned categories
            # keep their visual star but no longer jump ahead of portal order.
            self.media_type=media_type; self.content_items=valid; self.level="genres"
            # One measurement across the complete category list.  Paging through
            # groups of 14 must never change the row width.
            self._prepare_category_global_geometry(valid,cfg)
            # Never reuse adaptive assets from the previously opened media family.
            # Live/Movies/Series use the same static page and must not rebuild page mood.
            self._category_chrome = {}
            self._apply_category_portal_geometry()
            self._load_category_chrome()
            self["section"].setText(_("%s  /  Categories") % self._mode_name(media_type))
            # Restore by stable category ID first. If that folder vanished (for
            # example because it was hidden or removed by the provider), keep the
            # nearest valid row instead of throwing focus back to the top.
            target_index = 0
            if valid:
                target_index = max(0, min(int(focus_index or 0), len(valid) - 1))
                if focus_id:
                    for _i, _entry in enumerate(valid):
                        if gid(_entry) == focus_id:
                            target_index = _i
                            break
            try:self["list"].moveToIndex(target_index)
            except Exception as exc:optional_failure("ui.category_focus_restore",exc)
            self._render_genre_rows()
            self._reveal_browser_content()
            self._category_glass_keys()
            self["counter"].setText(_("Categories: %d") % len(valid)); self["status"].setText(_("Ready")); self._apply_browser_status_color(); self._selection_changed()
            LOG.info("PERF29 genres first_paint media=%s categories=%d elapsed_ms=%d",str(media_type),len(valid),int((time.monotonic()-_perf29_genres_t0)*1000))
            # R5.64: Home -> Live opens the 3-column Live screen straight away
            # (its own categories column replaces this list).  Leaving it returns
            # to Home, not to this category list.
            try:
                if (media_type=="itv" and valid and str(getattr(self,"initial_action","") or "")=="itv"
                        and not getattr(self,"_live_direct_done",False)
                        and str(cfg.get("live_view_mode") or "columns").lower()=="columns"):
                    self._live_direct_done=True
                    pick=target_index
                    last=str(cfg.get("live_last_category") or "")
                    if last:
                        for _i,_entry in enumerate(valid):
                            if str(_entry.get("id") or _entry.get("genre_id") or _entry.get("category_id") or _entry.get("name") or _entry.get("title") or "*")==last:
                                pick=_i;break
                    try:self["list"].moveToIndex(pick)
                    except Exception:pass
                    self._live_direct_mode=True
                    self._live_direct_pick=(dict(valid[pick]),pick)
                    # Open on the next GUI tick: the Browser may still be inside
                    # its own show/initial-action pass here.
                    self._live_direct_timer=eTimer()
                    def _go(scr=self):
                        try:
                            if getattr(scr,"_live_direct_conn",None) is not None:
                                scr._live_direct_conn.disconnect()
                                scr._live_direct_conn=None
                        except Exception:pass
                        try:
                            if getattr(scr,"_live_direct_timer",None) is not None and _go in scr._live_direct_timer.callback:
                                scr._live_direct_timer.callback.remove(_go)
                        except Exception:pass
                        if getattr(scr,"_screen_closed",False):return
                        try:
                            entry,index=scr._live_direct_pick
                            scr._open_genre_with_parental(entry,index)
                        except Exception as exc:
                            scr._live_direct_mode=False
                            optional_failure("ui.live_direct_open_tick",exc)
                    self._live_direct_cb=_go
                    try:self._live_direct_conn=self._live_direct_timer.timeout.connect(_go)
                    except Exception:self._live_direct_timer.callback.append(_go)
                    self._live_direct_timer.start(60,True)
            except Exception as exc:
                self._live_direct_mode=False
                optional_failure("ui.live_direct_open",exc)
        # Last-good categories are first-paint truth.  A stale HDD/RAM row is
        # shown immediately, then refreshed silently in-place; a transient
        # Stalker failure can therefore never replace useful categories with a
        # blank backdrop.  Fresh hot-cache rows need no network request.
        cached_painted = cached is not None
        if cached_painted:
            ok(cached,persist=False)
            # Never mark the screen busy after last-good first paint. Refresh a
            # stale catalogue on an isolated client so OK/navigation remains
            # instant and the shared Portal transport is not disturbed.
            try:
                stale=_category_cache_age(self.profile,media_type) > _CATEGORY_CACHE_TTL
            except Exception:
                stale=False
            if stale:
                profile_copy=dict(self.profile or {});media_copy=str(media_type or "")
                def apply_silent_category_refresh(rows):
                    if getattr(self,"_screen_closed",False) or getattr(self,"_browser_images_suspended",False):return
                    if self.level=="genres" and self.media_type==media_copy and isinstance(rows,list) and rows:
                        ok(rows,persist=False)
                def refresh_last_good():
                    isolated=None
                    try:
                        isolated=_new_isolated_source_client(profile_copy,timeout=6)
                        refresh=getattr(isolated,"refresh_menu",None)
                        rows=refresh(media_copy) if callable(refresh) else isolated.genres(media_copy)
                        if isinstance(rows,list) and rows:
                            _category_cache_put(profile_copy,media_copy,rows)
                            try:self._jobs.put((apply_silent_category_refresh,rows,False))
                            except Exception as queue_exc:optional_failure("ui.category_refresh_delivery",queue_exc)
                    except Exception as exc:
                        optional_failure("ui.category_last_good_refresh",exc)
                    finally:
                        try:
                            close_pending=getattr(isolated,"cancel_pending_requests",None)
                            if callable(close_pending):close_pending()
                        except Exception:pass
                try:_CATEGORY_PREFETCH_EXECUTOR.submit(refresh_last_good)
                except Exception as exc:optional_failure("ui.category_last_good_refresh_submit",exc)
            return

        def load_categories_resilient(handle):
            _perf29_net_t0=time.monotonic()
            """Recover transient category failures inside the same screen.

            Several MAG/Stalker portals intermittently return HTML/non-JSON or
            drop the first keep-alive request even though the very next manual
            re-entry succeeds.  Requiring the viewer to BACK/enter three or four
            times is pointless.  Keep recovery local to Categories: retry on a
            fresh transport, refresh authorization once, and only expose the
            error screen after all bounded attempts are exhausted.
            """
            cancel_event = getattr(handle, "cancel_event", None)
            last_error = None
            # First try is immediate. Subsequent waits are deliberately short so
            # a healthy portal still feels instant while flaky loaders self-heal.
            retry_delays = (0.0, 0.22, 0.55, 0.90)
            for attempt, delay in enumerate(retry_delays):
                if attempt:
                    if cancel_event is not None and getattr(cancel_event, "wait", lambda _x: False)(delay):
                        raise last_error or Exception("Request cancelled")
                    # A stale keep-alive socket is a common source of one-shot
                    # non-JSON/empty loader responses.  Drop only client transport
                    # state; do not alter portal/profile data or UI state.
                    try:
                        close_pending = getattr(self.client, "cancel_pending_requests", None)
                        if callable(close_pending) and not hasattr(self.client,"_xtream"):
                            close_pending()
                    except Exception as exc:
                        optional_failure("ui.category_retry_transport", exc)
                    try:
                        reset_backoff = getattr(self.client, "reset_failure_backoff", None)
                        if callable(reset_backoff):
                            reset_backoff()
                    except Exception as exc:
                        optional_failure("ui.category_retry_backoff", exc)
                    # Third pass mirrors what users were effectively doing by
                    # leaving/re-entering: establish one fresh authorized portal
                    # session.  M3U/Xtream adapters simply skip this branch.
                    if attempt == 2:
                        try:
                            authorize = getattr(self.client, "authorize", None)
                            if callable(authorize):
                                authorize(cancel_event=cancel_event)
                        except TypeError:
                            try: authorize()
                            except Exception as exc: last_error = exc
                        except Exception as exc:
                            last_error = exc
                try:
                    _rows=self.client.genres(media_type, cancel_event=cancel_event)
                    LOG.info("PERF29 genres provider_done media=%s attempt=%d elapsed_ms=%d rows=%d",str(media_type),int(attempt+1),int((time.monotonic()-_perf29_net_t0)*1000),len(_rows) if isinstance(_rows,list) else -1)
                    return _rows
                except Exception as exc:
                    last_error = exc
                    low = us_casefold(str(exc))
                    # Security-consent failures need explicit user approval and
                    # must never be hidden behind automatic retries.
                    if any(marker in low for marker in (
                        "security consent", "fallback is not approved",
                        "certificate verification", "unapproved https"
                    )):
                        raise
                    if any(marker in low for marker in ("http 469", "http 429", "rate limit")):
                        raise
            raise last_error or Exception("Categories could not be loaded")

        def failed(exc):
            # If a last-good catalogue is already on-screen, this was only a
            # silent refresh. Keep the useful rows and suppress transient portal
            # noise exactly like the M3U path.
            if cached_painted and self.level=="genres" and self.content_items:
                try:self["status"].setText("")
                except Exception:pass
                return
            # Never leave the viewer on a backdrop-only loading surface. Restore
            # normal Browser chrome and show the actual portal error immediately.
            self.level="root"
            self.content_items=[]
            try:self._restore_browser_geometry()
            except Exception as restore_exc:optional_failure("ui.category_error_restore",restore_exc)
            try:
                self["section"].setText(_("Categories unavailable"))
                self["status"].setText(_friendly_error(exc))
                self["counter"].setText("")
                self["list"].set_icon_rows([(_("Categories could not be loaded"),asset("us89_folder_yellow_42.png"),None,_friendly_error(exc))])
                self["list"].show()
            except Exception as render_exc:optional_failure("ui.category_error_render",render_exc)
        self._run_async(load_categories_resilient,ok,failed)

    def load_items(self, media_type, genre, page=1):
        if self._busy:return
        self._set_list_density("itv" if media_type == "itv" else "compact")
        self["status"].setText(_("Loading content..."))
        self._show_skeleton("Loading content")
        def ok(data):
            valid=[e for e in data if isinstance(e,dict)] if isinstance(data, list) else []
            self.media_type=media_type; self.genre=genre; self.page=max(1, int(page)); self.content_items=valid; self.all_content_items=list(valid); self.level="items"
            if valid and genre not in (None,"","*"):
                cfg=load_settings(); empty=dict(cfg.get("empty_categories") or {}); vals=[x for x in list(empty.get(media_type,[]) or []) if str(x)!=str(genre)]
                if vals!=list((cfg.get("empty_categories") or {}).get(media_type,[]) or []):
                    empty[media_type]=vals; save_settings({"empty_categories":empty})
            self._render_content_rows()
            self._reveal_browser_content()
            self["section"].setText(_("%s  /  Content") % self._mode_name(media_type))
            self["counter"].setText(_("Page %d  •  Items: %d") % (self.page, len(valid))); self["status"].setText(_("Ready") if valid else _("No content"))
            self._selection_changed()
            try:
                from .folder_refresh import schedule_list
                schedule_list(self,media_type,genre,page,ok)
            except Exception as exc:optional_failure("ui.selected_list_refresh",exc)
        def load_items_resilient(handle):
            cancel_event=getattr(handle,"cancel_event",None);last_error=None
            delays=(0.0,0.18,0.42,0.75)
            for attempt,delay in enumerate(delays):
                if attempt:
                    if cancel_event is not None and getattr(cancel_event,"wait",lambda _x:False)(delay):
                        raise last_error or Exception("Request cancelled")
                    try:
                        close_pending=getattr(self.client,"cancel_pending_requests",None)
                        if callable(close_pending) and not hasattr(self.client,"_xtream"):close_pending()
                    except Exception as exc:optional_failure("ui.content_retry_transport",exc)
                    try:
                        reset=getattr(self.client,"reset_failure_backoff",None)
                        if callable(reset):reset()
                    except Exception as exc:optional_failure("ui.content_retry_backoff",exc)
                try:
                    return self.client.ordered_list(media_type,genre,page,cancel_event=cancel_event)
                except Exception as exc:
                    last_error=exc;low=us_casefold(str(exc))
                    if any(marker in low for marker in ("security consent","fallback is not approved","certificate verification","unapproved https")):
                        raise
                    transient=any(marker in low for marker in ("connection","timed out","timeout","non-json","invalid page","temporarily paused","remote end closed","connection reset","broken pipe","http 502","http 503","http 504"))
                    if (not transient) or attempt>=len(delays)-1:raise
            raise last_error or Exception("Content could not be loaded")
        def failed_items(error):
            low=us_casefold(str(error))
            transient=any(marker in low for marker in ("connection","timed out","timeout","non-json","invalid page","temporarily paused","remote end closed","connection reset","broken pipe","http 502","http 503","http 504"))
            message=_("Content temporarily unavailable. Try again.") if transient else _friendly_error(error)
            # A failed portal request must never leave the Browser on its hidden
            # loading skeleton.  If this was a refresh of an already-painted
            # list, keep that last-good content.  Otherwise reveal one honest
            # error row so the viewer always has a visible, escapable surface.
            if self.level=="items" and getattr(self,"content_items",None):
                try:self._reveal_browser_content()
                except Exception as exc:optional_failure("ui.content_error_reveal_last_good",exc)
                try:self["status"].setText(message)
                except Exception as exc:optional_failure("ui.content_error_status_last_good",exc)
                return
            self.media_type=media_type;self.genre=genre;self.page=max(1,int(page));self.level="items";self.content_items=[];self.all_content_items=[]
            try:
                icon="settings_icons_40/channel_list.png" if media_type=="itv" else ("settings_icons_40/artwork.png" if media_type=="vod" else "settings_icons_40/next_episode.png")
                self["list"].set_icon_rows([(_("Content could not be loaded"),asset(icon),None,message)])
                self["section"].setText(_("%s  /  Content") % self._mode_name(media_type))
                self["counter"].setText("")
                self["status"].setText(message)
                self._reveal_browser_content()
            except Exception as exc:optional_failure("ui.content_error_render",exc)
        self._run_async(load_items_resilient,ok,failed_items)

    def _live_content_row(self, e, pos, cfg, state=None):
        state=state or {}
        _clean_titles=bool(cfg.get("clean_titles",True))
        raw=_provider_display_raw(e,_clean_titles,e.get("id") or "Channel")
        title=_clean_live_channel_name(raw,True) if _clean_titles else str(raw).strip()
        cid=str(e.get("id") or e.get("ch_id") or e.get("number") or pos)
        epg=self._epg_cache.get(cid,{})
        number=str(e.get("number") or e.get("num") or pos) if cfg.get("show_channel_numbers",True) else ""
        badges=[]
        if state.get("favorite"): badges.append("★")
        if e.get("allow_archive") or e.get("tv_archive_duration") or e.get("archive"): badges.append(_("CATCH-UP"))
        if epg.get("percent"): badges.append("%d%%"%epg["percent"])
        icon=asset(_letter_placeholder(title))
        try:
            raw_picon=_image_url(e)
            cached=_cached_live_picon_path(raw_picon,self.profile,e) if raw_picon else ""
            if cached:
                fitted=_fit_live_picon_canvas(cached,PERSISTENT_GENERATED_DIR,(60,60))
                if fitted: icon=fitted
        except Exception as exc:
            optional_failure("ui.live_row_picon_fit",exc)
        details={"number":number,"now":epg.get("now") or e.get("epg_title") or e.get("now") or _("No EPG information"),"next":epg.get("next") or "","badges":"  ".join(badges)}
        return (title,icon,e,details)

    def _render_content_rows(self, keep_index=None):
        cfg=load_settings(); rows=[]
        states=load_content_states(self.profile,self.media_type,self.content_items) if self.content_items else []
        self._content_state_cache={id(item):state for item,state in zip(self.content_items,states)}
        if self.media_type=="itv":
            self._set_list_density("itv")
            selected_rows=getattr(self,"_bouquet_selected_rows",{}) if getattr(self,"_bouquet_select_mode",False) else {}
            for pos,e in enumerate(self.content_items,1):
                row=self._live_content_row(e,pos,cfg,self._content_state_cache.get(id(e)))
                if self._bouquet_channel_key(e) in selected_rows:
                    row=("✓ "+str(row[0]),row[1],row[2],row[3])
                rows.append(row)
        else:
            self._set_list_density("compact")
            icon="settings_icons_40/artwork.png" if self.media_type=="vod" else "settings_icons_40/next_episode.png"
            for e in self.content_items:
                _clean_titles=bool(cfg.get("clean_titles",True))
                raw=_provider_display_raw(e,_clean_titles,e.get("id") or _("Result"))
                title=premium_title(raw,True) if _clean_titles else str(raw).strip(); meta=[]
                if cfg.get("show_quality_badges",True):
                    badges=quality_badges(raw)
                    if badges: meta.append(badges)
                if e.get("year"): meta.append(str(e.get("year"))[:10])
                state=self._content_state_cache.get(id(e),{})
                if state.get("favorite"): meta.append("★")
                if state.get("completed"): meta.append("WATCHED")
                elif state.get("duration") and state.get("position"):
                    meta.append("%d%%"%min(99,int(state["position"]*100.0/state["duration"])))
                rows.append((title,asset(icon),e,"  •  ".join(meta)[:36]))
        if not rows:
            icon="settings_icons_40/channel_list.png" if self.media_type=="itv" else ("settings_icons_40/artwork.png" if self.media_type=="vod" else "settings_icons_40/next_episode.png")
            rows=[(_("No content returned"),asset(icon),None,_("Try another category"))]
        self["list"].set_icon_rows(rows)
        if keep_index is not None:
            try:self["list"].moveToIndex(max(0,min(int(keep_index),len(rows)-1)))
            except Exception as exc:optional_failure("ui",exc)
        if self.media_type=="itv" and self.level=="items":
            self._schedule_live_page_epg()

    def _schedule_live_page_epg(self):
        """Short guide for every channel on this page, not only the focused one."""
        missing=[]
        for item in self.content_items or []:
            if not isinstance(item, dict):
                continue
            cid=str(item.get("id") or item.get("ch_id") or "")
            if cid and cid not in self._epg_cache and cid not in missing:
                missing.append(cid)
        if not missing:
            return
        sig=tuple(missing)
        if sig==getattr(self,"_live_epg_sig",None):
            return
        many=getattr(self.client,"epg_many",None)
        if not callable(many):
            return
        self._live_epg_sig=sig
        self._epg_token=int(getattr(self,"_epg_token",0) or 0)+1
        token=self._epg_token
        def ok(found):
            if token!=int(getattr(self,"_epg_token",0) or 0):
                return
            if self.media_type!="itv" or self.level!="items":
                return
            changed=False
            for cid, rows in (found or {}).items():
                if not rows:
                    continue
                try:
                    summary=epg_summary(rows)
                except Exception:
                    summary=None
                if summary:
                    self._epg_cache[cid]=summary
                    changed=True
            if not changed:
                return
            keep=None
            try:keep=self["list"].getSelectedIndex()
            except Exception:keep=None
            self._render_content_rows(keep_index=keep)
        self._run_async(lambda handle: many(missing, 10, cancel_event=handle.cancel_event), ok, lambda _e: None)

    def _refresh_live_epg_row(self, index):
        if self.media_type!="itv" or not (0<=index<len(self.content_items)):return
        item=self.content_items[index];cfg=load_settings();state=getattr(self,"_content_state_cache",{}).get(id(item),{})
        self["list"].update_icon_row(index,self._live_content_row(item,index+1,cfg,state))

    def _schedule_epg_preview(self, item):
        _fav_live=(self.level=="favorites_cards" and self._favorite_active_mt()=="itv")
        if (self.media_type!="itv" or self.level!="items") and not _fav_live: return
        if not isinstance(item,dict): return
        cid=str(item.get("id") or item.get("ch_id") or "")
        if not cid or cid in self._epg_cache: return
        self._epg_token+=1; self._epg_pending=(self._epg_token,cid)
        # A focus change makes a queued EPG request obsolete. Running network
        # work is allowed to finish, but it no longer owns this Screen.
        future=getattr(self,"_epg_future",None)
        if future is not None and not future.done():
            try:future.cancel()
            except Exception as exc:optional_failure("ui.browser_epg_requeue_cancel",exc)
        self._epg_future=None
        try:self._epg_timer.stop();self._epg_timer.start(350,True)
        except Exception as exc:optional_failure("ui",exc)

    def _fetch_selected_epg(self):
        pending=getattr(self,"_epg_pending",None)
        if not pending:return
        token,cid=pending
        client=self.client
        jobs=self._epg_jobs
        screen_ref=weakref.ref(self)
        def work():
            try:return (token,cid,epg_summary(client.epg(cid,4)),None)
            except Exception as exc:return (token,cid,None,exc)
        def done(fut,ref=screen_ref,result_queue=jobs):
            screen=ref()
            if screen is None or getattr(screen,"_screen_closed",False):return
            if fut.cancelled():return
            try:result_queue.put(fut.result())
            except Exception as exc:optional_failure("ui",exc)
            finally:
                if screen is not None and getattr(screen,"_epg_future",None) is fut:
                    screen._epg_future=None
        try:
            future=_GRID_EPG_EXECUTOR.submit(work)
            self._epg_future=future
            future.add_done_callback(done)
        except Exception as exc:
            self._epg_future=None
            optional_failure("ui.browser_epg_submit",exc)

    def _drain_epg_jobs(self):
        while True:
            try:token,cid,summary,error=self._epg_jobs.get_nowait()
            except queue.Empty:break
            if error is None and summary:
                self._epg_cache[cid]=summary
                if self.level=="favorites_cards":
                    try:
                        self._favorite_details_cache={}
                        self._favorite_refresh_details()
                    except Exception as exc:optional_failure("ui.favorite_epg_repaint",exc)
                    continue
                try:
                    idx=self["list"].getSelectedIndex(); self._refresh_live_epg_row(idx)
                    if 0<=idx<len(self.content_items):
                        item=self.content_items[idx]; current=str(item.get("id") or item.get("ch_id") or "")
                        if current==cid:
                            now=summary.get("now") or _("No programme description")
                            nxt=summary.get("next") or _("No programme description")
                            self["info"].setText(((_("NOW  %s") % now) + "\n" + (_("NEXT") + "  " + str(nxt)))[:118])
                except Exception as exc:optional_failure("ui",exc)

    def _stop_epg_preview(self):
        future=getattr(self,"_epg_future",None)
        if future is not None and not future.done():
            try:future.cancel()
            except Exception as exc:optional_failure("ui.browser_epg_stop_cancel",exc)
        self._epg_future=None
        try:self._epg_timer.stop()
        except Exception as exc:optional_failure("ui",exc)
        try:
            if self._epg_timer_conn is not None:self._epg_timer_conn.disconnect()
        except Exception as exc:optional_failure("ui",exc)
        try:
            if self._fetch_selected_epg in self._epg_timer.callback:self._epg_timer.callback.remove(self._fetch_selected_epg)
        except Exception as exc:optional_failure("ui.epg_callback",exc)
