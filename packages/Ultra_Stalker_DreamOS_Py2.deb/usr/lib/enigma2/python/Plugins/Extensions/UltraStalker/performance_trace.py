# -*- coding: utf-8 -*-
"""Opt-in, bounded opening trace. No account data, titles or local variables."""
from __future__ import absolute_import
import os
import sys
import time
import logging
import threading
import traceback
from logging.handlers import RotatingFileHandler
_LOG = None
_LOCK = threading.Lock()
def trace(stage):
    if not os.path.isfile('/tmp/ultrastalker_performance_trace'):
        return
    global _LOG
    try:
        with _LOCK:
            if _LOG is None:
                logger = logging.getLogger('UltraStalker.PerformanceTest')
                logger.propagate = False
                logger.setLevel(logging.INFO)
                handler = RotatingFileHandler('/tmp/ultrastalker_performance_test.log', maxBytes=262144, backupCount=1)
                handler.setFormatter(logging.Formatter('%(asctime)s %(message)s'))
                logger.addHandler(handler)
                _LOG = logger
            _LOG.info('%s', stage)
    except Exception:
        pass
def watch_open():
    if not os.path.isfile('/tmp/ultrastalker_performance_trace'):
        return None
    owner = threading.current_thread().ident
    def stalled():
        frame = getattr(sys, '_current_frames', lambda: {})().get(owner)
        if frame is not None:
            trace('details_open_over_6s\n' + ''.join(traceback.format_stack(frame)))
    timer = threading.Timer(6.0, stalled)
    timer.daemon = True
    timer.start()
    return timer
