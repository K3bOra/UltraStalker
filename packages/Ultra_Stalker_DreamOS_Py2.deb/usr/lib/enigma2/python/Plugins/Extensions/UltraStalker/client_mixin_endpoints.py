# -*- coding: utf-8 -*-
"""Portal URL/MAC normalisation, endpoint discovery and request headers.

Methods moved verbatim out of ``StalkerClient`` (client.py); behaviour is unchanged.
This module is imported by client.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, open, max, min, OSError
from .client import (
    EMULATOR_USER_AGENT,
    LOG,
    MAX_FRONTEND_BYTES,
    PortalCancelledError,
    PortalError,
    endpoint_log_label,
    extract_declared_endpoints,
    frontend_candidates,
    re,
    same_origin,
    time,
    urllib,
)


class ClientEndpointsMixin(object):
    """Portal URL/MAC normalisation, endpoint discovery and request headers."""

    # ------------------------------------------------------------------
    # URL / identity helpers
    # ------------------------------------------------------------------
    @staticmethod
    def _normalize_entry_url(portal):
        value = str(portal or "").strip()
        if not value:
            raise PortalError("Portal URL is empty")
        if not value.lower().startswith(("http://", "https://")):
            value = "https://" + value
        parsed = urllib.parse.urlsplit(value)
        if parsed.scheme.lower() not in ("http", "https") or not parsed.hostname:
            raise PortalError("Invalid portal URL")
        if parsed.username or parsed.password:
            raise PortalError("Credentials in portal URL are not supported")
        if len(value) > 2048:
            raise PortalError("Portal URL is too long")
        clean_path = re.sub(r"/+", "/", parsed.path or "/")
        return urllib.parse.urlunsplit((parsed.scheme.lower(), parsed.netloc, clean_path, "", "")).rstrip("/")

    @staticmethod
    def _normalize_mac(mac):
        value = str(mac or "").strip().upper().replace("-", ":")
        if not re.match(r"^[0-9A-F]{2}(:[0-9A-F]{2}){5}$", value):
            raise PortalError("Invalid MAC format")
        return value

    @staticmethod
    def _split_entry(entry):
        parsed = urllib.parse.urlsplit(entry)
        host = "%s://%s" % (parsed.scheme, parsed.netloc)
        path = (parsed.path or "").rstrip("/")
        if path.endswith("/stalker_portal/c"):
            prefix = "/stalker_portal/c/"
        elif path.endswith("/c"):
            prefix = "/c/"
        elif "/stalker_portal/" in path:
            prefix = "/stalker_portal/c/"
        else:
            prefix = "/c/"
        return host, prefix, host + prefix

    def _portal_key(self):
        return (self.host.lower(), self.mac)

    def _candidate_endpoints(self):
        parsed = urllib.parse.urlsplit(self.entry_url)
        entry_path = parsed.path or ""
        candidates = []
        if self.endpoint:
            candidates.append(self.endpoint)
        if self._compat_cached_endpoint:
            candidates.append(self._compat_cached_endpoint)
        for item in self._compat_discovered_candidates:
            if item:
                candidates.append(item)
        if entry_path.lower().endswith((".php", "/load.php")):
            candidates.append(self.entry_url)

        if self.path_prefix == "/stalker_portal/c/":
            candidates.extend([
                self.host + "/stalker_portal/server/load.php",
                self.host + "/stalker_portal/server/portal.php",
                self.host + "/stalker_portal/portal.php",
                self.host + "/stalker_portal/portal1.php",
                self.host + "/portal.php",
                self.host + "/portal1.php",
                self.host + "/server/load.php",
            ])
        else:
            # /c/ portals normally resolve to /portal.php. Keep the existing
            # order and add portal1.php only as a late compatibility candidate.
            candidates.extend([
                self.host + "/portal.php",
                self.host + "/server/load.php",
                self.host + "/portal1.php",
                self.host + "/stalker_portal/server/load.php",
                self.host + "/stalker_portal/portal.php",
                self.host + "/stalker_portal/portal1.php",
            ])

        # Custom subdirectory portals occasionally place the loader next to /c/.
        base_path = entry_path
        if base_path.endswith("/c"):
            base_path = base_path[:-2]
        elif base_path.endswith("/stalker_portal/c"):
            base_path = base_path[:-2]
        base_path = base_path.rstrip("/")
        if base_path and base_path != "/stalker_portal":
            candidates.extend([
                self.host + base_path + "/portal.php",
                self.host + base_path + "/portal1.php",
                self.host + base_path + "/server/load.php",
            ])

        result = []
        for item in candidates:
            item = re.sub(r"(?<!:)//+", "/", str(item or ""))
            if not item or not same_origin(item, self.entry_url):
                continue
            try:
                if not urllib.parse.urlsplit(item).path.lower().endswith(".php"):
                    continue
            except Exception:
                continue
            if item not in result:
                result.append(item)
        return result

    def _fetch_frontend_text(self, url, cancel_event=None, timeout=1.6):
        """Fetch one same-origin frontend JS file with strict size/time bounds."""
        if cancel_event is not None and getattr(cancel_event, "is_set", lambda: False)():
            raise PortalCancelledError("Request cancelled")
        if not same_origin(url, self.entry_url):
            return ""
        client = self

        class _SameOriginRedirect(urllib.request.HTTPRedirectHandler):
            def redirect_request(self, req, fp, code, msg, headers, newurl):
                target = urllib.parse.urljoin(req.full_url, newurl)
                if not same_origin(target, client.entry_url):
                    return None
                return urllib.request.HTTPRedirectHandler.redirect_request(
                    self, req, fp, code, msg, headers, target
                )

        context = self._tls_context(verified=True)
        opener = urllib.request.build_opener(
            urllib.request.HTTPSHandler(context=context), _SameOriginRedirect()
        )
        headers = {
            "User-Agent": self._profile_spec()["user_agent"],
            "Accept": "application/javascript,text/javascript,*/*;q=0.2",
            "Referer": self.referer,
            "Connection": "close",
        }
        request = urllib.request.Request(url, headers=headers, method="GET")
        try:
            with opener.open(request, timeout=max(0.8, min(float(timeout or 1.6), 2.0))) as response:
                final_url = str(getattr(response, "geturl", lambda: url)() or url)
                if not same_origin(final_url, self.entry_url):
                    return ""
                payload = response.read(MAX_FRONTEND_BYTES + 1)
                if len(payload) > MAX_FRONTEND_BYTES:
                    return ""
                content_type = str(response.headers.get("Content-Type", "") or "").lower()
                text = payload.decode("utf-8-sig", "replace")
                if ("javascript" not in content_type and "text/" not in content_type
                        and ".php" not in text.lower()):
                    return ""
                return text
        except PortalCancelledError:
            raise
        except Exception:
            return ""

    def _discover_portal_endpoints(self, cancel_event=None):
        """Run one bounded frontend discovery pass for this client session."""
        if self._compat_discovery_attempted:
            return list(self._compat_discovered_candidates)
        self._compat_discovery_attempted = True
        LOG.info("Portal bootstrap discovery started")
        found = []
        deadline = time.monotonic() + 4.2
        for js_url in frontend_candidates(self.entry_url):
            if time.monotonic() >= deadline:
                break
            if cancel_event is not None and getattr(cancel_event, "is_set", lambda: False)():
                raise PortalCancelledError("Request cancelled")
            remaining = max(0.8, min(1.6, deadline - time.monotonic()))
            text = self._fetch_frontend_text(js_url, cancel_event=cancel_event, timeout=remaining)
            if not text:
                continue
            for endpoint in extract_declared_endpoints(text, js_url, self.entry_url):
                if endpoint not in found:
                    found.append(endpoint)
                    LOG.info("Dynamic endpoint found: %s", endpoint_log_label(endpoint))
                if len(found) >= 6:
                    break
            # One real frontend file is authoritative enough for this bounded
            # pass. Do not probe extra JS files after it declared API paths.
            if found:
                break
        self._compat_discovered_candidates = found
        return list(found)

    # ------------------------------------------------------------------
    # HTTP / session
    # ------------------------------------------------------------------
    @staticmethod
    def _local_timezone():
        try:
            with open("/etc/timezone", "r", encoding="utf-8") as handle:
                value = handle.read().strip()
            if "/" in value and not value.startswith("#"):
                return value
        except (OSError, UnicodeError):
            pass
        return time.tzname[0] if time.tzname else "Europe/London"

    def _profile_spec(self, profile_name=None):
        key = str(profile_name or self.resolved_device_profile or self.device_profile or "auto").lower()
        if key == "auto":
            key = "mag254" if (self.path_prefix == "/stalker_portal/c/" or (self.endpoint and "/stalker_portal/" in self.endpoint)) else "mag250"
        return self.DEVICE_PROFILES.get(key, self.DEVICE_PROFILES["mag250"])

    def _headers(self):
        parsed = urllib.parse.urlsplit(self.host)
        wire_mac = str(self._compat_mac_override or self.mac)
        encoded_mac = urllib.parse.quote(wire_mac, safe="")
        encoded_tz = urllib.parse.quote(self._timezone, safe="")
        with self._server_cookie_lock:
            cookies = dict(self._server_cookies)
        cookies.update({"mac": encoded_mac, "stb_lang": "en", "timezone": encoded_tz})
        if self.token:
            cookies["token"] = urllib.parse.quote(str(self.token), safe="")
        cookie = "; ".join("%s=%s" % (key, value) for key, value in cookies.items() if key and value is not None)
        spec = self._profile_spec()
        headers = {
            "Pragma": "no-cache",
            "Accept": "*/*",
            "Host": parsed.netloc,
            "User-Agent": EMULATOR_USER_AGENT if self._compat_use_emulator_ua else spec["user_agent"],
            "X-User-Agent": "Model: MAG250; Link: WiFi" if self._compat_use_emulator_ua else spec["x_user_agent"],
            "Connection": "keep-alive",
            "Accept-Encoding": "gzip",
            "Referer": self.referer,
            "Cookie": cookie,
        }
        if self.token:
            headers["Authorization"] = "Bearer " + str(self.token)
        return headers
