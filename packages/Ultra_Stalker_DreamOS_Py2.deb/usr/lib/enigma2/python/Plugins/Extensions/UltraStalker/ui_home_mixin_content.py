# -*- coding: utf-8 -*-
"""Focus restore, refresh notices, account lines, content refresh, card emphasis, clock and menu warming.

Methods moved verbatim out of ``PortalHomeScreen`` (ui_screens_home.py); behaviour is unchanged.
This module is imported by ui_screens_home.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, max, min
from .ui_screens_home import (
    _,
    _category_cache_put,
    _lstrf,
    asset,
    content_refresh_failure,
    ePoint,
    eSize,
    eTimer,
    expiry_date,
    gFont,
    home_boot_pixmap,
    load_ui_state,
    optional_failure,
    os,
    parseColor,
    save_ui_state,
    time,
    updated_text,
)


class HomeContentMixin(object):
    """Focus restore, refresh notices, account lines, content refresh, card emphasis, clock and menu warming."""

    def _restore_home_focus(self):
        state=load_ui_state(self.profile)
        try:
            saved_key=str(state.get("home_key") or "").strip()
            matched=list(i for i,row in enumerate(self.CARDS) if str(row[2])==saved_key)
            if matched:self.index=matched[0]
            else:self.index=max(0,min(len(self.CARDS)-1,int(state.get("home_index",self.index))))
        except Exception as exc:optional_failure("ui.silent_guard",exc)
        self._ensure_menu_window();self._render_menu_window(load_icons=True)
        try:
            _saved_recent=int(state.get("home_recent_index",self.recent_index))
            # Migrate the old 3-panel index (0/1/2) to the first row of the
            # new Live/Movie/Series columns exactly once.
            if not state.get("home_recent_grid_v1") and 0<=_saved_recent<=2:_saved_recent*=3
            self.recent_index=max(0,min(8,_saved_recent))
        except Exception as exc:optional_failure("ui.silent_guard",exc)
        row=str(state.get("home_focus_row") or self.focus_row or "menu")
        self.focus_row=row if row in ("menu","recent") else "menu"
        self._update_focus()

    def refresh_hero(self):
        try:self["status"].setText(_("Home Hero changes only from Movie/Series Details MENU"))
        except Exception:pass

    def _show_refresh_notice(self,message):
        self._refresh_notice_visible=True
        self["refresh_notice_title"].setText(_("Refresh Content"))
        self["refresh_notice_message"].setText(str(message or _("Done")))
        for name in ("refresh_notice_panel","refresh_notice_title","refresh_notice_message"):
            try:self[name].show()
            except Exception:pass
        try:self["actions"].setEnabled(False)
        except Exception:pass
        try:self["refresh_notice_actions"].setEnabled(True)
        except Exception:pass

    def _hide_refresh_notice(self):
        self._refresh_notice_visible=False
        for name in ("refresh_notice_panel","refresh_notice_title","refresh_notice_message"):
            try:self[name].hide()
            except Exception:pass
        try:self["refresh_notice_actions"].setEnabled(False)
        except Exception:pass
        try:self["actions"].setEnabled(True)
        except Exception:pass

    def _home_expiry_text(self, expiry=None):
        value=str(expiry or self.profile.get("expiry") or "").strip()
        if not value:
            raw=str(self.profile.get("state") or "").strip()
            if "/" in raw:
                value=raw.split("/",2)[1].strip()
        return expiry_date(value) if value else ""

    def _set_home_account_line(self, expiry=None):
        """Use the existing account result; the card performs no network work."""
        try:
            self["portal_state"].setText("●")
            self["portal_connected"].setText(_("Server connected"))
            for name in ("portal_state","portal_connected"):
                if self[name].instance is not None:
                    self[name].instance.setForegroundColor(parseColor("#39e68b"))
            self["portal_expiry_prefix"].setText(_("Expires"))
            self["portal_expiry"].setText(self._home_expiry_text(expiry) or "—")
            self["portal_expiry_prefix"].show();self["portal_expiry"].show()
            self._fit_home_account_row()
            self._update_home_content_stamp()
        except Exception as exc:optional_failure("ui.home_account_card",exc)

    def _set_home_offline_line(self):
        """Offline changes text/colour only; card geometry and saved dates stay."""
        self._set_home_account_line()
        try:
            self["portal_connected"].setText(_("Server offline"))
            for name in ("portal_state","portal_connected"):
                if self[name].instance is not None:
                    self[name].instance.setForegroundColor(parseColor("#ff6060"))
            self._fit_home_account_row()
        except Exception as exc:optional_failure("ui.home_offline_card",exc)

    def _update_home_content_stamp(self):
        try:
            from .ui import home_content_updated_at
            text=updated_text(home_content_updated_at(self.profile), _).split(" • ",1)[-1]
            if text != getattr(self,"_home_content_stamp_text",None):
                self["home_content_updated"].setText(text)
                self._home_content_stamp_text=text
        except Exception as exc:optional_failure("ui.home_content_stamp",exc)

    def refresh_current_content(self):
        """Explicit GREEN refresh for the current Portal/Xtream/M3U source only."""
        if getattr(self,"_content_refresh_running",False) or getattr(self,"_refresh_notice_visible",False):
            return
        if getattr(self,"_busy",False):
            try:self["status"].setText(_("Please wait"))
            except Exception:pass
            return
        profile=dict(self.profile or {})
        client=self.client
        self._content_refresh_running=True
        self._set_home_account_line()
        def work(handle):
            method=getattr(client,"refresh_content",None)
            if not callable(method):
                raise RuntimeError(_("This source does not support content refresh."))
            result=method(cancel_event=handle.cancel_event)
            if handle.cancelled():
                raise RuntimeError(_("Content refresh cancelled"))
            rows=(result or {}).get("genre_rows") if isinstance(result,dict) else None
            if isinstance(rows,dict) and callable(_category_cache_put):
                for media,items in rows.items():
                    if isinstance(items,list) and items:
                        _category_cache_put(profile,media,items)
            if isinstance(result,dict) and result.get("ok"):
                from .ui import record_home_content_update
                record_home_content_update(profile)
            return result or {}
        def done(result):
            self._content_refresh_running=False
            self._set_home_account_line()
            try:self["status"].setText("")
            except Exception:pass
        def failed(exc):
            self._content_refresh_running=False
            message=content_refresh_failure(exc, _)
            self._set_home_account_line()
            try:self["status"].setText(message)
            except Exception:pass
        handle=self._run_async(work,done,failed)
        if not handle:
            self._content_refresh_running=False
            self._set_home_account_line()

    def _queue_home_focus_state(self, **updates):
        self._home_focus_state_pending=dict(updates or {})
        try:self._home_focus_state_timer.stop();self._home_focus_state_timer.start(250,True)
        except Exception:self._flush_home_focus_state()

    def _flush_home_focus_state(self):
        pending=getattr(self,"_home_focus_state_pending",None)
        self._home_focus_state_pending=None
        if not pending:return
        try:save_ui_state(self.profile,**pending)
        except Exception as exc:optional_failure("ui.home_focus_state_flush",exc)

    def _stop_home_focus_state_timer(self):
        try:self._home_focus_state_timer.stop()
        except Exception as exc:optional_failure("ui.home_focus_state_stop",exc)
        try:
            if self._home_focus_state_conn is not None:self._home_focus_state_conn.disconnect()
        except Exception as exc:optional_failure("ui.home_focus_state_disconnect",exc)
        try:
            if self._flush_home_focus_state in self._home_focus_state_timer.callback:self._home_focus_state_timer.callback.remove(self._flush_home_focus_state)
        except Exception as exc:optional_failure("ui.home_focus_state_callback",exc)

    # ------------------------------------------------------------------
    # R5.73 premium Home helpers
    def _home_card_emphasis(self, slot):
        """Focused card: bigger icon + larger title + its description; others stay calm."""
        if getattr(self,"_sc_mode",False):
            return
        sx=float(getattr(self,"_home_sx",1.0) or 1.0);sy=float(getattr(self,"_home_sy",1.0) or 1.0)
        start=int(getattr(self,"_menu_window_start",0) or 0)
        prev=getattr(self,"_home_focus_slot",-1);prev_start=getattr(self,"_home_emph_start",None)
        key=(sx,sy,start)
        if prev_start==key and getattr(self,"_home_emph_done",False):
            todo=sorted(i for i in {prev,slot} if 0<=i<self.VISIBLE_CARD_COUNT)
        else:
            todo=range(self.VISIBLE_CARD_COUNT)
        self._home_focus_slot=slot;self._home_emph_start=key
        try:self._home_emph_done=self["card_title0"].instance is not None
        except Exception:self._home_emph_done=False
        for i in todo:
            focused = (i == slot);cx=self.CARD_X[i]
            try:
                if focused:self["card_sub%d"%i].show()
                else:self["card_sub%d"%i].hide()
            except Exception:pass
            try:
                inst=self["card_title%d"%i].instance
                if inst is not None:
                    inst.setFont(_ultra_rfont("Regular",26 if focused else 22))
                    inst.setForegroundColor(parseColor("#ffffff"))
                    inst.move(ePoint(int((cx+13)*sx),int((534+(108 if focused else 102))*sy)))
                sub=self["card_sub%d"%i].instance
                if sub is not None:sub.move(ePoint(int((cx+13)*sx),int((534+(142 if focused else 135))*sy)))
            except Exception:pass
            try:
                logical=start+i
                if logical>=len(self.CARDS):continue
                ic=self["menu_icon%d"%i].instance
                if ic is None:continue
                name=self.CARDS[logical][3]
                if focused:name=name.replace(".png","_big.png");w,h,dx,dy=136,102,51,4
                else:w,h,dx,dy=112,82,63,18
                ic.move(ePoint(int((cx+dx)*sx),int((534+dy)*sy)));ic.resize(eSize(int(w*sx),int(h*sy)))
                state=(logical,bool(focused))
                if self._home_icon_state.get(i)!=state:
                    path=asset(name)
                    if path and os.path.isfile(path):
                        pix=home_boot_pixmap(path) if callable(home_boot_pixmap) else None
                        if pix is not None:ic.setPixmap(pix)
                        else:ic.setPixmapFromFile(path)
                        self._home_icon_state[i]=state
            except Exception as exc:optional_failure("ui.home_icon_focus",exc)

    def _home_clock_tick(self):
        try:
            now=time.localtime()
            self["home_clock"].setText(time.strftime("%H:%M",now))
            day=_lstrf("%A",now);month=_lstrf("%B",now)
            self["home_weekday"].setText(str(day))
            self["home_date"].setText("%d %s %d"%(int(now.tm_mday),month,int(now.tm_year)))
            inst=self["home_date"].instance
            if inst is not None and inst.calculateSize().width()>inst.size().width():
                self["home_date"].setText("%d %s %d"%(int(now.tm_mday),_lstrf("%b",now),int(now.tm_year)))
        except Exception as exc:optional_failure("ui.home_clock",exc)
        try:
            self._home_clock_timer.stop();self._home_clock_timer.start(max(1000,(60-int(time.time())%60)*1000),True)
        except Exception:pass
        self._update_home_content_stamp()
        self._schedule_auto_content_refresh()

    def _schedule_auto_content_refresh(self):
        """Let Home and the first category open use the warm cache.

        The refresh itself still runs on entry or at the daily hour, but it
        starts after navigation has had the client, and it publishes the new
        category lists instead of deleting the ones already on screen.
        """
        timer=getattr(self,"_auto_refresh_timer",None)
        if timer is None:
            try:
                timer=eTimer();self._auto_refresh_timer=timer
                try:self._auto_refresh_conn=timer.timeout.connect(self._maybe_auto_content_refresh)
                except Exception:timer.callback.append(self._maybe_auto_content_refresh)
            except Exception:
                self._maybe_auto_content_refresh();return
        try:timer.stop();timer.start(6000,True)
        except Exception:self._maybe_auto_content_refresh()

    def _maybe_auto_content_refresh(self):
        """Lists refresh when a Portal or Xtream source is opened.

        The old every-open and daily-hour switches are retired. A manual
        refresh remains available from Settings.
        """
        return

    def _warm_portal_menus(self):
        """Download the three section menus once, like a fast portal open.

        Channel and movie pages stay where they are. Only the folder names
        are refreshed, so the next list opens from memory instead of starting
        a heavy catalogue wipe.
        """
        if getattr(self, "_menu_warm_done", False) or getattr(self, "_menu_warm_running", False) or getattr(self, "_screen_closed", False):
            return
        try:
            from .ui import _category_cache_age
            profile = dict(self.profile or {})
            if all(_category_cache_age(profile, media) < 90 for media in ("itv", "vod", "series")):
                self._menu_warm_done = True
                return
        except Exception:
            profile = dict(self.profile or {})
        client = self.client
        method = getattr(client, "refresh_menus", None)
        if not callable(method):
            return
        profile = dict(self.profile or {})
        self._menu_warm_running = True
        def work(handle):
            result = method(cancel_event=handle.cancel_event)
            rows = (result or {}).get("genre_rows") if isinstance(result, dict) else None
            if isinstance(rows, dict) and callable(_category_cache_put):
                for media, items in rows.items():
                    if isinstance(items, list) and items:
                        _category_cache_put(profile, media, items)
            return result or {}
        def done(_result):
            self._menu_warm_running = False
            self._menu_warm_done = True
        def failed(_exc):
            self._menu_warm_running = False
        if not self._run_async(work, done, failed):
            self._menu_warm_running = False

    def _home_clock_stop(self):
        for t,c in ((getattr(self,"_home_clock_timer",None),getattr(self,"_home_clock_conn",None)),(getattr(self,"_auto_refresh_timer",None),getattr(self,"_auto_refresh_conn",None))):
            try:
                if t is not None:t.stop()
            except Exception:pass
            try:
                if c is not None:c.disconnect()
            except Exception:pass
from .wqhd_layout import responsive_font as _ultra_rfont, factors as _ultra_factors

def _ultra_osd_scale():
    return _ultra_factors()[1]
