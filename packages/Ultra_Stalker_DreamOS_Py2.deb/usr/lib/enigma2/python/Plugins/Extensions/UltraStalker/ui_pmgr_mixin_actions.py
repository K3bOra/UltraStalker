# -*- coding: utf-8 -*-
"""Portal helpers, action entries and rendering, selection and status.

Methods moved verbatim out of ``PortalManagerPremiumScreen`` (ui_screens_portallist.py); behaviour is unchanged.
This module is imported by ui_screens_portallist.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, max, min
from .ui_screens_portallist import (
    _,
    os,
)


class PortalManagerActionsMixin(object):
    """Portal helpers, action entries and rendering, selection and status."""

    def _selected_portal(self):
        try:
            idx = self.parent._index()
            if idx is not None and 0 <= idx < len(self.parent.profiles):
                return self.parent.profiles[idx]
        except Exception as exc:
            optional_failure("ui.portal_selected",exc)
        return None

    @staticmethod
    def _portal_name(profile, index=0):
        p = profile if isinstance(profile, dict) else {}
        if str(p.get("source_type") or "").lower() == "m3u":
            return str(p.get("name") or (_("M3U Playlist %d") % (index + 1)))
        return str(p.get("name") or (_("Portal Server %d") % (index + 1)))

    def _live_integration_exported(self, profile):
        """Return True when this portal already owns Live export state.

        Portal Manager only needs this while it is open, so keep the bouquet
        module lazy.  Treat either a committed registry row or surviving owned
        files as exported; in a partial/stale state the useful action is still
        Remove, because unexport_live_integration() is the cleanup path.
        """
        if not isinstance(profile, dict) or not profile:
            return False
        try:
            from .core.bouquets import _profile_key, _read_registry, _bouquet_paths
            pkey = _profile_key(profile)
            registry = _read_registry() or {}
            if isinstance(registry.get(pkey), dict):
                return True
            paths = _bouquet_paths(pkey) or {}
            for name in ("bouquet", "epg_channels", "epg_source", "xmltv_cache"):
                path = str(paths.get(name) or "")
                if path and os.path.exists(path):
                    return True
        except Exception as exc:
            optional_failure("ui.portal_manager_live_export_state", exc)
        return False

    def _action_entries(self):
        """Build the visible Portal Manager rows for the selected portal."""
        profile = self._selected_portal()
        exported = self._live_integration_exported(profile) if profile else False
        try:
            has_disabled = bool(load_disabled_profiles())
        except Exception as exc:
            optional_failure("ui.portal_manager_disabled_state", exc)
            has_disabled = False
        rows = []
        action_source = list(self._ACTIONS)
        for entry in action_source:
            action = entry[1] if len(entry) > 1 else ""
            if action == "enable_disabled" and not has_disabled:
                continue
            if action == "device_profile" and (not profile or str(profile.get("source_type") or "stalker").lower() == "m3u"):
                continue
            if action == "duplicate" and (not profile or str(profile.get("source_type") or "stalker").lower() == "m3u"):
                continue
            if action == "export_bouquet" and exported:
                continue
            if action == "unexport_bouquet" and not exported:
                continue
            rows.append(entry)
        return rows

    def _action_value(self, action):
        profile = self._selected_portal() or {}
        if action == "import_local_m3u":
            return _("HDD / USB / /tmp")
        if action == "add_portal":
            return _("URL / MAC")
        if action == "enable_disabled":
            try: return _("%d disabled") % len(load_disabled_profiles())
            except Exception: return _("Disabled portals")
        if action == "rename": return self._portal_name(profile) if profile else _("No portal selected")
        if action == "edit":
            raw = str(profile.get("portal") or "")
            return raw[:30] if raw else _("No portal selected")
        if action == "device_profile":
            if not profile: return _("No portal selected")
            device = str(profile.get("device_profile") or "Auto")
            return _("Auto") if device.lower() == "auto" else device.upper()
        if action == "move_portals": return _("%d portals • Multi-select") % len(getattr(self.parent, "profiles", []) or [])
        return ""

    @staticmethod
    def _settings_icon(icon_rel):
        """Use the exact 40x40 icon copies used by Settings Test8.

        Enigma2 MultiContent clips pixmaps instead of scaling them; handing it
        the authored 256x256 source icon is why Test30 looked icon-less on the
        receiver.
        """
        try:
            base = os.path.basename(str(icon_rel or ""))
            compact = asset("settings_icons_40/" + base) if base else ""
            if compact and os.path.isfile(compact):
                return compact
        except Exception as exc:
            optional_failure("ui.portal_icon_compact",exc)
        try:
            return asset(icon_rel)
        except Exception:
            return ""

    def _render_actions(self, selected=0):
        self._mode = "actions"
        entries = self._action_entries()
        self._visible_actions = list(entries)
        selected = max(0, min(int(selected or 0), max(0, len(entries) - 1))) if entries else 0
        rows = []
        for idx, (title, action, desc, icon_rel) in enumerate(entries):
            value = self._action_value(action)
            meta = {"level": "groups", "selected": bool(idx == selected), "kind": "group",
                    "value": str(value or ""), "count": str(value or ""),
                    "neutral_secondary": True}
            rows.append((_(title), self._settings_icon(icon_rel), action, meta))
        self._rebuilding = True
        try:
            self["list"].fit_visible_rows(max(1,min(11,len(rows))))
            self["list"].set_icon_rows(rows)
            if rows: self["list"].moveToIndex(selected)
        finally:
            self._rebuilding = False
        self._visual_index = selected
        self._update_status()

    def _render_multi(self, selected=0):
        self._mode = "multi"
        self._multi_profiles = list(load_profiles())
        valid = set(range(len(self._multi_profiles)))
        self._multi_selected.intersection_update(valid)
        selected = max(0, min(int(selected or 0), max(0, len(self._multi_profiles) - 1))) if self._multi_profiles else 0
        rows = []
        for idx, profile in enumerate(self._multi_profiles):
            picked = idx in self._multi_selected
            is_m3u = str(profile.get("source_type") or "").lower() == "m3u"
            identity = str(profile.get("mac") or "M3U")
            value = (((_("SELECTED") + " • ") if picked else "") + identity)[:32]
            meta = {"level": "groups", "selected": bool(idx == selected), "kind": "group",
                    "value": str(value or ""), "count": str(value or "")}
            icon_rel = "settings_icons_40/multi_search.png" if picked else ("settings_icons_40/web_access.png" if not is_m3u else "settings_icons_40/channel_list.png")
            rows.append((self._portal_name(profile, idx), self._settings_icon(icon_rel), profile, meta))
        self._rebuilding = True
        try:
            self["list"].fit_visible_rows(max(1,min(11,len(rows))))
            self["list"].set_icon_rows(rows)
            if rows: self["list"].moveToIndex(selected)
        finally:
            self._rebuilding = False
        self._visual_index = selected
        self._update_status()

    @staticmethod
    def _format_m3u_size(size_bytes):
        try:
            sz = int(size_bytes or 0)
        except Exception:
            sz = 0
        if sz >= 1024 * 1024:
            return "%.1f MB" % (float(sz) / (1024.0 * 1024.0))
        if sz >= 1024:
            return "%.1f KB" % (float(sz) / 1024.0)
        return "%d B" % sz

    def _render_local_m3u_entries(self, selected=0):
        self._mode = "local_m3u"
        entries = list(getattr(self, "_local_m3u_entries", []) or [])
        selected = max(0, min(int(selected or 0), max(0, len(entries) - 1))) if entries else 0
        rows = []
        for idx, (_kind, _target, title, sub, icon_rel) in enumerate(entries):
            meta = {
                "level": "groups",
                "selected": bool(idx == selected),
                "kind": "group",
                "value": str(sub or "")[:36],
                "count": str(sub or "")[:36],
                "row_asset": self._row_asset,
                "row_selected_asset": self._row_selected_asset,
                "value_color": self._value_color,
                "utility_accent_strong": True,
                "neutral_secondary": True,
            }
            rows.append((str(title), self._settings_icon(icon_rel), _target, meta))
        self._rebuilding = True
        try:
            self["list"].fit_visible_rows(max(1, min(11, len(rows))))
            self["list"].set_icon_rows(rows)
            if rows:
                self["list"].moveToIndex(selected)
        finally:
            self._rebuilding = False
        self._visual_index = selected
        self._update_status()

    def _render_local_m3u_roots(self, selected=0):
        self._local_m3u_current_dir = None
        self._local_m3u_root_dir = None
        entries = [
            ("scan", None, _("Scan All Storage for M3U Files"), _("Auto-detect .m3u / .m3u8 files"), "settings_icons_40/multi_search.png"),
        ]
        for root_path, label in list_local_m3u_roots():
            entries.append(("root", root_path, label, root_path, "settings_icons_40/disk.png"))
        self._local_m3u_entries = entries
        self._render_local_m3u_entries(selected)

    def _render_local_m3u_scan_results(self, selected=0):
        self._local_m3u_current_dir = "__scan__"
        entries = [
            ("up_roots", None, _(".. (Back to Storage Locations)"), _("Return to storage list"), "settings_icons_40/recovery.png"),
        ]
        try:
            found = list(scan_local_m3u_files() or [])
        except Exception:
            found = []
        if not found:
            entries.append(("empty", None, _("No .m3u / .m3u8 files found"), _("Place .m3u files on USB, HDD or /tmp"), "settings_icons_40/channel_list.png"))
        else:
            for fname, fpath, fsize in found:
                folder = os.path.basename(os.path.dirname(fpath)) or os.path.dirname(fpath)
                sub = "%s  •  %s" % (folder, self._format_m3u_size(fsize))
                entries.append(("file", fpath, fname, sub, "settings_icons_40/channel_list.png"))
        self._local_m3u_entries = entries
        self._render_local_m3u_entries(selected)

    def _render_local_m3u_dir(self, dir_path, selected=0):
        norm_dir = os.path.normpath(str(dir_path or "/"))
        self._local_m3u_current_dir = norm_dir
        root_dir = getattr(self, "_local_m3u_root_dir", None)
        if norm_dir == "/" or (root_dir and norm_dir == os.path.normpath(root_dir)):
            up_target = None
            up_label = _(".. (Back to Storage Locations)")
        else:
            up_target = os.path.dirname(norm_dir) or "/"
            up_label = _(".. (Parent Folder)")
        entries = [
            ("up", up_target, up_label, norm_dir, "settings_icons_40/recovery.png"),
        ]
        subdirs = []
        m3u_files = []
        try:
            for name in sorted(os.listdir(norm_dir), key=lambda x: str(x).lower()):
                if name.startswith(".") and name != ".uslib":
                    continue
                full = os.path.join(norm_dir, name)
                try:
                    st = os.stat(full)
                except OSError:
                    continue
                if os.path.isdir(full):
                    subdirs.append((name, full))
                elif name.lower().endswith((".m3u", ".m3u8")):
                    m3u_files.append((name, full, int(st.st_size)))
        except OSError:
            pass
        for dname, dfull in subdirs:
            entries.append(("dir", dfull, dname, _("Folder"), "settings_icons_40/disk.png"))
        for fname, ffull, fsize in m3u_files:
            entries.append(("file", ffull, fname, "M3U  •  %s" % self._format_m3u_size(fsize), "settings_icons_40/channel_list.png"))
        if not subdirs and not m3u_files:
            entries.append(("empty", None, _("No .m3u files in this folder"), norm_dir, "settings_icons_40/channel_list.png"))
        self._local_m3u_entries = entries
        self._render_local_m3u_entries(selected)

    def _selection_changed(self):
        if self._rebuilding:
            return
        idx = self._safe_index()
        if idx != self._visual_index:
            old = self._visual_index
            self._visual_index = idx
            # Only repaint the two affected rows.  Do not rebuild the whole list
            # on remote navigation; this is the same light interaction contract
            # used elsewhere after the restart/double-key work.
            if self._mode == "actions":
                # R5.219: keep Portal Manager navigation lightweight.  Repaint
                # only the row losing focus and the row gaining focus.  Include
                # both value and count because SettingsGlassList renders the
                # second line from count; omitting it was the original reason
                # portal details disappeared on focus.  The secondary line is
                # deliberately neutral instead of mint-green.
                entries = list(self._visible_actions)
                for j in set((old, idx)):
                    if 0 <= j < len(entries):
                        title, action, _desc, icon_rel = entries[j]
                        value = self._action_value(action)
                        meta = {"level": "groups", "selected": bool(j == idx), "kind": "group",
                                "value": str(value or ""), "count": str(value or ""),
                                "neutral_secondary": True}
                        self["list"].update_icon_row(
                            j, (_(title), self._settings_icon(icon_rel), action, meta)
                        )
            elif self._mode == "multi":
                for j in set((old, idx)):
                    if 0 <= j < len(self._multi_profiles):
                        profile = self._multi_profiles[j]; picked = j in self._multi_selected
                        is_m3u = str(profile.get("source_type") or "").lower() == "m3u"
                        value = (((_("SELECTED") + " • ") if picked else "") + str(profile.get("mac") or "M3U"))[:32]
                        meta = {"level":"groups", "count":value, "selected": j == idx, "value": value, "row_asset": self._row_asset, "row_selected_asset": self._row_selected_asset, "value_color": self._value_color, "utility_accent_strong": True}
                        icon_rel = "settings_icons_40/multi_search.png" if picked else ("settings_icons_40/web_access.png" if not is_m3u else "settings_icons_40/channel_list.png")
                        self["list"].update_icon_row(j, (self._portal_name(profile, j), self._settings_icon(icon_rel), profile, meta))
            elif self._mode == "local_m3u":
                entries = list(getattr(self, "_local_m3u_entries", []) or [])
                for j in set((old, idx)):
                    if 0 <= j < len(entries):
                        _k, _target, title, sub, icon_rel = entries[j]
                        val = str(sub or "")[:36]
                        meta = {"level":"groups", "count":val, "selected": bool(j == idx), "value": val, "row_asset": self._row_asset, "row_selected_asset": self._row_selected_asset, "value_color": self._value_color, "utility_accent_strong": True, "neutral_secondary": True}
                        self["list"].update_icon_row(j, (str(title), self._settings_icon(icon_rel), _target, meta))
        self._update_status()

    def _update_status(self):
        if self._mode == "local_m3u":
            self["status"].setText(_("Local M3U Browser  •  OK Open Folder / Import Playlist  •  BACK Return"))
            return
        if self._mode == "multi":
            self["status"].setText(_("Move %d selected • ARROWS choose destination • GREEN Place Here • BACK Cancel") % len(self._multi_selected))
            return
        # R5.218: the permanent Portal Manager helper sentence added visual
        # noise across the bottom-right of the clean Portal background.  The
        # cards themselves are self-explanatory and modal actions already give
        # their own feedback, so keep the normal manager footer intentionally
        # empty.  Multi-select mode above retains its operational instruction.
        self["status"].setText("")
