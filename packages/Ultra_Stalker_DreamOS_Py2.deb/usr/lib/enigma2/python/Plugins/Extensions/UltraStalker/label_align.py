"""eLabel alignment helpers.

eLabel.setHAlign/setVAlign take eLabel's own enum (alignLeft, alignCenter,
alignRight, alignTop, alignBottom).  The RT_* constants belong to list
MultiContent rows and have different values, so passing them to an eLabel
puts text in the wrong place (top/side), especially for translated text.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import int
_H={"left":("alignLeft",0),"center":("alignCenter",1),"right":("alignRight",2)}
_V={"top":("alignTop",0),"center":("alignCenter",1),"bottom":("alignBottom",2)}
def _get(table,kind):
    name,default=table[kind]
    try:
        from enigma import eLabel
        return int(getattr(eLabel,name,default))
    except Exception:
        return default
def halign(kind):return _get(_H,kind)
def valign(kind):return _get(_V,kind)
