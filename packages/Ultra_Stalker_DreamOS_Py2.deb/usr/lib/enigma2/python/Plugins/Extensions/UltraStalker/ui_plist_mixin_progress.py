# -*- coding: utf-8 -*-
"""Progress polling, UI hook teardown and colour key handlers.

Methods moved verbatim out of ``PortalListScreen`` (ui_screens_portallist.py); behaviour is unchanged.
This module is imported by ui_screens_portallist.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, round, us_clear
from .ui_helpers import fit_color_key_labels
from .ui_screens_portallist import (
    _,
    queue,
)


class PortalListProgressMixin(object):
    """Progress polling, UI hook teardown and colour key handlers."""

    def _fit_portal_color_keys(self):
        fit_color_key_labels(self, max_size=20, min_size=13, padding=4)

    def _start_portal_progress_poll(self):
        if getattr(self,"_screen_closed",False):return
        if getattr(self,"_portal_progress_active",False):return
        try:
            self._portal_progress_timer.start(300,False)
            self._portal_progress_active=True
        except Exception as exc:optional_failure("ui.portal_progress_start",exc)

    def _pause_portal_progress_poll(self):
        if not getattr(self,"_portal_progress_active",False):return
        try:self._portal_progress_timer.stop()
        except Exception as exc:optional_failure("ui.portal_progress_pause",exc)
        self._portal_progress_active=False

    def _stop_portal_progress(self):
        timer = getattr(self, "_pt_result_timer", None)
        if timer is not None:
            try:
                timer.stop()
            except Exception:
                pass
            try:
                if self._pt_clear_result in timer.callback:
                    timer.callback.remove(self._pt_clear_result)
            except Exception:
                pass
        conn = getattr(self, "_pt_result_conn", None)
        if conn is not None:
            try:
                conn.disconnect()
            except Exception:
                pass
            self._pt_result_conn = None
        self._portal_progress_active=False
        try:self._portal_progress_timer.stop()
        except Exception as exc:optional_failure("ui.portal_progress_stop",exc)
        try:
            if self._portal_progress_conn is not None:self._portal_progress_conn.disconnect()
        except Exception as exc:optional_failure("ui.portal_progress_stop",exc)
        try:
            if self._drain_portal_progress in self._portal_progress_timer.callback:self._portal_progress_timer.callback.remove(self._drain_portal_progress)
        except Exception as exc:optional_failure("ui.portal_progress_callback",exc)

    def _stop_portal_ui_hooks(self):
        try:
            while True:self._portal_progress_jobs.get_nowait()
        except queue.Empty:
            pass
        except Exception as exc:
            optional_failure("ui.portal_progress_queue_drain",exc)
        for hook_name, callback in (
            ("onLayoutFinish", self._layout_ready),
            ("onShown", self._portal_list_shown),
        ):
            try:
                hooks=getattr(self,hook_name,None)
                if hooks is not None and callback in hooks:hooks.remove(callback)
            except Exception as exc:
                optional_failure("ui.portal_hook_cleanup",exc)
        try:
            callbacks=self["list"].onSelectionChanged
            if self._selection_changed in callbacks:callbacks.remove(self._selection_changed)
        except Exception as exc:
            optional_failure("ui.portal_selection_cleanup",exc)

    def _drain_portal_progress(self):
        if getattr(self, "_screen_closed", False):
            return
        latest = None
        while True:
            try:latest = self._portal_progress_jobs.get_nowait()
            except queue.Empty:break
        if latest:
            done,total,name,success = latest
            mark = _("OK") if success else _("FAILED")
            self._set_check_progress(_("Check %d/%d • %s • %s") % (done,total,str(name)[:16],mark))
        if not getattr(self,"_busy",False) and self._portal_progress_jobs.empty():
            self._pause_portal_progress_poll()

    def _portal_cancel(self):
        if getattr(self, "_check_notice_visible", False):
            self._hide_check_notice()
            return
        if self._portal_select_mode:
            self._portal_select_mode = False
            us_clear(self._portal_selected)
            self._render_portal_rows(self._index() or 0)
            self._selection_changed()
            return
        if self._bulk_move_mode:
            self._cancel_bulk_move()
            return
        if self._reorder_mode:
            self._finish_reorder(commit=False)
            return
        if not getattr(self, "_tab_focus", False):
            self._tab_focus = True
            self.refresh()
            return
        self.close()

    def _portal_ok(self):
        if getattr(self, "_check_notice_visible", False):
            self._hide_check_notice()
            return
        if self._bulk_move_mode:
            self["status"].setText(_("Move selected portals • GREEN Place Here • BACK Cancel"))
            return
        if self._portal_select_mode:
            self._toggle_portal_selection_and_advance()
            return
        if self._reorder_mode:
            self._finish_reorder(commit=True)
            return
        if getattr(self, "_tab_focus", False):
            self._enter_category_grid()
            return
        self.open_portal()

    def _portal_green(self):
        if getattr(self, "_check_notice_visible", False):
            return
        if self._bulk_move_mode:
            self._place_bulk_move()
            return
        if self._reorder_mode:
            self["status"].setText(_("Move portal  •  ARROWS choose position  •  OK Save  •  BACK Cancel"))
            return
        if getattr(self, "_tab_focus", False):
            self._enter_category_grid()
        self._set_reorder_mode(True)

    def _portal_blue(self):
        if getattr(self, "_check_notice_visible", False):
            return
        if self._bulk_move_mode:
            self["status"].setText(_("Move selected portals • GREEN Place Here • BACK Cancel"))
            return
        if getattr(self, "_tab_focus", False) and self.profiles:
            self._enter_category_grid()
            return
        self._request_disable_portals()

    def _portal_red(self):
        if getattr(self, "_check_notice_visible", False):
            return
        if self._bulk_move_mode:
            self["status"].setText(_("Move selected portals • GREEN Place Here • BACK Cancel"))
            return
        if self._portal_select_mode:
            self._request_delete_selected_portals()
            return
        if getattr(self, "_tab_focus", False) and self.profiles:
            self._enter_category_grid()
            return
        self.delete_portal()

    def _portal_yellow(self):
        if getattr(self, "_check_notice_visible", False):
            return
        if self._bulk_move_mode:
            self["status"].setText(_("Move selected portals • GREEN Place Here • BACK Cancel"))
            return
        self.check_all_portals()

    def _portal_menu(self):
        if getattr(self, "_check_notice_visible", False):
            return
        if self._bulk_move_mode:
            self["status"].setText(_("Move selected portals • GREEN Place Here • BACK Cancel"))
            return
        self.open_portal_tools()

    def _portal_info(self):
        if getattr(self, "_check_notice_visible", False):
            return
        if self._bulk_move_mode:
            self["status"].setText(_("Move selected portals • GREEN Place Here • BACK Cancel"))
            return
        self.open_diagnostics()

from .wqhd_layout import responsive_font as _ultra_rfont, factors as _ultra_factors

def _ultra_osd_scale():
    return _ultra_factors()[1]
