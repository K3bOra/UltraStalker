# -*- coding: utf-8 -*-
"""Core runtime for UltraStalker 3.x."""
from __future__ import absolute_import, division, print_function, unicode_literals
