# -*- coding: utf-8 -*-
"""Inline, cancellable film/series correction using the existing menu rows."""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, InterruptedError, us_clear, us_text_callback, native_text
from Screens.VirtualKeyBoard import VirtualKeyBoard
from . import _,current_language
from .ui_async import AsyncScreenMixin
from .manual_identity import cache_token,original,set_choice,changed_since_paint
from .manual_match import search_candidates,verify_candidate
from .storage import load_settings
from .tmdb import TMDBClient

def text(en,ar):
    return ar if str(current_language()).startswith('ar') else _(en)

def menu_choices():
    return [(text('Correct movie / series','تصحيح الفيلم أو المسلسل'),'manual_match')]

def open_picker(owner,item,callback):
    previous=getattr(owner,'_manual_match_controller',None)
    if previous is not None:previous._dispose()
    controller=InlineManualMatch(owner,item,callback)
    if not controller._screen_closed:owner._manual_match_controller=controller

class InlineManualMatch(AsyncScreenMixin):
    """Correction steps reuse the owner's menu; no new Screen is constructed."""
    def __init__(self,owner,item,callback):
        self.owner=owner;self.callback=callback
        self.profile=dict(owner.profile or {});self.media_type=owner.media_type
        self.item=original(item);self._before=cache_token(self.profile,self.media_type,self.item)
        self._settings=load_settings() or {};self._rows=[];self._page=1;self._pages=1
        self._search_generation=0;self._failed_page=None;self._candidate=None;self._confirmation=None
        self._query=str(self.item.get('_raw_name') or self.item.get('name') or self.item.get('title') or '').strip()[:160]
        self.onClose=[];self.onShow=[];self.onHide=[]
        self._async_init();owner.onClose.append(self._dispose)
        self._search(1)

    def _client(self):
        credential=str(self._settings.get('tmdb_credential') or '').strip()
        if not credential:raise ValueError(text('TMDb is not configured.','إعداد TMDb غير متاح.'))
        return TMDBClient(credential,self._settings.get('tmdb_language','ar-EG'),timeout=6)

    def _show(self,rows,accept=None):
        if self._screen_closed or self.owner._screen_closed:return
        overlay=getattr(self.owner,'_settings_inline_menu',None)
        if overlay is None:
            show=getattr(self.owner,'_poster_menu_show',None)
            if callable(show):
                show(rows,on_accept=accept or (lambda row:self._finish()),on_close=self._finish)
            else:
                from .ui_floating_notice import show_notice
                show_notice(self.owner.session,text('Correction menu unavailable in this view.','قائمة التصحيح غير متاحة في العرض ده.'),owner=self.owner)
                self._finish()
            return
        show=getattr(self.owner,'_details_menu_scrim_show',None) or getattr(self.owner,'_settings_menu_scrim_show',None)
        if show:show()
        overlay.show(rows,on_accept=accept or (lambda row:self._finish()),on_close=self._finish,
            right=1850,region_top=240,region_h=400,anchor_bottom=670,
            min_card_w=560,max_card_w=680,padding=54,visual_style='text_only',
            row_h=66,max_visible=6,text_font=26)

    def _controls(self):
        rows=[(text('Edit search: ','تعديل البحث: ')+self._query,'edit')]
        if self._failed_page is not None:rows.append((text('Retry search','إعادة محاولة البحث'),'retry'))
        if self._page>1:rows.append((text('Previous results','النتائج السابقة'),'previous'))
        if self._page<self._pages:rows.append((text('More results','نتائج أخرى'),'next'))
        rows.extend([(text('Automatic matching','المطابقة التلقائية'),'reset'),(text('Back','رجوع'),'back')])
        return rows

    def _results(self,notice=None):
        rows=[]
        if notice:rows.append((str(notice)[:100],'notice'))
        for row in self._rows:
            year=str(row.get('release_date') or row.get('first_air_date') or '')[:4] or '—'
            kind=text('Series','مسلسل') if row['media_type']=='tv' else text('Movie','فيلم')
            country=' | KR' if row.get('original_language')=='ko' or 'KR' in (row.get('origin_country') or []) else ''
            rows.append(('%s | %s | %s%s'%(row['title'],year,kind,country),row))
        self._show(rows+self._controls(),self._selected)

    def _search(self,page):
        self._cancel_active_async()
        self._search_generation+=1;generation=self._search_generation;query=self._query
        self._rows=[];self._candidate=None;self._confirmation=None;self._failed_page=None
        self._show([(text('Searching…','جارٍ البحث…'),'wait'),(text('Back','رجوع'),'back')],self._waiting)
        def done(data):
            if self._screen_closed or generation!=self._search_generation:return
            self._rows=data['rows'];self._page=data['page'];self._pages=data['total_pages']
            self._results(text('No results','لا توجد نتائج') if not self._rows else None)
        def failed(exc):
            if self._screen_closed or generation!=self._search_generation:return
            self._rows=[];self._failed_page=page;self._results(str(exc))
        self._run_async(lambda handle:search_candidates(self._client(),query,self.media_type,page,handle.cancel_event),done,failed)

    def _waiting(self,row):
        if row and row[1]=='back':self._finish()
        else:self._show([(text('Please wait…','جارٍ التنفيذ…'),'wait'),(text('Back','رجوع'),'back')],self._waiting)

    def _selected(self,choice_row):
        if not choice_row:return self._finish()
        action=choice_row[1]
        if isinstance(action,dict):
            self._candidate=action
            self._show_match_confirmation()
        elif action=='edit':
            self.owner.session.openWithCallback(us_text_callback(self._entered),VirtualKeyBoard,title=native_text(text('Search title','اسم العمل للبحث')),text=native_text(self._query))
        elif action=='previous':self._search(self._page-1)
        elif action=='next':self._search(self._page+1)
        elif action=='retry':self._search(self._failed_page or 1)
        elif action=='reset':
            self._candidate=None;self._show_reset_confirmation()
        elif action=='back':self._finish()
        else:self._results()

    def _entered(self,value):
        if self._screen_closed:return
        if value is not None and str(value).strip():
            self._query=str(value).strip()[:160];self._pages=1;self._search(1)
        else:self._results()

    def _show_match_confirmation(self):
        row=self._candidate
        if row is None:return self._results()
        self._confirmation='match'
        year=str(row.get('release_date') or row.get('first_air_date') or '')[:4]
        kind=text('Series','مسلسل') if row['media_type']=='tv' else text('Movie','فيلم')
        self._show([(row['title'],'match_info'),('%s | %s | TMDb: %s'%(year,kind,row['tmdb_id']),'match_info'),
            (text('Apply this match','تأكيد المطابقة'),row),(text('Back to results','رجوع للنتائج'),'back')],self._confirmed)

    def _show_reset_confirmation(self):
        self._confirmation='reset'
        self._show([(text('Return to automatic matching?','الرجوع للمطابقة التلقائية؟'),'reset_info'),
            (text('Confirm','تأكيد'),'reset'),(text('Back','رجوع'),'back')],self._confirmed)

    def _confirmed(self,row):
        if not row:return self._results()
        action=row[1]
        if action=='back':return self._results()
        if action=='match_info' and self._confirmation=='match':return self._show_match_confirmation()
        if action=='reset_info' and self._confirmation=='reset':return self._show_reset_confirmation()
        if not ((action=='reset' and self._confirmation=='reset') or
                (isinstance(action,dict) and self._confirmation=='match' and action==self._candidate)):
            return self._results()
        self._show([(text('Saving selection…','جارٍ حفظ الاختيار…'),'wait'),(text('Back','رجوع'),'back')],self._waiting)
        def work(handle):
            selected=None if action=='reset' else verify_candidate(self._client(),action)
            if handle.cancelled():raise InterruptedError('Cancelled')
            set_choice(self.profile,self.media_type,self.item,selected)
            return True
        self._run_async(work,lambda result:self._finish(),lambda exc:self._results(str(exc)))

    def _dispose(self):
        if self._screen_closed:return
        self._search_generation+=1
        close=getattr(self.owner,'_poster_menu_close',None)
        if callable(close):close(notify=False)
        self._stop_async()
        if self._dispose in self.owner.onClose:self.owner.onClose.remove(self._dispose)
        if getattr(self.owner,'_manual_match_controller',None) is self:self.owner._manual_match_controller=None

    def _finish(self):
        if self._screen_closed:return
        changed=cache_token(self.profile,self.media_type,self.item)!=self._before
        overlay=getattr(self.owner,'_settings_inline_menu',None)
        if overlay:overlay.hide()
        hide=getattr(self.owner,'_details_menu_scrim_hide',None) or getattr(self.owner,'_settings_menu_scrim_hide',None)
        if hide:hide()
        self._dispose()
        if not self.owner._screen_closed:self.callback(changed)

def refresh_grid(owner,changed):
    if not changed or owner._screen_closed:return
    if not changed_since_paint(owner):return
    from .manual_identity import apply_choice
    owner.grid_items=[apply_choice(owner.profile,owner.media_type,x) for x in owner.grid_items]
    with owner._prepared_page_lock:us_clear(owner._prepared_page_cache)
    owner.load_page(owner.page,owner.index)

def refresh_details(owner,changed):
    _nl_opened = [None]
    if not changed or owner._screen_closed:return
    # A fresh Details screen drops every old identity's image token/decoder and
    # uses the ordinary constructor and canonical pipeline for the new choice.
    from .ui_screens_details import ContentDetailsScreen
    profile=owner.profile;client=owner.client;media_type=owner.media_type
    item=original(getattr(owner,'_portal_item',owner.item));session=owner.session
    # Session.close defers destruction/popCurrent until the next GUI turn.
    # Replace through that completion callback, retaining the parent's original
    # callback until the replacement Details screen eventually closes.
    parent_callback=getattr(owner,'callback',None)
    _nl_opened[0]=False
    def reopen(*_result):
        pass
        if _nl_opened[0]:return
        _nl_opened[0]=True
        session.openWithCallback(parent_callback,ContentDetailsScreen,profile,client,media_type,item)
    owner.callback=reopen
    owner.close()

