# -*- coding: utf-8 -*-
"""Small startup predicates and activity tracking; no UI/service imports at import time."""
from __future__ import absolute_import
import os
import json
import time
import sys
_SESSION=None
_LAST_INPUT=0.0
_BOUND=False
def set_session(session):
    global _SESSION
    _SESSION=session
def get_session():return _SESSION
def recording_needed(root='/etc/enigma2/ultrastalker'):
    return _nonempty(os.path.join(root,'recording_jobs.json'),'jobs')
def exports_needed(root='/etc/enigma2/ultrastalker'):
    return _nonempty(os.path.join(root,'bouquet_registry.json'),'exports')
def _nonempty(path,kind):
    try:
        try:info=os.stat(path)
        except OSError as exc:
            import errno
            return False if exc.errno==errno.ENOENT else True
        if info.st_size>8*1024*1024:return True
        with open(path,'rb') as handle:data=json.loads(handle.read().decode('utf-8'))
        if kind=='jobs':return bool(data) if isinstance(data,list) else True
        if not isinstance(data,dict):return True
        return any(key!='_meta' and isinstance(value,dict) and isinstance(value.get('channels'),dict) for key,value in data.items())
    except Exception:
        # An unreadable existing file must not suppress a scheduled recording/export.
        return True
def _input(key,flag):
    global _LAST_INPUT
    _LAST_INPUT=time.time()
    return 0
def bind_input():
    global _BOUND,_LAST_INPUT
    _LAST_INPUT=time.time()
    if _BOUND:return
    try:
        from enigma import eActionMap
        eActionMap.getInstance().bindAction('',-2147483647,_input)
        _BOUND=True
    except Exception:pass
def unbind_input():
    global _BOUND
    if not _BOUND:return
    try:
        from enigma import eActionMap
        eActionMap.getInstance().unbindAction('',_input)
    except Exception:pass
    _BOUND=False
def idle(session,seconds=20):
    if time.time()-_LAST_INPUT<float(seconds):return False
    dialog=getattr(session,'current_dialog',None)
    if dialog is None:return False
    if getattr(dialog,'_busy',False):return False
    # Keep optional network/maintenance out of Live, Details and Player sessions.
    return dialog.__class__.__name__ in ('PortalHomeScreen','PortalListScreen')
