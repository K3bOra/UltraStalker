# -*- coding: utf-8 -*-
"""Cleanup, hero visuals, layout readiness, movement and context overlay.

Methods moved verbatim out of ``PortalManagerPremiumScreen`` (ui_screens_portallist.py); behaviour is unchanged.
This module is imported by ui_screens_portallist.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, round, max, min
from .ui_screens_portallist import (
    _,
    _portal_category_backdrop,
    _portal_settings_text_width_px,
    cleanup_legacy_application_outputs,
    ePoint,
    eSize,
    fixed_settings_rows,
    fixed_value_color,
    gFont,
    getDesktop,
    os,
    parseColor,
)


class PortalManagerLayoutMixin(object):
    """Cleanup, hero visuals, layout readiness, movement and context overlay."""

    def _cleanup(self):
        try:
            callbacks = self["list"].onSelectionChanged
            if self._selection_changed in callbacks:
                callbacks.remove(self._selection_changed)
        except Exception as exc:
            optional_failure("ui.portal_manager_cleanup", exc)
        try:
            callbacks = self["context_list"].onSelectionChanged
            if self._context_selection_changed in callbacks:
                callbacks.remove(self._context_selection_changed)
        except Exception as exc:
            optional_failure("ui.portal_manager_context_cleanup", exc)

    def _hero_visuals(self):
        prepared = _portal_category_backdrop()
        ambient = ""
        return prepared, ambient

    def _layout_ready(self):
        try:cleanup_legacy_application_outputs()
        except Exception as exc:optional_failure("ui.fixed_adaptive_cleanup_portal_manager",exc)
        prepared, ambient = self._hero_visuals()
        try:
            if ambient:
                self["ambient_bg"].instance.setPixmapFromFile(ambient); self["ambient_bg"].show()
            else:
                self["ambient_bg"].hide()
        except Exception as exc:
            optional_failure("ui.portal_manager_ambient", exc)
        try:
            if prepared and os.path.isfile(prepared):
                self["hero_backdrop"].instance.setPixmapFromFile(prepared); self["hero_backdrop"].show()
        except Exception as exc:
            optional_failure("ui.portal_manager_backdrop", exc)
        try:
            chrome = fixed_settings_rows() or {}
            normal = str(chrome.get("normal") or "")
            selected = str(chrome.get("selected") or "")
            if normal and os.path.isfile(normal):
                self._row_asset = normal
            if selected and os.path.isfile(selected):
                self._row_selected_asset = selected
            self._value_color = int(chrome.get("value_color") or fixed_value_color(self._value_color))
            _accent=parseColor("#%06x" % (int(self._value_color)&0xFFFFFF))
            for _name,_size in (("context_subtitle",19),("status",19)):
                try:
                    _inst=self[_name].instance
                    if _inst is not None:
                        _inst.setForegroundColor(parseColor("#f0ece2") if _name=="portal_page" else _accent)
                        _inst.setFont(_ultra_rfont("Regular",_size))
                except Exception:pass
        except Exception as exc:
            optional_failure("ui.portal_manager_material", exc)
        try:
            if self["list"].instance is not None:
                self["list"].instance.setSelectionEnable(0)
                self["list"].instance.setTransparent(1)
                self["list"].instance.setScrollbarMode(2)
        except Exception as exc:
            optional_failure("ui.portal_manager_list_native", exc)
        # Repaint once so the dynamic Settings assets replace the safe fallback.
        if self._mode == "actions":
            self._render_actions(self._safe_index())
        elif self._mode == "multi":
            self._render_multi(self._safe_index())

    def _safe_index(self):
        try:
            return int(self["list"].getSelectedIndex() or 0)
        except Exception:
            return 0

    def _move(self, direction):
        if self._context_active and self._context_mode=="notice":
            self._context_notice_page(-1 if direction in ("up","left") else 1);return
        target = self["context_list"] if self._context_active else self["list"]
        try:
            if direction == "up": target.wrap_up()
            elif direction == "down": target.wrap_down()
            elif direction == "left": target.page_left()
            elif direction == "right": target.page_right()
        except Exception as exc:
            optional_failure("ui.portal_manager_nav", exc)

    def _context_geom(self,name,x,y,w,h):
        try:
            desktop=getDesktop(0).size();sx=float(desktop.width())/1920.0;sy=float(desktop.height())/1080.0
            inst=self[name].instance
            if inst is not None:
                inst.move(ePoint(int(round(x*sx)),int(round(y*sy))))
                inst.resize(eSize(max(1,int(round(w*sx))),max(1,int(round(h*sy)))))
        except Exception as exc:optional_failure("ui.portal_inline_context_geom",exc)

    def _context_hide_widgets(self):
        for name in ("context_panel","context_message","context_title","context_subtitle","context_list"):
            try:self[name].hide()
            except Exception as exc:optional_failure("ui.portal_inline_context_hide",exc)

    def _context_compact_episode_assets(self,card_w):
        card_w=max(300,min(560,((int(card_w)+19)//20)*20))
        base="settings_clean_r5390/row_%dx72"%card_w
        return asset(base+".png"),asset(base+"_selected.png")

    def _context_prepare_floating_choices(self,title,subtitle,labels,count,show_text=False):
        label_px=max([_portal_settings_text_width_px(x,22) for x in labels] or [220])
        card_w=max(300,min(560,((label_px+58+19)//20)*20));list_w=card_w+8;row_h=80
        visible=max(1,min(5,int(count or 1)));region_top,region_h=590,400
        list_h=visible*row_h;list_x=1850-list_w;list_y=region_top+max(0,(region_h-list_h)//2)
        if show_text:
            heading_w=min(740,max(420,_portal_settings_text_width_px(str(subtitle or title or ""),17)+24))
            heading_x=1850-heading_w
            self._context_geom("context_title",heading_x,max(600,list_y-92),heading_w,36)
            self._context_geom("context_subtitle",heading_x,max(638,list_y-54),heading_w,88)
            list_y=max(list_y,748)
        self._context_geom("context_list",list_x,list_y,list_w,list_h)
        self._context_row_asset,self._context_selected_asset=self._context_compact_episode_assets(card_w)
        try:
            if self["context_list"].instance is not None:
                self["context_list"].instance.setSelectionEnable(0);self["context_list"].instance.setTransparent(1)
                try:self["context_list"].instance.setScrollbarMode(2)
                except Exception:pass
            self["context_list"].row_width=list_w
            self["context_list"].set_layout(row_h,0,22,16,row_style="settings_dialog")
            inst = self["context_list"].instance
            if inst is not None:
                from .wqhd_layout import font_size
                self["context_list"].l.setItemHeight(font_size(row_h))
                if hasattr(inst, "setItemSpacing"):inst.setItemSpacing(ePoint(0, 0))
                if hasattr(inst, "setItemHeight"):inst.setItemHeight(font_size(row_h))
                inst.resize(eSize(inst.size().width(), visible * font_size(row_h) + 2))
        except Exception as exc:optional_failure("ui.portal_floating_context_layout",exc)

    def _context_open_choice(self,callback,title,choices,selection=0,subtitle="Choose an option",show_text=False):
        self._context_hide_widgets();self._context_active=True;self._context_mode="choice";self._context_callback=callback;self._context_choices=list(choices or [])
        labels=list(_(str(c[0])) if isinstance(c,(tuple,list)) and c else _(str(c)) for c in self._context_choices)
        title_text=_(str(title or "Settings"));subtitle_text=_(str(subtitle or ""))
        self._context_prepare_floating_choices(title_text,subtitle_text,labels,len(labels),show_text=show_text)
        self["context_title"].setText(title_text);self["context_subtitle"].setText(subtitle_text)
        selection=max(0,min(int(selection or 0),len(self._context_choices)-1)) if self._context_choices else 0
        rows=[]
        for i,c in enumerate(self._context_choices):
            details={"selected":i==selection,"row_asset":self._context_row_asset,"row_selected_asset":self._context_selected_asset,"meta":""}
            rows.append((labels[i],None,c,details))
        self["context_list"].set_icon_rows(rows)
        try:self["context_list"].moveToIndex(selection)
        except Exception as exc:optional_failure("ui.portal_inline_context_index",exc)
        self._context_last_idx=selection
        try:
            if self._context_selection_changed not in self["context_list"].onSelectionChanged:self["context_list"].onSelectionChanged.append(self._context_selection_changed)
        except Exception as exc:optional_failure("ui.portal_inline_context_hook",exc)
        self["context_list"].show()
        if show_text:
            self["context_title"].show();self["context_subtitle"].show()

    def _context_selection_changed(self):
        if not self._context_active or self._context_mode!="choice":return
        try:idx=self["context_list"].getSelectedIndex()
        except Exception:return
        old=getattr(self,"_context_last_idx",idx)
        if idx==old:return
        self._context_last_idx=idx
        for j in set((old,idx)):
            if 0<=j<len(self._context_choices):
                c=self._context_choices[j];label=_(str(c[0])) if isinstance(c,(tuple,list)) and c else _(str(c))
                details={"selected":j==idx,"row_asset":self._context_row_asset,"row_selected_asset":self._context_selected_asset,"meta":""}
                self["context_list"].update_icon_row(j,(label,None,c,details))
        try:self["context_list"].l.invalidate()
        except Exception as exc:optional_failure("ui.portal_inline_context_refresh",exc)

    def _context_accept(self):
        if self._context_mode=="notice":
            self._context_close();return
        try:idx=self["context_list"].getSelectedIndex()
        except Exception:idx=-1
        value=self._context_choices[idx] if 0<=idx<len(self._context_choices) else None
        self._context_close(value,False)

    def _context_close(self,value=None,cancelled=False):
        callback=self._context_callback
        self._context_active=False;self._context_callback=None;self._context_choices=[]
        self._context_hide_widgets()
        if callback is not None:
            try:callback(None if cancelled else value)
            except Exception as exc:optional_failure("ui.portal_inline_context_callback",exc)

from .wqhd_layout import responsive_font as _ultra_rfont, factors as _ultra_factors

def _ultra_osd_scale():
    return _ultra_factors()[1]
