# -*- coding: utf-8 -*-
"""The search itself and partial result draining.

Methods moved verbatim out of ``PortalGlobalSearchScreen`` (ui_screens_search.py); behaviour is unchanged.
This module is imported by ui_screens_search.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, max, min, us_casefold
from .core.runtime_log import breadcrumb
from .core.shared_executors import CACHE_IO_EXECUTOR
from .ui_screens_search import OrderedDict, SearchCancel, _, _SEARCH_CACHE_TTL, _SEARCH_RESULT_CACHE, _SEARCH_WORKERS, _SOURCE_HEALTH, _fast_client_search_detached, _hidden_category_ids, _mem34, _row_category_id, _source_health_rank, _title_contains_query, queue, threading, time

# A cancelled query can still hold a socket while a replacement query starts.
# Share the limits across both queries. Xtream decodes entire category payloads.
_SOURCE_LANES = {"portal": 2, "xtream": 1}
_SOURCE_SLOTS = {family: threading.BoundedSemaphore(size) for family, size in _SOURCE_LANES.items()}


class SearchQueryMixin(object):
    """The search itself and partial result draining."""

    def _search(self, term=None):
        self._history_hide()
        term = one_line(term or '', 60)
        if not term:
            return None
        if getattr(self, '_busy', False) or getattr(self, '_active_async_handle', None) is not None:
            try:
                self._cancel_active_async()
            except Exception:
                pass
        self._cancel_xtream_warm()
        self._search_generation = int(getattr(self, '_search_generation', 0) or 0) + 1
        generation = self._search_generation
        self.query = term
        try:
            CACHE_IO_EXECUTOR.submit(_save_recent_search, term)
        except Exception as exc:
            optional_failure("ui.search_history_queue",exc)
        cfg = load_settings()
        self._search_settings = dict(cfg)
        self.results = []
        self._search_bucket_rows = {'vod': [], 'series': []}
        self.index = 0
        self._search_gateway = True
        self._search_gateway_index = 0
        self._search_result_type = None
        self._advance_poster_generation()
        self._render_art_start = None
        self._render_signature = ()
        self._search_seen = set()
        self._search_groups = OrderedDict()
        self._search_errors = []
        self._search_incomplete = False
        self._search_portal_count = 0
        self._search_done_sources = 0
        self._search_last_shown_done = -1
        self._search_running = True
        self._search_source_mix = {'portal': 0, 'xtream': 0}
        self._set_source_mix_labels()
        try:
            while True:
                self._search_partial_jobs.get_nowait()
        except Exception:
            pass
        self['search_query'].setText(_('Search: %s') % term)
        self._set_search_status(_('Searching...'), '#b0bec8')
        self._render()
        multi = bool(cfg.get('multi_portal_search', True))
        limit = max(20, min(100, int(cfg.get('content_page_size', 50) or 50)))
        search_profile_base = dict(self.profile or {})
        search_settings = dict(self._search_settings or {})
        partial_queue = self._search_partial_jobs

        def profile_key(profile):
            return (str((profile or {}).get('portal') or '').rstrip('/').lower(), str((profile or {}).get('mac') or '').upper())

        hidden_sig = repr((cfg.get("hidden_categories_by_profile"), cfg.get("hidden_categories")))
        term_key = us_casefold(term)

        def work(handle):
            profiles = load_profiles() if multi else [search_profile_base]
            current_key = profile_key(search_profile_base)
            profiles = list((p for p in profiles if isinstance(p, dict)))
            if not profiles:
                profiles = [search_profile_base]

            source_keys = tuple(sorted(profile_key(p) for p in profiles))
            cache_key = (term_key, bool(multi), limit, source_keys, hidden_sig)
            hit = _SEARCH_RESULT_CACHE.get(cache_key)
            if hit is not None and time.time()-hit[0] < _SEARCH_CACHE_TTL:
                for offset in range(0,len(hit[1]),48):
                    if handle.cancelled():break
                    rows=[dict(row) for row in hit[1][offset:offset+48]]
                    partial_queue.put((generation, rows, None, hit[3], hit[4] if not offset else None))
                return ([], hit[3], hit[4], False, {"settled":hit[3],"limited":0}, None, [])

            def source_priority(p):
                if profile_key(p) == current_key:
                    return (0, 0)
                if str((p or {}).get('source_type') or 'stalker').lower() == 'm3u':
                    return (1, 0)
                return (2, 0)
            _now_h = time.time()
            profiles = sorted(profiles, key=lambda p: (source_priority(p), _source_health_rank(profile_key(p), _now_h)))
            source_mix = {'portal': sum((1 for p in profiles if str((p or {}).get('source_type') or 'stalker').lower() != 'm3u')), 'xtream': sum((1 for p in profiles if str((p or {}).get('source_type') or 'stalker').lower() == 'm3u'))}
            partial_queue.put((generation, [], None, len(profiles), source_mix))
            all_rows = []
            errors = []
            source_count = len(profiles)
            completed_sources = [0]
            incomplete_sources = [False]
            limited_sources = [0]
            local_cancel = threading.Event()
            active_clients = set()
            active_clients_lock = threading.RLock()

            def stop_local_workers():
                local_cancel.set()
                try:
                    with active_clients_lock:
                        clients = list(active_clients)
                except Exception:
                    clients = []
                for owned_client in clients:
                    try:
                        owned_client.close()
                    except Exception:
                        pass
            try:
                handle.add_cancel_callback(local_cancel.set)
            except Exception:
                pass

            def search_profile(p, pos, budget=5.0, pages=16):
                if handle.cancelled() or local_cancel.is_set():
                    return ([], None, False)
                cl = None
                source_cancel = SearchCancel(local_cancel, budget)
                source_timer = None
                hidden_vod = _hidden_category_ids(search_settings, p, 'vod')
                hidden_series = _hidden_category_ids(search_settings, p, 'series')
                source_type = str((p or {}).get('source_type') or 'stalker').lower()
                default_name = ('Xtream %d' if source_type == 'm3u' else 'Server %d') % (pos + 1)
                portal_name = str(p.get('name') or default_name)

                def tag_rows(rows):
                    tagged = []
                    for row in rows or []:
                        if not isinstance(row, dict) or not _title_contains_query(row, term):
                            continue
                        item = dict(row)
                        media = str(item.get('_search_media_type') or row.get('_search_media_type') or 'vod').lower()
                        cid = _row_category_id(item)
                        hidden = hidden_series if media == 'series' else hidden_vod
                        if cid and cid in hidden:
                            continue
                        item['_search_profile'] = dict(p)
                        item['_search_portal_name'] = portal_name
                        item['_search_source_type'] = 'xtream' if source_type == 'm3u' else 'portal'
                        tagged.append(item)
                    return tagged

                published = set()
                def item_key(item):
                    identity = (item.get("id") or item.get("movie_id") or item.get("series_id")
                                or item.get("cmd") or item.get("url") or item.get("name") or item.get("title"))
                    return (item.get("_search_media_type") or "vod", str(identity))

                def publish_partial(rows):
                    if handle.cancelled() or source_cancel.is_set() or generation != getattr(self, '_search_generation', generation):
                        return
                    tagged = tag_rows(rows)
                    if tagged:
                        published.update(item_key(item) for item in tagged)
                        partial_queue.put((generation, tagged, None, source_count))
                _t_start = time.monotonic()
                _failed = False
                try:
                    cl = _client_from_profile(p, timeout=min(4, int(cfg.get('timeout', 10) or 10)))
                    with active_clients_lock:
                        active_clients.add(cl)

                    def expire_source():
                        source_cancel.set()
                        try:
                            cl.close()
                        except Exception:
                            pass
                    source_timer = threading.Timer(max(0.01, source_cancel.deadline - time.monotonic()), expire_source)
                    source_timer.daemon = True
                    source_timer.start()
                    rows = _fast_client_search_detached(cl, term, limit, source_cancel, search_settings, time_budget=budget, max_pages=pages, on_partial=publish_partial)
                    tagged = tag_rows(rows)
                    remaining = [item for item in tagged if item_key(item) not in published]
                    if remaining:
                        partial_queue.put((generation, remaining, None, source_count))
                    return tagged, None, source_cancel.is_set() or getattr(cl,"_last_search_complete",None) is False
                except Exception as exc:
                    if local_cancel.is_set() or handle.cancelled():
                        _t_start = None
                        return ([], None, False)
                    _failed = True
                    return ([], '%s: %s' % (p.get('name') or p.get('portal') or default_name, exc), True)
                finally:
                    if source_timer is not None:
                        source_timer.cancel()
                    if _t_start is not None:
                        try:
                            _SOURCE_HEALTH[profile_key(p)] = (time.time(), time.monotonic() - _t_start, _failed)
                        except Exception:
                            pass
                    if cl is not None:
                        try:
                            with active_clients_lock:
                                active_clients.discard(cl)
                        except Exception:
                            pass
                        try:
                            cl.close()
                        except Exception:
                            pass
            jobs = {family: queue.Queue() for family in _SOURCE_LANES}
            for pos, profile in enumerate(profiles):
                family = "xtream" if str(profile.get("source_type") or "").lower() == "m3u" else "portal"
                jobs[family].put((pos, profile))
            result_lock = threading.RLock()
            # Retain the previous overall deadline. Sources left queued at
            # that deadline are counted as incomplete.
            waves = (source_count + _SEARCH_WORKERS - 1) // _SEARCH_WORKERS
            deadline_seconds = max(55.0, 12.0 + waves * (43.0 if source_mix["xtream"] else 33.0))
            started = time.monotonic()
            deadline = started + deadline_seconds
            breadcrumb("search_scan_start", portal=source_mix["portal"], xtream=source_mix["xtream"])

            def running():
                return not local_cancel.is_set() and not handle.cancelled() and time.monotonic() < deadline

            def worker(family):
                try:
                    _worker_loop(family)
                finally:
                    try:
                        from .repositories.database import DB
                        DB.close_thread_connection()
                    except Exception:
                        pass

            def _worker_loop(family):
                slots = _SOURCE_SLOTS[family]
                while running():
                    try:
                        pos, profile = jobs[family].get_nowait()
                    except queue.Empty:
                        return
                    while running():
                        if slots.acquire(False):
                            break
                        local_cancel.wait(0.05)
                    else:
                        return
                    try:
                        if not running():
                            return
                        is_current = profile_key(profile) == current_key
                        budget = 40.0 if family == "xtream" else (30.0 if is_current else 18.0)
                        pages = 80 if family == "xtream" else (24 if is_current else 16)
                        tagged, err, incomplete = search_profile(profile, pos, budget=budget, pages=pages)
                    finally:
                        slots.release()
                    if not running():
                        return
                    with result_lock:
                        completed_sources[0] += 1
                        partial_queue.put((generation, [], None, source_count, None, completed_sources[0]))
                        incomplete_sources[0] = incomplete_sources[0] or incomplete
                        if incomplete:
                            limited_sources[0] += 1
                        if err:
                            errors.append(err)
                        if tagged:
                            all_rows.extend(tagged)
            threads = []
            for family, limit_workers in _SOURCE_LANES.items():
                for idx in range(min(limit_workers, source_mix[family])):
                    thread = threading.Thread(target=worker, args=(family,),
                        name="ultrastalker-search-%s-%d" % (family, idx), daemon=True)
                    thread.start()
                    threads.append(thread)

            while running():
                if not any(t.is_alive() for t in threads):
                    break
                local_cancel.wait(0.05)
            stop_local_workers()
            grace = time.monotonic() + 1.5
            for thread in threads:
                remain = grace - time.monotonic()
                if remain <= 0:
                    break
                thread.join(remain)
            try:
                alive = sum((1 for thread in threads if thread.is_alive()))
                _mem34('search_workers_settled', source_threads_alive=alive, source_threads_total=len(threads), active_clients=len(active_clients))
            except Exception:
                pass
            breadcrumb("search_scan_stop", settled=completed_sources[0], sources=source_count,
                       cancelled=handle.cancelled(), ms=int((time.monotonic()-started)*1000))
            with result_lock:
                incomplete = incomplete_sources[0] or completed_sources[0] < source_count or bool(errors)
                outcome = {'settled': completed_sources[0], 'limited': limited_sources[0] + max(0, source_count - completed_sources[0])}
                cache_rows = [dict(row) for row in all_rows] if not incomplete else []
                return list(errors), source_count, source_mix, incomplete, outcome, cache_key, cache_rows

        def ok(result):
            if generation == getattr(self,"_search_generation",generation):
                # Apply Done after the preceding result batches reach the screen.
                partial_queue.put((generation, [], None, 0, None, 0, result))

        def fail(exc):
            if generation != getattr(self, '_search_generation', generation):
                return None
            self._search_running = False
            self._set_search_status(_friendly_error(exc), '#ff8a80')
        self._run_async(work, ok, fail)

    def _finish_search(self, result):
        errors, count, mix, incomplete, outcome, cache_key, cache_rows = result
        self._search_running = False
        self._search_incomplete = bool(incomplete)
        self._search_done_sources = outcome["settled"]
        self._search_limited_sources = outcome["limited"]
        self._search_portal_count = count
        self._search_source_mix = dict(mix)
        self._search_errors = list(dict.fromkeys(self._search_errors + errors))
        if cache_rows:
            _SEARCH_RESULT_CACHE[cache_key] = (time.time(), cache_rows, [], count, dict(mix), False)
            _SEARCH_RESULT_CACHE.move_to_end(cache_key)
            while len(_SEARCH_RESULT_CACHE) > 12:
                _SEARCH_RESULT_CACHE.popitem(last=False)
        final_text = _("Done") + "  •  " + self._search_status_text(False)
        if self._search_limited_sources:
            final_text += "  •  %s: %d" % (_("Incomplete sources"),self._search_limited_sources)
        self._set_search_status(final_text, "#00E676")
        _mem34("search_finished",results=len(self.results),ready_posters=len(self._poster_ready_cache),portals=count)

    def _drain_search_partials(self):
        changed = False
        mix_changed = False
        deadline = time.monotonic() + 0.008
        # Limit each GUI tick even when multiple sources deliver at once.
        for unused in range(48):
            try:
                job = self._search_partial_jobs.get_nowait()
            except queue.Empty:
                break
            generation, rows, error, count = job[:4]
            if generation == self._search_generation:
                if len(job)==7:
                    self._finish_search(job[6])
                    mix_changed = True
                    break
                self._search_portal_count = max(self._search_portal_count, int(count or 0))
                if len(job)==6:
                    self._search_done_sources = max(self._search_done_sources, int(job[5] or 0))
                if len(job)>=5 and isinstance(job[4],dict):
                    self._search_source_mix = dict(job[4])
                    mix_changed = True
                if error:
                    self._search_errors.append(error)
                if self._merge_search_rows(rows):
                    changed = True
            if time.monotonic() >= deadline:
                break
        if changed:
            self._render()
        if changed or mix_changed:
            self._set_source_mix_labels()
        if self._search_running and (changed or mix_changed or self._search_done_sources != self._search_last_shown_done):
            self._search_last_shown_done = self._search_done_sources
            self._set_search_status(self._search_status_text(True), "#b0bec8")
