# -*- coding: utf-8 -*-
"""Backdrop Grid 2: exact R208 seven-poster presentation on clean behavior."""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, round, max
from .wqhd_layout import responsive_font as _ultra_rfont, factors as _ultra_factors, xy as _bg_xy, wh as _bg_wh

def _ultra_osd_scale():
    return _ultra_factors()[1]
try:
    from enigma import ePoint, eSize, gFont
except Exception:  # pragma: no cover
    ePoint = eSize = gFont = None

from . import ui_backdrop_grid as _bg
from .ui_backdrop_grid import PremiumBackdropGridScreen

BACKDROP_GRID2_SKIN = ""


def configure_backdrop_grid2(**deps):
    globals().update(deps)
    if "BACKDROP_GRID2_SKIN" in deps:
        PremiumBackdropGrid2Screen.skin = _bg._backdrop_menu_scrim_skin(deps["BACKDROP_GRID2_SKIN"])


class PremiumBackdropGrid2Screen(PremiumBackdropGridScreen):
    """7-card 232x349 Backdrop Grid V2."""
    GRID_VIEW_TYPE = "backdrop2"
    skin = BACKDROP_GRID2_SKIN
    columns = 7
    page_size = 7
    image_size = (232, 349)
    placeholder = "grid_placeholder_movie_921.png"
    selection_asset = "poster_cursor_bd2_232x349.png"
    card_positions = [(55 + (263 * i), 651) for i in range(7)]

    def _bd_frame_asset(self):
        return _bg.asset("poster_frame_neutral_bd2_232x349.png")

    def _bd_selector_dimensions(self):
        return (232, 349)

    def _bg_fit_overview(self, text):
        try:
            inst=self["bd_overview"].instance
            value=str(text or "")
            try:
                from .ui_smooth_text import scroller as _smooth_scroller
                _scr=_smooth_scroller(self,"bd_overview","auto")
            except Exception:_scr=None
            if _scr is not None and not value.strip():_scr.stop()
            if inst is None:return
            if getattr(self,"_bg2_overview_fit_sig",None)==value:return
            self._bg2_overview_fit_sig=value
            if len(value)>520:start=22
            elif len(value)>420:start=23
            elif len(value)>320:start=24
            elif len(value)>220:start=25
            elif len(value)>140:start=26
            else:start=27
            comfort=22
            limit_h=int(round(198 * _ultra_osd_scale()))
            if _scr is not None and value.strip():
                fits=False
                for candidate in range(max(start,comfort),comfort-1,-1):
                    inst.setFont(_ultra_rfont("Regular",candidate))
                    try:
                        if int(inst.calculateSize().height())<=limit_h:fits=True;break
                    except Exception:fits=True;break
                if not fits and _scr.start(value,comfort):return
                _scr.stop()
                if len(value)>650:
                    self["bd_overview"].setText(value[:650])
            for candidate in range(start,20,-1):
                inst.setFont(_ultra_rfont("Regular",candidate))
                try:
                    if int(inst.calculateSize().height())<=limit_h:break
                except Exception:break
            try:self["bd_overview"].show()
            except Exception:pass
        except Exception:pass

    def _bd_force_geometry(self):
        if ePoint is None or eSize is None:return
        try:
            for name,x,y,w,h in (("cin_backdrop",0,0,1920,1080),("status",650,615,620,28)):
                inst=self[name].instance
                if inst is not None:inst.move(ePoint(*_bg_xy(x,y)));inst.resize(eSize(*_bg_wh(w,h)))
            for name,x,y,w,h in (("title_logo",55,60,432,210),("bd_title_fallback",55,86,500,180)):
                inst=self[name].instance
                if inst is not None:inst.move(ePoint(*_bg_xy(x,y)));inst.resize(eSize(*_bg_wh(w,h)))
            hud=(
                ("bd_year_bg",55,295,130,50),("bd_year",100,302,72,36),
                ("bd_quality_bg",198,295,150,50),("bd_quality_logo",212,303,122,34),("bd_quality",214,302,118,36),
                ("bd_runtime_bg",361,295,150,50),("bd_runtime",411,300,88,40),
                ("bd_genre_bg",55,355,440,50),("bd_age_rating",72,360,92,40),("bd_genre",168,362,310,36),
                ("bd_overview_bg",55,415,456,232),("bd_overview",76,427,414,206),
            )
            for name,x,y,w,h in hud:
                inst=self[name].instance
                if inst is not None:inst.move(ePoint(*_bg_xy(x,y)));inst.resize(eSize(*_bg_wh(w,h)))
            for pos in range(self.page_size):
                x=55+(263*pos)
                for name,gx,gy,gw,gh in (("art%d"%pos,x,651,232,349),("card_chrome%d"%pos,x,651,232,349),("item_title%d"%pos,2000,0,1,1),("item_meta%d"%pos,2000,0,1,1)):
                    inst=self[name].instance
                    if inst is not None:inst.move(ePoint(*_bg_xy(gx,gy)));inst.resize(eSize(*_bg_wh(gw,gh)))
            for name in ("selection","selection_adaptive"):
                inst=self[name].instance
                if inst is not None:inst.move(ePoint(*_bg_xy(55,651)));inst.resize(eSize(*_bg_wh(232,349)))
            self._scaled_card_positions=[(int((55+263*i)*self._grid_sx),int(651*self._grid_sy)) for i in range(self.page_size)]
        except Exception as exc:_bg.optional_failure("backdrop_grid2.r208_geometry",exc)
