# -*- coding: utf-8 -*-
"""Shared Ultra Stalker catalogue title cleaner used by Stalker/TMDB and M3U/Xtream."""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str, max, us_casefold
re = _us_env.re
import unicodedata

_TECH = {
    "4k","8k","uhd","fhd","hd","2160p","1080p","720p","3840p","4320p",
    "hdr","hdr10","dolby","atmos","hevc","h265","h264","avc","top","vip",
    "subs","sub","dub","dubs","raw","bluray","bdrip","brrip","hdrip","webrip","webdl","x264","x265","multi","audio","vod","movie","movies","series","tv",
    "ar","en","tr","s","do","fr","de","es","it","pl","nl","ru","pt","br","us","uk","eg","ksa","uae","der","ger","deu","lat","ara","eng","tur","kor","jpn","ind","arabic","english","turkish"," مترجم","مدبلج"
}

_STOP_HEADS={"the","a","an","of","in","on","at","to","and","for","le","la","les","el","al","de","du","der","die","das","il","un","une","los","las","mr","mrs","dr","st"}
_BR_PAIRS={")":"(","]":"[","}":"{"}

def _strip_unbalanced(text):
    """Strip edge punctuation but keep brackets that are properly paired."""
    t=str(text or "").strip(" -_|:.")
    for _ in range(8):
        old=t
        if t and t[-1] in "([{":t=t[:-1].rstrip(" -_|:.")
        if t and t[0] in ")]}":t=t[1:].lstrip(" -_|:.")
        if t and t[-1] in _BR_PAIRS and t.count(t[-1])>t.count(_BR_PAIRS[t[-1]]):t=t[:-1].rstrip(" -_|:.")
        if t and t[0] in "([{":
            closer={"(":")","[":"]","{":"}"}[t[0]]
            if t.count(t[0])>t.count(closer):t=t[1:].lstrip(" -_|:.")
        if t==old:break
    return t

def _normalize_unicode_digits(value):
    text=str(value or "")
    out=[]
    for ch in text:
        try:
            if unicodedata.category(ch)=="Nd":
                out.append(str(unicodedata.digit(ch)))
            else:
                out.append(ch)
        except Exception:
            out.append(ch)
    return "".join(out)

_ROUTE_LANG=r"(?:DE|DER|GER|DEU|FR|ES|IT|TR|PL|NL|RU|PT|BR|AR|ARA|EN|ENG|UK|US|EG|KSA|SE|NO|DK|FI|GR|RO|HU|CZ|IN)"
_ROUTE_LANG_STRICT=r"(?:DE|DER|GER|DEU|FR|ES|TR|PL|NL|RU|PT|BR|AR|ARA|EN|ENG|SE|DK|FI|GR|RO|HU|CZ)"
_ROUTE_TECH=r"(?:DV|HDR(?:10)?|PLUS|4K|8K|UHD|FHD|HD|SD|VIP|TOP|3D|ATMOS|HEVC|MULTI|SUBS?|DUBS?|RAW|NF|AMZ|AMZN|DSNP|ATVP|HMAX|PMTP|MOVIES?|SERIES|VOD|WEB|DL)"
_ROUTE_PREFIX_RE=re.compile(r"^\s*"+_ROUTE_LANG+r"(?:[\s\-_/+]+"+_ROUTE_TECH+r")+\+?\s*[-_/|:]+\s+(?=\S)",re.I)
_ROUTE_PREFIX_RE2=re.compile(r"^\s*"+_ROUTE_LANG+r"(?:[\s\-_/+]+"+_ROUTE_TECH+r")+\+?\s+-\s+(?=\S)",re.I)


_ROUTE_HEAD_RE=re.compile(r"^(?:"+_ROUTE_LANG+r"|"+_ROUTE_TECH+r"|AS|D|A|PM|DE|SD)$",re.I)


def _known_route_head(prefix):
    """First token of a 'XX-YY - Title' prefix must be a routing token, so
    all-caps titles such as SPIDER-MAN - HOMECOMING keep their name."""
    try:return bool(_ROUTE_HEAD_RE.match(re.split(r"[-_]",str(prefix))[0]))
    except Exception:return False


def _strip_route_prefix(text):
    """Remove portal routing prefixes such as 'DE-DV- /PLUS - ' (language + known
    technical tokens only, so real titles like X-Men / One-Punch Man stay intact)."""
    try:
        for rx in (_ROUTE_PREFIX_RE,_ROUTE_PREFIX_RE2):
            new=rx.sub("",text,count=1)
            if new.strip() and new!=text:return new
    except Exception:pass
    return text


def _clean_title_uncached(value):
    text=_strip_route_prefix(_normalize_unicode_digits(value).strip())
    # Strip purely decorative edge symbols/emoji that portals commonly prepend
    # or append to VOD/Series names.  Internal punctuation remains untouched.
    text=re.sub(r"^[\s\u2600-\u27ff\u2b00-\u2bff\U0001F000-\U0001FAFF★☆✦✧◆◇●○■□▶▷►]+", "", text)
    text=re.sub(r"[\s\u2600-\u27ff\u2b00-\u2bff\U0001F000-\U0001FAFF★☆✦✧◆◇●○■□▶▷►]+$", "", text)
    # Common routing/service labels wrapped in braces/brackets are not titles.
    text=re.sub(r"^[\[{(]\s*(?:4K|8K|UHD|FHD|HD|AR|EN|ARA|ENG|VIP|TOP|NEW|MOVIE|MOVIES|SERIES|TV)(?:[-_ /|]+(?:4K|8K|UHD|FHD|HD|AR|EN|ARA|ENG|VIP|TOP|NEW|SUBS?|DUBS?))*\s*[\]})]\s*[-:|]*\s*", "", text, flags=re.I)
    m=re.match(r"^([A-Z0-9]{2,6}(?:[-_][A-Z0-9]{1,6})*)\s+-\s+(.+)$",text)
    if m and ("-" in m.group(1) or "_" in m.group(1) or re.search(r"[\u0600-\u06ff]",m.group(2))) and _known_route_head(m.group(1)):
        text=m.group(2).strip()
    text=re.sub(r"\[(?:[^\]]*?(?:4K|8K|UHD|FHD|HD|2160P|1080P|720P|HDR|DOLBY|SUB|DUB)[^\]]*?)\]"," ",text,flags=re.I)
    text=re.sub(r"\((?:US|USA|UK|GB|EG|EGY|KSA|SA|UAE|AE|KR|KOR|TR|TUR|JP|JPN|CN|CHN|IN|IND|AR|EN|SUBS?|DUB|DUBBED|مترجم|مدبلج)\)"," ",text,flags=re.I)
    text=re.sub(r"^\s*[\[(]\s*(?:قريب(?:ا[\u064b-\u0652]?|اً)?|حصري(?:ا[\u064b-\u0652]?|اً)?|جديد|قادم|يعرض\s+الآن|soon|coming\s+soon|new)\s*[\])]+\s*"," ",text,flags=re.I)
    text=re.sub(r"^\s*(?:قريب(?:ا[\u064b-\u0652]?|اً)?|حصري(?:ا[\u064b-\u0652]?|اً)?|جديد|قادم|يعرض\s+الآن)\s*[-:|]+\s*"," ",text,flags=re.I)
    text=re.sub(r"[\[(]\s*(?:قريب(?:ا[\u064b-\u0652]?|اً)?|حصري(?:ا[\u064b-\u0652]?|اً)?|جديد|قادم|يعرض\s+الآن|soon|coming\s+soon|new)\s*[\])]"," ",text,flags=re.I)
    text=re.sub(r"\((?:19|20)\d{2}\)"," ",text)
    parts=re.split(r"\s[-|:]\s",text)
    while len(parts)>1:
        first=us_casefold(re.sub(r"[^\w+]+"," ",parts[0],flags=re.UNICODE).strip())
        toks=list(t for t in first.split() if t)
        known=sum(1 for t in toks if t in _TECH or re.match(r"^(?:4k|8k|\d{3,4}p)$",t))
        if len(toks)>=2 and known>=max(2,len(toks)-1):
            parts.pop(0)
        else:
            break
    text=" - ".join(parts)
    text=re.sub(r"(?i)\s+(?:19|20)\d{2}(?=\s+(?:4K|8K|UHD|FHD|HD|2160P|1080P|720P|HDR|DV|DOVI|WEB|BLU))"," ",text)
    text=re.sub(r"\b(?:4K|8K|UHD|FHD|HD|2160P|1080P|720P|3840P|4320P|HDR(?:10)?|HEVC|X264|X265|BLU[ ._-]?RAY|BDRIP|BRRIP|HDRIP|WEB[ ._-]?(?:DL|RIP)|MULTI[ ._-]?AUDIO|H\.?(?:264|265)|AR[-_ ]?SUBS?|DUBBED)\b"," ",text,flags=re.I)
    # Words that are also real title words (Raw Deal, Sub Zero, Dolby Theatre)
    # are release junk only at the very end of the label, never inside it.
    for _ in range(3):
        _tail=re.sub(r"(?i)[\s._-]+(?:SUBS?|DUBS?|RAW|ATMOS|DOLBY(?:[ ._-]?VISION)?)\s*$","",text)
        if _tail.strip(" -_|:.") and _tail!=text and len(_tail.split())>=1 and us_casefold(_tail.strip()) not in _STOP_HEADS:text=_tail
        else:break
    text=re.sub(r"^(?:#+\s*)?(?:AR|EN|BE|UK|US|EG|KSA|TOP|VIP|MOVIES?|SERIES|TV)(?:[-_ ](?:SUBS?|DUBS?|RAW|4K|8K|UHD|HD|TOP))*\s*[:|\-]+\s*","",text,flags=re.I)
    # Strip residual provider/routing prefixes only when they are KNOWN technical tokens.
    # Never treat an arbitrary short title token as routing metadata: e.g. "X-Men" must stay "X-Men".
    _route=r"(?:DER|GER|DEU|DE|ENG|ARA|LAT|AR|EN|TR|DO|FR|ES|IT|PL|NL|RU|PT|BR|US|UK|EG|KSA|UAE|GR|RO|HU|CZ|FI|DK|SE|NF|AMZN?|DSNP|ATVP|HMAX|DV|SUBS?|DUBS?|RAW|4K|8K|UHD|FHD|HD|VIP|TOP)"
    text=re.sub(r"^(?:"+_route+r")(?:[-_/](?:"+_route+r")){0,4}\s*(?:[|┃:/-]+)\s*(?=.+)","",text,flags=re.I)
    text=re.sub(r"\s*(?:[|┃/]+)\s*(?:DER|GER|DEU|ENG|ARA|LAT|SUBS?|DUBS?|RAW|4K|8K|UHD|FHD|HD)(?:\s*(?:[|┃/]+)\s*(?:DER|GER|DEU|ENG|ARA|LAT|SUBS?|DUBS?|RAW|4K|8K|UHD|FHD|HD))*\s*$","",text,flags=re.I)
    # Broken/incomplete country suffixes are common in Stalker names, e.g. "Dark (DE".
    # They are catalogue routing metadata, not part of the visible title.
    text=re.sub(r"\s*[\[(]\s*(?:[A-Z]{2,3}|USA|UAE|KSA)\s*[\])]?$", " ", text, flags=re.I)
    # Also remove trailing standalone provider/routing tokens after a slash/pipe.
    text=re.sub(r"\s+(?:[|┃/]+)\s*(?=[A-Z0-9_-]*[A-Z])[A-Z0-9]{2,6}(?:[-_][A-Z0-9]{1,6}){0,4}\s*$", " ", text)
    # Final pass for provider route prefixes such as "4K-AR -", "AR-AS-D |",
    # "VIP_MOVIES:" while preserving real hyphenated film names.
    text=re.sub(r"^(?:(?:4K|8K|UHD|FHD|HD|AR|EN|ARA|ENG|VIP|TOP|MOVIES?|SERIES|TV|SUBS?|DUBS?)(?:[-_ /]+(?:4K|8K|UHD|FHD|HD|AR|EN|ARA|ENG|VIP|TOP|MOVIES?|SERIES|TV|SUBS?|DUBS?))*)\s*(?:[-:|┃]+)\s*", "", text, flags=re.I)
    text=re.sub(r"[\(\[\{]\s*[\)\]\}]"," ",text)
    text=re.sub(r"\s+"," ",text).strip(" -_|:.")
    # R5.184: display tails that are catalogue noise, never part of the name.
    for _ in range(3):
        _old=text
        _t=re.sub(r"(?i)\s*[-|┃]+\s*"+_ROUTE_LANG_STRICT+r"\s*$","",text)
        _t=re.sub(r"\s+[-|┃]\s+(?:19|20)\d{2}\s*$","",_t)
        _t=re.sub(r"(?i)\s*[-|┃]\s*(?:DV|DOVI|HDR(?:10)?\+?)\s*$","",_t)
        _t=re.sub(r"(?i)(?<=\w)\s+(?:DV|DOVI)(?:\s+HDR(?:10)?\+?)?\s*$","",_t) if len(_t.split())>2 else _t
        _t=re.sub(r"\s+(?:مترجم|مدبلج|مترجمة|مدبلجة)\s*$","",_t)
        if _t.strip(" -_|:.") and _t!=text:text=_t.strip(" -_|:.")
        if text==_old:break
    text=_strip_unbalanced(text)
    return text or str(value or "").strip()


def tmdb_search_title(value):
    out=_tmdb_search_title_core(value)
    return _prefer_wrapped_title(value,out)


def _tmdb_search_title_core(value):
    """Aggressive SEARCH-ONLY title cleaner.

    IMPORTANT: this function must never be used as a catalogue/cache identity.
    The provider's raw label stays untouched for UI and persistent artwork keys.
    Only TMDB/Fanart matching gets this normalized title.
    """
    text=_strip_route_prefix(_normalize_unicode_digits(protect_title_wrappers(value)).strip())
    _g=re.match(r"^([A-Z0-9]{2,6}(?:[-_][A-Z0-9]{1,6})*)\s+-\s+(.+)$",text)
    if _g and ("-" in _g.group(1) or "_" in _g.group(1)) and _known_route_head(_g.group(1)):
        text=_g.group(2).strip()
    text=re.sub(r"(?i)\s+AR[-_ ]?SUBS?\s*$","",text)
    # Trailing provider language tag without a separator ("Die Arena DE"): search-only.
    _lt=re.match(r"^(.{4,}?)\s+(?:DE|TR|FR|ES|IT|AR|PL|NL|PT|RU|EN|GR|RO)$",text)
    if _lt:text=_lt.group(1).strip()
    if not text:
        return ""
    # Decorative edge glyphs / emoji / bullets.
    text=re.sub(r"^[\s\u2600-\u27ff\u2b00-\u2bff\U0001F000-\U0001FAFF★☆✦✧◆◇●○■□▶▷►]+", "", text)
    text=re.sub(r"[\s\u2600-\u27ff\u2b00-\u2bff\U0001F000-\U0001FAFF★☆✦✧◆◇●○■□▶▷►]+$", "", text)
    # Leading provider/platform route labels. Keep this search-only and require a
    # separator so real titles such as X-Men, Se7en or F1 are never damaged.
    edge=r"(?:AMZ|AMZN|NF|NETFLIX|AS|A\+|D\+|DSNP|DISNEY\+|APTV|APPLETV\+|HBO|MAX|HMAX|PM|PRIME|VIP|TOP|VOD|MOVIES?|SERIES|TV|4K|8K|UHD|FHD|HD|AR|ARA|EN|ENG|TR|FR|DE|ES|IT|SUBS?|DUBS?|RAW)"
    # Bracketed tags on either edge.
    text=re.sub(r"^\s*[\[{(]\s*"+edge+r"(?:\s*[-_/|+]\s*"+edge+r")*\s*[\]})]\s*[-:|┃]*\s*", "", text, flags=re.I)
    text=re.sub(r"\s*[-:|┃]*\s*[\[{(]\s*"+edge+r"(?:\s*[-_/|+]\s*"+edge+r")*\s*[\]})]\s*$", "", text, flags=re.I)
    # Plain edge tags: "NF - Title", "D+ | Title", "Title | AMZ".
    for _ in range(3):
        old=text
        text=re.sub(r"^\s*"+edge+r"(?:\s*[-_/+]\s*"+edge+r"){0,4}\s*(?:[-:|┃]+)\s*(?=\S)", "", text, flags=re.I)
        text=re.sub(r"\s*(?:[-:|┃]+)\s*"+edge+r"(?:\s*[-_/+]\s*"+edge+r"){0,4}\s*$", "", text, flags=re.I)
        if text==old: break
    text=re.sub(r"\s*\b\d{1,2}[./-]\d{1,2}[./-](?:19|20)\d{2}\b", " ", text)
    # Year/quality/language decorations at the edges are search noise.
    text=re.sub(r"\s*[\[(]\s*(?:19|20)\d{2}\s*[\])]\s*$", " ", text)
    text=re.sub(r"\s*(?:[-|┃:]+)\s*(?:19|20)\d{2}\s*$", " ", text)
    text=re.sub(r"\s*(?:[-|┃:/]+)\s*(?:4K|8K|UHD|FHD|HD|2160P|1080P|720P|HDR(?:10)?|DOLBY|ATMOS|HEVC|H\.?26[45]|X26[45]|WEB[ ._-]?(?:DL|RIP)|BLU[ ._-]?RAY|SUBS?|DUBBED|DUB|RAW|AR|EN|ARA|ENG)\s*$", " ", text, flags=re.I)
    # Generic portal codes are stripped only when isolated by a strong separator.
    text=re.sub(r"^\s*[A-Z0-9+]{2,6}\s+(?:[-|┃:])\s+(?=\S)", "", text)
    text=re.sub(r"\s+(?:[-|┃:])\s+[A-Z0-9+]{2,6}\s*$", "", text)
    # Existing safe search cleanup.
    text=re.sub(r"^(.+?)[,\s]+the$",lambda m:"The "+m.group(1).strip(),text,flags=re.I)
    text=re.sub(r"^(?:\s*[^|┃]{0,40}[|┃])+\s*","",text)
    text=re.sub(r"\([^)]*\)"," ",text)
    text=re.sub(r"\[[^\]]*\]"," ",text)
    # A year right before a quality tag ("Joker 2019 4K") is decoration.
    text=re.sub(r"(?i)\s+(?:19|20)\d{2}(?=\s+(?:4K|8K|UHD|FHD|HD|2160P|1080P|720P|HDR|DV|DOVI|WEB|BLU))"," ",text)
    text=re.sub(r"\b(?:4K|8K|UHD|FHD|HD|2160P|1080P|720P|HDR(?:10)?\+?|DOVI|HEVC|H\.?26[45]|X26[45]|BLU[ ._-]?RAY|WEB[ ._-]?(?:DL|RIP)|DUBBED|AR[-_ ]?SUBS?)\b"," ",text,flags=re.I)
    text=re.sub(r"(?i)(?<=\w)\s+DV\s*$","",text) if len(text.split())>2 else text
    text=re.sub(r"\s*[\[(]\s*[A-Za-z]{2,3}\s*$"," ",text)
    # Ordinary words (Raw Deal, Sub Zero, Top Gear, The Series) only count as
    # catalogue junk at the very end of the label.
    for _ in range(3):
        _t3=re.sub(r"(?i)[\s._-]+(?:DOLBY|ATMOS|SUBS?|DUBS?|RAW|VIP|TOP|MOVIES?|SERIES|TV)\s*$","",text)
        if _t3!=text and _t3.strip(" -_|:.") and us_casefold(_t3.strip()) not in _STOP_HEADS:text=_t3
        else:break
    text=re.sub(r"\b(?:مترجم|مدبلج|حصري|جديد|قريبا|قريباً|قريبًا)\b"," ",text,flags=re.I)
    text=re.sub(r"[._'*]+"," ",text)
    text=re.sub(r"\s+"," ",text).strip(" -_|:.")
    return text or clean_title(value)

def tmdb_search_aliases(value):
    """Return Ultra mixed-script search aliases while preserving the full title.

    For mixed-script catalogue names we keep both a conservative Latin-only
    search variant and the complete cleaned title. The visible title is never
    changed by this helper.
    """
    full=tmdb_search_title(value)
    out=[]
    has_ascii=bool(re.search(r"[A-Za-z]",full))
    has_non_ascii=bool(re.search(r"[^\x00-\x7f]",full))
    if has_ascii and has_non_ascii:
        latin=unicodedata.normalize("NFKD",full).encode("ascii","ignore").decode("ascii")
        latin=re.sub(r"\s+"," ",latin).strip(" -_|:.")
        if latin:
            out.append(latin)
    if full and full not in out:
        out.append(full)
    return out



def catalogue_title(value):
    """Visible/search title with catalogue branding and year decoration removed.

    'Pure' is treated as branding only when another meaningful title remains.
    An item literally named 'Pure' is preserved.
    """
    text=clean_title(value)
    # Episode-air-date suffixes ("Show 12.10.2026") are not part of the title.
    text=re.sub(r"\s*\b\d{1,2}[./-]\d{1,2}[./-](?:19|20)\d{2}\b", " ", text)
    text=re.sub(r"[\[(]\s*(?:19|20)\d{2}\s*[\])]", " ", text)
    text=re.sub(r"\b(?:19|20)\d{2}\b", " ", text)
    # Remove standalone PURE only if other meaningful content survives.
    without=re.sub(r"(?iu)(?<!\w)pure(?!\w)", " ", text)
    without=re.sub(r"\s+"," ",without).strip(" -_|:.()[]")
    meaningful=re.sub(r"[\W_]+","",without,flags=re.UNICODE)
    if len(meaningful)>=2:
        text=without
    text=re.sub(r"\s+"," ",text).strip(" -_|:.()[]")
    return text or clean_title(value)

# Display-only metadata vocabulary.  This deliberately lives OUTSIDE
# catalogue_title(): identity/TMDb/cache callers keep the conservative title,
# while UI labels may discard much noisier provider decoration.
_DISPLAY_NOISE = {
    "4k","8k","uhd","fhd","hd","sd","2160p","1440p","1080p","720p","576p","480p",
    "hdr","hdr10","hdr10+","dv","dolbyvision","dolby","vision","atmos",
    "hevc","avc","av1","h264","h265","x264","x265","10bit","8bit",
    "webdl","webrip","web","dl","rip","bluray","blurayrip","bdrip","brrip","bdremux","remux","hdtv","cam","camrip","ts","telesync",
    "aac","aac2","aac20","aac51","ac3","eac3","dd","ddp","ddp51","dts","dtshd","truehd","audio","dual","multi",
    "subs","sub","subtitle","subtitles","dub","dubs","dubbed","raw",
    "arabic","english","korean","japanese","chinese","hindi","tamil","telugu","thai","turkish","french","german","spanish","italian","portuguese","russian",
    "ara","eng","kor","jpn","chn","hin","tam","tel","tha","tur","fre","fra","ger","deu","spa","ita","por","rus",
    "netflix","nf","amazon","amzn","prime","primevideo","disney","disney+","dsnp","hbo","max","hmax","appletv","appletv+","aptv","shahid","watchit","osn","starzplay",
    "vip","top","vod","movie","movies","film","films","series","tv","new","latest","exclusive","premiere","pure",
    "مترجم","مدبلج","حصري","حصريا","حصرياً","حصريًا","جديد","قريبا","قريباً","قريبًا","افلام","أفلام","فيلم","مسلسلات","مسلسل",
}
_DISPLAY_AMBIGUOUS_CODES={"ar","en","tr","fr","de","es","it","pt","ru","us","uk","in","kr","jp","cn","eg","ae","sa","br"}
# Words that are technical junk next to a resolution/codec but ordinary title
# words on their own (Mad Max, Spider Web, Dolby Theatre, Raw Deal): they are
# never peeled from the end of a label by themselves.
_DISPLAY_REALWORDS={"max","web","ts","dd","dual","multi","audio","vision","dolby","sub","dub","raw","top","vip","new","latest","exclusive","premiere","film","films","prime","hbo","disney","netflix","amazon","cam","shahid","osn","pure","movie","movies","series","tv","vod"}
_DISPLAY_BARE_SAFE = _DISPLAY_NOISE - _DISPLAY_AMBIGUOUS_CODES - _DISPLAY_REALWORDS

# R100 display-only bracket normalization. IPTV labels sometimes contain
# full-width/small/ornate parentheses plus invisible RTL/Bidi controls. They
# render like normal brackets on Enigma2 but do not match ASCII-only regexes.
_DISPLAY_BRACKET_TRANSLATE = str.maketrans({
    "\uff08":"(", "\uff09":")", "\ufe59":"(", "\ufe5a":")",
    "\uff3b":"[", "\uff3d":"]", "\ufe47":"[", "\ufe48":"]",
    "\uff5b":"{", "\uff5d":"}", "\ufe5b":"{", "\ufe5c":"}",
    "\ufd3e":"(", "\ufd3f":")", "\u2768":"(", "\u2769":")",
    "\u27ee":"(", "\u27ef":")",
})
_DISPLAY_BIDI_CONTROLS = re.compile(r"[\u061c\u200e\u200f\u202a-\u202e\u2066-\u2069]")
_DISPLAY_ANNOUNCE_RE = r"(?:قريب(?:ا|اً|ًا)?|حصري(?:ا|اً|ًا)?|جديد|قادم|يعرض\s+الآن|مترجم|مدبلج|soon|coming\s+soon|new|exclusive|premiere)"

def _normalize_display_brackets(value):
    text=str(value or "")
    text=_DISPLAY_BIDI_CONTROLS.sub("", text)
    return text.translate(_DISPLAY_BRACKET_TRANSLATE)

def _raw_display_bracket_purge(value):
    """Remove bracket decoration before conservative identity cleanup.

    This is DISPLAY-ONLY. It deliberately understands malformed one-sided
    wrappers and RTL-rendered labels. Raw provider identity is never changed.
    """
    text=_normalize_display_brackets(value).strip()
    if not text:
        return text

    # R101 rescue: some providers publish a short catalogue code outside the
    # real localized title, e.g. ``SH (سيدو والحرية)``.  The user's bracket
    # policy must not throw away the meaningful Arabic programme name and leave
    # only the route/code.  This is DISPLAY-ONLY; raw identity remains intact.
    short_code=r"[A-Za-z0-9+._-]{1,8}"
    wrapped_ar=r"[^()\[\]{}]{2,180}[\u0600-\u06ff][^()\[\]{}]{1,180}"
    rescue_patterns=(
        r"^\s*("+short_code+r")\s*(?:[-|┃•·:]+\s*)?[\(\[\{]\s*("+wrapped_ar+r")\s*[\)\]\}]\s*$",
        r"^\s*[\(\[\{]\s*("+wrapped_ar+r")\s*[\)\]\}]\s*(?:[-|┃•·:]+\s*)?("+short_code+r")\s*$",
    )
    for idx,pat in enumerate(rescue_patterns):
        m=re.match(pat,text,flags=re.I)
        if not m:
            continue
        candidate=(m.group(2) if idx==0 else m.group(1)).strip()
        letters=re.sub(r"[^\w\u0600-\u06ff]+","",candidate,flags=re.UNICODE)
        if len(letters)>=3 and re.search(r"[\u0600-\u06ff]",candidate):
            text=candidate
            break

    # Complete wrappers: user policy is explicit -- anything inside a wrapper
    # is display decoration. Iterate for adjacent/nested simple groups.
    for _ in range(6):
        old=text
        text=re.sub(r"\[[^\[\]]{0,180}\]", " ", text)
        text=re.sub(r"\([^()]{0,180}\)", " ", text)
        text=re.sub(r"\{[^{}]{0,180}\}", " ", text)
        if text==old:
            break

    # Known malformed prefix decoration:  "قريبا) Title", "2026] Title",
    # including the visually mirrored RTL forms seen on receiver skins.
    prefix_noise=r"(?:"+_DISPLAY_ANNOUNCE_RE+r"|(?:19|20)\d{2}|4K|8K|UHD|FHD|HD|2160P|1080P|720P|HDR(?:10)?|WEB[ ._-]?(?:DL|RIP)|SUBS?|DUBBED|DUB|ARABIC|ENGLISH|KOREAN|JAPANESE|CHINESE)"
    for _ in range(4):
        old=text
        text=re.sub(r"^\s*[\(\[\{]?\s*"+prefix_noise+r"\s*[\)\]\}]\s*[-:|┃•·]*\s*", "", text, flags=re.I)
        text=re.sub(r"^\s*"+prefix_noise+r"\s*[\)\]\}]\s*[-:|┃•·]*\s*", "", text, flags=re.I)
        if text==old:
            break

    # Known malformed suffix decoration: "Title (قريبا", "Title 2026)".
    text=re.sub(r"\s+[\(\[\{]\s*"+prefix_noise+r"\s*$", "", text, flags=re.I)
    text=re.sub(r"\s+"+prefix_noise+r"\s*[\)\]\}]\s*$", "", text, flags=re.I)

    # Generic unmatched opener after meaningful title: by user policy,
    # everything from that opener to EOL is decoration even when unknown.
    # Preserve a leading opener so we can still rescue a title after a malformed
    # prefix instead of deleting the whole label.
    m=re.search(r"[\(\[\{]", text)
    if m and m.start()>0:
        head=text[:m.start()].strip(" -_|┃•·:._")
        if head:
            text=head

    # Any remaining orphan closers are punctuation only. Known prefix/suffix
    # noise was already removed above, so deleting the glyph cannot damage a
    # legitimate title token such as X-Men or Face/Off.
    text=re.sub(r"[\)\]\}]", " ", text)
    text=re.sub(r"^[\(\[\{]+", " ", text)
    text=re.sub(r"\s+", " ", text).strip(" -_|┃•·:._()[]{}")
    return text

def _display_token(value):
    t=us_casefold(str(value or "").strip())
    t=t.replace("h.264","h264").replace("h.265","h265").replace("dolby vision","dolbyvision")
    t=re.sub(r"[._\-\s]+","",t)
    return t

def _display_is_noise_segment(value):
    raw=str(value or "").strip(" \t-_|┃:;,.()[]{}")
    if not raw:return True
    if re.fullmatch(r"(?:19|20)\d{2}",raw):return True
    low=us_casefold(raw).replace("+","+")
    # Common compound technical forms.
    if re.fullmatch(r"(?i)(?:\d{3,4}p|[48]k|hdr10?\+?|web[ ._-]?(?:dl|rip)|blu[ ._-]?ray|h\.?26[45]|x26[45]|ddp?\s*5[ .]?1|aac\s*[25][ .]?[01]|eac3|ac3|dts(?:[ ._-]?hd)?|10bit|8bit)",raw):return True
    words=list(w for w in re.split(r"[^\w+]+",low,flags=re.UNICODE) if w)
    if not words:return True
    known=0
    for w in words:
        n=_display_token(w)
        if w in _DISPLAY_NOISE or n in _DISPLAY_NOISE or w in _DISPLAY_AMBIGUOUS_CODES:
            known+=1;continue
        if re.fullmatch(r"\d{3,4}p",w) or re.fullmatch(r"[48]k",w):known+=1;continue
        if re.fullmatch(r"(?:19|20)\d{2}",w):known+=1;continue
    if known==len(words):return True
    # Provider/release-group codes are safe to drop only as an isolated segment
    # next to a strong separator, never from the middle of a real title.
    if len(words)==1 and re.fullmatch(r"[A-Z0-9+]{2,7}",raw) and not re.fullmatch(r"\d+",raw):return True
    return False

def _inner_is_vocab_noise(inner):
    low=us_casefold(str(inner or "").strip())
    if not low:return True
    if re.fullmatch(r"(?:19|20)\d{2}",low):return True
    if re.fullmatch(_DISPLAY_ANNOUNCE_RE,low):return True
    words=list(w for w in re.split(r"[^\w+]+",low,flags=re.UNICODE) if w)
    if not words:return True
    for w in words:
        n=_display_token(w)
        if not (w in _DISPLAY_NOISE or n in _DISPLAY_NOISE or w in _DISPLAY_AMBIGUOUS_CODES or re.fullmatch(r"\d{3,4}p|[48]k|hdr10?\+?|h\.?26[45]|x26[45]|10bit|8bit",w)):
            return False
    return True

def protect_title_wrappers(value):
    """Unwrap a bracket group that IS the title: [REC], (500) Days of Summer,
    [Rec] 2, AR - [REC].  Real decoration such as [4K], (2019) or [AR] is left
    for the normal cleaners."""
    text=_normalize_display_brackets(value).strip()
    m=re.match(r"^\s*[\(\[\{]\s*([^\)\]\}]{1,60}?)\s*[\)\]\}]\s*(.*)$",text)
    if m:
        inner,rest=m.group(1).strip(),m.group(2).strip()
        rest_letters=len(re.sub(r"[\W_]+","",rest,flags=re.UNICODE))
        if re.fullmatch(r"\d{1,3}",inner) and rest_letters>=2 and not re.fullmatch(r"(?:19|20)\d{2}",inner):
            return (inner+" "+rest).strip()
        if rest_letters<=3 and not _inner_is_vocab_noise(inner):
            return (inner+" "+rest).strip()
    m=re.match(r"^\s*[A-Za-z]{2,3}\s*[-:|┃]\s*[\(\[\{]\s*([^\)\]\}]{2,80}?)\s*[\)\]\}]\s*$",text)
    if m and not _inner_is_vocab_noise(m.group(1)):
        return m.group(1).strip()
    return str(value or "")

_ABBR_RE=re.compile(r"^[A-Z0-9]{1,4}$")
_WRAP_RE=re.compile(r"[\(\[\{]\s*([^()\[\]{}]{3,120}?)\s*[\)\]\}]")


def _prefer_wrapped_title(original, cleaned):
    """'SH (Sido w Horeya)' / 'SH [سيدو وحرية]': when removing wrappers leaves only a
    short abbreviation, the wrapped text is the real programme name."""
    try:
        c=str(cleaned or "").strip()
        _lead=re.match(r"^[A-Z0-9]{1,4}\s*[-|:]\s*(?=[\(\[\{])",c)
        if _lead:c=c[_lead.end():].strip()
        if _lead and not re.search(r"[\(\[\{]",c):return cleaned
        if _lead:c=_lead.group(0)[:2].strip(" -|:")[:4] or "X"
        if not _ABBR_RE.match(c):return cleaned
        for m in _WRAP_RE.finditer(str(original or "")):
            seg=m.group(1).strip(" -_|:.")
            letters=re.sub(r"[^\w]|\d|_","",seg,flags=re.UNICODE)
            if len(letters)<3:continue
            if re.fullmatch(r"(?i)(?:19|20)\d{2}|\d{3,4}p|[48]k|hdr10?\+?|uhd|fhd|hd|sd|dv|webrip|web-dl|bluray|subs?|dubs?|dubbed|"
                            r"ar|en|ara|eng|us|usa|uk|eg|egy|ksa|مترجم|مدبلج|قريبا|جديد|حصري",seg):continue
            if re.fullmatch(r"(?i)(?:[A-Z]{2,3}|S\d+(?:E\d+)?|\d+)",seg):continue
            return seg
    except Exception:pass
    return cleaned


def _display_title_uncached(value, enabled=True):
    out=_display_title_core(value,enabled)
    return _prefer_wrapped_title(value,out) if enabled is not False else out


def _display_title_core(value, enabled=True):
    """Aggressive DISPLAY-ONLY movie/series title cleaner.

    Raw provider titles remain untouched for identity, TMDb matching, persistent
    cache keys and cross-source grouping.  This function is intended only for
    visible labels/fallback text.
    """
    original=str(value or "").strip()
    if enabled is None:
        try:
            from .storage import load_settings
            enabled=bool((load_settings() or {}).get("clean_titles",True))
        except Exception:
            enabled=True
    if not enabled:
        return original
    # Purge display wrappers from the RAW label first. This preserves evidence
    # such as one-sided/Unicode brackets that conservative clean_title() may
    # otherwise normalize away before the UI has a chance to act on it.
    _protected=protect_title_wrappers(original)
    raw_display=_raw_display_bracket_purge(_protected)
    text=clean_title(raw_display or _protected)
    if not text:return raw_display or original
    _raw_orphan_closer=bool(re.search(r"[\)\]\}]\s*$", _normalize_display_brackets(original)))
    # Some legacy labels arrive as adjacent tags like [KOR][1080P]. The
    # conservative cleaner may consume the first opening bracket while leaving
    # a harmless routing token plus closing bracket; repair that display-only.
    text=re.sub(r"^(?:KOR|JPN|CHN|IND|ARA|ENG|TUR|FRA|GER|DEU|SPA|ITA|POR|RUS|THA|HIN|TAM|TEL)\]\s*", "", text, flags=re.I)

    # Clean Titles ON means the visible label is the programme name only.
    # Provider/editorial decorations inside (), [] or {} are therefore removed
    # unconditionally at DISPLAY time. Raw/identity titles stay untouched.
    # Iterate to cover adjacent/nested wrappers such as [KOR][1080P] Title.
    for _ in range(4):
        old=text
        text=re.sub(r"\[[^\[\]]{0,120}\]", " ", text)
        text=re.sub(r"\([^()]{0,120}\)", " ", text)
        text=re.sub(r"\{[^{}]{0,120}\}", " ", text)
        if text==old:break
    # Portals also ship malformed ONE-SIDED wrappers. Treat both directions
    # symmetrically at DISPLAY time: ``Title (2026`` / ``Title 2026)`` and
    # ``Title [قريبا`` / ``Title قريبا]`` must all present as ``Title``.
    # Opening-only tails are unambiguous: everything from the unmatched opener
    # to the end is decoration. For closing-only tails, strip the orphan closer
    # first, then remove a trailing year/noise/announcement segment below.
    text=re.sub(r"\s*[\(\[\{][^\)\]\}]{1,120}$", " ", text)
    _had_orphan_closer=_raw_orphan_closer or bool(re.search(r"[\)\]\}]\s*$", text))
    if _had_orphan_closer:
        text=re.sub(r"[\)\]\}]\s*$", "", text).rstrip()
        # A year immediately before an orphan closer is provider decoration.
        text=re.sub(r"\s+(?:19|20)\d{2}\s*$", "", text)
        # Likewise for known announcement/technical tails. Iterate so forms
        # such as ``Title Arabic 1080p)`` collapse cleanly without touching
        # the real title on the left.
        for _ in range(6):
            m=re.search(r"(?:\s+|[._]+)([^\s._|┃•·]+)\s*$",text)
            if not m:break
            token=m.group(1)
            norm=_display_token(token)
            low=us_casefold(token)
            noisy=(low in _DISPLAY_NOISE or norm in _DISPLAY_NOISE or
                   bool(re.fullmatch(r"(?i)\d{3,4}p|[48]k|hdr10?\+?|h\.?26[45]|x26[45]|10bit|8bit",token)))
            if not noisy:break
            head=text[:m.start()].strip(" -_|┃•·:._()[]{}")
            if not head or us_casefold(head) in _STOP_HEADS:break
            text=head
        text=re.sub(r"\s*(?:[-|┃•·:]+\s*)?(?:قريب(?:ا|اً|ًا)?|مترجم|مدبلج|حصري(?:ا|اً|ًا)?|جديد)\s*$","",text,flags=re.I)

    # Strong separators are reliable portal boundaries. Peel metadata from both
    # edges but never split real punctuation such as X-Men, Face/Off or a colon
    # inside a film title.
    parts=[p.strip() for p in re.split(r"\s*(?:\||┃|•|·)\s*|\s+-\s+",text) if p.strip()]
    if len(parts)>1:
        while len(parts)>1 and _display_is_noise_segment(parts[0]):parts.pop(0)
        while len(parts)>1 and _display_is_noise_segment(parts[-1]):parts.pop()
        text=" - ".join(parts)

    # Edge platform/provider labels without a separator.
    # Only unambiguous provider brands are stripped without a separator.
    # Ambiguous words such as TOP/MAX/PRIME stay unless isolated by a strong
    # portal separator, so real titles like Top Gun and Max Payne survive.
    platforms=r"(?:NF|AMZN|PRIME\s*VIDEO|DISNEY\+|DSNP|HMAX|APPLE\s*TV\+|APTV|WATCHIT|STARZPLAY)"
    text=re.sub(r"^\s*"+platforms+r"\s+(?=\S)","",text,flags=re.I)
    text=re.sub(r"\s+"+platforms+r"\s*$","",text,flags=re.I)

    # Remove trailing year decorations, but preserve numeric titles such as 1917
    # when the year is the whole remaining title.
    def _strip_year_tail(t):
        # Bare numeric suffixes can be part of the real title (Blade Runner 2049,
        # Death Race 2000). Only a strong separator marks a plain year as
        # provider decoration; bracketed years were already handled above.
        m=re.search(r"\s*[-|┃•·]\s*((?:19|20)\d{2})\s*$",t)
        if not m:return t
        head=t[:m.start()].strip(" -_|┃•·:.()[]{}")
        return head if head else t
    text=_strip_year_tail(text)

    # Compound release tags that only mean junk together.
    for _ in range(3):
        _t2=re.sub(r"(?i)[\s._-]+(?:WEB[ ._-]?(?:DL|RIP)|DOLBY[ ._-]?VISION|(?:DUAL|MULTI)[ ._-]?AUDIO|(?:ARABIC|ENGLISH|AR|EN|TR)[ ._-]+(?:SUBS?|DUBS?)|SUBS?|DUBS?)\s*$","",text) if re.search(r"(?i)[\s._-](?:WEB[ ._-]?(?:DL|RIP)|DOLBY[ ._-]?VISION|(?:DUAL|MULTI)[ ._-]?AUDIO|(?:ARABIC|ENGLISH|AR|EN|TR)[ ._-]+(?:SUBS?|DUBS?)|SUBS|DUBS)\s*$",text) else text
        if _t2!=text and _t2.strip(" -_|┃•·:.") and us_casefold(_t2.strip()) not in _STOP_HEADS:text=_t2
        else:break
    # Peel unbracketed technical tails one token at a time. Ambiguous two-letter
    # language/country codes require a strong separator and are intentionally not
    # removed here.
    for _ in range(14):
        m=re.search(r"(?:\s+|[._]+)([^\s._|┃•·]+)\s*$",text)
        if not m:break
        token=m.group(1)
        norm=_display_token(token)
        low=us_casefold(token)
        noisy=(low in _DISPLAY_BARE_SAFE or norm in _DISPLAY_BARE_SAFE or
               bool(re.fullmatch(r"(?i)\d{3,4}p|[48]k|hdr10?\+?|h\.?26[45]|x26[45]|10bit|8bit",token)))
        if not noisy:break
        head=text[:m.start()].strip(" -_|┃•·:._()[]{}")
        if not head or us_casefold(head) in _STOP_HEADS:break
        text=head

    # Arabic/English announcement words are decoration when they are a separate
    # prefix/suffix, never when embedded inside the real title.
    text=re.sub(r"^(?:حصري(?:ا|اً|ًا)?|جديد|قريب(?:ا|اً|ًا)?|مترجم|مدبلج)\s*(?:[-|┃•·:]+\s*)?","",text,flags=re.I)
    text=re.sub(r"\s*(?:[-|┃•·:]+\s*)?(?:مترجم|مدبلج|حصري(?:ا|اً|ًا)?|جديد)\s*$","",text,flags=re.I)

    # Remove standalone PURE branding only when a meaningful title survives.
    without=re.sub(r"(?iu)(?<!\w)pure(?!\w)"," ",text)
    without=re.sub(r"\s+"," ",without).strip(" -_|┃•·:.()[]{}")
    if len(re.sub(r"[\W_]+","",without,flags=re.UNICODE))>=2:text=without

    text=re.sub(r"\s+"," ",text).strip(" -_|┃•·:.()[]{}")
    return text or catalogue_title(original) or original



# ---- R5.163: memoised public entry points (pure string -> string functions) ----
_lru_cache = _us_env.lru_cache


@_lru_cache(maxsize=6144)
def _clean_title_cached(text):
    return _clean_title_uncached(text)


@_lru_cache(maxsize=6144)
def _display_title_cached(text, enabled):
    return _display_title_uncached(text, enabled)


def clean_title(value):
    if isinstance(value, str):
        return _clean_title_cached(value)
    return _clean_title_uncached(value)


def display_title(value, enabled=None):
    """Aggressive DISPLAY-ONLY title cleaner (cached; see _display_title_uncached)."""
    if enabled is None:
        try:
            from .storage import load_settings
            enabled = bool((load_settings() or {}).get("clean_titles", True))
        except Exception:
            enabled = True
    else:
        enabled = bool(enabled)
    if isinstance(value, str):
        return _display_title_cached(value, enabled)
    return _display_title_uncached(value, enabled)
