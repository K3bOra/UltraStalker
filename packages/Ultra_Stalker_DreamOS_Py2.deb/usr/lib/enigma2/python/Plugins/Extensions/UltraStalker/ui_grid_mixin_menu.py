# -*- coding: utf-8 -*-
"""Information, export to receiver and the grid menu.

Methods moved verbatim out of ``PremiumGridBase`` (ui_grid_base.py); behaviour is unchanged.
This module is imported by ui_grid_base.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, min
from .ui_grid_base import (
    _,
    call_compatible,
    os,
    show_notice,
)


class GridMenuMixin(object):
    """Information, export to receiver and the grid menu."""

    def show_information(self):
        if not self.grid_items:return
        item=self.grid_items[self.index]
        if self.media_type in ("vod","series"):
            detail_item=dict(item) if isinstance(item,dict) else item
            try:
                visible_poster=self._visible_player_poster_path(item,self.index)
                if isinstance(detail_item,dict) and visible_poster:
                    detail_item["_ultra_palette_source"]=str(visible_poster);detail_item["_ultra_poster_source"]=str(visible_poster);detail_item["_player_poster"]=str(visible_poster);detail_item["_adaptive_source_local"]=str(visible_poster)
                    detail_item["_ultra_visible_poster_locked"]=True
                    _poster_key=self._page_visual_key(item) if isinstance(item,dict) else ""
                    if _poster_key:detail_item["_player_poster_identity"]=_poster_key
                if isinstance(item,dict) and isinstance(detail_item,dict):
                    for key in ("_backdrop_source_local","_cin_provider_backdrop_local","_cin_provider_poster_url","_cin_provider_backdrop_url"):
                        if item.get(key) not in (None,""):detail_item[key]=item.get(key)
            except Exception as exc:optional_failure("ui.grid_info_visual_handoff",exc)
            self.session.open(ContentDetailsScreen,self.profile,self.client,self.media_type,detail_item)
        else:
            cid=str(item.get("id") or item.get("ch_id") or "");epg=self._epg_cache.get(cid,{})
            text=_("%s\n\nNOW: %s\nNEXT: %s")%(self["title"].getText(),epg.get("now") or _("No EPG"),epg.get("next") or _("No EPG"))
            self.session.open(MessageBox,text,MessageBox.TYPE_INFO,timeout=12)

    def _export_focused_to_receiver(self):
        """Export only the movie or series under the cursor to the TV bouquet list."""
        if self.media_type not in ("vod", "series") or not self.grid_items:
            return
        try:
            item = dict(self.grid_items[self.index] or {})
        except Exception:
            return
        if not item:
            return
        media_type = self.media_type
        from .storage import load_settings
        from .ultra import premium_title
        from .ui import _new_isolated_source_client
        from .core.bouquets import export_receiver_items, export_series_category_bouquets, reload_bouquets
        cfg = load_settings() or {}
        raw_title = item.get("name") or item.get("title") or _("Item")
        title = premium_title(raw_title, cfg.get("clean_titles", True))
        from .export_progress import ExportProgress, start_poll
        progress = ExportProgress(_("Sending to Receiver: %s") % title)
        try:
            self["status"].setText(progress.text())
        except Exception:
            pass
        stop_poll = start_poll(self, progress)

        def work(handle):
            isolated = _new_isolated_source_client(dict(self.profile or {}), timeout=min(8, int(cfg.get("timeout", 10) or 10)))
            try:
                if media_type == "vod":
                    progress.set(_("Details and bouquet: %s") % title, 0, 0)
                    row = dict(item)
                    row["_receiver_name"] = title
                    poster = ""
                    try:
                        poster = str(self._visible_player_poster_path(item, self.index) or "")
                    except Exception:
                        poster = ""
                    if poster and os.path.isfile(poster):
                        row["_receiver_picon_local"] = poster
                    return export_receiver_items(self.profile, [row], "vod", _("Movies"), cfg.get("service_type", 4097))
                from .ui import _load_screen_group
                _load_screen_group('browser')
                from .ui_screens_browser import _series_poster_path, _stamp_episode_export
                seasons = call_compatible(
                    isolated.series_seasons,
                    (((item,), {"cancel_event": handle.cancel_event}), ((item, handle.cancel_event), {}), ((item,), {})),
                ) or []
                series_name = str(title or "Series")[:80]
                poster = ""
                try:
                    poster = str(self._visible_player_poster_path(item, self.index) or "")
                except Exception:
                    poster = ""
                if not (poster and os.path.isfile(poster)):
                    poster = _series_poster_path(self.profile, item, isolated)
                season_groups = []
                progress.set(_("Seasons: %s") % title, 0, len(seasons[:120]))
                for season in seasons[:120]:
                    if handle.cancelled():
                        break
                    progress.tick()
                    episodes = call_compatible(
                        isolated.series_episodes,
                        (((item, season), {"cancel_event": handle.cancel_event}), ((item, season, handle.cancel_event), {}), ((item, season), {})),
                    ) or []
                    try:
                        season_no = int((season or {}).get("season") or (season or {}).get("season_number") or 0)
                    except Exception:
                        season_no = 0
                    season_rows = []
                    for pos, episode in enumerate(episodes, 1):
                        if not isinstance(episode, dict):
                            continue
                        if not (episode.get("cmd") or episode.get("command") or episode.get("url")):
                            continue
                        row = dict(episode)
                        try:
                            ep_no = int(row.get("episode_num") or row.get("episode") or row.get("number") or pos)
                        except Exception:
                            ep_no = pos
                        s_no = season_no or (len(season_groups) + 1)
                        row["_receiver_name"] = "%s - S%02dE%02d" % (series_name, s_no, ep_no)
                        _stamp_episode_export(row, poster)
                        season_rows.append(row)
                        if len(season_rows) >= 800:
                            break
                    if season_rows:
                        season_groups.append({"name": "S%02d" % (season_no or (len(season_groups) + 1)), "episodes": season_rows})
                    if sum(len(group["episodes"]) for group in season_groups) >= 4000:
                        break
                if not season_groups:
                    raise RuntimeError(_("No playable episodes were found"))
                progress.set(_("Details and bouquet: %s") % title, 0, 0)
                return export_series_category_bouquets(
                    self.profile,
                    [{"name": series_name, "poster": poster, "seasons": season_groups, "metadata":dict(item)}],
                    series_name,
                    "series:" + str(item.get("id") or item.get("series_id") or series_name),
                    cfg.get("service_type", 4097),
                )
            finally:
                try:
                    isolated.close()
                except Exception:
                    pass

        def ok(result):
            stop_poll()
            try:
                reload_bouquets()
            except Exception:
                pass
            count = int((result or {}).get("items") or 0)
            try:
                self["status"].setText(_("Sent to Receiver • Items: %d") % count)
            except Exception:
                pass
            try:
                show_notice(self.session, _("Sent to the receiver bouquet list.\n\n%s\nItems: %d") % (title, count), timeout=8, owner=self)
            except Exception:
                pass

        def failed(exc):
            stop_poll()
            try:
                self["status"].setText(_("Send to Receiver failed: %s") % exc)
            except Exception:
                pass

        if not self._run_async(work, ok, failed):
            stop_poll()

    def open_menu(self):
        choices=[(_("Refresh page"),"refresh"),(_("First page"),"first"),(_("Toggle favorite"),"favorite")]
        if self.media_type in ("vod","series") and self.grid_items:
            from .ui_manual_match import menu_choices
            choices.extend(menu_choices())
            choices.append((_("Trailer"),"trailer"))
            choices.append((_("Export this to channel list"),"export_one"))
        if self.media_type=="vod" and self.grid_items:
            state=self._grid_item_state.get(id(self.grid_items[self.index]),{})
            choices.append((_("Mark unwatched") if state.get("completed") else _("Mark watched"),"unwatch" if state.get("completed") else "watch"))
        self.session.openWithCallback(self._menu_selected,ChoiceBox,title=_("Grid options"),list=choices)

    def _menu_selected(self,choice):
        if not choice:return
        if choice[1]=='manual_match' and self.media_type in ('vod','series') and self.grid_items:
            from .ui_manual_match import open_picker,refresh_grid
            open_picker(self,self.grid_items[self.index],lambda changed:refresh_grid(self,changed))
            return
        if choice[1]=="refresh":
            # R231: clear the exact provider first-paint URL used by both Xtream
            # and Stalker. Stalker public rows intentionally strip artwork and
            # keep it in _visible_provider_art_url, so _image_url(item) alone
            # could not clear the backoff that the visible poster worker uses.
            for item in self.grid_items:
                raw=(item.get("_visible_provider_art_url") or item.get("_rescue_provider_art_url") or _image_url(item)) if isinstance(item,dict) else None
                url = self._grid_absolute_url(raw,item) if raw else None
                if url:
                    _clear_artwork_failure(url)
            self.load_page(self.page)
        elif choice[1]=="first":self.load_page(1)
        elif choice[1]=="favorite":self.toggle_selected_favorite()
        elif choice[1]=="trailer":self.play_selected_trailer()
        elif choice[1]=="export_one":self._export_focused_to_receiver()
        elif choice[1]=="set_home_hero":self._pin_selected_as_home_hero()
        elif choice[1] in ("watch","unwatch") and self.grid_items:
            item=self.grid_items[self.index];watched=choice[1]=="watch";mark_watched(self.profile,self.media_type,item,watched)
            cached=self._grid_item_state.setdefault(id(item),{'favorite':False,'position':0,'duration':0,'completed':0});cached['completed']=1 if watched else 0
            if not watched:cached['position']=0
            try:self._apply_card_progress()
            except Exception as exc:optional_failure("ui.card_progress_mark",exc)
            try:self["item_meta%d"%self.index].setText(self._card_meta(item,self.index))
            except Exception as exc:optional_failure("ui",exc)
            self._update_header(item);self["status"].setText(_("Marked watched") if watched else _("Marked unwatched"))
