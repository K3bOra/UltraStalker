# -*- coding: utf-8 -*-
"""Future tracking, UI hook teardown, hide/show release and resume, close handling and backdrop watch.

Methods moved verbatim out of ``ContentDetailsScreen`` (ui_screens_details.py); behaviour is unchanged.
This module is imported by ui_screens_details.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, max
from .ui_screens_details import (
    _,
    _details_backdrop_truth,
    _ui_diag,
    _visual_source_fingerprint,
    diagnostic_failure,
    os,
    time,
)


from . import details_look as _look


class DetailsLifecycleMixin(object):
    """Future tracking, UI hook teardown, hide/show release and resume, close handling and backdrop watch."""

    def _track_details_future(self, future):
        if future is None:return None
        futures=getattr(self,"_details_worker_futures",None)
        if not isinstance(futures,set):
            futures=set();self._details_worker_futures=futures
        futures.add(future)
        try:future.add_done_callback(lambda done,owned=futures:owned.discard(done))
        except Exception:pass
        return future

    def _cancel_details_futures(self):
        futures=getattr(self,"_details_worker_futures",None)
        if not isinstance(futures,set):return
        for future in list(futures):
            if future is None or future.done():
                futures.discard(future);continue
            try:future.cancel()
            except Exception as exc:optional_failure("ui.details_future_cancel",exc)
            if future.done():futures.discard(future)

    def _ui_diag_details_close(self):
        try:_ui_diag("ui_close",screen="details",media_type=self.media_type,
                     lifetime_ms=int(max(0.0,(time.monotonic()-self._ui_diag_open_mono)*1000.0)))
        except Exception as exc:diagnostic_failure("ui.details.failsoft.185",exc)

    def _stop_details_ui_hooks(self):
        try:self._details_cancel_event.set()
        except Exception as exc:optional_failure("ui.details_cancel_cleanup",exc)
        self._cancel_details_futures()
        self._title_logo_token += 1;self._cast_language_token += 1
        future=getattr(self,"_title_logo_future",None)
        if future is not None and not future.done():
            try:future.cancel()
            except Exception:pass
        self._title_logo_future=None
        for result_queue_name in ("_adaptive_jobs","_backdrop_jobs","_tmdb_jobs","_title_logo_jobs"):
            result_queue=getattr(self,result_queue_name,None)
            if result_queue is None:continue
            try:
                while True:result_queue.get_nowait()
            except queue.Empty:
                pass
            except Exception as exc:
                optional_failure("ui.details_queue_cleanup",exc)
        for hook_name,callback in (
            ("onLayoutFinish",self._layout_ready),
            ("onHide",self._details_hidden_release),
            ("onShown",self._details_shown_resume),
        ):
            try:
                hooks=getattr(self,hook_name,None)
                if hooks is not None and callback in hooks:hooks.remove(callback)
            except Exception as exc:
                optional_failure("ui.details_hook_cleanup",exc)

    def _details_hidden_release(self):
        """Suspend background work while a child screen is open, but keep the UI state.

        Previous builds released every Details pixmap on onHide(). Enigma2 then
        returned to a live screen whose adaptive/glass widgets had already lost
        their native pixmaps, causing the black/no-glass state seen after Info,
        Episodes or Player. Full pixmap release belongs only to onClose().
        """
        if getattr(self,"_screen_closed",False):return
        self._details_images_suspended=True
        try:self._backdrop_watch_timer.stop()
        except Exception as exc:optional_failure("ui.silent_guard",exc)
        try:self._desc_scroll_timer.stop();self._desc_guard_timer.stop()
        except Exception as exc:optional_failure("ui.silent_guard",exc)
        # Freeze the exact presentation that was visible before the child/player.
        # Async backdrop jobs completing behind the player must not repaint Details
        # on return with a differently cropped source.
        try:
            current=str(getattr(self,"_backdrop_displayed_path","") or self._details_visual_state.get("backdrop_present") or getattr(self,"_portal_backdrop_present_local","") or "")
            canonical=str(self._details_visual_state.get("backdrop") or getattr(self,"_portal_backdrop_source_local","") or "")
            if canonical and os.path.isfile(canonical) and not os.path.basename(canonical).startswith("us221_detail_"):
                self._return_backdrop_source=canonical
            if current and os.path.isfile(current):
                self._return_backdrop_path=current
                self._details_visual_state["backdrop_present"]=current
        except Exception as exc:optional_failure("ui.details_freeze_backdrop",exc)
        try:
            self._backdrop_token += 1
            self._backdrop_present_pending=""
            while True:self._backdrop_jobs.get_nowait()
        except queue.Empty:
            pass
        except Exception as exc:optional_failure("ui.details_freeze_queue",exc)

    def _restore_details_visual_state(self, reload_disk=True):
        """Restore Details visuals, optionally re-reading the HDD bundle.

        First-paint callers already own the validated in-memory bundle loaded at
        screen construction, so they must not hit HDD again on the GUI thread.
        Child/player returns still request a fresh disk rehydrate.
        """
        if getattr(self,"_screen_closed",False):return
        state=dict(getattr(self,"_details_visual_state",{}) or {})
        # Child/player screens can release pixmaps under memory pressure. Rehydrate
        # the exact persistent visual bundle first, so return never depends on a
        # stale in-RAM path.
        try:
            snap=(getattr(self,"_tmdb_data",None) or getattr(self,"_local_detail_cache",None))
            disk=(_load_visual_bundle(self.profile,self.media_type,getattr(self,"_portal_item",self.item),snapshot=snap) or {}) if reload_disk else dict(getattr(self,"_persistent_visual_bundle",{}) or {})
            authority=str(getattr(self,"_poster_authoritative_source","") or "")
            if authority and os.path.isfile(authority):
                afp=_visual_source_fingerprint(authority)
                if str(disk.get("detail_poster_source_fp") or "")!=afp:
                    disk.pop("detail_poster",None)
                    state.pop("detail_poster",None)
                # The current Grid/Cinematic selection is the strongest poster
                # identity for this screen. Never let a stale disk row replace it.
                state["poster"]=authority
            # Live RAM state is authoritative. Disk is fallback only; overwriting
            # it here was the source of the post-player backdrop jump/crop.
            for key,value in disk.items():
                if key not in state or state.get(key) in (None,"",{},[]):
                    if value not in (None,"",{},[]):state[key]=value
            frozen=str(getattr(self,"_return_backdrop_path","") or "")
            authority=str(getattr(self,"_details_backdrop_authority_source","") or "")
            canonical=str(authority or getattr(self,"_return_backdrop_source","") or state.get("backdrop") or getattr(self,"_portal_backdrop_source_local","") or "")
            exact=""
            if canonical and os.path.isfile(canonical) and not os.path.basename(canonical).startswith("us221_detail_"):
                try:
                    candidate=self._backdrop_presentation_target(canonical)
                    if candidate and _valid_cache_file(candidate):exact=candidate
                except Exception as exc:optional_failure("ui.details_return_backdrop_target",exc)
            if exact:state["backdrop_present"]=exact
            elif frozen and os.path.isfile(frozen):state["backdrop_present"]=frozen
            elif getattr(self,"_portal_backdrop_present_local","") and os.path.isfile(self._portal_backdrop_present_local):state["backdrop_present"]=self._portal_backdrop_present_local
            self._details_visual_state.update(state)
        except Exception as exc:optional_failure("ui.details_restore_bundle",exc)

        # Re-apply the exact adaptive chrome that was already built on HDD.
        chrome=state.get("chrome")
        if isinstance(chrome,dict) and chrome:
            try:self._apply_detail_chrome(chrome)
            except Exception as exc:optional_failure("ui.details_restore_chrome",exc)
        else:
            try:self._apply_detail_chrome(None)
            except Exception as exc:optional_failure("ui.silent_guard",exc)

        # Background/theme/backdrop are restored directly from cached files.
        for widget,key in (
            ("dynamic_bg","theme"),
            ("cinematic_bg","backdrop_present"),
            ("cinematic_edge","edge"),
        ):
            if not _look.ADAPTIVE_COLORS and widget in ("dynamic_bg","cinematic_edge"):
                try:self[widget].hide()
                except Exception:pass
                continue
            try:
                path=str(state.get(key) or "")
                if path and os.path.isfile(path) and self[widget].instance is not None:
                    if widget=="cinematic_bg":
                        # Player/video modes on a few images can leave the native
                        # pixmap widget with stale geometry. Reassert the approved
                        # Details/Series hero rectangle before rebinding the file.
                        try:self[widget].instance.move(ePoint(*_ultra_xy(300,0)));self[widget].instance.resize(eSize(*_ultra_wh(1620,670)))
                        except Exception as exc:optional_failure("ui.details_restore_backdrop_geometry",exc)
                    try:self[widget].instance.setPixmap(None)
                    except Exception:pass
                    self[widget].instance.setPixmapFromFile(path)
                    self[widget].show()
                    if widget=="cinematic_bg":
                        self._backdrop_displayed_path=path
                        self._backdrop_rank=max(5,int(getattr(self,"_backdrop_rank",0) or 0))
                        self._backdrop_present_pending=""
            except Exception as exc:
                optional_failure("ui.details_restore_%s"%widget,exc)

        # Poster is already HDD-cached; restore directly if the decoder was reset.
        try:
            poster=str(state.get("detail_poster") or state.get("poster") or getattr(self,"_image_displayed_path","") or "")
            if poster and os.path.isfile(poster) and self["poster"].instance is not None:
                try:self["poster"].instance.setPixmap(None)
                except Exception:pass
                self["poster"].instance.setPixmapFromFile(poster)
                self["poster"].show()
                self._image_displayed_path=poster
        except Exception as exc:optional_failure("ui.details_restore_poster",exc)

        try:self._sync_detail_text_direction()
        except Exception as exc:optional_failure("ui.silent_guard",exc)
        try:self._ensure_description_visible()
        except Exception as exc:optional_failure("ui.silent_guard",exc)

    def _details_shown_resume(self):
        if not getattr(self,"_details_images_suspended",False):return
        if getattr(self,"_screen_closed",False):return
        self._details_images_suspended=False
        try:self._image_layout_ready()
        except Exception as exc:optional_failure("ui.silent_guard",exc)

        # First paint after return is synchronous and HDD-only.
        try:self._restore_details_visual_state()
        except Exception as exc:optional_failure("ui.details_resume_restore",exc)

        try:self._schedule_description_scroll();self._desc_guard_timer.start(700,True)
        except Exception as exc:optional_failure("ui.silent_guard",exc)
        try:
            if int(getattr(self,"_backdrop_rank",0) or 0)<5:self._backdrop_watch_timer.start(1400,True)
        except Exception as exc:optional_failure("ui.silent_guard",exc)

    def _release_details_pixmaps(self):
        # These widgets can own 1620x620 / full-screen native images. Clearing
        # only the poster is insufficient on long Movies/Series sessions.
        for _name in (
            "dynamic_bg","cinematic_bg","cinematic_edge","poster","accent_frame",
            "poster_card_bg","poster_border_overlay","poster_footer_bg","panel_bg","overview_bg",
            "cast_card_bg","quality_pill_bg","year_pill_bg",
            "runtime_pill_bg","country_pill_bg","genre_pill_bg","tmdb_pill_bg","imdb_pill_bg",
            "rating_ring","poster_imdb_logo","quality_logo","country_flag","runtime_icon"
        ):
            _release_pixmap_widget(self,_name)
        try:self._tmdb_data=None
        except Exception as exc:optional_failure("ui.silent_guard",exc)
        try:self._local_detail_cache={}
        except Exception as exc:optional_failure("ui.silent_guard",exc)
        try:self._backdrop_jobs=queue.Queue();self._adaptive_jobs=queue.Queue();self._tmdb_jobs=queue.Queue()
        except Exception as exc:optional_failure("ui.silent_guard",exc)
        _native_image_pressure_relief(force=True)

    def _fast_close(self):
        """Close details immediately and invalidate every stale visual callback."""
        try:self._details_cancel_event.set()
        except Exception as exc:optional_failure("ui.silent_guard",exc)
        self._cancel_details_futures()
        try:self._adaptive_token += 1; self._backdrop_token += 1; self._tmdb_token += 1
        except Exception as exc:optional_failure("ui.silent_guard",exc)
        try:self._backdrop_watch_timer.stop()
        except Exception as exc:optional_failure("ui.silent_guard",exc)
        try:self._desc_scroll_timer.stop(); self._desc_guard_timer.stop()
        except Exception as exc:optional_failure("ui.silent_guard",exc)
        self.close()

    def _stop_backdrop_watch(self):
        try:self._backdrop_watch_timer.stop()
        except Exception as exc:optional_failure("ui.silent_guard",exc)
        try:
            if self._backdrop_watch_conn is not None:self._backdrop_watch_conn.disconnect()
        except Exception as exc:optional_failure("ui.silent_guard",exc)
        try:
            if self._poll_recovered_backdrop in self._backdrop_watch_timer.callback:self._backdrop_watch_timer.callback.remove(self._poll_recovered_backdrop)
        except Exception as exc:optional_failure("ui.silent_guard",exc)

    def _poll_recovered_backdrop(self):
        """Notice a recovered HDD backdrop without doing image work on the UI thread."""
        if self._screen_closed or getattr(self,"_persistent_backdrop_locked",False):return
        try:
            snap=load_artwork_v2_manifest(self.profile,self.media_type,getattr(self,"_portal_item",self.item)) or {}
            authority=str(getattr(self,"_details_backdrop_authority_source","") or "")
            if getattr(self,"_details_backdrop_authority_locked",False) and authority:
                real=authority
            elif int(snap.get("clean_backdrop_selector_version") or 0)>=3:
                real=str(snap.get("backdrop_local") or "")
            else:
                real=""
            if _details_backdrop_truth(real):
                target=self._backdrop_presentation_target(real)
                if target and _valid_cache_file(target):
                    current=str(getattr(self,"_backdrop_displayed_path","") or "")
                    if target!=current and self["cinematic_bg"].instance is not None:
                        self["cinematic_bg"].instance.setPixmap(None);self["cinematic_bg"].instance.setPixmapFromFile(target);self["cinematic_bg"].show()
                        self._backdrop_displayed_path=target;self._backdrop_rank=max(5,int(getattr(self,"_backdrop_rank",0) or 0))
                        self["status"].setText(_("Backdrop ready • HDD"))
                        _runtime_endurance_log("details_backdrop_hot_reload",media_type=self.media_type,tmdb_id=snap.get("tmdb_id"))
                elif getattr(self,"_backdrop_present_pending","")!=real:
                    self._schedule_backdrop_presentation(real,5)
            if not self._screen_closed and int(getattr(self,"_backdrop_rank",0) or 0) < 5:
                self._backdrop_watch_timer.start(1100,True)
        except Exception as exc:
            optional_failure("ui.backdrop_watch",exc)
            try:
                if not self._screen_closed:self._backdrop_watch_timer.start(1800,True)
            except Exception as exc:optional_failure("ui.backdrop_watch_restart",exc)

    def _runtime_details_close(self):
        try:self._details_cancel_event.set()
        except Exception as exc:optional_failure("ui.details_cancel",exc)
        _runtime_endurance_log("details_close",media_type=self.media_type,backdrop_rank=int(getattr(self,"_backdrop_rank",0) or 0),tmdb=bool(isinstance(getattr(self,"_tmdb_data",None),dict) and self._tmdb_data.get("matched")))
from .wqhd_layout import xy as _ultra_xy, wh as _ultra_wh
