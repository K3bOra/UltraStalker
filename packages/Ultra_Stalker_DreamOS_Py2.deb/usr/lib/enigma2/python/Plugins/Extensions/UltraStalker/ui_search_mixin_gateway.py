# -*- coding: utf-8 -*-
"""Search gateway buckets.

Methods moved verbatim out of ``PortalGlobalSearchScreen`` (ui_screens_search.py); behaviour is unchanged.
This module is imported by ui_screens_search.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, max, min
from .wqhd_layout import responsive_font as _ultra_rfont, factors as _ultra_factors, xy as _ultra_xy, wh as _ultra_wh

def _ultra_osd_scale():
    return _ultra_factors()[1]
from .ui_screens_search import (
    _,
    _clean_display_text,
    gFont,
    load_detail_snapshot,
)


class SearchGatewayMixin(object):
    """Search gateway buckets."""

    def _ensure_search_buckets(self):
        buckets = getattr(self, "_search_bucket_rows", None)
        if isinstance(buckets, dict) and isinstance(buckets.get("vod"), list) and isinstance(buckets.get("series"), list):
            return buckets
        # Compatibility fallback for any in-memory screen created before this
        # code path existed. Rebuild once, then stay O(1) on navigation.
        buckets = {"vod": [], "series": []}
        for group in (getattr(self, "results", []) or []):
            typ = str((group or {}).get("_search_media_type") or "vod").lower()
            buckets["series" if typ == "series" else "vod"].append(group)
        self._search_bucket_rows = buckets
        return buckets

    def _search_bucket_counts(self):
        buckets = self._ensure_search_buckets()
        return len(buckets["vod"]), len(buckets["series"])

    def _view_results(self):
        """Return the active Search result bucket without filtering on moves.

        ``self.results`` stays authoritative for federation/status/source counts.
        R52 keeps Movies and Series as references to the same grouped dictionaries
        while they are created, so this hot path only returns an existing list.
        """
        wanted = str(getattr(self, "_search_result_type", None) or "").lower()
        if wanted not in ("vod", "series"):
            return getattr(self, "results", []) or []
        return self._ensure_search_buckets()[wanted]

    def _search_hide_details(self):
        for _n in ("sd_title", "sd_meta", "sd_desc"):
            try:self[_n].hide()
            except Exception:pass

    def _search_details_for(self, item, allow_disk=True):
        """(title, meta, description) for the focused result; cache/disk only, no network."""
        try:
            ident = self._poster_identity(item)
        except Exception:
            ident = id(item)
        hit = self._sd_cache.get(ident)
        if hit is not None:return hit
        row = dict(item or {})
        try:
            copies = self._group_copies(item)
            if copies:
                merged = dict(copies[0] or {})
                for k, v in row.items():
                    if v not in (None, "", 0, "0"):merged.setdefault(k, v)
                row = merged
        except Exception:pass
        typ = str(row.get("_search_media_type") or "vod").lower()
        raw = ((item.get("_search_group_title") if item.get("_search_group") else None) or row.get("_raw_name") or row.get("name") or row.get("title") or "")
        snap = {}
        def pick(*keys):
            for src in (row, snap):
                for k in keys:
                    v = src.get(k) if isinstance(src, dict) else None
                    if v not in (None, "", "0", "N/A"):return v
            return ""
        desc = pick("description", "descr", "overview", "plot")
        year = pick("year", "release_year", "release_date", "first_air_date")
        disk_skipped = False
        if not allow_disk:
            # No disk work while a federated search runs: pick the provider text
            # exactly like the authority does (pure string work).
            try:
                from .details_authority import provider_description_for_display
                desc = provider_description_for_display(row) or desc
            except Exception as exc:
                optional_failure("ui.search_description_provider", exc)
        if not (desc and year) and not allow_disk:
            disk_skipped = True
        elif not (desc and year):
            try:
                prof = row.get("_search_profile") or self.profile
                snap = (load_detail_snapshot(prof, typ, row) or {}) if prof else {}
            except Exception:snap = {}
            desc = desc or pick("description", "descr", "overview", "plot")
            year = year or pick("year", "release_year", "release_date", "first_air_date")
        # Favorites uses the Details-Authority localized snapshot when ready.
        # Cache/disk only: Search never launches a new metadata request merely
        # because the user moved the focus during an active federated search.
        if allow_disk:
            try:
                from .details_authority import details_overview, load_canonical, metadata_language_ready
                from .persistent_cache import load_detail_snapshot_by_tmdb
                prof = row.get("_search_profile") or self.profile
                canonical = dict(load_canonical(prof, typ, row) or {})
                tmdb_id = canonical.get("tmdb_id") or row.get("_locked_tmdb_id")
                if tmdb_id:
                    direct = load_detail_snapshot_by_tmdb(
                        canonical.get("media_type") or row.get("_locked_tmdb_type") or typ,
                        tmdb_id) or {}
                    if direct: canonical.update(direct)
                # Always ask the authority: it also knows what to show while the
                # selected-language snapshot is missing (same text as Details).
                localized, ready = details_overview(prof, typ, row, canonical)
                if localized: desc = localized
            except Exception as exc:
                optional_failure("ui.search_description_localized", exc)
        genre = pick("genres_str", "genre", "genres")
        if isinstance(genre, (list, tuple)):genre = ", ".join(str(x) for x in genre[:3] if x)
        rating = str(pick("rating_imdb", "rating", "vote_average") or "").strip()
        meta = []
        if year:meta.append(str(year)[:4])
        if genre:meta.append(str(genre)[:60])
        if rating:
            try:rating = "%.1f" % float(rating)
            except Exception:pass
            if rating not in ("0.0", "0"):meta.append("\u2605 " + rating)
        out = (str(raw).strip()[:90], "  \u2022  ".join(meta), _clean_display_text(str(desc or "").replace("\n", " "), 0))
        if disk_skipped:return out
        if len(self._sd_cache) > 80:self._sd_cache = {}
        self._sd_cache[ident] = out
        return out

    def _hide_search_gateway(self):
        for slot in range(2):
            for name in ("search_root_bg%d" % slot, "search_root_sel%d" % slot,
                         "search_root_icon%d" % slot, "search_root_title%d" % slot,
                         "search_root_count%d" % slot):
                try:self[name].hide()
                except Exception:pass

    def _render_search_gateway(self):
        """Premium two-card Search gateway with large artwork-style icons.

        R137 restores the approved fixed Home glass card/focus surfaces while
        keeping R136's larger 220x132 source icons.  The icons are fitted large
        inside each card, Movies/Series returns as a modest caption, and the
        live counters sit lower beneath the cards.
        """
        movies, series = self._search_bucket_counts()
        entries = (
            ("vod", _("Movies"), "home_movies_line.png", movies),
            ("series", _("Series"), "home_series_line.png", series),
        )
        # R5.198: same card family as the Local home: 380x330 focused / 340x296 idle cards,
        # the big neon line icons, title under the icon and the count INSIDE the card.
        active=max(0,min(1,int(getattr(self,"_search_gateway_index",0) or 0)))
        state=getattr(self,"_search_gateway_state",None)
        if not isinstance(state,dict) or not getattr(self,"_search_gateway_visuals_bound",False):
            state={};self._search_gateway_state=state
        for slot,(_mt,label,icon_name,count) in enumerate(entries):
            selected=(slot==active);x=535+slot*470;y=700 if selected else 717
            kind="movies" if slot==0 else "series"
            try:
                bg=self["search_root_bg%d"%slot]
                if bg.instance is not None:
                    if selected:bg.instance.move(ePoint(*_ultra_xy(x,700)));bg.instance.resize(eSize(*_ultra_wh(380,330)))
                    else:bg.instance.move(ePoint(*_ultra_xy(x+20,717)));bg.instance.resize(eSize(*_ultra_wh(340,296)))
                    if state.get(slot)!=selected:
                        bg.instance.setPixmapFromFile(asset("page_card_focus_380x330.png" if selected else "page_card_340x296_%d.png"%(1 if kind=="movies" else 2)))
                bg.show()
            except Exception:pass
            try:self["search_root_sel%d"%slot].hide()
            except Exception:pass
            try:
                icon=self["search_root_icon%d"%slot]
                if icon.instance is not None:
                    if selected:icon.instance.move(ePoint(*_ultra_xy(x+102,754)));icon.instance.resize(eSize(*_ultra_wh(176,132)))
                    else:icon.instance.move(ePoint(*_ultra_xy(x+122,774)));icon.instance.resize(eSize(*_ultra_wh(136,102)))
                    if state.get(slot)!=selected:
                        icon.instance.setPixmapFromFile(asset("home_%s_line%s.png"%(kind,"_xl" if selected else "_big")))
                icon.show()
            except Exception:pass
            try:
                title=self["search_root_title%d"%slot]
                if title.instance is not None:
                    title.instance.move(ePoint(*_ultra_xy(x if selected else x+20,909 if selected else 900)));title.instance.resize(eSize(*_ultra_wh(380 if selected else 340,50)))
                    title.instance.setFont(_ultra_rfont("Regular",36 if selected else 30))
                    title.instance.setForegroundColor(parseColor("#ffffff" if selected else "#c9ccd1"))
                title.setText(label);title.show()
            except Exception:pass
            try:
                counter=self["search_root_count%d"%slot]
                if counter.instance is not None:
                    counter.instance.move(ePoint(*_ultra_xy(x if selected else x+20,962 if selected else 949)));counter.instance.resize(eSize(*_ultra_wh(380 if selected else 340,52 if selected else 46)))
                    counter.instance.setForegroundColor(parseColor("#00E676" if selected else "#FFFFFF"))
                    counter.instance.setFont(_ultra_rfont("Regular",44 if selected else 36))
                counter.setText(str(int(count or 0)));counter.show()
            except Exception:pass
            state[slot]=selected
        self._search_gateway_visuals_bound=True

        for slot in range(self.PAGE_SIZE):
            try:
                art = self["result_art%d" % slot]
                if art.instance is not None:art.instance.setPixmap(None)
                art.hide()
            except Exception:pass
            self._set_label_if_changed(self["result_title%d" % slot], "")
            self._set_label_if_changed(self["result_meta%d" % slot], "")
            self._set_result_focus(slot, False)
        self._set_label_if_changed(self["page_label"], "")
        self._render_signature = ()
        self._render_slot_signatures = [None] * self.PAGE_SIZE
        self._render_art_identities = [None] * self.PAGE_SIZE
        self._render_art_start = None
        self._render_selected_slot = None

    def _show_search_gateway(self):
        self._search_gateway = True
        self._search_result_type = None
        self.index = 0
        self._advance_poster_generation()
        self._render_art_start = None
        self._render_selected_slot = None
        self._render()

    def _move_search_gateway(self, delta):
        self._search_gateway_index = (int(getattr(self, "_search_gateway_index", 0) or 0) + int(delta)) % 2
        self._render_search_gateway()

    def _open_search_gateway_bucket(self):
        movies, series = self._search_bucket_counts()
        slot = max(0, min(1, int(getattr(self, "_search_gateway_index", 0) or 0)))
        wanted = "vod" if slot == 0 else "series"
        count = movies if wanted == "vod" else series
        if int(count or 0) <= 0:
            return
        self._search_gateway = False
        self._search_result_type = wanted
        self.index = 0
        self._hide_search_gateway()
        self._render_art_start = None
        self._render_signature = ()
        self._render_selected_slot = None
        self._render()
