# -*- coding: utf-8 -*-
"""Player work origin metadata and playback entry.

Methods moved verbatim out of ``ContentDetailsScreen`` (ui_screens_details.py); behaviour is unchanged.
This module is imported by ui_screens_details.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str
from .ui_screens_details import (
    _,
    os,
)


class DetailsPlayMixin(object):
    """Player work origin metadata and playback entry."""

    def _player_work_origin_metadata(self):
        # Reuse the country already shown by Details, including its cached TMDB
        # fallback. Playback must not make another lookup or change audio tracks.
        from .services.origin_language import work_origin_metadata
        data=work_origin_metadata(getattr(self,"_tmdb_data",None),
                                  getattr(self,"_local_detail_cache",None),
                                  getattr(self,"item",None))
        country=str(getattr(self,"_country_raw","") or "").strip()
        if country:data["country_code"]=country
        return data

    def play(self):
        if self._busy:return
        if self.media_type == "series":
            
            series_payload=dict(self.item) if isinstance(self.item,dict) else self.item
            if isinstance(series_payload,dict):
                series_payload["_player_origin_metadata"]=self._player_work_origin_metadata()
                # Carry the already-resolved canonical HDD metadata into Seasons
                # and Episodes.  The child screen is intentionally fast-open and
                # must not lose country/genre/ratings/season count/title-logo id
                # merely because the source changed from Portal to Xtream/M3U.
                snap=(getattr(self,"_tmdb_data",None) or getattr(self,"_local_detail_cache",None) or {})
                if isinstance(snap,dict):
                    # Reuse validated Details metadata in RAM (identity check is
                    # repeated by ContentDetailsScreen before accepting it).
                    if snap and identity_cache_compatible(getattr(self,"_portal_item",self.item),snap):
                        series_payload["_ultra_detail_snapshot"]=dict(snap)
                    overlay=snap.get("item_overlay") if isinstance(snap.get("item_overlay"),dict) else {}
                    for key,value in overlay.items():
                        if value not in (None,"",[],{}):series_payload[key]=value
                    for key in ("tmdb_id","imdb_id","tvdb_id","year","rating","number_of_seasons","number_of_episodes","logo_url","poster_local","backdrop_local","original_language","countries","origin_country","production_countries","identity_verified","identity_pointer_verified","media_type"):
                        value=snap.get(key)
                        if value not in (None,"",[],{}):series_payload[key]=value
                    if snap.get("tmdb_id"):
                        series_payload["_locked_tmdb_id"]=snap.get("tmdb_id")
                        series_payload["_player_title_logo_tmdb_id"]=snap.get("tmdb_id")
                _logo_t=str(getattr(self,"_title_logo_cache_target","") or "")
                if _logo_t and os.path.isfile(_logo_t) and os.path.getsize(_logo_t)>256:
                    series_payload["_player_title_logo_cinematic_source"]=_logo_t
                    countries=snap.get("countries") or snap.get("production_countries") or snap.get("origin_country") or []
                    if countries and not series_payload.get("country"):
                        if isinstance(countries,(list,tuple)):series_payload["country"]=str(countries[0] or "")
                        else:series_payload["country"]=str(countries)
                    genres=snap.get("genres") or []
                    if genres:
                        if isinstance(genres,(list,tuple)):series_payload["genre"]=" / ".join(str(x) for x in genres[:3] if str(x or "").strip())
                        else:series_payload["genre"]=str(genres)
                    if snap.get("overview"):series_payload["description"]=snap.get("overview")
                    cast=snap.get("cast") or []
                    if cast:
                        series_payload["actors"]=(", ".join(str(x) for x in cast[:8]) if isinstance(cast,(list,tuple)) else str(cast))
                state=dict(getattr(self,"_details_visual_state",{}) or {})
                poster=str(getattr(self,"_adaptive_source_local","") or getattr(self,"_poster_authoritative_source","") or state.get("poster") or "")
                canonical=str(state.get("backdrop") or getattr(self,"_portal_backdrop_source_local","") or "")
                present=str(getattr(self,"_backdrop_displayed_path","") or state.get("backdrop_present") or getattr(self,"_portal_backdrop_present_local","") or "")
                if canonical and os.path.basename(canonical).startswith("us221_detail_"):
                    if not present:present=canonical
                    canonical=""
                if poster and os.path.isfile(poster):
                    series_payload["_adaptive_source_local"]=poster
                    series_payload["_ultra_palette_source"]=poster
                if canonical and os.path.isfile(canonical):series_payload["_backdrop_source_local"]=canonical
                if present and os.path.isfile(present):series_payload["_backdrop_present_local"]=present
                fast_bundle={}
                for key in ("poster","detail_poster","backdrop","backdrop_present","theme","accent","edge","chrome"):
                    value=state.get(key)
                    if value not in (None,"",{},[]):fast_bundle[key]=value
                if poster and os.path.isfile(poster):fast_bundle["poster"]=poster
                if canonical and os.path.isfile(canonical):fast_bundle["backdrop"]=canonical
                if present and os.path.isfile(present):fast_bundle["backdrop_present"]=present
                series_payload["_ultra_fast_bundle"]=fast_bundle
                prefetched=getattr(self,"_prefetched_series_seasons",None)
                if isinstance(prefetched,list) and prefetched:series_payload["_prefetched_series_seasons"]=list(dict(x) for x in prefetched if isinstance(x,dict))
            self.session.openWithCallback(lambda *args:self._restore_details_visual_state(),SeriesEpisodesScreen, self.profile, self.client, series_payload)
            return
        command=self.item.get("cmd") or self.item.get("command") or self.item.get("url")
        if not command:self["status"].setText(_("No stream command"));return
        self["status"].setText(_("Creating stream link..."))
        def ok(url):
            url=url if isinstance(url,str) else ""
            if not url.strip():
                from .ui_helpers import report_stream_link_failure
                report_stream_link_failure(self);return
            name=str(self.item.get("name") or self.item.get("title") or "Ultra Stalker stream")
            try:
                self["status"].setText(_("Opening player: %s") % name)
                def closed(result=None):
                    engine = result.get("engine") if isinstance(result, dict) else load_settings().get("service_type", 4097)
                    if isinstance(result,dict) and result.get("quality"):
                        try:
                            remember_content_quality(self.profile,self.media_type,self.item,result.get("quality"),result.get("video_width",0),result.get("video_height",0))
                            self["quality_text"].setText(str(result.get("quality") or ""))
                            self._refresh_detail_visuals()
                        except Exception as exc: optional_failure("ui.detail_quality_return",exc)
                    try:self._restore_details_visual_state()
                    except Exception as exc:optional_failure("ui.detail_player_restore",exc)
                    self["status"].setText(_("Player closed  •  engine %s") % engine)
                engine=_configured_playback_engine()
                payload=_player_payload(self.item, self.profile, media_type=self.media_type)
                payload["_player_client_ref"]=self.client
                payload["_player_origin_metadata"]=self._player_work_origin_metadata()
                # Player must continue the exact Details visual identity: same
                # authoritative poster source, then the same palette recipe.
                try:
                    _state=dict(getattr(self,"_details_visual_state",{}) or {})
                    _player_palette_source=str(
                        getattr(self,"_adaptive_source_local","") or
                        getattr(self,"_adaptive_authoritative_source","") or
                        getattr(self,"_poster_authoritative_source","") or
                        _state.get("poster") or _state.get("detail_poster") or ""
                    )
                    if _player_palette_source and os.path.isfile(_player_palette_source):
                        payload["_player_poster"]=_player_palette_source
                        payload["_adaptive_source_local"]=_player_palette_source
                        payload["_ultra_palette_source"]=_player_palette_source
                        if getattr(self,"_entry_visible_poster_locked",False):
                            payload["_ultra_visible_poster_locked"]=True
                            if isinstance(self.item,dict) and self.item.get("_player_poster_identity"):
                                payload["_player_poster_identity"]=self.item.get("_player_poster_identity")
                except Exception as exc:optional_failure("ui.detail_player_palette_handoff",exc)
                tmdb_data=getattr(self,"_tmdb_data",None) or getattr(self,"_local_detail_cache",None)
                _logo_t=str(getattr(self,"_title_logo_cache_target","") or "")
                if _logo_t and os.path.isfile(_logo_t) and os.path.getsize(_logo_t)>256:
                    payload["_player_title_logo_cinematic_source"]=_logo_t
                if isinstance(tmdb_data,dict):
                    poster_local=tmdb_data.get("poster_local")
                    existing=str(payload.get("_player_poster") or "")
                    if not (existing and os.path.isfile(existing)) and poster_local and os.path.isfile(poster_local):payload["_player_poster"]=poster_local
                    if tmdb_data.get("poster_url") and not payload.get("_player_poster_url"):payload["_player_poster_url"]=str(tmdb_data.get("poster_url"))
                    for _k in ("original_language","countries","origin_country","production_countries","identity_verified"):
                        if tmdb_data.get(_k) not in (None,"",[],{}):payload[_k]=tmdb_data.get(_k)
                    verified_id=tmdb_data.get("tmdb_id") or (self.item.get("_locked_tmdb_id") if isinstance(self.item,dict) else None)
                    if verified_id not in (None,""):
                        payload["_player_title_logo_tmdb_id"]=verified_id
                        payload["_locked_tmdb_id"]=verified_id
                        payload["tmdb_id"]=verified_id
                    payload["_player_title_logo_title"]=str(getattr(self,"_server_display_name","") or name)
                self.session.openWithCallback(closed, UltraStalkerPlayer, str(url).strip(), name, self.media_type, engine, payload)
            except Exception as exc:self["status"].setText(_("Player failed: %s")%exc)
        def link_failed(error):
            from .ui_helpers import report_stream_link_failure
            report_stream_link_failure(self,error)
        self._run_async(lambda handle:self.client.create_link(self.item,self.media_type,cancel_event=handle.cancel_event),ok,link_failed)
