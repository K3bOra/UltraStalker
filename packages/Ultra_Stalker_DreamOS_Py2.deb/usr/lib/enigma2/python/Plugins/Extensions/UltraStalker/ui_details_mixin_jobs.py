# -*- coding: utf-8 -*-
"""Hot snapshot persistence, job draining, poster visuals and first-paint components.

Methods moved verbatim out of ``ContentDetailsScreen`` (ui_screens_details.py); behaviour is unchanged.
This module is imported by ui_screens_details.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, max, us_func
from .ui_screens_details import (
    AsyncScreenMixin,
    ImageLoaderMixin,
    _details_backdrop_truth,
    canonical_dynamic_details_key,
    durable_view_path,
    hashlib,
    os,
    weakref,
)


from . import details_look as _look
from .log import optional_failure


class DetailsJobsMixin(object):
    """Hot snapshot persistence, job draining, poster visuals and first-paint components."""

    def _persist_portal_hot_snapshot(self):
        # Portal artwork is intentionally disabled for Movies/Series.
        # Keep the method as a compatibility no-op because old callbacks may
        # still call it while upgrading from previous builds.
        return

    def _drain_jobs(self):
        us_func(AsyncScreenMixin._drain_jobs)(self)
        if self._screen_closed:return
        self._drain_image_jobs()
        while True:
            try:
                payload=self._adaptive_jobs.get_nowait()
                token,source,chrome,theme_path,accent_path,fallback=payload[:6]
                edge=payload[6] if len(payload)>6 else None
            except queue.Empty:break
            if token!=self._adaptive_token or self._screen_closed:continue
            self._adaptive_pending_source=""
            try:
                if not self._adaptive_palette_locked and source and os.path.isfile(source):
                    self._adaptive_source_local=source
                    if theme_path and self["dynamic_bg"].instance is not None:
                        self["dynamic_bg"].instance.setPixmapFromFile(theme_path);self["dynamic_bg"].show()
                    # Legacy large poster accent frame is retired.  Preserve the
                    # path in state for compatibility, but never allocate/show it.
                    try:self["accent_frame"].hide()
                    except Exception:pass
                    if chrome:self._apply_detail_chrome(chrome)
                    if edge and os.path.isfile(edge) and self["cinematic_edge"].instance is not None:
                        self["cinematic_edge"].instance.setPixmapFromFile(edge);self["cinematic_edge"].show()
                    try:
                        self._details_visual_state.update({
                            "theme":theme_path if theme_path and os.path.isfile(theme_path) else "",
                            "accent":accent_path if accent_path and os.path.isfile(accent_path) else "",
                            "chrome":dict(chrome) if isinstance(chrome,dict) else {},
                            "edge":edge if edge and os.path.isfile(edge) else "",
                            "poster":str(getattr(self,"_image_displayed_path","") or source or ""),
                        })
                        self._persist_visual_bundle_async(self._details_visual_state,(getattr(self,"_tmdb_data",None) or getattr(self,"_local_detail_cache",None)))
                        self._persistent_adaptive_locked=True
                        self._schedule_search_visual_peer_sync(getattr(self,"_tmdb_data",None) or getattr(self,"_local_detail_cache",None))
                    except Exception as exc:optional_failure("ui.silent_guard",exc)
                    self._adaptive_palette_locked=True
                # R197: never use the poster/fallback as a temporary Details
                # backdrop.  That provisional rank-1 image was the first of the
                # visible two/three-backdrop swaps reported on receiver.  Hold the
                # screen background until the one approved landscape presentation
                # is ready instead.
            except Exception as exc:optional_failure("ui.poster_visual_apply",exc)
        while True:
            try:payload=self._backdrop_jobs.get_nowait()
            except queue.Empty:break
            try:
                token,path,rank=payload[:3]
                canonical_source=payload[3] if len(payload)>3 else ""
            except Exception:
                continue
            if token!=self._backdrop_token:continue
            try:
                rank=max(0,int(rank or 0))
                authority=str(getattr(self,"_details_backdrop_authority_source","") or "")
                if getattr(self,"_details_backdrop_authority_locked",False) and authority and canonical_source and os.path.abspath(str(canonical_source))!=os.path.abspath(authority):
                    continue
                if path and os.path.isfile(path) and rank>=getattr(self,"_backdrop_rank",0) and self["cinematic_bg"].instance is not None:
                    self["cinematic_bg"].instance.setPixmapFromFile(path);self["cinematic_bg"].show()
                    self._backdrop_rank=rank;self._backdrop_displayed_path=path;self._backdrop_present_pending="";self._details_visual_state["backdrop_present"]=path
                    if canonical_source and os.path.isfile(str(canonical_source)):
                        self._details_visual_state["backdrop"]=str(canonical_source)
                        if not getattr(self,"_details_backdrop_authority_locked",False):
                            self._details_backdrop_authority_source=str(canonical_source);self._details_backdrop_authority_locked=True
                    try:
                        self._persist_visual_bundle_async(self._details_visual_state,(getattr(self,"_tmdb_data",None) or getattr(self,"_local_detail_cache",None)))
                        self._persistent_backdrop_locked=True
                        self._persistent_backdrop_source_locked=bool(self._details_visual_state.get("backdrop") and os.path.isfile(str(self._details_visual_state.get("backdrop") or "")))
                        self._schedule_search_visual_peer_sync(getattr(self,"_tmdb_data",None) or getattr(self,"_local_detail_cache",None))
                    except Exception as exc:optional_failure("ui.silent_guard",exc)
                    except Exception as exc:optional_failure("ui.silent_guard",exc)
                    self._portal_backdrop_loaded=bool(rank>=2)
                    if rank>=4 and canonical_source and os.path.isfile(str(canonical_source)):
                        self._portal_backdrop_source_local=str(canonical_source)
                    if rank>=2:self._persist_portal_hot_snapshot()
                    if not getattr(self,"_runtime_artwork_logged",False) and rank>=2:
                        self._runtime_artwork_logged=True
                        _runtime_endurance_log("details_artwork_ready",media_type=self.media_type,rank=rank)
            except Exception as exc:optional_failure("ui.backdrop_rank_apply",exc)
        while True:
            try: token,path,lang=self._title_logo_jobs.get_nowait()
            except queue.Empty: break
            if token != self._title_logo_token or self._screen_closed: continue
            try:
                if path and os.path.isfile(str(path)) and self["title_logo"].instance is not None:
                    self["title_logo"].instance.setPixmapFromFile(str(path));self["title_logo"].show()
                else:
                    self["title_logo"].hide()
            except Exception as exc:optional_failure("ui.details_title_logo_apply",exc)
            finally:
                try:
                    if path and os.path.isfile(str(path)):os.remove(str(path))
                except Exception:pass
        while True:
            try: token,data=self._tmdb_jobs.get_nowait()
            except queue.Empty: break
            if token != self._tmdb_token or self._screen_closed: continue
            self._apply_tmdb_metadata(data)

    def _picture_ready(self, *args):
        # Poster decoding stays independent from the widescreen backdrop.  The
        # displayed poster is the one authoritative palette source for the
        # lifetime of this screen.  This removes the old portal/TMDB race where
        # a correct colour was repainted a moment later by another async job.
        us_func(ImageLoaderMixin._picture_ready)(self, *args)
        try:
            path=str(getattr(self,"_image_displayed_path","") or "")
            base=os.path.basename(path)
            if path and os.path.isfile(path) and base not in ("grid_placeholder_movie_921.png","grid_placeholder_series_921.png"):
                palette_source=getattr(self,"_adaptive_authoritative_source","") or getattr(self,"_poster_authoritative_source","") or path
                try:
                    if base.startswith("detailcover_"):
                        self._details_visual_state["detail_poster"]=path
                        if palette_source and os.path.isfile(str(palette_source)):
                            self._details_visual_state["poster"]=str(palette_source)
                    else:
                        self._details_visual_state["poster"]=path
                except Exception as exc:optional_failure("ui.silent_guard",exc)
                self._schedule_poster_visuals(palette_source)
                self._persist_portal_hot_snapshot()
        except Exception as exc:optional_failure("ui.poster_visual_schedule",exc)

    def _schedule_poster_visuals(self, path):
        """Apply/build adaptive Details chrome without GUI-thread HDD reads.

        The poster itself has already painted.  Reusing/building adaptive chrome
        is strictly second-paint work and must never delay Backdrop/Title Logo
        callbacks queued behind it on Enigma2's main loop.
        """
        path=str(path or "")
        if not _look.ADAPTIVE_COLORS:
            # Fixed glass: no poster-derived colour is built or shown (details_look.py).
            try:
                if path and os.path.isfile(path):self._adaptive_source_local=path
                self._adaptive_palette_locked=True
                for _name in ("dynamic_bg","cinematic_edge"):
                    try:self[_name].hide()
                    except Exception:pass
                self._apply_detail_chrome(None)
            except Exception as exc:optional_failure("ui.details_fixed_look",exc)
            return
        try:
            bundle=dict(getattr(self,"_persistent_visual_bundle",{}) or {})
            chrome=bundle.get("chrome") if isinstance(bundle.get("chrome"),dict) else {}
            complete=bool(bundle.get("theme") and os.path.isfile(str(bundle.get("theme") or "")) and chrome.get("panel_detail") and chrome.get("overview_detail"))
            if complete:
                self._persistent_adaptive_locked=True;self._adaptive_palette_locked=True
                self._adaptive_source_local=str(bundle.get("poster") or path or "")
                self._details_visual_state.update({
                    "poster":str(bundle.get("poster") or path or ""),"backdrop":str(bundle.get("backdrop") or ""),
                    "backdrop_present":str(bundle.get("backdrop_present") or ""),"detail_poster":str(bundle.get("detail_poster") or ""),
                    "theme":str(bundle.get("theme") or ""),"accent":str(bundle.get("accent") or ""),"edge":str(bundle.get("edge") or ""),"chrome":dict(chrome),
                })
                # No HDD reload here: the constructor already validated this bundle.
                self._restore_details_visual_state(reload_disk=False);return
        except Exception as exc:optional_failure("ui.details_ram_adaptive_reuse",exc)
        if not path or not os.path.isfile(path) or self._screen_closed:return
        if getattr(self,"_adaptive_pending_source","")==path:return
        self._adaptive_pending_source=path;self._adaptive_token+=1;token=self._adaptive_token
        cancel_event=self._details_cancel_event;adaptive_jobs=self._adaptive_jobs;screen_ref=weakref.ref(self)
        profile_copy=dict(self.profile or {});item_copy=dict(getattr(self,"_portal_item",self.item) or {})
        snap_copy=dict((getattr(self,"_tmdb_data",None) or getattr(self,"_local_detail_cache",None) or {}))
        def worker():
            try:
                if cancel_event.is_set():return
                # Disk lookup happens here, never on the GUI thread.  Another view
                # may have completed the exact adaptive package milliseconds ago.
                disk=_load_visual_bundle(profile_copy,self.media_type,item_copy,snapshot=snap_copy) or {}
                dchrome=disk.get("chrome") if isinstance(disk.get("chrome"),dict) else {}
                if disk.get("theme") and os.path.isfile(str(disk.get("theme") or "")) and dchrome.get("panel_detail") and dchrome.get("overview_detail"):
                    adaptive_jobs.put((token,str(disk.get("poster") or path),dchrome,str(disk.get("theme") or ""),str(disk.get("accent") or ""),None,str(disk.get("edge") or "")))
                    return
                stamp=str(os.path.getmtime(path));digest=hashlib.sha1((path+"|"+stamp+"|us64-details-local").encode("utf-8","ignore")).hexdigest()[:20]
                chrome=_build_dynamic_details_chrome(path,canonical_dynamic_details_key(path) or ("us64_"+digest)) or {}
                theme=_build_dynamic_details_gradient(path,durable_view_path("us64_%s_bg.jpg"%digest,source=path),(1920,1080)) or ""
                if cancel_event.is_set():return
                adaptive_jobs.put((token,path,chrome,theme,"","",None))
            except Exception as exc:
                screen=screen_ref()
                if screen is not None:screen._adaptive_pending_source=""
                optional_failure("ui.details_local_adaptive_build",exc)
        try:
            future=_DETAIL_PREFETCH_EXECUTOR.submit(worker,priority=2,_task_key="details-adaptive:%s"%str(getattr(self,"_details_content_key","") or id(self)))
            self._track_details_future(future)
        except Exception as exc:self._adaptive_pending_source="";optional_failure("ui.details_local_adaptive_submit",exc)

    def _persist_visual_bundle_async(self, payload=None, snapshot=None):
        """Persist presentation derivatives off the Enigma2 GUI thread."""
        try:
            state=dict(payload if isinstance(payload,dict) else (getattr(self,"_details_visual_state",{}) or {}))
            if not state:return
            profile_copy=dict(self.profile or {})
            item_copy=dict(getattr(self,"_portal_item",self.item) or {})
            snap_copy=dict(snapshot if isinstance(snapshot,dict) else ((getattr(self,"_tmdb_data",None) or getattr(self,"_local_detail_cache",None) or {})))
            key="details-persist:%s"%str(getattr(self,"_details_content_key","") or id(self))
            def worker():
                try:_save_visual_bundle(profile_copy,self.media_type,item_copy,state,snapshot=snap_copy)
                except Exception as exc:optional_failure("ui.details_visual_persist_bg",exc)
            future=_DETAIL_PREFETCH_EXECUTOR.submit(worker,priority=3,_task_key=key,_replace_task_key=True)
            self._track_details_future(future)
        except Exception as exc:optional_failure("ui.details_visual_persist_submit",exc)

    def _schedule_search_visual_peer_sync(self, data=None):
        """Search peer publishing is HDD maintenance, never first-paint GUI work."""
        if not list(getattr(self,"_search_visual_peers",[]) or []):return
        try:
            row=dict(data or {}) if isinstance(data,dict) else {}
            screen_ref=weakref.ref(self)
            key="details-peer-sync:%s"%str(getattr(self,"_details_content_key","") or id(self))
            def worker():
                screen=screen_ref()
                if screen is None or screen._screen_closed:return
                screen._sync_search_visual_peers(row)
            future=_DETAIL_PREFETCH_EXECUTOR.submit(worker,priority=3,_task_key=key,_replace_task_key=True)
            self._track_details_future(future)
        except Exception as exc:optional_failure("ui.details_peer_sync_submit",exc)

    def _load_cinematic_backdrop(self, portal_fallback=False):
        """Reuse only the verified local backdrop handed off by Cinematic/Grid.

        This does not inspect provider URLs and never performs network I/O. It
        simply lets Details display the exact HDD backdrop already accepted by
        the parent screen, eliminating the blank-background handoff regression.
        """
        authority=str(getattr(self,"_details_backdrop_authority_source","") or "")
        source=authority if getattr(self,"_details_backdrop_authority_locked",False) and authority else str(getattr(self,"_portal_backdrop_source_local","") or "")
        present="" if getattr(self,"_details_backdrop_authority_locked",False) else str(getattr(self,"_portal_backdrop_present_local","") or "")
        try:
            if present and _valid_cache_file(present) and self["cinematic_bg"].instance is not None:
                try:self["cinematic_bg"].instance.move(ePoint(*_ultra_xy(300,0)));self["cinematic_bg"].instance.resize(eSize(*_ultra_wh(1620,670)))
                except Exception as exc:optional_failure("ui.details_handoff_present_geometry",exc)
                self["cinematic_bg"].instance.setPixmapFromFile(present);self["cinematic_bg"].show()
                self._backdrop_rank=max(4,int(getattr(self,"_backdrop_rank",0) or 0));self._backdrop_displayed_path=present
                self._details_visual_state["backdrop_present"]=present
                if source and _details_backdrop_truth(source):self._details_visual_state["backdrop"]=source
                return
        except Exception as exc:optional_failure("ui.details_handoff_present",exc)
        if not _details_backdrop_truth(source):return
        try:
            target=self._backdrop_presentation_target(source)
            if target and _valid_cache_file(target):
                if self["cinematic_bg"].instance is not None:
                    self["cinematic_bg"].instance.setPixmapFromFile(target);self["cinematic_bg"].show()
                    self._backdrop_rank=max(4,int(getattr(self,"_backdrop_rank",0) or 0));self._backdrop_displayed_path=target
                    self._details_visual_state["backdrop"]=source;self._details_visual_state["backdrop_present"]=target
            else:
                self._schedule_backdrop_presentation(source,4)
        except Exception as exc:optional_failure("ui.details_handoff_backdrop",exc)

    def _apply_first_paint_component(self, token, kind, payload):
        """Apply one verified artwork component without waiting for siblings."""
        if self._screen_closed or int(token)!=int(getattr(self,"_tmdb_token",0) or 0):return
        if not isinstance(payload,dict):return
        try:
            if kind=="identity":
                title=str(getattr(self,"_server_display_name","") or self["name"].getText() or payload.get("title") or "")
                if payload.get("tmdb_id"):
                    self._schedule_details_title_logo(payload,title)
                return
            if kind=="metadata":
                if payload.get("matched") and payload.get("tmdb_id"):
                    self._tmdb_jobs.put((token,payload))
                return
            if kind=="poster":
                poster=str(payload.get("poster_local") or "")
                # R5.234 single-poster session authority.  If Details was opened
                # from an already visible Grid/Cinematic poster, cache canonical
                # artwork normally but never replace the pixels the user entered with.
                if getattr(self,"_entry_visible_poster_locked",False) and getattr(self,"_poster_authoritative_source",""):
                    return
                payload_verified=bool(
                    payload.get("tmdb_id") and
                    (payload.get("identity_verified") or payload.get("identity_pointer_verified")) and
                    identity_cache_compatible(getattr(self,"_portal_item",self.item),payload)
                )
                if poster and os.path.isfile(poster) and (
                        payload_verified or
                        (not getattr(self,"_persistent_poster_locked",False) and
                         not getattr(self,"_poster_authoritative_source",""))):
                    # Provider/Grid art is first-paint only. A verified canonical
                    # poster must be allowed to supersede it, including a stale
                    # rounded derivative that was locked by an older identity.
                    if payload_verified:
                        self._persistent_poster_locked=False
                        self._persistent_detail_poster_locked=False
                        self._details_visual_state.pop("detail_poster",None)
                        self._details_visual_state.pop("detail_poster_source_fp",None)
                        bundle=dict(getattr(self,"_persistent_visual_bundle",{}) or {})
                        bundle.pop("detail_poster",None)
                        bundle.pop("detail_poster_source_fp",None)
                        bundle.pop("detail_poster_final",None)
                        self._persistent_visual_bundle=bundle
                    self._poster_authoritative_source=poster
                    if payload_verified or not getattr(self,"_adaptive_authoritative_source",""):
                        self._adaptive_authoritative_source=poster
                    self._details_visual_state["poster"]=poster
                    self._image_token += 1
                    self._decode_picture(poster)
                return
            if kind=="backdrop":
                # R197 single Details backdrop authority. Never paint the raw
                # component and then replace it with a crop/clean candidate. If
                # Cinematic handed us its already-clean winner, only that source
                # may be presented. Otherwise wait until the resolver marks one
                # clean source and present it once.
                authority=str(getattr(self,"_details_backdrop_authority_source","") or "")
                if getattr(self,"_details_backdrop_authority_locked",False) and authority:
                    self._schedule_backdrop_presentation(authority,5)
                    return
                backdrop=str(payload.get("backdrop_local") or "")
                sealed=bool(int(payload.get("clean_backdrop_selector_version") or 0)>=3 or (payload.get("identity_verified") and not payload.get("first_paint_stage")))
                if sealed and _details_backdrop_truth(backdrop):
                    self._details_backdrop_authority_source=backdrop;self._details_backdrop_authority_locked=True
                    self._portal_backdrop_source_local=backdrop;self._details_visual_state["backdrop"]=backdrop
                    self._schedule_backdrop_presentation(backdrop,5)
                return
        except Exception as exc:optional_failure("ui.details_first_paint_component",exc)
from .wqhd_layout import xy as _ultra_xy, wh as _ultra_wh
