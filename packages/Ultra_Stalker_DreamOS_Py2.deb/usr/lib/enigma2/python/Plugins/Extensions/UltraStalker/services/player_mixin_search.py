# -*- coding: utf-8 -*-
"""Search the same title on other servers from the player.

Methods moved verbatim out of ``UltraStalkerPlayer`` (player_native.py); behaviour is unchanged.
This module is imported by player_native.py once its module-level helpers exist, so the
names below are taken from that module (partially initialised at this point) on purpose.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from ..us_env import str, int, max, min, us_clear, us_casefold, us_func
from .player_native import (
    Screen,
    UltraInfobarVisibility,
    _,
    _PLAYER_BG_EXECUTOR,
    _cached_poster,
    _short_portal_label,
    content_digest,
    force_session_silence,
    load_profiles,
    load_settings,
    optional_failure,
    os,
    queue,
    re,
    threading,
    time,
)


class PlayerServerSearchMixin(object):
    """Search the same title on other servers from the player."""

    @staticmethod
    def _server_search_norm(value):
        return " ".join(us_casefold(str(value or "")).replace("_"," ").replace("-"," ").split())

    @staticmethod
    def _server_search_number(value):
        match=re.search(r"\d+",str(value or ""))
        try:return int(match.group(0)) if match else 0
        except Exception:return 0

    @staticmethod
    def _server_search_profile_key(profile):
        profile=profile if isinstance(profile,dict) else {}
        return (str(profile.get("portal") or "").rstrip("/").lower(),str(profile.get("mac") or "").upper())

    def _server_search_current_profile(self):
        profile={
            "portal":str((self.item or {}).get("_portal") or ""),
            "mac":str((self.item or {}).get("_mac") or ""),
            "name":str((self.item or {}).get("_server_name") or ""),
            "source_type":str((self.item or {}).get("_source_type") or ""),
            "allow_http_fallback":bool((self.item or {}).get("_allow_http_fallback",False)),
            "tls_mode":str((self.item or {}).get("_tls_mode") or "auto"),
            "device_profile":str((self.item or {}).get("_device_profile") or "auto"),
            "tls_fallback_accepted":bool((self.item or {}).get("_tls_fallback_accepted",False)),
            "http_fallback_accepted":bool((self.item or {}).get("_http_fallback_accepted",False)),
        }
        if profile.get("portal"):
            try:
                wanted=self._server_search_profile_key(profile)
                for idx,row in enumerate(load_profiles() or []):
                    if isinstance(row,dict) and self._server_search_profile_key(row)==wanted:
                        profile.update(dict(row));profile["_display_index"]=int(idx);break
            except Exception:pass
        return profile

    def _server_search_raw_title(self):
        item=self.item if isinstance(self.item,dict) else {}
        if self.media_type=="episode":
            for key in ("_raw_series_title","_series_title","series_title","series_name"):
                value=str(item.get(key) or "").strip()
                if value:return value
            parent=item.get("_quality_parent_item")
            if isinstance(parent,dict):
                for key in ("_raw_name","name","title"):
                    value=str(parent.get(key) or "").strip()
                    if value:return value
        for key in ("_raw_name","name","title"):
            value=str(item.get(key) or "").strip()
            if value:return value
        return str(self.name or "").strip()

    @staticmethod
    def _server_search_source_type(profile):
        profile=profile if isinstance(profile,dict) else {}
        source_type=str(profile.get("source_type") or "").strip().lower()
        if source_type:return source_type
        portal=str(profile.get("portal") or "").lower()
        if ".m3u" in portal or "type=m3u" in portal or "output=m3u" in portal or ("get.php" in portal and ("username=" in portal or "password=" in portal)):
            return "m3u"
        return "stalker"

    @classmethod
    def _server_search_source_name(cls,profile,pos=0):
        profile=profile if isinstance(profile,dict) else {}
        name=str(profile.get("name") or "").strip()
        if name:return name
        try:display_index=int(profile.get("_display_index"))
        except Exception:display_index=int(pos or 0)
        return ((_("Xtream %d") if cls._server_search_source_type(profile)=="m3u" else _("Portal %d"))%(display_index+1))

    @classmethod
    def _player_server_label(cls,profile,pos=0):
        """Stable Player-only label: source type + global configured slot.

        Custom profile names remain available to Search/manager screens, but the
        Player deliberately shows only Portal N / Xtream N so long user labels
        never spill into playback metadata.
        """
        profile=profile if isinstance(profile,dict) else {}
        try:display_index=int(profile.get("_display_index"))
        except Exception:display_index=int(pos or 0)
        source_type=cls._server_search_source_type(profile)
        if source_type=="local":
            return "Local"
        kind="Xtream" if source_type=="m3u" else "Portal"
        return "%s %d"%(kind,display_index+1)

    @classmethod
    def _server_search_new_client(cls,profile,timeout=5):
        profile=dict(profile or {})
        source_type=cls._server_search_source_type(profile)
        if source_type=="m3u":
            from ..m3u_adapter import M3UClient
            return M3UClient(profile.get("portal"),profile.get("mac") or "M3U",timeout=max(3,int(timeout or 5)))
        from ..client import StalkerClient
        return StalkerClient(
            profile.get("portal"),profile.get("mac"),timeout=max(3,int(timeout or 5)),
            allow_http_fallback=profile.get("allow_http_fallback",False),
            tls_mode=profile.get("tls_mode","auto"),device_profile=profile.get("device_profile","auto"),
            allow_tls_fallback=profile.get("tls_fallback_accepted",False),
            http_fallback_accepted=profile.get("http_fallback_accepted",False),
        )

    def _server_search_begin_hold(self):
        self._server_search_mode_active=True
        if not self._server_search_locked:
            self._server_search_locked=True
            try:us_func(UltraInfobarVisibility.lockShow)(self)
            except Exception as exc:optional_failure("player.server_search_lock",exc)
        try:self.hideTimer.stop()
        except Exception:pass
        try:us_func(UltraInfobarVisibility.doShow)(self)
        except Exception:pass

    def _server_search_end_hold(self,hide_infobar=False):
        overlay=getattr(self,"_server_search_inline_overlay",None)
        try:
            if overlay is not None and overlay.active:overlay.hide()
        except Exception as exc:optional_failure("player.server_search_hide",exc)
        self._server_search_mode_active=False
        if self._server_search_locked:
            self._server_search_locked=False
            try:us_func(UltraInfobarVisibility.unlockShow)(self)
            except Exception as exc:optional_failure("player.server_search_unlock",exc)
        try:self["player_actions"].setEnabled(True);self["hard_exit_actions"].setEnabled(True)
        except Exception:pass
        if hide_infobar:
            try:self.hideTimer.stop()
            except Exception:pass
            try:
                self._us_infobar_visible=False
                us_func(Screen.hide)(self)
            except Exception:pass
        else:
            try:us_func(UltraInfobarVisibility.doShow)(self)
            except Exception:pass

    def _server_search_overlay_close(self):
        self._server_search_end_hold(hide_infobar=True)

    def _server_search_overlay_show(self,choices,selection=0,on_accept=None):
        self._server_search_begin_hold()
        frames=dict(getattr(self,"_player_chrome_frames",{}) or {})
        source=str(getattr(self,"_player_chrome_source","") or "")
        if not (source and os.path.isfile(source)):
            try:source=str(_cached_poster(self.item,self.name,self.media_type) or "")
            except Exception:source=""
        if not (source and os.path.isfile(source)):
            candidate=str(frames.get("main") or "")
            if candidate and os.path.isfile(candidate):source=candidate
        try:self["player_actions"].setEnabled(False);self["hard_exit_actions"].setEnabled(False)
        except Exception:pass
        return self._server_search_inline_overlay.show(
            choices,selection=selection,center_x=960,anchor_bottom=780,
            on_accept=on_accept,on_close=self._server_search_overlay_close,
            min_card_w=220,max_card_w=560,padding=38,
            visual_style="player_premium",row_h=70,max_visible=5,
            adaptive_source=source,adaptive_accent=frames.get("accent"),
            adaptive_accent_soft=frames.get("accent_soft"),
        )

    def serverSearch(self):
        """BLUE: explicit raw-title server search for Live, Movies and Series episodes."""
        if self.media_type not in ("itv","live","vod","series","episode"):
            try:self["connection"].setText(_("Search"));us_func(UltraInfobarVisibility.doShow)(self)
            except Exception:pass
            return False
        # If a search workflow is already active, BLUE simply re-opens the cached
        # server list. No second network scan is started.
        if self._server_search_mode_active and self._server_search_results:
            return self._server_search_show_results()
        raw=self._server_search_raw_title()
        if not raw:
            try:self["connection"].setText(_("No matching content"));us_func(UltraInfobarVisibility.doShow)(self)
            except Exception:pass
            return False
        self._server_search_query=raw
        # If the subtitle picker is open, close only that picker first. Search
        # then owns the same InfoBar region and the same modal input grammar.
        try:
            if getattr(self,"_subtitle_inline_overlay",None) is not None and self._subtitle_inline_overlay.active:
                self._subtitle_inline_finish()
        except Exception:pass
        label=_("Search")+"  •  "+raw
        return self._server_search_overlay_show([(label,"search")],0,self._server_search_hub_selected)

    def _server_search_hub_selected(self,choice=None):
        action=choice[1] if isinstance(choice,(tuple,list)) and len(choice)>1 else choice
        if action!="search":
            return self._server_search_overlay_close()
        return self._server_search_start()

    def _server_search_candidate_score(self,row,query):
        row=row if isinstance(row,dict) else {}
        title=str(row.get("name") or row.get("title") or "").strip()
        q=self._server_search_norm(query);t=self._server_search_norm(title)
        if not q or not t:return 99
        if t==q:return 0
        if q in t:return 1
        if t in q:return 2
        return 99

    def _server_search_start(self):
        self._server_search_begin_hold()
        try:
            if self._server_search_inline_overlay.active:self._server_search_inline_overlay.hide()
        except Exception:pass
        try:self["player_actions"].setEnabled(True);self["hard_exit_actions"].setEnabled(True)
        except Exception:pass
        self._server_search_generation+=1
        generation=self._server_search_generation
        try:self._server_search_cancel.set()
        except Exception:pass
        self._server_search_cancel=threading.Event()
        cancel_event=self._server_search_cancel
        query=str(self._server_search_query or self._server_search_raw_title() or "").strip()
        self._server_search_results=[]
        self._server_search_last_index=0
        try:self["connection"].setText(_("Searching...") );us_func(UltraInfobarVisibility.doShow)(self)
        except Exception:pass
        media_types=("series",) if self.media_type=="episode" else (("itv",) if self.media_type in ("itv","live") else ("vod",))
        current_profile=self._server_search_current_profile()
        current_key=self._server_search_profile_key(current_profile)
        q=self._server_search_queue
        settings=load_settings()

        def worker():
            profiles=[]
            for _idx,_row in enumerate(load_profiles() or []):
                if not isinstance(_row,dict):continue
                _p=dict(_row);_p.setdefault("_display_index",int(_idx));profiles.append(_p)
            if current_profile.get("portal") and current_key not in list(self._server_search_profile_key(p) for p in profiles):
                current_copy=dict(current_profile);current_copy.setdefault("_display_index",int(len(profiles)));profiles.insert(0,current_copy)
            def pri(p):
                if self._server_search_profile_key(p)==current_key:return (0,0)
                return (1 if self._server_search_source_type(p)=="m3u" else 2,0)
            profiles=sorted(profiles,key=pri)
            jobs=queue.Queue()
            for pos,p in enumerate(profiles):jobs.put((pos,p))
            found=[];found_lock=threading.RLock();stop=threading.Event();deadline=time.monotonic()+28.0

            def one_source(pos,profile):
                if cancel_event.is_set() or stop.is_set():return
                client=None
                try:
                    source_type=self._server_search_source_type(profile)
                    client=self._server_search_new_client(profile,timeout=min(5,int(settings.get("timeout",10) or 10)))
                    budget=14.0 if source_type=="m3u" else (9.0 if self._server_search_profile_key(profile)==current_key else 6.0)
                    pages=60 if source_type=="m3u" else (24 if self._server_search_profile_key(profile)==current_key else 16)
                    local_stop=threading.Event()
                    class _SourceCancel(object):
                        def is_set(_self):
                            return bool(cancel_event.is_set() or stop.is_set() or local_stop.is_set())
                    source_cancel=_SourceCancel()
                    best=[99,None]
                    published=[99]
                    def publish_candidate(row,score):
                        if not isinstance(row,dict) or score>=99:return
                        if score>published[0]:return
                        record={
                            "profile":dict(profile),
                            "name":self._server_search_source_name(profile,pos),
                            "item":dict(row),
                            "copies":[dict(row)],
                            "source_type":source_type,
                            "position":int(pos),
                            "score":int(score),
                        }
                        with found_lock:
                            key=self._server_search_profile_key(profile)
                            replaced=False
                            for idx,old in enumerate(found):
                                if self._server_search_profile_key(old.get("profile") or {})==key:
                                    if int(old.get("score",99))>=int(score):found[idx]=record
                                    replaced=True;break
                            if not replaced:found.append(record)
                        published[0]=int(score)
                        q.put(("search_update",generation,record,None))
                    def on_partial(rows):
                        for row in rows or []:
                            if not isinstance(row,dict):continue
                            score=self._server_search_candidate_score(row,query)
                            if score<best[0]:best[0]=score;best[1]=dict(row)
                            # Publish an exact/decorated raw-title hit immediately.
                            if score<=1:publish_candidate(row,score)
                            # Exact raw identity is authoritative; stop scanning this
                            # source while the remaining servers continue in parallel.
                            if score==0:local_stop.set();break
                    rows=client.search_content_fast(query,media_types=media_types,limit=24,max_pages=pages,cancel_event=source_cancel,time_budget=budget,on_partial=on_partial) or []
                    ranked=[]
                    for row in rows:
                        if not isinstance(row,dict):continue
                        score=self._server_search_candidate_score(row,query)
                        if score<99:ranked.append((score,row))
                    if best[1] is not None:ranked.append((best[0],best[1]))
                    if not ranked:return
                    ranked.sort(key=lambda x:x[0])
                    score,row=ranked[0]
                    record={
                        "profile":dict(profile),
                        "name":self._server_search_source_name(profile,pos),
                        "item":dict(row),
                        "copies":list(dict(x[1]) for x in ranked[:8]),
                        "source_type":source_type,
                        "position":int(pos),
                        "score":int(score),
                    }
                    publish_candidate(row,score)
                except Exception as exc:
                    optional_failure("player.server_search_source",exc)
                finally:
                    if client is not None:
                        try:client.close()
                        except Exception:pass

            def run_jobs():
                while not stop.is_set() and not cancel_event.is_set() and time.monotonic()<deadline:
                    try:pos,profile=jobs.get_nowait()
                    except queue.Empty:return
                    one_source(pos,profile)

            threads=[]
            for idx in range(min(6,jobs.qsize())):
                t=threading.Thread(target=run_jobs,name="ultrastalker-player-search-%d"%idx,daemon=True);t.start();threads.append(t)
            while time.monotonic()<deadline and not cancel_event.is_set():
                if not any(t.is_alive() for t in threads):break
                time.sleep(0.05)
            stop.set()
            for t in threads:
                try:t.join(0.2)
                except Exception:pass
            # One row per configured source, stable in configured order.
            unique={}
            for record in found:
                key=self._server_search_profile_key(record.get("profile") or {})
                if key not in unique:unique[key]=record
            result=sorted(unique.values(),key=lambda r:int(r.get("position",999)))
            q.put(("search",generation,result,None))

        try:
            self._server_search_future=_PLAYER_BG_EXECUTOR.submit(worker)
            self.server_search_timer.stop();self.server_search_timer.start(100,False)
            return True
        except Exception as exc:
            optional_failure("player.server_search_start",exc)
            try:self["connection"].setText(_("Unknown error"))
            except Exception:pass
            return False

    def _server_search_show_results(self):
        results=list(self._server_search_results or [])
        overlay=getattr(self,"_server_search_inline_overlay",None)
        if not results:
            try:self["connection"].setText(_("No matching content"))
            except Exception:pass
            raw=str(self._server_search_query or self._server_search_raw_title() or "")
            return self._server_search_overlay_show([(_("Search")+"  •  "+raw,"search")],0,self._server_search_hub_selected)
        choices=[(str(r.get("name") or _("Portal server")),r) for r in results]
        try:
            if overlay is not None and overlay.active:
                live_idx=int(overlay.selected_index())
                if live_idx>=0:self._server_search_last_index=live_idx
        except Exception:pass
        idx=max(0,min(int(self._server_search_last_index or 0),len(choices)-1))
        return self._server_search_overlay_show(choices,idx,self._server_search_server_selected)

    def _server_search_server_selected(self,choice=None):
        if not choice:return self._server_search_show_results()
        try:record=choice[1]
        except Exception:return self._server_search_show_results()
        if not isinstance(record,dict):return self._server_search_show_results()
        try:
            idx=[self._server_search_profile_key(x.get("profile") or {}) for x in self._server_search_results].index(self._server_search_profile_key(record.get("profile") or {}))
            self._server_search_last_index=idx
        except Exception:pass
        self._server_search_begin_hold()
        try:self["player_actions"].setEnabled(True);self["hard_exit_actions"].setEnabled(True)
        except Exception:pass
        name=str(record.get("name") or _("Portal server"))
        try:self["connection"].setText(_("Opening player: %s") % name);us_func(UltraInfobarVisibility.doShow)(self)
        except Exception:pass
        self._server_search_generation+=1
        generation=self._server_search_generation
        try:self._server_search_cancel.set()
        except Exception:pass
        self._server_search_cancel=threading.Event();cancel_event=self._server_search_cancel
        q=self._server_search_queue
        target_season=self._server_search_number((self.item or {}).get("_season_number") or (self.item or {}).get("season_number") or (self.item or {}).get("season"))
        target_episode=self._server_search_number((self.item or {}).get("_episode_number") or (self.item or {}).get("episode_number") or (self.item or {}).get("episode") or (self.item or {}).get("number"))
        query=str(self._server_search_query or self._server_search_raw_title() or "")

        def resolve_worker():
            client=None
            try:
                profile=dict(record.get("profile") or {})
                client=self._server_search_new_client(profile,timeout=7)
                source_item=dict(record.get("item") or {})
                history_item=dict(source_item)
                if self.media_type=="episode":
                    if not target_season or not target_episode:raise RuntimeError("Episode identity unavailable")
                    seasons=client.series_seasons(source_item,cancel_event=cancel_event) or []
                    season_item=None
                    for row in seasons:
                        if not isinstance(row,dict):continue
                        n=self._server_search_number(row.get("season_number") or row.get("season") or row.get("name") or row.get("title") or row.get("id"))
                        if n==target_season:season_item=dict(row);break
                    if season_item is None:raise RuntimeError("Season %d unavailable"%target_season)
                    episodes=client.series_episodes(source_item,season_item,cancel_event=cancel_event) or []
                    episode_item=None
                    for row in episodes:
                        if not isinstance(row,dict):continue
                        n=self._server_search_number(row.get("episode_number") or row.get("episode") or row.get("number") or row.get("name") or row.get("title") or row.get("id"))
                        if n==target_episode:episode_item=dict(row);break
                    if episode_item is None:raise RuntimeError("Episode %d unavailable"%target_episode)
                    episode_id=episode_item.get("id") or episode_item.get("episode_id") or episode_item.get("series") or episode_item.get("number")
                    url=client.create_link(episode_item,"series",episode_id,cancel_event=cancel_event)
                    history_item=dict(episode_item)
                    sid=source_item.get("series_id") or source_item.get("id") or source_item.get("series_uid")
                    if sid not in (None,""):history_item["_series_id"]=sid
                    history_item["_series_title"]=query;history_item["_raw_series_title"]=query
                    history_item["_season_number"]=target_season;history_item["_episode_number"]=target_episode
                elif self.media_type in ("itv","live"):
                    url=client.create_link(source_item,"itv",cancel_event=cancel_event)
                    history_item=dict(source_item)
                else:
                    url=client.create_link(source_item,"vod",cancel_event=cancel_event)
                url=str(url or "").strip()
                if not url:raise RuntimeError("Empty stream URL")
                q.put(("switch",generation,{"url":url,"client":client,"profile":profile,"history_item":history_item,"server_name":name},None))
                client=None
            except Exception as exc:
                q.put(("switch",generation,None,exc))
            finally:
                if client is not None:
                    try:client.close()
                    except Exception:pass

        try:
            self._save_history_progress(force=True)
        except Exception:pass
        try:
            self._server_search_future=_PLAYER_BG_EXECUTOR.submit(resolve_worker)
            self.server_search_timer.stop();self.server_search_timer.start(100,False)
            return True
        except Exception as exc:
            optional_failure("player.server_switch_start",exc)
            try:self["connection"].setText(_("Unknown error")+"  •  "+name)
            except Exception:pass
            return self._server_search_show_results()

    def _drain_server_search_result(self):
        if self.restored or self._closing_playback:
            try:self.server_search_timer.stop()
            except Exception:pass
            return
        processed=False
        while True:
            try:kind,generation,payload,error=self._server_search_queue.get_nowait()
            except queue.Empty:break
            except Exception:break
            processed=True
            if int(generation or 0)!=int(self._server_search_generation or 0):
                # A late successful switch owns an isolated client. Close it if
                # the user already started another search/switch generation.
                if kind=="switch" and isinstance(payload,dict):
                    stale=payload.get("client")
                    if stale is not None:
                        try:stale.close()
                        except Exception:pass
                continue
            if kind=="search_update":
                record=dict(payload or {}) if isinstance(payload,dict) else {}
                if record:
                    first_result=not bool(self._server_search_results)
                    key=self._server_search_profile_key(record.get("profile") or {})
                    merged=[];replaced=False
                    for old in list(self._server_search_results or []):
                        if self._server_search_profile_key(old.get("profile") or {})==key:
                            if int(record.get("score",99))<=int(old.get("score",99)):merged.append(record)
                            else:merged.append(old)
                            replaced=True
                        else:merged.append(old)
                    if not replaced:merged.append(record)
                    self._server_search_results=sorted(merged,key=lambda r:int(r.get("position",999)))
                    try:self["connection"].setText(_("Searching...")+"  •  %d"%len(self._server_search_results))
                    except Exception:pass
                    # Keep the visible server list live: first paint appears
                    # immediately, then later sources are appended/refined while
                    # preserving the user's current selection row.
                    if first_result or (getattr(self,"_server_search_inline_overlay",None) is not None and self._server_search_inline_overlay.active):
                        self._server_search_show_results()
            elif kind=="search":
                self._server_search_future=None
                self._server_search_results=list(payload or [])
                if self._server_search_results:
                    try:self["connection"].setText(_("Done")+"  •  %d"%len(self._server_search_results))
                    except Exception:pass
                    self._server_search_show_results()
                else:
                    try:self["connection"].setText(_("No matching content"))
                    except Exception:pass
                    self._server_search_show_results()
            elif kind=="switch":
                self._server_search_future=None
                if error or not isinstance(payload,dict):
                    name=""
                    try:
                        if 0<=self._server_search_last_index<len(self._server_search_results):name=str(self._server_search_results[self._server_search_last_index].get("name") or "")
                    except Exception:pass
                    try:self["connection"].setText(_("Unknown error")+("  •  "+name if name else ""))
                    except Exception:pass
                    self._server_search_show_results()
                    continue
                self._arm_recovery_resume()
                self._cancel_pending_resume_for_manual_seek()
                self._native_resume_started=False;self.resume_prompted=False
                old_url=str(self.streamurl or "")
                self._suppress_service_events(1.25)
                try:force_session_silence(self.session,old_url,force=True,stop_native=True,exclude_pids=self._external_player_baseline,owned_pids=self._owned_external_pids)
                except Exception as exc:optional_failure("player.server_switch_stop",exc)
                us_clear(self._owned_external_pids)
                try:
                    from ..core.playback_buffer import stop_buffer
                    stop_buffer(getattr(self,"_buffer_job",None));self._buffer_job=None
                except Exception:pass
                self._disable_online_subtitles();self._external_subtitle_stop()
                self._online_subtitle_generation+=1;self._online_subtitle_cancel.set()
                new_client=payload.get("client")
                old_owned=getattr(self,"_server_search_owned_client",None)
                if old_owned is not None and old_owned is not new_client:
                    try:old_owned.close()
                    except Exception:pass
                self._server_search_owned_client=new_client
                profile=dict(payload.get("profile") or {})
                history_item=dict(payload.get("history_item") or {})
                self._history_profile={"portal":str(profile.get("portal") or ""),"mac":str(profile.get("mac") or "")}
                self._history_item=history_item
                for key in ("id","episode_id","cmd","command","url","series_id","_series_id","series","number"):
                    self.item.pop(key,None)
                saved_position=int(self.item.get("_resume_position") or 0)
                saved_duration=int(self.item.get("_resume_duration") or 0)
                self.item.update(history_item)
                self.item["_resume_position"]=saved_position
                self.item["_resume_duration"]=saved_duration
                self.item["_history_item"]=dict(history_item)
                # The original Series screen owns next-episode navigation and
                # its provider client. Retain that navigation item unchanged;
                # never feed a different provider's episode into that client.
                try:self._subtitle_session_key=content_digest(self._history_profile,self.media_type,history_item)
                except Exception:self._subtitle_session_key=""
                self.item["_player_client_ref"]=new_client
                if self.media_type in ("itv","live"):self.item["_live_client_ref"]=new_client
                self.item["_portal"]=str(profile.get("portal") or "")
                self.item["_mac"]=str(profile.get("mac") or "")
                self.item["_source_type"]=str(profile.get("source_type") or self._server_search_source_type(profile))
                self.item["_server_name"]=str(payload.get("server_name") or self._server_search_source_name(profile,0))
                self.item["_allow_http_fallback"]=bool(profile.get("allow_http_fallback",False))
                self.item["_tls_mode"]=str(profile.get("tls_mode") or "auto")
                self.item["_device_profile"]=str(profile.get("device_profile") or "auto")
                self.item["_tls_fallback_accepted"]=bool(profile.get("tls_fallback_accepted",False))
                self.item["_http_fallback_accepted"]=bool(profile.get("http_fallback_accepted",False))
                self.streamurl=str(payload.get("url") or "")
                self._buffer_direct_url=self.streamurl
                self._active_server_name=self._player_server_label(profile,0)
                try:
                    self["server_name"].setText(_short_portal_label(self._active_server_name))
                    if self._lb_active():self._lb_layout_right(force=True)
                except Exception:pass
                self._lb_vod_meta_cache=None;self._lb_ep_name_cache=None
                if self.media_type in ("itv","live"):
                    # A cross-server Live handoff must never reuse the previous
                    # server's category/drawer rows. Keep playback safe and let
                    # the newly selected source own any subsequent Live lookup.
                    self._zap_channels=[];self._zap_total=0;self._zap_page_loader=None;self._zap_categories=[]
                    self._zap_category_id=str(history_item.get("category_id") or history_item.get("genre_id") or "")
                    try:
                        _new_picon=self._provider_live_picon_cached(self.item)
                        if _new_picon:
                            self.item["_player_picon"]=_new_picon
                            self._load_live_picon(_new_picon)
                        else:
                            self._request_provider_live_picon(self.item)
                    except Exception:pass
                    try:self._apply_live_channel_title();self._refresh_live_epg()
                    except Exception:pass
                else:
                    try:self._configure_vod_title_area()
                    except Exception:pass
                self._cancel_smart_recovery();self._recovery_attempts=0
                try:self["connection"].setText(_("Portal server")+"  •  "+str(payload.get("server_name") or ""))
                except Exception:pass
                # Keep the search-mode InfoBar pinned after the handoff. BACK
                # releases this hold without leaving playback; BLUE reopens the
                # cached server list instantly.
                self._server_search_begin_hold()
                self.playStream(self.servicetype,self.streamurl)
        if processed:
            try:us_func(UltraInfobarVisibility.doShow)(self)
            except Exception:pass
        try:
            if self._server_search_future is None:self.server_search_timer.stop()
        except Exception:pass
