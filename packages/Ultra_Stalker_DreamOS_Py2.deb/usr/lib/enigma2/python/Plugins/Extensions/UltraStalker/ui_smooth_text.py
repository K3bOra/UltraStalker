# -*- coding: utf-8 -*-
"""Slow pixel-smooth scrolling for long descriptions (Details, Episodes,
Cinematic, Backdrop grids).

Same mechanism as the Poster Grid 3 info panel: a clipped eWidget viewport
holds one tall eLabel that is moved up one pixel at a time (1 px / 70 ms,
about one line every 2 s) with a hold at the top and at the end.

A screen keeps its normal label. The scroller is used only when the text does
not fit at a comfortable font size; otherwise nothing changes. If the pixel
scroller cannot be created, ``start`` returns False and the caller keeps its
old shrink-to-fit behaviour. Disable file:
/etc/enigma2/ultrastalker/disable_smooth_scroll (shared with Grid 3).
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str, int, round, max, min
os = _us_env.os
re = _us_env.re

try:
    from enigma import eTimer, eWidget, eLabel, gFont, gRGB, ePoint, eSize, getDesktop
except Exception:  # pragma: no cover - not on a receiver
    eTimer = eWidget = eLabel = gFont = gRGB = ePoint = eSize = getDesktop = None

from .log import optional_failure

SMOOTH_DISABLE_FILE = "/etc/enigma2/ultrastalker/disable_smooth_scroll"
STEP_MS = 70
START_HOLD = 5000
END_HOLD = 6000
_ARABIC = re.compile(r"[؀-ۿݐ-ݿࢠ-ࣿﭐ-﷿ﹰ-﻿]")


def _tag(screen, name):
    skin = str(getattr(screen, "skin", "") or "")
    match = re.search(r'<widget name="%s"[^>]*>' % re.escape(name), skin)
    return match.group(0) if match else ""


class SmoothTextScroller(object):
    def __init__(self, screen, name, halign="skin"):
        self.screen = screen
        self.name = name
        self.halign = halign  # "skin" (as the widget) or "auto" (Arabic -> right, else left)
        self.active = False
        self._box = None
        self._lab = None
        self._broken = False
        self._pos = 0
        self._max = 0
        self._phase = "hold_top"
        self._hid = False
        self._key = None
        self._timer = None
        self._conn = None
        self._tag = None

    # ------------------------------------------------------------------ setup
    def _scale_y(self):
        try:
            return max(0.5, float(getDesktop(0).size().height()) / 1080.0)
        except Exception:
            return 1.0

    def _skin_tag(self):
        if self._tag is None:
            self._tag = _tag(self.screen, self.name)
        return self._tag

    def _ensure(self):
        if self._broken or eWidget is None:
            return False
        base = self.screen[self.name].instance
        parent = getattr(self.screen, "instance", None)
        if base is None or parent is None:
            return False
        pos, size = base.position(), base.size()
        if self._box is None:
            self._box = eWidget(parent)
            try:self._box.setTransparent(True)
            except Exception:pass
            self._lab = eLabel(self._box)
            self._lab.setVAlign(eLabel.alignTop)
            try:self._lab.setTransparent(True)
            except Exception:pass
            tag = self._skin_tag()
            match = re.search(r'foregroundColor="#([0-9a-fA-F]{6})"', tag)
            try:self._lab.setForegroundColor(gRGB(int(match.group(1), 16) if match else 0xffffff))
            except Exception:pass
            if "shadowColor" in tag:
                try:
                    self._lab.setShadowColor(gRGB(0x000000))
                    self._lab.setShadowOffset(ePoint(1, 1))
                except Exception:pass
            match = re.search(r'zPosition="(\d+)"', tag)
            try:self._box.setZPosition(int(match.group(1)) if match else 6)
            except Exception:pass
            self._box.hide()
            self._timer = eTimer()
            try:self._conn = self._timer.timeout.connect(self._tick)
            except Exception:self._timer.callback.append(self._tick)
            try:
                self.screen.onExecEnd.append(self.pause)
                self.screen.onExecBegin.append(self.resume)
                self.screen.onClose.append(self.close)
            except Exception:pass
        # Geometry follows the real widget every time (screens re-place it).
        self._box.move(ePoint(int(pos.x()), int(pos.y())))
        self._box.resize(eSize(int(size.width()), int(size.height())))
        return True

    def _halign_for(self, text):
        mode = self.halign
        if mode == "auto":
            return eLabel.alignRight if _ARABIC.search(text or "") else eLabel.alignLeft
        match = re.search(r'halign="(\w+)"', self._skin_tag())
        value = match.group(1) if match else "left"
        return {"right": eLabel.alignRight, "center": eLabel.alignCenter}.get(value, eLabel.alignLeft)

    def _font_for(self, px):
        match = re.search(r'font="([^";]+);(\d+)"', self._skin_tag())
        name = match.group(1) if match else "Regular"
        from .wqhd_layout import font_size
        raw = int(px) if px else int(match.group(2) if match else 22)
        return gFont(name, font_size(raw) if px else raw)

    # ----------------------------------------------------------------- public
    def start(self, text, font_px=None):
        """Scroll ``text`` inside the widget's box. False = caller keeps its layout."""
        text = str(text or "").strip()
        if not text or self._broken:
            return False
        try:
            if os.path.exists(SMOOTH_DISABLE_FILE):
                self.stop()
                return False
            key = (text, int(font_px or 0))
            if self.active and key == self._key:
                self._hide_original()
                return True
            if not self._ensure():
                return False
            view_w = int(self._box.size().width())
            view_h = int(self._box.size().height())
            lab = self._lab
            lab.setFont(self._font_for(font_px))
            lab.setHAlign(self._halign_for(text))
            lab.resize(eSize(view_w, 8000))
            lab.setText(text)
            total = int(lab.calculateSize().height())
            if total <= view_h:
                self.stop()
                return False
            lab.resize(eSize(view_w, total + 8))
            lab.move(ePoint(0, 0))
            self._pos = 0
            self._max = total + 6 - view_h
            self._phase = "hold_top"
            self._key = key
            self._box.show()
            lab.show()
            self.active = True
            self._hide_original()
            if getattr(self.screen, "execing", True):
                self._timer.start(START_HOLD, True)
            return True
        except Exception as exc:
            optional_failure("smooth_text.start", exc)
            self._broken = True
            self.stop()
            return False

    def stop(self):
        """Back to the normal label (shown again only if the scroller hid it)."""
        was = self.active
        self.active = False
        self._key = None
        self._pos = 0
        self._phase = "hold_top"
        try:
            if self._timer is not None:
                self._timer.stop()
            if self._box is not None:
                self._box.hide()
        except Exception:
            pass
        if self._hid:
            self._hid = False
            try:
                if str(self.screen[self.name].getText() or "").strip():
                    self.screen[self.name].show()
            except Exception:
                pass
        return was

    def pause(self):
        try:
            if self._timer is not None:
                self._timer.stop()
        except Exception:
            pass

    def resume(self):
        if not self.active or self._timer is None:
            return
        delay = START_HOLD if self._phase == "hold_top" else (END_HOLD if self._phase == "hold_end" else STEP_MS)
        try:
            self._timer.start(delay, True)
        except Exception:
            pass

    def close(self):
        self.stop()
        try:
            if self._conn is not None:
                self._conn.disconnect()
        except Exception:
            pass
        self._conn = None
        try:
            if self._timer is not None and self._tick in self._timer.callback:
                self._timer.callback.remove(self._tick)
        except Exception:
            pass
        try:
            if self.pause in self.screen.onExecEnd:
                self.screen.onExecEnd.remove(self.pause)
            if self.resume in self.screen.onExecBegin:
                self.screen.onExecBegin.remove(self.resume)
            if self.close in self.screen.onClose:
                self.screen.onClose.remove(self.close)
        except Exception:
            pass
        self._broken = True

    # --------------------------------------------------------------- internals
    def _hide_original(self):
        try:
            self.screen[self.name].hide()
            self._hid = True
        except Exception:
            pass

    def _tick(self):
        if getattr(self.screen, "_screen_closed", False) or not getattr(self.screen, "execing", True) or not self.active:
            return
        phase = self._phase
        try:
            if phase == "hold_top":
                self._phase = "run"
                delay = STEP_MS
                self._hide_original()
            elif phase == "run":
                self._pos = min(self._max, self._pos + max(1, int(round(self._scale_y()))))
                self._lab.move(ePoint(0, -int(self._pos)))
                if self._pos >= self._max:
                    self._phase = "hold_end"
                    delay = END_HOLD
                else:
                    delay = STEP_MS
            else:
                self._pos = 0
                self._lab.move(ePoint(0, 0))
                self._phase = "hold_top"
                delay = START_HOLD
        except Exception as exc:
            optional_failure("smooth_text.tick", exc)
            self._broken = True
            self.stop()
            return
        self._timer.start(delay, True)


def scroller(screen, name, halign="skin"):
    """Per-screen, per-widget scroller (created lazily)."""
    store = screen.__dict__.setdefault("_smooth_text_scrollers", {})
    inst = store.get(name)
    if inst is None:
        inst = store[name] = SmoothTextScroller(screen, name, halign)
    return inst


def stop_all(screen):
    for inst in list((screen.__dict__.get("_smooth_text_scrollers") or {}).values()):
        inst.stop()
