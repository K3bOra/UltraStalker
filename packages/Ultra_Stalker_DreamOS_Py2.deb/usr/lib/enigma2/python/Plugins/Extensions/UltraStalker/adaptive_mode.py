# -*- coding: utf-8 -*-
"""Global Adaptive Colors switch (R5.171).

ON  : menus/frames take their colours from the poster (existing behaviour).
OFF : every adaptive surface uses ONE fixed palette/source, so the look stays the
      static Ultra Stalker glass while artwork, logos, text and the cursor are
      untouched.  The fixed source also gives constant cache keys, so OFF mode
      builds each chrome set once and reuses it for every title.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str, int, open
import functools
threading = _us_env.threading
os = _us_env.os
time = _us_env.time

_PKG = os.path.dirname(os.path.abspath(__file__))
FIXED_KEY = "fixedoff2"  # bumped: v1 was green-tinted


_ENABLED_CACHE = [None, 0.0]
_ENABLED_TTL = 2.0


def invalidate_adaptive_cache():
    """Called by save_settings so a toggle takes effect immediately."""
    _ENABLED_CACHE[0] = None


def adaptive_enabled():
    # R5.181: called many times per navigation settle; load_settings() deep-copies
    # the whole settings dict each call, so keep the answer for a short time.
    now = time.monotonic()
    cached = _ENABLED_CACHE[0]
    if cached is not None and (now - _ENABLED_CACHE[1]) < _ENABLED_TTL:
        return cached
    try:
        from .storage import load_settings
        value = bool(load_settings().get("adaptive_colors", False))
    except Exception:
        value = False
    _ENABLED_CACHE[0] = value
    _ENABLED_CACHE[1] = now
    return value


def is_static_source(path):
    """Packaged assets are already static: Settings/Portal/Home surfaces keep their look."""
    try:
        return os.path.abspath(str(path or "")).startswith(os.path.join(_PKG, "assets_fhd") + os.sep)
    except Exception:
        return False


def uses_fixed_palette(path):
    """True in OFF mode for artwork and for the constant stand-in source itself."""
    if adaptive_enabled():
        return False
    return (not is_static_source(path)) or os.path.abspath(str(path or "")) == fixed_source()


def fixed_source():
    """Existing static asset used as the constant 'artwork' in OFF mode."""
    path = os.path.join(_PKG, "assets_fhd", "ultra_bg_clean_1920x1080.png")
    return path if os.path.isfile(path) else ""


def fixed_palette():
    """Neutral black-glass pair, matching the Home card material (grey rim, near-black fill)."""
    return ((34, 34, 38), (16, 16, 19))


def fixed_variant(source_path, cache_key):
    """(source, key) to use for a chrome builder; unchanged while adaptive is ON."""
    if adaptive_enabled() or is_static_source(source_path):
        return source_path, cache_key
    src = fixed_source()
    if not src:
        return source_path, cache_key
    return src, FIXED_KEY


def _neutralize_png(path, selected):
    """Make one OFF-mode surface fixed material (once per file, sidecar marker).

    Normal surfaces: pure neutral grey glass (luma only, alpha kept) - no hue can
    tint them.  Selected surfaces: the bundled Home/Settings cursor material (the
    flag-coloured focus row) at the same exact size, so the cursor looks identical
    from the first paint and never changes when the neutral set swaps in.
    PIL channel ops only, fast on the receiver.
    """
    marker = path + ".fx2"
    try:
        if os.path.isfile(marker):
            return
        from PIL import Image
        with Image.open(path) as im:
            im = im.convert("RGBA")
            size = im.size
            out = None
            if selected:
                try:
                    from .ui_fixed_adaptive import fixed_exact_surface
                    cursor = fixed_exact_surface(size[0], size[1], True, "offsel")
                    if cursor and os.path.isfile(cursor):
                        with Image.open(cursor) as cim:
                            out = cim.convert("RGBA")
                            if out.size != size:
                                out = out.resize(size, Image.LANCZOS)
                except Exception:
                    out = None
            if out is None:
                r, g, b, a = im.split()
                luma = im.convert("L")
                if selected:
                    luma = luma.point(lambda v: int(v * 0.62 + 104 * 0.38))
                out = Image.merge("RGBA", (luma, luma, luma, a))
        tmp = "%s.tmp.%d.%d" % (path, os.getpid(), threading.get_ident())
        out.save(tmp, "PNG")
        os.replace(tmp, path)
        with open(marker, "w") as fh:
            fh.write("1")
    except Exception:
        pass


def _neutralize_result(result):
    try:
        if isinstance(result, dict):
            for value in result.values():
                v = str(value or "")
                if v.endswith(".png") and FIXED_KEY in os.path.basename(v) and os.path.isfile(v):
                    _neutralize_png(v, "selected" in os.path.basename(v))
    except Exception:
        pass
    return result


def fixed_chrome(func):
    """Decorator for builders shaped f(source_path, cache_key, ...)."""
    @functools.wraps(func)
    def wrapper(source_path, cache_key=None, *args, **kwargs):
        source_path, cache_key = fixed_variant(source_path, cache_key)
        result = func(source_path, cache_key, *args, **kwargs)
        if cache_key == FIXED_KEY:
            _neutralize_result(result)
        return result
    return wrapper


def accent_hex(value):
    """Accent hint passthrough while ON; the fixed Home accent while OFF."""
    if adaptive_enabled():
        return value
    try:
        from .ui_fixed_adaptive import fixed_value_color
        return "#%06x" % (int(fixed_value_color()) & 0xFFFFFF)
    except Exception:
        return "#74d8ff"
