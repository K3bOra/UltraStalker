# -*- coding: utf-8 -*-
"""Link creation and fast content/category search.

Methods moved verbatim out of ``M3UClient`` (m3u_adapter.py); behaviour is unchanged.
This module is imported by m3u_adapter.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, max, min, us_casefold
from .m3u_adapter import (
    LOG,
    time,
)


class M3USearchMixin(object):
    """Link creation and fast content/category search."""

    def create_link(self,item,media_type="itv",*args,**kwargs):
        if isinstance(item,dict):
            return str(item.get("url") or item.get("cmd") or item.get("command") or "")
        return str(item or "")

    def search_metadata_copies(self,query,media_type="vod",cancel_event=None,time_budget=4):
        """Use loaded rows or one Xtream all-list request, without walking folders."""
        needle=" ".join(us_casefold(str(query or "")).split())
        if not needle:return []
        typ="series" if str(media_type).lower() in ("series","tv") else "vod"
        sources=[list(self._items.get(typ,[]) or [])]
        all_loaded=False
        if self._xtream:
            all_rows=self._read_xtream_category_cache_shared(typ,"*")
            if isinstance(all_rows,list):sources.append(all_rows);all_loaded=True
            for cid in list((self._xtream_categories.get(typ) or {}).keys()):
                if cancel_event is not None and cancel_event.is_set():return []
                rows=self._read_xtream_category_cache_shared(typ,cid)
                if isinstance(rows,list):sources.append(rows)
        def select():
            out=[];seen=set()
            for rows in sources:
                for row in rows:
                    if cancel_event is not None and cancel_event.is_set():return out
                    if not isinstance(row,dict):continue
                    title=str(row.get("name") or row.get("title") or "")
                    if needle not in " ".join(us_casefold(title).split()):continue
                    marker=(str(row.get("id") or row.get("stream_id") or row.get("series_id") or title),
                            str(row.get("category_id") or ''),str(row.get("description") or row.get("plot") or ''))
                    if marker in seen:continue
                    seen.add(marker);out.append(dict(row))
                    if len(out)>=24:return out
            return out
        matches=select()
        last_attempt=dict(getattr(self,"_metadata_all_lookup_at",{}) or {})
        if self._xtream and not all_loaded and len(matches)<24 and (typ not in last_attempt or time.monotonic()-last_attempt[typ]>=60):
            # Some panels support this optional endpoint. An unsupported all-list
            # stays a bounded miss here; it never starts a hidden category crawl.
            action="get_series" if typ=="series" else "get_vod_streams"
            last_attempt[typ]=time.monotonic();self._metadata_all_lookup_at=last_attempt
            raw=self._xtream_request(action,None,timeout=max(1,min(4,float(time_budget))),cancel_event=cancel_event)
            rows=self._normalise_xtream_rows(typ,raw,"",cancel_event=cancel_event) if isinstance(raw,list) else []
            if rows:
                self._write_xtream_category_cache(typ,"*",rows)
                sources.append(rows);matches=select()
        return matches

    def search_content_fast(self,query,media_types=("vod","series"),limit=80,max_pages=40,cancel_event=None,time_budget=8,on_partial=None):
        """Progressive Movies/Series search for plain M3U and Xtream sources.

        Xtream panels are not consistent about returning the whole catalogue when
        ``get_vod_streams`` / ``get_series`` is called without ``category_id``.
        Browsing already uses the provider category IDs, so global search must use
        that same authoritative route instead of assuming the optional all-catalog
        form works.  Cached category rows are scanned first; uncached categories
        are then loaded one by one and matches are published immediately.
        """
        self._last_search_complete=False
        category_failed=False
        needle=" ".join(us_casefold(str(query or "")).replace("_"," ").replace("-"," ").split())
        if not needle:return []
        limit=max(1,int(limit or 80))
        search_deadline=time.monotonic()+max(2.0,float(time_budget or 8.0))
        out=[];seen=set()

        def publish_rows(rows,typ):
            for row in rows or []:
                if cancel_event is not None and cancel_event.is_set():return True
                if not isinstance(row,dict):continue
                hay=" ".join(us_casefold(str(row.get("name") or row.get("title") or "")+" "+str(row.get("description") or row.get("descr") or row.get("plot") or "")).replace("_"," ").replace("-"," ").split())
                if needle not in hay:continue
                ident=str(row.get("id") or row.get("stream_id") or row.get("series_id") or row.get("url") or row.get("name") or row.get("title") or "")
                key=(str(typ),ident)
                if key in seen:continue
                seen.add(key)
                item=dict(row);item["_search_media_type"]=typ;out.append(item)
                if callable(on_partial):
                    try:on_partial([dict(item)])
                    except Exception:pass
                if len(out)>=limit:return True
            return False

        # Credentialed Xtream sources use the exact category routing that powers
        # the normal browser.  This works on panels that return [] for the
        # non-standard "all categories" request and makes existing HDD category
        # caches immediately searchable.
        if self._xtream:
            self._ensure(cancel_event)
            type_pending=[]
            wanted=[]
            for typ in tuple(str(x).lower() for x in media_types):
                if typ=="live":typ="itv"
                if typ in ("itv","vod","series") and typ not in wanted:
                    wanted.append(typ)
            wanted.sort(key=lambda name: {"series":0,"vod":1,"itv":2}.get(name,9))
            for typ in wanted:
                if typ=="live":typ="itv"
                if typ not in ("itv","vod","series"):continue
                if cancel_event is not None and cancel_event.is_set():break
                mapping=dict(self._xtream_categories.get(typ,{}) or {})
                if not mapping:
                    try:
                        self._load_xtream(cancel_event)
                        mapping=dict(self._xtream_categories.get(typ,{}) or {})
                    except Exception as exc:
                        category_failed=True
                        LOG.warning("Xtream search category bootstrap failed %s: %s",typ,exc)
                # Search previously opened/cached folders first, so repeat searches
                # and normal browse->search transitions produce instant matches.
                pending=[]
                cached_rows=[]
                for cid in mapping.keys():
                    if cancel_event is not None and cancel_event.is_set():break
                    cached=self._read_xtream_category_cache_shared(typ,cid)
                    if isinstance(cached,list):
                        cached_rows.append(cached)
                    else:
                        pending.append(str(cid))
                for cached in cached_rows:
                    if publish_rows(cached,typ):return out
                type_pending.append((typ, pending))

            # Round-robin uncached folders so Series is not stuck behind every
            # Movie category when the search time runs out.
            while type_pending and time.monotonic() < search_deadline:
                if cancel_event is not None and cancel_event.is_set():
                    break
                progressed=False
                nxt=[]
                for typ, pending in type_pending:
                    if not pending:
                        continue
                    cid=pending.pop(0)
                    remain=search_deadline-time.monotonic()
                    if remain<=0:
                        break
                    progressed=True
                    try:
                        rows=self._load_xtream_category(typ,cid,cancel_event,request_timeout=max(5,min(12,int(remain)))) or []
                    except Exception as exc:
                        category_failed=True
                        LOG.debug("Xtream search category failed %s/%s: %s",typ,cid,exc)
                        rows=[]
                    if publish_rows(rows,typ):
                        return out
                    if pending:
                        nxt.append((typ, pending))
                type_pending=nxt
                if not progressed:
                    break
            self._last_search_complete=bool(not category_failed and not any(pending for typ,pending in type_pending) and time.monotonic()<search_deadline and not (cancel_event is not None and cancel_event.is_set()))
            return out

        # Plain M3U keeps the original local-catalogue path.
        for typ in tuple(str(x).lower() for x in media_types):
            if typ=="live":typ="itv"
            if cancel_event is not None and cancel_event.is_set():break
            try:rows=self.ordered_all(typ,"*",start_page=1,max_pages=max_pages,max_items=max(300,limit*12),cancel_event=cancel_event) or []
            except Exception:
                category_failed=True;rows=[]
            if len(rows)>=max(300,limit*12):category_failed=True
            if publish_rows(rows,typ):return out
        self._last_search_complete=not category_failed and not (cancel_event is not None and cancel_event.is_set())
        return out

    def search_category_fast(self,query,media_type="vod",category="*",limit=120,max_pages=18,cancel_event=None,time_budget=5):
        """Search one M3U/Xtream folder only.

        Xtream category loading is already lazy/persistently cached, so this is
        normally one category request (or HDD/RAM hit) followed by a local scan.
        Plain M3U sources are scanned from their already parsed local catalogue.
        """
        needle=" ".join(us_casefold(str(query or "")).replace("_"," ").replace("-"," ").split())
        if not needle:return []
        typ=str(media_type or "vod").lower();category=str(category if category not in (None,"") else "*")
        # A whole-section search must not download every folder before the first
        # match. Cached folders are scanned first and the walk stops at the limit.
        if category in ("*","") and self._xtream:
            budget=max(2.0,min(6.0,float(time_budget or 3.5)))
            return self.search_content_fast(query,(typ,),limit=max(1,int(limit or 48)),max_pages=max_pages,cancel_event=cancel_event,time_budget=budget) or []
        try:rows=self.ordered_all(typ,category,start_page=1,max_pages=max_pages,max_items=self.MAX_ITEMS if hasattr(self,"MAX_ITEMS") else 50000,cancel_event=cancel_event) or []
        except Exception:rows=[]
        out=[];seen=set()
        for row in rows:
            if cancel_event is not None and cancel_event.is_set():break
            if not isinstance(row,dict):continue
            hay=" ".join(us_casefold(str(row.get("name") or row.get("title") or "")+" "+str(row.get("description") or row.get("descr") or "")).replace("_"," ").replace("-"," ").split())
            if needle not in hay:continue
            ident=str(row.get("id") or row.get("stream_id") or row.get("series_id") or row.get("url") or row.get("name") or row.get("title") or "")
            if ident in seen:continue
            seen.add(ident);item=dict(row);item["_search_media_type"]=typ;out.append(item)
            if len(out)>=int(limit):break
        return out

    def search_content(self,query,media_types=("vod","series"),limit=80,max_pages=40,cancel_event=None,time_budget=8):
        return self.search_content_fast(query,media_types,limit,max_pages,cancel_event,time_budget)
