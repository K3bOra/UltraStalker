# -*- coding: utf-8 -*-
"""Recent-search keyboard integration and prompt.

Methods moved verbatim out of ``PortalGlobalSearchScreen`` (ui_screens_search.py); behaviour is unchanged.
This module is imported by ui_screens_search.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, us_text_callback, native_text
from .ui_screens_search import (
    ChoiceBox,
    InputBox,
    VirtualKeyBoard,
    _,
)


class SearchKeyboardMixin(object):
    """Recent-search keyboard integration and prompt."""

    def _open_recent_search_menu_for_keyboard(self, keyboard):
        try:
            recent = [str(x).strip() for x in (_load_recent_searches() or []) if str(x or "").strip()]
        except Exception:
            recent = []
        if not recent or ChoiceBox is None:
            return
        choices = list((term, term) for term in recent[:100])

        def picked(choice):
            if not choice:
                return
            try:
                term = choice[1] if isinstance(choice, (tuple, list)) and len(choice) > 1 else choice[0]
            except Exception:
                term = choice
            term = str(term or "").strip()
            if not term:
                return
            try:
                keyboard.close(term)
            except Exception as exc:
                optional_failure("ui.search_recent_keyboard_close", exc)

        try:
            # R36: the parent Search screen can temporarily lose its `session`
            # attribute while the stock VirtualKeyBoard owns the modal stack.
            # Use the active keyboard's session first, which remains valid for
            # the lifetime of the keyboard, then fall back to the parent only.
            owner_session = getattr(keyboard, "session", None) or getattr(self, "session", None)
            if owner_session is None:
                raise RuntimeError("No active session for recent search menu")
            owner_session.openWithCallback(picked, ChoiceBox, title=_("Recent searches"), list=choices)
        except Exception as exc:
            optional_failure("ui.search_recent_menu", exc)

    def _attach_recent_menu_to_stock_keyboard(self, keyboard):
        """Keep the keyboard's existing black MENU history, but release it cleanly.

        The map is attached after the stock keyboard starts, so it needs one
        manual execBegin(). R159 pairs that with a guaranteed execEnd() on close;
        otherwise MENU can remain captured by a dead keyboard after returning to
        Search and the inline fixed-green history never receives the key again.
        """
        if keyboard is None:
            return
        try:
            amap = ActionMap(
                ["MenuActions","UltraStalkerMenuActions"],
                {"menu": lambda: self._open_recent_search_menu_for_keyboard(keyboard)},
                -1000,
            )
            keyboard["ultrastalker_recent_search_actions"] = amap
            try:amap.execBegin()
            except Exception as exc:optional_failure("ui.search_recent_keyboard_exec", exc)

            def cleanup():
                try:amap.execEnd()
                except Exception:pass
                try:
                    if getattr(keyboard, "widgets", {}).get("ultrastalker_recent_search_actions") is amap:
                        keyboard.widgets.pop("ultrastalker_recent_search_actions", None)
                except Exception:pass
            try:keyboard.onClose.append(cleanup)
            except Exception:pass
        except Exception as exc:
            optional_failure("ui.search_recent_keyboard_action", exc)

    def prompt(self):
        self._history_hide()
        recent = _load_recent_searches()
        title = _("Search Movies & Series")
        if recent:
            title += "  •  " + _("Recent: %s") % ", ".join(recent[:3])
        if VirtualKeyBoard is not None:
            # Always use the receiver's native class so its stock skin renders.
            keyboard = self.session.openWithCallback(us_text_callback(self._search), VirtualKeyBoard, title=native_text(title), text=native_text(self.query))
            self._attach_recent_menu_to_stock_keyboard(keyboard)
        elif InputBox is not None:
            self.session.openWithCallback(us_text_callback(self._search), InputBox, title=native_text(title), text=native_text(self.query), maxSize=60)
        else:
            self.session.open(MessageBox, _("Search keyboard is unavailable on this image."), MessageBox.TYPE_ERROR, timeout=5)
