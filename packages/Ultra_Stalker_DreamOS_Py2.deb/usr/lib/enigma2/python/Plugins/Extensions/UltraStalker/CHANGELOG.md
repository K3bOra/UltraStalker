## Ultra Stalker 9.3.5
- Fixed a DreamOS crash when opening Settings options.

## Ultra Stalker 9.3.4
- Improved YouTube trailer resolution and playback, with 1080p preferred and 720p or lower fallback when available.
- Web management starts automatically and opens without a PIN on the local network by default. Explicit Web Cleaner settings are respected.

## Ultra Stalker 9.3.3
- Two source cards for Stalker Portal and Xtream / M3U, with green Online status and local playlist browsing.
- Edit and reorder each source group separately in Manage Servers. Web Cleaner starts automatically with PIN / QR protection by default.
- Search shows Xtream / M3U results as they arrive and limits simultaneous requests.
- Local opens mounted drives without waiting for a media scan. Refresh rebuilds the library when requested.
- Check Artwork reuses cached images and prepares title logos for different views.
- Updated the Live channel list, picons and poster frames in the player, and restored Recent and Continue cards.
- Added Free Portal and Free Xtream catalogs, and cleaned up unused picons when exported bouquets are removed.

## Ultra Stalker 9.3.1-r34
- Keep Online status green on both source cards.
- Group the web server editor into Stalker Portal and Xtream / M3U with group-local ordering.
- Start Web Cleaner automatically at receiver session startup by default.

## Ultra Stalker 9.3.1-r33
- Center the source cards within the area left of the summary and hide the source chooser heading.

## Ultra Stalker 9.3.1-r32
- Restore the original full-size source cards, centered at the same height.

## Ultra Stalker 9.3.1-r31
- Center the Stalker Portal and Xtream / M3U cards and show local and remote playlists alongside Xtream accounts.
- Give source navigation and check status more space in the footer.
- Align a shared poster frame in Player Old, New and New 2.

## Ultra Stalker 9.3.1-r29
- Track newly exported receiver artwork and remove unused aliases when their bouquets are deleted.
- Keep artwork shared by another bouquet and preserve untracked or changed picons.

## Ultra Stalker 9.3.1-r28
- Cap Search at two Portal requests and one Xtream/M3U catalogue scan across active and cancelling queries.
- Log Search timing and source counts for receiver diagnostics.

## Ultra Stalker 9.3.1-r27
- Paint ONLINE in green on the source selection tiles and the selected source detail.
- Keep Search responsive during provider delivery and save recent terms in the background.
- Load Xtream search categories correctly and publish cached matches as each folder is scanned.

## Ultra Stalker 9.3.1-r26.1
- Highlight server counts in green in Free Portal and Free Xtream.
- Keep the current Live picon visible while the InfoBar is open. Remove the separate picon plate in all three player styles.
- Preserve Live mini-list page positions when changing channels and resolve OK on a pending channel row.

## Ultra Stalker 9.3.1-r25
- Show mounted storage cards on Local entry. Read device capacity separately and reuse it on reopen.
- Open Movies, Series and Browse without waiting for storage capacity or starting an inventory scan.
- Rebuild the Local inventory only with GREEN Refresh, keeping the last index available while refreshing.

## Ultra Stalker 9.3.1-r24
- Fit ten rows in the Settings options card. Move the divider down and fit full descriptions in the wider footer.
- Add subtle corner highlights to the existing left-hand cards in Settings, Portal Manager, Free Portal and Free Xtream.

## Ultra Stalker 9.3.1-r23
- Restore Recent Live, Continue Movies and Continue Series rendering from existing watch history.
- Identify catalog requests as Ultra Stalker to avoid refusal of the default Python user agent.

## Ultra Stalker 9.3.1-r22
- Use the catalog's stored server name or its full source hostname.
- Open the group with OK to see expiry dates. Press OK on a selected account to reveal its connection details.

## Ultra Stalker 9.3.1-r21
- Open the Free Portal / Stalker and Free Xtream catalogs from Portal Manager or Settings.
- Show the catalog group name and exact account count from the online index when supplied. OK opens the selected group.
- Smooth progress bars on both splash screens, Home Recent cards, Live views and the player.
- Align the Settings notice button on FHD and WQHD. Extend the Settings card to the bottom edge.
- Redraw the Live EPG badge at native FHD and WQHD sizes.

## BlueFix R8 - Prepared page navigation (9.3.1-r8)
- Retain the most recent four prepared pages with LRU eviction; use RAM on repeated visits.
- Cancel obsolete cold page requests when a warm page is selected.
- Warm next and previous pages without waiting for TMDB artwork enrichment.
- Stop duplicate shared poster cache probes for worker-prepared negative results.
- Share the static card pixmap rather than decode it separately for every visible slot.
- Present titles/selection first, then at most two images per GUI timer callback with page generation/visibility/close guards.
- Reuse bounded WQHD skin transformations.
- Trailer resolver/runtime, 15 UI trailer methods and 27 legacy playback methods remain restored from 9.2.2.
- Retain parent poster pixmaps on BACK; refresh cached watch progress without decoding the entire page again.
- 21 local behavior/source comparison checks passed. No physical receiver timing or playback validation.

## BlueFix R7 - Trailer 9.2.2 restore (9.3.1-r7)
- Restored complete trailer resolver/runtime from the supplied UltraStalker_Final_V9.2.2.ipk.
- All 15 catalogue/details trailer method bodies copied from 9.2.2.
- All 27 trailer-only player method bodies/signatures copied from 9.2.2; normal movie/live methods continue using the current build.
- Removed R6 candidate probing, added User-Agent, quality fallback and extra trailer retry behavior.
- Restored the original quality order, raw split-video/audio URI, 4097 handoff, startup, EOF, failure and close behavior.
- DreamOS retains its Python 2 compatibility aliases; WQHD screen sizing remains current.
- 13 comparison/regression checks passed. Physical receiver playback remains unverified.

## BlueFix R6 test build (9.3.1-r6)
- Preserve split video/audio as first choice on native 4097.
- Validate each track with a bounded media-prefix GET on the resolver worker; reject HTTP errors and HTML error pages before playback.
- Hand the extractor User-Agent to the native Enigma2 service.
- Retry validated alternatives for the same exact video: 1080p, 720p, then complete 360p compatibility and available HLS.
- Keep retries bounded and isolated from movie/series provider recovery and history.
- Use the same candidate handoff from catalogue and Details.
- All R5 storage, navigation, EOF and RAM-pressure changes retained.
- 15 local regression checks passed. Real receiver playback is unverified.

## BlueFix R5 test build (9.3.1-r5)
- Preserve the 9.2.2 split video/audio trailer resolver and native 4097 handoff.
- Bypass the DreamOS provider relay for trailer URLs.
- Guard old-service events and early EOF; never treat zero/unknown playback as completion.
- Keep genuine startup failures visible instead of automatically dismissing the player.
- Require sustained measured low available RAM before an emergency playback exit.
- Defer Grid 3 cast/logo/panel work until focus settles; skip redundant progress repaints.
- Show capacity only for mounted local data drives; omit root flash, swap, virtual mounts and duplicates.
- Local regression checks passed. Physical Enigma2 receiver testing still required.

## V9.3.1 (2026-11-03, build 992, revision 576)

- BLUE poster caching uses the same public resolver as page browsing, including verified rescue seeds and gallery recovery after a failed details request.
- Apply saved manual identity selections before cache checks and writes.
- Preserve four-worker poster caching, existing images, screen-specific artwork and WQHD quality.

## V9.3 (2026-11-03, package 9.3.0, build 991, revision 575)

• FHD/WQHD display improvements and sharper 780px poster masters.
• Faster poster caching with four bounded parallel workers and direct verified image paths.
• Screen-aware artwork caching: posters for Poster Grids; posters and backdrops for Cinematic/Backdrop Grids.
• Refresh upgraded posters immediately; prevent stale images after atomic cache replacement.
• Adaptive Colors defaults to OFF on new installs; saved user preferences are preserved.
• Fix clipped recent-search buttons and package integrity checks.
• Retain Local storage/SWAP filtering and native player progress improvements.

## 9.2.6 Audited maintenance (2026-11-03)
- Correct Open metadata title fallback and Dream artwork diagnostic binding.
- Key decoded grid pixmaps by native size and enforce the local cache bound on shared hits.
- Move Settings cache cleanup and legacy menu cache statistics off the GUI thread.
- Scan Browse directories asynchronously with cancellation and stale-screen guards.
- Restrict startup cleanup to plugin-owned temporary outputs, preserving user installers.
- Recompress PNG IDAT streams losslessly; preserve exact pixels, transparency and metadata.
- Retain Settings, portable backup, native progress and Local SWAP fixes.

## 9.2.6 Local swap filter (2026-11-03)
- Exclude dedicated SWAP mounts from Local discovery, media scans and capacity cards.
- Filter old in-memory snapshots before display; skip SWAP before stat/statvfs probes.
- Retain normal Receiver/HDD/USB media even when a data drive also hosts a swap file.
- Preserve native progress rasters and previous Local performance improvements.

## 9.2.6 Native progress raster fix (2026-11-03)
- Ship progress, buffer and head rasters at their exact FHD/WQHD pixel sizes.
- Clip native rasters to the played position without relying on receiver pixmap scaling.
- Correct the Old player white/buffer raster width on WQHD as well as both New layouts.
- Preserve Local library navigation improvements and previous Settings/backup fixes.

## 9.2.6 Local and player fixes (2026-11-03)
- Scale player progress and buffer fills to native display geometry so the played line meets its head on FHD and WQHD.
- Reuse the Local catalogue immediately after checking drive identity; validate and rebuild changed directories in a deduplicated background worker.
- Discover mounted drives from mount metadata without enumerating every automount directory.
- Publish receiver usage before slower HDD/USB usage, and reuse recent Local Home summaries.
- Start the shared Local inventory warmup after drive discovery; retain the manual Refresh action.

## 9.2.6 Settings layout fix (2026-11-02)
- Balanced Settings, Portal Manager, Free Portal and Free Xtream spacing uses the full rail.
- Ten rows use 100px slots with exact 90px card assets; the optional eleventh action uses exact 82px cards in 90px slots.
- Reapply native row height and zero spacing after the receiver skin; retain pre-widget row counts.
- Reset stale list page offsets when all entries fit, with a two-pixel rounding margin.
- Open portals before decoding Home artwork or migrating legacy Home/utility caches.
- Import deferred recorder/proxy services only inside their timer callback after portal opening.
- Allocate whole native rows after WQHD scaling; keep the last option on the same page.
- Fit all eleven Portal Manager actions, including the optional disabled-portals action.
- Keep Free Portal / Free Xtream ten-item pages within the native list height.
- Fix WQHD rounding for Portal Manager choice lists and clamp saved option selection.
- Label complete backups as portable across DreamOS and Open; retain the shared format-9 archive.
- Adapt an unavailable restored playback engine to the target image before transactional commit.
- Restore the Smart Recovery ON/OFF control and switch rendering.

## V9.2.6 DreamOS Fix1 (build 990, revision 574)
- Bind Backdrop Grid 2 to its seven-card skin instead of inheriting the eight-card skin; fixes the DM900 art7 SkinError recorded in enigma2_crash_1793612317.log.
- Match seven-column navigation, frame and cursor dimensions, and the overview-fit hook to this layout.
- Public version remains 9.2.6. Receiver retest required.

## V9.2.6 (build 989, revision 573)
- Unified public package, runtime and release-note versions.
- FHD/WQHD presentation and responsive update notes.
- DreamOS: TEXT switches playback engine; extra field reports removed; DEB updates prepared; bounded installer wait; shared cache/geometry performance changes.
- Prepared for receiver testing. Local checks are not native receiver acceptance tests.

## V9.2.2 R7 Fix42 (build 987, revision 618; package 9.2.2-r7.42)
- Retry missing/unreadable subtitle-choice storage instead of marking an absent HDD snapshot as loaded. Before writing, merge newly available stored choices with pending explicit selections and removals; preserve the current selection within the 96-title limit even when older disk records have future timestamps. Retry unsaved unchanged choices without repeating a successful unchanged fsync. Corrupt/unreadable snapshots are retained for a later valid read.
- Promote the surviving secondary video reader when the buffered primary GET ends. Continue ring buffering from the exact next byte owed to that reader, protect its new ownership from later probe requests, refresh owner metrics, and fence retired producers before shared cache writes. Existing live-primary protection and bounded ring storage remain enabled.
- Verification: targeted subtitle persistence and buffered reader handoff regression checks, exact output-byte comparisons through the production Range handler with simulated transports, full Python 3.12 source compilation, payload hashes and archive permission validation. Native receiver rendering, decoding and real provider sessions remain device acceptance tests.

## V9.2.2 R7 Fix41 (build 986, revision 617; package 9.2.2-r7.41)
- Restore explicit per-title subtitle ownership: native track/language, online cached file/provider/language, SubsSupport/Pro descriptor, or explicit OFF. Reapply once after audio restoration, service readiness and Resume; remap native tracks by language when PIDs change. Manual interaction cancels delayed automatic track changes and queued subtitle restoration. Respect remember-track settings and retain choices across same-title recovery/buffer restarts.
- Keep the current renderer while browsing a replacement source; commit ownership only after a valid choice/download. Preserve native selection on cancel, fence receiver cached-subtitle callbacks, and resume after a changed native selection only if playback had been running before it. Failed parsing/search leaves the working renderer intact.
- Bind subtitle provider/language to its request and candidate batch; reject in-flight request mutation. Download and parse subtitle files on the player worker. Render unchanged cues only once; retain forced redraw for style/volume changes.
- Preserve the primary buffered video GET during auxiliary Range/index/subtitle reads. Secondary reads stream directly with bounded memory and never mutate the primary ring/cache. New seeks may retire an older secondary read, not the playing primary. Reader admission failures no longer poison the whole movie. Preserve Range validation, cache bound and cancellation/stop cleanup.
- Recent uses cancellable provider requests and background-only payload/cache preparation. Capture the return-service reference on the GUI thread. Busy/rejected/cancelled launches release owned clients, and Home close cleans undelivered clients. Live starts from saved channel/page context and loads drawer pages lazily rather than scanning its category before playback.
- Recent episode launches resolve next-episode context after playback starts; persist parent/season labels, handle next-episode results, release source ownership and resolve each successor freshly. Bounded/cancellable lookups never delay initial video startup.
- Add a conservative post-startup VOD PTS health check: 30s of unchanged positive position can use existing bounded same-engine recovery, excluding pause, subtitle UI, Resume and near EOF. Add launch/first-progress timing breadcrumbs without logging stream URLs.
- Validation: 123 audit/player/regression tests and 19 retained correction/Local/Korean tests pass (142 total; zero expected failures). Includes real parallel loopback HTTP Range reads with byte-exact continued primary playback, bounded ring storage, persistent subtitle descriptors, source handoff/cancel, stale results, background parsing/cache reads, Recent ownership, episode context and stall exclusions. Native receiver rendering, provider sessions and decoder smoothness still require device acceptance.

## V9.2.2 R7 Fix40 (build 985, revision 616; package 9.2.2-r7.40)
- Reuse resident poster-menu widgets for correction search, paging and confirmation in both poster grids; no ChoiceBox stacking. BACK owns controller cancellation and closes the same overlay. Keep search results generation-scoped, clear old candidates on new requests, and offer an explicit retry after failures.
- Separate match-information and automatic-reset confirmation states so a previous candidate cannot hijack reset. Reject a stale/foreign confirmation candidate.
- Backup format 9 includes a validated, bounded manual_tmdb.json snapshot. Restore exact per-item choices transactionally with ordinary config/database files, invalidate manual-choice RAM state, and roll back choices and settings together if commit fails. Formats 1-8 remain accepted; they preserve existing manual choices because those archives did not contain them. Manual writers share the state snapshot/restore lock.
- Web and M3U export link resolution use signature-based call_compatible and execute providers once; internal TypeError no longer causes repeated requests. Legacy signatures remain supported.
- Reject HTML/JSON error documents returned instead of video, including obvious HTML bodies mislabeled as octet-stream. Preserve generic binary video support and existing HLS, Content-Range, length and cancellation checks.
- Exclude __pycache__ and .pyc from the IPK; every remaining plugin payload file except the manifest itself is verified against the installation manifest.
- Correct the audit's offline-root finding: the prior installer already exited before host dependency checks and restart. An isolated offline-root install test confirms no host Python, killall or nohup is invoked; no extra restart guard was necessary.
- Validation: 71 audit/regression tests plus 19 retained correction, Local and Korean-search tests passed. Includes real temporary SQLite/ZIP operations, exact restore, rollback fault injection, legacy backup compatibility, empty snapshots, provider call counts, resident poster-menu callbacks, download rejection and offline-root installer staging. All Python syntax, package hashes, shell syntax, and bytecode exclusion checked. Native receiver playback/rendering and live provider sessions remain device tests.

## V9.2.2 R7 Fix39 (build 984, revision 615; package 9.2.2-r7.39)
- Manual correction now strips explicit Korean routing tags (KR/KOR/Korean and Arabic category prefixes) before searching. Try up to three distinct cleaned aliases for bilingual Latin/Arabic/Hangul provider labels, preserving native Hangul and title wrappers. Keep the raw query available for editing; numeric titles are no longer erased by catalogue-year cleanup.
- Search only the selected movie/TV namespace, merge duplicate IDs, preserve result paging and cancellation, rank exact title matches and Korean-tagged matches first. Plain Latin queries request English display titles; original-language and Korean-country metadata are retained and Korean results show KR in the menu.
- Partial alias failures retain available results. All alias requests failing still reports an error. No automatic translation or fabricated title mapping is used.
- Validation: seven new tests cover routing-tag cleanup, mixed/native scripts, legitimate/numeric titles, alias recovery, deduplication/ranking, type isolation, paging/partial failure and cancellation. All twelve retained correction/Local tests pass. Python syntax and packaged payload integrity verified. Live TMDb credentials and native receiver rendering were unavailable.

## V9.2.2 R7 Fix38 (build 983, revision 614; package 9.2.2-r7.38)
- Correction search requests only the current content namespace: series use /search/tv and films use /search/movie. No mixed results or cross-type fallback.
- Local root discovery now enables Movies/Series/Browse before storage usage and index counts complete. Local probes use a separate bounded executor instead of waiting behind artwork cache batches. Failed requests release their running state and display a retry message.
- Retain the last Local Home snapshot across screen instances for immediate return visits. Storage panels are visible from first paint with a loading message on cold entry; storage results publish before index counts. Fresh discovery still updates drives and usage in the background.
- Validation: six new tests cover search namespace isolation, navigation before storage/index results, close/reopen snapshot reuse, rejecting closed-screen callbacks, retry after discovery failure and cold storage panel visibility; all six Fix37 controller tests pass. Native Enigma rendering and mounted receiver storage remain to be tested on device.

## V9.2.2 R7 Fix37 (build 982, revision 613; package 9.2.2-r7.37)
- Replace the standalone manual correction Screen with the existing inline floating menu on Details and Cinematic views. Search status, results, paging, query editing, confirmation and automatic reset reuse the same rows and anchor. Plain grids retain their supported choice dialog.
- BACK cancels pending work and releases menu input; late results cannot reopen a dismissed overlay. Network failures leave edit/back controls available. Owner close stops the correction timer and task handles.
- Validation: six mocked controller tests cover inline apply/persistence, cancellation with late completion, network failure, query editing/paging, confirmed reset and owner destruction. Package syntax and payload integrity verified; receiver rendering requires device testing.

## V9.2.2 R7 Fix36 (build 981, revision 612; package 9.2.2-r7.36)
- Poster Grid 1/2/3 and Backdrop Grid 1/2 capture provider-prose publication during page preparation and defer its disk writes until the page has rendered. A separate bounded single-worker lane preserves first-frame cached artwork without occupying the catalogue worker for publication.
- Cinematic defers navigation-alias writes until after render, skips identical aliases already held in RAM, and avoids rereading an exact-ID snapshot when the current snapshot already carries the same complete identity. M3U's final cache-only artwork refresh runs on page workers, including Cinematic neighbour preparation, rather than the GUI callback.
- Deferred publication pauses while a child screen is open, resumes unfinished rows on return even when hiding cancelled artwork prefetch, and rejects closed screens, superseded pages and stale manual identities. Existing Fix35 manual-choice protection and Arabic metadata sharing remain enabled.
- Local's first draw no longer discovers storage roots, rereads the library index twice, queries filesystem usage or decodes unused Browse backgrounds. Summary reads run on a cache worker; GUI updates and pending Movies/Series/Browse opens are delivered only to the live screen. Forced refreshes arriving during a read are coalesced and replayed.
- Local Browse decodes each of its two repeated background surfaces once through the bounded static-icon cache. All three Live modes also reuse small chrome through that cache; full-screen Live backgrounds remain widget-owned. The 16-entry cache now evicts the least recently used entry instead of clearing every entry at capacity. Existing native memory-pressure relief is retained.
- Immutable bundled fixed surfaces are validated once per process and returned as detached metadata. Missing bundled files are retried; mutable HDD fallbacks keep their validation.
- Preserves Fix35 fixes, artwork choices, approved skins, playback settings and provider behavior. No cache wipe, new hidden network prefetch or user-data migration is required.
- Offline verification covers eight opening regressions reproduced on Fix35, 24 opening/lifecycle/cache tests here, and the existing 51 regression tests. Receiver-native screen timing, skin rendering, playback and real provider latency still require device verification; no percentage speedup is claimed.

## V9.2.2 R7 Fix35 (build 980, revision 611; package 9.2.2-r7.35)
- Details manual-match replacement waits for the session's deferred close completion and preserves the original parent callback. No modal reopen occurs during teardown.
- Manual choices clear descriptive aliases (including IMDb rating, duration, director/writer and artwork identity fields). Details provider enrichment, retries, artwork and late season-count callbacks respect the active choice and its revision; automatic matching still resumes after reset. Stream commands and episode routing remain source-owned.
- Shared metadata retains accepted unpublished writes independently from the display LRU. Pending records have explicit count/byte budgets and reject new work with a reported failure rather than evicting accepted data. Writes recover after storage returns and merge existing durable fields.
- Shared metadata misses use a bounded three-second negative cache, invalidated by puts and observed mount transitions. Manual-choice disk reads and fsyncs use per-key serialization instead of the global RAM-cache lock.
- Details snapshots are queued to a dedicated ordered storage worker, with immutable inputs, same-item coalescing, duplicate suppression, retry after storage failure, stale-choice rejection and runtime shutdown draining. The GUI no longer synchronously publishes these snapshots; atomic writes and fsync remain enabled.
- Xtream EPG propagates account busy/rate-limit failures, avoids the API/sibling retry ladder during Retry-After, and publishes transient failures distinctly from genuine empty guides. Cached XMLTV and explicit native guides remain usable. The already-serial batch runs on its caller's worker without creating a new executor for each page.
- Correct package script/helper execute permissions and refresh the README version. No user-data wipe or broad cache migration is required.
- Offline verification: all eight Fix34 defect/performance regression cases fail on the old package and pass here, with additional cache, concurrency, persistence, EPG, XMLTV and image checks. Native receiver UI, playback and real provider sessions still require device verification.

## V9.2.2 R7 Fix34 (build 979, revision 610; package 9.2.2-r7.34)
- Add Correct movie / series to Poster Grid, Cinematic, Backdrop and Details menus. Search both TMDb namespaces, edit the query, navigate result pages and inspect the selected result's poster, original title, year, type and synopsis before confirming. Arabic and English UI text follows the plugin language.
- Persist confirmed choices by provider account, content type and stable provider item identity under receiver configuration. Same-title neighbours remain independent; equivalent provider ID fields reuse the same choice. No stream URLs or account credentials are stored in selection files. Playback IDs, URLs, favorites and episode routing remain unchanged.
- Apply manual identity before catalogue artwork, Details and metadata resolution. Exact id/type outranks old pointer caches, provider hints and fuzzy matching. Provider metadata/artwork fallback is disabled for explicitly selected works; a failed exact lookup cannot silently switch to another namesake.
- Version per-item presentation/cache keys on selection and reset. Old queued artwork/metadata jobs cannot write the current pointer after a correction, and manual selections do not publish provider-title aliases that could affect unrelated works. Shared canonical artwork/metadata remain deduplicated by the selected TMDb type and id.
- Red in the correction screen removes the manual choice and returns this item to automatic matching. Parent views retain their page and focus and refresh once when returning from correction, including corrections made inside Details. Choices survive GUI restart and HDD cache clearing.
- Validation: retained Fix32/Fix33 regression tests, targeted manual persistence/search/UI callback tests, plus the production canonical artwork/metadata pipeline with temporary storage and mocked TMDb HTTP, including stale wrong cache, movie-to-TV correction, replacement, restart, namesake isolation and reset. Native receiver rendering and a real provider/TMDb session were not available.

## V9.2.2 R7 Fix33 (build 978, revision 609; package 9.2.2-r7.33)
- Live picon HTTP work now has its own bounded four-worker priority executor; fitting/validation has a separate two-worker executor. Neither queues behind the single general image worker, movie backdrops, HDD catalogue warming or EPG metadata. The selected visible logo has priority and inactive-page queued downloads are rejected. Cancelled/evicted artwork futures clear their inflight identity so subsequent automatic retries can recover.
- Plain M3U pages start their own playlist logo URLs immediately; optional full Xtream artwork indexing runs once in the background and merges only into a bounded set of displayed pages. Page opening no longer waits for that full catalogue download. Per-channel download identities prevent late enrichment from sharing another channel's fallback image.
- Live grid downloads use a 2.5-second socket window with the existing overall transfer budget and candidate/cache recovery. The pinned opener performs DNS destination validation during the actual connection under the download deadline, avoiding a redundant pre-download DNS resolution; destination pinning, redirect restrictions and TLS verification remain enforced.
- Introduce an account-scoped provider coordinator shared across separate Xtream/M3U client instances, including isolated catalogue refresh/rescue clients. API calls and same-provider XMLTV downloads no longer open competing connections for the same account. Queue waits observe cancellation, foreground catalogue actions take priority, and background guide transfers yield without corrupting the last working index.
- HTTP 429/469 responses now honor Retry-After and defer other requests for that account. One bounded rate-limit replay replaces the immediate alternate-UA burst. Plain M3U fetches/probes participate in the same account lease through response close; a busy result is not amplified into additional playlist/UA fallbacks.
- Screen catalogue retry paths preserve M3U client request scopes instead of closing unrelated shared responses. Rate-limit classification stops the outer retry/isolated-rescue cascade while preserving explicit authentication and genuine provider errors.
- Reference comparison: inspected the upstream kiddac/XStreamity live-logo path read-only. It takes the selected channel's catalogue logo URL, debounces navigation and performs a short direct asynchronous image request. No upstream implementation was copied or vendored; all changes here use UltraStalker's own cache, request, executor and UI contracts.
- Validation: prior Fix32 regressions plus account sharing/isolation, concurrent clients, cancellation/reopen, 429/469 timing, persistent limits, actual XMLTV foreground preemption, ordinary M3U response lifetime, independent picon worker execution, cancelled-logo retry cleanup and destination-validation handoff. No receiver/user-provider session was available. Playback buffers and unrelated TMDb/Arabic logic remain preserved.

## V9.2.2 R7 Fix32 (build 977, revision 608; package 9.2.2-r7.32)
- Live picon transfers now share one absolute time budget across response headers, body reads, redirects and alternate-header retries. The validated media connections register their raw/TLS sockets with that request's deadline so trickle traffic cannot monopolise image workers. Ordinary requests without a picon deadline retain their existing transport and TLS checks.
- Legacy cached picons are verified off the GUI thread by a deduplicated, bounded local worker queue. Verification results are keyed by the file's current fingerprint; corrupt/replaced files are excluded from cache hits and repaired by an atomic download. Grid retry checks the original source even after a fitted derivative is displayed. Working cache files and unrelated user data are retained.
- Public/bulk picon cache fills use the same bounded atomic downloader and validate existing files before counting them as cached, preserving the public request identity and validated destination handling.
- XMLTV queries discard expired history before applying the 512-event result cap. The latest unknown-end programme and long-running current programmes remain eligible; one lookahead row resolves the last returned programme's missing stop time. All SQL values remain parameterised and lookups use the existing channel/time index.
- Columns detach cancelled page requests once, restore the 2-second idle heartbeat for fully cached pages and stale completion markers, and recover from completed futures or failed submissions without a perpetual 200ms poll. Partial results still keep the active visible-page request running.
- Verification covers actual slow-header/body/redirect HTTP fixtures, cache-only GUI first paint followed by background corruption repair without remote input, native image fallbacks, dense guides and unknown stop times, and page-fetch lifecycle recovery. Receiver-specific display and user-provider behaviour still require a receiver test. Independently implemented; prior TMDb/Arabic logic and playback buffers are retained.

## V9.2.2 R7 Fix31 (build 976, revision 607; package 9.2.2-r7.31)
- Correct the Live EPG request identity in Columns and Classic: the full provider/page channel list identifies a job, so partial cache fills and cursor movement cannot cancel the remaining channels. Keep all fetch/parse work off the GUI thread.
- Columns, Classic and Wall now refresh missing/expired visible guides without remote input, with one page request at a time, transport-error backoff, short negative caches, stale-generation rejection and hidden/closed-screen guards. A RAM revision published after XMLTV preparation invalidates visible negative answers promptly.
- Xtream/M3U page batches publish all cached XMLTV results before entering any per-channel API/native fallback. After a cold guide preparation, a second cache pass publishes ready channels before a missing channel can delay them.
- Restore existing JPEG/WebP picon cache entries. Share a bounded 30-second failure cooldown per full URL under the existing download lock, allowing each channel's own alternatives to proceed after a shared dead primary. Network timeouts no longer repeat merely to change User-Agent. Preserve atomic writes, bounded image sizes and validated openers; support older Pillow resampling names.
- The Columns detail logo fits on the local cache executor, independently of EPG requests; repeated repaint polls share one fit job per source, and completed failed fits do not loop.
- Missing visible picons retry automatically at most once per slot per 30 seconds and stop while the screen is hidden or closed. Existing successful picons remain cache-only; retries are scoped to the current page, including after a transient failure.
- Regression coverage includes production fetch/drain/heartbeat methods for stationary Columns, Classic and Wall; partial results during cursor movement; automatic transport/empty-result recovery; XMLTV readiness; actual adapter/feed-to-screen delivery; old WebP cache reuse; concurrent shared-primary failures; bounded retry state and older Pillow. No receiver or user-provider session was available. Prior TMDb/Arabic fixes and playback buffer settings are preserved. Independently implemented; no XStreamity code copied.

## V9.2.2 R7 Fix30 (build 975, revision 606; package 9.2.2-r7.30)
- Large-package verification reproduced a real Fix29 limit: a 10,000-channel/240,000-programme fixture failed at the 200,000-programme ceiling. Its 34 MiB uncompressed XML body would also exceed the previous 32 MiB download ceiling. This release addresses that measured capacity gap; it is not a claim that all providers, mappings or receiver images have been tested.
- XMLTV cache on the configured writable HDD now supports up to 2,000,000 retained programmes, 512 MiB raw input, 2 GiB streamed XML and a 512 MiB index. Raw/index budgets are additionally reduced according to available disk space; large indexes retain the current/near-past guide plus the next 30 hours. Temporary/RAM fallback keeps the previous small limits instead of allocating a large guide in receiver RAM.
- Streaming indexing uses a 2 MiB SQLite page cache, bounded 256-row writes, bounded channel/date caches, and a channel/time index maintained during insertion. It avoids the previous per-programme duplicate alias insertions and end-of-build full-guide sort. Cooperative processing yields let UI/input threads run between batches. Date parsing remains timezone-correct and has a bounded 8,192-entry cache.
- Existing guide reads continue against the previous complete index while the replacement is built and atomically published. The whole guide is prepared once per source; indexed reads do not issue per-channel provider calls. Cancellation and source/account isolation remain intact.
- Capacity/full-disk failures and a lost HDD mount retain the working guide and use a retry delay, without repeating the same large download with another User-Agent. The mount/write gate is rechecked before temporary files, index construction and publication so a disappearing HDD does not redirect large writes onto receiver flash. Browser retry remains available for ordinary transport/format failures. No channel mapping is guessed to claim guide coverage; the provider still needs to supply EPG data with a usable identifier.
- Reproducible local scale tests: 100 channels/2,400 programmes; 5,000/120,000; 25,000/600,000. Every channel was verified in each final index. At 25,000 channels the fixture was 197.31 MiB XML and the index 161.69 MiB; one simulated HTTP body transfer prepared it in 5.258 seconds. Concurrent old-cache reads continued throughout 827 polling ticks; 95th-percentile individual cache reads were 1.987 ms and a visible 17-channel batch 3.765 ms. Process peak RSS was 26.68 MiB versus 22.75 MiB before preparation. These are host/offline fixture measurements, not Enigma2 receiver or internet download timings.
- Verification: 35 EPG + 14 picon + all 47 prior metadata regressions (96 total), three scale cases, full source compilation, isolated install/config preservation/rollback, and actual IPK manifest/version checks. Added storage-policy, bounded-SQLite/date-cache, capacity/no-repeat-download and full-disk recovery regressions. Includes every Fix29 correction; playback/buffer and portal EPG behavior are unchanged.

## V9.2.2 R7 Fix29 (build 974, revision 605; package 9.2.2-r7.29)
- Follow-up review of the delivered Fix28 runtime integration found two reproduced edge cases. Regression fixtures fail on Fix28 and pass with these fixes; all Fix28 EPG, picon and metadata behavior remains included.
- Grid Live downloads are now coalesced only when their complete ordered logo candidate sets match. Channels sharing a dead/generic primary URL but having different alternatives no longer receive another channel's logo from a shared completion. Identical candidate sets still share one job, and generation guards remain intact.
- M3UClient now distinguishes temporary request cancellation from terminal close. Cancelling Splash uses cancel_pending_requests, closes old responses and cancels that EPG generation, but preserves the cached PortalSession for a later open. Background jobs capture their generation's stop event before scheduling, so a late-starting cancelled job cannot adopt the new generation and download/publish data. Explicit client close stays terminal.
- The standalone image-loader mixin now uses the same item-scoped provider-art resolver as Grid/Home, preserving root-relative paths, playlist directory origins, escaped URLs and signed query bytes.
- Verification: 30 EPG + 14 picon + all 47 metadata regressions (91 total). New coverage executes the actual Grid request method for different/identical candidate sets and verifies queued/active cancellation followed by successful reuse of the same client. URL tests also execute the standalone image-loader resolver. Full source compilation, isolated install/config preservation/rollback and actual package manifest/version checks are repeated for this release. No receiver or user-provider session was available.

## V9.2.2 R7 Fix28 (build 973, revision 604; package 9.2.2-r7.28)
- Independent EPG/picon implementation; no XStreamity code has been copied. All prior verified-TMDb metadata/Arabic fixes are retained. Buffer sizes and playback configuration are unchanged.
- Entering Live categories/pages starts a bounded XMLTV preparation in a daemon worker. A shared per-source lock coalesces foreground/background requests, including separate clients. Live requests prefer whole-guide XMLTV before the per-channel Xtream API; API/catch-up support remains available. Active Live use checks for updates, reusing the two-hour disk index; no continuous idle polling or full-channel-list fetch is introduced by preparation.
- Existing guide data stays readable during an atomic background replacement. Failed/empty/malformed updates preserve the working guide, failures have a bounded retry delay, and client close cancels the worker/read without publishing partial data. XMLTV downloads and legacy M3U header discovery try browser headers after the default VLC request fails; cancellation does not trigger another connection or a failure cooldown.
- A final native receiver EPG fallback requires an explicit, validated service_ref/custom_sid on that channel. Xtream normalization and M3U service-ref attributes preserve it. No DVB identity is fabricated from a stream number or channel name. Native reads use the receiver GUI loop, are bounded/cancellable, and never import/overwrite receiver EPG.
- Shared provider-art URL handling preserves percent-encoded paths and signed query values, handles escaped/HTML URL text, and distinguishes host-root /logos paths from playlist-directory logos paths. The Grid, Home and Live picon cache use the same resolution. Plain M3U CDN requests use the adapter's browser headers with credential-free origin Referer and identity encoding.
- Xtream keeps all usable logo fields instead of collapsing them into stream_icon. M3U enrichment preserves original playlist artwork and adds API alternatives with each origin resolved first. Live tries up to six catalogue alternatives; cached alternatives are reused by Grid, Home and Player even if the first stream_icon is dead.
- Live image downloads retry once with VLC identity on M3U/Xtream rejection, keep verified HTTPS/DNS/redirect handling, use bounded downloads/gzip decoding and pixel limits, and atomically produce native PNGs (including WebP/GIF when Pillow is available). Small valid PNGs are cached too. Incomplete/bad images cannot replace working files.
- Existing Xtream Live category caches automatically refresh once to recover previously discarded logo/service-reference fields. A failed upgrade keeps the old channel list and delays another attempt. No HDD-wide cache deletion is required.
- Verification: 27 offline EPG regressions + 12 picon regressions + all 47 prior metadata regressions (86 total), plus full source compilation, isolated install/config preservation/rollback checks and actual IPK manifest/version verification. Fixtures exercise adapter normalization, the real Live UI helpers/downloader, primary XMLTV/API ordering, background coalescing/cancellation, native main-loop dispatch, signed/root-relative URLs, alternate logos, codec conversion, legacy cache migration and failure recovery. No live receiver or user-provider session was available; absent provider schedules/logos cannot be manufactured.

## V9.2.2 R7 Fix27 (build 972, revision 603; package 9.2.2-r7.27)
- EPG follow-up: plain M3U previously returned [] whenever no Xtream credentials were present, without reading the playlist XMLTV source. Xtream supported its short/table API but had no provider XMLTV fallback. These are confirmed input-path gaps; the user's particular providers have not been exercised remotely.
- M3U now discovers url-tvg / x-tvg-url / tvg-url / epg-url from the playlist header, resolves relative HTTP(S) feed URLs, persists the source list, and maps programme channels through tvg-id. Existing cached playlists discover the header using a bounded Range read, preserving their loaded catalogue without forcing a full playlist refresh.
- Xtream keeps working short/table API guides. Empty/unusable guides can fall back automatically to the same account's xmltv.php feed. Loaded category rows preserve stream-to-EPG IDs, avoiding an unnecessary all-stream lookup; successful shared XMLTV indexes can serve later channels without another guide download.
- XMLTV and .gz input is streamed into a private, source-specific SQLite index with bounded download, decompression and index sizes. Numeric timezone offsets and UTC-default XMLTV dates are handled explicitly. The index refreshes after two hours; failed refreshes retain usable prior data, cancelled refreshes can retry, and failed requests have a bounded retry delay. Explicit channel IDs take precedence; name-only fallback requires a unique channel match.
- Xtream timestamps now support milliseconds and timezone-aware ISO values, skip invalid/zero timestamp aliases, and use the panel timezone when available for naive ISO dates. Normalized time/time_to fields prevent old raw aliases from overriding valid times in the Live UI. Existing Stalker EPG and native receiver/export paths are unchanged.
- A channel still needs provider EPG data. Plain M3U with neither a feed declaration nor Xtream credentials has no guide to retrieve. This release does not generate schedules or obtain an unrelated provider's guide.
- Verification: 15 new offline EPG checks use the actual M3U/Xtream adapter, compressed feeds, the real Live row/Now-Next policy, two-channel shared-cache reuse, account fallback, timestamp aliases, persistence/legacy header discovery, cancellation, malformed feeds, stale-index recovery, source isolation and ambiguous channel rejection. All 47 prior metadata regressions also passed (62 total), with source compilation, package integrity and isolated install/rollback checks. No receiver or user-server session was available.

## V9.2.2 R7 Fix26 (build 971, revision 602; package 9.2.2-r7.26)
- Fix25 still depended on first collecting Arabic catalogue prose through browsing the source category or BLUE. That is insufficient after deleting the HDD cache and starting directly from an English-category copy.
- Focused text metadata now automatically looks for an Arabic provider copy when Arabic is selected, the current work has a verified TMDb identity, and neither its loaded fields nor its shared cache has real Arabic prose. No visit to the Arabic category or BLUE action is required for this lookup.
- Candidates are independently resolved through the existing identity-only policy and must match both the exact TMDb ID and movie/TV namespace. Raw provider IDs, injected locks, donor title similarity alone and alternate-media numeric matches cannot authorize sharing. The donor can contribute only the existing whitelisted metadata fields, never playback URLs, quality or progress.
- Stalker uses bounded provider-filtered search (up to two title aliases, three search pages, three donor verifications); it does not launch a category crawl or mutate user Search state. Separate Arabic/English rows sharing a provider stream ID remain distinct for metadata discovery.
- Plain M3U searches already loaded rows. Xtream reuses loaded/category/global caches, or tries one cached all-list endpoint without walking every category; up to two matching rows may request provider info for a missing catalogue plot. Panels that cannot expose the alternate Arabic row through these routes can still fall back to English. This is retrieval, not generated translation or a guarantee that every source exposes Arabic.
- Lookups are serialized per source, honor focus cancellation, reuse a successful shared synopsis, and suppress repeated completed misses for two minutes. Cancelled/incomplete searches do not stamp a completed miss. No new artwork download is performed by the lookup.
- Verification: 47 local regression tests including cold English-first resolution with empty shared caches, the actual PG3 late-identity worker repainting Arabic, exact-ID/type rejection, forged-lock stripping, cancellation/retry, account-scoped miss caching, native-search isolation, same-stream language variants, and Xtream all-list reuse. Source compilation, package integrity and isolated upgrade/rollback checks also passed. No receiver session was available.

## V9.2.2 R7 Fix25 (build 970, revision 601; package 9.2.2-r7.25)
- Receiver feedback confirmed the two selected duplicate movies eventually shared Arabic correctly, while untouched folder titles remained English. The previous sharing path ran when a title was focused; page preparation and the full-category BLUE artwork pass did not publish catalogue synopses.
- Loaded pages now publish provider metadata for every row with an already verified local TMDb identity, including RAM artwork hits. New artwork identities also publish their source row. These hooks do no extra title searches, detail requests or provider enrichment.
- BLUE / Check Artwork now collects known provider synopses across the whole current category, including titles with already cached artwork. Newly resolved identities publish their catalogue metadata before backdrop work, so a backdrop failure cannot suppress a valid Arabic synopsis.
- To populate existing untouched duplicates, run BLUE once in the category containing the Arabic descriptions, wait for completion, then reopen the destination category. Only available Arabic text is shared; missing Arabic translations are not invented. The normal artwork cache operation can still perform its usual requests for missing assets.
- Sharing requires verified same-media TMDb identity and rejects conflicting locked IDs. Common and localized fields stay whitelisted; playback URL, quality and progress remain per-copy. English provider fallback prose is no longer published into the Arabic shared metadata slot.
- Verification: 39 local regression tests, including actual page preparation, the BLUE category enumerator and worker over 61 cached movies across seven provider pages, backdrop-failure independence and the artwork save hook. No receiver session was available.

## V9.2.2 R7 Fix24 (build 969, revision 600; package 9.2.2-r7.24)
- Receiver follow-up: Fix23 did not resolve the reported cross-folder discrepancy. A reproduced worker-path defect let the title-logo lane discover a verified TMDb identity and origin metadata after the initial metadata result, then use that result for cast portraits only. The information panel was never repainted from the late row.
- PG3 now joins late verified artwork/logo identity and invariant origin data into the selected-language metadata authority, saves the source pointer, and publishes another metadata result. Donor prose, genres, quality, URLs and source IDs are excluded from this handoff; differing verified IDs/media types are rejected.
- Details Authority also checks existing validated local artwork pointers when the source has no Details pointer. This is a local-cache bridge, not another artwork download or a raw provider-ID trust shortcut.
- PG3 country display gives canonical metadata precedence over provider production_countries aliases. Repeated focus-settle jobs get separate generations; cancelled jobs cannot emit a done marker that stops a newer job's poller.
- Temporary bounded receiver diagnostics: /tmp/ultrastalker/metadata_trace.jsonl (128 KiB plus one rotated copy), written by workers. Records contain build, hashed source/item identity, title/folder, TMDb ID/type, selected metadata locale, country/original language and synopsis character/Arabic presence. No raw credentials, URLs, MAC, synopsis body or playback links are logged. This file is evidence for any remaining receiver-specific failure; the actual receiver root cause has not been established from its logs yet.
- Verification: 33 local regression tests, including the actual PG3 worker execution for late identity and already-known-ID origin handoffs, cancellation delivery, shared-cache bridges, raw/unrelated identity rejection, canonical-country precedence and diagnostic redaction. No Enigma2/receiver session was available.

## V9.2.2 R7 Fix23 (build 968, revision 599; package 9.2.2-r7.23)
- Screenshot follow-up: verified same-ID provider fallbacks now share original production language as well as country/year. Explicit production-language fields are accepted; stream audio/subtitle language is not used as production-language evidence.
- Previously locale-stamped cache entries missing country, original language or release year are eligible for one exact-ID metadata repair. A successful lookup records the origin check even if TMDb genuinely has no value, preventing an endless repair loop. Existing complete entries retain their hot path.
- PG3 first-paint descriptions now use a pure, RAM-only selected-language policy. Explicitly empty/filtered worker results stay empty instead of restoring a stale English synopsis or advert from raw fields. Shared selected-language provider prose is available on first paint too.
- The PG3 side panel uses the record's release year before the folder fallback, so the same verified work has the same metadata across folders.
- Includes every Fix22 change. Local verification: 26 regression tests, including the actual PG3 paint method with the two incomplete-folder patterns, exact-ID legacy repair, original-language sharing and empty-result handling. Synthetic fixtures model the supplied screenshots; no receiver/server session was available.

## V9.2.2 R7 Fix22 (build 967, revision 598; package 9.2.2-r7.22)
- Proven identical TMDb IDs share their complete information across folders and sources even when catalogue names, country tags or years differ. Movie and TV IDs stay in separate namespaces; raw/unverified IDs and ambiguous name matches keep the previous conservative validation.
- A sparse refresh in the same information locale keeps existing complete metadata. Changing locale still replaces localized text without reviving an old-language synopsis or genre list.
- Missing provider fallback fields (country, year, duration, genres, cast, ratings and series counts) are shared in a separate whitelisted display cache by verified TMDb ID. TMDb's canonical record remains separate. No playback URLs, credentials, source IDs, quality, episode identity or progress are published by this cache.
- Shared selected-language provider synopses retain the fullest clean text. Arabic continues to fall back to English only when Arabic is unavailable. Pure adverts no longer populate the synopsis.
- Provider language evidence no longer equates every Latin-script language or Korean/Japanese/Chinese. Uncertain evidence yields to explicitly localized TMDb metadata; recognition is conservative and offline.
- Shared-cache writes that fail before HDD mounting stay pending and retry in the background. Retried writes merge with the existing durable cache to preserve richer information; already-cached legacy Arabic synopsis files remain readable.
- Local verification: 21 regression tests, source compilation, package integrity and isolated upgrade/rollback checks. Enigma2 UI/playback behavior still requires receiver verification.

## V9.2.2 R7 Fix21 (build 966, revision 597; package 9.2.2-r7.21)
- Player, Next Episode card: moved to the bottom-right corner. The visible card now ends 2 px from the right edge and 2 px from the bottom edge of the 1920x1080 screen (screen position 1114,734; the card art's 24 px transparent glow margin lies outside the screen and is clipped). Previously it sat at 1076,666, 16 px from the right and 46 px from the bottom, so it looked too high.
- Only the position changed; size, text, countdown bar and buttons are the same.
- Includes Fix18, Fix19 and Fix20.
- Not seen on a receiver.

## V9.2.2 R7 Fix20 (build 965, revision 596; package 9.2.2-r7.20)
- Synopsis order is now strictly: (1) the server's own text (portal / Xtream / M3U) when it is written in the selected information language, (2) TMDb in that language, (3) the fallback. Before, only Arabic and English could be recognised and Arabic took the LONGEST text from any source, so a longer TMDb text could replace the server's.
- A server text counts as the selected language by its script: Arabic for an Arabic selection, Latin letters for any Latin-script language (English, French, German, Turkish, Spanish ...), and the matching script for Russian / Ukrainian (Cyrillic), Chinese / Japanese / Korean, Hindi, Thai, Hebrew and Greek.
- With Arabic selected, the Arabic text another portal supplied for the same TMDb id (Fix18) is used only when this server has no Arabic of its own.
- Unchanged guards: advert sentences are removed first, and a stub (a tag or one-word category, under 60 characters, 25 for CJK) still yields to a much longer TMDb text.
- Only the synopsis follows this rule; genres, country, language, cast, rating, artwork and logos still come from the shared TMDb record.
- Includes Fix18 and Fix19.
- Not seen on a receiver.

## V9.2.2 R7 Fix19 (build 964, revision 595; package 9.2.2-r7.19)
- One film = one record for every source. The title/year link to the shared TMDb record used to be filed under the item's country/language tag, so a copy named "Title (2026) (CN)" in one portal and "Title" in another (or in Xtream / M3U) never found each other and the second copy stayed without genres, country, language, backdrop and TMDb synopsis (only the portal's own text). The link is now also written without the tag and read back with it, and the compatibility check still refuses a record whose country or language contradicts the item. Links learned before this version are copied across the first time they are read.
- Two different films with the same title and year stay separate (country-tagged links remain; the tag-less one is marked ambiguous instead of guessing).
- Includes Fix18 (shared Arabic synopsis by TMDb id; shared record used before any new TMDb request).
- Not seen on a receiver.

## V9.2.2 R7 Fix18 (build 963, revision 594; package 9.2.2-r7.18)
- One film = one TMDb id = one description. When any portal supplies a real Arabic synopsis for a verified TMDb id (advert-stripped, Arabic text, not TMDb's own overview), it is remembered once per title (`shared_overview.py`, one small file under the persistent index) and shown under every other portal for the same id, instead of that portal's English or empty text. Nothing is written into the TMDb snapshot.
- A portal with no pointer for a title now reads the shared TMDb record first and only asks TMDb when that record is missing or not ready for the selected language. Genres, country, language and overview therefore match across portals, and it still works when TMDb is slow or unreachable.
- Both Details and the Poster Grid 3 side panel use the shared Arabic text.
- Not seen on a receiver.

## V9.2.2 R7 Fix17 (build 962, revision 593; package 9.2.2-r7.17)
- Title logo, fewer requests: Fanart answers are cached for 10 minutes per title (a failure for 45 s), so the four language lanes (ar, en, neutral, any) make one request instead of up to four. The TMDb `/images` request is made once for all policy languages plus neutral logos instead of once per lane, and the TVDB id is looked up once. Results were identical to the previous resolver in 210 simulated cases; TMDb requests dropped by about 27%.
- Poster Grid 3: the title-logo lookup now runs on its own thread, at once when the TMDb identity is known, otherwise right after the metadata request. Overview and cast no longer wait for it, and the focus job still finishes only after the logo is posted.
- Arabic description: a short Arabic synopsis (15+ characters, 3+ Arabic words) now beats an English one, and an Arabic text that quotes several Latin names (3+ Arabic words, a third of the letters) counts as Arabic. Pure advert text is still dropped.
- A snapshot whose overview fell back to English is looked up again after 14 days (rows without a time stamp once). The cached English text keeps showing meanwhile and when TMDb is unreachable.
- Not seen on a receiver.

## V9.2.2 R7 Fix16 (build 961, revision 592; package 9.2.2-r7.16)
- Back to the Fix14 behaviour on Details, Seasons and Episodes: the poster-generated colour is built and applied again (`details_look.ADAPTIVE_COLORS = True`).
- Exception: the description (overview) box keeps the fixed-green glass and is never replaced by the poster-generated one, so it no longer turns dark/black (`details_look.OVERVIEW_FIXED = True`).
- Not seen on a receiver.

## V9.2.2 R7 Fix15 (build 960, revision 591; package 9.2.2-r7.15)
- Details, Seasons and Episodes no longer use a poster-generated colour. The tinted background layer, the generated panel / overview / cast / pill glass and the cinematic edge are not built or shown any more; the fixed Ultra Stalker glass (the material those screens paint first) stays. Nothing changes colour after the poster loads, and the background worker that built them no longer runs for these screens.
- One switch, `details_look.ADAPTIVE_COLORS` (False now). Setting it to True restores the previous poster-adaptive HUD.
- The Adaptive Colors setting text in Settings still says the Details/Seasons/Episodes HUD stays poster-adaptive; it is not changed here because its translations are keyed to that exact sentence.
- Not seen on a receiver.

## V9.2.2 R7 Fix14 (build 959, revision 590; package 9.2.2-r7.14)
- Poster Grid V2 bottom bar: the Fix13 sheen only landed on the four corner arcs (its PNG is opaque up to the image border, so the ring detection missed the straight edges), which showed broken orange arcs at both ends. The sheen is now a continuous rim: red-orange from the top-left, gold to the bottom-right, slightly softer than on the glass bars. The ring detection now pads the image first, so every bar follows its real outline.
- Poster Grid V2 selected-title text: font 72 -> 54 and the box moved to y 943-1011, so the Arabic descenders are no longer cut by the bar.
- Not seen on a receiver; checked on the generated images and the skin geometry.

## V9.2.2 R7 Fix13 (build 958, revision 589; package 9.2.2-r7.13)
- Every bottom bar now ends 2 px above the screen edge (the bar PNGs have one transparent row at each end, so the visible pixels end on row 1077 of 1080). Bars moved down by 15 px (shared grid bar, y 1000 -> 1015) or 1-2 px (Poster Grid V2, compact bars); labels and colour keylines moved with them. Content above the bars did not move.
- Corner sheen on every bar, like the Home cards: red-orange at the top-left corner and gold at the bottom-right corner, fading out along the edges. Baked into the bar images, so there is no extra runtime work.
- Covered: Live (Grid, Columns, Wall), Cinematic, Backdrop Grid 1/2, Poster Grid, Poster Grid V2, Poster Grid 3, Portal list, Free Portal/Xtream library, Local, the portal browser and its Movies/Series category page.
- The dynamic bars (portal browser, Free library, Local, category page) are now five pieces: two fixed corner caps (exact radius), two stretchable sheen strips and a plain middle. Asset set `premium_footer_caps_r5424` replaces `premium_footer_caps_r5423`.
- Not changed: the player/Live infobar and the player zap footer (different surfaces), and Details/Episodes/Search, which show colour keys without a bar.
- Validated offline: skin geometry of every screen above (bar and key positions, idempotence), piece widths for bars from 280 to 1840 px, and the generated images. Not seen on a receiver.

## V9.2.2 R7 Fix12 (build 957, revision 588; package 9.2.2-r7.12)
- Local Movies and Local Series now open in the view selected under Settings > Movies View / Series View (Cinematic, Backdrop Grid, Backdrop Grid 2, Poster Grid, Poster Grid V2, Poster Grid 3), the same dispatch the portal browser uses. Local used to be fixed to Cinematic. If the chosen view cannot be created, Local falls back to Cinematic.
- Offline validation covers the dispatch for every view value and the fallback. Not verified on a receiver: the grid views were written for portal data, so artwork behaviour with Local items needs a check on the device.

## V9.2.2 R7 Fix11 (build 956, revision 587; package 9.2.2-r7.11)
- Details poster no longer grows, shrinks and grows again. Root cause: the raw source poster (fitted by the image loader) was painted first, the finished 352x552 cover-crop was swapped in later, and later events (metadata jobs, TMDb apply, view restore) asked for the raw source again, which repainted it over the finished poster. When the finished derivative already exists on disk, Details now paints only that derivative (`detail_poster.cached_cover_path`, a pure stat-only lookup that uses the same cache key as the builder, so existing caches stay valid). Raw-source repaints of a source that has a derivative are skipped, and the first-paint/restore paths now record the file on screen so identical requests are deduplicated.
- First view of a title that has no derivative yet still shows the raw poster once and then the finished one once; the image work stays off the GUI thread by design.
- Web "Service keys": a key identical to the built-in SubDL/SubSource/TMDB key is never written to api_keys.conf (by design). The page used to say "Verified and saved" and keep showing "Default key is active", which looked like the key was ignored. It now says the key equals the built-in key and the built-in key stays active (`same_as_default` in the response).
- Validation is offline: cache-key parity with the old formula, derivative lookup hit/miss, derivative-first painting (raw never painted), and the same_as_default flag for default and custom keys. Not verified on a receiver.

## V9.2.2 R7 Fix10 (build 955, revision 586; package 9.2.2-r7.10)
- One synopsis on every screen and in every description language. `details_authority.details_overview` is the single decision; `provider_description_for_display` (same pick, provider text only) and `synopsis_text` (text only) are thin wrappers over it. Fix9 limited the Details change to the Arabic description language; it now applies to all languages.
- Cinematic and Backdrop Grid 1/2 no longer fall back to the cached `row["overview"]` when the authority has no text yet (that field can hold a stale other-language snapshot). The cached overview is used only if the authority call itself raises.
- Poster Grid 3: the instant paint (before the background lookup) uses the same provider pick instead of the first raw field.
- Search results and Favorites ask the authority even when the selected-language snapshot is not stored yet (Search without disk access uses the pure-string provider pick), so the list preview matches Details.
- Information card (movie and episode): shows the synopsis the Details box shows. The old "longest text of everything, any language" pick remains only as a fallback while the box shows the loading placeholder. In the series screen the episode card no longer prefers a portal's per-episode description; set `SHOW_EPISODE_OWN_SYNOPSIS = True` in `ui_screens_series.py` to restore that.
- Web Details uses the same authority text.
- Reverts the Fix8 change that returned a provider English synopsis as "not final" while the Arabic snapshot was pending: it made grids and Cinematic disagree during loading. Every screen now shows the same text at every moment; all of them switch to Arabic together when TMDb answers.
- Validation is offline: 1,296 combinations (3 description languages x provider-first on/off x description/plot/descr contents) give identical text for Details first paint, `details_overview` and `synopsis_text`; the Fix8 chooser tests still pass. Receiver installation and on-screen behaviour still require device verification.

## V9.2.2 R7 Fix9 (build 954, revision 585; package 9.2.2-r7.9)
- One synopsis on every screen (Arabic description language). Cinematic, Backdrop Grids, Poster Grid 3, Search and the Information card already asked `details_overview`; Details did not. Details painted the first non-empty raw provider field (description, then descr, then plot) and kept it for any title TMDb never matches, so it could differ from the text shown outside. New `details_authority.provider_description_for_display` applies the same field list and the same Arabic-first pick, and Details uses it for its first paint (`ContentDetailsScreen.__init__`) and for provider callbacks (`_apply_provider_metadata`). It returns nothing for other description languages, which keep their previous behaviour.
- Series screen: the episode Information card falls back to the synopsis the Details box is showing instead of re-reading raw `series_item` fields. An episode's own description still wins when the portal sends one.
- Validation is offline: for 125 combinations of description/plot/descr on an unmatched title, Details now paints exactly what `details_overview` returns (the old rule differed in 83 of them). Receiver installation and on-screen rendering still require device verification.

## V9.2.2 R7 Fix8 (build 953, revision 584; package 9.2.2-r7.8)
- Arabic description: advert sentences that a server appends to a synopsis (links, channel handles, "watch now in HD on our server") are dropped before the candidates are compared, so a padded text no longer wins only because it is longer. The patterns are phrase-level; a plot that mentions Facebook, a server or a subscription is left alone. If every candidate is pure advert, the longest one is still shown rather than an empty box.
- Arabic description: an Arabic text shorter than 40 characters (a tag such as "dubbed" or a category name) is a stub. It is used only when no real Arabic synopsis and no English synopsis exists.
- Arabic description: when the TMDb id is known but its Arabic snapshot is not stored yet and the only text at hand is not Arabic, `details_overview` returns it as not final. Screens that wait for the ready flag no longer paint English first and flip to Arabic. Titles without a TMDb id and Arabic text are unchanged.
- Episode metadata cache: a damaged (non-dict) entry sorts as the oldest during eviction, so it is dropped instead of making every later save fail.
- The main Details path already falls back to another Arabic region (ar-SA, ar-AE ...) through the TMDb translations list before English, so no extra request was added to the legacy single-locale enrich path.
- Validation is offline: targeted simulations of the chooser, `details_overview` readiness and the episode cache, plus package/source checks. Receiver installation, playback and on-screen rendering still require device verification.

## V9.2.2 R7 Fix7 (build 952, revision 583; package 9.2.2-r7.7)
- Repeated numeric seeks bind arrival tolerance to each new step, so a previous large jump cannot acknowledge a later ten-second seek before the decoder reaches it.
- Episode metadata provider aliases are scoped to the source and account. Ambiguous legacy aliases are ignored; metadata keyed by a known TMDb id remains shared. Series-screen reads and background lookups carry their profile through to the cache.
- Episode metadata is snapshotted after acquiring the publication lock, preventing a delayed older writer from overwriting a newer save. Save failures are reported to the caller.
- Details posters keep fully opaque square corners at the existing 352x552 size. The new derivative namespace invalidates rounded crops in disk bundles and fast screen handoffs without deleting original artwork.
- Validation is offline: targeted regression simulations and package/source checks. Receiver installation, playback and on-screen rendering still require device verification.

## V9.2.2 R7 Fix6 (build 951, revision 582; package 9.2.2-r7.6)
- Player seek keys (1/3 = 10 s, 4/6 = 1 min, 7/9 = 5 min) repaired as described under Fix3, and the player and the other very large classes stay split into focused modules (Fix4/Fix5) with no behaviour change.
- YouTube HLS fallback: stream URLs that contain a "|" character are no longer mangled when the itag is recorded; the itag is now carried separately from the URL.
- Episode labels: concurrent writes of the on-disk episode metadata are serialised, so two threads can no longer corrupt or lose the file.
- Localization: clearing the language override now also resets the cached signature, so the next call really reloads the language.
- Portal compatibility: portal URLs with an invalid port or a malformed IPv6 host no longer raise; they are skipped.
- Web Cleaner / Web Browse: import tokens are compared safely, the QR image is written with exclusive 0600 permissions, valid-entry updates run under the state lock, remote backdrop failures are cached for 60 s, and search results use a stable snapshot.
- Storage: schema-read errors are handled cleanly and removing a portal also removes its dependent rows. The legacy parental PIN is compared in constant time.
- Startup cleanup of stale runtime temp files only touches the plugin's own file patterns; release-cleanup preparation and migration are guarded by locks.
- Two unused PortalListScreen methods were removed.
- Verified offline only: compile, import of every module, the regression tests, the static checkers and a function-by-function comparison with Fix3/Fix4 (every difference is an intentional fix above). Receiver installation and playback still require device verification.

## V9.2.2 R7 Fix5 (build 950, revision 581; package 9.2.2-r7.5)
- Internal only, no behaviour change: the other very large classes were split into focused topic modules, the same way the player was in Fix4: `StalkerClient` (`client_mixin_*`, 11 modules), `PortalBrowserScreen` (`ui_browser_mixin_*`), `PremiumGridBase` (`ui_grid_mixin_*`), `ContentDetailsScreen` (`ui_details_mixin_*`), `PremiumGlobalCinematicScreen` (`ui_cine_mixin_*`), `PortalListScreen` and `PortalManagerPremiumScreen` (`ui_plist_mixin_*`, `ui_pmgr_mixin_*`), `M3UClient` (`m3u_mixin_*`), `PortalHomeScreen` (`ui_home_mixin_*`), `PortalGlobalSearchScreen` (`ui_search_mixin_*`) and `NovaSettingsScreen` (`ui_settings_mixin_*`). The original modules keep their names and exports.
- Methods were moved verbatim by a script. The mixins are listed before the existing bases so they override them exactly as the old class body did. `__init__`, methods that name their own class, rebind module globals or use names defined after the class stay in the main module. Runtime dependency injection (`configure_*`) now also reaches the mixin modules, including the lazily configured Settings screens.
- Verified offline: 1,748 class members (all 12 split classes) have identical bytecode, constants, defaults and global resolution before and after; classes that inherit from them were compared too. Every module imports on its own, all files compile, no source line was lost, and the numeric-seek simulation still passes. A deliberate code change in a mixin is detected by the same comparison. Receiver installation and on-screen behaviour still require device verification.

## V9.2.2 R7 Fix4 (build 949, revision 580; package 9.2.2-r7.4)
- Internal only, no behaviour change: the 8,700-line `UltraStalkerPlayer` class was split into twelve focused modules (`services/player_mixin_*.py`: layout, chips, chrome, livebar, epg, subtitles, buffer, playback, search, zap, progress/seek, tracks). `player_native.py` keeps the skins, `__init__`, close/cleanup and the next-episode core, and still exports the same names (`UltraStalkerPlayer`, `force_session_silence`, `shutdown_player_workers`, ...).
- Methods were moved verbatim by a script. The mixins come before the Enigma2 bases in the class list, so they override them exactly as the old class body did. Methods that rebind module globals (next-episode session switch) or name the class directly stay in `player_native.py`.
- Verified offline: all 387 class members have identical bytecode, constants, defaults and global resolution before and after; the numeric-seek simulation still passes. Receiver installation and playback still require device verification.

## V9.2.2 R7 Fix3 (build 948, revision 579; package 9.2.2-r7.3)
- Player seek keys (1/3 = 10 s, 4/6 = 1 min, 7/9 = 5 min): the bar no longer snaps back after a 10 s step, and repeated presses chain from the last target until the engine confirms the jump, so a slow network seek no longer sends the next press to the wrong place.
- Forward seeks stop 15 s before the end of a movie (clips under 2 minutes keep the old 1 s margin); a press already inside the last 15 s is ignored instead of jumping backward. Landing 1 s from the end used to trigger the end-of-file / next-episode logic.
- A seek key pressed while the stream cannot seek yet shows "SEEK UNAVAILABLE" (movies and series only, at most once per second). Such a press no longer cancels the saved Resume position.
- Player startup, resume, event-suppression and watch-time timeouts use the monotonic clock, so an NTP clock jump after boot cannot shorten or stretch them. Wall-clock uses (EPG, "Ends at", saved subtitle choices) are unchanged.
- Playback-buffer rings left on the HDD by a previous Enigma2 run are removed even when their process id has been reused by another program.
- The player adaptive-chrome timer and its pending job are stopped when the screen closes.
- Failures in buffer fallback, startup probing, smart recovery and seek fallback are recorded once in the log instead of being swallowed.
- No change to LEFT/RIGHT: they stay free for the on-screen controls. Offline simulation passed; receiver installation and playback still require device verification.

## V9.2.2 R7 Fix2 (build 947, revision 578; package 9.2.2-r7.2)
- Source export removal cleans all generated Movie/Series/Live bouquets and their index references.
- Recorded plugin services are removed from personal bouquets while other channels and sources stay intact. Cleanup snapshots roll back on failure and failed sources retain their registry for retry.
- Category visibility uses a name-independent source key, with legacy settings read support and migration before renaming a profile.
- Export progress is screen-owned, stopped on cancellation, and released if a job cannot be scheduled. Replacing a poll retires its previous timer.
- Runtime shutdown explicitly closes the category metadata worker pool.
- Includes all R7 Fix1 corrections. Offline regressions passed; receiver installation and playback still require device verification.

## V9.2.2 R7 Fix1 (build 946, revision 577; package 9.2.2-r7.1)
- Live category export keeps existing Movie/Episode media types and excludes them from the Live EPG mapping.
- Web Details creates its Xtream provider client with the existing shared-session factory.
- Arabic description fallback compares existing, original and enriched text before merging; stale short/English provider text can no longer suppress the longest Arabic candidate. Canonical TMDb metadata remains unchanged.
- M3U parsing separates EXTINF attributes from the display title at the first comma outside quoted values.
- Native Search rejects provider error responses and marks unrecognized responses incomplete while keeping valid empty results complete.
- Offline behavior regressions and source checks passed; receiver playback/installation requires device verification.

## V9.2.2 - Release (build 938, revision 569)
- Version is V9.2.2 everywhere (Home, About, Settings, update screens, web pages, package). The V9.2.2 highlights are shown once after upgrading; the update notice text is new.
- Web: premium Movie / Series / Live / Local / Search cards - gradient rim, soft glow running down both sides of the poster and fading out, poster melting into the glow, title under the poster, one chip group (year, age, rating, seasons) at the bottom, Favorite as a bookmark ribbon on the poster. The page background is unchanged.
- Web: Movie and Series Details keep their layout and gain a premium glow around the poster, the description box and the seasons panel.
- Arabic description language: the LONGEST Arabic text from Portal, Xtream or TMDB is shown first; English only when no Arabic exists. Applies to Details, Cinematic, Backdrop Grids, Poster Grid 3, Search, Information card and the Web details. Xtream info is also read when only English text exists so far.
- Web Browse: a slow or failed page no longer ends the folder at "Unable to load more items" - the page is retried once on the receiver and up to 3 times in the browser, then offers "tap to retry". One odd item can no longer fail a whole page.

## V9.2.2 - Export and Player New/New 2 (R12)
- Player New / New 2: a language line in the right column between the Buffer text and the engine box: "Sub: <language>  •  Audio: <language>". Audio is the audio track being played; Sub is the chosen subtitle language (also online subtitles). When no subtitle is chosen it shows "Off" with the languages the film carries, for example "Sub: Off (AR, EN)". It is hidden while a reconnect message is shown. New 2: Portal and Buffer moved up a little to make room.
- Movies and Series folders: new menu choice "Add current Movies / Series folder to a Bouquet" - pick any existing TV bouquet, like the Live folder tools (Series are limited to 2000 episodes per bouquet).
- Every folder export (Live, Movies, Series, add to Bouquet) shows a progress line with the step, a bar and done/total, for example "Posters  [====-------]  20/80  25%".
- The export progress line is shown on the line each screen really displays; on the Categories page it uses the notice line above the footer (the status line used before is not visible there).
- Sending one movie or series to the receiver (grids and Portal browser) also shows the progress line: seasons done/total, then the details-and-bouquet step with the seconds it has taken.
- Exported movies and series keep their description, genre and year for 30 days without a refresh (14 or 7 days for very large exports) instead of 3 days; they are also renewed every day.
- Player New and New 2 moved down to the bottom of the screen, level with Player Old. The quality chip is no longer gold. Player New: "Portal" is centred in its box.
- Player New 2: the engine (for example ExtePlayer3 5002) has its own capsule beside the key dock, which leaves room for the quality chip.
- Player New / New 2: the clock and date move down together with the bar. The buffer text is centred under the portal name, and the buffer line is brighter so it can be seen on the progress line.
- Player New: the clock and date are centred in the right column, and the engine chip moved to the bottom of that column (low in that column, under Portal and Buffer), so the title and chips have more room.
- Player Old, New and New 2: the buffer line is now based on the buffered TIME (the same seconds as the Buffer text). It is drawn stretched so it can be seen: 5 minutes ahead is 12% of the line, at most 25%.
- Quality chip: the picture size is read for up to 90 seconds (it was 5), so slow starts and films with the same size as the previous one still show it.
## V9.2.2 - Episode names + one Player look for every language
- Every episode is now called "Episode 1", "Episode 2"... in the Series list, whatever the portal sends ("01", "S01E02", "Episode 2 - Name"...), so all series look the same.
- When the portal or TMDB has a real episode name, it is shown under the number in the Series list and under "Episode N" in the Player info bar (the Next Episode card shows it too). Episodes without a real name keep the single "Episode N" line.
- The episode runtime (for example "58 min") is shown at the right edge of each Series row when the portal or TMDB knows it. Missing names and runtimes are filled from TMDB once per season (cached); nothing changes if TMDB is off or has no data.
- The Player no longer has an English-only engraved artwork: the technical chips (quality, audio, video, FPS, stream, audio tag, engine) and the colour-key buttons show translated text centred in their boxes in every language, exactly like the other languages. The engraved English images were removed from the package.
- Player New shows the same real episode name: it leads the info line under the title in gold, followed by year, genre and rating. Its chips and colour keys were already plain translated text in every language.
- The episode name is gold in both Players, so it stands out from the rest of the info.
- The small +10s / -10s text no longer appears when you seek with keys 1 and 3 (the seek itself is unchanged).
- Hidden categories: the folders you hide stay hidden, but the "All" row is always kept (Categories page, Player Live list and the web pages) and opens the whole catalogue, so nothing looks missing. Web pages also hide the folders you hid on the receiver, and a hidden folder cannot be opened from an old tab or link.
- Player Old and Player New now use the same black premium material as the Home screen: neutral black glass, and a thin lit edge (red top-left, green bottom-right) on the info bar, the colour-key bar, the technical chips (quality, audio, video, FPS, stream, engine) and the poster. The poster has no frame any more, only the lit edge. Layouts, colours and texts are unchanged.
- New Player look "Player New 2" (Settings > Media > Player View): three floating black-premium panels (channel/poster, info, clock) with the colour keys in their own dock underneath, for Live, Movies and Series. Live shows the programme time, a large title with the minutes left, the progress line and the Next programme; Movies and Series show the title, the gold episode name with year/genre/rating, the progress line, elapsed and remaining time, duration, plot and "Ends at". The poster's bottom edge lines up with the key dock. Player Old and Player New are unchanged in layout.
- The Next Episode card uses the same black premium material.
- Home shortcuts: press BLUE on Home and the seven cards switch to quick settings - Live TV view, Movies view, Series view, Player view, Clean Display Names and Info Bar Timeout. UP / DOWN change the value of the selected card (or press OK, then LEFT / RIGHT), LEFT / RIGHT select the card otherwise, and BLUE or BACK returns to the normal Home. Changes are saved at once and apply the next time that screen opens.
- Player New / New 2 art polish: the progress track now has round end caps like the progress fill, and the boxes, chips and panels no longer carry dark colour in their transparent edges (no dark halo on images that scale or filter the pictures). Player New 2 uses progress art cut for its own line length, and its progress line and dot start at their final size and place (nothing is resized while playing).
- Player New / New 2 and the Next Episode card draw their progress fill with the same 0-100 range as the classic Player (some images ignored the longer range and drew the fill far too long), the text boxes keep a small safety margin so the last character is never clipped, and a technical chip never ends on an opened bracket.
- Player panels, chips, number pill and LIVE pill have a new premium glass material: continuous lit rim, inner depth, dithered gradients.
- Series: episode names and runtimes are saved on the receiver after the first lookup and appear instantly with the episode list.
- Home: the description under the selected card keeps its small size after leaving the shortcuts mode.
- Playback and resume: the start-up, buffer and saved-position code is the same as the official 9.2.1 Player, shared by Player Old, New and New 2 (the earlier extra resume safeguards are removed).
- Player New: the poster now covers the whole left end of the info bar (no empty bar box beside it). The bar re-measures its clock texts only once instead of every second.
- Player: the quality chip shows the real picture size (for example 1920x800 or 1920x1080) instead of a class name; Player Old poster moved left so it covers the info bar edge.
- Home: card description is one line again when it fits.
- Player Old, New and New 2: the black info bars now carry a very light colour wash (red from the left, green from the right, glowing up from the bottom edge) instead of flat black. Layouts and texts are unchanged.
- Live 3 columns: status and export notices have their own line under the guide hint, so no text overlaps.
- Package version 9.2.2-r17.
## V9.2.2 - Live folder tools
- Whole Live folder tools are back on the Live screens (3 columns, Logo wall, classic grid, Portal browser): press MENU to export the current folder as a NEW bouquet, ADD all its channels to an EXISTING bouquet, or export it as an M3U file. Before this they only existed in the Categories page menu, which the 3-column view skips.
- New translation (28 languages): "Add current Live folder to a Bouquet".
- Package version 9.2.2-r5.
## V9.2.2 (R5.546) - Next Episode card
- Next Episode card (Player New style): when an episode ends and a next episode exists, a glass card appears bottom-right with the series poster (no frame), "Next Episode", the series name, the episode, "Next episode starts in N seconds", a countdown bar and three keys: Play now (OK / green), Cancel (BACK / red), Autoplay off (yellow, for this session). The Player info bar is hidden while the card is on screen. The countdown comes from Settings > Next Episode Countdown (5 / 10 / 15 / 20 / 30 s).
- Before this build the next episode started instantly with no card; the old card and its setting were not connected.
- New translations (29 languages): "Play now", "Autoplay off".
- Package version 9.2.2-r4.
## V9.2.2 (R5.545) - Player New (optional) + Info Bar Timeout + category hiding
- Category hiding now behaves the same on every screen: whatever the user hides stays hidden everywhere (Categories page, Live 3 columns, Logo wall, Movies, Series, search, and the Player's Live category drawer). Hide 100 folders and keep 3, and only those 3 are offered.
- MENU on the Categories page has "Manage Categories" again (select several folders, Keep selected only, Hide selected, Show all). It was missing from the menu in the 9.2 builds.
- The provider's "All" row is not offered once any folder is hidden, because it would bring the hidden content back.
- Package version 9.2.2-r3.
## V9.2.2 (R5.544) - Player New (optional) + Info Bar Timeout
- Settings > Media > Info Bar Timeout: how long the Player info bar stays on screen (3 / 6 / 10 / 15 / 30 seconds or Always On). Default 10 seconds. Applies to Live, Movies and Series in both Player Old and Player New, from the next time the Player opens. Always On keeps the bar until OK is pressed; subtitle and server-search pickers still hold it open as before.
- New translations (29 languages): "Info Bar Timeout", "Always On" and the help text.
- Package version 9.2.2-r2 (newer than r1) so receivers that already installed the earlier V9.2.2 receive this update.
## V9.2.2 (R5.543) - Player New (optional)
- Settings > Media > Player View: "Player Old" (default, the classic Player exactly as before) or "Player New". Applies the next time the Player opens.
- Player New - Live TV: one glass bar with the picon card, LIVE badge, channel number + name, chips (quality, audio, video codec, fps, stream, player engine e.g. "ExtePlayer3 5002"), EPG Now/Next with times, programme progress, minutes left / duration, colour keys inside the bar (red, green, yellow, blue in every language), portal / buffer / retry status under the clock, "Loading EPG..." / "No EPG information".
- Player New - Movies / Series / Episodes: same bar with the poster (no frame) standing on the bottom-left corner, "Episode N" pill, playback progress with the downloaded-buffer line, elapsed | info line (episode name, year, genre, rating) | -remaining, duration | plot | "Ends at HH:MM", red key = Buffer, seek hint under the clock.
- Every text is measured with the receiver font: long names shrink, then end with "…"; chips shrink and only then drop the least important (quality and player always stay). Quality chip uses the universal 4K / FULL HD / HD / SD labels in every language.
- Catch-up and trailers keep the classic Player.
- New translations (29 languages): "Player View", its help text, "%d min left", "Ends at %s".
- Package version 9.2.2-r1 so receivers already on V9.2.2 receive this update; the plugin shows V9.2.2 everywhere.

## V9.2.2 (R5.540)
- Built-in TMDB / SubDL / SubSource keys: Settings now shows BUILT-IN instead of FILE ••••, the edit field opens empty (the bundled key is no longer revealed), and pressing OK never writes the bundled key into api_keys.conf.
- Provider keys (SubDL, SubSource, Fanart) are never mirrored into settings.json.
- Your own keys in api_keys.conf still always win; clearing a key falls back to the built-in one.

## V9.2.1 (R5.539)
- Version is V9.2.1 everywhere (Home, About, Settings, update screens, package).
- The online update screen now opens on the Settings background with the Home-style card instead of a black screen.
- V9.2.1 highlights shown once after upgrading.

## V9.2 Final (R5.538)
- Public screens show "V9.2 Final" without the internal R5 build number (Home, About, update notices). Diagnostics keeps the build number for support.

## V9.2 Final (R5.537)
- About box shows "Developer: Ahmed L-HadarY" (translated label in all 29 languages).
- Public release name changed to Ultra Stalker Final V9.2 (package Version 9.2, build 920).
- Includes everything from R5.516 to R5.536: luxury Home-style cards on every screen, redesigned Player, centred translated text in all languages, premium Web pages, stability fixes.
- New localized V9.2 highlights (29 languages) shown once after upgrading.

## R5.536 - Release check
- Player chip labels get a few pixels of safety margin so translated text can never be clipped by the label edge (still centred).

## R5.535 - Premium web cards (replaces R5.534 web styling)
- Browse and Web Cleaner pages: the Home-card corner rim is now only on the real cards (launch cards, Local, panels, categories, Live/Movie/Series cards), sized to each card so the accents stay in the two corners, with soft depth shadows and a coloured lift/glow on tap, hover or keyboard focus. Buttons, tabs and input fields are back to their original look.

## R5.534 - Home card rim on the phone web pages
- Browse and Web Cleaner pages: every card, button, tab, category, Live/Movie/Series card and input field now has the Home-card corner rim (top-left + bottom-right gradient, neutral in between). Active/selected items keep their own look. CSS only, no extra downloads.

## R5.533 - Correct text alignment on every screen
- Details, Search, Browser and floating notices used RT_* list flags for eLabel alignment (same bug as the player chips). All now use the proper eLabel alignment via label_align.py, so centred/right/left text lands where intended in every language.

## R5.532 - Centred translated text in player chips and key bar
- Non-English languages: chip labels and colour-key labels are now sized to the measured text and centred exactly (horizontally and vertically) inside their capsules, for both RTL and LTR text. Fixes eLabel alignment being set with RT_* list flags, which pushed text to the top/side.

## R5.531 - More breathing room between stacked rows
- Settings, portal and list rows are slightly shorter so the bright rims no longer look stuck together (about 10-12 px gap).

## R5.530 - Row spacing restored
- Rows, tiles and panels regained the original transparent margin, so stacked cards no longer touch each other. The search-source row is back to the original file.

## R5.529 - Glass transparency restored on rows, tiles and panels
- Cards from R5.528 were too dark/opaque; they now keep the original translucent glass body (backdrop shows through) with the Home-style corner rim. Also applies the rim to the recent rows and portal rows, which R5.528 missed.

## R5.528 - Home card rims on rows, tiles and panels
- Settings, Portal settings, portal lists, recent rows and Live logo wall cards use the exact Home card rim (same thickness, same corner gradient), each in its Home counterpart colour. Selected items unchanged.

## R5.524 - Black-luxe cards on Local, Search and Favorites
- Local root, Search root and the Favorites tabs use the same black-luxe cards as Home, each with the rim colour of its Home counterpart (Live TV red, Movies, Series, Local, ...). Focused cards are unchanged.

## R5.523 - Black-luxe Home
- Home menu cards and the three Continue panels keep the deep black but gain a fine gradient rim (red to green across the cards), a soft top gloss and an inner shadow; recent rows get a matching neutral rim. Focus visuals are unchanged.

## R5.522 - Poster frame matches the player glass
- Poster frame is now a muted dark-glass band with the same red-to-green gradient and rim as the info panel.

## R5.521 - Live guide layout
- Live: the current-programme line moved up and uses a larger font (25); the next-programme line keeps its place.

## R5.520 - Poster, live picon and chip polish
- Poster + a thicker simple frame (subtle red-to-green gradient) now sit level with the bottom of the key bar, left edge unchanged.
- Live picon is centred in the free space left of the text (horizontally and vertically on the panel).
- Chips: near-neutral dark body so the badge icons stand out; colour kept only as a thin tinted edge.

## R5.519 - Clean poster frame, seamless live picon
- Poster frame: the glow is gone; a clean square frame hugs the poster and lines up with the panel (left edge and bottom).
- Live: the picon card background is transparent so the picon sits directly on the panel with no separators.

## R5.518 - Player layout back to the classic arrangement
- One full-width info panel under the poster (as before), key bar underneath; faint smooth red-to-green tint over panel and key bar; much softer chip tints.
- Poster frame (232x349 art) level with the panel bottom; Portal name on the progress-bar line.
- Progress: mint-to-red gradient play bar and a brighter buffer line so it stays visible.

## R5.517 - Player info bar redesign
- Player panel, key bar, chips and poster frame use the dark opaque Settings glass look with a soft red-to-green tint ramp; poster frame is a single thick muted band with halo, sized exactly to the poster (232x349) and level with the key bar.
- Portal name moved onto the progress-bar line (right side, shortened with an ellipsis when long). Progress fill uses the Settings mint gradient.

## R5.516 - Stability round (inspection report R5.515)
- F01 Restore: the rollback copy is now a coherent SQLite backup-API snapshot taken while all writers are blocked (includes changes still in the WAL). A failed restore always rolls the database back, removes stale -wal/-shm files and verifies quick_check.
- F02 Database locks: one fixed lock order (write lock, then state lock) in initialize/reset; readers wait during a restore swap instead of deadlocking.
- F03 Reload during a slow Details metadata request now delivers the shared job's result under the newest token instead of dropping it.
- F04 Provider backdrop / Xtream enrichment flags are set only after the async job is accepted, so a busy screen can no longer leave them stuck.
- F05 Keyed executor submit (lookup + reservation + enqueue) is atomic: concurrent requests with the same key run once.
- F06 Download resume validates Content-Range start/end/total before appending; a mismatched 206 is rejected and the partial file is discarded.
- F07 Player _cleanup also stops the buffer job and its poll timer/connection (idempotent).
- Diagnostics: the snapshot/cache scan and the support-bundle export now run in worker threads and are delivered to the GUI; the remote stays responsive, closing the screen discards late results. The storage scan no longer re-checks the HDD mount for every file.
- Recording: the recording client is chosen by source type (Xtream/M3U use M3UClient, Stalker uses StalkerClient) like the rest of the plugin.

## R5.515 - Fix Details crash
- Opening a title could raise NameError: _backdrop_candidates in ContentDetailsScreen._load_provider_art (provisional provider backdrop) and drop the metadata update. The helper is now imported where it is used. All other names the Details, Cinematic and grid screens rely on were checked against the values injected by ui.py.

## R5.514 - Clean cast names
- Actor and character names are cleaned for display: Arabic tashkeel and other combining marks, tatweel and invisible bidi characters are removed (they rendered as broken glyphs). Precomposed letters such as hamza stay. Applies to Poster Grid 3 (name and role), Cinematic and Details cast lines. Stored data is not changed.

## R5.513 - Live list shows the same guide as the receiver
- The receiver export finds a guide by trying the channel's other ids (ch_id, stream_id, epg/xmltv id) when the first one answers empty; the Live list and 3-column screens tried only the first id, so they showed fewer guides (log: snapshot with_guide=18 of 26 while the list showed about 8).
- The on-screen fetch now does the same: when a channel's first id is empty, up to two alternative ids are tried and the result is stored for that channel. Xtream/M3U sources are unchanged.

## R5.512 - More channels with a guide (Xtream / M3U)
- When the provider returns no guide for a stream, the plugin now tries the same channel's other stream ids (same epg id or same clean name, e.g. another quality) and uses their guide.
- Channels loaded from an M3U playlist (m3u-live-...) are now mapped to their Xtream stream id through the URL id, tvg-id or a unique clean name; before, they often had no guide request at all.
- Log lines: "Xtream EPG sibling used: stream=A -> B" and "Xtream EPG empty: stream=A (no guide from provider)" show which channels the provider genuinely has no guide for.

## R5.511 - Server description first
- The overview text now prefers the server/provider description when it is written in the selected description language: Arabic selected -> server text if mostly Arabic; English selected -> server text if it reads as English.
- If the server has no text in that language (or only a tiny stub next to a much longer TMDb text), TMDb is used. Any other selected language always uses TMDb.
- Applies to Poster Grid 3, Details/Episodes, Cinematic, Backdrop 1/2, browser and search (single authority). Setting overview_provider_first=False restores the old TMDb-first order.

## R5.510 - Smooth description scroll everywhere
- The slow pixel-smooth description scroll from Poster Grid 3 (1 px / 70 ms, 5 s hold at the top, 6 s at the end) now also runs on Details (and so Seasons/Episodes, which use the same screen), Cinematic, and Backdrop Grid 1 and 2.
- Only for long text: a description that fits at a comfortable size (Details/Cinematic 22 px, Backdrop 1 19 px, Backdrop 2 22 px) looks exactly as before. Longer ones used to shrink to tiny fonts (or, on Backdrop grids, be cut at 650 characters); they now keep a readable size and scroll.
- Shared component ui_smooth_text.py. If the pixel scroller cannot be created, or /etc/enigma2/ultrastalker/disable_smooth_scroll exists, the old shrink-to-fit layout is used. Scrolling pauses while another screen is on top.

## R5.509 - Classic Live list layout
- Classic Live list: the row number moved to the left (same as the 3-column screen); logo and title shifted right accordingly. The EPG mark is inset 12 px from the row edge instead of touching it.

## R5.508 - EPG mark on Live rows
- Live list and Live 3-column screens: channels that have a programme guide get a small green "EPG" mark at the right end of the row (new asset live_epg_mark_40x22.png), so guide-less channels are easy to tell apart.
- The list screen now loads the guide for the whole visible page in the background (shared cache with the 3-column screen and the wall, refreshed every 5 minutes), instead of only the focused channel. Marks are only painted from cache; nothing runs on the GUI thread.
- 3-column screen: the quality badge (4K/FHD...) moved 26 px left to make room. The Live wall is unchanged (it already shows a progress bar per card).

## R5.507 - Receiver channel guide renewed before it expires
- Fixed: in the receiver's own channel list the NOW/NEXT guide disappeared for most channels and came back later. A channel's guide batch was only renewed after its LAST programme had ended, so there was a gap until the background sweep reached that channel again (only long events such as matches stayed visible).
- Batches are now renewed when about 20 minutes remain (checked every minute, at most one soft refresh per 10 minutes per portal), and a new batch replaces the old one only if it reaches further. Fully expired batches are still refreshed immediately as before.

## R5.506 - Instant +/-10 s seeks in the buffer
- Fixed: pressing +10 s (key 3) could stall for about a second and drop the buffer to zero, while +60 s was smooth. The buffer ring only kept data ahead of what had been sent to the player, but the player's own read-ahead sits behind that point, so short seeks landed in already-evicted bytes and forced a new upstream request.
- The ring now keeps a quarter of the buffer size (max 32 MB) behind the playhead, so +/-10 s (and small back-seeks) are served from cache instantly with no empty-buffer flash. Buffer-ahead capacity is correspondingly 75% of the selected size.

## R5.505 - Buffer Auto-Reconnect and Buffer Seconds
- Buffer proxy: if the upstream connection drops mid-stream, it now reconnects automatically at the exact byte offset (HTTP Range) with up to 4 retries (0.3/0.8/1.6/3 s). Permanent errors (400/401/403/404/405/410/416) are not retried and fall back as before.
- Player: buffer is shown as seconds of video buffered ahead (bitrate-aware) plus MB, colour coded: green 20 s+, amber 8-20 s, red under 8 s, amber "Reconnecting n/4" during a retry.
- The buffer text moved off the date: it now sits right-aligned on the info row above the progress bar (1290,865), plain text with no pill under the progress bar.
- Arabic translation added for "Reconnecting".

## R5.504 - Arabic description no longer flips to English
- details_overview(): when Arabic is the selected description language and TMDb only has an English fallback, a same-item Arabic provider synopsis is kept instead of being replaced by the English text once metadata resolves. Applies to every screen that uses details_overview (Grid3, Backdrop grids, Cinematic, Details, Search).
- English or other selected languages, and items with a real Arabic TMDb overview, are unchanged.

## R5.503 - Grid3 Smooth Description Scroll
- Long descriptions in the Grid3 info panel now scroll smoothly (1px every 70 ms, about one line every 2 s) inside a clipped viewport instead of jumping a line at a time. 5 s hold at the top, 6 s hold at the end, then back to the top.
- Short descriptions that fit stay static. Scrolling pauses when another screen is on top and resumes where it stopped.
- Safe fallback: if the pixel scroller cannot be created, or /etc/enigma2/ultrastalker/disable_smooth_scroll exists, the old paged scroll is used (now one line every 2 s instead of 6.5 s).

## R5.502 - Grid3 Panel Soft Glow
- Poster Grid 3 info panel gets a soft cursor-style glow (thin light rim, red top-left to green bottom-right halo), baked into one pre-rendered PNG (grid3_spotlight_panel_glow_590x1020.png): no runtime drawing or extra widgets.
- Panel position/size of all widgets unchanged; the glow lives in a 30px margin around the same 530x960 panel.

## R5.501 - Grid3 Info Panel Layout
- Poster Grid 3 info panel: only Country and Language remain; Episodes and Status rows removed.
- IMDb / TMDb ratings moved up into the freed row; the description box sits right below them, is larger (about 8 lines) and still ends just above CAST.
- Series: Year, Age and Seasons chips are left-aligned and a new Episodes chip (with the Episodes icon) is added. Movies keep the centred Year / Age / Duration trio.
- Grid3 description now drops Arabic tashkeel (display only); the shared strip function returns immediately for text with no Arabic characters.
- No player, portal, download, subtitle or installer changes.

## R5.442 - Search Focus / Favorites Description / Bounded Federation
- Brighter selected portal row indicator, preserving premium card material.
- Search description matches Favorites: six-line width, RTL alignment, display text clean-up, cached localized overview.
- Search completion: bounded wave-aware deadline, per-source progress, no caching of incomplete results; genuine timeouts remain visible.
- No player, portal account, subtitle, download, or installer changes.

## R5.441 - Remove legacy Search portal chooser
- Deleted the unused standalone SubtitleGlassChoiceScreen class and its skin, originally used by multi-portal Search in R5.435.
- Removed its re-export from player_native.py. The current compact Search picker, subtitles, Details, and playback behavior are unchanged.
- No dedicated static PNG existed for the retired chooser; its dynamically-generated premium assets are shared with live Details UI and are preserved.

## R5.440 - R5.435 clean baseline with R5.439 visuals
- Search only: retired multi-portal modal chooser removed; transferred R5.439 in-page compact Settings-style portal selector, its assets and navigation.
- Player visuals only: R5.439 overlay material and fallback HUD PNGs. All R5.435 playback/control implementation unchanged.
- Other screens, catalogs, configuration, installer, updater remain on R5.435.

## R5.246 - Local Counts Always Visible
- Keep the Movies and Series totals visible on both Local Home cards at the same time, regardless of which card currently has focus.
- Browse keeps its existing focus-only subtitle.
- No Local layout, card geometry, focus styling, storage panels, navigation, scanning, Web UI, Downloads, Player, or front-panel behavior changes.

## R5.245 - Plugin Front-Panel Logo
- Add an Ultra Stalker-owned front-panel summary for plugin browsing screens so supported colour/TFT receiver displays show the existing Ultra Stalker plugin icon instead of the image/default clock.
- Reuse the receiver front-display desktop geometry dynamically; large displays center the existing `plugin.png` artwork, while tiny monochrome/OLED displays fall back to a clean `Ultra Stalker` text identity.
- The existing Player LCD/VFD summary is untouched and still takes over during movie/series/catch-up/trailer playback.
- No TV UI, Web UI, Downloads, artwork, player, navigation, or service behavior changes.

## R5.244 - Download Guard + Web CSP + Remove Label
- Prevent re-downloading/overwriting an already completed movie or episode file that still exists on HDD after its Downloads Manager entry was removed.
- Allow the approved browser-direct TMDb artwork fallback in the Web UI Content Security Policy via `https://image.tmdb.org`.
- Rename the blue Downloads action from `Delete` to `Remove` to make its list-only behavior clear; it still never deletes media or `.part` files from HDD.
- No Downloads layout, overlay, focus, progress, player, or other UI design changes.

## R5.243 - Downloads Remove Facade Crash Fix
- Fix Blue Delete crash in the same-screen Downloads overlay by exposing `remove()` on the main lazy Downloads facade used by Details/Series screens.
- Remove remains metadata-only: it removes the selected stopped/completed entry from Downloads Manager and never deletes movie/episode or `.part` files from HDD.
- No UI/layout/overlay/focus/progress changes.

## R5.242 - Downloads Blue Remove-From-List
- Built directly from the audited R5.240 baseline; R5.241 is cancelled and must not be distributed.
- Added the blue Delete action to remove only the selected Downloads Manager entry from downloads.json.
- The blue action never deletes, truncates, renames, or otherwise touches the movie/episode file or .part file on HDD.
- Active queued/resolving/downloading entries are protected; cancel them first with Yellow, then remove the stopped entry with Blue.
- All approved R5.240 Downloads overlay layout, progress, 1090x72 focus, Information-style same-screen frost/dim, and existing actions remain unchanged.

## R5.240 - Release Audit Fix
- Release audit of the R5.239 same-screen Downloads implementation against the R5.237 baseline.
- Fixed the inline Downloads progress-track/progress-fill asset resolver so it uses the exact fixed_master_r63 assets used by the approved R5.237 Downloads panel.
- No panel geometry, row geometry, text, buttons, progress behavior, download engine, or same-screen Information-style presentation changed.

## R5.239 - Same-Screen Downloads Overlay
- Replaced the R5.238 stand-alone Downloads dialog approach with the exact Information presentation model: Downloads widgets now live on the current Details/Series screen and never open or instantiate a second Screen.
- Reuses the same Information dim/frost resolver while leaving the approved Downloads panel, rows, text, buttons, progress line, sizes and Premium Neutral chrome unchanged.
- All existing movie/series download-manager entry points now call the same inline overlay path, so the current page remains rendered underneath.
- Preserved the R5.238 unified 1090x72 Cinematic/Poster-family moving focus indicator; download progress bars are unchanged.

## R5.238 - True Floating Downloads + Unified Focus
- Kept the approved R5.237 Downloads panel, rows, text, buttons, progress line, sizing and fixed Premium Neutral chrome unchanged.
- Download Manager now opens from every existing entry point as a stand-alone overlay window without Session.open(), so the current Cinematic / Details / Seasons / Episodes page remains physically rendered underneath.
- Uses the exact Details Information focus scrim (us88_focus_dim_scrim.png) behind the unchanged Downloads panel.
- Disabled Enigma2 native list selection in Downloads and replaced only the moving selection indicator with the same edge-only focus family used by Cinematic / Seasons / Episodes, bundled at the exact 1090x72 download-row size.
- Download progress bars and all download-engine behavior are unchanged.

## R5.237 - Floating Premium Downloads Overlay
- Downloads Manager now opens as a transparent floating overlay, keeping the current Details / Seasons / Episodes page visibly rendered underneath like the yellow-key Information treatment.
- Removed the separate full-screen black Downloads background and ambient page.
- Replaced the old green/red selected download card with a neutral fixed Premium glass row and restrained silver focus ring.
- Downloads panel height now adapts to the number of visible jobs so a single download does not leave a large empty box.
- Download state, downloaded/total size, percentage and progress line remain live and update every second.
- Download visual chrome remains package-owned and fixed: no adaptive sampling, palette generation, artwork dependency or per-title recolouring.

## R5.236 - Download Manager Restore + Fixed Premium UI
- Rebased directly on R5.234; R5.235 menu changes are not included.
- Download Movie now opens Downloads Manager immediately after a successful/already queued download request.
- Download Episode and Download Season open Downloads Manager after queueing.
- Downloads Manager uses fixed package-owned Home premium material only; no adaptive sampling, palette generation or per-title recolouring.
- Download rows show state, downloaded bytes / total size, percentage and a fixed Home progress line.

## R5.232 - Fixed Premium Dark baseline
- Replaced the old darker Cinematic/Backdrop first-paint chrome with the exact lighter Premium Dark material that R5.230 previously reached only after the fixedoff2 pass.
- Adaptive OFF is now final from first paint: no synthetic fixed adaptive cache lookup, palette analysis, Pillow generation or dark-to-light second swap in Cinematic.
- Cinematic, Backdrop Grid 1 and Backdrop Grid 2 fixed information boxes use the new pre-rendered Premium Dark surfaces.
- Details, Seasons and Episodes fixed description/chrome boxes use the same pre-rendered Premium Dark material.
- Seasons/Episodes fixed rails use the same pre-rendered Premium Dark rows; when Adaptive is ON and real per-title rows become ready, the temporary Poster-style focus ring retires and the original adaptive selected-row material takes over.

# R5.230 — Unified Poster Focus Cursor

- Cinematic, Seasons and Episodes now share one selection cursor.
- Uses the same muted Palestine poster-grid material, 5px rim and glow as the poster pages.
- Normal adaptive row glass remains underneath; only the focus ring changes.
- No layout, navigation, data or backend changes.

# R5.229 — Web Poster Metadata Chips

- Web Movies/Series poster cards now use a compact Poster Grid 1/3-inspired facts lane below the title: year, age certification, rating and series season count when available.
- The duplicate year badge over the poster and the old `MOVIE • YEAR` / `SERIES • YEAR` text are removed from poster cards.
- Card facts use provider metadata first and existing canonical HDD metadata only for missing values. No TMDb/IMDb/provider network request is added by the grid.
- A small RAM cache prevents repeated local metadata reads during infinite scroll/revisits.
- Search copies, Local Movies/Series and Favorites inherit the same poster-card facts design.

## R5.228 - Compact source selector
- Reduced the saved-source selector height and vertical padding on Web Browse.
- Kept source name, source-kind badge and chevron aligned in a tighter premium row.
- Visual-only change; Web behavior and APIs are unchanged.

# Ultra Stalker Changelog

## R5.227 - Compact two-up Live cards
- Live channel catalogue now renders two compact premium cards per row on mobile and desktop.
- Each card shows channel picon, channel name, and a small icon-only Favorite control.
- Removed the separate Play button and LIVE CHANNEL meta line from Live cards.
- Tapping the Live card itself opens the existing player-options sheet immediately; Favorite remains independently clickable.
- Movie, Series, APIs, backend and player-option behavior are unchanged.

## R5.226 - Portal controls final polish
- Moved Home control to the left below Accounts / Portals.
- Moved saved-source count above the source selector, right-aligned.
- Removed remaining green/red source-selector and Live/Movies/Series card chrome.
- Preserved all Browse JavaScript and backend behavior.

## R5.225 - Web premium cleanup
- Removed remaining legacy green/red chrome from saved-source selector, search, details actions, overview, seasons and inline episodes.
- Kept R5.224 layout and web behavior unchanged.

# R5.223 — Premium Neutral Glass Web

- Rebased web presentation directly on R5.219.
- Browse and Web Cleaner layout, HTML structure, icons, JavaScript and backend behavior remain unchanged.
- Replaced green/red web chrome with a premium neutral black/smoked-glass visual layer.
- Added subtle frosted depth, graphite highlights, silver borders, neutral active/focus states and cohesive detail/player styling.
- No API, player, search, local, favorites, portal, Xtream, M3U or cleaner behavior changes.

## R5.219 - Portal Manager Fast Neutral Focus
- Restored lightweight two-row focus repaint in Portal Manager; remote Up/Down no longer rebuilds the full action list on every key press.
- Portal detail/subtext remains visible during focus by supplying both value and count to SettingsGlassList.
- Removed the mint-green focused secondary colour in Portal Manager; details keep the normal neutral colour.
- Free Portal / Free Xtream selection colours, catalogs, parser, cache and runtime are unchanged from R5.218.

## R5.218 - Portal Manager Settings Focus Clean
- Portal Manager action rows now use the exact Plugin Settings group-rail rebuild behaviour on focus changes, so secondary portal information never disappears when a row is highlighted.
- Focused secondary information keeps the approved light mint Settings colour while the title stays bright and readable.
- Removed the permanent Portal Manager helper sentence from the bottom-right in normal action mode; multi-select move mode keeps its required operational instruction.
- Free Portal / Free Xtream runtime, catalogs, parser, cache and library UI are unchanged from R5.217.

# Changelog

## R5.217
- Free Portal / Free Xtream: lowered the far-right information block closer to the footer, enlarged the title, kept it pure white, and centred the title plus both summary lines as one visual unit above Preview.
- Replaced the blue summary tone with a restrained dark green (#6DA487) that belongs to the current Portal backdrop palette.
- Added absolute source numbers to every Free-library card using the main Portal-list numbering grammar; 1-9 render as 01-09, while dedicated font steps keep 3- and 4-digit numbers fully visible without clipping.
- Source names remain pure white, SELECTED remains vivid green, and all backend/catalog/parser/cache/import/preview behavior is unchanged from R5.216.

## R5.216
- Free Portal / Free Xtream: source names now stay pure white (#FFFFFF) on every row, focused or not.
- SELECTED now stays vivid green (#39FF88) on every selected source even when focus moves away; AVAILABLE remains deliberately muted for immediate visual separation.
- Footer placement, backend, bundled catalogs, parser/cache, import/preview behavior and navigation are unchanged from R5.215.

## R5.215
- Free Portal / Free Xtream: moved the title and two-line source/page summary to the far-right, directly above the blue Preview side of the bottom action footer.
- The summary is right-aligned so its right edge tracks the footer instead of floating in the middle of the screen.
- Backend, catalogs, parser/cache, selection colours, import/preview behavior and navigation are unchanged from R5.214.

## R5.214
- Free Portal / Free Xtream: moved the information block to the lower-right area and split it into three clear visual lines: title, source/selected counts, then page/current-source position.
- Selected rows now render `SELECTED` in a strong bright green (#39FF88) while `AVAILABLE` keeps the normal adaptive value colour.
- Backend, bundled catalogs, parser/cache, import/preview behavior and navigation are unchanged from R5.213.

## R5.213
- Free Portal / Free Xtream: fixed the R5.212 runtime NameError by injecting the restored V7 `load_server_library` and `import_server_library_profiles` functions into the Portal List module, where the Free Library screens actually run.
- No UI, catalog, parser, navigation, speed/cache behavior, or other plugin feature was changed.

## R5.212
- Restored the exact bundled Free Portal / Free Xtream catalog payloads and the proven V7 passive catalog parser/import behavior on the approved new R5.211 UI.
- Preserved the fast Xtream parser + mtime/size RAM cache and deferred catalog parsing until after the screen opens.
- Replaced the old V7 footer presentation with the current UltraStalker bottom-right dash actions.

## R5.211
- Portal Manager: Free Portal is now the first entry and Free Xtream the second entry, permanently adjacent regardless of portal-specific actions.
- Free Portal / Free Xtream: finished the data-ready UI shell on the shared Portal background using the exact Settings glass cards and selected-row indicator.
- Added real empty-state, source count, page counter and left/right page-navigation scaffolding. No free-library catalog, loader or importer files are bundled yet.

## R5.210
- Portal Settings: restored the Free Portal and Free Xtream entries using the exact approved Settings glass rows, selected-row indicator and Portal background.
- Added isolated UI-only Free Portal / Free Xtream shell pages. No catalog, loader, importer or bundled free-library data is included yet; backend files are intentionally deferred to the next stage.

## R5.209
- Details > Information, cleaner layout (as in the approved mock-up): the duplicated facts box is gone; ONE meta line (rating, date, runtime, genres) sits under the title. The overview box is tighter with an OVERVIEW label; Cast / Director / Writer boxes are taller; the vote count moved under the IMDb/TMDB box; Status joined the Original/Language/Country line.
- The in-player information overlay keeps its own frame sizes.

## R5.208
- Details > Information (and the in-player information overlay): the panels are the unified black glass (dark fill, grey rim, fine inner line) instead of the blue/purple tint taken from the poster. Nothing is derived from the poster any more, so the frames are built once. The poster frame is a neutral grey rim.
- Information text: the light-blue labels / meta line are now the app mint (#8FE9BA) and the facts text a neutral off-white.
- Removed an unused duplicate of the information-frame builder (player_visuals) and the old poster-tinted frame files from the cache.

## R5.207
- MENU lists (Cinematic / Details / Categories): the focused entry no longer loses its last letters (e.g. "Replace Backdrop (HQ" instead of "(HQ)"). The list is now sized 14 % + 24 px wider than the measured text because the focused face is larger.

## R5.206
- Search results: the title stays plain white (no colour change, same size). The focused poster gets the unified poster cursor, exactly the poster size (206x310).
- Favorites (Movies / Series): the focus frame is the same unified cursor, exactly the poster size (232x348); the old oversized frame was removed. Move mode keeps its amber frame.
- Player: the poster frame is now a thin dark-grey rim with a fine inner line, the same language as the info bar panels and chips (square corners, no thick silver border).

## R5.205
- Search speed: up to 10 sources are searched at once (was 6), so far more of a large source list is covered inside the time limit.
- Search order: each source's last speed / failure is remembered; fast sources go first and sources that failed in the last 10 minutes go last (none are skipped).
- Search cache: the same query repeated within 10 minutes (e.g. from Recent searches) is shown instantly from memory with no network.
- Favorites > Live: icons no longer appear huge and then shrink. Until the correctly sized 184x110 icon is ready the small bundled Live icon is shown, and it is replaced when the icon is built.

## R5.204
- Package size: the bundled Recent-searches rows now come in 40 px width steps (8 sizes instead of 16 per state), halving that asset set. No visual change. Old superseded builds are no longer kept next to the new one.

## R5.203
- Search, MENU > Recent searches: the boxes are no longer green. They use the Home card material (black glass; the focused one gets the Home green-to-red rim) from bundled pre-sized rows, so opening the list does no image processing any more (this removes the lag on MENU / picking a recent search).
- The list opens further right (from x=960) so it no longer overlaps the "Recent searches" hint.
- Search text area: "MENU" is now a small key chip with "Recent searches" next to it on the Search-key row, and the status line uses a calmer grey.

## R5.202 (R5.201 repack: the page counter text now uses an existing translated string)
- Same changes as below.

## R5.201
- Movies / Series grids: pressing DOWN (or UP / LEFT / RIGHT at the edge) to hop a page now behaves as one press = one page. While that page is loading, extra presses in the same direction are ignored instead of being stored and jumping several pages when the load finished. The page counter also switches to the target page immediately, so the press is visibly accepted. Presses within the first 110 ms still merge (held key), and the opposite direction is always accepted.

## R5.200
- Movies / Series / Live: after resting about 0.65 s on a category, its first page is fetched in the background into the existing page cache (one request at a time, nothing is painted, skipped while scrolling fast). Pressing OK on that category then opens from cache instead of waiting 2-3 s for the portal.

## R5.199
- Favorites: the saved list is read from SQLite (and JSON-decoded) once per favorites revision and then served from memory. Opening Favorites and moving between the Live / Movies / Series tabs no longer opens the database again; the grouping per type and the tab counts are computed once. Add / remove / reorder invalidate the cache.
- Search: the recent-searches file is parsed once and re-read only when it changes.

## R5.198
- Search: the Movies / Series tiles now use the Local home cards (380x330 focused, 340x296 idle), the big neon line icons centred in the card, the title under the icon and the result count INSIDE the card (it used to sit below the tile).
- Favorites: the Live / Movies / Series tabs use the same big neon icons placed centred with the title and the item count inside the tile; tile size is unchanged because the rail below needs the room.

## R5.197
- Poster focus cursor (Poster Grid 1/2/3, Backdrop Grid 1/2): rim is now 5 px (was 3) with a slightly stronger halo, so the focused poster stands out clearly.
- Backdrop Grid 1 and 2: the poster frames are neutral silver (no mint/teal) and the five info boxes (year, quality, runtime, genre, overview) are the ONE fixed set like Cinematic. Nothing is derived from the poster any more, so the per-title HUD builder and its cache were removed.
- Settings: long help texts (e.g. Adaptive Colors) were cut off at the bottom of the right card. They now wrap into up to 4 lines (16/15 px) inside a taller text box and nothing is lost.

## R5.196
- Player poster frame is now square like the poster itself (R5.195 rounded the inside and left dark square corners). Same exact 250x375 size and position, 3 px silver rim in the Player bar colour.

## R5.195
- Player poster: the outer halo and the oversized frame around the poster are gone. The poster now has ONE frame, exactly the poster size (250x375, same position), in the Player bar's own dark glass colour with a thin silver rim and softly rounded corners. The unused poster_halo image was removed.

## R5.194
- ONE focus cursor for Poster Grid 1, Poster Grid 2, Poster Grid 3, Backdrop Grid 1 and Backdrop Grid 2: a muted Palestine-flag ring (green, soft white, dark, red) with a soft halo. Each screen has its own file at the exact size of its card and the same corner shape as its card (square top / rounded bottom on Grid 1 and 3, small radius on Grid 2, square on both Backdrop grids). Adaptive Colors ON or OFF no longer changes the cursor and no per-poster focus overlay is built, loaded or swapped.
- Removed the 3 old cursor images and the dead per-poster cursor builder.

## R5.193
- Poster Grid 3 info panel: genre chips (Drama / Comedy ...) are now rounded dark-glass pills identical to the year / age / rating pills (all 57 widths rebuilt, same sizes).
- Cleanup: removed the unused oa_diag_panel.png, the dead per-poster page-background builder and its worker, and a one-time purge deletes the old gridmood_*.jpg cache files from the HDD.

## R5.192
- The background WITH the Free Palestine mark is now used only by the Portals list and the Settings pages. Every other screen (Home, categories, Live, Favorites/Catch-up/Search, Local library, Diagnostics, release notes, Live wall/columns) uses the same background without the mark, so it can never overlap content.

## R5.191
- Poster Grid / Poster Grid 3: the static background no longer carries the corner brand mark that overlapped the info panel; same colours, a clean copy (ultra_bg_clean_1920x1080.png, 618 KB vs 696 KB). Other pages keep the original background.

## R5.190
- Poster Grid and Poster Grid 3: the page background is now the plugin's one bundled static background (same as the category pages). The poster-derived adaptive background (blur built per poster, cached and re-loaded on every move) is removed completely, so moving between posters no longer builds or reloads a full-screen image. Cards and focus ring are unchanged.

## R5.189
- Poster Grid / Poster Grid 3 / 9-column grid with Adaptive Colors OFF: every poster now sits on the SAME card (poster + title tray + rim, the shape the adaptive card has) in the unified black glass, bundled at the exact size of each grid (236x418, 206x382, 240x424). It is applied in the first paint and nothing is built or swapped afterwards, so cards no longer blink or load per poster.
- Poster badges (year, rating, age rating): rebuilt as rounded dark-glass pills like the info-panel pills instead of the old boxes with notched corners (all 7 sizes, same dimensions).

## R5.188
- New Movies / Series placeholders (shown while a poster is missing or loading): a calm dark glass card with the plugin's own line icons - the clapperboard for Movies, the stacked-play icon for Series - replacing the old blue 3D icon with the green/red frame. Same file names and now 236x354 (2:3), so every screen that shows them (Poster Grid, Poster Grid 3, Details, Favorites, Web) picks them up.

## R5.187
- Poster Grid and Poster Grid 3 with Adaptive Colors OFF: every poster uses the ONE bundled neutral card (same size as the poster) and the bundled flag focus ring. No per-poster card or focus overlay is scheduled, built, loaded or swapped, so nothing appears one by one when changing pages, and old coloured cards cached earlier are no longer replayed. Adaptive ON is unchanged.
- Poster cards: the watch-progress fill is the flat silver bar (was a green gradient).

## R5.186
- Poster/Cinematic/Backdrop/Live grids: a small category no longer turns into the whole catalogue. When a Stalker series category ended (an empty later page), the grid retried the page using the category *name* as the category id; portals answer an unknown id with the entire list, so a category of 8 series suddenly showed `Page 1 / 4890 - Series 10 / 48895`. The name retry is now limited to an empty FIRST page of a series category that reported no total (M3U behaviour unchanged). This is the shared grid loader, so every grid screen is covered.

## R5.185
- Title cleaning: a short abbreviation followed by the real name in brackets (`SH (سيدو وحرية)`, `SH [Sido w Horeya]`, `FR (Le Parrain)`, `SH - (...)`) no longer collapses to just `SH`; the bracketed name is used for display and for the TMDb/Fanart search (the search previously stripped all brackets and looked up `SH`). Years, quality tags, country codes and season tags in brackets are still removed.
- Title cleaning: a number after a slash is part of the name (`50/50`), not a routing tag; empty `( )` left by `(4K)` is removed.

## R5.184
- Title cleaning audit (display and TMDb/Fanart search title):
  - All-caps real titles such as `SPIDER-MAN - HOMECOMING` are no longer cut to `HOMECOMING` (the generic `XX-YY - Title` prefix rule now needs a known routing token first).
  - Language prefixes `DE - / DE | / DE:` and provider tags `NF -`, `AMZ -`, `DV` are removed from the displayed name too.
  - Trailing noise is removed: ` - DE`, ` - 2025`, ` - DV`, `DV HDR`, `مترجم/مدبلج`, a year placed before a quality tag (`Joker 2019 4K`), `AR-SUBS`, and an unbalanced `(DE`.
  - `AR-AS-D - Title` now also cleans the lone `D` for search. Real titles such as Fantasia 2000, Blade Runner 2049, X-Men, One-Punch Man are untouched.

## R5.183
- Title cleaning: portal routing prefixes made of a language code plus technical tags (for example `DE-DV- /PLUS - Dune`, `FR-4K - ...`, `DE-HDR+ - ...`) are removed both for display and for the TMDb/Fanart search title. Before, the raw prefix was searched, so no poster, backdrop or information was found. Real hyphenated titles (X-Men, One-Punch Man) are untouched.

## R5.182
- Cinematic with Adaptive Colors OFF: after the fixed surfaces are applied once, navigating no longer schedules any adaptive work (no per-title worker thread, no 450 ms adaptive timer commit, no chrome re-check). Only the backdrop, logo and information follow the focused title. Adaptive ON is unchanged.

## R5.181
- Edge cursor: back to the R5.179 frame (bright white part restored) - R5.180's grey was reverted on request.
- Navigation: the Adaptive Colors switch was re-read from settings (full settings copy) on every chrome/palette/accent call, many times per Cinematic move. It is now cached for 2 s and invalidated on save, so toggling still applies at once.

## R5.180
- Edge cursor: the white part of the frame is now a calm grey instead of bright white, so it no longer glows or spoils the look on dark artwork. Same size, thickness and glow.

## R5.179
- Edge cursor: the frame now carries all four Palestine colours (green, a soft white, a soft black, red) with the same thickness and glow.
- Edge cursor: a light flat scrim inside the frame keeps the title, the progress bar and the percentage readable on bright artwork (the first row was washed out).

## R5.178
- Cinematic and Episode lists: the focus cursor is now an edge-only frame (flag green to red, thin rim plus a very small inner edge glow) with a fully transparent interior - no glass fill.
- Cinematic/Episode rows: the watched-progress bar stays put while navigating. Its cache key depended on the per-title accent colour, so every move missed the cache and the bar vanished until rebuilt; the flat bar is now accent-independent and reuses the built file.

## R5.177
- Player: the info bar, keys bar and poster frame now use the same neutral grey glass as Home/Settings. The poster-derived navy/blue chrome (and the green fallback) are gone, so nothing changes colour after the Player opens.
- Player: the watched progress is the flat silver bar (no laser/glow tip, no green).

## R5.176
- Cinematic continue-watching rows and episode rows: the old laser line with the glowing ball is replaced by the flat silver progress bar used across the plugin; it no longer disappears/reappears on focus.
- Player: the progress line no longer flashes the bundled green first and then switches to the adaptive blue; it stays hidden until the adaptive colours are ready (or the build fails, then the bundled accent is used).

## R5.175
- Adaptive Colors OFF: the focused row/episode surface is now the bundled Home/Settings cursor material (the flag-coloured focus) at the exact size, so the cursor looks the same from first paint and no longer changes when the neutral set swaps in. Normal rows stay the neutral grey glass.
- Adaptive Colors OFF: the poster-coloured screen wash (tinted background field, Cinematic backdrop tint, Backdrop Grid HUD counter/clock) keeps following the poster colour; only frames, menus and the cursor use the fixed look.

## R5.174
- Adaptive Colors OFF: all fixed surfaces are pure neutral grey glass (no hue, so no red/green tint); the focused episode/row surface is the same black glass lifted to a softer translucent grey. Backdrop Grid HUD uses the same neutral set (new cache tag).
- Cinematic: DOWN on the last title / UP on the first now wraps to the other end even when the whole folder fits on one page (e.g. 5 titles); before it tried to reload the page it was already on and did nothing.

## R5.173
- Adaptive Colors OFF now uses a neutral black-glass palette matching the Home cards (grey rim, near-black fill). R5.171/172 derived the fixed palette from the green Home accent, which tinted the surfaces green after the static glass appeared. Old green fixed files are ignored (new cache tag).

## R5.172
- Adaptive Colors OFF: the colour cover layers (details/episode chrome, the tinted background field, aux frames, Backdrop Grid HUD) are still generated - with the fixed palette - so they keep hiding the backdrop underneath. Verified by building them in OFF mode.
- OFF no longer reuses poster-coloured surfaces stored in a title's bundle by an earlier ON session, and never writes fixed surfaces into it, so switching back ON is clean.

## R5.171 - Adaptive Colors switch
- New Plugin Settings option "Adaptive Colors" (ON by default = unchanged behaviour). OFF gives Details, Seasons, Episodes, Cinematic, Backdrop Grids and the Player one fixed palette instead of poster-derived colours; artwork, title logos, info and the cursor are untouched. OFF builds each chrome set once and reuses it for every title.
- Applies the next time a screen is opened. Settings, Portal Manager and Home are unaffected.

## R5.170
- Live channel icons: while the exact row-size icon is being prepared the row keeps its placeholder instead of flashing the raw oversized provider picon (the "grow then reappear" effect). Prepared icon paths are remembered in RAM so revisiting a page paints the final icon in one step.

## R5.169
- Poster grid side panel: the focused title's poster is prepared on its own small thread instead of waiting in the shared metadata queue behind the page's TMDb work, so it appears as soon as the grid poster exists (polls ~8 s if the grid poster is still downloading).

## R5.168
- Fix: in the 3-row poster grid the side-panel poster for the first focused title stayed empty until you moved away and back. When the grid poster was still downloading at focus time, the panel now waits for it (up to ~8 s) in a side thread and paints it as soon as it exists.

## R5.167 - Navigation and Portal Manager style
- Portal Manager list uses the same premium boxes as the Plugin Settings left rail.
- Plugin Settings: RIGHT on the category rail no longer jumps into the options; OK enters, BACK returns.
- LEFT/RIGHT page through lists without wrapping; poster grids hop to the previous/next page at the first/last card; portal tiles no longer wrap.
- Category screens: exact-size folder icons, so the unselected folder is no longer cropped.

## R5.166
- Fix: the small poster, cast portraits and details were missing since R5.164. The stricter JPEG/PNG end-marker check added to artwork validation rejected valid cached images that carry trailing bytes; validation is header-only again.

## R5.165
- Language packs re-saved in compact form (same content, ~0.4 MB smaller unpacked); the earlier merge had left them pretty-printed.

## R5.164 - Performance phase 2
- Poster grid: hero/logo disk lookups moved off the GUI thread; the cache probe for visible posters covers the focused card and its neighbours first and the rest a moment later; helper timer runs only while work is pending.
- Artwork/TMDB caches: no fsync on re-downloadable image/manifest/marker writes; truncated JPEG/PNG files are rejected and re-fetched; artwork log writes are cheaper.
- Content-quality cache kept in RAM and flushed compactly in the background; image loader remembers misses for 5 s.
- Xtream/M3U: last 3 categories kept parsed in RAM (page flips no longer unpickle 25k rows); only the returned page is copied; auth-marker scan no longer serialises whole catalogues.
- Portal requests: once an endpoint is proven, a transient failure is raised immediately instead of retrying every candidate; search fetches up to 3 categories concurrently.
- EPG refresh: no per-channel sleep (back-off only on throttling) and per-channel responses are no longer written to the flash cache.
- Response cache: expired rows purged every 10 minutes; RAM tier bounded by size.
- Search: details panel reads from disk only after 150 ms of focus. Home: only the old and new cards are restyled; recent list cached per history revision. Browser: category titles cached. Splash: fewer timer stages.

## R5.163 - Performance phase 1
- Live Wall/Columns: no more font re-fitting of two hidden labels on every key press; the last Live category is saved in a background thread (only when it changed).
- Portal list/Home/Splash/Search: load_profiles() is cached until portals.txt, profiles.json or the disabled list change.
- Browser root: favorites/continue-watching counts are cached per portal (refreshed on any change) instead of reading ~1000 rows several times per open.
- Home warm-up splash: minimum visible time 1350 ms -> 400 ms.
- Title cleaning is memoised (same output, no repeated regex work for the same title).
- One shared verified TLS context instead of building a new CA store context for every image/portal connection.

## R5.162
- Splash / portal-entry progress bar: the bright dot at the end of the bar is removed; the same green-to-red gradient remains.

## R5.161
- The Free Palestine emblem moved to the top-right corner inside the shared background (same pixels, lossless PNG, old spot refilled from the surrounding gradient). The Live wall cover patch was removed and its page counter shifted left of the emblem.

## R5.160
- Diagnostics now shows the shared Ultra background (extra dimming layer removed, background also painted at runtime like Settings).
- The one-time V9.1.3 highlights popup is drawn over the shared background instead of a black screen.

## R5.159
- Diagnostics screen redesigned to the new look: unified background, six tile cards (plugin & system, playback engines, libraries, storage & cache, network performance, selected portal), colored status dots, status bar with the log path, and three key chips (GREEN refresh, YELLOW support bundle, BLUE log path). 47 new strings translated in all 28 packs.

## R5.158
- Player: a stale link-refresh result no longer stops the poll timer of a newer retry; zapping cancels the previous channel's pending retry; VOD/series re-seek to the last position after a link refresh or restart (no more 0:10 overwriting the bookmark); a dropped connection with unknown length is no longer saved as completed and no longer autoplays the next episode.
- Subtitles: SRT millisecond fields were mis-scaled (",050" read as 500 ms); now exact.

## R5.157
- Localization completion: playback-failure reasons shown in the error popup are translated (new keys in all 28 packs), "Live preview"/cached-subtitle/default portal labels translated, count-neutral wording for plural-sensitive values in ar, ru, uk, pl, cs, sk, hr, sr.
- Tests: new keys covered by the pack-key test.

## R5.156
- Localization: Live-view description in all packs, parental-PIN messages translated, count-neutral wording instead of "item(s)" plurals, weekday/month abbreviations no longer cut for CJK/Arabic/Persian.
- Stability: proxy stop no longer blocks the GUI thread, proxy start/stop serialized, unique temp names for config writes, SQLite thread connections closed after search workers, restore bumps connection generation.
- Hardening: ticket stream route origin check, stream redirect scheme/host guard, safer log/restart-helper temp files, setgid cleared, state dir 0700.
- Tests: 34 tests (shell syntax, payload hygiene, pack keys vs code, redirect guard, parental, proxy stop).

## R5.155 - Cleanup, docs, tests
- Removed unused module-level constants and variables (no behaviour change).
- Added README.md and CHANGELOG.md.
- Expanded test suite.

## R5.153 - Full localization
- 14 languages: bouquet and metadata strings localized.
- Localized status words; weekday and month names via `localized_strftime`.
- Performance caches now have size caps.

## R5.152 - Security and packaging hardening
- Web interface Host/Origin guard.
- Size cap on subtitle zip extraction.
- Timeout for opkg calls.
- XMLTV cache moved off flash.
- URL guard for outgoing requests.
- Added/hardened postinst, preinst and postrm scripts.

## R5.151 - Live wall cover
- Cover artwork for the live wall.

## R5.149 - Unified background
- Single unified background across screens.

## R5.148 - Smooth home icons
- Smoother home icon rendering and transitions.

## R5.147 - Player keybar Arabic
- Arabic support in the player keybar.

## R5.146 - Language complete
- Language packs completed and marked complete for selection.

## R5.145 - Track memory
- Track selection memory (audio/subtitle choices remembered).

R5.233 - Adaptive first-row cursor commit, cold-source fallback, and Details/Seasons/Episodes HUD adaptive exception.
R5.234 - Poster Authority + Cinematic Fast Hydration: visible Grid/Cinematic poster stays authoritative through Details/Player; Cinematic title-logo settles at 180 ms and metadata at 360 ms without requiring a Details open.
