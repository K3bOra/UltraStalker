# -*- coding: utf-8 -*-
"""Live LCD summary using the Player's cached provider logo, on OE-A and DreamOS."""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str, int, max, min, us_func
os = _us_env.os

from Screens.Screen import Screen
from Components.Label import Label
from Components.Pixmap import Pixmap
from enigma import ePicLoad, eTimer, getDesktop

from .log import optional_failure


def live_front_skin(width, height):
    width, height = max(1, int(width)), max(1, int(height))
    graphical = width >= 96 and height >= 48
    margin = max(2, min(8, width // 40))
    text_h = max(16, min(30, height // 5)) if graphical else height
    logo_h = max(1, height - text_h - margin * 2) if graphical else 1
    logo_w = max(1, width - margin * 2) if graphical else 1
    text_y = height - text_h if graphical else 0
    font = max(10, min(22, text_h - 3))
    skin = '''<screen name="UltraStalkerLiveFrontSummary" position="0,0" size="%(w)d,%(h)d" backgroundColor="#000000" flags="wfNoBorder">
        <widget name="picon" position="%(m)d,%(m)d" size="%(lw)d,%(lh)d" alphatest="blend" transparent="1" />
        <widget name="title" position="0,%(ty)d" size="%(w)d,%(th)d" font="Regular;%(fs)d" halign="center" valign="center" foregroundColor="#ffffff" backgroundColor="#000000" noWrap="1" />
    </screen>''' % dict(w=width,h=height,m=margin,lw=logo_w,lh=logo_h,ty=text_y,th=text_h,fs=font)
    return skin, (logo_w, logo_h), graphical


class UltraStalkerLiveFrontSummary(Screen):
    def __init__(self, session, parent):
        us_func(Screen.__init__)(self, session, parent=parent)
        self._player = parent
        try:
            desktop = getDesktop(1)
            size = desktop.size()
            width, height = int(size.width()), int(size.height())
            if width <= 0 or height <= 0:
                raise ValueError("no graphical front display")
        except Exception:
            width, height = 132, 64
        self.skin, self._logo_size, self._graphical = live_front_skin(width, height)
        self["title"] = Label("")
        self["picon"] = Pixmap()
        self._visible = False
        self._closed = False
        self._desired = None
        self._active = None
        self._applied = None
        self._failed = None
        self._decoder = ePicLoad()
        self._decoder_connection = None
        self._decoder_ready = False
        try:
            self._decoder.PictureData.get().append(self._picture_ready)
            self._decoder_ready = True
        except Exception:
            try:
                self._decoder_connection = self._decoder.PictureData.connect(self._picture_ready)
                self._decoder_ready = True
            except Exception as exc:
                optional_failure("frontpanel.live_decoder_bind", exc)
        self._timer = eTimer()
        self._timer_connection = None
        try:
            self._timer_connection = self._timer.timeout.connect(self._tick)
        except Exception:
            self._timer.callback.append(self._tick)
        self.onShow.append(self._start)
        self.onHide.append(self._pause)
        self.onClose.append(self._close)

    def _start(self):
        if self._closed:
            return
        self._visible = True
        self._applied = None
        self._tick()
        self._timer.start(1000, False)

    def _pause(self):
        self._visible = False
        self._timer.stop()

    def _tick(self):
        if self._closed or not self._visible:
            return
        player = self._player
        item = getattr(player, "item", None) or {}
        title = str(getattr(player, "name", "") or item.get("name") or "Live TV")
        if self["title"].getText() != title:
            self["title"].setText(title)
        path = str(getattr(player, "_front_live_picon_path", "") or item.get("_player_picon") or "")
        # A missing channel logo must never display the previous channel's logo.
        if "placeholder" in os.path.basename(path).lower():
            path = ""
        identity = str(item.get("id") or item.get("stream_id") or item.get("ch_id") or title)
        desired = (identity, title, path)
        if desired != self._desired:
            self._desired = desired
            self._applied = None
            self._failed = None
            self["picon"].hide()
        if (not self._graphical or not self._decoder_ready or not path or
                self._active is not None or desired in (self._applied, self._failed)):
            return
        try:
            if not os.path.isfile(path):
                return
            self._decoder.setPara((self._logo_size[0], self._logo_size[1], 1, 1, False, 1, "#000000"))
            self._active = desired
            result = self._decoder.startDecode(path)
            if result not in (None, 0):
                self._active = None
                self._failed = desired
        except Exception as exc:
            self._active = None
            self._failed = desired
            optional_failure("frontpanel.live_decode", exc)

    def _picture_ready(self, *args):
        active, self._active = self._active, None
        if self._closed:
            return
        try:
            pixmap = self._decoder.getData()
            if active == self._desired and self._visible and pixmap is not None:
                instance = self["picon"].instance
                if instance is not None:
                    instance.setPixmap(pixmap)
                    self["picon"].show()
                    self._applied = active
            elif active == self._desired and pixmap is None:
                self._failed = active
        except Exception as exc:
            self._failed = active
            optional_failure("frontpanel.live_apply", exc)

    def _close(self):
        self._pause()
        self._closed = True
        try:
            if self._timer_connection is not None:
                self._timer_connection.disconnect()
            elif self._tick in self._timer.callback:
                self._timer.callback.remove(self._tick)
        except Exception:
            pass
        try:
            if self._decoder_connection is not None:
                self._decoder_connection.disconnect()
            else:
                callbacks = self._decoder.PictureData.get()
                if self._picture_ready in callbacks:
                    callbacks.remove(self._picture_ready)
        except Exception:
            pass
        self._player = None
