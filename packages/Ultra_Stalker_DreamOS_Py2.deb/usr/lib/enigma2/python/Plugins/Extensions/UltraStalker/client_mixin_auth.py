# -*- coding: utf-8 -*-
"""Handshake, authorisation, profile initialisation and account info.

Methods moved verbatim out of ``StalkerClient`` (client.py); behaviour is unchanged.
This module is imported by client.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, max, min
from .client import (
    EMULATOR_USER_AGENT,
    LOG,
    OrderedDict,
    PortalCancelledError,
    PortalError,
    compatible_identity,
    endpoint_log_label,
    hashlib,
    json,
    portal_roots,
    random,
    re,
    same_origin,
    string,
    time,
    urllib,
)


class ClientAuthMixin(object):
    """Handshake, authorisation, profile initialisation and account info."""

    # ------------------------------------------------------------------
    # MAG authorization
    # ------------------------------------------------------------------
    def _compat_handshake_candidates(self, limit=6):
        """Return a bounded, root-diverse endpoint set for identity/UA fallback."""
        try:
            limit = max(1, min(int(limit or 6), 6))
        except (TypeError, ValueError):
            limit = 6
        ordered = []
        for endpoint in ([self._compat_cached_endpoint] + list(self._compat_discovered_candidates)
                         + list(self._candidate_endpoints())):
            endpoint = str(endpoint or "").strip().rstrip("/")
            if endpoint and endpoint not in ordered:
                ordered.append(endpoint)

        selected = []
        # Proven/discovered hints go first because they were learned from this
        # exact portal, but never exceed the global bound.
        for endpoint in ([self._compat_cached_endpoint] + list(self._compat_discovered_candidates)):
            endpoint = str(endpoint or "").strip().rstrip("/")
            if endpoint and endpoint in ordered and endpoint not in selected:
                selected.append(endpoint)
                if len(selected) >= limit:
                    return selected

        def endpoint_shape(endpoint):
            parsed = urllib.parse.urlsplit(endpoint)
            path = re.sub(r"/+", "/", parsed.path or "/")
            low = path.lower()
            if low.endswith("/server/load.php"):
                root_path = path[:-len("/server/load.php")] or ""; kind = 0
            elif low.endswith("/server/portal.php"):
                root_path = path[:-len("/server/portal.php")] or ""; kind = 1
            elif low.endswith("/portal.php"):
                root_path = path[:-len("/portal.php")] or ""; kind = 1
            elif low.endswith("/portal1.php"):
                root_path = path[:-len("/portal1.php")] or ""; kind = 2
            else:
                root_path = path.rsplit("/", 1)[0] if "/" in path else ""; kind = 3
            root = urllib.parse.urlunsplit((parsed.scheme, parsed.netloc, root_path, "", "")).rstrip("/")
            return root.lower(), kind

        roots = list(str(root or "").rstrip("/").lower() for root in portal_roots(self.entry_url))
        ranked = []
        for index, endpoint in enumerate(ordered):
            root, kind = endpoint_shape(endpoint)
            try:
                root_rank = roots.index(root)
            except ValueError:
                root_rank = len(roots)
            ranked.append((kind, root_rank, index, endpoint))
        ranked.sort()
        # Round-robin by endpoint family: loader from each root first, then
        # portal.php, then portal1.php.  This avoids spending the whole fallback
        # budget on several aliases below only one middleware root.
        for kind in range(4):
            for root_rank in range(len(roots) + 1):
                for row_kind, row_root, _index, endpoint in ranked:
                    if row_kind != kind or row_root != root_rank or endpoint in selected:
                        continue
                    selected.append(endpoint)
                    break
                if len(selected) >= limit:
                    return selected
        return selected

    def authorize(self, cancel_event=None):
        # Serialize token/profile mutation.  This prevents an artwork/metadata
        # worker from clearing/replacing the shared auth state while Play is
        # resolving a stream URL.
        with self._auth_lock:
            return self._authorize_impl(cancel_event=cancel_event)

    def _reauthorize(self, seen_token=None, cancel_event=None):
        """Refresh a rejected token once for every concurrent worker.

        ``seen_token`` is the token the failing request was sent with. If another
        worker already replaced it while this one waited for the lock, that new
        token is reused instead of running yet another full handshake (several
        category/artwork/EPG workers hitting an expired token used to queue one
        handshake each and kept clearing each other's fresh token).
        """
        with self._auth_lock:
            current = self.token
            if seen_token and current and current != seen_token:
                return current
            return self._authorize_impl(cancel_event=cancel_event)

    def _authorize_impl(self, cancel_event=None):
        self._reset_auth()
        variants = [
            {"type": "stb", "action": "handshake", "token": "", "JsHttpRequest": "1-xml"},
            {"type": "stb", "action": "handshake", "token": "", "mac": self.mac, "JsHttpRequest": "1-xml"},
        ]
        last_error = None
        js = None
        for params in variants:
            try:
                js = self._unwrap(self._get(params, retry_auth=False, cancel_event=cancel_event))
                if isinstance(js, dict) and js.get("token"):
                    break
                msg = str(js.get("msg") or "") if isinstance(js, dict) else ""
                if "missing" in msg.lower():
                    fake_token = "".join(random.choice(string.ascii_uppercase + string.digits) for _ in range(32))
                    prehash = hashlib.sha1(fake_token.encode("utf-8")).hexdigest()
                    fake_headers = {"Authorization": "Bearer " + fake_token}
                    js = self._unwrap(self._get({
                        "type": "stb", "action": "handshake", "JsHttpRequest": "1-xml",
                        "mac": self.mac, "prehash": prehash,
                    }, retry_auth=False, extra_headers=fake_headers, cancel_event=cancel_event))
                    if isinstance(js, dict) and js.get("token"):
                        break
            except PortalCancelledError:
                raise
            except PortalError as exc:
                last_error = exc

        token = js.get("token") if isinstance(js, dict) else None
        if not token:
            LOG.info("Primary handshake failed; checking bounded portal bootstrap discovery")
            try:
                discovered = self._discover_portal_endpoints(cancel_event=cancel_event)
            except PortalCancelledError:
                raise
            except Exception as exc:
                LOG.debug("Portal bootstrap discovery failed safely: %s", exc)
                discovered = []
            for endpoint in discovered:
                if token:
                    break
                LOG.info("Trying discovered portal endpoint: %s", endpoint_log_label(endpoint))
                for params in variants:
                    try:
                        js = self._unwrap(self._request_endpoint(
                            endpoint, params, cancel_event=cancel_event, max_attempts=1
                        ))
                        token = js.get("token") if isinstance(js, dict) else None
                        if token:
                            break
                        msg = str(js.get("msg") or "") if isinstance(js, dict) else ""
                        if "missing" in msg.lower():
                            fake_token = "".join(random.choice(string.ascii_uppercase + string.digits) for _ in range(32))
                            prehash = hashlib.sha1(fake_token.encode("utf-8")).hexdigest()
                            fake_headers = {"Authorization": "Bearer " + fake_token}
                            js = self._unwrap(self._request_endpoint(
                                endpoint,
                                {"type": "stb", "action": "handshake", "JsHttpRequest": "1-xml", "mac": self.mac, "prehash": prehash},
                                extra_headers=fake_headers, cancel_event=cancel_event, max_attempts=1,
                            ))
                            token = js.get("token") if isinstance(js, dict) else None
                            if token:
                                break
                    except PortalCancelledError:
                        raise
                    except PortalError as exc:
                        last_error = exc
                if token:
                    self.endpoint = endpoint
                    self.portal = endpoint
                    method = self._compat_endpoint_methods.get(endpoint) or "GET"
                    self._persist_compat_state(endpoint=endpoint, method=method)
                    self._persist_transport_state()
                    LOG.info("Discovered portal endpoint validated: %s", endpoint_log_label(endpoint))
                    break
        if not token:
            LOG.info("Trying emulator-style User-Agent fallback for handshake")
            ua_headers = {
                "User-Agent": EMULATOR_USER_AGENT,
                "X-User-Agent": "Model: MAG250; Link: WiFi",
            }
            ua_candidates = self._compat_handshake_candidates(limit=6)
            for endpoint in ua_candidates:
                if token:
                    break
                for params in variants:
                    try:
                        js = self._unwrap(self._request_endpoint(
                            endpoint, params, extra_headers=ua_headers,
                            cancel_event=cancel_event, max_attempts=1,
                        ))
                        token = js.get("token") if isinstance(js, dict) else None
                        if token:
                            self.endpoint = endpoint
                            self.portal = endpoint
                            self._compat_use_emulator_ua = True
                            method = self._compat_endpoint_methods.get(endpoint) or "GET"
                            self._persist_compat_state(endpoint=endpoint, method=method, ua_variant="emulator")
                            self._persist_transport_state()
                            break
                    except PortalCancelledError:
                        raise
                    except PortalError as exc:
                        last_error = exc

        if not token:
            raise last_error or PortalError("Handshake did not return a token")
        # A handshake token is the authority for calling an API endpoint
        # working.  Remember that endpoint by portal root (not MAC) so another
        # profile on the same middleware can skip redundant endpoint probing.
        working_endpoint = str(self.endpoint or "").strip().rstrip("/")
        if working_endpoint:
            try:
                if same_origin(working_endpoint, self.entry_url) and urllib.parse.urlsplit(working_endpoint).path.lower().endswith(".php"):
                    method = self._compat_endpoint_methods.get(working_endpoint) or "GET"
                    self._persist_compat_state(endpoint=working_endpoint, method=method)
            except Exception:
                pass
        self.token = str(token)
        self.token_random = str(js.get("random") or "")
        self._initialize_profile(cancel_event=cancel_event)
        self._validate_account(cancel_event=cancel_event)
        return self.token

    def _profile_identity(self):
        mac = self.mac
        sn = hashlib.md5(mac.encode("utf-8")).hexdigest().upper()[:13]
        device_id = hashlib.sha256(mac.encode("utf-8")).hexdigest().upper()
        device_id2 = hashlib.sha256(device_id.encode("utf-8")).hexdigest().upper()
        hw_version_2 = hashlib.sha1(mac.encode("utf-8")).hexdigest()
        prehash = hashlib.sha1((sn + mac).encode("utf-8")).hexdigest()
        signature = hashlib.sha256((device_id + device_id).encode("utf-8")).hexdigest().upper()
        return sn, device_id, device_id2, hw_version_2, prehash, signature

    def _full_profile_params(self, profile_name=None):
        sn, device_id, device_id2, hw_version_2, prehash, signature = self._profile_identity()
        spec = self._profile_spec(profile_name)
        model = spec["model"]
        in_stalker_path = bool(self.endpoint and "/stalker_portal/" in self.endpoint)
        metrics_data = {
            "type": "stb" if in_stalker_path else "STB",
            "model": model,
            "mac": self.mac,
            "sn": sn,
            "uid": device_id2 if in_stalker_path else "",
            "random": self.token_random if in_stalker_path else "",
        }
        metrics = json.dumps(metrics_data, separators=(",", ":"))
        return OrderedDict([
            ("type", "stb"), ("action", "get_profile"), ("JsHttpRequest", "1-xml"),
            ("hd", "1"), ("ver", spec["ver"]),
            ("num_banks", "2"), ("sn", sn), ("stb_type", model),
            ("client_type", "STB"), ("image_version", spec["image_version"]), ("video_out", "hdmi"),
            ("device_id", device_id), ("device_id2", device_id2), ("signature", signature),
            ("auth_second_step", "1"), ("hw_version", spec["hw_version"]),
            ("not_valid_token", "0"), ("metrics", metrics), ("hw_version_2", hw_version_2),
            ("timestamp", str(int(time.time()))), ("api_signature", spec["api_signature"]), ("prehash", prehash),
        ])

    def _basic_profile_params(self):
        sn, _device_id, _device_id2, _hw, _prehash, _sig = self._profile_identity()
        return OrderedDict([
            ("type", "stb"), ("action", "get_profile"), ("JsHttpRequest", "1-xml"),
            ("sn", sn), ("device_id", ""), ("timestamp", str(int(time.time()))),
        ])

    @staticmethod
    def _profile_problem_text(js):
        try:
            return json.dumps(js, ensure_ascii=False, sort_keys=True).lower()
        except Exception:
            return str(js or "").lower()

    def _compat_profile_params(self, mac_value):
        """Dedicated random-aware MAG250 fallback, isolated from normal Ultra profiles.

        This branch is intentionally minimal and is reached only after the
        current Ultra identities fail.  Keep its middleware identity stable:
        changing DEVICE_PROFILES must not silently mutate this compatibility
        request.
        """
        mac_value = str(mac_value or self.mac)
        identity = compatible_identity(mac_value, self.token_random)
        sn = identity["sn"]
        device_id = identity["device_id"]
        device_id2 = identity["device_id2"]
        signature = identity["signature"]
        metrics = json.dumps({
            "mac": mac_value,
            "sn": sn,
            "type": "STB",
            "model": "MAG250",
            "random": str(self.token_random or ""),
        }, separators=(",", ":"))
        compat_ver = (
            "ImageDescription: 0.2.18-r23-250; PORTAL version: 5.3.0; "
            "API Version: JS API version: 343; STB API version: 146; "
            "Player Engine version: 0x58c"
        )
        return OrderedDict([
            ("type", "stb"), ("action", "get_profile"), ("JsHttpRequest", "1-xml"),
            ("ver", compat_ver),
            ("sn", sn), ("stb_type", "MAG250"), ("client_type", "STB"),
            ("device_id", device_id), ("device_id2", device_id2), ("signature", signature),
            ("auth_second_step", "1"),
            ("hw_version", "2.17-IB-00"), ("hw_version_2", "62"),
            ("metrics", metrics),
        ])

    def _compat_profile_headers(self, mac_value, emulator=False):
        base = self._headers()
        parts = []
        replaced = False
        encoded_mac = urllib.parse.quote(str(mac_value or self.mac), safe="")
        for part in str(base.get("Cookie") or "").split(";"):
            piece = part.strip()
            if piece.lower().startswith("mac="):
                parts.append("mac=" + encoded_mac); replaced = True
            elif piece:
                parts.append(piece)
        if not replaced:
            parts.insert(0, "mac=" + encoded_mac)
        headers = {"Cookie": "; ".join(parts)}
        if emulator:
            headers["User-Agent"] = EMULATOR_USER_AGENT
            headers["X-User-Agent"] = "Model: MAG250; Link: WiFi"
        return headers

    def _try_compat_profile(self, cancel_event=None):
        cached = str(self._compat_cached_profile_variant or "")
        variants = []
        if cached:
            variants.append(cached)
        for name in ("random_upper", "random_lower", "random_upper_emulator", "random_lower_emulator"):
            if name not in variants:
                variants.append(name)
        last_error = None
        for variant in variants:
            lower = "_lower" in variant
            emulator = variant.endswith("_emulator")
            mac_value = self.mac.lower() if lower else self.mac.upper()
            LOG.info("Trying random-aware MAG profile%s%s",
                     " with MAC-case fallback" if lower else "",
                     " and emulator UA" if emulator else "")
            try:
                js = self._unwrap(self._get(
                    self._compat_profile_params(mac_value), retry_auth=False,
                    extra_headers=self._compat_profile_headers(mac_value, emulator=emulator),
                    cancel_event=cancel_event,
                ))
                if not isinstance(js, dict):
                    continue
                self._remember_live_link_policy(js)
                text = self._profile_problem_text(js)
                if any(marker in text for marker in ("device_id mismatch", "old firmware", "not valid token", "authorization failed")):
                    continue
                msg = str(js.get("msg") or "").lower()
                if msg and "error" in msg and not js.get("play_token"):
                    continue
                self.play_token = str(js.get("play_token") or "")
                self.profile_initialized = True
                self.resolved_device_profile = "mag250"
                self._compat_mac_override = mac_value if lower else ""
                self._compat_use_emulator_ua = bool(self._compat_use_emulator_ua or emulator)
                self._persist_compat_state(
                    profile_variant=variant,
                    ua_variant="emulator" if self._compat_use_emulator_ua else "",
                )
                self._persist_transport_state()
                return True
            except PortalCancelledError:
                raise
            except PortalError as exc:
                last_error = exc
        if last_error:
            LOG.debug("Compatibility MAG profile fallback exhausted: %s", last_error)
        return False

    def _initialize_profile(self, cancel_event=None):
        if self.profile_initialized or not self.token:
            return
        last_error = None
        identity_problem = False
        if self.device_profile == "auto":
            preferred = "mag254" if (self.path_prefix == "/stalker_portal/c/" or (self.endpoint and "/stalker_portal/" in self.endpoint)) else "mag250"
            profile_names = [preferred] + [x for x in ("mag250", "mag254", "mag256") if x != preferred]
        else:
            profile_names = [self.device_profile]
        attempts = list((name, self._full_profile_params(name)) for name in profile_names)
        attempts.append((None, self._basic_profile_params()))
        for name, params in attempts:
            try:
                self.resolved_device_profile = name or self.resolved_device_profile
                js = self._unwrap(self._get(params, retry_auth=False, cancel_event=cancel_event))
                if isinstance(js, dict):
                    self._remember_live_link_policy(js)
                    text = self._profile_problem_text(js)
                    if any(marker in text for marker in ("device_id mismatch", "old firmware")):
                        identity_problem = True
                        continue
                    msg = str(js.get("msg") or "")
                    self.play_token = str(js.get("play_token") or "")
                    if msg and not self.play_token and "error" in msg.lower():
                        continue
                    self.profile_initialized = True
                    self._persist_transport_state()
                    return
            except PortalCancelledError:
                raise
            except PortalError as exc:
                last_error = exc

        # Primary Ultra identities stay first. Only a portal that rejected all
        # of them reaches this bounded compatibility branch.
        if self.token_random or identity_problem or last_error is not None:
            if self._try_compat_profile(cancel_event=cancel_event):
                return

        # Some older portals are token-only. Keep compatibility but record it.
        self.profile_initialized = True
        if last_error:
            LOG.warning("MAG profile fallback exhausted: %s", last_error)

    def _validate_account(self, cancel_event=None):
        try:
            js = self._unwrap(self._get({
                "type": "account_info", "action": "get_main_info", "JsHttpRequest": "1-xml"
            }, retry_auth=False, cancel_event=cancel_event))
            self.account_valid = isinstance(js, dict)
            if not self.account_valid:
                # Match mature clients: retry the lighter profile when account info
                # was not accepted after the full profile.
                self._get(self._basic_profile_params(), retry_auth=False, cancel_event=cancel_event)
        except PortalError:
            self.account_valid = False

    # ------------------------------------------------------------------
    # Portal data
    # ------------------------------------------------------------------
    def account_info(self, cancel_event=None, fresh=False):
        if not self.token:
            self.authorize(cancel_event=cancel_event)
        js = self._unwrap(self._get({
            "type": "account_info", "action": "get_main_info", "JsHttpRequest": "1-xml"
        }, use_cache=not bool(fresh), cancel_event=cancel_event))
        return js if isinstance(js, dict) else {"raw": js}
