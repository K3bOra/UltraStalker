# -*- coding: utf-8 -*-
"""M3U compatibility adapter for Ultra Stalker.

The rest of Ultra Stalker sees the same client contract it expects from a
Stalker portal. This module is intentionally isolated: UI/player/cache code does
not need to know where the catalogue came from.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str, int, max, min, OSError, FileNotFoundError, us_casefold, us_func
concurrent = _us_env.concurrent
base64 = _us_env.base64
OrderedDict = _us_env.collections.OrderedDict
hashlib = _us_env.hashlib
json = _us_env.json
os = _us_env.os
import pickle
re = _us_env.re
socket = _us_env.socket
import stat
threading = _us_env.threading
time = _us_env.time
urllib = _us_env.urllib
urllib = _us_env.urllib
urllib = _us_env.urllib
import zlib

from .persistent_cache import ROOT as _PERSISTENT_ROOT, hdd_ready, ensure_persistent_dirs
from .securefs import secure_private_dir
from .netsec import provider_urlopen
from .log import diagnostic_failure, get_logger
from .localization import localized_strftime as _lstrf

try:
    from .title_clean import clean_title as _portal_clean_title
except Exception:
    def _portal_clean_title(value):
        return str(value or "").strip()

LOG = get_logger()


def _us_abort_response(response):
    """Break a blocking read from another thread.

    On Python 2, urllib responses closed from a second thread keep waiting in
    recv() until the socket timeout; shutting the socket down wakes the reader.
    """
    seen = set()
    stack = [(response, 0)]
    while stack:
        obj, depth = stack.pop()
        if obj is None or id(obj) in seen or depth > 6:
            continue
        seen.add(id(obj))
        if hasattr(obj, "shutdown") and hasattr(obj, "fileno"):
            try:
                obj.shutdown(socket.SHUT_RDWR)
            except Exception:
                pass
            continue
        for name in ("fp", "raw", "_sock", "sock", "_fp"):
            try:
                child = getattr(obj, name, None)
            except Exception:
                child = None
            if child is not None:
                stack.append((child, depth + 1))


class M3UCancelledError(RuntimeError):
    """Internal control-flow signal for user cancellation.

    Keep cancellation distinct from provider/network failure so a BACK/EXIT
    action never triggers a second compatibility fallback or noisy error log.
    """
    pass

_CACHE_ROOT=os.path.join(_PERSISTENT_ROOT,"m3u")
# R5.64: tiny in-RAM LRU of parsed Xtream category caches (last 3 categories) so
# page flips do not unpickle up to 25k rows each time.  Entries are validated
# against the cache file signature and dropped whenever the cache is rewritten.
_CAT_LRU=OrderedDict()
_CAT_LRU_LOCK=threading.Lock()
_CAT_LRU_MAX=3

def _cat_lru_get(path,sig):
    with _CAT_LRU_LOCK:
        ent=_CAT_LRU.get(path)
        if ent is None:return None
        if ent[0]!=sig:
            _CAT_LRU.pop(path,None)
            return None
        _CAT_LRU.move_to_end(path)
        return ent[1],ent[2]

def _cat_lru_put(path,sig,saved,rows):
    with _CAT_LRU_LOCK:
        _CAT_LRU[path]=(sig,saved,rows)
        _CAT_LRU.move_to_end(path)
        while len(_CAT_LRU)>_CAT_LRU_MAX:_CAT_LRU.popitem(last=False)

def _cat_lru_drop(path):
    with _CAT_LRU_LOCK:
        _CAT_LRU.pop(path,None)

_MEM_LOCK=threading.RLock()
_SERIES_PERSIST_EXECUTOR=concurrent.futures.ThreadPoolExecutor(max_workers=1)

def _ensure_cache_root():
    """Return True only when the canonical persistent HDD cache is safe to write."""
    try:
        if not hdd_ready() or not ensure_persistent_dirs(_CACHE_ROOT):
            return False
        secure_private_dir(_CACHE_ROOT,0o700)
        return True
    except (OSError,ValueError) as exc:
        LOG.warning("M3U cache root unavailable: %s",exc)
        return False

def _unique_tmp(path):
    return "%s.tmp.%d.%d"%(path,os.getpid(),threading.get_ident())

def _private_replace(tmp,path):
    os.chmod(tmp,0o600)
    os.replace(tmp,path)
    os.chmod(path,0o600)

def _prepare_private_read(path):
    """Harden legacy cache permissions and refuse symlink/non-regular cache files."""
    try:
        if not os.path.isdir(_CACHE_ROOT):
            return False
        secure_private_dir(_CACHE_ROOT,0o700)
        st=os.lstat(path)
        if stat.S_ISLNK(st.st_mode) or not stat.S_ISREG(st.st_mode):
            LOG.warning("Refusing unsafe M3U cache file: %s",os.path.basename(path))
            return False
        os.chmod(path,0o600)
        return True
    except OSError as exc:
        if not isinstance(exc, FileNotFoundError): raise
        return False
    except OSError as exc:
        LOG.warning("M3U cache permission hardening failed for %s: %s",os.path.basename(path),exc)
        return False

_MODE_HINTS_MAX=128
_MODE_HINTS=OrderedDict()
_PICKLE_PY2_BUILTINS = {("__builtin__", "set"): set, ("__builtin__", "frozenset"): frozenset}


def _mode_hint_get(key,default=None):
    with _MEM_LOCK:
        value=_MODE_HINTS.get(key,default)
        if key in _MODE_HINTS:
            try:_MODE_HINTS.move_to_end(key)
            except Exception:pass
        return value


def _mode_hint_set(key,value):
    if not key:
        return
    with _MEM_LOCK:
        try:_MODE_HINTS.pop(key,None)
        except Exception:pass
        _MODE_HINTS[key]=value
        while len(_MODE_HINTS)>_MODE_HINTS_MAX:
            try:_MODE_HINTS.popitem(last=False)
            except Exception:break


def shutdown_m3u_workers(wait=False):
    try:_SERIES_PERSIST_EXECUTOR.shutdown(wait=bool(wait),cancel_futures=True)
    except TypeError:
        try:_SERIES_PERSIST_EXECUTOR.shutdown(wait=bool(wait))
        except Exception as exc:LOG.warning("M3U persist executor shutdown fallback failed: %s",exc)
    except Exception as exc:LOG.warning("M3U persist executor shutdown failed: %s",exc)

class _SafeCacheUnpickler(pickle.Unpickler):
    """Unpickle only plain built-in container/scalar data from plugin-owned caches."""
    def find_class(self, module, name):
        # Python 2 pickles sets through a global reference (protocol 2).
        found = _PICKLE_PY2_BUILTINS.get((module, name)) if _us_env.PY2 else None
        if found is not None:
            return found
        raise pickle.UnpicklingError("global objects are not allowed in UltraStalker cache files")

def _safe_pickle_load(file_obj):
    return _SafeCacheUnpickler(file_obj).load()

_SERIES_GROUP_WORDS=("series","tv series","shows","show","مسلسل","مسلسلات","دراما")
_MOVIE_GROUP_WORDS=("movie","movies","vod","film","films","cinema","افلام","أفلام","فيلم")
_LIVE_GROUP_WORDS=("live","channel","channels","قنوات","قناة","sports","news","bein","osn")

_EP_PATTERNS=(
    re.compile(r"(?i)\bS(\d{1,2})\s*E(\d{1,3})\b"),
    re.compile(r"(?i)\b(\d{1,2})x(\d{1,3})\b"),
    re.compile(r"(?i)\bseason[\s._-]*(\d{1,2}).{0,12}episode[\s._-]*(\d{1,3})\b"),
)
_CLEAN_EP_PATTERNS=(
    re.compile(r"(?i)[\s._-]*\bS\d{1,2}\s*E\d{1,3}\b.*$"),
    re.compile(r"(?i)[\s._-]*\b\d{1,2}x\d{1,3}\b.*$"),
    re.compile(r"(?i)[\s._-]*\bseason[\s._-]*\d{1,2}.{0,12}episode[\s._-]*\d{1,3}\b.*$"),
)

def _safe_int(value,default=0):
    """int() for provider data: tolerates "7.0", " 3 ", None and junk."""
    try:return int(value)
    except (TypeError,ValueError):pass
    try:return int(float(str(value).strip()))
    except (TypeError,ValueError,OverflowError):return default

class _BoundedInfoCache(OrderedDict):
    """Per-session Xtream info/series cache with a hard entry limit.

    Series info replies carry every episode of every season; an unbounded dict
    keeps growing for as long as the session browses, which a low-RAM receiver
    cannot afford. Eviction only costs one re-request."""
    MAX_ENTRIES=160
    def __setitem__(self,key,value):
        if key in self:self.move_to_end(key)
        us_func(OrderedDict.__setitem__)(self,key,value)
        while len(self)>self.MAX_ENTRIES:self.popitem(last=False)
    def get(self,key,default=None):
        if key in self:self.move_to_end(key)
        return us_func(OrderedDict.get)(self,key,default)

def looks_like_m3u_url(value):
    s=str(value or "").strip()
    if not s:return False
    low=s.lower()
    parsed=urllib.parse.urlsplit(s)
    path=(parsed.path or "").lower()
    query=(parsed.query or "").lower()
    if path.endswith((".m3u",".m3u8")):return True
    if "type=m3u" in query or "output=m3u" in query:return True
    if "get.php" in path and ("username=" in query or "password=" in query):return True
    if low.startswith(("m3u://","m3u8://")):return True
    return False

def _slug_id(*parts):
    raw="|".join(str(x or "") for x in parts)
    return hashlib.sha1(raw.encode("utf-8","ignore")).hexdigest()[:20]

def _attr_map(info):
    attrs={}
    text=str(info or "")
    for key,val1,val2 in re.findall(r'([\w-]+)=(?:"([^"]*)"|\'([^\']*)\')',text):
        attrs[key.lower()]=val1 if val1!="" else val2
    for key,val in re.findall(r'([\w-]+)=([^"\'\s,]+)',text):
        k=key.lower()
        if k not in attrs:attrs[k]=val
    return attrs

# "24x7" / "24x365" describe an always-on live channel, not season 24 episode 7.
_ALWAYS_ON_RE=re.compile(r"(?i)(?<![\w])24\s*[x/]\s*(?:7|365)(?![\d])")

def _episode_numbers(name):
    text=_ALWAYS_ON_RE.sub(" ",str(name or ""))
    for rx in _EP_PATTERNS:
        m=rx.search(text)
        if m:
            try:return int(m.group(1)),int(m.group(2))
            except Exception:return None
    return None

def _series_base(name):
    text=str(name or "").strip()
    for rx in _CLEAN_EP_PATTERNS:
        cleaned=rx.sub("",text).strip(" ._-|")
        if cleaned and cleaned!=text:return cleaned
    return text

def _group_matcher(words):
    """Latin words must stand alone (so "Vodafone", "FilmBox" or "Showtime"
    do not hit "vod", "film" or "show"); non-Latin words keep substring
    matching because Arabic carries prefixes such as ال."""
    latin=list(re.escape(us_casefold(w)) for w in words if all(ord(ch) < 128 for ch in w))
    other=tuple(us_casefold(w) for w in words if not all(ord(ch) < 128 for ch in w))
    rx=re.compile(r"(?<![^\W\d_])(?:%s)(?![^\W\d_])"%"|".join(latin)) if latin else None
    def match(group):
        if rx is not None and rx.search(group):return True
        return any(w in group for w in other)
    return match

_series_group=_group_matcher(_SERIES_GROUP_WORDS)
_movie_group=_group_matcher(_MOVIE_GROUP_WORDS)
_live_group=_group_matcher(_LIVE_GROUP_WORDS)

def _kind(group,name,url):
    g=us_casefold(str(group or ""))
    if _episode_numbers(name):return "series"
    if _series_group(g):return "series"
    if _movie_group(g):return "vod"
    if _live_group(g):return "itv"
    path=urllib.parse.urlsplit(str(url or "")).path.lower()
    if path.endswith((".mp4",".mkv",".avi",".mov",".wmv",".m4v")):return "vod"
    return "itv"

# Split: related method groups live in m3u_mixin_*.py modules. They are imported here, after every module-level helper above exists,
# and listed BEFORE the other bases so they override them exactly like the methods that used to sit in this class body.
from .m3u_mixin_cache import M3UCacheMixin
from .m3u_mixin_xtream import M3UXtreamMixin
from .m3u_mixin_menu import M3UMenuMixin
from .m3u_mixin_fetch import M3UFetchMixin
from .m3u_mixin_browse import M3UBrowseMixin
from .m3u_mixin_series import M3USeriesMixin
from .m3u_mixin_search import M3USearchMixin
from .m3u_mixin_epg import M3UEpgMixin


class M3UClient(
    M3UCacheMixin,
    M3UXtreamMixin,
    M3UMenuMixin,
    M3UFetchMixin,
    M3UBrowseMixin,
    M3USeriesMixin,
    M3USearchMixin,
    M3UEpgMixin,
):
    PAGE_SIZE=50

    def __init__(self,url,mac="",timeout=10,**kwargs):
        self.url=str(url or "").strip()
        self.mac=str(mac or "M3U")
        # Stalker APIs are small JSON calls; M3U playlists can be tens of MB.
        # Keep the caller's timeout as a floor but give playlist transfers a
        # realistic read window so large providers are not falsely marked offline.
        self.timeout=max(15,int(timeout or 10))
        self.full_timeout=max(45,self.timeout)
        self.probe_timeout=max(12,min(self.full_timeout,20))
        self.token="m3u"
        self.endpoint=self.url
        self.security_warning=""
        self._loaded=False
        self._loaded_at=0.0
        self._lock=threading.RLock()
        self._items={"itv":[],"vod":[],"series":[]}
        self._genres={"itv":[],"vod":[],"series":[]}
        self._series_index={}
        self._live_epg_map={}
        self._live_native_refs={}
        self._xmltv_urls=[]
        self._xmltv_header_pending=False
        self._last_error=""
        self._last_success=0.0
        with _MEM_LOCK:
            self._mode=str(_mode_hint_get(hashlib.sha1(self.url.encode("utf-8","ignore")).hexdigest()) or "m3u")
        self._xtream=self._parse_xtream_credentials()
        if self._mode=="m3u":
            persisted=self._read_mode_hint()
            if persisted:
                self._mode=persisted
                _mode_hint_set(self._cache_key(),persisted)
        self._xtream_account={}
        self._xtream_categories={"itv":{},"vod":{},"series":{}}
        self._xtream_category_ids={"itv":{},"vod":{},"series":{}}
        self._xtream_loaded_categories={"itv":set(),"vod":set(),"series":set()}
        # Per-session rich info cache. Xtream list endpoints often omit cover/backdrop
        # while get_series_info/get_vod_info carries the authoritative provider art.
        self._xtream_info_cache=_BoundedInfoCache()
        self._xtream_live_art_index=None
        self._live_art_prepare_lock=threading.RLock()
        self._live_art_index_lock=threading.RLock()
        self._live_art_waiters=[]
        self._live_art_future=None
        self._xtream_series_name_index=None
        # one full catalogue write can be several MB. Focus-prefetch used
        # to enqueue one complete JSON+pickle write per series, saturating the HDD
        # long after the user left M3U. Coalesce bursts into at most one follow-up.
        self._series_persist_lock=threading.RLock()
        self._series_persist_dirty=False
        self._series_persist_running=False
        # urlopen() reads can otherwise sit inside a socket timeout after the
        # screen has already closed. Track current responses so close() can
        # actively break those reads instead of leaving orphan workers behind.
        self._io_lock=threading.RLock()
        self._active_responses=set()
        self._epg_closed=False
        self._epg_stop=threading.Event()
        self._epg_prepare_lock=threading.Lock()
        self._xmltv_header_lock=threading.Lock()
        self._epg_prepare_thread=None
        self._epg_prepare_at=0.0


