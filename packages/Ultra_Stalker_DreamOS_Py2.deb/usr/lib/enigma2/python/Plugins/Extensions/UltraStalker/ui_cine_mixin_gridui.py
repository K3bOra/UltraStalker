# -*- coding: utf-8 -*-
"""Grid rendering, selection, opening and debounced focus.

Methods moved verbatim out of ``PremiumGlobalCinematicScreen`` (ui_cinematic_global.py); behaviour is unchanged.
This module is imported by ui_cinematic_global.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, zip, max, min, us_clear, us_func
from .ui_cinematic_global import (
    PremiumGridBase,
    _,
    logging,
    optional_failure,
    os,
    threading,
    time,
)


class CineGridUiMixin(object):
    """Grid rendering, selection, opening and debounced focus."""

    def _render_grid(self):
        self._cin_hot_row_cache={}
        # keep the same Settings/Episodes row grammar in a compact 73px
        # slot and show 12 rows, starting directly beneath the Ultra Stalker header.
        # release additionally indexes the tiny canonical package JSON for every
        # visible row here.  Arrow navigation therefore does zero HDD lookup and
        # can bind the already-cached decoder-ready backdrop immediately.
        us_clear(self._cin_row_complete);self._cin_page_records={};self._cin_page_packages={};self._cin_page_backdrops={}
        rows=[]
        for pos in range(min(self.page_size,len(self.grid_items))):
            _item=self.grid_items[pos]
            # R99 maintenance: the normal path is RAM-only.  All tiny JSON and
            # canonical snapshot reads were already completed by the async page
            # worker in _prepare_grid_page.
            _prepared=(getattr(self,"_prepared_art_for_render",[]) or [])
            _ram_art=_prepared[pos] if pos < len(_prepared) and isinstance(_prepared[pos],dict) else {}
            if _ram_art.get("_cin_index_ready"):
                _record=_ram_art.get("cin_record") if isinstance(_ram_art.get("cin_record"),dict) else {}
                _pkg=_ram_art.get("cin_package") if isinstance(_ram_art.get("cin_package"),dict) else {}
                self._cin_page_records[pos]=_record
                if _pkg:self._cin_page_packages[pos]=_pkg
                _bd=str(_ram_art.get("cin_backdrop") or _ram_art.get("backdrop") or "")
                if _bd:self._cin_page_backdrops[pos]=_bd
            else:
                # Compatibility fallback only; current page preparation always
                # emits the marker above.
                try:
                    _ram_bd=str(_ram_art.get("backdrop") or "")
                    if _ram_bd:self._cin_page_backdrops[pos]=_ram_bd
                except Exception:pass
                try:
                    _alias={} if pos in self._cin_page_backdrops else (self._cin_load_nav_alias(_item) or {});_abd=str(_alias.get("backdrop") or "")
                    if _abd and os.path.isfile(_abd):self._cin_page_backdrops[pos]=_abd
                    elif pos not in self._cin_page_backdrops:
                        _blue=self._cin_read_blue_lock(_item) or {};_blue_bd=str(_blue.get("backdrop_fast") or "")
                        if _blue_bd and os.path.isfile(_blue_bd) and os.path.getsize(_blue_bd)>4096:self._cin_page_backdrops[pos]=_blue_bd
                except Exception as exc:optional_failure("cinematic.page_nav_alias_fallback",exc)
                try:self._cin_page_records[pos]=self._record(_item) or {}
                except Exception:self._cin_page_records[pos]={}
                try:
                    _pkg=self._cin_load_canonical_package_fast(_item,self._cin_page_records.get(pos,{}) or {}) or {}
                    if _pkg:
                        self._cin_page_packages[pos]=_pkg
                        _bd=str(_pkg.get("backdrop_fast") or _pkg.get("backdrop") or "")
                        if _bd and os.path.isfile(_bd):self._cin_page_backdrops[pos]=_bd
                except Exception as exc:optional_failure("cinematic.page_backdrop_index_fallback",exc)
            rows.append(self._cin_list_row(pos,selected=(pos==self.index),record=self._cin_page_records.get(pos)))
        try:
            self["cin_list"].set_icon_rows(rows)
            if rows:self["cin_list"].moveToIndex(max(0,min(self.index,len(rows)-1)))
        except Exception as exc:optional_failure("cinematic.settings_list_render",exc)
        try:
            _jpg=sum(1 for _p in self._cin_page_backdrops.values() if str(_p or "").lower().endswith((".jpg",".jpeg")))
            logging.getLogger("UltraStalker").info("PERF54 cinematic_backdrop_index page=%s rows=%d ready=%d jpeg=%d",int(getattr(self,"page",1) or 1),len(rows),len(self._cin_page_backdrops),_jpg)
        except Exception:pass
        self._update_selection()

    def _cin_after_navigation(self,item):
        """The single selected-title navigation gate used by Cinematic/BG1/BG2."""
        self._cin_last_nav_at=time.monotonic()
        self._cin_cancel_fast_info();self._cin_cancel_focus(enqueue=False);self._cin_cancel_background();self._cin_last_focus_item=dict(item)
        # R111: cancel any previous title-logo/backdrop request immediately, but
        # keep the last-good pixels on screen.  New visual work is armed only
        # after the navigation quiet window.
        try:
            _logo_cancel=getattr(self,"_cin_logo_cancel",None)
            if _logo_cancel is not None:_logo_cancel.set()
            _logo_sig=str(getattr(self,"_cin_logo_active_sig","") or "")
            if _logo_sig:self._cin_logo_pending.discard(_logo_sig)
            self._cin_logo_cancel=None;self._cin_logo_active_sig=""
        except Exception as exc:optional_failure("cinematic.nav_logo_cancel",exc)
        try:self._fast_bd_cancel(clear_file=False)
        except Exception as exc:optional_failure("cinematic.nav_fast_backdrop_cancel",exc)
        # R5.234: title-logo gets the same quick independent settle lane on the
        # initial/default selection as it does after arrow navigation.
        self._cin_arm_fast_logo()
        self._cin_arm_fast_info()
        if not getattr(self,"_cin_cache_exclusive",False):
            try:
                self._cin_nav_backdrop_timer.stop();self._cin_nav_backdrop_timer.start(self._cin_cached_backdrop_delay_ms(),True)
            except Exception as exc:optional_failure("cinematic.nav_backdrop_schedule",exc)
        if not getattr(self,"_cin_cache_exclusive",False):
            try:
                self._nav_burst_until=time.monotonic()+0.54;self._grid_focus_timer.stop();self._grid_focus_timer.start(550,True)
                self._cin_nav_adaptive_timer.stop();self._cin_nav_adaptive_timer.start(450,True)
                if self.media_type=="series":self._series_prefetch_timer.stop();self._series_prefetch_timer.start(900,True)
            except Exception:self._apply_debounced_grid_focus()
        self._update_page_counter()

    def _cin_set_adaptive_target(self,item):
        """Make the current selection the sole owner of future adaptive work.

        A running Pillow job cannot be force-killed safely on Enigma2, so the
        generation/event pair makes it cooperative: queued work is cancelled, a
        running stale job is prevented from starting its next expensive phase,
        and any result that still arrives is rejected before GUI commit.  The
        last committed adaptive is deliberately NOT cleared here.
        """
        try:sig=str(self._page_visual_key(item) or "")
        except Exception:sig=""
        if sig==str(getattr(self,"_cin_adaptive_target_sig","") or ""):
            return int(getattr(self,"_cin_adaptive_generation",0) or 0)
        self._cin_adaptive_generation=int(getattr(self,"_cin_adaptive_generation",0) or 0)+1
        self._cin_adaptive_target_sig=sig
        old_event=getattr(self,"_cin_adaptive_cancel",None)
        if old_event is not None:
            try:old_event.set()
            except Exception:pass
        old_future=getattr(self,"_cin_visual_future",None)
        if old_future is not None and not old_future.done():
            try:old_future.cancel()
            except Exception:pass
        self._cin_adaptive_cancel=threading.Event()
        self._cin_visual_future=None
        # Pending keys belong to obsolete generations.  Clearing them lets a
        # repeated/colliding provider key for the new selection schedule at once.
        try:us_clear(self._cin_pending)
        except Exception:pass
        return int(self._cin_adaptive_generation)

    def _update_selection(self):
        if not self.grid_items:return
        self.index=max(0,min(self.index,len(self.grid_items)-1));item=self.grid_items[self.index]
        self._cin_set_adaptive_target(item)
        self._cin_last_nav_at=time.monotonic()
        # First touch only the two rail rows involved in this key event. Their
        # tuples are RAM-cached by _cin_list_row, so the remote path performs no
        # metadata/HDD/Pillow work before moveToIndex().
        try:
            previous=getattr(self,"_cin_last_list_index",-1)
            previous=int(previous if previous is not None else -1)
            if 0<=previous<len(self.grid_items) and previous!=self.index:
                self["cin_list"].update_icon_row(previous,self._cin_list_row(previous,selected=False,record=self._cin_page_records.get(previous,{}),allow_progress_build=False))
            self["cin_list"].update_icon_row(self.index,self._cin_list_row(self.index,selected=True,record=self._cin_page_records.get(self.index,{}),allow_progress_build=False))
            self["cin_list"].moveToIndex(self.index)
            self._cin_last_list_index=int(self.index)
        except Exception as exc:optional_failure("cinematic.settings_list_selection",exc)
        self._remember_grid_state()
        # R225 Stage 3 correction: HOLD LAST GOOD adaptive during navigation.
        # The fixed-green master is cold-start/failure fallback only, never an
        # obligatory bridge between title A and title B.  Stable focus later
        # atomically swaps directly from A's complete adaptive to B's complete
        # adaptive; skipped titles perform zero adaptive repaint/build work.
        try:
            self._cin_nav_adaptive_pending_sig=str(self._page_visual_key(item) or "")
            self._cin_nav_adaptive_timer.stop()
        except Exception as exc:optional_failure("cinematic.nav_adaptive_hold",exc)
        # Navigation path is deliberately UI-only. Never enqueue skipped titles,
        # reprioritize artwork workers, scan HDD manifests or start network work.
        self._cin_cancel_focus(enqueue=False);self._cin_cancel_background();self._cin_last_focus_item=dict(item)
        # R111: kill work owned by the title we just left.  Do not blank any
        # already-painted visual; hold-last-good remains the presentation rule.
        try:
            _logo_cancel=getattr(self,"_cin_logo_cancel",None)
            if _logo_cancel is not None:_logo_cancel.set()
            _logo_sig=str(getattr(self,"_cin_logo_active_sig","") or "")
            if _logo_sig:self._cin_logo_pending.discard(_logo_sig)
            self._cin_logo_cancel=None;self._cin_logo_active_sig=""
        except Exception as exc:optional_failure("cinematic.nav_logo_cancel",exc)
        try:self._fast_bd_cancel(clear_file=False)
        except Exception as exc:optional_failure("cinematic.nav_fast_backdrop_cancel",exc)
        # R5.234: title-logo is presentation artwork, not Details metadata. Match
        # Poster Grid 3's quick settle cadence instead of waiting for the slower
        # metadata/focus lanes.
        self._cin_arm_fast_logo()
        # Arrow/key-repeat path must stay UI-only. Keep the previously committed
        # information visible and let the 160 ms fast-info timer paint the new
        # cached record after the key burst settles. _cin_arm_fast_info() owns the
        # one required fast-info cancellation; avoid cancelling the same future twice.
        self._cin_arm_fast_info()
        # Warm-cache safety: never decode a full-HD backdrop on every remote
        # repeat event. Restart one short one-shot timer instead; the highlight
        # and list movement stay immediate while the final cached backdrop binds
        # after the user releases the arrow key.
        if not getattr(self,"_cin_cache_exclusive",False):
            try:
                # R111: one fixed quiet window for every title.  Do not even
                # probe cached artwork on the arrow path; that work begins only
                # after the user has stopped moving.
                self._cin_nav_backdrop_timer.stop();self._cin_nav_backdrop_timer.start(self._cin_cached_backdrop_delay_ms(),True)
            except Exception as exc:optional_failure("cinematic.nav_backdrop_schedule",exc)
        if not getattr(self,"_cin_cache_exclusive",False):
            try:
                self._nav_burst_until=time.monotonic()+0.54;self._grid_focus_timer.stop();self._grid_focus_timer.start(550,True)
                self._cin_nav_adaptive_timer.stop();self._cin_nav_adaptive_timer.start(450,True)
                if self.media_type=="series":self._series_prefetch_timer.stop();self._series_prefetch_timer.start(900,True)
            except Exception:self._apply_debounced_grid_focus()
        self._update_page_counter()

    def open_selected(self):
        """Movies play directly; Series keep the existing Details/Episodes route."""
        if self._busy or not self.grid_items:return
        if self.media_type!="vod":
            return us_func(PremiumGridBase.open_selected)(self)
        item=self.grid_items[self.index]
        command=item.get("cmd") or item.get("command") or item.get("url")
        if not command:
            try:self["status"].setText(_("No stream command"))
            except Exception:pass
            return
        try:self["status"].setText(_("Creating stream link..."))
        except Exception:pass
        selected_page=int(self.page or 1);selected_index=int(self.index or 0)
        def ok(url):
            url=url if isinstance(url,str) else ""
            if not url.strip():
                from .ui_helpers import report_stream_link_failure
                report_stream_link_failure(self);return
            name=str(item.get("name") or item.get("title") or "Ultra Stalker stream")
            try:
                engine=_configured_playback_engine()
                play_item=dict(item) if isinstance(item,dict) else item
                if isinstance(play_item,dict):
                    try:
                        # R111 speed: page records were already loaded while painting the
                        # rail. Avoid rescanning manifest/detail JSON on every PLAY press.
                        row=(getattr(self,"_cin_page_records",{}) or {}).get(int(self.index),{}) or {}
                        row_verified=(row.get("tmdb_id") if isinstance(row,dict) and (row.get("identity_verified") or row.get("identity_pointer_verified")) else None)
                        locked=(row.get("_locked_tmdb_id") or row.get("_ultra_search_verified_tmdb_id") or row_verified or play_item.get("_locked_tmdb_id") or play_item.get("_ultra_search_verified_tmdb_id")) if isinstance(row,dict) else (play_item.get("_locked_tmdb_id") or play_item.get("_ultra_search_verified_tmdb_id"))
                        if locked in (None,""):
                            fallback=self._record(item) or {}
                            fallback_verified=(fallback.get("tmdb_id") if isinstance(fallback,dict) and (fallback.get("identity_verified") or fallback.get("identity_pointer_verified")) else None)
                            locked=(fallback.get("_locked_tmdb_id") or fallback.get("_ultra_search_verified_tmdb_id") or fallback_verified) if isinstance(fallback,dict) else None
                        if locked not in (None,""):
                            play_item["_locked_tmdb_id"]=locked;play_item["tmdb_id"]=locked
                        authority=str(getattr(self,"_cin_logo_path","") or "")
                        if authority and os.path.isfile(authority) and os.path.getsize(authority)>256:
                            play_item["_player_title_logo_cinematic_source"]=authority
                    except Exception as exc:optional_failure("cinematic.direct_player_logo_handoff",exc)
                    try:
                        visible_poster=self._visible_player_poster_path(item,self.index)
                        if visible_poster:
                            play_item["_player_poster"]=visible_poster
                            play_item["_ultra_poster_source"]=visible_poster
                            play_item["_adaptive_source_local"]=visible_poster
                            play_item["_ultra_visible_poster_locked"]=True
                            _poster_key=self._page_visual_key(item) if isinstance(item,dict) else ""
                            if _poster_key:play_item["_player_poster_identity"]=_poster_key
                    except Exception as exc:optional_failure("cinematic.direct_player_poster_handoff",exc)
                payload=_player_payload(play_item,self.profile,media_type="vod")
                payload["_player_client_ref"]=self.client
                def closed(result=None):
                    try:self["status"].setText("")
                    except Exception:pass
                    # Player persists resume position. Reload only lightweight content state
                    # and repaint the same rail; no Details screen/artwork cycle is involved.
                    try:
                        states=load_content_states(self.profile,self.media_type,self.grid_items) if self.grid_items else []
                        qualities=load_content_qualities(self.profile,self.media_type,self.grid_items) if self.grid_items else []
                        self._grid_item_state={}
                        for it,st,q in zip(self.grid_items,states,qualities):
                            rr=dict(st or {});rr["quality"]=q or "";self._grid_item_state[id(it)]=rr
                    except Exception as exc:optional_failure("cinematic.direct_play_state_reload",exc)
                    if self.page!=selected_page or not self.grid_items:
                        self.load_page(selected_page,selected_index);return
                    self.index=max(0,min(selected_index,len(self.grid_items)-1))
                    try:self["status"].setText("")
                    except Exception:pass
                    try:self._render_grid()
                    except Exception as exc:optional_failure("cinematic.direct_play_repaint",exc)
                    try:self._update_selection()
                    except Exception:pass
                    # Player can invalidate native adaptive/backdrop surfaces while
                    # our cached path markers remain unchanged. Rebind the exact
                    # same cached files once; no image work or network refresh.
                    try:self._cin_force_cached_visual_rebind()
                    except Exception as exc:optional_failure("cinematic.direct_play_cached_rebind",exc)
                try:self["status"].setText("")
                except Exception:pass
                self.session.openWithCallback(closed,UltraStalkerPlayer,str(url).strip(),name,"vod",engine,payload)
            except Exception as exc:
                try:self["status"].setText(_("Player failed: %s")%exc)
                except Exception:pass
        def link_failed(error):
            from .ui_helpers import report_stream_link_failure
            report_stream_link_failure(self,error)
        self._run_async(lambda handle:self.client.create_link(item,"vod",cancel_event=handle.cancel_event),ok,link_failed)

    def _apply_debounced_grid_focus(self):
        if self._screen_closed or not self.grid_items:return
        # R5.47 stable-focus law: skipped titles do zero work. Cached adaptive
        # gets its own 450 ms read-only lane; cold adaptive starts here at 550 ms.
        try:
            quiet=max(0.0,time.monotonic()-float(getattr(self,"_cin_last_nav_at",0.0) or 0.0))
            if quiet < 0.55:
                self._grid_focus_timer.stop();self._grid_focus_timer.start(max(60,int((0.55-quiet)*1000)),True)
                return
        except Exception:
            return
        item=self.grid_items[self.index]
        # R112: this timer is a GUI callback. Consume only the RAM index prepared
        # by the page worker; missing authority is resolved by background lanes.
        row=self._cin_page_records.get(self.index,{}) or {}
        self._cin_page_records[self.index]=row

        # --- R81 LEFT RAIL AUTHORITY ---
        # Apply the canonical R81 package rows immediately after stable focus,
        # regardless of whether Details metadata has resolved yet.  This restores
        # the exact R81 row/adaptive cadence: neutral/previous material while
        # moving, then the focused title's real poster-derived rows after pause.
        package=(getattr(self,"_cin_page_packages",{}) or {}).get(int(self.index)) or {}
        adaptive_committed=False
        if package:
            try:self._cin_page_packages[int(self.index)]=dict(package)
            except Exception:pass
            adaptive_committed=bool(self._cin_apply_package(item,row,package))
        if not adaptive_committed:
            # Missing either half of the title presentation means HOLD the last
            # committed state and prepare BOTH halves off-thread.  Never let the
            # description chrome and rail colours arrive as two visible phases.
            try:self._cin_schedule_visuals(item,row)
            except Exception as exc:optional_failure("cinematic.r200_atomic_visual_schedule",exc)

        # Backdrop is an independent modern lane.  Calling it here is harmless
        # for an already-painted/cache hit and is the cold-title fallback after
        # the same R81 stable-focus window.
        if getattr(self,"_fast_bd_enabled",False):
            try:self._fast_bd_schedule(item,row)
            except Exception as exc:optional_failure("cinematic.r200_backdrop_focus",exc)

        # --- DETAILS INFORMATION AUTHORITY ---
        # The information box never gates the R81 rows.  It paints only the same
        # canonical Details record used by the real Details screen.
        try:
            from .details_authority import metadata_language_ready
            details_ready=bool(row.get("_details_authority_ready") and metadata_language_ready(row,(self._grid_settings or {})))
        except Exception:
            details_ready=bool(row.get("_details_authority_ready"))

        # Paint the information cluster immediately from the already-indexed HDD
        # record.  This is presentation-only and does not mark the record ready.
        # The authoritative focus resolve below will repaint the same widgets when
        # richer/correct-language Details metadata becomes available.
        self._cin_apply_record(item,row,allow_build=False,hold_missing=not details_ready)
        if details_ready:
            # Details chrome is loaded from the title's persisted visual bundle;
            # _cin_apply_package above already prefers that exact bundle and does
            # not manufacture a second information-box authority.
            return

        # Cold/incomplete title: resolve the same Details Authority once.
        self._cin_schedule_focus(item)
