"""Account-scoped provider scheduling across shared and isolated source clients."""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str, int, max, min, OSError, InterruptedError
__metaclass__ = type  # new-style classes on Python 2
OrderedDict = _us_env.collections.OrderedDict
from email.utils import parsedate_tz as _parsedate_tz, mktime_tz as _mktime_tz
hashlib = _us_env.hashlib
json = _us_env.json
socket = _us_env.socket
threading = _us_env.threading
time = _us_env.time
urllib = _us_env.urllib
import weakref

class ProviderCancelled(InterruptedError):pass

class ProviderBusyError(RuntimeError):
    def __init__(self,code=429,retry_after=2.0):
        self.code=int(code);self.retry_after=max(.25,min(120.,float(retry_after)))
        super(ProviderBusyError, self).__init__('Provider busy (HTTP %d). Please wait and retry.'%self.code)

def retry_delay(headers,default=2.):
    value=(headers or {}).get('Retry-After','')
    try:return max(.25,min(120.,float(value)))
    except (ValueError,TypeError):pass
    try:return max(.25,min(120.,_mktime_tz(_parsedate_tz(value))-time.time()))
    except (ValueError,TypeError,OverflowError):return default

class Events:
    def __init__(self,*events):self.events=tuple(e for e in events if e is not None)
    def is_set(self):return any(e.is_set() for e in self.events)

def _interrupt(response):
    # shutdown releases a blocked read without closing another request's socket.
    try:
        raw=getattr(getattr(response,'fp',None),'raw',None)
        sock=getattr(raw,'_sock',None)
        if sock is not None:sock.shutdown(socket.SHUT_RDWR)
    except (OSError,ValueError):pass

class Lease:
    def __init__(self,gate,priority,event,preemptible):
        self.gate=gate;self.priority=priority;self.preempt=threading.Event()
        self.event=Events(event,self.preempt);self.preemptible=preemptible;self.response=None
    def bind(self,response):
        with self.gate.condition:
            self.response=response
            if self.preempt.is_set():_interrupt(response)
    def release(self):
        with self.gate.condition:
            if self.gate.active is self:
                self.gate.active=None;self.gate.next_at=max(self.gate.next_at,time.monotonic()+.15)
                self.gate.condition.notify_all()

class Gate:
    def __init__(self):
        self.condition=threading.Condition();self.active=None;self.waiters=[];self.sequence=0;self.next_at=0.;self.limited_until=0.;self.limited_code=429
    def defer(self,seconds,code=429):
        with self.condition:
            until=time.monotonic()+max(.25,min(120.,seconds))
            self.next_at=max(self.next_at,until)
            self.limited_until=max(self.limited_until,until);self.limited_code=int(code)
            self.condition.notify_all()
    def raise_if_deferred(self):
        # RAM-only probe for background EPG: do not occupy a worker waiting
        # through a known Retry-After window or invent an empty guide result.
        with self.condition:
            remaining=self.limited_until-time.monotonic()
            if remaining>0:raise ProviderBusyError(self.limited_code,remaining)
    def acquire(self,event=None,priority=0,preemptible=False,timeout=25):
        end=time.monotonic()+max(.1,float(timeout))
        with self.condition:
            self.sequence+=1;ticket=(priority,self.sequence);self.waiters.append(ticket)
            try:
                while True:
                    if event is not None and event.is_set():raise ProviderCancelled('Provider request cancelled')
                    now=time.monotonic()
                    if self.active is None and ticket==min(self.waiters) and now>=self.next_at:
                        lease=Lease(self,priority,event,preemptible);self.active=lease;return lease
                    if now>=end:raise ProviderBusyError(429,max(.25,self.next_at-now))
                    active=self.active
                    if active is not None and priority<active.priority and active.preemptible:
                        active.preempt.set();_interrupt(active.response)
                    self.condition.wait(min(.05,end-now))
            finally:
                self.waiters.remove(ticket);self.condition.notify_all()

_LOCK=threading.Lock()
_GATES=weakref.WeakValueDictionary()
_RECENT=OrderedDict()

def _origin(url):
    p=urllib.parse.urlsplit(url)
    return (p.scheme.lower(),(p.hostname or '').lower(),p.port or (443 if p.scheme.lower()=='https' else 80))

def account_gate(client):
    cfg=getattr(client,'_xtream',None) or {}
    if cfg:
        identity=(_origin(cfg.get('base','')),urllib.parse.urlsplit(cfg.get('base','')).path.rstrip('/'),cfg.get('username',''),cfg.get('password',''))
    else:identity=(str(getattr(client,'url','')),)
    key=hashlib.sha256(json.dumps(identity,ensure_ascii=False).encode("utf-8")).hexdigest()
    with _LOCK:
        gate=_GATES.get(key)
        if gate is None:gate=Gate();_GATES[key]=gate
        _RECENT[key]=gate;_RECENT.move_to_end(key)
        while len(_RECENT)>128:_RECENT.popitem(last=False)
    return gate

def same_provider(client,url):
    cfg=getattr(client,'_xtream',None) or {}
    return _origin(url)==_origin(cfg.get('base') or str(getattr(client,'url','')))

class LeasedResponse:
    """Keep a playlist's account slot until its response has actually closed."""
    def __init__(self,response,lease):self.response=response;self.lease=lease
    def __getattr__(self,name):return getattr(self.response,name)
    def read(self,*args):
        if self.lease.event.is_set():raise ProviderCancelled('Provider read cancelled')
        result=self.response.read(*args)
        if self.lease.event.is_set():raise ProviderCancelled('Provider read cancelled')
        return result
    def read1(self,*args):
        if self.lease.event.is_set():raise ProviderCancelled('Provider read cancelled')
        result=getattr(self.response,'read1',self.response.read)(*args)
        if self.lease.event.is_set():raise ProviderCancelled('Provider read cancelled')
        return result
    def close(self):
        try:self.response.close()
        finally:self.lease.release()
    def __enter__(self):return self
    def __exit__(self,*args):self.close()
