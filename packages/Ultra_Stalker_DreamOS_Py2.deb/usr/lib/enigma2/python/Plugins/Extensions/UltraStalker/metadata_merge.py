"""Keep complete same-ID fields when a later copy supplies sparse metadata."""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str

INVARIANT_FIELDS = frozenset(('runtime', 'duration', 'time', 'length', 'year', 'release_year',
    'release_date', 'first_air_date', 'releaseDate', 'countries', 'country', 'country_code',
    'production_country', 'production_countries', 'origin_country', 'original_language',
    'number_of_seasons', 'seasons_count', 'season_count', 'number_of_episodes', 'episodes_count',
    'episode_count', 'rating', 'vote_count'))


def same_locale(old, new):
    normalize = lambda row: str(row.get('_details_metadata_language') or '').lower().replace('_', '-')
    return bool(normalize(old) and normalize(old) == normalize(new))


def richer_same_locale(old, new, key, value):
    if not same_locale(old, new):
        return value
    if key in ('overview_language', '_details_metadata_fallback_fields'):
        chosen = richer_same_locale(old, new, 'overview', new.get('overview'))
        if chosen and chosen == old.get('overview') and chosen != new.get('overview'):
            if key == 'overview_language':
                return old.get('overview_language') or old.get('_details_metadata_language')
            before = str(old.get('overview_language') or old.get('_details_metadata_language') or '').split('-')[0].lower()
            wanted = str(new.get('_details_metadata_language') or '').split('-')[0].lower()
            if before == wanted:
                return [field for field in value or [] if field != 'overview']
    current = old.get(key)
    if key in ('genres', 'cast', 'crew', 'directors', 'writers', 'countries'):
        if isinstance(current, list) and isinstance(value, list):
            return current + [part for part in value if part not in current]
    if key == 'overview' and current and value:
        before = str(old.get('overview_language') or old.get('_details_metadata_language') or '').lower()
        after = str(new.get('overview_language') or new.get('_details_metadata_language') or '').lower()
        wanted = str(new.get('_details_metadata_language') or '').lower().split('-')[0]
        # A real selected-language translation always replaces an English
        # fallback, regardless of length; an English fallback cannot erase it.
        if before.split('-')[0] == wanted and after.split('-')[0] != wanted:
            return current
        if before == after and len(str(current)) > len(str(value)):
            return current
    return value


def clear_localized_fields(merged, old, new, fields):
    if same_locale(old, new):
        # Ephemeral provider fallbacks never become canonical by accident.
        for key in old.get('_details_provider_fields') or ():
            merged.pop(key, None)
        return
    for key in fields:
        if key not in INVARIANT_FIELDS:
            merged.pop(key, None)
