# -*- coding: utf-8 -*-
"""Close handling, context overlay and choice/notice dialogs.

Methods moved verbatim out of ``NovaSettingsScreen`` (ui_screens_settings.py); behaviour is unchanged.
This module is imported by ui_screens_settings.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str, int, round, max, min
threading = _us_env.threading
from .ui_screens_settings import (
    _SETTINGS_NOTICE_FONT,
    _SETTINGS_NOTICE_INNER_W,
    _SETTINGS_NOTICE_MASTER_H,
    _SETTINGS_NOTICE_MASTER_W,
    _SETTINGS_NOTICE_MAX_LINES,
    _mem34,
    _settings_notice_pages,
    _settings_notice_title,
    fixed_settings_chrome,
    fixed_settings_rows,
    gFont,
    show_notice,
)


class SettingsContextMixin(object):
    """Close handling, context overlay and choice/notice dialogs."""

    def _mem34_settings_close(self):
        _mem34("settings_close", section=str(getattr(self,"_settings_section","") or "root"))

    def _context_geom(self,name,x,y,w,h):
        try:
            desktop=getDesktop(0).size();sx=float(desktop.width())/1920.0;sy=float(desktop.height())/1080.0
            inst=self[name].instance
            if inst is not None:
                inst.move(ePoint(int(round(x*sx)),int(round(y*sy))))
                inst.resize(eSize(max(1,int(round(w*sx))),max(1,int(round(h*sy)))))
        except Exception as exc:optional_failure("ui.settings_inline_context_geom",exc)

    def _context_hide_widgets(self):
        for name in ("context_panel","context_title","context_subtitle","context_message","context_list","context_hint"):
            try:self[name].hide()
            except Exception as exc:optional_failure("ui.settings_inline_context_hide",exc)

    def _settings_cancel(self):
        if getattr(self,"_context_active",False):
            self._context_close(None, cancelled=True)
            return
        if getattr(self,"_pane","groups")=="options":
            self._set_pane("groups")
            return
        self.close()

    def _settings_ok(self):
        if getattr(self,"_context_active",False):
            if self._context_mode=="choice":self._context_accept()
            else:self._context_close(None, cancelled=False)
        else:
            self.select()

    def _settings_diagnostics(self):
        if getattr(self,"_context_active",False):return
        self.open_diagnostics()

    def _settings_move(self,direction):
        if getattr(self,"_context_active",False) and self._context_mode=="notice":
            if direction in ("up","left"):self._context_notice_page(-1)
            elif direction in ("down","right"):self._context_notice_page(1)
            return
        if not getattr(self,"_context_active",False):
            # R5.167: RIGHT/LEFT page the category rail (same page_shift as every other
            # list); the options panel is entered with OK only.
            if self._pane=="options" and direction=="left":
                self._set_pane("groups");return
            if self._pane=="options" and direction=="right":return
        if getattr(self,"_context_active",False) and self._context_mode=="choice":target=self["context_list"]
        elif self._pane=="options":
            if direction in ("up","down"):self._opt_step(-1 if direction=="up" else 1)
            return
        else:target=self["list"]
        try:
            if direction=="up":target.wrap_up()
            elif direction=="down":target.wrap_down()
            elif direction=="left":target.page_left()
            elif direction=="right":target.page_right()
        except Exception as exc:optional_failure("ui.settings_inline_context_move",exc)

    def _context_compact_episode_assets(self,card_w):
        """Resize the approved Settings episode-row glass horizontally only.

        The left Settings rail remains the visual source of truth.  Context
        choices reuse those exact normal/selected assets, with a 9-slice style
        horizontal resize so the rounded ends and adaptive glow keep their shape.
        """
        card_w=max(300,min(560,int(card_w or 426)))
        normal=str(getattr(self,"_settings_row_asset","") or "")
        selected=str(getattr(self,"_settings_row_selected_asset","") or "")
        if not (normal and selected and os.path.isfile(normal) and os.path.isfile(selected)):
            chrome=fixed_settings_rows() or {}
            normal=str(chrome.get("normal") or normal);selected=str(chrome.get("selected") or selected)
        if card_w==426:
            return normal,selected
        out=[]
        for src,kind in ((normal,"normal"),(selected,"selected")):
            if not (src and os.path.isfile(src)):
                out.append(src);continue
            try:
                stamp=int(os.path.getmtime(src))
                sig=hashlib.sha1((src+"|"+str(stamp)+"|"+str(card_w)+"|floating-choice-v1").encode("utf-8","ignore")).hexdigest()[:16]
                cache_dir=os.path.dirname(src)
                if cache_dir.startswith("/usr/"):
                    try:
                        from .persistent_cache import GENERATED as _GENERATED
                        cache_dir=os.path.join(_GENERATED,"inline_context_glass")
                        if not os.path.isdir(cache_dir):
                            os.makedirs(cache_dir,0o700)
                    except Exception:
                        cache_dir="/tmp"
                dst=os.path.join(cache_dir,"dyn_settings_context_%s_%s_%d.png"%(sig,kind,card_w))
                if not (os.path.isfile(dst) and os.path.getsize(dst)>64):
                    from PIL import Image as _SettingsImage
                    im=_SettingsImage.open(src).convert("RGBA")
                    sw,sh=im.size
                    target_h=72
                    if sh!=target_h:
                        resample=getattr(getattr(_SettingsImage,"Resampling",_SettingsImage),"LANCZOS",getattr(_SettingsImage,"LANCZOS",1))
                        im=im.resize((sw,target_h),resample);sw,sh=im.size
                    cap=max(36,min(72,sw//4,(card_w-16)//2))
                    resample=getattr(getattr(_SettingsImage,"Resampling",_SettingsImage),"LANCZOS",getattr(_SettingsImage,"LANCZOS",1))
                    if card_w>cap*2+8 and sw>cap*2+8:
                        canvas=_SettingsImage.new("RGBA",(card_w,target_h),(0,0,0,0))
                        left=im.crop((0,0,cap,target_h));right=im.crop((sw-cap,0,sw,target_h))
                        center=im.crop((cap,0,sw-cap,target_h)).resize((card_w-cap*2,target_h),resample)
                        canvas.paste(left,(0,0));canvas.paste(center,(cap,0));canvas.paste(right,(card_w-cap,0))
                    else:
                        canvas=im.resize((card_w,target_h),resample)
                    tmp=dst+".tmp.%d.%d" % (os.getpid(), threading.get_ident());canvas.save(tmp,"PNG");os.replace(tmp,dst)
                out.append(dst)
            except Exception as exc:
                optional_failure("ui.settings_context_episode_resize",exc);out.append(src)
        return (out+[None,None])[:2]

    def _context_prepare_floating_choices(self,title,subtitle,labels,count,show_text=False):
        # Choices live INSIDE the right card, in the same slot as the option rows.
        row_h=66;list_w=500
        visible=max(1,min(6,int(count or 1)))
        list_x=1370;list_y=570
        if show_text:
            self._context_geom("context_subtitle",list_x,list_y,list_w,70)
            list_y=list_y+78;visible=max(1,min(visible,4))
        else:
            self._context_geom("context_subtitle",0,0,1,1)
        list_h=visible*row_h
        self._context_geom("context_list",list_x,list_y,list_w,list_h)
        self._context_geom("context_title",0,0,1,1)
        self._context_geom("context_panel",0,0,1,1)
        self._context_geom("context_message",0,0,1,1)
        self._context_geom("context_hint",0,0,1,1)
        self._context_row_asset=asset("settings_d_r5392/row_492x58.png");self._context_selected_asset=asset("settings_d_r5392/row_492x58_selected.png")
        try:
            if self["context_list"].instance is not None:
                self["context_list"].instance.setSelectionEnable(0)
                self["context_list"].instance.setTransparent(1)
                try:self["context_list"].instance.setScrollbarMode(2)
                except Exception:pass
            self["context_list"].row_width=list_w
            self["context_list"].set_layout(row_h,0,22,16,row_style="settings_dialog")
        except Exception as exc:optional_failure("ui.settings_floating_context_list_layout",exc)
        return list_w,row_h

    def _card_context_enter(self,title,subtitle=""):
        for n in ("opt_list","description","pv_hair_bottom"):
            try:self[n].hide()
            except Exception:pass
        try:
            self["pv_title"].setText(str(title or "")[:40]);self["pv_desc"].setText(str(subtitle or ""))
        except Exception:pass

    def _card_context_leave(self):
        for n in ("opt_list","pv_hair_bottom"):
            try:self[n].show()
            except Exception:pass
        self._pv_shown=None
        try:self._update_preview(int(self["list"].getSelectedIndex() or 0))
        except Exception:pass

    def _context_open_choice(self,callback,title,choices,selection=0,subtitle="Choose an option",show_text=False):
        self._context_hide_widgets()
        self._context_active=True;self._context_mode="choice"
        self._context_callback=callback;self._context_choices=list(choices or [])
        labels=list(_(str(c[0])) if isinstance(c,(tuple,list)) and c else _(str(c)) for c in self._context_choices)
        title_text=_(str(title or "Settings")); subtitle_text=_(str(subtitle or ""))
        self._card_context_enter(title_text,"" if show_text else subtitle_text)
        self._context_prepare_floating_choices(title_text,subtitle_text,labels,len(labels),show_text=show_text)
        self["context_title"].setText("");self["context_subtitle"].setText(subtitle_text)
        self["context_hint"].setText("")
        selection=max(0,min(int(selection or 0),len(self._context_choices)-1)) if self._context_choices else 0
        rows=[]
        for i,c in enumerate(self._context_choices):
            details={"selected":i==selection,"row_asset":self._context_row_asset,"row_selected_asset":self._context_selected_asset,"meta":"","wrap_title":True}
            rows.append((labels[i],None,c,details))
        self["context_list"].set_icon_rows(rows)
        try:self["context_list"].moveToIndex(selection)
        except Exception as exc:optional_failure("ui.settings_inline_context_index",exc)
        self._context_last_idx=selection
        try:
            if self._context_selection_changed not in self["context_list"].onSelectionChanged:
                self["context_list"].onSelectionChanged.append(self._context_selection_changed)
        except Exception as exc:optional_failure("ui.settings_inline_context_hook",exc)
        try:self["context_list"].show()
        except Exception as exc:optional_failure("ui.settings_inline_context_show",exc)
        if show_text:
            for name in ("context_subtitle",):
                try:self[name].show()
                except Exception as exc:optional_failure("ui.settings_inline_context_text_show",exc)
        try:self["context_panel"].hide();self["context_message"].hide();self["context_hint"].hide()
        except Exception:pass

    def _context_selection_changed(self):
        if not getattr(self,"_context_active",False) or self._context_mode!="choice":return
        try:idx=self["context_list"].getSelectedIndex()
        except Exception:return
        old=getattr(self,"_context_last_idx",idx)
        if idx==old:return
        self._context_last_idx=idx
        for j in set((old,idx)):
            if 0<=j<len(self._context_choices):
                c=self._context_choices[j]
                label=_(str(c[0])) if isinstance(c,(tuple,list)) and c else _(str(c))
                details={"selected":j==idx,"row_asset":self._context_row_asset,"row_selected_asset":self._context_selected_asset,"meta":"","wrap_title":True}
                self["context_list"].update_icon_row(j,(label,None,c,details))
        try:self["context_list"].l.invalidate()
        except Exception as exc:optional_failure("ui.settings_inline_context_refresh",exc)

    def _context_open_notice(self,title,message,callback=None,yesno=False):
        # R5.340: brief passive messages should never open a blocking card.
        # Long reference text, legal information and callback screens remain readable.
        raw_text = str(message or "")
        if (not yesno and callback is None and len(raw_text) <= 165
                and raw_text.count("\n") <= 1):
            show_notice(self.session, raw_text, timeout=4, title=_(str(title or "")), owner=self)
            return
        if yesno:
            # Confirmations keep explicit Yes/No choices; only passive notices
            # become text-only adaptive cards.
            self._context_open_choice(callback,str(title or _("Confirm")),[(_("Yes"),True),(_("No"),False)],0,str(message or ""),show_text=True)
            return
        self._context_hide_widgets()
        self._context_active=True;self._context_mode="notice"
        self._context_callback=callback;self._context_choices=[]
        message=_(str(message or ""))
        title_text=_(str(title or "Information"))

        # Issue 6: the approved About card is the sole passive message master.
        # Refresh/Update/Backup/etc. never grow the panel; long copy is paged
        # inside the same 560x260 glass.
        panel_w=_SETTINGS_NOTICE_MASTER_W
        panel_h=_SETTINGS_NOTICE_MASTER_H
        inner_w=_SETTINGS_NOTICE_INNER_W
        msg_font=_SETTINGS_NOTICE_FONT
        message_h=174
        panel_x=1340+(560-panel_w)//2
        panel_y=380+(680-panel_h)//2
        self._card_context_enter("","")
        self._context_notice_title_base=title_text
        self._context_notice_pages=_settings_notice_pages(message,msg_font,inner_w,_SETTINGS_NOTICE_MAX_LINES)
        self._context_notice_page_idx=0

        self._context_geom("context_panel",panel_x,panel_y,panel_w,panel_h)
        self._context_geom("context_title",panel_x+36,panel_y+16,inner_w,40)
        self._context_geom("context_subtitle",0,0,1,1)
        self._context_geom("context_message",panel_x+36,panel_y+68,inner_w,message_h)
        self._context_geom("context_list",0,0,1,1)
        self._context_geom("context_hint",0,0,1,1)
        chrome=fixed_settings_chrome(panel_w,panel_h,inner_w,48) or {}
        try:
            panel=chrome.get("panel")
            if panel and os.path.isfile(panel):self["context_panel"].instance.setPixmapFromFile(panel)
        except Exception as exc:optional_failure("ui.settings_inline_notice_panel",exc)
        try:
            if self["context_message"].instance is not None:self["context_message"].instance.setFont(_ultra_rfont("Regular",msg_font))
        except Exception as exc:optional_failure("ui.settings_inline_notice_font",exc)

        self["context_title"].setText(_settings_notice_title(title_text,0,len(self._context_notice_pages)));self["context_subtitle"].setText("")
        self["context_message"].setText(self._context_notice_pages[0]);self["context_hint"].setText("")
        for name in ("context_panel","context_title","context_message"):
            try:self[name].show()
            except Exception as exc:optional_failure("ui.settings_inline_notice_show",exc)
        try:self["context_subtitle"].hide();self["context_list"].hide();self["context_hint"].hide()
        except Exception:pass

    def _context_notice_page(self,step):
        if not getattr(self,"_context_active",False) or getattr(self,"_context_mode",None)!="notice":return
        pages=list(getattr(self,"_context_notice_pages",[]) or [])
        if len(pages)<=1:return
        idx=(int(getattr(self,"_context_notice_page_idx",0) or 0)+int(step or 0))%len(pages)
        self._context_notice_page_idx=idx
        title=str(getattr(self,"_context_notice_title_base","") or "Information")
        self["context_title"].setText(_settings_notice_title(title,idx,len(pages)))
        self["context_message"].setText(pages[idx])

    def _context_accept(self):
        try:idx=self["context_list"].getSelectedIndex()
        except Exception:idx=-1
        value=self._context_choices[idx] if 0<=idx<len(self._context_choices) else None
        self._context_close(value,cancelled=False)

    def _context_close(self,value=None,cancelled=False):
        callback=getattr(self,"_context_callback",None)
        mode=getattr(self,"_context_mode",None)
        self._context_active=False;self._context_mode=None;self._context_callback=None;self._context_choices=[]
        self._context_notice_pages=[];self._context_notice_page_idx=0;self._context_notice_title_base=""
        self._context_hide_widgets()
        try:
            self._card_context_leave()
            if getattr(self,"_pane","groups")=="options":self._opt_selection_changed(force=True)
            else:self._selection_changed()
        except Exception:pass
        if callback is not None:
            try:callback(None if cancelled else value)
            except Exception as exc:optional_failure("ui.settings_inline_context_callback",exc)

from .wqhd_layout import responsive_font as _ultra_rfont, factors as _ultra_factors

def _ultra_osd_scale():
    return _ultra_factors()[1]
