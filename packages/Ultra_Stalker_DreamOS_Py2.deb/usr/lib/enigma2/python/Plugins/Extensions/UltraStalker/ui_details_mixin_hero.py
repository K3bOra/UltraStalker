# -*- coding: utf-8 -*-
"""Pinning the current item as the home hero.

Methods moved verbatim out of ``ContentDetailsScreen`` (ui_screens_details.py); behaviour is unchanged.
This module is imported by ui_screens_details.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, open, OSError
from .ui_screens_details import (
    _,
    cleanup_legacy_application_outputs,
    fixed_home_assets,
    hashlib,
    json,
    os,
    reactor,
    tempfile,
    time,
)


class DetailsHeroMixin(object):
    """Pinning the current item as the home hero."""

    def _stop_hero_pin_timer(self):
        try:self._hero_pin_timer.stop()
        except Exception:pass
        try:
            if self._hero_pin_conn is not None:
                self._hero_pin_conn.disconnect()
                self._hero_pin_conn=None
        except Exception:pass
        try:
            if self._pin_current_as_home_hero_retry in self._hero_pin_timer.callback:self._hero_pin_timer.callback.remove(self._pin_current_as_home_hero_retry)
        except Exception:pass

    def _stop_hero_note_timer(self):
        try:self._hero_note_timer.stop()
        except Exception:pass
        try:
            if getattr(self,"_hero_note_conn",None) is not None:
                self._hero_note_conn.disconnect()
                self._hero_note_conn=None
        except Exception:pass
        try:
            if self._hero_note_clear in self._hero_note_timer.callback:self._hero_note_timer.callback.remove(self._hero_note_clear)
        except Exception:pass

    def _pin_current_as_home_hero_retry(self):
        if getattr(self,"_screen_closed",False):return
        self._pin_current_as_home_hero(_retry=True)

    def _hero_note_show(self,text,ms=3500):
        try:
            self["hero_note"].setText(str(text or ""))
            self._hero_note_timer.stop()
            if ms:self._hero_note_timer.start(int(ms),True)
        except Exception as exc:optional_failure("ui.hero_note",exc)

    def _hero_note_clear(self):
        try:self["hero_note"].setText("")
        except Exception:pass

    def _show_hero_pin_toast(self,final=False):
        """No separate screens: a one-line note above the description box (like Cinematic)."""
        try:
            self["hero_note"].setText(_("Hero pinned • active across Ultra Stalker") if final else _("Hero selected • preparing…"))
            self._hero_note_timer.stop();self._hero_note_timer.start(3500 if final else 6000,True)
        except Exception as exc:optional_failure("ui.hero_pin_note",exc)

    @staticmethod
    def _hero_old_generated_paths(hero):
        paths=[]
        if not isinstance(hero,dict):return paths
        for key in ("prepared",):
            value=str(hero.get(key) or "")
            if value:paths.append(value)
        for key in ("home_mood","adaptive_focus"):
            block=hero.get(key) if isinstance(hero.get(key),dict) else {}
            for value in block.values():
                value=str(value or "")
                if value:paths.append(value)
        return paths

    def _pin_current_as_home_hero(self,_retry=False):
        """V7.8-style explicit Hero pin using the already-cached selected backdrop.

        The selected HDD backdrop is the only source.  No TMDb redownload occurs.
        Home's top composite plus the exact adaptive mood/focus files are prepared
        serially in background, then one single persistent Hero state is published.
        """
        if not _retry:
            self._hero_pin_attempts=0
            try:self._hero_pin_timer.stop()
            except Exception:pass
        self._hero_pin_attempts=int(getattr(self,"_hero_pin_attempts",0) or 0)+1

        source=""
        candidates=[]
        tmdb=getattr(self,"_tmdb_data",None)
        if isinstance(tmdb,dict):candidates.extend([tmdb.get("backdrop_local"),tmdb.get("display_backdrop_local")])
        cache=getattr(self,"_local_detail_cache",None)
        if isinstance(cache,dict):candidates.extend([cache.get("backdrop_local"),cache.get("display_backdrop_local")])
        state=getattr(self,"_details_visual_state",None)
        if isinstance(state,dict):candidates.extend([state.get("backdrop"),state.get("backdrop_present")])
        live_item=self.item if isinstance(getattr(self,"item",None),dict) else {}
        portal_item=getattr(self,"_portal_item",None) if isinstance(getattr(self,"_portal_item",None),dict) else {}
        for obj in (live_item,portal_item):
            candidates.extend([obj.get("_backdrop_source_local"),obj.get("_cin_provider_backdrop_local"),obj.get("backdrop_local"),obj.get("display_backdrop_local")])
        candidates.extend([getattr(self,"_portal_backdrop_source_local",""),getattr(self,"_adaptive_source_local",""),getattr(self,"_backdrop_displayed_path","")])
        for candidate in candidates:
            try:
                candidate=str(candidate or "")
                if candidate and os.path.isfile(candidate) and os.path.getsize(candidate)>4096:
                    source=os.path.realpath(candidate);break
            except Exception:pass
        if not source:
            if self._hero_pin_attempts<21 and not getattr(self,"_screen_closed",False):
                try:self._hero_note_show(_("Preparing Hero… waiting for cached backdrop"),2500);self._hero_pin_timer.start(300,True)
                except Exception:pass
                return
            try:self._hero_note_show(_("Hero not set • selected backdrop is not cached on HDD"),4000)
            except Exception:pass
            return
        try:self._hero_pin_timer.stop()
        except Exception:pass

        item_snapshot=dict(live_item);media_type=str(self.media_type or "")
        raw_id=str(item_snapshot.get("tmdb_id") or item_snapshot.get("id") or item_snapshot.get("stream_id") or item_snapshot.get("series_id") or "")
        tmdb_id=(tmdb or {}).get("tmdb_id") if isinstance(tmdb,dict) and tmdb.get("matched") else None
        if not tmdb_id and isinstance(cache,dict) and cache.get("matched"):tmdb_id=cache.get("tmdb_id")
        if not tmdb_id:tmdb_id=item_snapshot.get("_locked_tmdb_id") or item_snapshot.get("_ultra_search_verified_tmdb_id")
        try:overview=self["description"].getText() or ""
        except Exception:overview=""

        request_token=str(int(time.time()*1000000));hero_dir=os.path.dirname(str(HOME_HERO_FILE or ""))
        marker=os.path.join("/tmp","ultrastalker_home_hero_pending")
        try:
            with open(marker,"w",encoding="ascii") as fh:fh.write(request_token)
        except Exception:pass
        self._show_hero_pin_toast(False)
        try:pass
        except Exception:pass

        source=str(source)
        def token_current():
            try:
                with open(marker,"r",encoding="ascii") as fh:return fh.read().strip()==request_token
            except Exception:return False

        def safe_unlink_generated(path,keep=()):
            try:
                path=str(path or "");base=os.path.basename(path)
                if not path or path in keep or not os.path.isfile(path):return
                # Never delete canonical movie/series artwork. Only old Hero files
                # and the release adaptive Home derivatives referenced by hero.json.
                if (os.path.realpath(path).startswith(os.path.realpath(hero_dir)+os.sep) or
                    base.startswith("dyn228home_") or base.startswith("dyn280home_")):
                    os.unlink(path)
            except OSError:pass
            except Exception:pass

        def worker():
            temp_home=""
            created=[]
            try:
                os.makedirs(hero_dir,mode=0o700,exist_ok=True)
                stamp=os.stat(source)
                digest=hashlib.sha1((source+"|%s|%s|manual-hero-v78-contract"%(int(stamp.st_mtime),int(stamp.st_size))).encode("utf-8","ignore")).hexdigest()[:20]
                temp_home=os.path.join(hero_dir,".hero.%s.%s.png"%(os.getpid(),request_token))
                prepared=_prepare_single_home_hero(source,temp_home,(1920,1080))
                if not prepared or not os.path.isfile(prepared) or os.path.getsize(prepared)<=1024:return False
                if not token_current():return False

                # R64: Set Hero changes artwork only.  Application chrome is
                # frozen and no legacy Home adaptive writer may run here.
                try:cleanup_legacy_application_outputs()
                except Exception:pass
                fixed=fixed_home_assets() or {}
                if not fixed:
                    return False
                adaptive_focus=dict(fixed.get("focus") or {})
                home_mood=dict(fixed.get("mood") or {})

                required=[adaptive_focus.get("menu"),adaptive_focus.get("recent"),home_mood.get("ambient"),home_mood.get("menu"),home_mood.get("recent")]
                if not all(p and os.path.isfile(str(p)) and os.path.getsize(str(p))>100 for p in required):return False

                old_hero={}
                try:
                    with open(HOME_HERO_FILE,"r",encoding="utf-8") as fh:
                        old=json.load(fh);old_hero=old.get("hero") if isinstance(old,dict) and isinstance(old.get("hero"),dict) else {}
                except Exception:old_hero={}

                with _HOME_HERO_LOCK:
                    if not token_current():return False
                    final_home=os.path.join(hero_dir,"hero.png")
                    os.replace(temp_home,final_home);temp_home=""
                    hero_title=str(getattr(self,"_server_display_name","") or live_item.get("name") or live_item.get("title") or "")
                    hero={
                        "id":"manual-"+(raw_id or digest),"media_type":media_type,"tmdb_id":tmdb_id,
                        "title":hero_title,"overview":overview,"rating":0,"language":"","collection":"ULTRA STALKER",
                        "prepared":final_home,"backdrop_local":source,"display_backdrop_local":source,
                        "source_backdrop_local":source,"adaptive_focus":adaptive_focus,"home_mood":home_mood,
                        "manual_pin":True,"manual_pin_token":int(request_token),
                    }
                    payload={"schema":HOME_HERO_SCHEMA,"expires":0,"persistent":True,"manual_pin":True,
                             "manual_pin_token":int(request_token),"hero":hero}
                    fd,tmp=tempfile.mkstemp(prefix=".hero-state.",suffix=".tmp",dir=hero_dir)
                    try:
                        with os.fdopen(fd,"w",encoding="utf-8") as fh:
                            json.dump(payload,fh,ensure_ascii=False,separators=(",",":"));fh.flush();os.fsync(fh.fileno())
                        os.chmod(tmp,0o600);os.replace(tmp,HOME_HERO_FILE)
                    finally:
                        if os.path.exists(tmp):
                            try:os.unlink(tmp)
                            except OSError:pass

                keep=set([final_home]+[str(x or "") for x in required])
                for old_path in self._hero_old_generated_paths(old_hero):safe_unlink_generated(old_path,keep)
                try:
                    if token_current():os.unlink(marker)
                except OSError:pass
                return True
            except Exception as exc:
                optional_failure("ui.details_set_home_hero_v78_contract",exc);return False
            finally:
                if temp_home and os.path.exists(temp_home):
                    try:os.unlink(temp_home)
                    except OSError:pass
                if not token_current():
                    for path in created:safe_unlink_generated(path)

        def finished(result):
            if not result:return
            try:pass
            except Exception:pass
            if not getattr(self,"_screen_closed",False):self._show_hero_pin_toast(True)

        try:
            old=getattr(self,"_hero_pin_future",None)
            if old is not None and not old.done():
                try:old.cancel()
                except Exception:pass
            future=_IMAGE_EXECUTOR.submit(worker)
            self._hero_pin_future=future
            def done(_f):
                try:result=bool(_f.result())
                except Exception:result=False
                if result:
                    try:reactor.callFromThread(finished,True)
                    except Exception:pass
            try:future.add_done_callback(done)
            except Exception:pass
        except Exception as exc:
            optional_failure("ui.details_set_home_hero_submit",exc)
            try:self._hero_note_show(_("Hero failed: %s")%str(exc)[:90],4500)
            except Exception:pass
