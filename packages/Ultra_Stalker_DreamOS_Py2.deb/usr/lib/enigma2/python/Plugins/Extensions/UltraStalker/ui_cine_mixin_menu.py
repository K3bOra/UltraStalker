# -*- coding: utf-8 -*-
"""Settings menu scrim, menu selection and sharp details overview.

Methods moved verbatim out of ``PremiumGlobalCinematicScreen`` (ui_cinematic_global.py); behaviour is unchanged.
This module is imported by ui_cinematic_global.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, max, min, us_func
from .ui_cinematic_global import (
    PremiumGridBase,
    _,
    _PILImage,
    durable_view_path,
    hashlib,
    optional_failure,
    os,
    threading,
)


class CineMenuMixin(object):
    """Settings menu scrim, menu selection and sharp details overview."""

    def _settings_menu_scrim_show(self):
        try:
            path=asset("us88_focus_dim_scrim.png")
            if path and os.path.isfile(path) and self["settings_menu_scrim"].instance is not None:
                self["settings_menu_scrim"].instance.setPixmapFromFile(path)
            self["settings_menu_scrim"].show()
        except Exception as exc:optional_failure("cinematic.menu_scrim_show",exc)

    def _settings_menu_scrim_hide(self):
        try:self["settings_menu_scrim"].hide()
        except Exception as exc:optional_failure("cinematic.menu_scrim_hide",exc)

    def _menu_selected_with_scrim(self,choice):
        self._settings_menu_scrim_hide()
        return self._menu_selected(choice)

    def _menu_selected(self,choice):
        if not choice:return
        try:
            if choice[1]=="replace_backdrop_hq":
                self._replace_backdrop_hq();return
        except Exception:pass
        return us_func(PremiumGridBase._menu_selected)(self,choice)

    def open_menu(self):
        choices=[(_("Refresh page"),"refresh"),(_("First page"),"first"),(_("Toggle favorite"),"favorite")]
        if self.media_type=="vod" and self.grid_items:
            choices.insert(0,(_("Download Movie"),"download_movie"))
        if self.media_type in ("vod","series") and self.grid_items:
            choices.insert(1 if self.media_type=="vod" else 0,(_("Downloads Manager"),"downloads_manager"))
            from .ui_manual_match import menu_choices
            choices.extend(menu_choices())
            choices.append((_("Trailer"),"trailer"))
            choices.append((_("Export this to channel list"),"export_one"))
            choices.append((_("Replace Backdrop (HQ)"),"replace_backdrop_hq"))
            choices.append((_("Set as Home Hero"),"set_home_hero"))
        if self.media_type=="vod" and self.grid_items:
            state=self._grid_item_state.get(id(self.grid_items[self.index]),{})
            choices.append((_("Mark unwatched") if state.get("completed") else _("Mark watched"),"unwatch" if state.get("completed") else "watch"))
        # R168 menu-light pass: same actions and anchor, but pure floating text.
        # No glass/adaptive row generation or pixmap bind is allowed on MENU open.
        # Normal rows are bright white; selection is the shared green + larger font.
        self._settings_menu_scrim_show()
        self._settings_inline_menu.show(choices,selection=0,right=1850,region_top=240,region_h=400,
            on_accept=self._menu_selected_with_scrim,on_close=self._settings_menu_scrim_hide,
            min_card_w=260,max_card_w=680,padding=54,anchor_bottom=670,
            visual_style="text_only",row_h=66,max_visible=6,text_font=30)

    def _cin_sharp_details_overview(self, source, target_size=(1318,170), key="overview_detail"):
        """Use the same nine-slice sharpening geometry as Details."""
        try:
            source=str(source or "")
            if not source or not os.path.isfile(source):return ""
            tw,th=int(target_size[0]),int(target_size[1])
            with _PILImage.open(source) as probe:sw,sh=probe.size
            if (sw,sh)==(tw,th):return source
            stamp="%s|%s|%s|%s|%s"%(source,os.path.getmtime(source),key,tw,th)
            out=durable_view_path(hashlib.sha1(stamp.encode("utf-8","ignore")).hexdigest()[:24]+".png","details_sharp_v6514",source=source)
            root=os.path.dirname(out)
            if not os.path.isdir(root):os.makedirs(root,mode=0o700,exist_ok=True)
            if os.path.isfile(out) and os.path.getsize(out)>256:return out
            with _PILImage.open(source) as im:
                im=im.convert("RGBA");sw,sh=im.size
                cx=max(10,min(38,sw//5,tw//5));cy=max(8,min(22,sh//4,th//4))
                left=right=cx;top=bottom=cy
                canvas=_PILImage.new("RGBA",(tw,th),(0,0,0,0))
                sx=(0,left,sw-right,sw);sy=(0,top,sh-bottom,sh)
                dx=(0,left,tw-right,tw);dy=(0,top,th-bottom,th)
                res=getattr(getattr(_PILImage,"Resampling",_PILImage),"LANCZOS",getattr(_PILImage,"LANCZOS",1))
                for yi in range(3):
                    for xi in range(3):
                        tile=im.crop((sx[xi],sy[yi],sx[xi+1],sy[yi+1]))
                        size=(dx[xi+1]-dx[xi],dy[yi+1]-dy[yi])
                        if tile.size!=size:tile=tile.resize(size,res)
                        canvas.paste(tile,(dx[xi],dy[yi]))
                temp=out+".tmp.%s.%s"%(os.getpid(),threading.get_ident())
                try:
                    canvas.save(temp,"PNG",optimize=True);os.replace(temp,out)
                finally:
                    try:
                        if os.path.exists(temp):os.unlink(temp)
                    except Exception:pass
            return out
        except Exception as exc:
            optional_failure("cinematic.details_overview_sharp",exc);return str(source or "")
