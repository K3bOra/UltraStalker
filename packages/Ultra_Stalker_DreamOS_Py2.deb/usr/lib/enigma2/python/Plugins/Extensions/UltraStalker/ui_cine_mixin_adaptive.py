# -*- coding: utf-8 -*-
"""Final/adaptive chrome and rail presentation.

Methods moved verbatim out of ``PremiumGlobalCinematicScreen`` (ui_cinematic_global.py); behaviour is unchanged.
This module is imported by ui_cinematic_global.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, max, min
from .ui_cinematic_global import (
    _build_dynamic_details_chrome,
    _cached_dynamic_details_chrome,
    _cached_dynamic_settings_episode_rows,
    adaptive_enabled,
    canonical_dynamic_details_key,
    canonical_dynamic_rows_key,
    fixed_exact_surface,
    hashlib,
    optional_failure,
    os,
    re,
    time,
)


class CineAdaptiveMixin(object):
    """Final/adaptive chrome and rail presentation."""

    @staticmethod
    def _cin_final_chrome_ready(chrome):
        """True only for one complete Details-family adaptive snapshot.

        Cinematic never swaps a partial title palette.  The previous good adaptive
        remains visible until every surface needed by the right-side information
        cluster is physically present on HDD.
        """
        if not isinstance(chrome,dict):return False
        required=("panel_detail","overview_detail","cast_detail","quality","year","runtime","country","genre_detail")
        for key in required:
            path=str(chrome.get(key) or "")
            try:
                if not path or not os.path.isfile(path) or os.path.getsize(path)<=128:return False
            except Exception:return False
        return True

    def _cin_load_final_adaptive(self,item,row):
        try:
            bundle=_load_visual_bundle(self.profile,self.media_type,item,row) or {}
            chrome=bundle.get("chrome") if isinstance(bundle.get("chrome"),dict) else {}
            return dict(chrome) if self._cin_final_chrome_ready(chrome) else {}
        except Exception as exc:
            optional_failure("cinematic.final_adaptive_load",exc);return {}

    def _cin_ensure_final_adaptive(self,item,row,cancel_event=None,build=False):
        """Load or build the ONE persistent title adaptive bundle.

        This is deliberately independent from the shared full-HD backdrop cache.
        A title visited normally is persisted exactly like a BLUE Cache Artwork
        title; BLUE simply pre-builds the same files for the whole folder.
        """
        ready=self._cin_load_final_adaptive(item,row)
        if ready or not build:return ready
        if cancel_event is not None and cancel_event.is_set():return {}
        row=dict(row or {})
        poster=str(row.get("poster_local") or "")
        if not (poster and os.path.isfile(poster)):return {}
        try:
            key=canonical_dynamic_details_key(poster) or ("r170_final_%s"%hashlib.sha1(poster.encode("utf-8","ignore")).hexdigest()[:20])
            chrome=_build_dynamic_details_chrome(poster,key) or {}
            if cancel_event is not None and cancel_event.is_set():return {}
            if not self._cin_final_chrome_ready(chrome):return {}
            if not _save_visual_bundle(self.profile,self.media_type,item,{"poster":poster,"chrome":chrome},snapshot=row):return {}
            return dict(chrome)
        except Exception as exc:
            optional_failure("cinematic.final_adaptive_build",exc);return {}

    def _cin_fixed_master_chrome(self):
        """Exact bundled fixed-green Cinematic first-paint chrome.

        The files are already shipped at the final widget geometries, so this
        path performs no image generation and never depends on the selected title.
        It is the cold-start baseline only; once a complete title adaptive is
        ready, hold-last-good logic owns all subsequent navigation handoffs.
        """
        specs={
            "panel_detail":(1410,360,"cin_panel_detail"),
            "overview_detail":(1318,170,"cin_overview_detail"),
            "cast_detail":(1318,50,"cin_cast_detail"),
            "quality":(150,50,"cin_quality"),
            "year":(130,50,"cin_year"),
            "runtime":(150,50,"cin_runtime"),
            "country":(160,50,"cin_country"),
            "genre_detail":(680,50,"cin_genre_detail"),
        }
        out={}
        try:
            for key,(w,h,tag) in specs.items():
                path=str(fixed_exact_surface(w,h,False,tag) or "")
                if not (path and os.path.isfile(path) and os.path.getsize(path)>128):
                    return {}
                out[key]=path
        except Exception as exc:
            optional_failure("cinematic.fixed_green_master",exc);return {}
        return out

    def _cin_layout_ready(self):
        try:self["cin_backdrop_stage"].hide()
        except Exception:pass
        try:self["title_logo"].hide()
        except Exception:pass
        try:
            self._set_native_pixmap("artwork_status_bg","us66_neutral_pill_genre.png")
            self["artwork_status_bg"].hide()
        except Exception:pass
        # R214 Stage 1: delete the old neutral first-paint path from Cinematic.
        # The exact bundled fixed-green material is the one immutable cold shell,
        # matching Home/utility chrome.  It stays resident until a COMPLETE title
        # adaptive replaces it; navigation never re-applies a fallback in between.
        _master=self._cin_fixed_master_chrome()
        if _master:
            self._cin_fixed_master_cache=dict(_master)
            self._cin_display_adaptive_owner_sig=""
            self._apply_native_detail_chrome(_master)
        else:
            # Package-corruption safety only. Normal shipped builds always have
            # the complete fixed master, so this bridge is not part of first paint.
            self._apply_native_detail_chrome({})
        # Cinematic paints selection entirely inside the Settings/Episodes row
        # renderer. Disable Enigma2's native listbox selection layer, otherwise
        # some OpenBH skins inject the red rectangular slab seen on receiver.
        try:
            if self["cin_list"].instance is not None:self["cin_list"].instance.setSelectionEnable(0)
        except Exception as exc:optional_failure("cinematic.native_selection",exc)
        # drain completed HDD visual jobs quickly enough that a ready
        # backdrop does not sit in the queue for half a second after navigation.
        # Re-run the exact Details season/runtime fit only after Enigma has
        # instantiated the label and its real 102px width is available.
        self._cin_fit_runtime_like_details()
        try:self._cin_set_poll_interval(120 if self._cin_poll_has_pending_work() else 0,force=True)
        except Exception as exc:optional_failure("cinematic.poll_start",exc)

    def _set_native_pixmap(self,widget,path):
        try:
            if path and not os.path.isabs(str(path)):path=asset(path)
            path=str(path or "")
            if path and os.path.isfile(path) and self[widget].instance is not None:
                if self._cin_widget_paths.get(widget)==path:
                    self[widget].show();return True
                self[widget].instance.setPixmapFromFile(path);self._cin_widget_paths[widget]=path;self[widget].show();return True
            self._cin_widget_paths.pop(widget,None);self[widget].hide()
        except Exception as exc:optional_failure("cinematic.native_pixmap",exc)
        return False

    def _cin_buffered_handoff(self,base_name,stage_name,path,expected_sig=""):
        """Commit one decoder-ready backdrop without ever blanking last-good.

        Stage 5 keeps the proven single native full-screen surface used by
        Cinematic/BG1/BG2, but removes the destructive ``setPixmap(None)`` that
        ran *before* the replacement bind.  If a decoder/driver rejects the new
        JPEG, the already-visible backdrop therefore remains on screen.

        ``expected_sig`` is the selected catalogue identity at schedule time.
        Async/cache completions are allowed to paint only while that identity is
        still current; a stale title can never replace the user's current image.
        """
        try:
            path=str(path or "");expected_sig=str(expected_sig or "")
            if expected_sig and expected_sig!=self._fast_bd_current_sig():return False
            if not path or not os.path.isfile(path):return False
            target=self[base_name]
            if target.instance is None:return False
            if self._cin_pixmap_paths.get(base_name)==path:
                if expected_sig and expected_sig!=self._fast_bd_current_sig():return False
                target.show();return True
            # Never clear the committed surface first. setPixmapFromFile replaces
            # it only when Enigma accepts the new decoder-ready file, preserving
            # last-good on missing/corrupt/stale candidates.
            target.instance.setPixmapFromFile(path)
            if expected_sig and expected_sig!=self._fast_bd_current_sig():return False
            self._cin_pixmap_paths[base_name]=path
            self._cin_active_pixmap[base_name]=base_name
            target.show()
            try:
                stage=self[stage_name]
                stage.hide()
                if stage.instance is not None:stage.instance.setPixmap(None)
                self._cin_pixmap_paths.pop(stage_name,None)
            except Exception:pass
            return True
        except Exception as exc:optional_failure("cinematic.single_backdrop_handoff",exc);return False

    def _apply_native_detail_chrome(self,chrome):
        """Fixed-green cold shell + atomic hold-last-good title adaptive.

        A visible chrome set is never cleared, hidden, or partially replaced on
        navigation.  Cold open starts from the complete fixed-green set.  After
        that, only another complete eight-surface title adaptive may replace the
        currently visible set.
        """
        incoming=chrome if isinstance(chrome,dict) else {}
        required=("panel_detail","overview_detail","cast_detail","quality","year","runtime","country","genre_detail")
        incoming_complete=all(str(incoming.get(k) or "") and os.path.isfile(str(incoming.get(k) or "")) for k in required)

        previous=dict(getattr(self,"_cin_last_chrome",{}) or {})
        previous_complete=all(str(previous.get(k) or "") and os.path.isfile(str(previous.get(k) or "")) for k in required)

        if incoming_complete:
            active={k:str(incoming.get(k) or "") for k in required}
            self._cin_last_chrome=dict(active)
        elif previous_complete:
            active=previous
        else:
            # Only possible before first layout paint or with a damaged package.
            # Prefer the fixed master as a complete set instead of mixing/hiding.
            master=self._cin_fixed_master_chrome() or {}
            if all(str(master.get(k) or "") and os.path.isfile(str(master.get(k) or "")) for k in required):
                active=master;self._cin_last_chrome=dict(master)
            else:
                active=previous

        mapping={
            "panel_bg":"panel_detail",
            "overview_bg":"overview_detail",
            "cast_card_bg":"cast_detail",
            "quality_pill_bg":"quality",
            "year_pill_bg":"year",
            "runtime_pill_bg":"runtime",
            "country_pill_bg":"country",
            "genre_pill_bg":"genre_detail",
        }
        for widget,key in mapping.items():
            path=str(active.get(key) or "")
            if path and os.path.isfile(path):
                if key=="overview_detail":
                    path=self._cin_sharp_details_overview(path,(1318,170),"overview_detail") or path
                elif key=="panel_detail":
                    path=self._cin_sharp_details_overview(path,(1410,360),"panel_detail") or path
                self._set_native_pixmap(widget,path)
                continue
            # Never blank a resident widget.  A missing replacement is simply
            # ignored until the complete next chrome set exists.
            held=str((getattr(self,"_cin_widget_paths",{}) or {}).get(widget) or "")
            if held and os.path.isfile(held):
                try:self[widget].show()
                except Exception:pass

    @staticmethod
    def _cin_adaptive_rows_ready(rows):
        rows=rows if isinstance(rows,dict) else {}
        normal=str(rows.get("normal") or rows.get("row_normal") or "")
        selected=str(rows.get("selected") or rows.get("row_selected") or "")
        return bool(normal and selected and os.path.isfile(normal) and os.path.isfile(selected))

    @staticmethod
    def _cin_adaptive_chrome_ready(chrome):
        chrome=chrome if isinstance(chrome,dict) else {}
        required=("panel_detail","overview_detail","cast_detail","quality","year","runtime","country","genre_detail")
        return all(str(chrome.get(key) or "") and os.path.isfile(str(chrome.get(key) or "")) for key in required)

    def _cin_refresh_rail_material_only(self,allow_progress_build=True):
        """Rebind visible Cinematic rows without rebuilding/indexing the page.

        The old path called ``_render_grid`` after every adaptive colour change.
        That rescanned page packages/HDD metadata and then recursively ran a full
        selection update on the GUI thread.  Per-entry invalidation is enough:
        names, progress and selection state are already resident in RAM.
        """
        try:
            limit=min(int(self.page_size or 0),len(self.grid_items or []))
            for pos in range(limit):
                row=(getattr(self,"_cin_page_records",{}) or {}).get(pos,{}) or {}
                self["cin_list"].update_icon_row(pos,self._cin_list_row(pos,selected=(pos==self.index),record=row,allow_progress_build=allow_progress_build))
            if limit:
                self["cin_list"].moveToIndex(max(0,min(int(self.index),limit-1)))
                self._cin_last_list_index=int(self.index)
            return True
        except Exception as exc:
            optional_failure("cinematic.atomic_rows_refresh",exc);return False

    def _cin_commit_adaptive_presentation(self,item,row,rows,chrome,accent=""):
        """Commit rail material + Details chrome as one selected-title state.

        A title never paints only the overview/description chrome and later the
        left rail (or vice versa).  Until BOTH complete surface sets exist, the
        previously committed adaptive state stays visible.  The commit itself is
        GUI-only and performs no page scan, metadata lookup, image analysis or
        network work.
        """
        if self._screen_closed or not self.grid_items:return False
        if not self._cin_adaptive_rows_ready(rows) or not self._cin_adaptive_chrome_ready(chrome):return False
        try:
            current=self.grid_items[self.index]
            if self._page_visual_key(current)!=self._page_visual_key(item):return False
        except Exception:return False
        normal=str(rows.get("normal") or rows.get("row_normal") or "")
        selected=str(rows.get("selected") or rows.get("row_selected") or "")
        key=self._record_key(row,item)
        try:
            changed=bool(normal!=self._settings_row_asset or selected!=self._settings_row_selected_asset)
            self._settings_row_asset=normal;self._settings_row_selected_asset=selected
            # R5.233: publish adaptive ownership BEFORE repainting the visible rail.
            # R5.232 flipped this flag after _cin_refresh_rail_material_only(), so
            # the first selected row was rebuilt with the fixed Poster ring and
            # only corrected itself after the next Up/Down navigation event.
            next_adaptive_active=bool(adaptive_enabled())
            state_changed=bool(next_adaptive_active!=bool(getattr(self,"_cin_adaptive_rows_active",False)))
            self._cin_off_committed=not next_adaptive_active
            self._cin_adaptive_rows_active=next_adaptive_active
            if re.match(r"^#[0-9a-fA-F]{6}$",str(accent or "")):
                # Keep the laser colour authority, but do not force a full page
                # rebuild.  Existing laser pixmaps stay resident until a row is
                # naturally invalidated; adaptive row surfaces still swap now.
                self._cin_progress_accent=str(accent).lower()
            if changed or state_changed:self._cin_refresh_rail_material_only()
            self._apply_native_detail_chrome(chrome)
            self._cin_committed_adaptive_key=str(key or "")
            try:self._cin_display_adaptive_owner_sig=str(self._page_visual_key(item) or "")
            except Exception:self._cin_display_adaptive_owner_sig=""
            # State was published before the rail repaint above so the current
            # selected row switches material atomically with this commit.
            return True
        except Exception as exc:
            optional_failure("cinematic.atomic_adaptive_commit",exc);return False

    def _cin_adaptive_source_for(self, item=None, row=None):
        """Return the best already-local artwork source for adaptive chrome.

        Cold titles can paint a clean fast-backdrop before Details Authority has
        copied that path into the canonical row.  R5.232 looked only at
        row.poster_local/backdrop_local, so those titles could remain on the
        fixed Premium shell forever despite a valid image already being visible.
        This resolver is lookup-only: it never downloads, scans or builds.
        """
        row = row if isinstance(row, dict) else {}
        item = item if isinstance(item, dict) else {}
        candidates = (
            row.get("poster_local"), row.get("backdrop_local"),
            item.get("_ultra_palette_source"), item.get("_adaptive_source_local"),
            item.get("_cin_provider_poster_local"), item.get("_backdrop_source_local"),
            item.get("_cin_provider_backdrop_local"), item.get("_details_clean_backdrop_source"),
        )
        for value in candidates:
            path = str(value or "")
            try:
                if path and os.path.isfile(path) and os.path.getsize(path) > 512:
                    return path
            except Exception:
                pass
        try:
            sig = str(self._page_visual_key(item) or "")
            fast_sig = str(getattr(self, "_fast_bd_sig", "") or "")
            fast_path = str(getattr(self, "_fast_bd_path", "") or "")
            if sig and sig == fast_sig and fast_path and os.path.isfile(fast_path) and os.path.getsize(fast_path) > 512:
                return fast_path
        except Exception:
            pass
        return ""

    def _cin_apply_nav_adaptive_baseline(self):
        """R5.47 timing law: cached adaptive commits after 450 ms quiet.

        This lane never builds. Titles without cached surfaces stay on the last
        good adaptive until the 550 ms stable-focus worker starts generation.
        """
        try:
            if self._screen_closed or not self.grid_items or getattr(self,"_cin_hidden",False):return False
            if not adaptive_enabled():return False
            quiet=time.monotonic()-float(getattr(self,"_cin_last_nav_at",0.0) or 0.0)
            if quiet<0.45:
                self._cin_nav_adaptive_timer.stop();self._cin_nav_adaptive_timer.start(max(40,int((0.45-quiet)*1000)),True)
                return False
            item=self.grid_items[self.index]
            row=(getattr(self,"_cin_page_records",{}) or {}).get(int(self.index),{}) or self._record(item) or {}
            source=self._cin_adaptive_source_for(item,row)
            if not source:return False
            rows_key=canonical_dynamic_rows_key(source,selected_rim_only=True,cinematic_premium=False)
            chrome_key=canonical_dynamic_details_key(source)
            if not (rows_key and chrome_key):return False
            rows=_cached_dynamic_settings_episode_rows(source,rows_key,selected_rim_only=True,cinematic_premium=False) or {}
            if not (rows.get("normal") and rows.get("selected")):return False
            chrome=_cached_dynamic_details_chrome(source,chrome_key) or {}
            if not chrome:return False
            return bool(self._cin_commit_adaptive_presentation(item,row,rows,chrome,""))
        except Exception as exc:
            optional_failure("cinematic.quick_cached_adaptive",exc);return False
