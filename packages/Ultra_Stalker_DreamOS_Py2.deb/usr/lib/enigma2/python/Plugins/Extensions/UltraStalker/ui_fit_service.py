# -*- coding: utf-8 -*-
"""Prepare missing list derivatives off the GUI thread, then rebind existing rows."""
from __future__ import absolute_import,division,print_function,unicode_literals
import weakref
from . import us_env as _env
from .us_env import str,int,max,min
threading=_env.threading;os=_env.os
from .core.executor import PriorityLazyExecutor
_FIT_EXECUTOR=PriorityLazyExecutor(max_workers=1,max_pending=16,thread_name_prefix='ultrastalker-ui-fit')
_PENDING=set()
_LOCK=threading.Lock()
_OBSERVERS=[]
def register(owner):
    global _OBSERVERS
    _OBSERVERS=[ref for ref in _OBSERVERS if ref() is not None]
    if not any(ref() is owner for ref in _OBSERVERS):
        try:_OBSERVERS.append(weakref.ref(owner))
        except TypeError:pass
    if len(_OBSERVERS)>256:_OBSERVERS=_OBSERVERS[-256:]
def _publish(source,geometry,ptr,old=None):
    from . import wqhd_layout as layout
    for ref in list(_OBSERVERS):
        owner=ref()
        if owner is None:continue
        if hasattr(owner,"instance") and owner.instance is None:continue
        content=getattr(owner,'l',None)
        if content is None:continue
        try:rows=content.getList()
        except Exception:rows=getattr(_env,'_CONTENT_ROWS',{}).get(id(content))
        if not isinstance(rows,list):continue
        changed=False
        for row in rows:
            if not isinstance(row,list):continue
            for index,entry in enumerate(row[1:],1):
                if not isinstance(entry,tuple) or len(entry)<6 or entry[0] not in layout._pixmap_flags()[0]:continue
                if (int(entry[3]),int(entry[4]))!=geometry:continue
                existing=entry[5]
                record=layout._PIXMAP_PATHS.get(id(existing))
                path=record[1] if record and record[0] is existing else ''
                origin=layout._FIT_ORIGINS.get(path)
                if (old is not None and existing is old) or path==source or (origin and origin[0]==source):
                    value=list(entry);value[5]=ptr;row[index]=tuple(value);changed=True
        if changed:
            try:content.invalidate()
            except Exception:pass
def _submit(key,source,geometry,build,cache_key=None,old=None):
    with _LOCK:
        if key in _PENDING:return
        _PENDING.add(key)
    def work():
        try:return build()
        finally:pass
    def done(future):
        try:path=future.result()
        except Exception:path=''
        def apply():
            try:
                if not path or not os.path.isfile(path):return
                from enigma import loadPNG
                from . import wqhd_layout as layout
                ptr=loadPNG(path)
                if ptr is None:return
                layout.register_pixmap_path(ptr,path)
                if cache_key is not None:layout._WQHD_PIXMAP_CACHE[cache_key]=ptr
                _publish(source,geometry,ptr,old)
            finally:
                with _LOCK:_PENDING.discard(key)
        try:
            from twisted.internet import reactor
            reactor.callFromThread(apply)
        except Exception:
            with _LOCK:_PENDING.discard(key)
    try:_FIT_EXECUTOR.submit(work,priority=1,_task_key=str(key)).add_done_callback(done)
    except Exception:
        with _LOCK:_PENDING.discard(key)
def request_file(source,width,height,nine=False):
    def build():
        from .ui_icon_menu import _us_fit_png
        return _us_fit_png(source,width,height,nine)
    _submit(('file',source,int(width),int(height),bool(nine)),source,(int(width),int(height)),build)
def request_scaled(ptr,path,orig_w,orig_h,target_w,target_h,ckey):
    from . import wqhd_layout as layout
    origin=layout._FIT_ORIGINS.get(path)
    base,nine=origin if origin is not None else (path,bool(orig_w>=64 and orig_h>=22 and orig_w!=orig_h))
    def build():
        from .ui_icon_menu import _us_fit_png
        src_w,src_h=layout._image_dims(base)
        fit_w,fit_h=int(target_w),int(target_h)
        slicing=nine
        if src_w>orig_w and orig_h<=40 and any(k in base.lower() for k in ('pbar','laser','fill','track','neon')):
            fit_w,fit_h=layout.wh(src_w,src_h);slicing=False
        return _us_fit_png(base,fit_w,fit_h,slicing)
    _submit(('scaled',ckey),base,(int(target_w),int(target_h)),build,ckey,ptr)
