# -*- coding: utf-8 -*-
"""Ready/shown handling and timers.

Methods moved verbatim out of ``PortalGlobalSearchScreen`` (ui_screens_search.py); behaviour is unchanged.
This module is imported by ui_screens_search.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals


class SearchLifecycleMixin(object):
    """Ready/shown handling and timers."""

    def _ready(self):
        # Search is intentionally static/lightweight. The shared Palestine
        # background is already painted by the skin before this callback runs;
        # no Hero lookup, adaptive backdrop build, palette work or glass
        # generation is allowed on this screen.
        self._history_hide()
        self._source_picker_bind()
        self._source_picker_hide()
        self._hide_search_gateway()
        self._render()

    def _shown(self):
        if not self._first_prompt_pending:
            return
        self._first_prompt_pending = False
        try:
            self.onShown.remove(self._shown)
        except Exception:
            pass
        try:
            self._prompt_timer.start(120, True)
        except Exception:
            self._open_first_prompt()

    def _open_first_prompt(self):
        if not getattr(self, "_screen_closed", False):
            self.prompt()

    def _stop_prompt_timer(self):
        try:
            self._prompt_timer.stop()
        except Exception:
            pass
        try:
            if self._prompt_timer_conn is not None:
                self._prompt_timer_conn.disconnect()
        except Exception:
            pass
        try:
            if self._open_first_prompt in self._prompt_timer.callback:
                self._prompt_timer.callback.remove(self._open_first_prompt)
        except Exception:
            pass

    def _stop_sd_timer(self):
        self._sd_pending_item = None
        try:self._sd_timer.stop()
        except Exception:pass
        try:
            if self._sd_timer_conn is not None:
                self._sd_timer_conn.disconnect()
        except Exception:pass
        try:
            if self._search_details_deferred in self._sd_timer.callback:
                self._sd_timer.callback.remove(self._search_details_deferred)
        except Exception:pass
