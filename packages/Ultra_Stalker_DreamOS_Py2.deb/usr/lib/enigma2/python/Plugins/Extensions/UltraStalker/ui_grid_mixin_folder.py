# -*- coding: utf-8 -*-
"""Folder catalogue data, filtering, sorting and folder artwork progress.

Methods moved verbatim out of ``PremiumGridBase`` (ui_grid_base.py); behaviour is unchanged.
This module is imported by ui_grid_base.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, zip, max, min, us_clear, us_casefold
from .ui_grid_base import (
    _,
    _ui_diag,
    diagnostic_failure,
    threading,
    time,
)


class GridFolderMixin(object):
    """Folder catalogue data, filtering, sorting and folder artwork progress."""

    @staticmethod
    def _folder_search_norm(value):
        text=us_casefold(str(value or ""))
        # Arabic-friendly normalization without changing what is displayed.
        text=re.sub(r"[\u064b-\u065f\u0670\u06d6-\u06ed]","",text)
        text=text.replace("\u0640","")
        text=re.sub(r"[\s._\-–—:/|]+"," ",text)
        return " ".join(text.split())

    @staticmethod
    def _folder_rating_value(item):
        """Return TMDb rating only for poster cards.

        Provider/IMDb ratings are intentionally excluded.  The poster score must
        match the canonical TMDb value used by Details.  `_tmdb_rating` is filled
        by the existing artwork/TMDb hydration lane and is therefore network-free
        on the GUI thread.
        """
        for value in (
            item.get("_tmdb_rating"),item.get("tmdb_rating"),item.get("vote_average"),
            item.get("rating"),item.get("rating_imdb"),item.get("imdb_rating"),
        ):
            match=re.search(r"\d+(?:\.\d+)?",str(value or ""))
            if match:
                try:
                    score=float(match.group(0))
                    if 0.0 < score <= 10.0:return score
                except Exception as exc:diagnostic_failure("ui.grid.tmdb_rating",exc)
        return -1.0

    @staticmethod
    def _folder_year_value(item):
        for value in (
            item.get("year"),item.get("released"),item.get("release_date"),
            item.get("releasedate"),item.get("first_air_date"),item.get("create_date"),
        ):
            match=re.search(r"(?:19|20)\d{2}",str(value or ""))
            if match:
                try:return int(match.group(0))
                except Exception as exc:diagnostic_failure("ui.grid.failsoft.353",exc)
        return 0

    def _display_item_title(self,item,default=""):
        item=item if isinstance(item,dict) else {}
        clean=bool((self._grid_settings or {}).get("clean_titles",True))
        raw=item.get("_raw_name") or item.get("name") or item.get("title") or item.get("original_name") or item.get("original_title") or default
        raw=str(raw or "")
        # Display-only rescue for provider route/catalogue codes such as ``SH``.
        # If a meaningful localized title is present on the same item/default,
        # prefer it for presentation without changing identity/cache fields.
        if re.fullmatch(r"[A-Za-z0-9+._-]{1,8}",raw.strip()):
            for alt in (item.get("_raw_name"),item.get("_provider_name"),item.get("original_name"),item.get("original_title"),default):
                alt=str(alt or "").strip()
                if len(alt)>=3 and re.search(r"[\u0600-\u06ff]",alt):
                    raw=alt;break
        if not clean:
            return raw.strip()
        try:
            if self.media_type=="itv":return _clean_live_channel_name(raw,True)
            if self.media_type in ("vod","series"):return _catalogue_title(raw)
            return premium_title(raw,True)
        except Exception:return raw.strip()

    def _folder_title_value(self,item):
        return self._display_item_title(item,"")

    def _folder_item_identity(self,item,index=0):
        for key in ("id","movie_id","series_id","ch_id","cmd","command","url"):
            value=item.get(key)
            if value not in (None,""):return "%s:%s"%(key,value)
        return "title:%s:%d"%(self._folder_search_norm(self._folder_title_value(item)),int(index))

    def _active_total(self):
        if self.media_type in ("vod","series") and self._view_active and isinstance(self._view_items,list):
            return len(self._view_items)
        return int(self._portal_total or 0)

    def _apply_shared_footer_geometry(self):
        if not getattr(self,"shared_footer",False):return
        try:
            from .ui_shared_footer import apply_footer_geometry
            apply_footer_geometry(self)
        except Exception as exc:optional_failure("ui.shared_footer",exc)

    def _refresh_search_sort_controls(self):
        if self.media_type not in ("vod","series"):
            self._apply_shared_footer_geometry();return
        label=_(self._FOLDER_SORT_LABELS[self._sort_mode % len(self._FOLDER_SORT_LABELS)])
        try:self["red"].setText(_("Search"))
        except Exception as exc:diagnostic_failure("ui.grid.failsoft.376",exc)
        try:self["yellow"].setText(label)
        except Exception as exc:diagnostic_failure("ui.grid.failsoft.378",exc)
        try:
            blue_label=str(self["blue"].getText() or "Check Artwork")
            units=sum(1.55 if ord(ch)>0x2ff else (0.60 if ch in " ilI1|.,:'" else 1.0) for ch in blue_label)
            size=22 if units<=11 else (21 if units<=15 else (19 if units<=19 else 17))
            if self["blue"].instance is not None:self["blue"].instance.setFont(_ultra_rfont("Regular",size))
        except Exception as exc:optional_failure("ui.folder_cache_label_font",exc)
        # The yellow box geometry never changes. Only the font scales, always
        # centered horizontally/vertically by the existing skin.
        try:
            units=sum(1.55 if ord(ch)>0x2ff else (0.60 if ch in " ilI1|.,:'" else 1.0) for ch in label)
            size=22 if units<=10 else (21 if units<=14 else (19 if units<=18 else 17))
            if self["yellow"].instance is not None:self["yellow"].instance.setFont(_ultra_rfont("Regular",size))
        except Exception as exc:optional_failure("ui.folder_sort_label_font",exc)
        try:
            base=str(self.category_title or "")
            self["section"].setText(base)
        except Exception as exc:diagnostic_failure("ui.grid.failsoft.397",exc)
        self._apply_shared_footer_geometry()

    def _load_folder_catalog_data(self,cancel_event=None):
        if self.media_type not in ("vod","series","itv"):return []
        first=self._portal_page(1,cancel_event=cancel_event)
        native=max(1,int(self._portal_page_size or len(first) or self.page_size))
        total=max(0,int(self._portal_total or 0))
        max_pages=max(1,min(int((self._grid_settings or {}).get("search_max_pages",250) or 250),500))
        expected_pages=((total+native-1)//native) if total else max_pages
        expected_pages=max(1,min(expected_pages,max_pages))
        rows=[];seen=set();previous_signature=None
        for native_page in range(1,expected_pages+1):
            if cancel_event is not None and cancel_event.is_set():raise _ArtworkCancelled()
            page_rows=first if native_page==1 else self._portal_page(native_page,cancel_event=cancel_event)
            if not page_rows:break
            signature=tuple(self._folder_item_identity(row,pos) for pos,row in enumerate(page_rows[:4]))
            if native_page>1 and signature and signature==previous_signature:
                # Some portals ignore p= and repeat page one forever.
                break
            previous_signature=signature
            added=0
            for pos,row in enumerate(page_rows):
                if not isinstance(row,dict):continue
                # Xtream provider artwork is authoritative. Do not strip cover/backdrop
                # before folder caching/search; Stalker keeps the external-art policy.
                if row.get("_xtream"):
                    item=dict(row)
                else:
                    raw_provider_art="";raw_provider_backdrop="";raw_provider_backdrops=[]
                    try:raw_provider_art=str(_image_url(row) or "").strip()
                    except Exception:raw_provider_art=""
                    try:
                        from .ui_artwork_helpers import _backdrop_url as _manual_backdrop_url, _backdrop_candidates as _manual_backdrop_candidates
                        raw_provider_backdrop=str(_manual_backdrop_url(row) or "").strip()
                        raw_provider_backdrops=[str(x or "").strip() for x in (_manual_backdrop_candidates(row) or []) if str(x or "").strip()]
                    except Exception:raw_provider_backdrop="";raw_provider_backdrops=[]
                    item=_strip_portal_artwork(row)
                    # Preserve every real provider candidate privately for BLUE.
                    # Some Stalker portals expose a dead first screenshot followed
                    # by a valid CDN fanart URL; keeping only candidate #1 caused
                    # an avoidable permanent 'left N' after TMDB had its chance.
                    if raw_provider_art:item["_rescue_provider_art_url"]=raw_provider_art
                    if raw_provider_backdrop:item["_rescue_provider_backdrop_url"]=raw_provider_backdrop
                    if raw_provider_backdrops:item["_rescue_provider_backdrop_candidates"]=raw_provider_backdrops
                identity=self._folder_item_identity(item,len(rows)+pos)
                if identity in seen:continue
                seen.add(identity);rows.append(item);added+=1
                if total and len(rows)>=total:break
            if total and len(rows)>=total:break
            if not added:break
            if not total and len(page_rows)<native:break
        # Reject obvious provider-wide placeholder art from the explicit rescue
        # chain. A repeated list-level icon is not a real missing-title poster.
        try:
            rescue_counts={};backdrop_counts={}
            for item in rows:
                if not isinstance(item,dict):continue
                url=str(item.get("_rescue_provider_art_url") or "").strip()
                burl=str(item.get("_rescue_provider_backdrop_url") or "").strip()
                if url:rescue_counts[url]=rescue_counts.get(url,0)+1
                if burl:backdrop_counts[burl]=backdrop_counts.get(burl,0)+1
            generic_rescue={url for url,count in rescue_counts.items() if count>=3}
            generic_backdrop={url for url,count in backdrop_counts.items() if count>=3}
            if generic_rescue or generic_backdrop:
                for item in rows:
                    if not isinstance(item,dict):continue
                    if str(item.get("_rescue_provider_art_url") or "").strip() in generic_rescue:
                        item["_rescue_provider_art_generic"]=True
                    if str(item.get("_rescue_provider_backdrop_url") or "").strip() in generic_backdrop:
                        item["_rescue_provider_backdrop_generic"]=True
        except Exception as exc:optional_failure("ui.folder_rescue_generic_detect",exc)
        return rows

    def _ensure_folder_catalog(self,callback):
        if self.media_type not in ("vod","series","itv"):return
        if isinstance(self._folder_catalog,list):
            callback(self._folder_catalog);return
        self._folder_catalog_waiters.append(callback)
        if self._folder_catalog_loading:return
        self._folder_catalog_loading=True
        self["status"].setText(_("Loading folder index..."))
        def ok(rows):
            self._folder_catalog_loading=False
            self._folder_catalog=[x for x in (rows or []) if isinstance(x,dict)]
            if not self._portal_total:self._portal_total=len(self._folder_catalog)
            waiters=list(self._folder_catalog_waiters);self._folder_catalog_waiters=[]
            for cb in waiters:
                try:cb(self._folder_catalog)
                except Exception as exc:optional_failure("ui.folder_catalog_waiter",exc)
        def failed(error):
            self._folder_catalog_loading=False
            self._folder_catalog_waiters=[]
            self["status"].setText(_friendly_error(error))
        self._run_async(lambda handle:self._load_folder_catalog_data(handle.cancel_event),ok,failed)

    def _build_folder_view(self):
        query=self._folder_search_norm(self._search_query)
        # R76: a live Search view may come from the same bounded provider-search
        # lane used by Home Search. Keep it independent from _folder_catalog so
        # clearing Search returns to normal native paging without a giant scan.
        if query and isinstance(getattr(self,"_folder_search_rows",None),list):
            rows=list(self._folder_search_rows or [])
        else:
            rows=list(self._folder_catalog or [])
        if query:
            filtered=[]
            for item in rows:
                haystack=" ".join(self._folder_search_norm(item.get(key)) for key in ("name","title","original_name","original_title"))
                if query in haystack:filtered.append(item)
            rows=filtered
        mode=self._sort_mode % len(self._FOLDER_SORT_LABELS)
        if mode==1:
            rows=sorted(rows,key=lambda item:(self._folder_rating_value(item)<0,-self._folder_rating_value(item),self._folder_search_norm(self._folder_title_value(item))))
        elif mode==2:
            rows=sorted(rows,key=lambda item:(self._folder_year_value(item)<=0,-self._folder_year_value(item),self._folder_search_norm(self._folder_title_value(item))))
        elif mode==3:
            rows=sorted(rows,key=lambda item:(self._folder_year_value(item)<=0,self._folder_year_value(item) if self._folder_year_value(item)>0 else 9999,self._folder_search_norm(self._folder_title_value(item))))
        elif mode==4:
            rows=sorted(rows,key=lambda item:self._folder_search_norm(self._folder_title_value(item)))
        elif mode==5:
            rows=sorted(rows,key=lambda item:self._folder_search_norm(self._folder_title_value(item)),reverse=True)
        self._view_items=rows
        self._view_active=True
        return rows

    def _load_folder_view_page(self,page,restore_index=None):
        self._ui_diag_page_request_mono=time.monotonic();self._ui_diag_first_poster_logged=False

        # Folder-view navigation is a real page transition too.  Reset the
        # previous page's poster-prefetch lifecycle exactly like load_page():
        # otherwise _page_prefetch_seen keeps the old card keys and revisiting a
        # page leaves provider-owned cards as permanent placeholders.
        try:
            old_cancel=getattr(self,"_page_prefetch_cancel",None)
            if old_cancel is not None:
                old_cancel.set()
        except Exception as exc:optional_failure("ui.folder_prefetch_cancel",exc)

        self._cancel_detached_page_prefetch_futures()
        for future in list(getattr(self,"_page_prefetch_futures",[]) or []):
            try:future.cancel()
            except Exception as exc:optional_failure("ui.folder_prefetch_future_cancel",exc)
        self._page_prefetch_futures=[]
        self._page_prefetch_cancel=threading.Event()
        try:self._page_prefetch_generation+=1
        except Exception:self._page_prefetch_generation=1
        try:
            with self._page_prefetch_lock:
                us_clear(self._page_prefetch_seen)
                us_clear(self._visible_tmdb_pending)
                us_clear(self._page_quality_seen)
                us_clear(self._page_art_retry_count)
        except Exception as exc:optional_failure("ui.folder_prefetch_reset",exc)

        rows=self._build_folder_view()
        total=len(rows);total_pages=max(1,(total+self.page_size-1)//self.page_size)
        target=max(1,min(int(page),total_pages))
        start=(target-1)*self.page_size
        valid=rows[start:start+self.page_size]
        if self.media_type in ('vod','series'):
            from .manual_identity import apply_choice
            valid=[apply_choice(self.profile,self.media_type,x) for x in valid]
        if self.media_type in ("vod","series"):
            for _age_item in valid:
                if not isinstance(_age_item,dict):continue
                try:
                    from .ui_grid_v2_premium import seed_badge_metadata, merge_badge_metadata
                    seed_badge_metadata(self,_age_item)
                    _snap=load_artwork_v2_manifest(self.profile,self.media_type,_age_item) or {}
                    if not _snap.get("tmdb_id") or not (_snap.get("rating") or _snap.get("vote_average")) or not (_snap.get("_age_rating_checked") or _snap.get("certification") or _snap.get("age_rating")):
                        try:
                            from .details_authority import load_canonical as _da_load_canonical
                            _canon=_da_load_canonical(self.profile,self.media_type,_age_item) or {}
                            for _ck,_cv in _canon.items():
                                if _cv not in (None,"",[],{}) and _snap.get(_ck) in (None,"",[],{}):
                                    _snap[_ck]=_cv
                        except Exception:pass
                    if _snap:
                        merge_badge_metadata(self,_age_item,_snap)
                except Exception:pass
                try:self._age_cache_seed_item(_age_item)
                except Exception as exc:optional_failure("ui.age_cache_folder_first_paint",exc)
        self.page=target;self.grid_items=valid
        self._initial_grid_paint_done=True
        states=load_content_states(self.profile,self.media_type,self.grid_items) if self.grid_items else []
        qualities=load_content_qualities(self.profile,self.media_type,self.grid_items) if self.grid_items else []
        self._grid_item_state={}
        for item,state,quality in zip(self.grid_items,states,qualities):
            row=dict(state or {});row["quality"]=quality or "";self._grid_item_state[id(item)]=row
        self.index=max(0,min(int(restore_index or 0),len(valid)-1)) if valid else 0
        self._grid_full_chrome_warm=False
        # Folder views used to fall through to _grid_request_art() with no
        # prepared-art map. That forced up to 12 synchronous HDD snapshot /
        # visual-bundle / manifest lookups during the GUI paint itself.
        #
        # Paint the page immediately, then let the existing visible-poster
        # workers fill cards progressively. An explicit empty row is important:
        # _grid_request_art() sees the slot as prepared and never enters its
        # legacy synchronous cold fallback.
        self._prepared_art_for_render=list(self._page_visual_get(item) or {} for item in valid)
        self._prepared_titles_for_render=[]
        self._prepared_fitted_for_render=[]
        self._prepared_meta_for_render=[]
        self._render_grid();self._remember_grid_state();self._refresh_search_sort_controls()
        try:
            if int(getattr(self,"_grid_page_nav_target",0) or 0)==int(self.page or 0):
                self._grid_page_nav_target=0;self._grid_page_nav_index=0
        except Exception:pass
        try:_ui_diag("ui_page_ready",screen="grid",media_type=self.media_type,page=self.page,items=len(self.grid_items),
                     folder_view=True,elapsed_ms=int(max(0.0,(time.monotonic()-self._ui_diag_page_request_mono)*1000.0)))
        except Exception as exc:diagnostic_failure("ui.grid.failsoft.496",exc)
        self._update_page_counter()
        if valid:
            self["status"].setText("")
            try:self._start_progressive_poster_prefetch()
            except Exception as exc:optional_failure("ui.folder_view_auto_visible_page",exc)
            if bool(getattr(self,"visible_card_rating_prefetch",False)) and self.media_type in ("vod","series"):
                try:
                    self._schedule_visible_rating_sweeps()
                except Exception as exc:
                    optional_failure("ui.folder_visible_rating_schedule",exc)
        else:
            try:self["selection"].hide()
            except Exception as exc:diagnostic_failure("ui.grid.failsoft.507",exc)
            try:self["title"].setText(self.category_title);self["rating"].setText("");self["meta1"].setText("");self["meta2"].setText("")
            except Exception as exc:diagnostic_failure("ui.grid.failsoft.509",exc)
            self["status"].setText(_("No matching content"))

    def _apply_folder_artwork_result(self,result):
        if getattr(self,"_folder_artwork_ui_finalized",False):return
        self._folder_artwork_ui_finalized=True
        self._folder_artwork_cache_running=False
        result=result or {}
        try:
            self["blue"].setText(str(getattr(self,"_folder_artwork_idle_label","") or _("Check Artwork")));self._refresh_search_sort_controls()
        except Exception as exc:optional_failure("ui.check_artwork_controls",exc)
        if result.get("backdrop_page_cache"):
            total=int(result.get("total",0) or 0);done=int(result.get("done",0) or 0)
            cached=int(result.get("cached",0) or 0);downloaded=int(result.get("downloaded",0) or 0);failed=int(result.get("failed",0) or 0)
            try:
                cache_label=str(result.get("cache_label") or _("Backdrop cache"))
                label=(_("%s incomplete") if (result.get("incomplete") or done<total) else _("%s complete"))%cache_label
                self["status"].setText(_("%s • %d/%d • new %d • already %d • failed %d")%(label,done,total,downloaded,cached,failed))
            except Exception:pass
            try:us_clear(self._page_prefetch_seen)
            except Exception:pass
            try:
                if total>0 and ("details_ready" in result or "logos_ready" in result):
                    self["status"].setText(str(self["status"].getText() or "")+_(" • details %d/%d • logos %d/%d")%(int(result.get("details_ready",0)),total,int(result.get("logos_ready",0)),total))
            except Exception:pass
            try:
                from .ui_grid_v2_premium import merge_badge_metadata, seed_badge_metadata
                from .artwork_v2 import load_fast_local_poster as _fast_lp
                from .details_authority import load_canonical as _da_load_canonical
                for _pos,_vis_item in enumerate(list(getattr(self,"grid_items",[]) or [])):
                    if not isinstance(_vis_item,dict):continue
                    try:
                        _canon=_fast_lp(self.profile,self.media_type,_vis_item) or _da_load_canonical(self.profile,self.media_type,_vis_item) or load_artwork_v2_manifest(self.profile,self.media_type,_vis_item) or {}
                        if _canon:
                            merge_badge_metadata(self,_vis_item,_canon)
                        seed_badge_metadata(self,_vis_item)
                        if hasattr(self,"_card_rating_layout"):
                            self._card_rating_layout(_vis_item,_pos)
                    except Exception:pass
            except Exception:pass
            try:self._poll_visible_poster_cache(refresh=True)
            except Exception:pass
            try:
                if hasattr(self,"_spot_settle") and getattr(self,"grid_items",None):
                    self._spot_key=""
                    if hasattr(self,"_spot_meta_rows") and hasattr(self._spot_meta_rows,"clear"):self._spot_meta_rows.clear()
                    if hasattr(self,"_spot_logo_paths") and hasattr(self._spot_logo_paths,"clear"):self._spot_logo_paths.clear()
                    if hasattr(self,"_spot_cast_rows") and hasattr(self._spot_cast_rows,"clear"):self._spot_cast_rows.clear()
                    self._spot_update_header_settled(self.grid_items[self.index])
                    self._spot_settle()
            except Exception:pass
            try:
                if hasattr(self,"_cin_leave_cache_exclusive"):
                    self._cin_leave_cache_exclusive()
            except Exception:pass
            return
        total=int(result.get("total",0) or 0)
        pm=int(result.get("poster_missing",0) or 0);bm=int(result.get("backdrop_missing",0) or 0)
        pr=int(result.get("poster_recovered",0) or 0);br=int(result.get("backdrop_recovered",0) or 0)
        pf=int(result.get("poster_failed",0) or 0);bf=int(result.get("backdrop_failed",0) or 0)
        bu=int(result.get("backdrop_upgraded",0) or 0)
        if not pm and not bm:
            # release: report only physically verified poster/backdrop components.
            # "fully cached" was misleading when Details later rejected a
            # canonical identity handoff and therefore could not present it.
            text=_("Artwork check • posters %d/%d • backdrops %d/%d • 0 missing")%(total,total,total,total)
            self["status"].setText(text)
        else:
            self["status"].setText(_("Artwork cache • posters %d/%d (left %d) • backdrops %d/%d (left %d)")%(pr,pm,pf,br,bm,bf))
        try:
            pt=int(result.get("presentation_total",0) or 0);prdy=int(result.get("presentation_ready",0) or 0)
            if pt:
                left=max(0,pt-prdy)
                suffix=_(" • display-ready %d/%d")%(prdy,pt)
                self["status"].setText(str(self["status"].getText() or "")+suffix)
        except Exception as exc:optional_failure("ui.check_artwork_display_ready_status",exc)
        us_clear(self._page_prefetch_seen)
        try:self._poll_visible_poster_cache_staged()
        except Exception as exc:optional_failure("ui.check_artwork_repaint",exc)

    def _drain_folder_artwork_progress(self):
        raw_events=[]
        while True:
            try:raw_events.append(self._folder_artwork_progress.get_nowait())
            except Exception:break
        if not raw_events:
            return
        progress_events=[]
        complete_event=None
        for ev in raw_events:
            if isinstance(ev,tuple) and len(ev)==2 and ev[0]=="__complete__":
                complete_event=ev
            else:
                progress_events.append(ev)
        deduped=[]
        for ev in progress_events:
            cur_done=None
            if isinstance(ev,tuple) and len(ev)==2 and ev[0]=="__page_backdrop_progress__" and isinstance(ev[1],dict):
                cur_done=int(ev[1].get("done",0) or 0)
            elif isinstance(ev,tuple) and len(ev)==2:
                try:cur_done=int(ev[0] or 0)
                except Exception:cur_done=None
            if deduped and cur_done is not None:
                prev=deduped[-1]
                prev_done=None
                if isinstance(prev,tuple) and len(prev)==2 and prev[0]=="__page_backdrop_progress__" and isinstance(prev[1],dict):
                    prev_done=int(prev[1].get("done",0) or 0)
                elif isinstance(prev,tuple) and len(prev)==2:
                    try:prev_done=int(prev[0] or 0)
                    except Exception:prev_done=None
                if prev_done==cur_done:
                    deduped[-1]=ev
                    continue
            deduped.append(ev)
        if deduped:
            step=1 if len(deduped)<=1 else max(2 if len(deduped)>4 else 1,(len(deduped)+4)//5)
            event=deduped[step-1]
            remaining=deduped[step:]
            for rem in remaining:
                try:self._folder_artwork_progress.put(rem)
                except Exception:pass
            if complete_event is not None:
                try:self._folder_artwork_progress.put(complete_event)
                except Exception:pass
            if isinstance(event,tuple) and len(event)==2 and event[0]=="__page_backdrop_progress__":
                info=event[1] if isinstance(event[1],dict) else {}
                done=int(info.get("done",0) or 0);total=int(info.get("total",0) or 0)
                cached=int(info.get("cached",0) or 0);downloaded=int(info.get("downloaded",0) or 0);failed=int(info.get("failed",0) or 0)
                self._folder_artwork_cache_done=done;self._folder_artwork_cache_total=total
                if self._folder_artwork_cache_running and total:
                    try:self["status"].setText(_("%s • %d/%d • new %d • already %d • failed %d")%(str(info.get("cache_label") or _("Backdrop cache")),done,total,downloaded,cached,failed))
                    except Exception:pass
                    try:
                        self["blue"].setText("%d / %d"%(done,total))
                        if self["blue"].instance is not None:self["blue"].instance.setFont(gFont("Regular",22))
                    except Exception:pass
            else:
                try:
                    done,total=event
                    self._folder_artwork_cache_done=int(done or 0)
                    self._folder_artwork_cache_total=int(total or 0)
                    if self._folder_artwork_cache_running and total:
                        try:self["status"].setText(_("Caching %d / %d")%(done,total))
                        except Exception as exc:diagnostic_failure("ui.grid.failsoft.521",exc)
                        try:
                            self["blue"].setText("%d / %d"%(done,total))
                            if self["blue"].instance is not None:self["blue"].instance.setFont(gFont("Regular",22))
                        except Exception as exc:diagnostic_failure("ui.grid.failsoft.525",exc)
                except Exception:
                    pass
            try:
                self._async_set_poll_interval(45)
                if hasattr(self,"_cin_set_poll_interval"):
                    self._cin_set_poll_interval(45,force=True)
            except Exception:
                pass
            return
        if complete_event is not None:
            try:self._apply_folder_artwork_result(complete_event[1])
            except Exception as exc:optional_failure("ui.check_artwork_terminal",exc)

    def _blue_item_sig(self,item):
        """Stable category identity; never hash the entire mutable provider dict."""
        row=item if isinstance(item,dict) else {}
        mt=str(self.media_type or "")
        tmdb=row.get("_locked_tmdb_id") or row.get("_ultra_search_verified_tmdb_id")
        if not tmdb and (row.get("identity_verified") or row.get("identity_pointer_verified")):
            tmdb=row.get("tmdb_id")
        if tmdb:return "tmdb:%s:%s"%(mt,str(tmdb))
        provider_id=row.get("stream_id") or row.get("series_id") or row.get("movie_id") or row.get("id") or row.get("ch_id")
        title=us_casefold(_catalogue_title(row.get("name") or row.get("title") or "")).strip()
        year=str(row.get("year") or row.get("release_date") or row.get("first_air_date") or "")[:4]
        raw="%s|%s|%s|%s"%(mt,str(provider_id or ""),title,year)
        return hashlib.sha1(raw.encode("utf-8","ignore")).hexdigest()

    def _cache_folder_artwork_worker(self, rows, cancel_event=None):
        # Test110: one artwork engine only. Settings/maintenance uses the exact
        # same TMDB-first, missing-only rescue path as BLUE.
        return self._check_missing_posters_worker(rows,cancel_event)
from .wqhd_layout import responsive_font as _ultra_rfont, factors as _ultra_factors

def _ultra_osd_scale():
    return _ultra_factors()[1]
