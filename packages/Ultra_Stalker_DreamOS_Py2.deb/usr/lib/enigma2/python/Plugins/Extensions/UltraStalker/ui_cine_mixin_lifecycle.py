# -*- coding: utf-8 -*-
"""Resume, hidden start, cancellation, fast info/logo and stop.

Methods moved verbatim out of ``PremiumGlobalCinematicScreen`` (ui_cinematic_global.py); behaviour is unchanged.
This module is imported by ui_cinematic_global.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import int, us_clear
from .ui_cinematic_global import (
    _FAST_BACKDROP_META_EXECUTOR,
    optional_failure,
    threading,
)


class CineLifecycleMixin(object):
    """Resume, hidden start, cancellation, fast info/logo and stop."""

    def _grid_shown_resume(self):
        self._cin_hidden=False
        self._cin_cancel_background()
        # Child screens stop Cinematic's private heartbeat completely.  Resume
        # only when this screen is visible again, using the adaptive cadence.
        try:self._cin_set_poll_interval(120 if self._cin_poll_has_pending_work() else 0,force=True)
        except Exception:pass
        if getattr(self,"_screen_closed",False) or getattr(self,"_grid_closed",False):return
        from .manual_identity import changed_since_paint
        if changed_since_paint(self):
            from .ui_manual_match import refresh_grid
            self._grid_images_suspended=False;refresh_grid(self,True);return
        self._grid_images_suspended=False
        try:self._schedule_page_maintenance()
        except Exception as exc:optional_failure('ui.page_maintenance_resume',exc)
        # Restore the exact local visual first so BACK never waits on network or
        # artwork hydration. Selection repaint can then refresh text/chrome only.
        try:self._cin_restore_surfaces_after_child()
        except Exception as exc:optional_failure("cinematic.resume_surface_restore",exc)
        if self.grid_items:
            try:self._update_selection();self._apply_debounced_grid_focus()
            except Exception as exc:optional_failure("cinematic.resume",exc)

    def _cin_hidden_start(self):
        """Child screens are a quiet period, not an automatic cache worker.

        Older builds started hidden folder hydration here while Details was
        allocating its own surfaces. That competed for CPU/HDD and contributed to
        gAccel pressure. Explicit BLUE Cache Artwork remains the only folder-wide
        artwork job.
        """
        if self._screen_closed:return
        self._cin_hidden=True
        try:self._cin_poll.stop()
        except Exception:pass
        try:self._cin_fast_info_timer.stop()
        except Exception:pass
        try:
            timer=getattr(self,"_cin_fast_logo_timer",None)
            if timer is not None:timer.stop()
        except Exception:pass
        self._cin_cancel_fast_info();self._cin_cancel_focus(enqueue=False);self._cin_cancel_background()
        try:
            if self._cin_adaptive_cancel is not None:self._cin_adaptive_cancel.set()
        except Exception:pass
        try:
            if self._cin_visual_future is not None and not self._cin_visual_future.done():self._cin_visual_future.cancel()
        except Exception:pass
        self._cin_visual_future=None
        try:
            if self._cin_logo_cancel is not None:self._cin_logo_cancel.set()
        except Exception:pass
        # Hidden child screens cancel the in-flight logo but keep the dedicated
        # executor alive; BACK must be able to resolve the same title again.
        self._cin_logo_cancel=None;self._cin_logo_active_sig=""

    def _cin_cancel_background(self):
        ev=getattr(self,"_cin_background_cancel",None)
        if ev is not None:
            try:ev.set()
            except Exception:pass
        future=getattr(self,"_cin_background_future",None)
        if future is not None and not future.done():
            try:future.cancel()
            except Exception:pass
        self._cin_background_cancel=None
        self._cin_background_future=None

    def _cin_cancel_fast_info(self):
        ev=getattr(self,"_cin_fast_info_cancel",None)
        if ev is not None:
            try:ev.set()
            except Exception:pass
        future=getattr(self,"_cin_fast_info_future",None)
        if future is not None:
            try:
                if not future.done():future.cancel()
            except Exception:pass
        self._cin_fast_info_cancel=None;self._cin_fast_info_future=None;self._cin_fast_info_sig=""

    def _cin_arm_fast_logo(self):
        """Poster-Grid-3-speed title-logo lane for Cinematic only.

        Keep arrow/key-repeat cheap: every move merely restarts one 180 ms timer.
        Once focus is quiet, the existing shared title-logo authority handles HDD
        cache adoption / canonical resolution on its background executor.  No
        metadata timing is changed and stale jobs remain generation-cancelled by
        the existing Cinematic logo lifecycle.
        """
        if self._screen_closed or getattr(self,"_cin_cache_exclusive",False) or not self.grid_items:return
        timer=getattr(self,"_cin_fast_logo_timer",None)
        if timer is None:return
        try:timer.stop();timer.start(180,True)
        except Exception:self._cin_apply_fast_logo()

    def _cin_apply_fast_logo(self):
        if self._screen_closed or getattr(self,"_cin_cache_exclusive",False) or not self.grid_items:return
        try:
            item=self.grid_items[self.index]
            row=(getattr(self,"_cin_page_records",{}) or {}).get(int(self.index),{}) or {}
            self._cin_show_title_logo(item,row)
        except Exception as exc:optional_failure("cinematic.fast_title_logo",exc)

    def _cin_arm_fast_info(self):
        """Selected-title metadata lane, armed only after navigation settles.

        While the user is still moving, only the list focus changes. Metadata
        now settles at 360 ms; title-logo owns its independent 180 ms lane.
        """
        if self._screen_closed or getattr(self,"_cin_cache_exclusive",False) or not self.grid_items:return
        self._cin_cancel_fast_info()
        # R5.234: match the settled-focus cadence used by the fast poster views.
        # Metadata is still debounced, but no longer waits 650 ms behind artwork;
        # this lets Genre/Cast/Title Logo hydrate before Details is ever opened.
        try:self._cin_fast_info_timer.stop();self._cin_fast_info_timer.start(360,True)
        except Exception:self._cin_apply_fast_info()

    def _cin_apply_fast_info(self):
        if self._screen_closed or getattr(self,"_cin_cache_exclusive",False) or not self.grid_items:return
        item=self.grid_items[self.index]
        # R112: page preparation already indexed the current record off-thread.
        # Never fall back to an HDD/details lookup from an eTimer GUI callback.
        row=(getattr(self,"_cin_page_records",{}) or {}).get(int(self.index),{}) or {}
        # Cached Details data paints immediately. Missing fields keep the previous
        # title's text until the new authoritative snapshot arrives.
        try:self._cin_apply_record(item,row,allow_build=False,hold_missing=True)
        except TypeError:self._cin_apply_record(item,row,allow_build=False)
        except Exception as exc:optional_failure("cinematic.fast_info_paint",exc)
        try:
            from .details_authority import metadata_language_ready
            if metadata_language_ready(row,(self._grid_settings or {})):return
        except Exception:
            if row.get("_details_authority_ready"):return
        # Do not require a pre-existing TMDb id here. The metadata-only Details
        # Authority lane can resolve the selected catalogue identity itself, so
        # titles such as Grand Hotel populate outside Details without an enter/exit.
        sig=self._page_visual_key(item)
        if not sig:return
        ev=threading.Event();self._cin_fast_info_cancel=ev;self._cin_fast_info_sig=sig
        item_copy=dict(item);row_copy=dict(row);profile=self.profile;media_type=self.media_type;settings=dict(self._grid_settings or {});provider_client=self.client
        def worker():
            try:
                from .details_authority import resolve_metadata_fast
                resolved=resolve_metadata_fast(profile,media_type,item_copy,current=row_copy,cancel_event=ev,settings=settings,provider_client=provider_client) or row_copy
                if not ev.is_set():self._cin_jobs.put({"kind":"fast_info","sig":sig,"row":resolved})
            except Exception as exc:optional_failure("cinematic.fast_info_worker",exc)
        try:
            self._cin_fast_info_future=getattr(self,"_cin_fast_meta_executor",_FAST_BACKDROP_META_EXECUTOR).submit(worker,_task_key="cin-info:%x"%id(self),_replace_task_key=True)
            self._cin_kick_poll()
        except Exception as exc:
            self._cin_fast_info_cancel=None;self._cin_fast_info_future=None;self._cin_fast_info_sig=""
            optional_failure("cinematic.fast_info_submit",exc)

    def _cin_cancel_focus(self,enqueue=True):
        ev=getattr(self,"_cin_focus_cancel",None)
        if ev is not None:
            try:ev.set()
            except Exception:pass
        future=getattr(self,"_cin_focus_future",None)
        if future is not None and not future.done():
            try:future.cancel()
            except Exception:pass
        if enqueue and isinstance(getattr(self,"_cin_last_focus_item",None),dict):
            self._cin_enqueue_missed(self._cin_last_focus_item)
        self._cin_focus_cancel=None;self._cin_focus_future=None;self._cin_focus_sig=""

    def _cin_stop(self):
        # Stop and detach every native timer. Some Enigma2 images keep signal
        # callbacks alive after stop(), which can retain a closed screen.
        _timer_links=(
            ("_cin_page_nav_timer","_cin_page_nav_conn",self._cin_commit_page_nav),
            ("_cin_poll","_cin_poll_conn",self._cin_poll_hdd),
            ("_cin_nav_backdrop_timer","_cin_nav_backdrop_conn",self._cin_apply_debounced_backdrop),
            ("_cin_nav_adaptive_timer","_cin_nav_adaptive_conn",self._cin_apply_nav_adaptive_baseline),
            ("_cin_fast_info_timer","_cin_fast_info_conn",self._cin_apply_fast_info),
            ("_cin_fast_logo_timer","_cin_fast_logo_conn",self._cin_apply_fast_logo),
        )
        for timer_name,conn_name,callback in _timer_links:
            timer=getattr(self,timer_name,None);conn=getattr(self,conn_name,None)
            if timer is not None:
                try:timer.stop()
                except Exception:pass
            if conn is not None:
                try:conn.disconnect()
                except Exception:pass
            try:setattr(self,conn_name,None)
            except Exception:pass
            if timer is not None:
                try:
                    if callback in timer.callback:timer.callback.remove(callback)
                except Exception:pass
        for hook_name,callback in (("onLayoutFinish",self._cin_layout_ready),("onHide",self._cin_hidden_start)):
            try:
                hooks=getattr(self,hook_name,None)
                if hooks is not None and callback in hooks:hooks.remove(callback)
            except Exception:pass
        self._cin_page_nav_target=0;self._cin_page_nav_row=0
        try:self._fast_bd_cancel(clear_file=False)
        except Exception:pass
        try:self._fast_bd_fast_cleanup()
        except Exception:pass
        us_clear(self._fast_bd_meta_pending)
        self._cin_cancel_fast_info();self._cin_cancel_focus(enqueue=False);self._cin_cancel_background()
        try:
            if self._cin_logo_cancel is not None:self._cin_logo_cancel.set()
        except Exception:pass
        try:
            ex=getattr(self,"_cin_logo_executor",None)
            if ex is not None:ex.shutdown(wait=False,cancel_futures=True)
        except Exception:pass
        for name in ("cin_backdrop","cin_backdrop_stage","title_logo"):
            try:
                self[name].hide()
                if self[name].instance is not None:self[name].instance.setPixmap(None)
            except Exception:pass
        us_clear(self._cin_pixmap_paths);us_clear(self._cin_widget_paths)
        us_clear(self._cin_pending);us_clear(self._cin_missed);us_clear(self._cin_missed_keys);us_clear(self._cin_logo_pending);self._cin_logo_path=""

    def _prefetch_visible_page_details(self, priority_index=None, max_items=None):
        # Hybrid Cinematic owns hydration itself. PremiumGridBase page warming is
        # deliberately disabled here so no hidden gridposter_1x1 or neighbour
        # TMDB jobs run while the user is navigating.
        return
