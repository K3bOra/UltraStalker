# -*- coding: utf-8 -*-
"""Search description and details.

Methods moved verbatim out of ``PortalGlobalSearchScreen`` (ui_screens_search.py); behaviour is unchanged.
This module is imported by ui_screens_search.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str
from .ui_screens_search import (
    _clean_display_text,
    _lbl_h,
    unicodedata,
)


class SearchDetailsMixin(object):
    """Search description and details."""

    def _search_set_description(self, desc):
        """Exact Favorites six-line summary style with direction-aware alignment."""
        text = _clean_display_text(str(desc or "").replace("\n", " "), 0)
        self._set_label_if_changed(self["sd_desc"], text)
        try:
            rtl = next((unicodedata.bidirectional(ch) in ("R", "AL") for ch in text
                        if unicodedata.bidirectional(ch) in ("L", "R", "AL")), False)
            inst = self["sd_desc"].instance
            if inst is not None:
                inst.setHAlign(_lbl_h("right") if rtl else _lbl_h("left"))
        except Exception as exc:
            optional_failure("ui.search_description_align", exc)
        (self["sd_desc"].show() if text else self["sd_desc"].hide())

    def _apply_search_details(self, item, allow_disk=True):
        _t, _m, _d = self._search_details_for(item, allow_disk)
        self._set_label_if_changed(self["sd_title"], _t);self["sd_title"].show()
        self._set_label_if_changed(self["sd_meta"], _m)
        (self["sd_meta"].show() if _m else self["sd_meta"].hide())
        self._search_set_description(_d)

    def _search_details_deferred(self):
        # Debounced (150 ms after the last render) disk lookup for the focused
        # row; _render() clears _sd_pending_item when the selection changes.
        item = self._sd_pending_item
        self._sd_pending_item = None
        if item is None:return
        try:self._apply_search_details(item, True)
        except Exception as exc:optional_failure("ui.search_details", exc)
