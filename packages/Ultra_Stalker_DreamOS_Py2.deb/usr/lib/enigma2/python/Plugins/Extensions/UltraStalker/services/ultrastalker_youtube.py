# -*- coding: utf-8 -*-
"""UltraStalker native YouTube trailer resolver (1080p Full HD primary with 720p HD fallback)."""
from __future__ import absolute_import, division, print_function, unicode_literals
import os
import ssl
import time
import zlib
from contextlib import closing

try:
    from .. import us_env as _us_env
    from ..us_env import bytes, int, max, min, str
    json = _us_env.json
    re = _us_env.re
    threading = _us_env.threading
    urllib = _us_env.urllib
except ImportError:
    import json
    import re
    import threading
    import urllib.parse
    import urllib.request
    import urllib.error

_SUBURI = "&suburi="
_ANDROID_VERSION = "21.08.266"
_ANDROID_UA = "com.google.android.youtube/%s (Linux; U; Android 11) gzip" % _ANDROID_VERSION
_ANDROID_NEW_VERSION = "21.26.364"
_ANDROID_NEW_UA = "com.google.android.youtube/%s (Linux; U; Android 11) gzip" % _ANDROID_NEW_VERSION
_VISIONOS_VERSION = "1.02"
_VISIONOS_UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 15_7_3) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0 Safari/605.1.15"
_TVHTML5_VERSION = "7.20250319.10.00"
_TVHTML5_UA = "Mozilla/5.0 (PlayStation; PlayStation 4/12.00) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.0 Safari/605.1.15"
_IOS_VERSION = "21.26.4"
_IOS_UA = "com.google.ios.youtube/%s (iPhone16,2; U; CPU iOS 18_3_2 like Mac OS X;)" % _IOS_VERSION
_WEB_EMBED_VERSION = "1.20241201.00.00"
_TV_EMBED_VERSION = "2.0"
_WEB_UA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/124.0 Safari/537.36"
_PLAYER_ENDPOINT = "https://www.youtube.com/youtubei/v1/player?prettyPrint=false"

_SSL_CONTEXT = ssl.create_default_context()

_CACHE_LOCK = threading.Lock()
_CANDIDATE_CACHE = {}
_CANDIDATE_CACHE_TTL = 900.0


# Primary target resolution is 1080p Full HD (1920x1080, tier 0) with immediate
# fallback to 720p HD (1280x720, tier 1) -> 480p -> 360p -> lower.
_ITAG_TIER = {
    # 1080p Full HD (tier 0)
    "37": (0, 0),   # 1080p progressive muxed MP4
    "96": (0, 1),   # 1080p HLS muxed TS
    "301": (0, 2),  # 1080p60 HLS muxed TS
    "137": (0, 3),  # 1080p DASH H.264 MP4 video
    "299": (0, 4),  # 1080p60 DASH H.264 MP4 video
    "270": (0, 5),  # 1080p DASH/HLS H.264 video
    # 720p HD (tier 1 - immediate fallback)
    "22": (1, 0),   # 720p progressive muxed MP4
    "95": (1, 1),   # 720p HLS muxed TS
    "300": (1, 2),  # 720p60 HLS muxed TS
    "136": (1, 3),  # 720p DASH H.264 MP4 video
    "298": (1, 4),  # 720p60 DASH H.264 MP4 video
    "232": (1, 5),  # 720p HLS H.264 video
    # 480p (tier 2)
    "35": (2, 0),
    "59": (2, 1),
    "78": (2, 2),
    "94": (2, 3),   # 480p HLS
    "135": (2, 4),  # 480p DASH H.264 MP4 video
    "212": (2, 5),  # 480p DASH H.264 MP4 video
    "231": (2, 6),  # 480p HLS H.264 video
    # 360p (tier 3)
    "18": (3, 0),   # 360p progressive muxed MP4
    "93": (3, 1),   # 360p HLS
    "34": (3, 2),
    "6": (3, 3),
    "134": (3, 4),  # 360p DASH H.264 MP4 video
    "230": (3, 5),  # 360p HLS H.264 video
    # 240p (tier 4)
    "5": (4, 0),
    "36": (4, 1),
    "92": (4, 2),
    "132": (4, 3),
    "133": (4, 4),  # 240p DASH H.264 MP4 video
    "229": (4, 5),
    # 144p (tier 5)
    "17": (5, 0),
    "91": (5, 1),
    "13": (5, 2),
    "151": (5, 3),
    "160": (5, 4),  # 144p DASH H.264 MP4 video
    "269": (5, 5),
}

_VIDEO_ORDER = (
    "37", "96", "301", "137", "299", "270",
    "22", "95", "300", "136", "298", "232",
    "35", "59", "78", "94", "135", "212", "231",
    "18", "93", "34", "6", "134", "230",
    "5", "36", "92", "132", "133", "229",
    "17", "91", "13", "151", "160", "269",
)
_AUDIO_ORDER = ("141", "140", "139", "258", "265", "325", "328", "233", "234")
_SPLIT_VIDEO = {
    "133", "134", "135", "136", "137", "138", "160", "212", "229", "230",
    "231", "232", "248", "264", "271", "272", "266", "269", "270", "298",
    "299", "303", "313", "315", "308",
}
_BLOCKED = {
    # Block >1080p (1440p/4K) and VP8/VP9/AV1/WebM/3D formats
    "38", "138", "264", "266",
    "43", "44", "45", "46",
    "82", "83", "84", "85",
    "100", "101", "102",
    "167", "168", "169", "170", "171", "172",
    "218", "219",
    "242", "243", "244", "245", "246", "247", "248",
    "249", "250", "251",
    "271", "272", "302", "303", "308", "313", "315",
    "394", "395", "396", "397", "398", "399", "400", "401", "402",
    "571", "694", "695", "696", "697", "698", "699", "700", "701",
}


def _http_text(url, data=None, headers=None, timeout=5, limit=6 * 1024 * 1024):
    if data is not None and not isinstance(data, (bytes, bytearray)):
        data = json.dumps(data, separators=(",", ":")).encode("utf-8")
    req_timeout = max(2.5, min(6.0, float(timeout or 5)))
    req_headers = dict(headers or {})
    req_headers.setdefault("Accept-Encoding", "gzip")
    req = urllib.request.Request(url, data=data, headers=req_headers)
    with closing(urllib.request.urlopen(req, timeout=req_timeout, context=_SSL_CONTEXT)) as response:
        raw = response.read(limit + 1)
    if len(raw) > limit:
        raise RuntimeError("response too large")
    if raw[:2] == b"\x1f\x8b":
        raw = zlib.decompressobj(16 + zlib.MAX_WBITS).decompress(raw, limit + 1)
        if len(raw) > limit:
            raise RuntimeError("response too large")
    return raw.decode("utf-8", "replace")


def _http_json(url, payload, headers, timeout):
    text = _http_text(url, payload, headers, timeout=timeout)
    value = json.loads(text)
    return value if isinstance(value, dict) else {}


def _probe_media_url(url, ua=None, timeout=3.0):
    return bool(str(url or "").strip().startswith(("http://", "https://")))


def _balanced_body(source, open_pos):
    """Return text inside a JS brace block using a small string-aware scanner."""
    if open_pos < 0 or open_pos >= len(source) or source[open_pos] != "{":
        return ""
    depth = 0
    quote = None
    escaped = False
    start = open_pos + 1
    limit = min(len(source), open_pos + 65536)
    for idx in range(open_pos, limit):
        ch = source[idx]
        if quote is not None:
            if escaped:
                escaped = False
            elif ch == "\\":
                escaped = True
            elif ch == quote:
                quote = None
            continue
        if ch in ("'", '"', "`"):
            quote = ch
        elif ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0:
                return source[start:idx]
    return ""


def _fetch_watch_html(video_id, timeout=5):
    watch_url = "https://www.youtube.com/watch?v=%s&bpctr=9999999999&has_verified=1" % urllib.parse.quote(str(video_id))
    headers = {
        "User-Agent": _WEB_UA,
        "Accept-Language": "en-US,en;q=0.9",
    }
    return _http_text(watch_url, headers=headers, timeout=timeout)


def _extract_visitor_id(html):
    if not html:
        return ""
    match = re.search(r'"visitorData"\s*:\s*"([^"]+)"', html)
    if match:
        return str(match.group(1)).strip()
    match = re.search(r"ytcfg\.set\s*\(\s*(\{.+?\})\s*\)\s*;", html)
    if match:
        try:
            cfg = json.loads(match.group(1))
            vis = (((cfg.get("INNERTUBE_CONTEXT") or {}).get("client") or {}).get("visitorData") or "")
            if vis:
                return str(vis).strip()
        except Exception:
            pass
    return ""


def _player_script_from_html(html, timeout=5):
    if not html:
        return ""
    match = re.search(r'"jsUrl"\s*:\s*"([^"]+base\.js)"', html)
    if not match:
        match = re.search(r'src="([^"]+base\.js)"', html)
    if not match:
        return ""
    js_url = match.group(1).replace("\\/", "/")
    if js_url.startswith("//"):
        js_url = "https:" + js_url
    elif js_url.startswith("/"):
        js_url = "https://www.youtube.com" + js_url
    headers = {
        "User-Agent": _WEB_UA,
        "Accept-Language": "en-US,en;q=0.9",
    }
    return _http_text(js_url, headers=headers, timeout=timeout, limit=12 * 1024 * 1024)


def _player_script(video_id, timeout=5):
    html = _fetch_watch_html(video_id, timeout=timeout)
    return _player_script_from_html(html, timeout=timeout)


def _extract_sts(html, js):
    for text in (html or "", js or ""):
        if not text:
            continue
        match = re.search(r'(?:signatureTimestamp|sts|"STS")\s*:\s*(\d{5})', text)
        if match:
            try:
                return int(match.group(1))
            except Exception:
                pass
    return None


def _find_object_body(js, obj_name):
    escaped = re.escape(obj_name)
    for pattern in (
        r"(?:var|let|const)\s+" + escaped + r"\s*=\s*\{",
        r"[,;\s]" + escaped + r"\s*=\s*\{",
    ):
        match = re.search(pattern, js)
        if match:
            brace = js.find("{", match.start(), match.end())
            body = _balanced_body(js, brace)
            if body:
                return body
    return ""


def _parse_helper_methods(body):
    methods = {}
    cursor = 0
    pattern = re.compile(r"([A-Za-z0-9_$]+)\s*:\s*function\s*\([^)]*\)\s*\{")
    while True:
        match = pattern.search(body, cursor)
        if not match:
            break
        name = match.group(1)
        brace = body.find("{", match.start(), match.end())
        fn_body = _balanced_body(body, brace)
        cursor = brace + len(fn_body) + 2
        if "reverse" in fn_body:
            methods[name] = "reverse"
        elif "splice" in fn_body:
            methods[name] = "splice"
        elif "%" in fn_body and ".length" in fn_body:
            methods[name] = "swap"
    return methods


def _signature_plan(js):
    """Extract a list of (operation, arg) steps from YouTube player JS."""
    candidates = (
        r'\b[cs]\s*&&\s*[adf]\.set\([^,]+,\s*encodeURIComponent\(([A-Za-z0-9_$]+)\(',
        r'\b[a-zA-Z0-9]+\s*&&\s*[a-zA-Z0-9]+\.set\([^,]+,\s*encodeURIComponent\(([A-Za-z0-9_$]+)\(',
        r'(?:\b|[^a-zA-Z0-9_$])([A-Za-z0-9_$]{2,})\s*=\s*function\(\s*a\s*\)\s*\{\s*a\s*=\s*a\.split\(\s*""\s*\)',
    )
    fn_names = []
    for pattern in candidates:
        for match in re.finditer(pattern, js):
            name = match.group(1)
            if name and name not in fn_names:
                fn_names.append(name)
    for fn_name in fn_names:
        escaped = re.escape(fn_name)
        for fn_pat in (
            escaped + r"\s*=\s*function\(\s*[A-Za-z0-9_$]+\s*\)\s*\{",
            r"function\s+" + escaped + r"\(\s*[A-Za-z0-9_$]+\s*\)\s*\{",
        ):
            match = re.search(fn_pat, js)
            if not match:
                continue
            brace = js.find("{", match.start(), match.end())
            fn_body = _balanced_body(js, brace)
            if ".split(" not in fn_body or ".join(" not in fn_body:
                continue
            calls = re.findall(r"([A-Za-z0-9_$]+)\.([A-Za-z0-9_$]+)\(\s*[A-Za-z0-9_$]+\s*,\s*(\d+)\s*\)", fn_body)
            if not calls:
                continue
            helper_body = _find_object_body(js, calls[0][0])
            methods = _parse_helper_methods(helper_body)
            steps = []
            for _obj, method, arg in calls:
                if method in methods:
                    steps.append((methods[method], int(arg)))
            if steps:
                return steps
    return []


def _apply_signature(sig, plan):
    chars = list(str(sig or ""))
    if not chars or not plan:
        return ""
    for kind, number in plan:
        if kind == "reverse":
            chars.reverse()
        elif kind == "splice":
            del chars[:max(0, number)]
        elif kind == "slice":
            chars = chars[max(0, number):]
        elif kind == "swap":
            index = number % len(chars)
            chars[0], chars[index] = chars[index], chars[0]
    return "".join(chars)


def _skip_format(row, itag):
    if not isinstance(row, dict):
        return True
    if row.get("targetDurationSec") or row.get("drmFamilies"):
        return True
    if str(row.get("type") or "") == "FORMAT_STREAM_TYPE_OTF":
        return True
    if str(itag or "") in _BLOCKED:
        return True
    mime = str(row.get("mimeType") or "").lower()
    if any(bad in mime for bad in ("vp9", "vp09", "vp8", "av01", "av1", "webm", "opus", "vorbis")):
        return True
    height = int(row.get("height") or 0)
    if height > 1080:
        return True
    return False


def _tier_for_row(row, itag):
    itag_s = str(itag or "")
    if itag_s in _ITAG_TIER:
        return _ITAG_TIER[itag_s]
    height = int((row or {}).get("height") or 0)
    if 720 < height <= 1080:
        return (0, 9)
    if 480 < height <= 720:
        return (1, 9)
    if 360 < height <= 480:
        return (2, 9)
    if 240 < height <= 360:
        return (3, 9)
    if 144 < height <= 240:
        return (4, 9)
    if 0 < height <= 144:
        return (5, 9)
    return (9, 9)


class UltraYouTubeResolver(object):
    def __init__(self):
        self._html = ""
        self._js = ""
        self._visitor_id = ""
        self._sts = None
        self._sig_plan = None

    def _ensure_web_context(self, video_id, timeout, need_js=False):
        if not self._html:
            try:
                self._html = _fetch_watch_html(video_id, timeout=min(5, timeout))
            except Exception:
                self._html = ""
            if self._html:
                vis = _extract_visitor_id(self._html)
                if vis:
                    self._visitor_id = vis
                self._sts = _extract_sts(self._html, "")
        if need_js and not self._js and self._html:
            try:
                self._js = _player_script_from_html(self._html, timeout=min(5, timeout))
            except Exception:
                self._js = ""
            if self._js and self._sts is None:
                self._sts = _extract_sts(self._html, self._js)

    def _build_client_request(self, client_id, video_id, visitor_id="", sts=None):
        content_ctx = {"html5Preference": "HTML5_PREF_WANTS"}
        if sts is not None and client_id in (7, 56, 85):
            content_ctx["signatureTimestamp"] = int(sts)

        real_client_id = 3 if client_id in (3, 30, 3003) else (101 if client_id == 101 else client_id)
        body = {
            "videoId": video_id,
            "playbackContext": {"contentPlaybackContext": content_ctx},
            "context": {"client": {"hl": "en", "gl": "US"}},
        }
        headers = {
            "Content-Type": "application/json",
            "Origin": "https://www.youtube.com",
            "X-YouTube-Client-Name": str(real_client_id),
        }

        if client_id in (3, 3003):
            # Primary fast path matching Taapat/fairbird enigma2-plugin-youtube:
            # ANDROID 21.08.266 with params="2AMB" returns direct unencrypted 1080p (itag 137/299)
            # + 720p (itag 136/298) + M4A audio (itag 140) + progressive MP4 in one ~200ms request.
            ua = _ANDROID_UA
            body["params"] = "2AMB"
            body["context"]["client"].update({
                "clientName": "ANDROID",
                "clientVersion": _ANDROID_VERSION,
                "androidSdkVersion": 30,
                "osName": "Android",
                "osVersion": "11",
                "userAgent": ua,
            })
            headers["X-YouTube-Client-Version"] = _ANDROID_VERSION
            headers["User-Agent"] = ua
            if visitor_id:
                headers["X-Goog-Visitor-Id"] = visitor_id
        elif client_id == 30:
            # ANDROID without "2AMB" to ensure full adaptiveFormats (1080p itag 137 / 720p itag 136)
            ua = _ANDROID_NEW_UA
            body["context"]["client"].update({
                "clientName": "ANDROID",
                "clientVersion": _ANDROID_NEW_VERSION,
                "androidSdkVersion": 30,
                "osName": "Android",
                "osVersion": "11",
                "userAgent": ua,
            })
            headers["X-YouTube-Client-Version"] = _ANDROID_NEW_VERSION
            headers["User-Agent"] = ua
            if visitor_id:
                headers["X-Goog-Visitor-Id"] = visitor_id
        elif client_id == 101:
            # VISIONOS (yt-dlp #17184 / youtube-dl #33293): returns unencrypted 1080p/720p DASH + HLS m3u8 without PO token
            ua = _VISIONOS_UA
            body["context"]["client"].update({
                "clientName": "VISIONOS",
                "clientVersion": _VISIONOS_VERSION,
                "deviceMake": "Apple",
                "deviceModel": "RealityDevice17,1",
                "osName": "visionOS",
                "osVersion": "26.5.230471",
                "userAgent": ua,
            })
            headers["X-YouTube-Client-Name"] = "101"
            headers["X-YouTube-Client-Version"] = _VISIONOS_VERSION
            headers["User-Agent"] = ua
            if visitor_id:
                headers["X-Goog-Visitor-Id"] = visitor_id
        elif client_id == 5:
            ua = _IOS_UA
            body["context"]["client"].update({
                "clientName": "IOS",
                "clientVersion": _IOS_VERSION,
                "deviceMake": "Apple",
                "deviceModel": "iPhone16,2",
                "osName": "iPhone",
                "osVersion": "18.3.2.22D82",
                "userAgent": ua,
            })
            headers["X-YouTube-Client-Version"] = _IOS_VERSION
            headers["User-Agent"] = ua
            if visitor_id:
                headers["X-Goog-Visitor-Id"] = visitor_id
        elif client_id == 7:
            ua = _TVHTML5_UA
            body["context"]["client"].update({
                "clientName": "TVHTML5",
                "clientVersion": _TVHTML5_VERSION,
                "userAgent": ua,
            })
            headers["X-YouTube-Client-Version"] = _TVHTML5_VERSION
            headers["User-Agent"] = ua
            if visitor_id:
                headers["X-Goog-Visitor-Id"] = visitor_id
        elif client_id == 56:
            ua = _WEB_UA
            body["context"]["client"].update({
                "clientName": "WEB_EMBEDDED_PLAYER",
                "clientVersion": _WEB_EMBED_VERSION,
            })
            headers["X-YouTube-Client-Version"] = _WEB_EMBED_VERSION
            headers["User-Agent"] = ua
        else:
            ua = _WEB_UA
            body["context"]["client"].update({
                "clientName": "TVHTML5_SIMPLY_EMBEDDED_PLAYER",
                "clientVersion": _TV_EMBED_VERSION,
            })
            body["context"]["thirdParty"] = {"embedUrl": "https://www.youtube.com/"}
            headers["X-YouTube-Client-Version"] = _TV_EMBED_VERSION
            headers["User-Agent"] = ua

        return ua, body, headers

    def _decipher(self, video_id, encrypted, timeout):
        if not encrypted:
            return ""
        self._ensure_web_context(video_id, timeout, need_js=True)
        if not self._js:
            try:
                self._js = _player_script(video_id, timeout=min(5, timeout))
            except Exception:
                self._js = ""
        if not self._js:
            return ""
        if self._sig_plan is None:
            self._sig_plan = _signature_plan(self._js)
        if not self._sig_plan:
            return ""
        return _apply_signature(encrypted, self._sig_plan)

    def _stream_url(self, video_id, row, timeout, allow_cipher=False):
        if not isinstance(row, dict):
            return ""
        direct = str(row.get("url") or "").strip()
        if direct.startswith(("http://", "https://")):
            return direct
        cipher = str(row.get("signatureCipher") or row.get("cipher") or "").strip()
        if not cipher:
            return ""
        data = urllib.parse.parse_qs(cipher, keep_blank_values=True)
        base = str((data.get("url") or [""])[0] or "").strip()
        if not base.startswith(("http://", "https://")):
            return ""
        ready = str((data.get("sig") or data.get("signature") or [""])[0] or "").strip()
        if not ready and allow_cipher:
            encrypted = str((data.get("s") or [""])[0] or "").strip()
            ready = self._decipher(video_id, encrypted, timeout)
        if ready:
            key = str((data.get("sp") or ["signature"])[0] or "signature")
            sep = "&" if "?" in base else "?"
            return base + sep + urllib.parse.urlencode({key: ready})
        return ""

    @staticmethod
    def _rank(itag, order):
        try:
            return order.index(str(itag))
        except ValueError:
            return 100

    def _video_candidates(self, video_id, rows, timeout, allow_cipher=False):
        choices = []
        for row in rows:
            if not isinstance(row, dict):
                continue
            itag = str(row.get("itag") or "")
            if _skip_format(row, itag):
                continue
            tier, subrank = _tier_for_row(row, itag)
            if tier > 5:
                mime = str(row.get("mimeType") or "").lower()
                height = int(row.get("height") or 0)
                if "video/mp4" in mime and 0 < height <= 1080:
                    tier = 0 if height > 720 else (1 if height > 480 else (2 if height > 360 else (3 if height > 240 else 4)))
                    subrank = 8
                else:
                    continue
            url = self._stream_url(video_id, row, timeout, allow_cipher=allow_cipher)
            if url:
                is_split = (itag in _SPLIT_VIDEO) or (
                    "audio" not in str(row.get("mimeType") or "").lower()
                    and itag not in ("18", "22", "37", "34", "35", "36", "17", "5", "6", "59", "78", "91", "92", "93", "94", "95", "96", "300", "301")
                )
                choices.append((tier, subrank, is_split, row, url))
        choices.sort(key=lambda item: (item[0], item[1]))
        return choices

    def _audio_candidates(self, video_id, rows, timeout, allow_cipher=False):
        choices = []
        for row in rows:
            if not isinstance(row, dict):
                continue
            itag = str(row.get("itag") or "")
            if _skip_format(row, itag):
                continue
            rank = self._rank(itag, _AUDIO_ORDER)
            audio_track = row.get("audioTrack") if isinstance(row.get("audioTrack"), dict) else {}
            disp = str(audio_track.get("displayName") or "").lower()
            if "original" in disp:
                rank -= 40
            if audio_track.get("audioIsDefault"):
                rank -= 20
            if rank == 100:
                mime = str(row.get("mimeType") or "").lower()
                rank = 20 if "audio/mp4" in mime else 200
            if rank >= 200:
                continue
            url = self._stream_url(video_id, row, timeout, allow_cipher=allow_cipher)
            if url:
                choices.append((rank, url))
        choices.sort(key=lambda item: item[0])
        return [item[1] for item in choices]

    def _hls_tiered_candidates(self, manifest_url, timeout, ua=None):
        """Return list of (tier, subrank, is_split, url) from HLS master manifest (<=1080p only)."""
        if not str(manifest_url or "").startswith(("http://", "https://")):
            return []
        text = _http_text(manifest_url, headers={"User-Agent": str(ua or _VISIONOS_UA)}, timeout=min(4, timeout), limit=2 * 1024 * 1024)
        audio_by_group = {}
        pending_audio = ""
        pending_height = 0
        candidates = []
        for line in text.splitlines():
            line = line.strip()
            if line.startswith("#EXT-X-MEDIA:") and "TYPE=AUDIO" in line.upper():
                group = re.search(r'GROUP-ID="([^"]+)"', line)
                uri = re.search(r'URI="([^"]+)"', line)
                if group and uri:
                    abs_audio = urllib.parse.urljoin(manifest_url, uri.group(1))
                    if group.group(1) not in audio_by_group or 'DEFAULT=YES' in line.upper():
                        audio_by_group[group.group(1)] = abs_audio
                continue
            if line.startswith("#EXT-X-STREAM-INF:"):
                if any(bad in line.lower() for bad in ("vp09", "vp9", "av01")):
                    pending_height = 9999
                else:
                    res = re.search(r"RESOLUTION=\d+x(\d+)", line)
                    pending_height = int(res.group(1)) if res else 0
                group = re.search(r'AUDIO="([^"]+)"', line)
                pending_audio = audio_by_group.get(group.group(1), "") if group else ""
                candidates.append((line, pending_audio, pending_height, ""))
                continue
            if candidates and line and not line.startswith("#") and not candidates[-1][3]:
                tag = re.search(r"(?:/sgovp/[^/]+itag%3D|/itag/|itag%3D)(\d+)", line)
                itag = tag.group(1) if tag else ""
                info, audio, h_val, _ = candidates[-1]
                candidates[-1] = (info, audio, h_val, urllib.parse.urljoin(manifest_url, line) + ("|" + itag if itag else ""))
        out = []
        for _info, audio, h_val, packed in candidates:
            if not packed or h_val > 1080:
                continue
            if "|" in packed:
                url, itag = packed.rsplit("|", 1)
            else:
                url, itag = packed, ""
            if itag in _BLOCKED:
                continue
            tier, subrank = _tier_for_row({"height": h_val}, itag)
            if tier > 5:
                continue
            if not audio:
                out.append((tier, subrank, False, url))
            else:
                out.append((tier, subrank + 3, True, url + _SUBURI + audio))
        out.sort(key=lambda item: (item[0], item[1]))
        return out

    def _collect_from_payload(self, key, payload, client_ua, timeout, stopped, seen, tier_buckets, muxed_buckets, split_buckets, allow_cipher=False):
        if not isinstance(payload, dict):
            return False
        vis = str(((payload.get("responseContext") or {}).get("visitorData") if isinstance(payload.get("responseContext"), dict) else "") or "").strip()
        if vis and not self._visitor_id:
            self._visitor_id = vis
        play_status = str(((payload.get("playabilityStatus") if isinstance(payload.get("playabilityStatus"), dict) else {}) or {}).get("status") or "")
        if play_status and play_status != "OK":
            return False
        vdetails = payload.get("videoDetails") if isinstance(payload.get("videoDetails"), dict) else {}
        ret_id = str(vdetails.get("videoId") or "").strip()
        if ret_id and ret_id != key:
            return False
        streaming = payload.get("streamingData") if isinstance(payload.get("streamingData"), dict) else {}
        if not streaming:
            return False
        is_live = bool(vdetails.get("isLive"))
        rows = [row for row in (streaming.get("formats") or []) if isinstance(row, dict)]
        if not is_live:
            rows.extend([row for row in (streaming.get("adaptiveFormats") or []) if isinstance(row, dict)])

        video_choices = self._video_candidates(key, rows, timeout, allow_cipher=allow_cipher)
        audio_choices = self._audio_candidates(key, rows, timeout, allow_cipher=allow_cipher) if not is_live else []
        best_audio = audio_choices[0] if audio_choices else ""

        added_any = False

        for tier, subrank, is_split, _row, video_url in video_choices:
            if is_split:
                if not best_audio or tier in split_buckets:
                    continue
                full_url = video_url + _SUBURI + best_audio
                split_buckets[tier] = (subrank, full_url)
            else:
                if tier in muxed_buckets:
                    continue
                full_url = video_url
                muxed_buckets[tier] = (subrank, full_url)
            if full_url not in seen:
                seen.add(full_url)
                tier_buckets.setdefault(tier, []).append((subrank, is_split, full_url))
                added_any = True

        hls = str(streaming.get("hlsManifestUrl") or "").strip()
        if hls and not stopped() and (0 not in tier_buckets or 0 not in muxed_buckets):
            try:
                for tier, subrank, is_split, hls_url in self._hls_tiered_candidates(hls, timeout=min(4, timeout), ua=client_ua):
                    if is_split:
                        if tier in split_buckets:
                            continue
                        split_buckets[tier] = (subrank, hls_url)
                    else:
                        if tier in muxed_buckets:
                            continue
                        muxed_buckets[tier] = (subrank, hls_url)
                    if hls_url and hls_url not in seen:
                        seen.add(hls_url)
                        tier_buckets.setdefault(tier, []).append((subrank, is_split, hls_url))
                        added_any = True
            except Exception:
                pass
        return added_any

    def extract_candidates(self, video_id, timeout=8, cancel_event=None):
        """Return ordered 1080p-first (with 720p fallback) playable stream URLs."""
        key = str(video_id or "").strip()
        if not key:
            return []

        is_dreamos = bool(getattr(_us_env, "IS_DREAMOS", False)) if "_us_env" in globals() else False
        has_exteplayer3 = os.path.exists("/usr/bin/exteplayer3")
        cache_key = (key, is_dreamos, has_exteplayer3, "1080p")
        now = time.time()
        with _CACHE_LOCK:
            cached_entry = _CANDIDATE_CACHE.get(cache_key)
            if cached_entry and (now - cached_entry[0]) < _CANDIDATE_CACHE_TTL and cached_entry[1]:
                return list(cached_entry[1])

        seen = set()
        tier_buckets = {}
        muxed_buckets = {}
        split_buckets = {}

        def stopped():
            if cancel_event is not None:
                try:
                    return bool(cancel_event.is_set())
                except Exception:
                    return False
            return False

        req_timeout = max(3, min(5, int(timeout or 6)))

        # Phase 1: Fast direct non-cipher JSON clients (zero HTML fetch, zero 12MB base.js download)
        # 1. Client 3 (ANDROID 21.08.266 + params="2AMB") — exact Taapat/fairbird client:
        #    returns 1080p (itag 137/299) + 720p (itag 136/298) + M4A audio (itag 140) in one ~200ms request.
        # 2. Client 30 (ANDROID without 2AMB) & Client 101 (VISIONOS) — if HD adaptiveFormats weren't in cid 3.
        # 3. Client 5 (IOS) — fast fallback.
        fast_clients = (3, 30, 101, 5)
        for cid in fast_clients:
            if stopped():
                break
            ua, body, headers = self._build_client_request(cid, key, self._visitor_id, None)
            try:
                cand_payload = _http_json(_PLAYER_ENDPOINT, body, headers, timeout=req_timeout)
            except Exception:
                continue
            self._collect_from_payload(
                key, cand_payload, ua, req_timeout, stopped,
                seen, tier_buckets, muxed_buckets, split_buckets, allow_cipher=False
            )
            # Stop immediately once we have 1080p (tier 0) or adaptive HD (720p tier 1 when video maxes at 720p)!
            if 0 in tier_buckets or (1 in tier_buckets and split_buckets):
                break
            if tier_buckets and cid in (101, 5):
                break

        # Phase 2: Only if ALL fast direct clients returned zero streams (e.g. age-restricted video),
        # try embedded/TV fallback clients.
        if not tier_buckets and not stopped():
            for cid in (85, 7, 56):
                if stopped():
                    break
                self._ensure_web_context(key, req_timeout, need_js=True)
                ua, body, headers = self._build_client_request(cid, key, self._visitor_id, self._sts)
                try:
                    cand_payload = _http_json(_PLAYER_ENDPOINT, body, headers, timeout=req_timeout)
                except Exception:
                    continue
                self._collect_from_payload(
                    key, cand_payload, ua, req_timeout, stopped,
                    seen, tier_buckets, muxed_buckets, split_buckets, allow_cipher=True
                )
                if tier_buckets:
                    break

        results = []
        # Strict 1080p-first -> 720p-second ordering:
        # 1. Tier 0: 1080p Full HD (itag 37/96/301 muxed or itag 137/299 + &suburi= + itag 140)
        # 2. Tier 1: 720p HD immediate fallback (itag 22/95/300 muxed or itag 136/298 + &suburi= + itag 140)
        # 3. Tier 2: 480p
        # 4. Tier 3: 360p muxed (itag 18)
        for tier in sorted(tier_buckets.keys()):
            items = sorted(tier_buckets[tier], key=lambda x: x[0])
            for _subrank, _is_split, url in items:
                if url not in results:
                    results.append(url)

        results = results[:4]
        if results:
            with _CACHE_LOCK:
                if len(_CANDIDATE_CACHE) > 128:
                    _CANDIDATE_CACHE.clear()
                _CANDIDATE_CACHE[cache_key] = (now, list(results))
        return results

    def extract(self, video_id, timeout=8):
        cands = self.extract_candidates(video_id, timeout=timeout)
        return cands[0] if cands else ""
