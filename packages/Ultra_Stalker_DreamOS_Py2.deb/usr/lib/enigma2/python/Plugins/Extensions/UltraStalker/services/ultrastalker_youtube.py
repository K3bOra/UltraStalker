# -*- coding: utf-8 -*-
"""UltraStalker native YouTube trailer resolver."""
from __future__ import absolute_import, division, print_function, unicode_literals
from .. import us_env as _us_env
from ..us_env import bytes, int, list, max, min, object, range, str

json = _us_env.json
re = _us_env.re
threading = _us_env.threading
urllib = _us_env.urllib

_SUBURI = "&suburi="
_ANDROID_VERSION = "21.08.266"
_ANDROID_UA = "com.google.android.youtube/%s (Linux; U; Android 11) gzip" % _ANDROID_VERSION
_IOS_VERSION = "20.10.4"
_IOS_UA = "com.google.ios.youtube/%s (iPhone16,2; U; CPU iOS 18_3_2 like Mac OS X;)" % _IOS_VERSION
_VR_VERSION = "1.71.26"
_VR_UA = "com.google.android.apps.youtube.vr.oculus/%s (Linux; U; Android 12L; eureka-user Build/SQ3A.220605.009.A1) gzip" % _VR_VERSION
_TV_VERSION = "2.0"
_TV_UA = "Mozilla/5.0 (PlayStation; PlayStation 4/12.00) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.4 Safari/605.1.15"
_PLAYER_ENDPOINT = "https://www.youtube.com/youtubei/v1/player?prettyPrint=false"

# Strictly 1080p and 720p HD formats (prefer H.264/MP4 Full HD 1080p first, then
# 720p H.264/MP4, then VP9 1080p/720p). Never include 360p (itag 18) or 240p so
# trailers always play in crisp HD and never degrade to blurry 360p.
_VIDEO_ORDER = (
    "37", "96", "301", "137", "299", "270",
    "22", "95", "300", "136", "298", "232",
    "248", "303", "271",
)
_AUDIO_ORDER = ("141", "140", "139", "258", "265", "325", "328", "233", "234", "251", "250", "249")
_SPLIT_VIDEO = {
    "133", "134", "135", "136", "137", "138", "160", "212", "229", "230",
    "231", "232", "248", "264", "271", "272", "266", "269", "270", "298",
    "299", "303", "313", "315", "308",
}
_BLOCKED = {
    "18", "43", "44", "45", "46", "82", "83", "84", "85", "92", "93", "94",
    "100", "101", "102", "133", "134", "135",
    "167", "168", "169", "170", "171", "172", "218", "219", "242", "243",
    "244", "245", "246", "247", "302", "394", "395",
    "396", "397", "398", "399", "400", "401", "402", "571", "694", "695",
    "696", "697", "698", "699", "700", "701",
}


def _http_text(url, data=None, headers=None, timeout=8, limit=6 * 1024 * 1024):
    if data is not None and not isinstance(data, (bytes, bytearray)):
        data = json.dumps(data, separators=(",", ":")).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers=headers or {})
    with urllib.request.urlopen(req, timeout=max(4, int(timeout or 8))) as response:
        raw = response.read(limit + 1)
    if len(raw) > limit:
        raise RuntimeError("response too large")
    return raw.decode("utf-8", "replace")


def _http_json(url, payload, headers, timeout):
    text = _http_text(url, payload, headers, timeout=timeout)
    value = json.loads(text)
    return value if isinstance(value, dict) else {}


def _probe_media_url(url, ua=None, timeout=3.0):
    return bool(str(url or "").strip().startswith(("http://", "https://")))


def _balanced_body(source, open_pos):
    """Return text inside a JS brace block using a small string-aware scanner."""
    if open_pos < 0 or open_pos >= len(source) or source[open_pos] != "{":
        return ""
    depth = 0
    quote = None
    escaped = False
    start = open_pos + 1
    for idx in range(open_pos, len(source)):
        ch = source[idx]
        if quote is not None:
            if escaped:
                escaped = False
            elif ch == "\\":
                escaped = True
            elif ch == quote:
                quote = None
            continue
        if ch in ("'", '"', "`"):
            quote = ch
        elif ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0:
                return source[start:idx]
    return ""


def _player_script(video_id, timeout=8):
    watch_url = "https://www.youtube.com/watch?v=%s&bpctr=9999999999&has_verified=1" % urllib.parse.quote(str(video_id))
    headers = {
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/124.0 Safari/537.36",
        "Accept-Language": "en-US,en;q=0.9",
    }
    html = _http_text(watch_url, headers=headers, timeout=timeout)
    match = re.search(r'"jsUrl"\s*:\s*"([^"]+base\.js)"', html)
    if not match:
        match = re.search(r'src="([^"]+base\.js)"', html)
    if not match:
        return ""
    js_url = match.group(1).replace("\\/", "/")
    if js_url.startswith("//"):
        js_url = "https:" + js_url
    elif js_url.startswith("/"):
        js_url = "https://www.youtube.com" + js_url
    return _http_text(js_url, headers=headers, timeout=timeout, limit=12 * 1024 * 1024)


def _find_object_body(js, obj_name):
    escaped = re.escape(obj_name)
    for pattern in (
        r"(?:var|let|const)\s+" + escaped + r"\s*=\s*\{",
        r"[,;\s]" + escaped + r"\s*=\s*\{",
    ):
        match = re.search(pattern, js)
        if match:
            brace = js.find("{", match.start(), match.end())
            body = _balanced_body(js, brace)
            if body:
                return body
    return ""


def _parse_helper_methods(body):
    methods = {}
    cursor = 0
    pattern = re.compile(r"([A-Za-z0-9_$]+)\s*:\s*function\s*\([^)]*\)\s*\{")
    while True:
        match = pattern.search(body, cursor)
        if not match:
            break
        name = match.group(1)
        brace = body.find("{", match.start(), match.end())
        fn_body = _balanced_body(body, brace)
        cursor = brace + len(fn_body) + 2
        if "reverse" in fn_body:
            methods[name] = "reverse"
        elif "splice" in fn_body:
            methods[name] = "splice"
        elif "%" in fn_body and ".length" in fn_body:
            methods[name] = "swap"
    return methods


def _signature_plan(js):
    """Extract a list of (operation, arg) steps from YouTube player JS."""
    candidates = (
        r'\b[cs]\s*&&\s*[adf]\.set\([^,]+,\s*encodeURIComponent\(([A-Za-z0-9_$]+)\(',
        r'\b[a-zA-Z0-9]+\s*&&\s*[a-zA-Z0-9]+\.set\([^,]+,\s*encodeURIComponent\(([A-Za-z0-9_$]+)\(',
        r'(?:\b|[^a-zA-Z0-9_$])([A-Za-z0-9_$]{2,})\s*=\s*function\(\s*a\s*\)\s*\{\s*a\s*=\s*a\.split\(\s*""\s*\)',
    )
    fn_names = []
    for pattern in candidates:
        for match in re.finditer(pattern, js):
            name = match.group(1)
            if name and name not in fn_names:
                fn_names.append(name)
    for fn_name in fn_names:
        escaped = re.escape(fn_name)
        for fn_pat in (
            escaped + r'\s*=\s*function\(\s*[A-Za-z0-9_$]+\s*\)\s*\{',
            r'function\s+' + escaped + r'\(\s*[A-Za-z0-9_$]+\s*\)\s*\{',
        ):
            match = re.search(fn_pat, js)
            if not match:
                continue
            brace = js.find("{", match.start(), match.end())
            fn_body = _balanced_body(js, brace)
            if ".split(" not in fn_body or ".join(" not in fn_body:
                continue
            calls = re.findall(r'([A-Za-z0-9_$]+)\.([A-Za-z0-9_$]+)\(\s*[A-Za-z0-9_$]+\s*,\s*(\d+)\s*\)', fn_body)
            if not calls:
                continue
            helper_body = _find_object_body(js, calls[0][0])
            methods = _parse_helper_methods(helper_body)
            steps = []
            for _obj, method, arg in calls:
                if method in methods:
                    steps.append((methods[method], int(arg)))
            if steps:
                return steps
    return []


def _apply_signature(sig, plan):
    chars = list(str(sig or ""))
    if not chars or not plan:
        return ""
    for kind, number in plan:
        if kind == "reverse":
            chars.reverse()
        elif kind == "splice":
            del chars[:max(0, number)]
        elif kind == "slice":
            chars = chars[max(0, number):]
        elif kind == "swap":
            index = number % len(chars)
            chars[0], chars[index] = chars[index], chars[0]
    return "".join(chars)


class UltraYouTubeResolver(object):
    def __init__(self):
        self._js = ""
        self._sig_plan = None

    def _client_specs(self, video_id):
        # 1. ANDROID with params="2AMB" FIRST: returns direct 1080p H.264 (itag 137)
        #    + AAC audio (itag 140) that plays immediately on Enigma2 4097 without
        #    requiring custom User-Agent headers on GStreamer souphttpsrc.
        # 2. IOS second: provides 1080p (itag 96) and 720p (itag 95) HLS streams.
        # 3. TV_EMBED / ANDROID_VR as last-resort fallbacks for restricted videos.
        return (
            (
                "ANDROID",
                _ANDROID_UA,
                {
                    "videoId": video_id,
                    "params": "2AMB",
                    "playbackContext": {"contentPlaybackContext": {"html5Preference": "HTML5_PREF_WANTS"}},
                    "context": {"client": {
                        "hl": "en",
                        "gl": "US",
                        "clientName": "ANDROID",
                        "clientVersion": _ANDROID_VERSION,
                        "androidSdkVersion": 30,
                        "osName": "Android",
                        "osVersion": "11",
                        "userAgent": _ANDROID_UA,
                    }},
                },
                {
                    "content-type": "application/json",
                    "Origin": "https://www.youtube.com",
                    "X-YouTube-Client-Name": "3",
                    "X-YouTube-Client-Version": _ANDROID_VERSION,
                    "User-Agent": _ANDROID_UA,
                },
            ),
            (
                "IOS",
                _IOS_UA,
                {
                    "videoId": video_id,
                    "playbackContext": {"contentPlaybackContext": {"html5Preference": "HTML5_PREF_WANTS"}},
                    "context": {"client": {
                        "hl": "en",
                        "gl": "US",
                        "clientName": "IOS",
                        "clientVersion": _IOS_VERSION,
                        "deviceMake": "Apple",
                        "deviceModel": "iPhone16,2",
                        "osName": "iPhone",
                        "osVersion": "18.3.2.22D82",
                        "userAgent": _IOS_UA,
                    }},
                },
                {
                    "content-type": "application/json",
                    "Origin": "https://www.youtube.com",
                    "X-YouTube-Client-Name": "5",
                    "X-YouTube-Client-Version": _IOS_VERSION,
                    "User-Agent": _IOS_UA,
                },
            ),
            (
                "ANDROID_VR",
                _VR_UA,
                {
                    "videoId": video_id,
                    "playbackContext": {"contentPlaybackContext": {"html5Preference": "HTML5_PREF_WANTS"}},
                    "context": {"client": {
                        "hl": "en",
                        "gl": "US",
                        "clientName": "ANDROID_VR",
                        "clientVersion": _VR_VERSION,
                        "deviceMake": "Oculus",
                        "deviceModel": "Quest 3",
                        "androidSdkVersion": 32,
                        "osName": "Android",
                        "osVersion": "12L",
                        "userAgent": _VR_UA,
                    }},
                },
                {
                    "content-type": "application/json",
                    "Origin": "https://www.youtube.com",
                    "X-YouTube-Client-Name": "28",
                    "X-YouTube-Client-Version": _VR_VERSION,
                    "User-Agent": _VR_UA,
                },
            ),
            (
                "TV_EMBED",
                _TV_UA,
                {
                    "videoId": video_id,
                    "playbackContext": {"contentPlaybackContext": {"html5Preference": "HTML5_PREF_WANTS"}},
                    "context": {
                        "client": {
                            "hl": "en",
                            "gl": "US",
                            "clientName": "TVHTML5_SIMPLY_EMBEDDED_PLAYER",
                            "clientVersion": _TV_VERSION,
                        },
                        "thirdParty": {"embedUrl": "https://www.youtube.com/"},
                    },
                },
                {
                    "content-type": "application/json",
                    "Origin": "https://www.youtube.com",
                    "X-YouTube-Client-Name": "85",
                    "X-YouTube-Client-Version": _TV_VERSION,
                    "User-Agent": _TV_UA,
                },
            ),
        )

    def _request_android(self, video_id, timeout):
        for _name, _ua, body, headers in self._client_specs(video_id):
            if _name == "ANDROID":
                return _http_json(_PLAYER_ENDPOINT, body, headers, timeout)
        return {}

    def _decipher(self, video_id, encrypted, timeout):
        if not encrypted:
            return ""
        if not self._js:
            try:
                self._js = _player_script(video_id, timeout=min(8, timeout))
            except Exception:
                self._js = ""
        if not self._js:
            return ""
        if self._sig_plan is None:
            self._sig_plan = _signature_plan(self._js)
        if not self._sig_plan:
            return ""
        return _apply_signature(encrypted, self._sig_plan)

    def _stream_url(self, video_id, row, timeout):
        if not isinstance(row, dict):
            return ""
        direct = str(row.get("url") or "").strip()
        if direct.startswith(("http://", "https://")):
            return direct
        cipher = str(row.get("signatureCipher") or row.get("cipher") or "").strip()
        if not cipher:
            return ""
        data = urllib.parse.parse_qs(cipher, keep_blank_values=True)
        base = str((data.get("url") or [""])[0] or "").strip()
        if not base.startswith(("http://", "https://")):
            return ""
        ready = str((data.get("sig") or data.get("signature") or [""])[0] or "").strip()
        if not ready:
            encrypted = str((data.get("s") or [""])[0] or "").strip()
            ready = self._decipher(video_id, encrypted, timeout)
        if ready:
            key = str((data.get("sp") or ["signature"])[0] or "signature")
            sep = "&" if "?" in base else "?"
            return base + sep + urllib.parse.urlencode({key: ready})
        return ""

    @staticmethod
    def _rank(itag, order):
        try:
            return order.index(str(itag))
        except ValueError:
            return 999

    def _video_candidates(self, video_id, rows, timeout):
        choices = []
        for row in rows:
            if not isinstance(row, dict):
                continue
            itag = str(row.get("itag") or "")
            if itag in _BLOCKED:
                continue
            rank = self._rank(itag, _VIDEO_ORDER)
            if rank >= 999:
                continue
            url = self._stream_url(video_id, row, timeout)
            if url:
                choices.append((rank, row, url))
        choices.sort(key=lambda item: item[0])
        return choices

    def _pick_video(self, video_id, rows, timeout):
        choices = self._video_candidates(video_id, rows, timeout)
        return choices[0] if choices else None

    def _audio_candidates(self, video_id, rows, timeout):
        choices = []
        for row in rows:
            if not isinstance(row, dict):
                continue
            itag = str(row.get("itag") or "")
            rank = self._rank(itag, _AUDIO_ORDER)
            if rank >= 999:
                continue
            url = self._stream_url(video_id, row, timeout)
            if url:
                choices.append((rank, url))
        choices.sort(key=lambda item: item[0])
        return [item[1] for item in choices]

    def _pick_audio(self, video_id, rows, timeout):
        choices = self._audio_candidates(video_id, rows, timeout)
        return choices[0] if choices else ""

    def _hls_candidates(self, manifest_url, timeout, ua=None):
        if not str(manifest_url or "").startswith(("http://", "https://")):
            return []
        text = _http_text(manifest_url, headers={"User-Agent": str(ua or _IOS_UA)}, timeout=timeout, limit=3 * 1024 * 1024)
        audio_by_group = {}
        pending_audio = ""
        candidates = []
        for line in text.splitlines():
            line = line.strip()
            if line.startswith("#EXT-X-MEDIA:") and "TYPE=AUDIO" in line.upper():
                group = re.search(r'GROUP-ID="([^"]+)"', line)
                uri = re.search(r'URI="([^"]+)"', line)
                if group and uri:
                    audio_by_group[group.group(1)] = urllib.parse.urljoin(manifest_url, uri.group(1))
                continue
            if line.startswith("#EXT-X-STREAM-INF:"):
                group = re.search(r'AUDIO="([^"]+)"', line)
                pending_audio = audio_by_group.get(group.group(1), "") if group else ""
                candidates.append((line, pending_audio, ""))
                continue
            if candidates and line and not line.startswith("#") and not candidates[-1][2]:
                tag = re.search(r"(?:/itag/|itag%3D)(\d+)", line)
                itag = tag.group(1) if tag else ""
                info, audio, _ = candidates[-1]
                candidates[-1] = (info, audio, urllib.parse.urljoin(manifest_url, line) + ("|" + itag if itag else ""))
        best = []
        for _info, audio, packed in candidates:
            if not packed:
                continue
            if "|" in packed:
                url, itag = packed.rsplit("|", 1)
            else:
                url, itag = packed, ""
            rank = self._rank(itag, _VIDEO_ORDER) if itag else 999
            if rank < 999:
                best.append((rank, url + (_SUBURI + audio if audio else "")))
        best.sort(key=lambda item: item[0])
        return [item[1] for item in best]

    def _hls_fallback(self, manifest_url, timeout):
        cands = self._hls_candidates(manifest_url, timeout)
        return cands[0] if cands else ""

    def extract_candidates(self, video_id, timeout=10, cancel_event=None):
        """Return ordered HD (1080p/720p) playable stream URLs without slow pre-probing."""
        key = str(video_id or "").strip()
        if not key:
            return []
        seen = set()
        results = []

        def stopped():
            if cancel_event is not None:
                try:
                    return bool(cancel_event.is_set())
                except Exception:
                    return False
            return False

        for client_name, client_ua, body, headers in self._client_specs(key):
            if stopped():
                break
            try:
                payload = _http_json(_PLAYER_ENDPOINT, body, headers, timeout=max(4, min(8, int(timeout or 10))))
            except Exception:
                continue
            if not isinstance(payload, dict):
                continue
            streaming = payload.get("streamingData") if isinstance(payload, dict) and isinstance(payload.get("streamingData"), dict) else {}
            if not streaming:
                continue
            rows = []
            for bucket in (streaming.get("formats") or [], streaming.get("adaptiveFormats") or []):
                rows.extend([row for row in bucket if isinstance(row, dict)])

            video_choices = self._video_candidates(key, rows, timeout)
            audio_choices = self._audio_candidates(key, rows, timeout)
            best_audio = audio_choices[0] if audio_choices else ""

            for _rank, row, video_url in video_choices:
                itag = str(row.get("itag") or "")
                if itag in _SPLIT_VIDEO:
                    if not best_audio:
                        continue
                    full_url = video_url + _SUBURI + best_audio
                else:
                    full_url = video_url
                if full_url not in seen:
                    seen.add(full_url)
                    results.append(full_url)
                    if len(results) >= 2:
                        break

            if not results:
                hls = str(streaming.get("hlsManifestUrl") or "").strip()
                if hls and not stopped():
                    try:
                        for hls_url in self._hls_candidates(hls, timeout=min(6, timeout), ua=client_ua):
                            if hls_url and hls_url not in seen:
                                seen.add(hls_url)
                                results.append(hls_url)
                                if len(results) >= 2:
                                    break
                    except Exception:
                        pass

            # As soon as ANDROID (or the first working client) yields an HD stream,
            # return immediately so playback starts in <0.5s with zero extra HTTP calls!
            if results:
                return results

        return results

    def extract(self, video_id, timeout=10):
        cands = self.extract_candidates(video_id, timeout=timeout)
        return cands[0] if cands else ""
