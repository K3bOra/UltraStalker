# -*- coding: utf-8 -*-
"""Xtream load, menu refresh and category loading.

Methods moved verbatim out of ``M3UClient`` (m3u_adapter.py); behaviour is unchanged.
This module is imported by m3u_adapter.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, min, OSError, us_clear
from .m3u_adapter import (
    LOG,
    _mode_hint_set,
    os,
    time,
)


class M3UMenuMixin(object):
    """Xtream load, menu refresh and category loading."""

    def _load_xtream(self, cancel_event=None):
        """Bootstrap Xtream with categories only. Content catalogues stay lazy."""
        if not self._xtream:
            raise ValueError("Xtream credentials unavailable.")
        if cancel_event is not None and cancel_event.is_set():return

        started=time.monotonic()
        actions={"itv":"get_live_categories","vod":"get_vod_categories","series":"get_series_categories"}
        results={}
        failed=[]
        for kind,action in actions.items():
            if cancel_event is not None and cancel_event.is_set():
                return
            try:
                results[kind]=self._xtream_request(action,None,self.full_timeout,cancel_event)
            except Exception as exc:
                LOG.warning("Xtream categories failed %s: %s",kind,exc)
                failed.append(exc)
                results[kind]=[]
        if failed and not any(results.get(kind) for kind in actions):
            raise failed[0]

        genres={"itv":[],"vod":[],"series":[]}
        maps={"itv":{},"vod":{},"series":{}}
        reverse={"itv":{},"vod":{},"series":{}}
        for kind in ("itv","vod","series"):
            mapping,order=self._category_rows_to_map(results.get(kind))
            maps[kind]=mapping
            genres[kind]=order
            reverse[kind]={name:cid for cid,name in mapping.items() if name}

        self._xtream_categories=maps
        self._xtream_category_ids=reverse
        self._genres=genres
        self._items={"itv":[],"vod":[],"series":[]}
        self._mode="xtream"
        _mode_hint_set(self._cache_key(),"xtream")
        self._write_mode_hint("xtream")
        self._loaded=True
        self._loaded_at=time.time()
        self._last_success=time.time()
        self._last_error=""
        LOG.info("Xtream bootstrap categories live=%s vod=%s series=%s elapsed_ms=%s",
                 len(genres["itv"]),len(genres["vod"]),len(genres["series"]),
                 int((time.monotonic()-started)*1000))

    def refresh_menu(self, media_type, cancel_event=None, quiet=False):
        """Fresh Xtream folder names. One small request, no full-catalogue read or write."""
        if not self._xtream:
            return None
        if cancel_event is not None and getattr(cancel_event, "is_set", lambda: False)():
            return []
        kind=str(media_type or "itv").lower()
        action={"itv":"get_live_categories","vod":"get_vod_categories","series":"get_series_categories"}.get(kind)
        if not action:
            return []
        # Folder names are a tiny player_api call. Reading or rewriting the saved
        # movie catalogue here made the first Xtream open wait on a huge file.
        self._mode="xtream"
        data=self._xtream_request(action, None, min(12, self.full_timeout), cancel_event)
        mapping,order=self._category_rows_to_map(data)
        if not mapping and not order:
            return []
        self._xtream_categories[kind]=mapping
        self._xtream_category_ids[kind]={name:cid for cid,name in mapping.items() if name}
        self._genres[kind]=order
        if not quiet:
            self._xtream_menu_epoch=time.time()
        return self._xtream_genre_rows(kind)

    def forget_saved_episodes(self):
        """Drop saved season lists so the next open asks for new episodes."""
        changed=False
        for key,data in list((getattr(self,"_series_index",{}) or {}).items()):
            if isinstance(data,dict) and data.get("seasons"):
                fresh=dict(data)
                fresh.pop("seasons",None)
                self._series_index[key]=fresh
                changed=True
        try:us_clear(self._xtream_info_cache)
        except Exception:pass
        if changed:
            try:self._schedule_series_persist()
            except Exception:pass
        return changed

    def refresh_saved_folder(self, kind, category_id, cancel_event=None):
        """Reload one folder the user already opened. Skip folders with no cache."""
        path=self._xtream_category_cache_path(kind, category_id or "*")
        try:
            if not os.path.isfile(path):
                return False
        except OSError:
            return False
        self._load_xtream_category(kind, category_id, cancel_event=cancel_event, force=True)
        return True

    def _xtream_category_id(self, kind, genre):
        kind=str(kind or "itv").lower()
        if genre in (None,"","*"):return ""
        text=str(genre).strip()
        if text in self._xtream_categories.get(kind,{}):
            return text
        cid=self._xtream_category_ids.get(kind,{}).get(text)
        if cid:return str(cid)
        return ""

    def _load_xtream_category(self, kind, genre="*", cancel_event=None, force=False, request_timeout=None, shared=False):
        kind=str(kind or "itv").lower()
        self._drop_stale_catalogue()
        self._ensure(cancel_event)
        cid=self._xtream_category_id(kind,genre)
        if genre not in (None,"","*") and not cid:
            LOG.error("Xtream category routing failed kind=%s requested=%r",kind,genre)
            raise ValueError("Xtream category ID could not be resolved: %s"%genre)
        cache_key=cid or "*"
        legacy_art=None

        if not force:
            cached=self._read_xtream_category_cache_shared(kind,cache_key)
            if isinstance(cached,list):
                self._xtream_loaded_categories.setdefault(kind,set()).add(cache_key)
                # shared=True: caller promises read-only use and copies only the
                # rows it keeps (ordered_page copies just its page slice).
                if shared:return cached
                return list(dict(x) if isinstance(x,dict) else x for x in cached)

            if kind=="itv":
                legacy_art=self._read_xtream_category_cache_shared(kind,cache_key,accept_legacy=True)
                retries=getattr(self,"_live_art_retry_at",{})
                if legacy_art and time.monotonic()<retries.get(cache_key,0):
                    return list(dict(row) if isinstance(row,dict) else row for row in legacy_art)

            # Legacy-cache migration: the main cache contains the entire catalogue.
            # Seed the selected category from that HDD/RAM data once, with no
            # network wait, then persist it in the smaller category cache.
            legacy_rows=list(self._items.get(kind,[]) or [])
            if legacy_rows and (kind!="itv" or all("_picon_candidates" in row for row in legacy_rows if isinstance(row,dict))):
                if genre not in ("*","",None):
                    migrated=list(x for x in legacy_rows
                              if str((x or {}).get("category_id") or (x or {}).get("category") or "")==str(genre))
                else:
                    migrated=legacy_rows
                if migrated:
                    self._write_xtream_category_cache(kind,cache_key,migrated)
                    self._xtream_loaded_categories.setdefault(kind,set()).add(cache_key)
                    return list(dict(x) if isinstance(x,dict) else x for x in migrated)

        action={"itv":"get_live_streams","vod":"get_vod_streams","series":"get_series"}.get(kind)
        if not action:return []
        extra={"category_id":cid} if cid else None
        started=time.monotonic()
        LOG.info("Xtream route kind=%s requested=%r category_id=%s action=%s",kind,genre,cid or "*",action)
        def legacy_fallback():
            retries=getattr(self,"_live_art_retry_at",None)
            if retries is None:retries={};self._live_art_retry_at=retries
            retries[cache_key]=time.monotonic()+120
            while len(retries)>128:retries.pop(next(iter(retries)))
            return [dict(row) if isinstance(row,dict) else row for row in legacy_art]
        try:
            raw=self._xtream_request(action,extra,timeout=(request_timeout if request_timeout is not None else self.full_timeout),cancel_event=cancel_event)
        except Exception:
            if cancel_event is not None and cancel_event.is_set():return []
            if legacy_art:return legacy_fallback()
            raise
        rows=self._normalise_xtream_rows(kind,raw,cid,cancel_event=cancel_event)
        if legacy_art and not rows and not (cancel_event is not None and cancel_event.is_set()):return legacy_fallback()
        if cancel_event is not None and cancel_event.is_set():
            return rows
        # R5.63: a non-list reply (auth error / connection limit) normalises to
        # [] - never persist that as the category's content.
        if isinstance(raw,list) and rows:
            self._write_xtream_category_cache(kind,cache_key,rows)
            self._xtream_loaded_categories.setdefault(kind,set()).add(cache_key)
        if not rows and genre in ("*", "", None):
            combined=[]
            seen=set()
            for cid in list((self._xtream_categories.get(kind) or {}).keys()):
                if cancel_event is not None and cancel_event.is_set():
                    break
                try:
                    part=self._load_xtream_category(kind, cid, cancel_event, force=force, request_timeout=request_timeout) or []
                except Exception:
                    part=[]
                for row in part:
                    if not isinstance(row, dict):
                        continue
                    ident=str(row.get("id") or row.get("stream_id") or row.get("series_id") or row.get("url") or row.get("name") or "")
                    if ident and ident in seen:
                        continue
                    if ident:
                        seen.add(ident)
                    combined.append(row)
            rows=combined
            if rows:
                self._write_xtream_category_cache(kind, "*", rows)
        LOG.info("Xtream lazy category kind=%s category=%s rows=%s elapsed_ms=%s",
                 kind,cid or "*",len(rows),int((time.monotonic()-started)*1000))
        return rows
