# -*- coding: utf-8 -*-
"""Static category chrome, pixmap release, UI hooks and selection snapshots.

Methods moved verbatim out of ``PortalBrowserScreen`` (ui_screens_browser.py); behaviour is unchanged.
This module is imported by ui_screens_browser.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, max, us_casefold, us_func
from .ui_screens_browser import (
    ImageLoaderMixin,
    _CAT_GLASS_PIXMAPS,
    _mem34,
    _ui_diag,
    diagnostic_failure,
    os,
    time,
)


class BrowserChromeMixin(object):
    """Static category chrome, pixmap release, UI hooks and selection snapshots."""

    def _category_surface_active(self):
        return getattr(self, "level", None) in ("genres", "genres_loading")

    def _category_dynamic_visuals_enabled(self):
        """Dynamic category visuals are permanently disabled for Live/Movies/Series.

        All three category pages share one bundled static background and floating rows.
        """
        media = str(getattr(self, "media_type", "") or "").lower()
        return not (self._category_surface_active() and media in ("itv", "vod", "series"))

    def _movies_static_category_chrome(self):
        """Zero-work category chrome for Live, Movies and Series.

        Both pages use the approved floating-row grammar.  They do not resolve,
        load or generate any row background/glass asset.
        """
        return {}

    def _static_category_background_path(self):
        """Return the one receiver-local background shared by Live, Movies and Series."""
        media = str(getattr(self, "media_type", "") or "").lower()
        if self._category_surface_active() and media in ("itv", "vod", "series"):
            path = asset("ultra_bg_clean_1920x1080.png")
            if os.path.isfile(path):
                return path
        return ""

    def _apply_static_category_background(self):
        """Paint the shared Live/Movies/Series background once, with no worker.

        The pixmap stays resident while a child grid is open so returning to
        Categories does not decode it again. It is released only when leaving
        the static category surface or closing the Browser.
        """
        path = self._static_category_background_path()
        if not path:
            try:
                if self["page_adaptive_bg"].instance is not None:
                    self["page_adaptive_bg"].instance.setPixmap(None)
                self["page_adaptive_bg"].hide()
            except Exception as exc:
                optional_failure("ui.category_static_bg_clear", exc)
            self._category_static_bg_loaded = ""
            return False
        self._set_category_clean_visibility(True)
        self._browser_geom("page_adaptive_bg", 0, 0, 1920, 1080)
        try:
            if self["page_adaptive_bg"].instance is not None:
                if str(getattr(self, "_category_static_bg_loaded", "") or "") != path:
                    self["page_adaptive_bg"].instance.setPixmap(None)
                    self["page_adaptive_bg"].instance.setPixmapFromFile(path)
                    self._category_static_bg_loaded = path
                self["page_adaptive_bg"].show()
                return True
        except Exception as exc:
            optional_failure("ui.category_static_bg_apply", exc)
        return False

    def _decode_pending_picture(self):
        """Never let a stale Browser preview decode paint over Categories.

        The Browser root queues its right-side section artwork through ePicLoad.
        On fast cached category opens that decode can fire *after* the screen has
        already switched to ``genres``.  Hiding the preview widget is therefore
        not enough: the delayed decoder callback simply shows it again.

        Categories intentionally have no preview artwork, so drop queued preview
        work while the category rail is active.  Leaving Categories restores the
        normal ImageLoaderMixin path automatically.
        """
        if self._category_surface_active():
            self._image_pending_path = None
            self._image_active_path = None
            self._image_displayed_path = None
            self._image_decode_busy = False
            try:self._image_decode_timer.stop()
            except Exception as exc:optional_failure("ui.category_preview_timer_stop", exc)
            try:
                if self["preview"].instance is not None:
                    self["preview"].instance.setPixmap(None)
                self["preview"].hide()
            except Exception as exc:optional_failure("ui.category_preview_drop", exc)
            return
        return us_func(ImageLoaderMixin._decode_pending_picture)(self)

    def _picture_ready(self, *args):
        """Drain late ePicLoad completions without revealing them in Categories."""
        if self._category_surface_active():
            try:
                # Consume the completed native pixmap so ePicLoad is left in a
                # clean reusable state, but deliberately never assign/show it.
                self._picload.getData()
            except Exception as exc:optional_failure("ui.category_preview_drain", exc)
            self._image_pending_path = None
            self._image_active_path = None
            self._image_displayed_path = None
            self._image_decode_busy = False
            try:
                if self["preview"].instance is not None:
                    self["preview"].instance.setPixmap(None)
                self["preview"].hide()
            except Exception as exc:optional_failure("ui.category_preview_late_hide", exc)
            return
        return us_func(ImageLoaderMixin._picture_ready)(self, *args)

    def _release_browser_pixmaps(self):
        # Keep the static Categories/Favorites backdrop resident while a child
        # screen (notably the Live player) is on top.  Favorites is intentionally
        # one inline page; dropping page_adaptive_bg here produced the black
        # return frame until BACK forced a fresh render.
        keep_static_bg = (
            not getattr(self, "_screen_closed", False)
            and (
                (self._category_surface_active()
                 and str(getattr(self, "media_type", "") or "").lower() in ("itv", "vod", "series")
                 and bool(getattr(self, "_category_static_bg_loaded", "")))
                or str(getattr(self, "level", "") or "") in ("favorites_root", "favorites_cards", "favorites_live")
            )
        )
        names=("preview","accent_frame","info_card1","info_card2","info_card3")
        if not keep_static_bg:
            names=("page_adaptive_bg",)+names
            self._category_static_bg_loaded = ""
            self._utility_static_bg_loaded = ""
            self._favorites_static_bg_loaded = ""
        for _name in names:
            _release_pixmap_widget(self,_name)
        try:
            self._cat_pv_token+=1
            self._cat_pv_timer.stop()
            if not keep_static_bg:
                # Release glass page pixmaps only when closing or leaving Categories.
                # Keeping the lightweight category glass resident while a child grid
                # is open makes returning to Categories instant and avoids synchronous
                # disk reloads on every OK/BACK transition.
                for _name in _CAT_GLASS_PIXMAPS:
                    _release_pixmap_widget(self,_name)
                self._cat_glass_pix=set();self._cat_pv_fan_path="";self._cat_pv_state="";self._cat_focus_pos=None;self._cat_scroll_sig=None
        except Exception as exc:optional_failure("ui.category_glass_release",exc)
        if not keep_static_bg:
            try:self._category_chrome={}
            except Exception as exc:optional_failure("ui.silent_guard",exc)
            _native_image_pressure_relief(force=True)

    def _restore_category_side_identity(self):
        """Keep the clean category page clean after returning from child screens."""
        if not self._category_surface_active() or self.media_type not in ("itv","vod","series"):
            return
        if not self._category_dynamic_visuals_enabled():
            # Live, Movies and Series share the exact same receiver-local static page.
            # Never redo this work on arrow-key selection changes.
            if getattr(self, "_movies_category_visual_ready", False):
                return
            self._set_category_clean_visibility(True)
            self._apply_static_category_background()
            self._movies_category_visual_ready = True
            return
        self._set_category_clean_visibility(True)
        try:self["page_adaptive_bg"].show()
        except Exception as exc:optional_failure("ui.category_backdrop_restore",exc)

    def _apply_browser_status_color(self):
        try:
            text=us_casefold(str(self["status"].getText() or "").strip())
            color="#69e79a" if text=="ready" else "#7fd7ff"
            if self["status"].instance is not None:self["status"].instance.setForegroundColor(parseColor(color))
        except Exception as exc:optional_failure("ui.browser_status_color",exc)

    def _ui_diag_browser_close(self):
        _mem34("browser_close", action=str(getattr(self,"initial_action","") or "root"), level=str(getattr(self,"level","") or ""), items=len(getattr(self,"content_items",[]) or []))
        try:_ui_diag("ui_close",screen="browser",level=getattr(self,"level",""),
                     lifetime_ms=int(max(0.0,(time.monotonic()-self._ui_diag_open_mono)*1000.0)))
        except Exception as exc: diagnostic_failure("ui.browser.failsoft", exc)

    def _stop_browser_ui_hooks(self):
        for result_queue_name in ("_epg_jobs","_live_picon_cache_progress"):
            result_queue=getattr(self,result_queue_name,None)
            if result_queue is None:continue
            try:
                while True:result_queue.get_nowait()
            except queue.Empty:
                pass
            except Exception as exc:
                optional_failure("ui.browser_queue_cleanup",exc)
        self._epg_pending=None
        self._epg_token += 1
        future=getattr(self,"_epg_future",None)
        if future is not None and not future.done():
            try:future.cancel()
            except Exception as exc:optional_failure("ui.browser_epg_future_cancel",exc)
        self._epg_future=None
        for hook_name,callback in (
            ("onShown",self._browser_shown_reset),
            ("onHide",self._browser_hidden_release),
            ("onLayoutFinish",self._layout_ready),
        ):
            try:
                hooks=getattr(self,hook_name,None)
                if hooks is not None and callback in hooks:hooks.remove(callback)
            except Exception as exc:
                optional_failure("ui.browser_hook_cleanup",exc)
        try:
            callbacks=self["list"].onSelectionChanged
            if self._selection_changed in callbacks:callbacks.remove(self._selection_changed)
        except Exception as exc:
            optional_failure("ui.browser_selection_cleanup",exc)

    def _selection_snapshot(self, cfg):
        cfg=cfg if isinstance(cfg,dict) else {}
        return {
            "clean_titles":bool(cfg.get("clean_titles",True)),
            "load_images":bool(cfg.get("load_images",True)),
            "category_preview_posters":bool(cfg.get("category_preview_posters",True)),
            "parental_lock":bool(cfg.get("parental_lock",False)),
            "parental_mode":str(cfg.get("parental_mode","pin") or "pin"),
            "adult_keywords":list(cfg.get("adult_keywords",[]) or []),
            "pinned_categories":{str(k):list(v or []) for k,v in dict(cfg.get("pinned_categories",{}) or {}).items()},
            "protected_categories":{str(k):list(v or []) for k,v in dict(cfg.get("protected_categories",{}) or {}).items()},
        }

    def _selection_settings(self):
        # Selection/key-repeat is RAM-only. Settings are refreshed on onShown and
        # explicit settings mutations; do not reopen persistent JSON every 350 ms.
        if float(getattr(self,"_selection_cfg_mono",0.0) or 0.0)<=0.0:
            self._refresh_selection_settings()
        return self._selection_cfg

    def _refresh_selection_settings(self):
        self._selection_cfg=self._selection_snapshot(load_settings());self._selection_cfg_mono=time.monotonic()
        try:self._image_load_images=bool(self._selection_cfg.get("load_images",True))
        except Exception:pass

    def _browser_shown_reset(self):
        try:self._refresh_selection_settings()
        except Exception as exc:optional_failure("ui.browser_settings_refresh",exc)
        # Do not jump to the first row when a child screen closes.  Enigma2
        # fires onShown again after modal dialogs/players, so moving to index 0
        # here destroyed the user's navigation position.
        try:
            if getattr(self,"_browser_images_suspended",False):
                self._browser_images_suspended=False
                self._image_layout_ready()
        except Exception as exc:optional_failure("ui.browser_resume_image",exc)
        # Favorites never opens a second Browser page.  After a modal child
        # (especially UltraStalkerPlayer) closes, re-show the exact inline
        # Favorites surface and current card without resetting selection.
        if str(getattr(self,"level","") or "") in ("favorites_root","favorites_cards","favorites_live"):
            try:
                self._apply_favorites_static_mode(show_list=(self.level=="favorites_live"))
                self._render_favorites_root()
                self._render_favorite_cards()
            except Exception as exc:optional_failure("ui.favorites_resume_surface",exc)
        if self._category_surface_active() and self.media_type in ("itv","vod","series"):
            try:
                self._apply_category_portal_geometry()
                if self._category_dynamic_visuals_enabled():
                    self._load_category_backdrop()
                    if self.level == "genres":
                        self._load_category_chrome()
                else:
                    # Live+Movies+Series: no Hero decode/build and no adaptive
                    # palette/chrome generation on screen resume.
                    self._category_chrome = self._movies_static_category_chrome()
                self._restore_category_side_identity()
            except Exception as exc:optional_failure("ui.category_resume_identity",exc)
        try:self._selection_changed()
        except Exception as exc:optional_failure("ui",exc)
        try:self._apply_browser_status_color()
        except Exception as exc:optional_failure("ui.silent_guard",exc)
        self._schedule_initial_action()

    def _browser_hidden_release(self):
        if getattr(self,"_screen_closed",False):return
        # Live, Movies and Series keep the same static background decoded while a
        # child grid is open. Returning to Categories costs no second decode.
        self._browser_images_suspended=True
        try:self._image_suspend()
        except Exception as exc:optional_failure("ui.silent_guard",exc)
        self._release_browser_pixmaps()
