# -*- coding: utf-8 -*-
"""One canonical metadata authority shared by Details, Cinematic and Backdrop Grid."""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str, int, max, min, us_casefold, us_acquire
os = _us_env.os
re = _us_env.re
time = _us_env.time
hashlib = _us_env.hashlib
threading = _us_env.threading
from .persistent_cache import detail_snapshot_path
from .artwork_v2 import ArtworkV2, save_manifest
from .persistent_cache import load_detail_snapshot, load_detail_snapshot_by_tmdb, save_detail_snapshot
from .storage import load_settings
from .log import optional_failure
from .description_language import matches_language as _matches_description_language
from .metadata_merge import INVARIANT_FIELDS, clear_localized_fields, same_locale, richer_same_locale
from .verified_identity import verified_id, exact_match as _exact_tmdb_match
from .language_catalog import normalize_description_choice, effective_description_language
from .age_rating import certification_from_tmdb, rating_endpoint
from .media_library import load_alias as _media_load_alias
from .title_clean import catalogue_title as _catalogue_title
_DETAILS_METADATA_SCHEMA = 8
_DESCRIPTION_OVERLAY_KEYS = ('_details_description_language', '_details_description_checked_at', '_details_description_fallback', '_replace_description_only', '_description_clear_overview')
_RAW_METADATA_FIELDS = ('overview', 'overview_language', 'description', 'plot', 'descr', 'genres', 'genre', 'cast', 'actors', 'actor', 'crew', 'directors', 'director', 'writers', 'writer', 'runtime', 'duration', 'time', 'length', 'number_of_seasons', 'seasons_count', 'season_count', 'number_of_episodes', 'episodes_count', 'episode_count', 'release_date', 'first_air_date', 'year', 'release_year', 'releaseDate', 'countries', 'country', 'country_code', 'production_country', 'production_countries', 'origin_country', 'rating', 'vote_count', 'original_language', 'certification', 'age_rating')

def _cancelled(ev):
    try:
        return bool(ev is not None and ev.is_set())
    except Exception:
        return False

def _tmdb_certification(details, media_type, supplemental=None):
    return certification_from_tmdb(details, media_type, supplemental=supplemental)

def _backdrop_ok(path):
    try:
        from .artwork_v2 import _valid_backdrop
        return bool(_valid_backdrop(str(path or '')))
    except Exception:
        try:
            return bool(path and os.path.isfile(str(path)) and (os.path.getsize(str(path)) > 100))
        except Exception:
            return False

def _poster_ok(path):
    """Return whether the canonical poster file is physically ready.

    Local media has no provider-artwork bootstrap. If metadata arrives first, a
    missing poster must therefore force one full ArtworkV2 resolve instead of
    leaving the title permanently half-hydrated.
    """
    try:
        return bool(path and os.path.isfile(str(path)) and (os.path.getsize(str(path)) > 100))
    except Exception:
        return False

def _local_name_first(item):
    return bool(isinstance(item, dict) and (item.get('_local_name_first_identity') or (item.get('_local_media') and str(item.get('source_type') or item.get('_source_type') or '').lower() == 'local')))

def _local_alias_snapshot(media_type, item):
    """HDD-only Local bridge: clean name/year -> verified global TMDb identity.

    The returned record is the same canonical media-library row used by Portal,
    Xtream and M3U. No Local artwork/metadata store is created.
    """
    if not _local_name_first(item):
        return {}
    try:
        title = _catalogue_title(item.get('_local_identity_title') or item.get('_provider_name') or item.get('series_name') or item.get('movie_name') or item.get('name') or item.get('title') or '')
        year = str(item.get('year') or item.get('release_year') or item.get('release_date') or item.get('first_air_date') or '')[:4]
        if not title:
            return {}
        mt = 'tv' if str(media_type).lower() in ('series', 'tv', 'episode') else 'movie'
        row = _media_load_alias(mt, title, year or None) or {}
        if not row:
            return {}
        if mt == 'movie' and year:
            actual = ''
            try:
                raw = str(row.get('release_date') or row.get('first_air_date') or row.get('year') or '')
                m = re.search('(?:19|20)\\d{2}', raw)
                actual = m.group(0) if m else ''
            except Exception:
                actual = ''
            if not actual or str(actual) != str(year):
                return {}
        return row
    except Exception as exc:
        optional_failure('details_authority.local_alias', exc)
        return {}

def _merge(a, b):
    out = dict(a or {})
    if isinstance(b, dict):
        if b.get('_replace_description_only') and b.get('_description_clear_overview'):
            out.pop('overview', None)
            out.pop('overview_language', None)
        if b.get('_replace_localized_metadata'):
            clear_localized_fields(out, a or {}, b, _RAW_METADATA_FIELDS)
            for key in ('_details_provider_fields', '_details_provider_metadata', '_details_provider_overview'):
                out.pop(key, None)
        for k, v in b.items():
            if k == '_description_clear_overview':
                continue
            if b.get('_replace_localized_metadata'):
                v = richer_same_locale(a or {}, b, k, v)
            if k == '_details_metadata_fallback_fields':
                out[k] = v
                continue
            if k in INVARIANT_FIELDS and v in (0, '0', False):
                continue
            if v not in (None, '', [], {}):
                out[k] = v
    return out

def _metadata_language(value):
    """Return the requested TMDb locale without collapsing it to AR/EN.

    Stage 3 treats metadata as TMDb-owned data.  Ultra only normalizes locale
    spelling for cache/readiness keys; it does not infer a different language
    from the text itself.
    """
    raw = str(value or 'en-US').strip().replace('_', '-') or 'en-US'
    bits = [x for x in raw.split('-') if x]
    if not bits:
        return 'en-US'
    language = bits[0].lower()
    if len(bits) == 1:
        return language
    return '%s-%s' % (language, bits[1].upper())

def _has_arabic(value):
    return bool(re.search('[\\u0600-\\u06ff]', str(value or '')))

def _arabic_dominant(value):
    text = str(value or '')
    arabic = len(re.findall('[\\u0600-\\u06ff]', text))
    latin = len(re.findall('[A-Za-z]', text))
    if arabic > 0 and arabic >= latin:
        return True
    if arabic < 8:
        return False
    words = len(re.findall('[\\u0600-\\u06ff]+', text))
    return words >= 3 and arabic >= 0.3 * (arabic + latin)
_EN_WORDS = frozenset('the and of to a in is his her with for on as by an at from that who when after he she they their it be are was'.split())

def _english_dominant(value):
    text = str(value or '')
    latin = len(re.findall('[A-Za-z]', text))
    other = len(re.findall('[^\\W\\d_A-Za-z]', text))
    if latin < 20 or other > latin * 0.1:
        return False
    words = re.findall("[a-z']+", text.lower())
    if not words:
        return False
    hits = sum((1 for w in words if w in _EN_WORDS))
    return hits >= 2 and hits / float(len(words)) >= 0.08
_SCRIPT_PATTERNS = (('arabic', re.compile('[\\u0600-\\u06ff\\u0750-\\u077f\\ufb50-\\ufdff\\ufe70-\\ufeff]')), ('latin', re.compile('[A-Za-z\\u00c0-\\u024f]')), ('cyrillic', re.compile('[\\u0400-\\u04ff]')), ('cjk', re.compile('[\\u3040-\\u30ff\\u3400-\\u9fff\\uac00-\\ud7af]')), ('devanagari', re.compile('[\\u0900-\\u097f]')), ('thai', re.compile('[\\u0e00-\\u0e7f]')), ('hebrew', re.compile('[\\u0590-\\u05ff]')), ('greek', re.compile('[\\u0370-\\u03ff]')))
_LANGUAGE_SCRIPT = {'ar': 'arabic', 'fa': 'arabic', 'ur': 'arabic', 'ru': 'cyrillic', 'uk': 'cyrillic', 'bg': 'cyrillic', 'sr': 'cyrillic', 'zh': 'cjk', 'ja': 'cjk', 'ko': 'cjk', 'hi': 'devanagari', 'mr': 'devanagari', 'ne': 'devanagari', 'th': 'thai', 'he': 'hebrew', 'el': 'greek'}

def _text_script(value):
    """('script', letters) of the script that makes up at least 80% of the letters, else ('',n)."""
    text = str(value or '')
    counts = list(((name, len(pattern.findall(text))) for name, pattern in _SCRIPT_PATTERNS))
    total = sum((n for _name, n in counts))
    if not total:
        return ('', 0)
    name, top = max(counts, key=lambda pair: pair[1])
    return (name, total) if top >= total * 0.8 else ('', total)

def _provider_matches_language(value, wanted):
    base = str(wanted or 'en').split('-', 1)[0].lower()
    if base == 'ar':
        return _arabic_dominant(value) and (not _matches_description_language(value, 'fa'))
    return _matches_description_language(value, wanted)
_EMPTY_DESCRIPTIONS = frozenset(('n/a', 'na', 'none', 'null', '-', '--', '...', 'unknown'))

def _description_candidate(value):
    text = str(value or '').replace('\r', ' ').replace('\n', ' ').strip()
    if not text or text.lower() in _EMPTY_DESCRIPTIONS:
        return ''
    return text
_PROMO_RE = re.compile('https?://|\\bwww\\.|\\bt\\.me/|@\\w{3,}|watch\\s+(?:now|online|free)|subscribe\\s+(?:now|to\\s+our)|follow\\s+us\\b|join\\s+(?:us|our)\\b|download\\s+(?:now|free)|شاهد(?:وا)?\\s+(?:الآن|الان|اون\\s*لاين|أون\\s*لاين|مجان)|مشاهدة\\s+(?:مباشرة|مجان|اون\\s*لاين|أون\\s*لاين|الآن|الان)|تابعونا|تابعنا\\s+على|اشترك\\s+(?:الآن|الان|في\\s+(?:القناة|قناتنا|الموقع|السيرفر))|حمّ?ل\\s+(?:الآن|الان)|تحميل\\s+(?:مباشر|مجان)|جودة\\s+(?:عالية|ممتازة|HD|FHD|UHD|4K|\\d{3,4}p)|حصري(?:ا|ًا|اً)?\\s+(?:على|علي|فقط)|على\\s+سيرفر|سيرفرنا|قناتنا', re.I | re.U)
_SENTENCE_SPLIT = re.compile('(?<=[.!?؟…])\\s+|\\s+[|•·]\\s+')
_MIN_ARABIC_DESCRIPTION = 40
_MIN_ARABIC_SHORT = 15

def _real_arabic_description(text):
    """An Arabic text that is a synopsis, not a one-word tag or a category name.

    Long enough (40+), or a short but genuine sentence: 15+ characters and at least
    three Arabic words. Fix17: a short Arabic synopsis no longer loses to an English one.
    """
    text = str(text or '')
    if len(text) >= _MIN_ARABIC_DESCRIPTION:
        return True
    return len(text) >= _MIN_ARABIC_SHORT and len(re.findall('[\\u0600-\\u06ff]+', text)) >= 3

def _strip_promo(text):
    """Drop advert sentences from a synopsis; unchanged when it has none."""
    if not _PROMO_RE.search(text):
        return text
    kept = [part for part in _SENTENCE_SPLIT.split(text) if part and (not _PROMO_RE.search(part))]
    return ' '.join(kept).strip()

def choose_description_arabic_first(candidates):
    raw = []
    pool = []
    for value in candidates or ():
        text = _description_candidate(value)
        if not text:
            continue
        if text not in raw:
            raw.append(text)
        cleaned = _strip_promo(text)
        if cleaned and cleaned not in pool:
            pool.append(cleaned)
    if not pool:
        return ''
    arabic = list((t for t in pool if _provider_matches_language(t, 'ar')))
    real = list((t for t in arabic if _real_arabic_description(t)))
    if real:
        return max(real, key=len)
    english = list((t for t in pool if _english_dominant(t)))
    if english:
        return max(english, key=len)
    if arabic:
        return max(arabic, key=len)
    return ''

def _own_real_arabic(values):
    """The best real Arabic synopsis among THIS server's own texts ('' when it has none)."""
    try:
        best = choose_description_arabic_first(list(values or ()))
        if best and (not _PROMO_RE.search(best)) and _arabic_dominant(best) and _real_arabic_description(best):
            return best
    except Exception:
        pass
    return ''

def _tmdb_kind(media_type):
    return 'tv' if str(media_type or '').strip().lower() in ('tv', 'show', 'shows', 'series', 'episode') else 'movie'

def _shared_arabic_for(media_type, tmdb_id, cfg=None):
    """Arabic synopsis another portal already supplied for this TMDb id ('' if none).

    Only when Arabic is the selected description language. See shared_overview.py.
    """
    try:
        if not tmdb_id:
            return ''
        if _base_metadata_target(dict(cfg or load_settings() or {})).split('-', 1)[0] != 'ar':
            return ''
        from .shared_overview import load_shared_arabic
        return load_shared_arabic(_tmdb_kind(media_type), tmdb_id)
    except Exception:
        return ''

def _remember_arabic_overview(media_type, row, candidates, cfg):
    """Worker-side: keep a portal's real Arabic synopsis for every other portal.

    Needs a verified TMDb id. The text is advert-stripped, must be a real Arabic synopsis,
    and a text that is just TMDb's own overview is not stored again.
    """
    try:
        if not isinstance(row, dict):
            return
        tmdb_id = row.get('tmdb_id')
        if not tmdb_id or not (row.get('_details_authority_ready') or row.get('identity_verified') or row.get('identity_pointer_verified')):
            return
        if _base_metadata_target(cfg).split('-', 1)[0] != 'ar':
            return
        own = str(row.get('overview') or '').strip()
        pool = [str(c).strip() for c in candidates or () if str(c or '').strip() and str(c).strip() != own]
        best = choose_description_arabic_first(pool) if pool else ''
        if not best or _PROMO_RE.search(best) or (not _arabic_dominant(best)) or (not _real_arabic_description(best)):
            return
        from .shared_overview import save_shared_arabic
        save_shared_arabic(_tmdb_kind(row.get('media_type') or media_type), tmdb_id, best)
    except Exception as exc:
        optional_failure('details_authority.remember_arabic_overview', exc)

def choose_description_for_settings(candidates, settings=None):
    """Arabic-first pick when the description language is Arabic, else ''."""
    try:
        cfg = dict(settings or load_settings() or {})
        if _base_metadata_target(cfg).split('-', 1)[0] != 'ar':
            return ''
        return choose_description_arabic_first(candidates)
    except Exception as exc:
        optional_failure('details_authority.choose_description', exc)
        return ''

def _pick_provider_only(provider, wanted, cfg):
    """Synopsis choice when only provider text exists (no ready TMDb snapshot).

    This is the provider-only branch of details_overview, kept in one place so
    the screens that paint before TMDb answers cannot drift away from it.
    """
    if not provider:
        return ''
    if wanted.split('-', 1)[0] == 'ar':
        chosen = choose_description_arabic_first(provider)
        if chosen:
            return chosen
    if cfg.get('overview_provider_first', True) not in (False, 0, '0', 'false', 'off', 'no'):
        for value in provider:
            if _provider_matches_language(value, wanted):
                return value
    return next((_strip_promo(_description_candidate(value)) for value in provider if _strip_promo(_description_candidate(value))), '')

def provider_description_for_display(*sources):
    """Provider-only synopsis, picked exactly like details_overview picks it
    while no TMDb snapshot exists (same fields, same rule, every language).

    Details paints the provider text before TMDb answers (and keeps it for a
    title TMDb never matches). Cinematic, the grids, Search and Favorites ask
    details_overview. Both go through the same pick, so one title shows the
    same synopsis on every screen.
    """
    try:
        cfg = dict(load_settings() or {})
        wanted = _base_metadata_target(cfg)
        values = []
        for source in sources:
            if not isinstance(source, dict):
                continue
            keys = ['_details_provider_overview', 'description', 'descr', 'plot']
            if not source.get('_details_authority_ready'):
                keys.append('overview')
            for key in keys:
                value = _strip_promo(_description_candidate(source.get(key)))
                if value and value not in values:
                    values.append(value)
        try:
            tmdb_id = None
            kind = None
            for source in sources:
                if not isinstance(source, dict):
                    continue
                tid = source.get('_locked_tmdb_id') or (source.get('tmdb_id') if source.get('_details_authority_ready') or source.get('identity_verified') or source.get('identity_pointer_verified') else None)
                if tid:
                    tmdb_id = tid
                    kind = source.get('_locked_tmdb_type') or source.get('media_type')
                    break
            if tmdb_id and kind:
                shared = _shared_arabic_for(kind, tmdb_id, cfg)
                if shared and shared not in values:
                    values.append(shared)
            for source in sources:
                if not isinstance(source, dict):
                    continue
                fields = _shared_fields_for(source, source.get('media_type'), cfg)
                shared = fields.get('overview')
                if shared and shared not in values:
                    values.append(shared)
            values.sort(key=len, reverse=True)
        except Exception:
            pass
        return _pick_provider_only(values, wanted, cfg)
    except Exception as exc:
        optional_failure('details_authority.provider_description_for_display', exc)
        return ''

def loaded_description_for_display(item, row, settings):
    """Pure first-paint decision: no cache reads, writes or network activity.

    PG3 must not resurrect an arbitrary raw/old-language description after its
    worker explicitly chose an empty string or filtered an advert.
    """
    item = item if isinstance(item, dict) else {}
    row = row if isinstance(row, dict) else {}
    cfg = dict(settings or {})
    wanted = _base_metadata_target(cfg)
    provider = _provider_overview_values(item)
    source = dict(row)
    if row.get('_details_authority_ready') and 'overview' not in (row.get('_details_provider_fields') or []):
        source.pop('overview', None)
    provider += _provider_overview_values(source)
    provider = sorted(set(provider), key=len, reverse=True)
    canonical = _strip_promo(_description_candidate(row.get('overview'))) if _base_metadata_language_ready(row, cfg) else ''
    if wanted.split('-', 1)[0] == 'ar':
        own = _own_real_arabic(provider)
        if own and cfg.get('overview_provider_first', True) not in (False, 0, '0', 'false', 'off', 'no'):
            if not (canonical and _arabic_dominant(canonical) and (len(own) < 60) and (len(canonical) > len(own) * 2)):
                return own
        chosen = choose_description_arabic_first(provider + [canonical])
        if chosen:
            return chosen
    if cfg.get('overview_provider_first', True) not in (False, 0, '0', 'false', 'off', 'no'):
        for text in provider:
            if _provider_matches_language(text, wanted):
                if canonical and len(text) < 60 and (len(canonical) > len(text) * 2):
                    continue
                return text
    return canonical or _pick_provider_only(provider, wanted, cfg)

def synopsis_text(profile, media_type, item, row=None):
    """The one synopsis string every screen paints for a title ("" = nothing yet).

    A stale cached overview from another information language is never a
    substitute: details_overview already decides between the provider text and
    the selected-language TMDb snapshot.
    """
    try:
        text, _ready = details_overview(profile, media_type, item, row)
        return str(text or '').strip()
    except Exception as exc:
        optional_failure('details_authority.synopsis_text', exc)
        return ''

def _provider_overview_values(src):
    values = []

    def add(value):
        text = _strip_promo(_description_candidate(value))
        if text and text not in values:
            values.append(text)
    if not isinstance(src, dict):
        return values
    for key in ('_details_provider_overview', 'description', 'descr', 'plot', 'overview'):
        add(src.get(key))
    overlay = src.get('item_overlay')
    if isinstance(overlay, dict):
        for key in ('description', 'descr', 'plot', 'overview'):
            add(overlay.get(key))
    return values

def _arabic_description_missing(cfg, *sources):
    """True when Arabic is selected and none of the given rows has Arabic text yet."""
    try:
        if _base_metadata_target(cfg).split('-', 1)[0] != 'ar':
            return False
        for src in sources:
            for value in _provider_overview_values(src):
                if _arabic_dominant(value):
                    return False
        return True
    except Exception:
        return False

def _base_metadata_target(cfg):
    """The selected information language, with no Ultra language policy.

    The user-facing Description Language selector already exposes every TMDb
    locale supported by Ultra.  Stage 3 makes that selection the text-metadata
    language for overview/genres/credits as well.  ``current`` keeps the legacy
    internal TMDb locale for backwards compatibility.  Artwork/title-logo
    language remains separate and is not changed here.
    """
    cfg = cfg or {}
    choice = normalize_description_choice(cfg.get('description_language', 'ar-en'))
    if choice == 'current':
        return _metadata_language(cfg.get('tmdb_language', 'ar-EG'))
    wanted = effective_description_language(choice, cfg.get('plugin_language', 'en'))
    return _metadata_language(wanted or cfg.get('tmdb_language', 'ar-EG'))

def _base_metadata_language_ready(row, settings=None):
    """Ready means the exact selected TMDb locale has already been requested.

    No script inspection, Arabic-vs-English heuristics, genre checks or text
    rejection are allowed.  A selected-language request may legitimately fall
    back field-by-field to English; the locale stamp still records which request
    policy produced the snapshot so it is not re-fetched forever.
    """
    row = row if isinstance(row, dict) else {}
    if not (row.get('_details_authority_ready') and row.get('tmdb_id')):
        return False
    try:
        if int(row.get('_details_metadata_schema') or 0) < _DETAILS_METADATA_SCHEMA:
            return False
    except Exception:
        return False
    cfg = dict(settings or load_settings() or {})
    wanted = _base_metadata_target(cfg)
    stamped = str(row.get('_details_metadata_language') or '').strip()
    return bool(stamped and _metadata_language(stamped) == wanted)

def _description_choice(cfg):
    return normalize_description_choice((cfg or {}).get('description_language', 'current'))
_OVERVIEW_RECHECK_SECONDS = 14 * 24 * 3600

def _overview_recheck_due(row, settings=None):
    try:
        fields = row.get('_details_metadata_fallback_fields') or []
        if 'overview' not in fields:
            return False
        cfg = dict(settings or load_settings() or {})
        if _base_metadata_target(cfg).split('-', 1)[0] == 'en':
            return False
        fetched = int(row.get('_details_metadata_fetched_at') or 0)
        return not fetched or time.time() - fetched > _OVERVIEW_RECHECK_SECONDS
    except Exception:
        return False

def metadata_language_ready(row, settings=None):
    """Return raw-TMDb metadata readiness for the selected locale."""
    if not _base_metadata_language_ready(row, settings):
        return False
    if not row.get('_details_origin_checked'):
        country = row.get('countries') or row.get('country') or row.get('production_countries') or row.get('origin_country')
        language = str(row.get('original_language') or '').strip()
        year = row.get('year') or row.get('release_date') or row.get('first_air_date')
        if not country or not language or (not year):
            return False
    return not _overview_recheck_due(row, settings)

def _pick_tmdb_youtube_trailers(video_payload, wanted_language="", limit=4):
    """Pick ranked TMDb-linked YouTube trailers/teasers for an exact TMDb id."""
    payload=video_payload if isinstance(video_payload,dict) else {}
    rows=payload.get("results") or []
    if not isinstance(rows,list):return []
    wanted=str(wanted_language or "").strip().lower().split("-",1)[0]
    type_bonus={"trailer":200,"teaser":120,"clip":40,"featurette":25,"opening credits":15}
    candidates=[]
    for row in rows:
        if not isinstance(row,dict):continue
        if str(row.get("site") or "").strip().lower()!="youtube":continue
        vtype=str(row.get("type") or "").strip().lower()
        if vtype not in type_bonus:continue
        key=str(row.get("key") or "").strip()
        if not key:continue
        name=str(row.get("name") or "").strip()
        lang=str(row.get("iso_639_1") or "").strip().lower()
        official=bool(row.get("official"))
        score=type_bonus.get(vtype,0)
        if wanted=="ar" and lang=="ar":score+=1000
        if official:score+=100
        low_name=name.lower()
        if "official trailer" in low_name:score+=40
        elif "trailer" in low_name:score+=25
        elif "official" in low_name:score+=20
        if wanted and lang==wanted:score+=25
        elif lang=="en":score+=10
        try:score+=min(6,max(0,int(row.get("size") or 0)//360))
        except Exception:pass
        published=str(row.get("published_at") or "")
        candidates.append((score,published,row))
    if not candidates:return []
    candidates.sort(key=lambda x:(x[0],x[1]),reverse=True)
    out=[];seen=set()
    for _score,_pub,row in candidates:
        key=str(row.get("key") or "").strip()
        if not key or key in seen:continue
        seen.add(key)
        out.append({
            "trailer_site":"YouTube",
            "trailer_key":key,
            "trailer_name":str(row.get("name") or "Trailer").strip() or "Trailer",
            "trailer_language":str(row.get("iso_639_1") or "").strip(),
            "trailer_official":bool(row.get("official")),
            "trailer_url":"https://www.youtube.com/watch?v="+key,
        })
        if len(out)>=max(1,int(limit or 4)):break
    return out


def _pick_tmdb_youtube_trailer(video_payload, wanted_language=""):
    """Pick one official TMDb-linked YouTube trailer for an exact TMDb id."""
    rows=_pick_tmdb_youtube_trailers(video_payload,wanted_language=wanted_language,limit=1)
    return rows[0] if rows else {}


def _localized_metadata(profile, media_type, item, current, cfg, cancel_event=None):
    """Fetch one raw TMDb metadata snapshot by verified id.

    Contract: selected locale first, then English only for fields TMDb leaves
    empty.  Ultra does not inspect scripts, force Arabic/English, transliterate,
    prefer Latin person names, or preserve an older language over the new one.
    Artwork and title-logo bytes are never touched here.
    """
    if _cancelled(cancel_event):
        return {}
    tmdb_id = (current or {}).get('tmdb_id')
    credential = str((cfg or {}).get('tmdb_credential') or '').strip()
    if not (tmdb_id and credential and (cfg or {}).get('tmdb_enabled', True)):
        return {}
    try:
        from .tmdb import TMDBClient, _tmdb_country_codes
        wanted = _base_metadata_target(cfg or {})
        mt = str((current or {}).get('media_type') or ('tv' if str(media_type).lower() in ('series', 'tv') else 'movie')).lower()
        if mt in ('series', 'show'):
            mt = 'tv'
        if mt not in ('movie', 'tv'):
            mt = 'movie'
        timeout = min(7, max(3, int((cfg or {}).get('timeout', 10) or 10)))
        client = TMDBClient(credential, wanted, timeout)
        _rating_append = 'release_dates' if mt == 'movie' else 'content_ratings'
        params = {'language': wanted, 'append_to_response': 'credits,external_ids,translations,videos,%s' % _rating_append}
        details = client._get('/%s/%s' % (mt, int(tmdb_id)), params) or {}
        if _cancelled(cancel_event) or not isinstance(details, dict) or (not details.get('id')):
            return {}
        trailer = _pick_tmdb_youtube_trailer(details.get('videos'), wanted)

        def _credit_parts(payload):
            credits = payload.get('credits') if isinstance(payload.get('credits'), dict) else {}
            cast = [str(p.get('name')) for p in (credits.get('cast') or [])[:6] if isinstance(p, dict) and p.get('name')]
            directors = []
            writers = []
            crew = []
            for person in credits.get('crew') or []:
                if not isinstance(person, dict) or not person.get('name'):
                    continue
                name = str(person.get('name'))
                job = str(person.get('job') or '')
                dept = str(person.get('department') or '')
                if job == 'Director' and name not in directors:
                    directors.append(name)
                if job in ('Writer', 'Screenplay', 'Story', 'Teleplay', 'Original Story', 'Novel') or dept == 'Writing':
                    if name not in writers:
                        writers.append(name)
                if job in ('Director', 'Creator', 'Executive Producer') and name not in crew:
                    crew.append(name)
            if mt == 'tv':
                for person in payload.get('created_by') or []:
                    if isinstance(person, dict) and person.get('name'):
                        name = str(person.get('name'))
                        if name not in writers:
                            writers.insert(0, name)
                        if name not in crew:
                            crew.insert(0, name)
            return (cast, crew[:4], directors[:3], writers[:4])
        selected_genres = list((str(x.get('name')) for x in details.get('genres') or [] if isinstance(x, dict) and x.get('name')))
        selected_cast, selected_crew, selected_directors, selected_writers = _credit_parts(details)
        wanted_lang = _description_locale_parts(wanted)[0]
        original_lang = str(details.get('original_language') or '').strip().lower().split('-')[0]
        translations = details.get('translations') if isinstance(details.get('translations'), dict) else {}
        if wanted_lang == 'en':
            overview = str(details.get('overview') or '').strip()
        else:
            overview = _translation_overview(translations, wanted)
            if not overview and original_lang == wanted_lang:
                overview = str(details.get('overview') or '').strip()
        fallback_fields = []
        if not overview and wanted_lang != 'en':
            en_trans_ov = _translation_overview(translations, 'en-US')
            if not en_trans_ov and original_lang == 'en':
                en_trans_ov = str(details.get('overview') or '').strip()
            if en_trans_ov:
                overview = en_trans_ov
                fallback_fields.append('overview')
        fallback = {}
        need_english = wanted.lower() != 'en-us' and (not overview or not selected_genres)
        if need_english:
            try:
                fallback = client._get('/%s/%s' % (mt, int(tmdb_id)), {'language': 'en-US', 'append_to_response': 'credits,external_ids'}) or {}
            except Exception as exc:
                optional_failure('details_authority.raw_english_fallback', exc)
                fallback = {}
        fallback_genres = list((str(x.get('name')) for x in fallback.get('genres') or [] if isinstance(x, dict) and x.get('name')))
        fallback_cast, fallback_crew, fallback_directors, fallback_writers = _credit_parts(fallback or {})
        if not overview:
            overview = str((fallback or {}).get('overview') or '').strip()
            if overview:
                fallback_fields.append('overview')
        genres = selected_genres or fallback_genres
        if genres and (not selected_genres):
            fallback_fields.append('genres')
        cast = selected_cast or fallback_cast
        if cast and (not selected_cast):
            fallback_fields.append('cast')
        crew = selected_crew or fallback_crew
        if crew and (not selected_crew):
            fallback_fields.append('crew')
        directors = selected_directors or fallback_directors
        if directors and (not selected_directors):
            fallback_fields.append('directors')
        writers = selected_writers or fallback_writers
        if writers and (not selected_writers):
            fallback_fields.append('writers')
        runtime = details.get('runtime')
        if mt == 'tv' and (not runtime):
            runtimes = details.get('episode_run_time') or []
            runtime = runtimes[0] if isinstance(runtimes, list) and runtimes else None
        date = details.get('release_date') if mt == 'movie' else details.get('first_air_date')
        year = ''
        try:
            year = int(str(date)[:4]) if str(date or '')[:4].isdigit() else ''
        except Exception:
            year = ''
        countries = _tmdb_country_codes(details, mt) or _tmdb_country_codes(fallback, mt)
        external = details.get('external_ids') if isinstance(details.get('external_ids'), dict) else {}
        if not external and isinstance((fallback or {}).get('external_ids'), dict):
            external = fallback.get('external_ids') or {}
        certification = _tmdb_certification(details, mt)
        if not certification and (not isinstance(details.get(_rating_append), dict)) and (not _cancelled(cancel_event)):
            try:
                rating_payload = client._get(rating_endpoint(mt, tmdb_id)) or {}
            except Exception as exc:
                optional_failure('details_authority.age_rating_fallback', exc)
                rating_payload = {}
            certification = _tmdb_certification(details, mt, supplemental=rating_payload)
        out = {'tmdb_id': int(tmdb_id), 'media_type': mt, '_details_metadata_language': wanted, '_details_metadata_schema': _DETAILS_METADATA_SCHEMA, '_details_metadata_fallback_fields': fallback_fields, '_details_metadata_fetched_at': int(time.time()), '_details_origin_checked': True, '_replace_localized_metadata': True, 'overview': overview, 'overview_language': ('en-US' if 'overview' in fallback_fields else wanted) if overview else '', 'genres': genres, 'cast': cast, 'crew': crew, 'directors': directors, 'writers': writers, 'runtime': runtime, 'number_of_seasons': details.get('number_of_seasons') or 0, 'number_of_episodes': details.get('number_of_episodes') or 0, 'release_date': date or '', 'year': year, 'rating': details.get('vote_average'), 'vote_count': details.get('vote_count'), 'certification': certification, 'age_rating': certification, '_age_rating_checked': True, 'countries': countries, 'original_language': str(details.get('original_language') or fallback.get('original_language') or '').strip().lower(), 'imdb_id': str(external.get('imdb_id') or (current or {}).get('imdb_id') or '').strip(), '_trailer_checked': bool(trailer)}
        if trailer:
            out.update(trailer)
        return out
    except Exception as exc:
        optional_failure('details_authority.raw_metadata', exc)
        return {}

def _description_locale_parts(value):
    raw = str(value or 'en-US').replace('_', '-').strip()
    bits = [x for x in raw.split('-') if x]
    language = bits[0].lower() if bits else 'en'
    region = bits[1].upper() if len(bits) > 1 else ''
    return (language, region)

def _translation_overview(payload, wanted):
    """Return only an overview explicitly tagged with the requested language.

    Region is preferred when TMDb exposes more than one translation for the
    same language (for example pt-BR vs pt-PT or zh-CN vs zh-TW). Falling back
    to another region of the same language is allowed; falling back to a
    different language is never allowed here.
    """
    language, region = _description_locale_parts(wanted)
    rows = (payload or {}).get('translations') or []
    same = []
    for entry in rows:
        if not isinstance(entry, dict):
            continue
        if str(entry.get('iso_639_1') or '').strip().lower() != language:
            continue
        text = str((entry.get('data') or {}).get('overview') or '').strip()
        if not text:
            continue
        entry_region = str(entry.get('iso_3166_1') or '').strip().upper()
        same.append((entry_region, text))
    if region:
        for entry_region, text in same:
            if entry_region == region:
                return text
    return same[0][1] if same else ''

def load_canonical(profile, media_type, item):
    try:
        from .manual_identity import apply_choice, selected
        item = apply_choice(profile, media_type, item)
        manual = selected(item)
        if manual:
            return load_detail_snapshot_by_tmdb(manual['media_type'], manual['tmdb_id']) or {}
        if _local_name_first(item):
            return _local_alias_snapshot(media_type, item) or {}
        row = load_detail_snapshot(profile, media_type, item) or {}
        if not row and verified_id(item):
            row = load_detail_snapshot_by_tmdb(item.get('_locked_tmdb_type') or media_type, verified_id(item)) or {}
        if not row.get('tmdb_id'):
            from . import artwork_v2 as artwork_cache
            for loader_name in ('load_fast_local_poster', 'load_manifest'):
                try:
                    candidate = getattr(artwork_cache, loader_name)(profile, media_type, item) or {}
                    ident = verified_id(candidate)
                    if not ident:
                        continue
                    from .verified_identity import media_kind
                    kind = media_kind(candidate.get('media_type') or media_type)
                    wanted_kind = media_kind(media_type)
                    if not kind or (wanted_kind and kind != wanted_kind):
                        continue
                    if verified_id(item) and _exact_tmdb_match(item, candidate) is not True:
                        continue
                    direct = load_detail_snapshot_by_tmdb(kind, ident) or {}
                    row = _merge(candidate, direct)
                    row['tmdb_id'] = int(ident)
                    row['media_type'] = kind
                    row['identity_verified'] = True
                    row['_details_identity_bridge'] = loader_name
                    break
                except Exception as exc:
                    optional_failure('details_authority.artwork_identity_bridge', exc)
        if row.get('tmdb_id'):
            direct = load_detail_snapshot_by_tmdb(row.get('media_type') or media_type, row.get('tmdb_id')) or {}
            row = _merge(row, direct)
        return row
    except Exception as exc:
        optional_failure('details_authority.load', exc)
        return {}

def adopt_verified_artwork_metadata(profile, media_type, item, current, candidate, settings=None, cancel_event=None, provider_client=None):
    """Worker-only join for identity/origin data discovered by the logo lane.

    A logo response may be in another locale. Only verified identity and work
    invariants cross this boundary; prose/genres use the normal selected-locale
    metadata authority. Stream-specific fields are never copied from the donor.
    """
    out = dict(current or {})
    if _cancelled(cancel_event) or not isinstance(candidate, dict):
        return out
    ident = verified_id(candidate)
    if not ident:
        return out
    from .verified_identity import media_kind
    kind = media_kind(candidate.get('media_type') or media_type)
    requested = media_kind(media_type)
    if not kind or (requested and requested != kind):
        return out
    if out.get('tmdb_id'):
        proof = {'_locked_tmdb_id': out['tmdb_id'], '_locked_tmdb_type': out.get('media_type') or media_type}
        if _exact_tmdb_match(proof, candidate) is not True:
            return out
    if verified_id(item) and _exact_tmdb_match(item, candidate) is not True:
        return out
    out.update(tmdb_id=int(ident), media_type=kind, identity_verified=True, matched=True)
    for key in INVARIANT_FIELDS:
        value = candidate.get(key)
        if not out.get(key) and value not in (None, '', [], {}, 0, '0'):
            out[key] = value
    locked = dict(item or {})
    locked['_locked_tmdb_id'] = int(ident)
    locked['_locked_tmdb_type'] = kind
    cfg = dict(settings or load_settings() or {})
    result = resolve_metadata_fast(profile, media_type, locked, current=out, cancel_event=cancel_event, settings=cfg, provider_client=provider_client) or out
    if not _cancelled(cancel_event):
        try:
            save_detail_snapshot(profile, media_type, item, result)
        except Exception as exc:
            optional_failure('details_authority.artwork_metadata_join_save', exc)
    return result

def _visible_provider_overview(src):
    """Return the exact provider synopsis fields Native Details paints first."""
    if not isinstance(src, dict):
        return ''
    direct = _strip_promo(_description_candidate(src.get('_details_provider_overview')))
    if direct:
        return direct
    for key in ('description', 'descr', 'plot', 'overview'):
        value = _strip_promo(_description_candidate(src.get(key)))
        if value:
            return value
    overlay = src.get('item_overlay')
    if isinstance(overlay, dict):
        for key in ('description', 'descr', 'plot', 'overview'):
            value = _strip_promo(_description_candidate(overlay.get(key)))
            if value:
                return value
    return ''

def _enrich_provider_overview(provider_client, item, media_type, cancel_event=None):
    """Mirror Details' Xtream provider-info fallback without polluting TMDb HDD data."""
    if _cancelled(cancel_event) or not isinstance(item, dict):
        return ''
    if not item.get('_xtream') or provider_client is None or (not hasattr(provider_client, 'enrich_provider_artwork')):
        return ''
    try:
        from .core.call_compat import call_compatible
        enriched = call_compatible(provider_client.enrich_provider_artwork, (((dict(item), media_type, cancel_event), {'force': True}), ((dict(item), media_type, cancel_event), {}))) or {}
        if _cancelled(cancel_event):
            return ''
        _best = choose_description_for_settings(_provider_overview_values(enriched))
        return _best or _visible_provider_overview(enriched)
    except Exception as exc:
        optional_failure('details_authority.provider_overview_enrich', exc)
        return ''

def details_overview(profile, media_type, item, current=None):
    """Return one stable visible synopsis for Details/Cinematic/BG1/BG2.

    A cached row from another information language cannot paint the box while
    the selected locale is resolving. The selected TMDb snapshot wins, including
    its English fallback; same-item server text fills only an unresolved gap.
    """
    try:
        item = item if isinstance(item, dict) else {}
        current = current if isinstance(current, dict) else {}
        cfg = dict(load_settings() or {})
        wanted = _base_metadata_target(cfg)
        row = load_canonical(profile, media_type, item) or {}
        if current.get('_details_authority_ready'):
            row = _merge(row, current)
        tmdb_id = row.get('tmdb_id') or current.get('tmdb_id') or item.get('_locked_tmdb_id')
        if tmdb_id:
            mt = row.get('media_type') or current.get('media_type') or item.get('_locked_tmdb_type') or media_type
            direct = load_detail_snapshot_by_tmdb(mt, tmdb_id) or {}
            if direct:
                row = _merge(row, direct)
        ready = _base_metadata_language_ready(row, cfg)
        canonical = str(row.get('overview') or '').strip() if ready else ''

        def provider_values(source):
            source = source if isinstance(source, dict) else {}
            values = []
            for key in ('_details_provider_overview', 'description', 'descr', 'plot'):
                value = _strip_promo(_description_candidate(source.get(key)))
                if value and value not in values:
                    values.append(value)
            if not source.get('_details_authority_ready'):
                value = _strip_promo(_description_candidate(source.get('overview')))
                if value and value not in values:
                    values.append(value)
            return values
        provider = []
        for source in (item, current):
            for value in provider_values(source):
                if value not in provider:
                    provider.append(value)
        if tmdb_id:
            shared = _shared_fields_for(row or current, media_type, cfg)
            shared_overview = _strip_promo(str(shared.get('overview') or ''))
            if shared_overview and shared_overview not in provider:
                provider.append(shared_overview)
        provider.sort(key=len, reverse=True)
        if wanted.split('-', 1)[0] == 'ar':
            _shared = _shared_arabic_for(row.get('media_type') or media_type, tmdb_id, cfg) if tmdb_id else ''
            if _shared and _shared not in provider:
                provider.append(_shared)
            _own = _own_real_arabic(provider)
            if _own and cfg.get('overview_provider_first', True) not in (False, 0, '0', 'false', 'off', 'no'):
                if not (canonical and _arabic_dominant(canonical) and (len(_own) < 60) and (len(canonical) > len(_own) * 2)):
                    return (_own, True)
            _shared = _shared_arabic_for(row.get('media_type') or media_type, tmdb_id, cfg) if tmdb_id else ''
            _chosen = choose_description_arabic_first(list(provider) + [canonical] + ([_shared] if _shared else []))
            if _chosen:
                return (_chosen, True)
        if cfg.get('overview_provider_first', True) not in (False, 0, '0', 'false', 'off', 'no'):
            for value in provider:
                if not _provider_matches_language(value, wanted):
                    continue
                _stub = 25 if _text_script(value)[0] == 'cjk' else 60
                if canonical and len(value) < _stub and (len(canonical) > len(value) * 2):
                    continue
                return (value, True)
        if canonical:
            if wanted.split('-', 1)[0] == 'ar' and (not _has_arabic(canonical)):
                for value in provider:
                    if _arabic_dominant(value):
                        return (value, True)
            return (canonical, True)
        if provider:
            return (provider[0], True)
        if ready:
            return ('', True)
        return ('', False)
    except Exception as exc:
        optional_failure('details_authority.overview', exc)
        return ('', False)
_METADATA_FLIGHT_LOCKS = tuple((threading.Lock() for _ in range(32)))

def resolve_metadata_fast(profile, media_type, item, current=None, cancel_event=None, settings=None, provider_client=None):
    """Coalesce same-item metadata work; waiting callers re-read the saved result."""
    from .manual_identity import apply_choice, selected
    item = apply_choice(profile, media_type, item)
    if selected(item):
        provider_client = None
        if _exact_tmdb_match(item, current or {}) is not True:
            current = {}
    if _cancelled(cancel_event):
        return dict(current or {})
    key = detail_snapshot_path(profile, media_type, item)
    index = int(hashlib.sha1(str(key).encode('utf-8')).hexdigest()[:8], 16) % len(_METADATA_FLIGHT_LOCKS)
    lock = _METADATA_FLIGHT_LOCKS[index]
    while not us_acquire(lock, 0.1):
        if _cancelled(cancel_event):
            return dict(current or {})
    try:
        if _cancelled(cancel_event):
            return dict(current or {})
        latest = load_canonical(profile, media_type, item) or {}
        row = dict(current or {})
        same_id = not row.get('tmdb_id') or not latest.get('tmdb_id') or _exact_tmdb_match({'_locked_tmdb_id': row['tmdb_id'], '_locked_tmdb_type': row.get('media_type')}, latest) is True
        cfg = settings or load_settings() or {}
        if latest and same_id and metadata_language_ready(latest, cfg):
            row = _merge(row, latest)
        result = _resolve_metadata_fast_owned(profile, media_type, item, current=row, cancel_event=cancel_event, settings=settings, provider_client=provider_client)
        return _provider_metadata_fallback(result, item, media_type, provider_client, cancel_event, profile, allow_copy_search=False)
    finally:
        lock.release()

def _resolve_metadata_fast_owned(profile, media_type, item, current=None, cancel_event=None, settings=None, provider_client=None):
    """Fast Details-Authority text hydration for Cinematic/BG1/BG2.

    This lane is exact-id and metadata-only: no title search, artwork download,
    backdrop preparation, Pillow work or title-logo work.  It exists so the
    external information boxes can obtain the same Details record without the
    user having to open Details first.
    """
    if _cancelled(cancel_event):
        return dict(current or {})
    cfg = dict(settings or load_settings() or {})
    row = dict((load_canonical(profile, media_type, item) if _local_name_first(item) else current or load_canonical(profile, media_type, item)) or {})
    if row.get('tmdb_id'):
        shared = load_detail_snapshot_by_tmdb(row.get('media_type') or media_type, row['tmdb_id']) or {}
        if shared and (not row.get('_details_metadata_language') or same_locale(row, shared)):
            row = _merge(row, shared)
    if metadata_language_ready(row, cfg):
        if not str(row.get('overview') or '').strip() and (not _visible_provider_overview(item)) and (not _visible_provider_overview(row)) or _arabic_description_missing(cfg, row, item):
            provider_text = _enrich_provider_overview(provider_client, item, media_type, cancel_event=cancel_event)
            if provider_text:
                row['_details_provider_overview'] = provider_text
        return row
    if not row.get('tmdb_id') and isinstance(item, dict):
        _item_tid = item.get('_locked_tmdb_id') or item.get('_ultra_search_verified_tmdb_id')
        if _item_tid:
            row['tmdb_id'] = _item_tid
            row['media_type'] = item.get('_locked_tmdb_type') or item.get('media_type') or ('tv' if str(media_type).lower() in ('series', 'tv') else 'movie')
            row['identity_verified'] = True
    if not row.get('tmdb_id'):
        credential = str(cfg.get('tmdb_credential') or '').strip()
        if credential and cfg.get('tmdb_enabled', True) and isinstance(item, dict):
            try:
                resolver = ArtworkV2(credential, cfg.get('tmdb_language', 'ar-EG'), min(7, max(3, int(cfg.get('timeout', 10) or 10))))
                resolved_type, resolved_id, confidence, identity_source, _seed = resolver._resolve_identity(media_type, item, hot=row)
                if _cancelled(cancel_event):
                    return row
                if resolved_id:
                    row['tmdb_id'] = int(resolved_id)
                    row['media_type'] = str(resolved_type or ('tv' if str(media_type).lower() in ('series', 'tv') else 'movie'))
                    row['identity_verified'] = True
                    row['identity_source'] = str(identity_source or 'metadata_identity')
                    try:
                        row['identity_confidence'] = float(confidence or 0.0)
                    except Exception:
                        pass
            except Exception as exc:
                optional_failure('details_authority.fast_identity', exc)
    if not row.get('tmdb_id'):
        if not _visible_provider_overview(item) and (not _visible_provider_overview(row)) or _arabic_description_missing(cfg, row, item):
            provider_text = _enrich_provider_overview(provider_client, item, media_type, cancel_event=cancel_event)
            if provider_text:
                row['_details_provider_overview'] = provider_text
        return row
    refreshed = None
    try:
        _global_kind = _tmdb_kind(row.get('media_type') or media_type)
        _global = load_detail_snapshot_by_tmdb(_global_kind, row.get('tmdb_id')) or {}
        if _global and metadata_language_ready(_global, cfg):
            refreshed = dict(_global)
    except Exception as exc:
        optional_failure('details_authority.fast_shared_record', exc)
    if refreshed is None:
        refreshed = _localized_metadata(profile, media_type, item, row, cfg, cancel_event=cancel_event) or {}
    if not refreshed:
        if not _visible_provider_overview(item) and (not _visible_provider_overview(row)) or _arabic_description_missing(cfg, row, item):
            provider_text = _enrich_provider_overview(provider_client, item, media_type, cancel_event=cancel_event)
            if provider_text:
                row['_details_provider_overview'] = provider_text
        return row
    merged = _merge(row, refreshed)
    merged['matched'] = bool(merged.get('matched', True))
    merged['identity_verified'] = bool(merged.get('identity_verified') or merged.get('identity_pointer_verified') or merged.get('tmdb_id'))
    merged['_details_authority_ready'] = True
    merged['_details_authority_version'] = 4
    for key in _DESCRIPTION_OVERLAY_KEYS + ('_details_base_description', '_description_overviews', '_details_description_restore_needed', '_details_visible_overview', '_details_visible_overview_language', '_details_visible_overview_source', '_details_visible_overview_updated_at'):
        merged.pop(key, None)
    if _cancelled(cancel_event):
        return row
    try:
        save_detail_snapshot(profile, media_type, item, merged)
    except Exception as exc:
        optional_failure('details_authority.fast_snapshot', exc)
    try:
        save_manifest(profile, media_type, item, merged)
    except Exception as exc:
        optional_failure('details_authority.fast_manifest', exc)
    if not str(merged.get('overview') or '').strip() and (not _visible_provider_overview(item)) and (not _visible_provider_overview(merged)) or _arabic_description_missing(cfg, merged, item):
        provider_text = _enrich_provider_overview(provider_client, item, media_type, cancel_event=cancel_event)
        if provider_text:
            merged['_details_provider_overview'] = provider_text
    return merged

def _resolve_canonical_tmdb(profile, media_type, item, cancel_event=None, settings=None, provider_client=None, provider_downloader=None, component_callback=None):
    """Resolve one stable-focus item and persist the single Details record."""
    if _cancelled(cancel_event):
        return {}
    cfg = dict(settings or load_settings() or {})
    current = load_canonical(profile, media_type, item)
    metadata_ready = metadata_language_ready(current, cfg)
    backdrop_ready = _backdrop_ok(current.get('backdrop_local'))
    poster_ready = _poster_ok(current.get('poster_local'))
    if metadata_ready and backdrop_ready and poster_ready:
        return current
    credential = str(cfg.get('tmdb_credential') or '').strip()
    if not credential:
        return current
    if not cfg.get('tmdb_enabled', True):
        return current
    src = dict(item or {}) if isinstance(item, dict) else {}
    if metadata_ready and current.get('tmdb_id') and (not backdrop_ready) and poster_ready:
        try:
            retry_at = int(current.get('next_retry_at') or current.get('backdrop_next_retry_at') or 0)
        except Exception:
            retry_at = 0
        if not retry_at or int(time.time()) >= retry_at:
            try:
                resolver = ArtworkV2(credential, cfg.get('tmdb_language', 'ar-EG'), min(7, max(3, int(cfg.get('timeout', 10) or 10))))
                locked = dict(src)
                locked['_locked_tmdb_id'] = current.get('tmdb_id')
                locked['_locked_tmdb_type'] = current.get('media_type') or ('tv' if str(media_type) == 'series' else 'movie')
                rescued = resolver.resolve_backdrop_only(profile, media_type, locked, cancel_event=cancel_event) or {}
                if rescued:
                    row = _merge(current, rescued)
                    row['_details_authority_ready'] = True
                    row['_details_authority_version'] = 2
                    if _cancelled(cancel_event):
                        return current
                    save_detail_snapshot(profile, media_type, src, row)
                    try:
                        save_manifest(profile, media_type, src, row)
                    except Exception as exc:
                        optional_failure('details_authority.backdrop_manifest', exc)
                    current = row
                    backdrop_ready = _backdrop_ok(row.get('backdrop_local'))
            except Exception as exc:
                optional_failure('details_authority.backdrop_repair', exc)
        if backdrop_ready:
            return current
        return current
    if current.get('tmdb_id'):
        src['_locked_tmdb_id'] = current.get('tmdb_id')
        src['_locked_tmdb_type'] = current.get('media_type') or ('tv' if str(media_type) == 'series' else 'movie')
        if current.get('_details_authority_ready') and (not metadata_ready):
            repaired = _localized_metadata(profile, media_type, src, current, cfg, cancel_event=cancel_event)
            if repaired:
                row = _merge(current, repaired)
                row['_details_authority_ready'] = True
                row['_details_authority_version'] = 4
                row['_details_metadata_language'] = _base_metadata_target(cfg)
                for _key in _DESCRIPTION_OVERLAY_KEYS + ('_details_base_description', '_description_overviews', '_details_description_restore_needed', '_details_visible_overview', '_details_visible_overview_language', '_details_visible_overview_source', '_details_visible_overview_updated_at'):
                    row.pop(_key, None)
                if _cancelled(cancel_event):
                    return current
                save_detail_snapshot(profile, media_type, src, row)
                try:
                    save_manifest(profile, media_type, src, row)
                except Exception as exc:
                    optional_failure('details_authority.language_manifest', exc)
                current = row
                if backdrop_ready and poster_ready:
                    return row
            elif backdrop_ready and poster_ready:
                return current
    try:
        resolver = ArtworkV2(credential, cfg.get('tmdb_language', 'ar-EG'), min(7, max(3, int(cfg.get('timeout', 10) or 10))))
        row = dict(current or {})
        full = resolver.resolve(profile, media_type, src, full=True, cancel_event=cancel_event, component_callback=component_callback) or {}
        if _cancelled(cancel_event):
            return current
        if isinstance(full, dict) and full.get('matched'):
            row = _merge(row, full)
        if row.get('tmdb_id') and (not _backdrop_ok(row.get('backdrop_local'))):
            locked = dict(src)
            locked['_locked_tmdb_id'] = row.get('tmdb_id')
            locked['_locked_tmdb_type'] = row.get('media_type') or ('tv' if str(media_type) == 'series' else 'movie')
            row = _merge(row, resolver.resolve_backdrop_only(profile, media_type, locked, cancel_event=cancel_event) or {})
        if _cancelled(cancel_event) or not row.get('tmdb_id'):
            return row or current
        localized = _localized_metadata(profile, media_type, src, row, cfg, cancel_event=cancel_event) or {}
        if localized:
            row = _merge(row, localized)
        if _cancelled(cancel_event):
            return current
        row['matched'] = bool(row.get('matched', True))
        row['identity_verified'] = bool(row.get('identity_verified') or row.get('identity_pointer_verified') or row.get('tmdb_id'))
        row['_details_authority_ready'] = True
        row['_details_authority_version'] = 4
        if localized:
            row['_details_metadata_language'] = _base_metadata_target(cfg)
        for _key in _DESCRIPTION_OVERLAY_KEYS + ('_details_base_description', '_description_overviews', '_details_description_restore_needed', '_details_visible_overview', '_details_visible_overview_language', '_details_visible_overview_source', '_details_visible_overview_updated_at'):
            row.pop(_key, None)
        if _cancelled(cancel_event):
            return current
        save_detail_snapshot(profile, media_type, src, row)
        try:
            save_manifest(profile, media_type, src, row)
        except Exception as exc:
            optional_failure('details_authority.manifest', exc)
        if callable(component_callback) and (not _cancelled(cancel_event)):
            try:
                component_callback('metadata', dict(row))
            except Exception:
                pass
        return row
    except Exception as exc:
        optional_failure('details_authority.resolve', exc)
        return current
_PROVIDER_FIELDS = {'overview': ('description', 'plot', 'descr', 'overview'), 'genres': ('genres', 'genre'), 'cast': ('cast', 'actors', 'actor'), 'directors': ('directors', 'director'), 'writers': ('writers', 'writer'), 'runtime': ('runtime', 'duration', 'time', 'length'), 'year': ('year', 'release_year', 'release_date', 'releaseDate'), 'countries': ('countries', 'country', 'production_countries', 'origin_country'), 'original_language': ('original_language', '_origin_language', 'original_language_code', 'originalLanguage'), 'rating': ('rating', 'rating_imdb', 'imdb_rating'), 'certification': ('certification', 'age_rating'), 'number_of_seasons': ('number_of_seasons', 'seasons_count', 'season_count'), 'number_of_episodes': ('number_of_episodes', 'episodes_count', 'episode_count')}

def _shared_fields_for(row, media_type, cfg):
    row = row if isinstance(row, dict) else {}
    ident = verified_id(row)
    if not ident and row.get('_details_authority_ready'):
        ident = row.get('tmdb_id')
    if not ident:
        return {}
    from .shared_metadata import load_shared_metadata
    return load_shared_metadata(row.get('_locked_tmdb_type') or row.get('media_type') or media_type, ident, _base_metadata_target(cfg))

def _provider_metadata_fallback(current, item, media_type, provider_client=None, cancel_event=None, profile=None, allow_copy_search=True):
    from .shared_metadata import enrich_shared_metadata, save_shared_metadata
    cfg = dict(load_settings() or {})
    from .manual_identity import selected
    if selected(item):
        return enrich_shared_metadata(current, cfg)
    out = enrich_shared_metadata(current, cfg)
    out = _provider_metadata_fallback_owned(out, item, media_type, provider_client, cancel_event)
    if _cancelled(cancel_event):
        return out
    if provider_client is not None and allow_copy_search:
        from .provider_metadata_lookup import find_arabic_copy
        text = find_arabic_copy(profile or {}, media_type, item, out, provider_client, cfg, cancel_event)
        if _cancelled(cancel_event):
            return out
        if text:
            out = enrich_shared_metadata(out, cfg)
            out['_details_provider_overview'] = text
    ident = verified_id(out)
    if not ident and out.get('_details_authority_ready'):
        ident = out.get('tmdb_id')
    if ident:
        fields = {key: out.get(key) for key in out.get('_details_provider_fields') or ()}
        fields.pop('overview', None)
        candidates = _provider_overview_values(item)
        candidates += _provider_overview_values(out.get('_details_provider_metadata'))
        own = out.get('_details_provider_overview')
        if own and ('overview' in fields or own != out.get('overview')):
            candidates.append(own)
        candidates = list((_strip_promo(_description_candidate(value)) for value in candidates))
        matches = list((value for value in candidates if _provider_matches_language(value, _base_metadata_target(cfg))))
        if matches:
            fields['overview'] = max(matches, key=len)
        save_shared_metadata(out.get('media_type') or media_type, ident, _base_metadata_target(cfg), fields)
        out = enrich_shared_metadata(out, cfg)
    return out

def remember_catalogue_metadata(media_type, item, record=None):
    """Publish an already-loaded row's fallbacks, without resolving or fetching.

    Called on page/BLUE workers and after artwork identity resolution. Reading a
    catalogue must not require focusing every title before its Arabic synopsis
    becomes available to copies in other folders. Raw provider TMDb IDs alone
    never authorize sharing; the caller supplies a verified local pointer/result.
    """
    from .verified_identity import media_kind, positive_id, exact_match
    source = item if isinstance(item, dict) else {}
    row = dict(record or source)
    ident = verified_id(row)
    if not ident and row.get('_details_authority_ready'):
        ident = positive_id(row.get('tmdb_id'))
    kind = media_kind(media_type)
    actual = media_kind(row.get('_locked_tmdb_type') or row.get('media_type')) or kind
    if not ident or not kind or actual != kind:
        return False
    row.update(tmdb_id=int(ident), media_type=kind, identity_pointer_verified=True)
    if exact_match(source, row) is False:
        return False
    try:
        _provider_metadata_fallback(row, source, media_type)
        return True
    except Exception as exc:
        optional_failure('details_authority.catalogue_metadata', exc)
        return False

def _provider_metadata_fallback_owned(current, item, media_type, provider_client=None, cancel_event=None):
    """Attach same-item fallbacks only after the TMDb lane has had its turn.

    Mark each injected field so global writers can discard it. A provider-only
    row never receives TMDb identity/completion/locale stamps.
    """
    out = dict(current or {})
    src = dict(item or {}) if isinstance(item, dict) else {}
    if _cancelled(cancel_event):
        return out
    cfg = dict(load_settings() or {})
    description_candidates = _provider_overview_values(out) + _provider_overview_values(src)
    description_candidates += _provider_overview_values(out.get('_details_provider_metadata'))
    _shared_text = '' if _own_real_arabic(description_candidates) else _shared_arabic_for(out.get('media_type') or media_type, out.get('tmdb_id'), cfg)
    if _shared_text and _shared_text not in description_candidates:
        description_candidates.append(_shared_text)
    previous = out.get('_details_provider_fields') or []
    missing = list((key for key in _PROVIDER_FIELDS if not out.get(key) or key in previous))
    need_arabic_overview = _arabic_description_missing(cfg, out, src)
    if str(media_type).lower() not in ('series', 'tv'):
        missing = list((key for key in missing if key not in ('number_of_seasons', 'number_of_episodes')))
    need_backdrop = not _backdrop_ok(out.get('backdrop_local'))
    if not missing and (not need_backdrop) and (not need_arabic_overview):
        _remember_arabic_overview(media_type, out, description_candidates, cfg)
        best_description = choose_description_for_settings(description_candidates, cfg)
        if best_description:
            out['_details_provider_overview'] = best_description
        return out
    if src.get('_xtream') and provider_client is not None and hasattr(provider_client, 'enrich_provider_artwork'):
        try:
            from .core.call_compat import call_compatible
            rich = call_compatible(provider_client.enrich_provider_artwork, (((dict(src), media_type, cancel_event), {'force': True}), ((dict(src), media_type, cancel_event), {})))
            if isinstance(rich, dict):
                description_candidates += _provider_overview_values(rich)
                src.update({k: v for k, v in rich.items() if v not in (None, '', [], {})})
        except Exception as exc:
            optional_failure('details_authority.provider_fallback', exc)
    if _cancelled(cancel_event):
        return out
    _remember_arabic_overview(media_type, out, description_candidates, cfg)
    fields = list(previous)
    for key in missing:
        if key == 'overview':
            value = _pick_provider_only(description_candidates, _base_metadata_target(cfg), cfg) or None
        else:
            value = next((src.get(alias) for alias in _PROVIDER_FIELDS[key] if src.get(alias) not in (None, '', [], {}, 0)), None)
        if value is None:
            continue
        if key == 'genres' and isinstance(value, str):
            norm = lambda text: ' '.join(us_casefold(str(text or '')).split())
            if norm(value) in {norm(src.get(k)) for k in ('category_name', 'category', 'group', 'group_title') if src.get(k)}:
                continue
        if key in ('genres', 'cast', 'directors', 'writers', 'countries') and isinstance(value, str):
            value = [part.strip() for part in re.split('[,/|]', value) if part.strip()]
        if key == 'year':
            found = re.search('\\b(?:19|20)\\d{2}\\b', str(value))
            value = found.group(0) if found else value
        if key == 'original_language':
            value = str(value).strip().lower().replace('_', '-')
            if not re.fullmatch('[a-z]{2,3}(?:-[a-z]{2})?', value):
                continue
        out[key] = value
        if key not in fields:
            fields.append(key)
        if key == 'overview':
            out['_details_provider_overview'] = str(value)
    best_description = choose_description_for_settings(description_candidates, cfg)
    if best_description:
        out['_details_provider_overview'] = best_description
    elif 'overview' not in missing and (not out.get('_details_provider_overview')):
        best_prov = _visible_provider_overview(src)
        if best_prov:
            out['_details_provider_overview'] = str(best_prov)
    if fields or need_backdrop or out.get('_details_provider_overview'):
        out['_details_provider_metadata'] = src
        out['_details_provider_fields'] = fields
    return out

def resolve_canonical(profile, media_type, item, cancel_event=None, settings=None, provider_client=None, provider_downloader=None, component_callback=None):
    """TMDb first; provider data fills only the unresolved same-item fields."""
    from .manual_identity import apply_choice, selected
    item = apply_choice(profile, media_type, item)
    if selected(item):
        provider_client = None
        provider_downloader = None
    data = _resolve_canonical_tmdb(profile, media_type, item, cancel_event=cancel_event, settings=settings, provider_client=provider_client, provider_downloader=provider_downloader, component_callback=component_callback)
    result = _provider_metadata_fallback(data, item, media_type, provider_client, cancel_event, profile)
    rich = result.get('_details_provider_metadata') or {}
    identity_keys = ('tmdb_id', 'tmdb', 'imdb_id', 'imdb', '_provider_name', 'original_name', 'original_title', 'year', 'release_date', 'releaseDate')
    if not (data or {}).get('tmdb_id') and any((rich.get(k) and rich.get(k) != (item or {}).get(k) for k in identity_keys)) and (not _cancelled(cancel_event)):
        upgraded = _resolve_canonical_tmdb(profile, media_type, rich, cancel_event=cancel_event, settings=settings, provider_client=None, provider_downloader=provider_downloader, component_callback=component_callback)
        if isinstance(upgraded, dict) and upgraded.get('tmdb_id'):
            result = _provider_metadata_fallback(upgraded, rich, media_type, provider_client, cancel_event, profile)
    return _provider_backdrop_fallback(result, profile, item, provider_client, provider_downloader, cancel_event)

def _provider_backdrop_fallback(data, profile, item, provider_client, downloader, cancel_event=None):
    """Keep provider pixels outside canonical art and completion markers."""
    out = dict(data or {})
    if _cancelled(cancel_event) or not callable(downloader) or _backdrop_ok(out.get('backdrop_local')):
        return out
    src = out.get('_details_provider_metadata') or item or {}
    try:
        from .ui_artwork_helpers import _backdrop_candidates
        for url in _backdrop_candidates(src)[:3]:
            if _cancelled(cancel_event):
                return out
            path = downloader(url, profile, provider_client, landscape=True, timeout=3.5, cancel_event=cancel_event, item=src)
            if path and _provider_backdrop_ok(path):
                out['_details_provider_backdrop_local'] = path
                provider = dict(src)
                provider['_details_provider_backdrop_local'] = path
                out['_details_provider_metadata'] = provider
                break
    except Exception as exc:
        optional_failure('details_authority.provider_backdrop_fallback', exc)
    return out

def _provider_backdrop_ok(path):
    """A real landscape may be provisional even below canonical TMDb quality."""
    try:
        if not path or not os.path.isfile(str(path)) or os.path.getsize(str(path)) <= 100:
            return False
        from PIL import Image
        with Image.open(str(path)) as image:
            width, height = image.size
            return bool(width >= 320 and height >= 180 and (float(width) / max(1, height) >= 1.25))
    except Exception:
        return False
