# -*- coding: utf-8 -*-
"""Switches for the poster-generated colour on Details, Seasons and Episodes.

ADAPTIVE_COLORS True (current): poster-adaptive HUD (tinted background, generated panel / cast /
pill glass, cinematic edge), built on a background worker after the poster loads.
False: none of that is built or shown; the three screens keep the fixed Ultra Stalker glass.

OVERVIEW_FIXED True (current): the description (overview) box always keeps the fixed-green glass,
even when the poster-generated set is applied to everything else. It never turns dark/black.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
ADAPTIVE_COLORS = True
OVERVIEW_FIXED = True
