# -*- coding: utf-8 -*-
"""Cookies, transport lifecycle and the GET/POST request engine.

Methods moved verbatim out of ``StalkerClient`` (client.py); behaviour is unchanged.
This module is imported by client.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, max, min, OSError, TimeoutError, ConnectionError, ConnectionRefusedError, us_clear
from .client import LOG, PERF, PortalAuthError, PortalCancelledError, PortalDataError, PortalError, PortalLinkError, PortalSecurityConsentError, PortalThrottleError, _bounded_gzip_decompress, endpoint_log_label, http, json, re, same_origin, socket, ssl, threading, time, urllib, validate_http_url

class ClientHttpMixin(object):
    """Cookies, transport lifecycle and the GET/POST request engine."""

    def _remember_response_cookies(self, headers):
        try:
            values = headers.get_all('Set-Cookie') or []
        except Exception:
            value = headers.get('Set-Cookie') if headers is not None else None
            values = [value] if value else []
        if not values:
            return
        with self._server_cookie_lock:
            for raw in values:
                try:
                    jar = http.cookies.SimpleCookie()
                    jar.load(str(raw))
                    for key, morsel in jar.items():
                        if key.lower() not in ('mac', 'token', 'stb_lang', 'timezone'):
                            self._server_cookies[key] = morsel.value
                except Exception:
                    pass

    def _set_current_transport(self, key, conn):
        self._transport_local.connection = (key, conn)
        with self._transport_lock:
            self._transport_connections[threading.get_ident()] = (key, conn)

    @staticmethod
    def _close_transport_socket(conn):
        try:
            sock = getattr(conn, 'sock', None)
            if sock is not None:
                sock.shutdown(socket.SHUT_RDWR)
        except OSError:
            pass
        try:
            conn.close()
        except OSError:
            pass

    def _drop_current_transport(self, close=True):
        ident = threading.get_ident()
        entry = getattr(self._transport_local, 'connection', None)
        if close and entry:
            self._close_transport_socket(entry[1])
        self._transport_local.connection = None
        with self._transport_lock:
            current = self._transport_connections.get(ident)
            if current is not None and (entry is None or current[1] is entry[1]):
                self._transport_connections.pop(ident, None)

    def close(self):
        """Release every persistent socket owned by this portal client."""
        with self._transport_lock:
            entries = list(self._transport_connections.values())
            us_clear(self._transport_connections)
            self._transport_generation += 1
        seen = set()
        for _key, conn in entries:
            marker = id(conn)
            if marker in seen:
                continue
            seen.add(marker)
            self._close_transport_socket(conn)
        self._transport_local.connection = None

    def cancel_pending_requests(self):
        """Interrupt active sockets without discarding authorization state."""
        self.close()

    def _persistent_http_get(self, url, headers, timeout, cancel_event=None, _redirects=0):
        try:
            validate_http_url(url)
        except urllib.error.URLError as exc:
            raise PortalError('Invalid portal URL: %s' % exc)
        parsed = urllib.parse.urlsplit(url)
        if parsed.scheme not in ('http', 'https') or not parsed.hostname:
            raise PortalError('Unsupported portal transport')
        verified = not self.used_unverified_tls and self.tls_mode != 'compatible'
        generation = self._transport_generation
        key = (generation, parsed.scheme, parsed.netloc, bool(verified))
        entry = getattr(self._transport_local, 'connection', None)
        conn = entry[1] if entry and entry[0] == key else None
        if conn is None:
            if entry:
                self._drop_current_transport(close=True)
            if parsed.scheme == 'https':
                context = self._tls_context(verified=verified)
                conn = http.client.HTTPSConnection(parsed.hostname, parsed.port or 443, timeout=timeout, context=context)
                if not verified:
                    conn.connect()
                    self._pin_compatible_tls_peer(conn, parsed.hostname, parsed.port or 443)
            else:
                conn = http.client.HTTPConnection(parsed.hostname, parsed.port or 80, timeout=timeout)
            self._set_current_transport(key, conn)
            PERF.increment('http.connections')
        else:
            try:
                if conn.sock is not None:
                    conn.sock.settimeout(timeout)
            except Exception:
                pass
            self._set_current_transport(key, conn)
            PERF.increment('http.keepalive_reuse')
        target = urllib.parse.urlunsplit(('', '', parsed.path or '/', parsed.query, ''))
        try:
            if cancel_event is not None and getattr(cancel_event, 'is_set', lambda: False)():
                raise PortalCancelledError('Request cancelled')
            conn.request('GET', target, headers=headers)
            response = conn.getresponse()
            if generation != self._transport_generation:
                raise PortalCancelledError('Request cancelled')
            self._remember_response_cookies(response.headers)
            chunks = []
            total = 0
            while True:
                if cancel_event is not None and getattr(cancel_event, 'is_set', lambda: False)():
                    self._drop_current_transport(close=True)
                    raise PortalCancelledError('Request cancelled')
                chunk = response.read(min(64 * 1024, self.MAX_RESPONSE_BYTES + 1 - total))
                if generation != self._transport_generation:
                    raise PortalCancelledError('Request cancelled')
                if not chunk:
                    break
                total += len(chunk)
                chunks.append(chunk)
                if total > self.MAX_RESPONSE_BYTES:
                    raise PortalDataError('Portal response is too large')
            payload = b''.join(chunks)
            status = int(response.status or 0)
            if response.will_close or str(response.headers.get('Connection', '')).lower() == 'close':
                self._drop_current_transport(close=True)
            if status in (301, 302, 303, 307, 308):
                location = str(response.headers.get('Location') or '').strip()
                if not location or _redirects >= 4:
                    raise PortalError('Portal redirect could not be resolved')
                redirected = urllib.parse.urljoin(url, location)
                try:
                    validate_http_url(redirected)
                except urllib.error.URLError as exc:
                    raise PortalError('Invalid portal redirect: %s' % exc)
                target_parts = urllib.parse.urlsplit(redirected)
                source_scheme = str(parsed.scheme or '').lower()
                target_scheme = str(target_parts.scheme or '').lower()
                source_host = str(parsed.hostname or '').lower()
                target_host = str(target_parts.hostname or '').lower()
                source_port = parsed.port or (443 if source_scheme == 'https' else 80 if source_scheme == 'http' else None)
                target_port = target_parts.port or (443 if target_scheme == 'https' else 80 if target_scheme == 'http' else None)
                approved_downgrade = source_scheme == 'https' and target_scheme == 'http' and self.allow_http_fallback
                same_origin = source_scheme == target_scheme and source_host == target_host and (source_port == target_port)
                approved_http_origin = approved_downgrade and source_host == target_host and (target_port == 80)
                if not (same_origin or approved_http_origin):
                    raise PortalError('Portal redirect changed the approved origin')
                if source_scheme == 'https' and target_scheme == 'http' and (not self.allow_http_fallback):
                    raise PortalSecurityConsentError('Portal attempted an unapproved HTTPS to HTTP redirect')
                redirect_headers = dict(headers)
                redirect_headers['Host'] = target_parts.netloc
                redirect_headers['Referer'] = url
                PERF.increment('http.redirects')
                return self._persistent_http_get(redirected, redirect_headers, timeout, cancel_event=cancel_event, _redirects=_redirects + 1)
            if status >= 400:
                raise urllib.error.HTTPError(url, status, response.reason, response.headers, None)
            return (payload, response.headers)
        except PortalError:
            self._drop_current_transport(close=True)
            raise
        except Exception:
            self._drop_current_transport(close=True)
            raise

    def _request_endpoint_post(self, endpoint, params, extra_headers=None, cancel_event=None):
        """Single bounded form-POST compatibility attempt for a proven API path."""
        if cancel_event is not None and getattr(cancel_event, 'is_set', lambda: False)():
            raise PortalCancelledError('Request cancelled')
        if not same_origin(endpoint, self.entry_url):
            raise PortalError('Portal POST fallback changed origin')
        parsed = urllib.parse.urlsplit(endpoint)
        if parsed.scheme not in ('http', 'https') or not parsed.hostname:
            raise PortalError('Unsupported portal transport')
        body = urllib.parse.urlencode(params).encode('utf-8')
        headers = self._headers()
        if extra_headers:
            headers.update(extra_headers)
        headers['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8'
        headers['Content-Length'] = str(len(body))
        timeout = self._adaptive_timeout()
        conn = None
        try:
            started = time.monotonic()
            if parsed.scheme == 'https':
                conn = http.client.HTTPSConnection(parsed.hostname, parsed.port or 443, timeout=timeout, context=self._tls_context(verified=True))
            else:
                conn = http.client.HTTPConnection(parsed.hostname, parsed.port or 80, timeout=timeout)
            target = urllib.parse.urlunsplit(('', '', parsed.path or '/', parsed.query, ''))
            conn.request('POST', target, body=body, headers=headers)
            response = conn.getresponse()
            self._remember_response_cookies(response.headers)
            status = int(response.status or 0)
            if status in (301, 302, 303, 307, 308):
                raise PortalError('Portal POST fallback returned a redirect')
            if status >= 400:
                raise urllib.error.HTTPError(endpoint, status, response.reason, response.headers, None)
            payload = response.read(self.MAX_RESPONSE_BYTES + 1)
            if len(payload) > self.MAX_RESPONSE_BYTES:
                raise PortalDataError('Portal response is too large')
            if str(response.headers.get('Content-Encoding', '')).lower() == 'gzip':
                payload = _bounded_gzip_decompress(payload, self.MAX_RESPONSE_BYTES)
            raw = payload.decode('utf-8-sig', 'replace').strip()
            elapsed_ms = int((time.monotonic() - started) * 1000)
            PERF.record('http.request_ms', elapsed_ms)
            PERF.increment('http.requests')
            self._record_success(elapsed_ms)
            if not raw:
                raise PortalDataError('Portal returned empty data')
            try:
                return json.loads(raw)
            except (ValueError, TypeError):
                snippet = re.sub('\\s+', ' ', raw)[:110]
                raise PortalDataError('Portal returned non-JSON data%s' % (': ' + snippet if snippet else ''))
        except urllib.error.HTTPError as exc:
            if exc.code in (401, 403):
                raise PortalAuthError('HTTP %s authorization failed' % exc.code)
            if exc.code == 429:
                raise PortalThrottleError('HTTP 429 rate limit')
            raise PortalError('HTTP %s' % exc.code)
        finally:
            try:
                if conn is not None:
                    conn.close()
            except Exception:
                pass

    def _request_endpoint(self, endpoint, params, extra_headers=None, cancel_event=None, max_attempts=None):
        self._check_circuit()
        preferred_method = str(self._compat_endpoint_methods.get(endpoint) or '').upper()
        if preferred_method == 'POST':
            try:
                data = self._request_endpoint_post(endpoint, params, extra_headers=extra_headers, cancel_event=cancel_event)
                return data
            except PortalCancelledError:
                raise
            except PortalError:
                self._compat_endpoint_methods.pop(endpoint, None)
                if endpoint == self._compat_cached_endpoint:
                    self._persist_compat_state(method='')
        url = endpoint + '?' + urllib.parse.urlencode(params)
        attempts = len(self.RETRY_DELAYS) + 1
        if max_attempts is not None:
            try:
                attempts = max(1, min(attempts, int(max_attempts)))
            except (TypeError, ValueError):
                pass
        last_error = None
        attempt = 0
        while attempt < attempts:
            headers = self._headers()
            if extra_headers:
                headers.update(extra_headers)
            retryable = False
            try:
                started = time.monotonic()
                payload, response_headers = self._persistent_http_get(url, headers, self._adaptive_timeout(), cancel_event=cancel_event)
                if str(response_headers.get('Content-Encoding', '')).lower() == 'gzip':
                    payload = _bounded_gzip_decompress(payload, self.MAX_RESPONSE_BYTES)
                raw = payload.decode('utf-8-sig', 'replace').strip()
                elapsed_ms = int((time.monotonic() - started) * 1000)
                PERF.record('http.request_ms', elapsed_ms)
                PERF.increment('http.requests')
                self._record_success(elapsed_ms)
                try:
                    return json.loads(raw)
                except (ValueError, TypeError):
                    snippet = re.sub('\\s+', ' ', raw)[:110]
                    raise PortalDataError('Portal returned non-JSON data%s' % (': ' + snippet if snippet else ''))
            except urllib.error.HTTPError as exc:
                if exc.code in (401, 403):
                    last_error = PortalAuthError('HTTP %s authorization failed' % exc.code)
                elif exc.code in (429, 469):
                    last_error = PortalThrottleError('HTTP %s rate limit' % exc.code)
                    retryable = attempt == 0
                    if retryable:
                        delay = 1.6
                        try:
                            hint = float(str((getattr(exc, 'headers', None) or {}).get('Retry-After', '')).strip())
                            if 0 < hint <= 10:
                                delay = max(1.0, hint)
                        except (TypeError, ValueError, AttributeError):
                            pass
                        if cancel_event is not None and getattr(cancel_event, 'wait', lambda _x: False)(delay):
                            raise PortalCancelledError('Request cancelled')
                        if cancel_event is None:
                            time.sleep(delay)
                        attempt += 1
                        continue
                else:
                    last_error = PortalError('HTTP %s' % exc.code)
                if exc.code not in (429, 469):
                    retryable = exc.code in self.RETRY_CODES
            except ssl.SSLCertVerificationError as exc:
                if self.tls_mode == 'auto' and (not self.used_unverified_tls) and self.allow_tls_fallback:
                    self._enable_compatible_tls()
                    continue
                last_error = PortalSecurityConsentError('TLS certificate verification failed. This hardened build does not allow unverified TLS.')
                retryable = False
            except urllib.error.URLError as exc:
                reason = getattr(exc, 'reason', exc)
                if self.tls_mode == 'auto' and (not self.used_unverified_tls) and self.host.startswith('https://') and self._is_certificate_error(reason):
                    if self.allow_tls_fallback:
                        self._enable_compatible_tls()
                        continue
                    last_error = PortalSecurityConsentError('TLS certificate verification failed. This hardened build does not allow unverified TLS.')
                    retryable = False
                else:
                    LOG.warning('Portal connection transport error endpoint=%s action=%s detail=%s', endpoint, params.get('action'), reason)
                    if isinstance(reason, socket.gaierror):
                        last_error = PortalError('Portal host could not be resolved')
                    elif isinstance(reason, ConnectionRefusedError):
                        last_error = PortalError('Portal connection was refused')
                    else:
                        last_error = PortalError('Portal connection failed')
                    retryable = isinstance(reason, (socket.timeout, TimeoutError, OSError))
            except (socket.timeout, TimeoutError):
                last_error = PortalError('Connection timed out')
                retryable = True
            except (http.client.HTTPException, ConnectionError, OSError) as exc:
                LOG.warning('Portal connection transport error endpoint=%s action=%s detail=%s', endpoint, params.get('action'), exc)
                if isinstance(exc, ConnectionRefusedError):
                    last_error = PortalError('Portal connection was refused')
                else:
                    last_error = PortalError('Portal connection failed')
                retryable = True
            except PortalError as exc:
                last_error = exc
                retryable = False
            except Exception as exc:
                LOG.exception('Unexpected portal request failure endpoint=%s action=%s', endpoint, params.get('action'))
                last_error = PortalError('Portal request failed')
                retryable = False
            if not retryable or attempt >= attempts - 1:
                break
            delay = self.RETRY_DELAYS[min(attempt, len(self.RETRY_DELAYS) - 1)]
            if cancel_event is not None and getattr(cancel_event, 'wait', lambda _x: False)(delay):
                raise PortalCancelledError('Request cancelled')
            if cancel_event is None:
                time.sleep(delay)
            attempt += 1
        message = str(last_error or '').lower()
        post_eligible = isinstance(last_error, (PortalDataError, PortalAuthError)) or 'http 405' in message
        if post_eligible:
            try:
                data = self._request_endpoint_post(endpoint, params, extra_headers=extra_headers, cancel_event=cancel_event)
                self._compat_endpoint_methods[endpoint] = 'POST'
                LOG.info('Portal API method fallback accepted: POST %s', endpoint_log_label(endpoint))
                return data
            except PortalCancelledError:
                raise
            except PortalError as exc:
                last_error = exc
        raise last_error or PortalError('Portal request failed')

    def _get_once(self, params, use_cache=False, extra_headers=None, cancel_event=None):
        if use_cache:
            cached = self._cache_get(params)
            if cached is not None:
                return cached
        errors = []
        security_consent_error = None
        action = str((params or {}).get('action') or '').strip().lower()
        playback_link = bool(getattr(self._priority_local, 'playback', False) and action == 'create_link')
        endpoints = list(self._candidate_endpoints())
        preferred_playback_endpoint = ''
        if playback_link:
            pinned = str(getattr(self._priority_local, 'playback_endpoint', '') or '').strip()
            for candidate in (pinned, self.endpoint, self._compat_cached_endpoint):
                candidate = str(candidate or '').strip()
                if candidate and candidate in endpoints:
                    preferred_playback_endpoint = candidate
                    break
            if preferred_playback_endpoint:
                endpoints = [preferred_playback_endpoint] + list((endpoint for endpoint in endpoints if endpoint != preferred_playback_endpoint))
        proven_endpoint = str(self.endpoint or '').strip()
        pin_proven = bool(not playback_link and proven_endpoint and endpoints and (endpoints[0] == proven_endpoint) and (action not in ('handshake', 'do_auth', 'get_profile', 'get_main_info', 'login', '')) and (not self.used_http_fallback))
        for endpoint in endpoints:
            try:
                data = self._request_endpoint(endpoint, params, extra_headers=extra_headers, cancel_event=cancel_event, max_attempts=1 if playback_link else None)
                self.endpoint = endpoint
                self.portal = endpoint
                if playback_link:
                    self._priority_local.playback_endpoint = endpoint
                self._persist_transport_state()
                if endpoint == self._compat_cached_endpoint or endpoint in self._compat_discovered_candidates or self._compat_endpoint_methods.get(endpoint) == 'POST':
                    method = self._compat_endpoint_methods.get(endpoint) or 'GET'
                    self._persist_compat_state(endpoint=endpoint, method=method)
                if use_cache:
                    self._cache_put(params, data)
                return data
            except PortalCancelledError:
                raise
            except PortalSecurityConsentError as exc:
                security_consent_error = exc
                errors.append('%s: %s' % (endpoint, exc))
            except PortalError as exc:
                message = str(exc).lower()
                if any((marker in message for marker in ('http 469', 'http 429', 'rate limit'))):
                    raise
                if 'temporarily paused after repeated failures' in str(exc).lower():
                    raise
                message = str(exc).lower()
                endpoint_invalid = any((marker in message for marker in ('http 404', 'http 405', 'non-json', 'empty data')))
                if str(params.get('action') or '').lower() == 'handshake' and 'http 403' in message:
                    endpoint_invalid = True
                if endpoint == self._compat_cached_endpoint and endpoint_invalid:
                    self._invalidate_compat_endpoint(endpoint)
                    LOG.info('Cached portal endpoint invalidated: %s', endpoint_log_label(endpoint))
                errors.append('%s: %s' % (endpoint, exc))
                if playback_link and preferred_playback_endpoint and (endpoint == preferred_playback_endpoint) and (not endpoint_invalid):
                    raise
                if pin_proven and endpoint == proven_endpoint and (not endpoint_invalid) and (not any((m in message for m in ('http 404', 'http 405')))):
                    self._record_failure()
                    raise
        if self.allow_http_fallback and (not self.used_http_fallback) and self.host.startswith('https://'):
            self.host = 'http://' + self.host[8:]
            self.entry_url = 'http://' + self.entry_url[8:]
            self.referer = 'http://' + self.referer[8:]
            self.endpoint = None
            self.used_http_fallback = True
            self.security_warning = 'WARNING: HTTPS unavailable; using insecure HTTP'
            return self._get_once(params, use_cache=use_cache, extra_headers=extra_headers, cancel_event=cancel_event)
        if security_consent_error is not None:
            self._record_failure()
            raise security_consent_error
        self._record_failure()
        raise PortalError(errors[-1] if errors else 'No usable portal endpoint')

    @classmethod
    def _has_auth_marker(cls, obj, depth=0):
        """Cheap scan for portal auth-error text.

        Auth failures arrive as a short message string or a small dict
        (``{"error": "..."}``).  Only strings, small dicts and short lists are
        inspected; big catalogue lists are never serialised or walked.
        """
        if isinstance(obj, str):
            low = obj[:4096].lower()
            return any((m in low for m in cls._AUTH_MARKERS))
        if depth >= 3:
            return False
        if isinstance(obj, dict):
            if len(obj) > 64:
                return False
            return any((cls._has_auth_marker(v, depth + 1) for v in obj.values() if isinstance(v, (str, dict, list))))
        if isinstance(obj, list):
            if len(obj) > 16:
                return False
            return any((cls._has_auth_marker(v, depth + 1) for v in obj if isinstance(v, (str, dict, list))))
        if obj is None or isinstance(obj, (bool, int, float)):
            return False
        return any((m in str(obj).lower() for m in cls._AUTH_MARKERS))

    def _get(self, params, use_cache=False, retry_auth=True, extra_headers=None, cancel_event=None):
        seen_token = self.token
        try:
            data = self._get_once(params, use_cache=use_cache, extra_headers=extra_headers, cancel_event=cancel_event)
            unwrapped = self._unwrap(data)
            if retry_auth and params.get('action') != 'handshake' and self._has_auth_marker(unwrapped):
                self._reauthorize(seen_token, cancel_event=cancel_event)
                return self._get_once(params, use_cache=False, extra_headers=extra_headers, cancel_event=cancel_event)
            return data
        except PortalError as exc:
            message = str(exc).lower()
            if retry_auth and params.get('action') != 'handshake' and any((marker in message for marker in ('http 401', 'http 403', 'authorization', 'token'))):
                self._reauthorize(seen_token, cancel_event=cancel_event)
                return self._get_once(params, use_cache=False, extra_headers=extra_headers, cancel_event=cancel_event)
            raise

    def _reset_auth(self):
        with self._auth_lock:
            self.token = None
            self.token_random = ''
            self.play_token = ''
            self.profile_initialized = False
            self.account_valid = False

    @staticmethod
    def _is_auth_playback_error(exc):
        if isinstance(exc, PortalAuthError):
            return True
        message = str(exc or '').lower()
        return any((marker in message for marker in ('http 401', 'http 403', 'authorization', 'not valid token', 'token expired', 'invalid token', 'expired token')))

    @staticmethod
    def _is_transient_playback_transport_error(exc):
        """Return True only for one-shot transport/response faults worth replaying.

        Playback gets one fresh-socket replay for failures that are commonly
        caused by a stale keep-alive or a truncated middleware response.  Auth,
        throttle, security-consent and semantic link failures deliberately stay
        outside this lane.
        """
        if isinstance(exc, (PortalAuthError, PortalThrottleError, PortalSecurityConsentError, PortalCancelledError, PortalLinkError)):
            return False
        if isinstance(exc, PortalDataError):
            return True
        message = str(exc or '').lower()
        return any((marker in message for marker in ('connection failed', 'connection timed out', 'timed out', 'connection was refused', 'host could not be resolved', 'returned empty data', 'non-json', 'remote end closed', 'connection reset', 'broken pipe', 'http 408', 'http 500', 'http 502', 'http 503', 'http 504')))

    def _playback_request_once_more_on_fresh_transport(self, request_callable):
        """Run one playback API call with a bounded fresh-socket replay.

        Normal portal traffic keeps persistent keep-alive for performance.  An
        explicit Play action is rare and latency-sensitive in a different way:
        if a pooled worker inherited a stale socket, retry exactly once after
        dropping only that thread's transport.  Authorization state is preserved.
        """
        try:
            return request_callable()
        except PortalCancelledError:
            raise
        except PortalError as exc:
            if not self._is_transient_playback_transport_error(exc):
                raise
            try:
                self._drop_current_transport(close=True)
            except Exception:
                pass
            LOG.info('Playback transport replay on fresh socket after %s', exc.__class__.__name__)
            return request_callable()
