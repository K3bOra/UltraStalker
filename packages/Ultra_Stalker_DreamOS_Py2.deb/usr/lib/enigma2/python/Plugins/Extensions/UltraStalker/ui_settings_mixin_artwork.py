# -*- coding: utf-8 -*-
"""Global artwork preload state and worker.

Methods moved verbatim out of ``NovaSettingsScreen`` (ui_screens_settings.py); behaviour is unchanged.
This module is imported by ui_screens_settings.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str, int, open, max, min
threading = _us_env.threading
from .ui_screens_settings import (
    _profile_hidden_ids,
    _queue,
    _time,
)


class SettingsArtworkMixin(object):
    """Global artwork preload state and worker."""

    def _global_artwork_state_path(self):
        try:return os.path.join(os.path.dirname(str(IMAGE_CACHE_DIR).rstrip("/")),"global_artwork_preload.json")
        except Exception:return ""

    def _global_artwork_source_key(self):
        profile=dict(self.profile or {})
        raw="|".join((
            str(profile.get("portal") or profile.get("url") or "").rstrip("/").lower(),
            str(profile.get("mac") or "").upper(),
            str(profile.get("source_type") or profile.get("type") or "portal").lower(),
            str(profile.get("username") or profile.get("user") or profile.get("login") or "").strip().lower(),
        ))
        return hashlib.sha1(raw.encode("utf-8","ignore")).hexdigest()[:20]

    def _global_artwork_source_label(self):
        profile=dict(self.profile or {})
        return str(profile.get("name") or profile.get("portal") or profile.get("url") or "Current source")

    def _load_global_artwork_state(self):
        path=self._global_artwork_state_path()
        if not path or not os.path.isfile(path):return {}
        try:
            with open(path,"r",encoding="utf-8") as h:data=json.load(h)
            if not isinstance(data,dict):return {}
            sources=data.get("sources") if isinstance(data.get("sources"),dict) else {}
            state=sources.get(self._global_artwork_source_key()) if sources else None
            return dict(state) if isinstance(state,dict) else {}
        except Exception:return {}

    def _save_global_artwork_state(self,data):
        path=self._global_artwork_state_path()
        if not path:return
        try:
            old={}
            try:
                if os.path.isfile(path):
                    with open(path,"r",encoding="utf-8") as h:old=json.load(h)
            except Exception:old={}
            if not isinstance(old,dict) or not isinstance(old.get("sources"),dict):old={"schema":2,"sources":{}}
            old["schema"]=2;old.setdefault("sources",{})
            clean=dict(data or {});clean["source_key"]=self._global_artwork_source_key();clean["source_label"]=self._global_artwork_source_label()
            old["sources"][self._global_artwork_source_key()]=clean
            temp=path+".tmp.%d.%d" % (os.getpid(), threading.get_ident())
            os.makedirs(os.path.dirname(path),exist_ok=True)
            with open(temp,"w",encoding="utf-8") as h:
                json.dump(old,h,ensure_ascii=False,sort_keys=True)
                h.flush();os.fsync(h.fileno())
            os.replace(temp,path)
        except Exception as exc:optional_failure("ui.global_artwork_state",exc)

    def _global_artwork_value(self):
        if self._global_artwork_running:return _("RUNNING")
        state=self._global_artwork_last or self._load_global_artwork_state()
        if not isinstance(state,dict) or not state.get("total"):return _("START")
        total=int(state.get("total",0) or 0);ready=int(state.get("ready",0) or 0);failed=int(state.get("failed",0) or 0)
        return ((_("%d/%d READY")%(ready,total))+((_(" • %d MISS")%failed) if failed else ""))

    def _drain_global_artwork_progress(self):
        latest=None
        while True:
            try:latest=self._global_artwork_progress.get_nowait()
            except _queue.Empty:break
            except Exception:break
        if not latest:return
        kind=latest[0] if isinstance(latest,(tuple,list)) and latest else ""
        if kind=="scan":
            _k,label,media,category_done,category_total,found=latest
            self["status"].setText(_("Current Artwork • %s • %s categories %d/%d • %d titles counted")%(
                str(label),str(media),int(category_done or 0),int(category_total or 0),int(found or 0)))
        elif kind=="scan_request":
            _k,label,media,scope,page,found=latest
            self["status"].setText(_("Current Artwork • %s • %s • reading %s page %d • %d titles counted")%(
                str(label),str(media),str(scope),int(page or 1),int(found or 0)))
        elif kind=="scan_catalog":
            _k,label,media,page,pages,found,expected=latest
            if int(pages or 0)>0:
                self["status"].setText(_("Current Artwork • %s • %s catalog pages %d/%d • %d/%d titles counted")%(
                    str(label),str(media),int(page or 1),int(pages or 1),int(found or 0),max(int(found or 0),int(expected or 0))))
            else:
                self["status"].setText(_("Current Artwork • %s • %s catalog page %d • %d titles counted")%(
                    str(label),str(media),int(page or 1),int(found or 0)))
        elif kind=="scan_category":
            _k,label,media,category_done,category_total,page,pages,found=latest
            suffix=(_(" • page %d/%d")%(int(page or 1),int(pages or 1))) if int(pages or 0)>0 else (_(" • page %d")%int(page or 1))
            self["status"].setText(_("Current Artwork • %s • %s categories %d/%d%s • %d titles counted")%(
                str(label),str(media),int(category_done or 0),int(category_total or 0),suffix,int(found or 0)))
        elif kind=="inventory_progress":
            _k,checked,total,ready,pending=latest
            self["status"].setText(_("Current Artwork • HDD check %d/%d • Ready %d • Need work %d")%(
                int(checked),int(total),int(ready),int(pending)))
        elif kind=="inventory":
            _k,total,ready,pending=latest
            self["status"].setText(_("Current Artwork • Total %d • Ready on HDD %d • Need work %d")%(
                int(total),int(ready),int(pending)))
        elif kind=="progress":
            _k,done,total,already,downloaded,local_built,failed=latest
            remaining=max(0,int(total)-int(done))
            self["status"].setText(_("Current Artwork • %d/%d processed • Already ready %d • Downloaded %d • Local build %d • Remaining %d • Unavailable %d")%(
                int(done),int(total),int(already),int(downloaded),int(local_built),remaining,int(failed)))

    @staticmethod
    def _global_profile_key(profile):
        profile=profile if isinstance(profile,dict) else {}
        return (str(profile.get("portal") or "").rstrip("/").lower(),str(profile.get("mac") or "").upper(),str(profile.get("source_type") or "").lower())

    @staticmethod
    def _global_category_id(row):
        row=row if isinstance(row,dict) else {}
        return str(row.get("id") or row.get("genre_id") or row.get("category_id") or row.get("name") or row.get("title") or "*")

    def _global_artwork_host(self,profile,client,media_type,progress_cb=None):
        # Generic Poster/Grid artwork host only.  Deliberately independent from
        # Generic Poster/Grid artwork host: preload never depends on a presentation-specific renderer.
        from .ui_grid_base import PremiumGridBase
        host=object.__new__(PremiumGridBase)
        host.profile=dict(profile or {});host.client=client;host.media_type=str(media_type)
        host._grid_settings=load_settings();host._grid_image_size=(250,310);host._poster_cover_mode=True
        host._folder_artwork_heavy_finalize=False;host._folder_artwork_worker_limit=1;host._screen_closed=False
        host._folder_artwork_progress=_queue.Queue();host._folder_artwork_cache_done=0;host._folder_artwork_cache_total=0
        host._folder_artwork_progress_offset=0;host._folder_artwork_progress_total_override=0
        host._folder_artwork_progress_callback=progress_cb
        return host

    def _global_artwork_item_ready(self,profile,media_type,item):
        # Poster Grid / content-owned originals are the readiness source.  HDD only:
        # no manifests/network/TMDB are touched by this inventory check.
        def valid(path):
            try:return bool(path and os.path.isfile(str(path)) and os.path.getsize(str(path))>256)
            except Exception:return False
        try:
            owned=_load_content_art(profile,media_type,item) or {}
        except Exception:
            owned={}
        poster=str((owned or {}).get("poster") or "");backdrop=str((owned or {}).get("backdrop") or "")
        if valid(poster) and valid(backdrop):return True
        try:
            visual=_load_visual_bundle(profile,media_type,item,snapshot={}) or {}
        except Exception:
            visual={}
        if not valid(poster):poster=str((visual or {}).get("poster") or "")
        if not valid(backdrop):backdrop=str((visual or {}).get("backdrop") or "")
        return bool(valid(poster) and valid(backdrop))

    def _global_artwork_collect(self,cancel_event):
        _nl_found = [None]
        from .persistent_cache import content_cache_key
        # Current source only.  Fast path asks the provider for category="*" and
        # walks native pages, which is the same catalogue API the old Poster Grid
        # already trusts.  This avoids serially opening hundreds of categories
        # (e.g. 443) before the first counter can move.  Category-by-category is
        # retained only as a compatibility fallback for panels that reject "*".
        profile=dict(self.profile or {})
        if not profile:return []
        client=self.client;label=self._global_artwork_source_label()
        groups=[];seen=set();_nl_found[0]=0;cfg=load_settings();max_pages=max(25,min(int(cfg.get("search_max_pages",250) or 250),500))

        def add_rows(media,rows,bucket):
            pass
            added=0
            for item in rows if isinstance(rows,list) else []:
                if not isinstance(item,dict):continue
                try:key=str(content_cache_key(profile,media,item) or "")
                except Exception:key="%s|%s|%s"%(self._global_profile_key(profile),media,str(item.get("id") or item.get("movie_id") or item.get("series_id") or item.get("name") or item.get("title") or ""))
                global_key=(media,key)
                if global_key in seen:continue
                seen.add(global_key);bucket.append(dict(item));_nl_found[0]+=1;added+=1
            return added

        def scan_pages(media,gid,bucket,scope,category_done=0,category_total=0):
            page=1;previous_signature=None;added_total=0
            for _ in range(max_pages):
                if cancel_event is not None and cancel_event.is_set():return added_total
                self._global_artwork_progress.put(("scan_request",label,(_("Movies") if media=="vod" else _("Series")),scope,page,len(bucket)))
                try:payload=client.ordered_page(media,gid,page,cancel_event=cancel_event) or {}
                except Exception as exc:
                    optional_failure("ui.global_artwork_catalog_page",exc);break
                rows=list(x for x in (payload.get("items") or []) if isinstance(x,dict)) if isinstance(payload,dict) else []
                if not rows:break
                signature=tuple(str(x.get("id") or x.get("movie_id") or x.get("series_id") or x.get("name") or x.get("title") or "") for x in rows[:4])
                if page>1 and signature and signature==previous_signature:break
                previous_signature=signature
                added=add_rows(media,rows,bucket);added_total+=added
                total=max(0,int(payload.get("total") or 0)) if isinstance(payload,dict) else 0
                page_size=max(1,int(payload.get("page_size") or len(rows) or 1)) if isinstance(payload,dict) else max(1,len(rows))
                pages=((total+page_size-1)//page_size) if total else 0
                if category_total:
                    self._global_artwork_progress.put(("scan_category",label,(_("Movies") if media=="vod" else _("Series")),category_done,category_total,page,pages,len(bucket)))
                else:
                    self._global_artwork_progress.put(("scan_catalog",label,(_("Movies") if media=="vod" else _("Series")),page,pages,len(bucket),total))
                if total and page*page_size>=total:break
                if not total and len(rows)<page_size:break
                page+=1
            return added_total

        for media in ("vod","series"):
            if cancel_event is not None and cancel_event.is_set():return []
            bucket=[]
            hidden=_profile_hidden_ids(cfg,profile,media)
            # Wildcard catalogues are safe only when nothing is hidden. When the
            # user hides folders, enumerate visible category IDs so hidden content
            # is never fetched by the background artwork worker.
            wildcard_added=scan_pages(media,"*",bucket,"catalog") if not hidden else 0
            if wildcard_added<=0:
                try:categories=client.genres(media,cancel_event=cancel_event) or []
                except Exception as exc:
                    optional_failure("ui.global_artwork_genres",exc);categories=[]
                category_ids=[]
                for row in categories if isinstance(categories,list) else []:
                    if isinstance(row,dict):
                        gid=self._global_category_id(row)
                        if gid and gid not in hidden and gid not in category_ids:category_ids.append(gid)
                category_total=len(category_ids)
                for cidx,gid in enumerate(category_ids,1):
                    if cancel_event is not None and cancel_event.is_set():return []
                    self._global_artwork_progress.put(("scan",label,(_("Movies") if media=="vod" else _("Series")),cidx-1,category_total,len(bucket)))
                    scan_pages(media,gid,bucket,"category",cidx,category_total)
            if bucket:groups.append((dict(profile),client,media,bucket))
        return groups

    def _global_artwork_worker(self,cancel_event):
        groups=self._global_artwork_collect(cancel_event)
        if cancel_event is not None and cancel_event.is_set():return {"cancelled":True}
        total=sum(len(rows) for _p,_c,_m,rows in groups)
        ready=0;checked=0;pending_groups=[]
        for profile,client,media,rows in groups:
            host=self._global_artwork_host(profile,client,media)
            pending=[]
            for item in rows:
                if cancel_event is not None and cancel_event.is_set():return {"cancelled":True}
                checked+=1
                if self._global_artwork_item_ready(profile,media,item):ready+=1
                else:pending.append(item)
                if checked==1 or checked==total or checked%5==0:
                    self._global_artwork_progress.put(("inventory_progress",checked,total,ready,checked-ready))
            if pending:pending_groups.append((profile,client,media,pending))
        self._global_artwork_progress.put(("inventory",total,ready,total-ready))
        if total<=0:return {"total":0,"ready":0,"already":0,"downloaded":0,"local_built":0,"failed":0}
        if not pending_groups:return {"total":total,"ready":total,"already":total,"downloaded":0,"local_built":0,"failed":0,"nothing_missing":True}
        processed=0;downloaded=0;local_built=0;failed=0
        for profile,client,media,rows in pending_groups:
            if cancel_event is not None and cancel_event.is_set():return {"cancelled":True}
            base_processed=processed;base_downloaded=downloaded;base_local=local_built;base_failed=failed
            def pcb(done,_group_total,stats,bp=base_processed,bd=base_downloaded,bl=base_local,bf=base_failed):
                self._global_artwork_progress.put(("progress",ready+bp+int(done or 0),total,ready,bd+int(stats.get("downloaded",0) or 0),bl+int(stats.get("hot",0) or 0),bf+int(stats.get("failed",0) or 0)))
            host=self._global_artwork_host(profile,client,media,pcb)
            result=host._cache_folder_artwork_worker(rows,cancel_event) or {}
            processed+=int(result.get("done",0) or 0);downloaded+=int(result.get("downloaded",0) or 0);local_built+=int(result.get("hot",0) or 0);failed+=int(result.get("failed",0) or 0)
            self._global_artwork_progress.put(("progress",ready+processed,total,ready,downloaded,local_built,failed))
        final_ready=max(0,total-failed)
        return {"total":total,"ready":final_ready,"already":ready,"downloaded":downloaded,"local_built":local_built,"failed":failed}

    def _start_global_artwork_preload(self):
        # Always count the CURRENT source first.  This deliberately does not trust
        # an old total blindly: a Portal/Xtream catalogue may have gained titles.
        # The count/HDD check is cheap compared with artwork download, and matching
        # canonical files prepared from another source are reused immediately.
        if self._global_artwork_running or self._busy:
            self["status"].setText(_("Current Artwork preload is already running"));return
        self._global_artwork_running=True;self.refresh()
        self["status"].setText(_("Current Artwork • opening current source catalog..."))
        def ok(result):
            self._global_artwork_running=False;result=result or {}
            if result.get("cancelled"):
                self["status"].setText(_("Current Artwork preload cancelled"));self.refresh();return
            total=int(result.get("total",0) or 0);ready=int(result.get("ready",0) or 0);already=int(result.get("already",0) or 0);downloaded=int(result.get("downloaded",0) or 0);local_built=int(result.get("local_built",0) or 0);failed=int(result.get("failed",0) or 0)
            state={"schema":2,"completed_at":int(_time.time()),"total":total,"ready":ready,"already":already,"downloaded":downloaded,"local_built":local_built,"failed":failed}
            self._global_artwork_last=state;self._save_global_artwork_state(state);self.refresh()
            if result.get("nothing_missing") or (total and ready==total and downloaded==0 and local_built==0 and failed==0):
                self["status"].setText(_("Current Artwork already ready • checked %d/%d • everything is on HDD • 0 remaining")%(ready,total))
            elif total and ready==total:
                self["status"].setText(_("Current Artwork ready • %d/%d on HDD • %d already ready • %d downloaded • %d local builds • 0 remaining")%(ready,total,already,downloaded,local_built))
            else:
                self["status"].setText(_("Current Artwork finished • %d/%d ready • %d downloaded • %d local builds • %d unavailable")%(ready,total,downloaded,local_built,failed))
        def fail(error):
            self._global_artwork_running=False;self.refresh();self["status"].setText(_("Current Artwork failed: %s")%str(error or _("Unknown error")))
        self._run_async(lambda handle:self._global_artwork_worker(handle.cancel_event),ok,fail)
