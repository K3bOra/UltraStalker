# -*- coding: utf-8 -*-
from __future__ import absolute_import, division, print_function, unicode_literals
from .. import us_env as _us_env
from ..us_env import str, int, open, min, max, OSError, us_casefold
from ..version import PLUGIN_VERSION
from .. import _
from ..title_clean import display_title as _subtitle_display_title, tmdb_search_aliases as _subtitle_search_aliases
hashlib = _us_env.hashlib
json = _us_env.json
os = _us_env.os
re = _us_env.re
threading = _us_env.threading
import unicodedata
import zipfile
urlencode = _us_env.urllib.parse.urlencode
Request = _us_env.urllib.request.Request
urlopen = _us_env.urllib.request.urlopen
SUBDL_SEARCH = 'https://api.subdl.com/api/v1/subtitles'
SUBDL_DOWNLOAD = 'https://dl.subdl.com'
SUBSOURCE_BASE = 'https://api.subsource.net/api/v1'
CONFIG_DIR = '/etc/enigma2/ultrastalker'
CACHE_DIR = '/media/hdd/UltraStalker/subtitles'

def _safe_int(value):
    try:
        value = str(value or '').strip()
        if not value:
            return 0
        m = re.search('\\d+', value)
        return int(m.group(0)) if m else 0
    except Exception:
        return 0

def _pick(item, *keys):
    for key in keys:
        value = item.get(key) if isinstance(item, dict) else None
        if value not in (None, ''):
            return value
    return None

def _load_tmdb_record(kind, tmdb_id):
    if not tmdb_id:
        return {}
    try:
        from ..media_library import load as _lib_load
        rec = _lib_load(kind, tmdb_id)
        if isinstance(rec, dict):
            return rec
    except Exception:
        pass
    return {}

def _identity(item, media_type, display_name=''):
    item = item if isinstance(item, dict) else {}
    kind = 'tv' if str(media_type or '').lower() in ('series', 'episode') else 'movie'
    title = str(_pick(item, '_series_title', 'series_name', 'name', 'title', 'movie_name') or display_name or '').strip()
    year = _safe_int(_pick(item, 'year', 'release_year', 'releasedate', 'release_date', 'first_air_date'))
    if not year and title:
        ym = re.search('\\b((?:19|20)\\d{2})\\b', title)
        if ym:
            year = _safe_int(ym.group(1))
    tmdb = str(_pick(item, 'tmdb_id', 'tmdb', '_tmdb_id', 'tmdbId', '_locked_tmdb_id', '_ultra_search_verified_tmdb_id') or '').strip()
    imdb = str(_pick(item, 'imdb_id', 'imdb', '_imdb_id', 'imdbId') or '').strip()
    if tmdb and (not imdb or not year):
        rec = _load_tmdb_record(kind, tmdb)
        if not imdb and rec.get('imdb_id'):
            imdb = str(rec.get('imdb_id') or '').strip()
        if not year:
            year = _safe_int(rec.get('year') or rec.get('release_date') or rec.get('first_air_date'))
    season = _safe_int(_pick(item, 'season_number', 'season', '_season_number', 'season_num'))
    episode = _safe_int(_pick(item, 'episode_number', 'episode', '_episode_number', 'episode_num', 'number'))
    return {'type': kind, 'title': title, 'year': year, 'tmdb_id': tmdb, 'imdb_id': imdb, 'season': season, 'episode': episode}

def _extra_item_titles(item, ident):
    item = item if isinstance(item, dict) else {}
    out = []
    for k in ('original_title', 'original_name', 'english_title', 'english_name', 'o_name', 'movie_name', 'series_name', 'title', 'name'):
        v = str(item.get(k) or '').strip()
        if v and v not in out:
            out.append(v)
    tmdb_id = (ident or {}).get('tmdb_id')
    kind = (ident or {}).get('type') or 'movie'
    if tmdb_id:
        rec = _load_tmdb_record(kind, tmdb_id)
        for k in ('original_title', 'original_name', 'title', 'name'):
            v = str(rec.get(k) or '').strip()
            if v and v not in out:
                out.append(v)
    return out

def _cache_key(identity):
    raw = json.dumps(identity, sort_keys=True, ensure_ascii=True)
    return hashlib.sha1(raw.encode('utf-8')).hexdigest()

def _ensure_cache():
    for path in (CACHE_DIR, '/tmp/UltraStalker-subtitles'):
        try:
            if str(path).startswith('/media/'):
                try:
                    from ..persistent_cache import hdd_ready as _sub_hdd_ready
                    if not _sub_hdd_ready():
                        continue
                except Exception:
                    if not os.path.ismount('/media/hdd'):
                        continue
            os.makedirs(path, mode=448, exist_ok=True)
            probe = os.path.join(path, '.write-test')
            with open(probe, 'w') as h:
                h.write('1')
            os.unlink(probe)
            return path
        except Exception:
            pass
    return '/tmp'

def cached_subtitle(item, media_type, display_name=''):
    ident = _identity(item, media_type, display_name)
    root = _ensure_cache()
    prefix = _cache_key(ident)
    for ext in ('.srt', '.ass', '.ssa', '.vtt'):
        path = os.path.join(root, prefix + ext)
        if os.path.isfile(path) and os.path.getsize(path) > 16:
            return (path, ident)
    return ('', ident)
_SUBTITLE_EXTS = ('.srt', '.ass', '.ssa', '.vtt')
_SUBTITLE_CACHE_KEEP = 300
_SUBTITLE_CACHE_TRIGGER = 400

def _finish_cached_subtitle(base, target):
    """Make ``target`` the only cached copy for this identity and bound the cache.

    Without this a later download in another format (.ass after .srt) was shadowed
    by the older file, and the cache folder grew for ever.
    """
    for ext in _SUBTITLE_EXTS:
        other = base + ext
        for path in (other, other + '.sync.json') if other != target else (other + '.sync.json',):
            try:
                if os.path.isfile(path):
                    os.unlink(path)
            except Exception:
                pass
    try:
        root = os.path.dirname(target)
        if os.path.normpath(root) not in (os.path.normpath(CACHE_DIR), os.path.normpath('/tmp/UltraStalker-subtitles')):
            return
        rows = []
        for name in os.listdir(root):
            if os.path.splitext(name)[1].lower() not in _SUBTITLE_EXTS:
                continue
            path = os.path.join(root, name)
            try:
                rows.append((os.path.getmtime(path), path))
            except OSError:
                pass
        if len(rows) <= _SUBTITLE_CACHE_TRIGGER:
            return
        rows.sort(reverse=True)
        for _mtime, path in rows[_SUBTITLE_CACHE_KEEP:]:
            if path == target:
                continue
            for victim in (path, path + '.sync.json'):
                try:
                    if os.path.isfile(victim):
                        os.unlink(victim)
                except Exception:
                    pass
    except Exception:
        pass
_MAX_SUBTITLE_BYTES = 5 * 1024 * 1024

def _zip_member_bytes(z, name):
    """R5.152: never decompress an oversized (zip-bomb) subtitle member."""
    info = z.getinfo(name)
    if int(info.file_size) > _MAX_SUBTITLE_BYTES:
        raise RuntimeError('subtitle file too large')
    with z.open(info) as h:
        data = h.read(_MAX_SUBTITLE_BYTES + 1)
    if len(data) > _MAX_SUBTITLE_BYTES:
        raise RuntimeError('subtitle file too large')
    return data

def _require_web_url(url):
    low = str(url or '').strip().lower()
    if not low.startswith(('https://', 'http://')):
        raise RuntimeError('unsupported subtitle URL')
    return str(url).strip()

def _download(url, timeout=15):
    if str(url).startswith('/'):
        url = SUBDL_DOWNLOAD + str(url)
    url = _require_web_url(url)
    req = Request(str(url), headers={'User-Agent': 'UltraStalker/%s' % PLUGIN_VERSION, 'Accept': '*/*'})
    with urlopen(req, timeout=timeout) as res:
        data = res.read(8 * 1024 * 1024 + 1)
    if len(data) > 8 * 1024 * 1024:
        raise RuntimeError('subtitle download too large')
    return data

def _decode_text(data):
    if data.startswith(b'\xef\xbb\xbf'):
        return data.decode('utf-8-sig', 'replace')
    if data.startswith((b'\xff\xfe', b'\xfe\xff')):
        return data.decode('utf-16', 'replace')
    for enc in ('utf-8', 'cp1256', 'windows-1256', 'iso-8859-6'):
        try:
            return data.decode(enc)
        except Exception:
            pass
    return data.decode('utf-8', 'replace')

def _normalize_srt_bytes(data):
    text = _decode_text(data)
    text = text.replace('\r\n', '\n').replace('\r', '\n')
    return text.encode('utf-8')
SUBTITLE_LANGUAGES = {'EN': {'name': 'English', 'api_code': 'EN', 'aliases': ('EN', 'ENG', 'ENGLISH')}, 'AR': {'name': 'العربية', 'api_code': 'AR', 'aliases': ('AR', 'ARA', 'ARABIC')}, 'DE': {'name': 'Deutsch', 'api_code': 'DE', 'aliases': ('DE', 'GER', 'DEU', 'GERMAN')}, 'FR': {'name': 'Français', 'api_code': 'FR', 'aliases': ('FR', 'FRE', 'FRA', 'FRENCH')}, 'TR': {'name': 'Türkçe', 'api_code': 'TR', 'aliases': ('TR', 'TUR', 'TURKISH')}, 'ES': {'name': 'Español', 'api_code': 'ES', 'aliases': ('ES', 'SPA', 'SPANISH', 'CASTILIAN')}, 'IT': {'name': 'Italiano', 'api_code': 'IT', 'aliases': ('IT', 'ITA', 'ITALIAN')}, 'PT_BR': {'name': 'Português (Brasil)', 'api_code': 'PT', 'aliases': ('PT', 'POR', 'POB', 'PORTUGUESE', 'BRAZILIAN PORTUGUESE', 'PT-BR', 'PT_BR')}, 'NL': {'name': 'Nederlands', 'api_code': 'NL', 'aliases': ('NL', 'DUT', 'NLD', 'DUTCH')}, 'PL': {'name': 'Polski', 'api_code': 'PL', 'aliases': ('PL', 'POL', 'POLISH')}, 'RU': {'name': 'Русский', 'api_code': 'RU', 'aliases': ('RU', 'RUS', 'RUSSIAN')}, 'EL': {'name': 'Ελληνικά', 'api_code': 'EL', 'aliases': ('EL', 'ELL', 'GRE', 'GREEK')}, 'CS': {'name': 'Čeština', 'api_code': 'CS', 'aliases': ('CS', 'CZE', 'CES', 'CZECH')}, 'SK': {'name': 'Slovenčina', 'api_code': 'SK', 'aliases': ('SK', 'SLO', 'SLK', 'SLOVAK')}, 'HU': {'name': 'Magyar', 'api_code': 'HU', 'aliases': ('HU', 'HUN', 'HUNGARIAN')}, 'RO': {'name': 'Română', 'api_code': 'RO', 'aliases': ('RO', 'RUM', 'RON', 'ROMANIAN', 'MOLDAVIAN', 'MOLDOVAN')}, 'SR': {'name': 'Српски', 'api_code': 'SR', 'aliases': ('SR', 'SCC', 'SRP', 'SERBIAN')}, 'HR': {'name': 'Hrvatski', 'api_code': 'HR', 'aliases': ('HR', 'HRV', 'CROATIAN')}, 'BG': {'name': 'Български', 'api_code': 'BG', 'aliases': ('BG', 'BUL', 'BULGARIAN')}, 'UK': {'name': 'Українська', 'api_code': 'UK', 'aliases': ('UK', 'UKR', 'UKRAINIAN')}, 'SV': {'name': 'Svenska', 'api_code': 'SV', 'aliases': ('SV', 'SWE', 'SWEDISH')}, 'DA': {'name': 'Dansk', 'api_code': 'DA', 'aliases': ('DA', 'DAN', 'DANISH')}, 'FI': {'name': 'Suomi', 'api_code': 'FI', 'aliases': ('FI', 'FIN', 'FINNISH')}, 'ZH_CN': {'name': '简体中文', 'api_code': 'ZH', 'aliases': ('ZH', 'CHI', 'ZHO', 'CHINESE', 'ZH-CN', 'ZH_CN')}, 'ZH_TW': {'name': '繁體中文', 'api_code': 'ZH', 'aliases': ('ZH', 'CHI', 'ZHO', 'CHINESE', 'ZH-TW', 'ZH_TW')}, 'JA': {'name': '日本語', 'api_code': 'JA', 'aliases': ('JA', 'JPN', 'JAPANESE')}, 'KO': {'name': '한국어', 'api_code': 'KO', 'aliases': ('KO', 'KOR', 'KOREAN')}, 'ID': {'name': 'Bahasa Indonesia', 'api_code': 'ID', 'aliases': ('ID', 'IND', 'INDONESIAN')}, 'FA': {'name': 'فارسی', 'api_code': 'FA', 'aliases': ('FA', 'PER', 'FAS', 'PERSIAN', 'FARSI', 'FARSI_PERSIAN')}}
INTERFACE_TO_SUBDL_LANGUAGE = {'en': 'EN', 'ar': 'AR', 'de': 'DE', 'fr': 'FR', 'tr': 'TR', 'es': 'ES', 'it': 'IT', 'pt-br': 'PT_BR', 'nl': 'NL', 'pl': 'PL', 'ru': 'RU', 'el': 'EL', 'cs': 'CS', 'sk': 'SK', 'hu': 'HU', 'ro': 'RO', 'sr': 'SR', 'hr': 'HR', 'bg': 'BG', 'uk': 'UK', 'sv': 'SV', 'da': 'DA', 'fi': 'FI', 'zh-cn': 'ZH_CN', 'zh-tw': 'ZH_TW', 'ja': 'JA', 'ko': 'KO', 'id': 'ID', 'fa': 'FA'}

def _language_spec(language):
    code = str(language or 'AR').strip().upper().replace('-', '_')
    if code not in SUBTITLE_LANGUAGES:
        raise RuntimeError('Unsupported subtitle language: %s' % code)
    spec = SUBTITLE_LANGUAGES[code]
    return (code, spec['name'], tuple(spec['aliases']), str(spec.get('api_code') or code).upper())

def interface_subtitle_language_code(interface_code):
    return INTERFACE_TO_SUBDL_LANGUAGE.get(str(interface_code or 'en').strip().lower().replace('_', '-'), 'EN')

def subtitle_language_name(language):
    try:
        return _language_spec(language)[1]
    except Exception:
        return _('English')

def is_supported_subtitle_language(language):
    code = str(language or '').strip().upper().replace('-', '_')
    return code in SUBTITLE_LANGUAGES

def _language_identity(item, media_type, display_name, language):
    ident = _identity(item, media_type, display_name)
    ident['subtitle_language'] = str(language or 'AR').upper()
    return ident

def cached_subtitle_language(item, media_type, display_name='', language='AR'):
    code, _name, _aliases, _api_code = _language_spec(language)
    ident = _language_identity(item, media_type, display_name, code)
    root = _ensure_cache()
    prefix = _cache_key(ident)
    for ext in ('.srt', '.ass', '.ssa', '.vtt'):
        path = os.path.join(root, prefix + ext)
        if os.path.isfile(path) and os.path.getsize(path) > 16:
            return (path, ident)
    return ('', ident)

def search_language(api_key, item, media_type, display_name='', language='AR'):
    api_key = str(api_key or '').strip()
    if not api_key:
        raise RuntimeError('SubDL API key is not configured')
    code, language_name, aliases, api_code = _language_spec(language)
    cached, ident = cached_subtitle_language(item, media_type, display_name, code)
    cached_candidate = {'cached_path': cached, 'name': language_name, 'score': 10000} if cached else None
    base_params = {'api_key': api_key, 'type': ident['type'], 'languages': api_code, 'subs_per_page': '20', 'releases': '1', 'unpack': '1', 'client': 'custom_integration'}
    if ident['type'] == 'tv':
        if ident['season']:
            base_params['season_number'] = str(ident['season'])
        if ident['episode']:
            base_params['episode_number'] = str(ident['episode'])
    query_attempts = []
    if ident['tmdb_id']:
        p = dict(base_params)
        p['tmdb_id'] = ident['tmdb_id']
        query_attempts.append(p)
    if ident['imdb_id']:
        p = dict(base_params)
        p['imdb_id'] = ident['imdb_id']
        query_attempts.append(p)
    seen_names = set()
    for candidate_title in _subsource_search_titles(ident, item):
        clean_name = str(candidate_title or '').strip()
        if not clean_name:
            continue
        ck = us_casefold(clean_name)
        if ck in seen_names:
            continue
        seen_names.add(ck)
        p = dict(base_params)
        p['film_name'] = clean_name
        if ident['year']:
            p['year'] = str(ident['year'])
        query_attempts.append(p)
        if ident['year'] and len(query_attempts) < 4:
            p_noyear = dict(base_params)
            p_noyear['film_name'] = clean_name
            query_attempts.append(p_noyear)
        if len(query_attempts) >= 4:
            break
    if not query_attempts:
        raise RuntimeError('No title or TMDB/IMDb id is available for subtitle search')
    subtitles = []
    last_err = None
    for params in query_attempts[:4]:
        try:
            req = Request(SUBDL_SEARCH + '?' + urlencode(params), headers={'Accept': 'application/json', 'User-Agent': 'UltraStalker/%s' % PLUGIN_VERSION})
            with urlopen(req, timeout=15) as res:
                payload = json.loads(res.read(2 * 1024 * 1024).decode('utf-8', 'replace'))
            if isinstance(payload, dict) and payload.get('status'):
                subtitles = payload.get('subtitles') or []
                if subtitles:
                    break
            elif isinstance(payload, dict) and payload.get('error'):
                last_err = str(payload.get('error'))
        except Exception as exc:
            last_err = str(exc)
    if not subtitles:
        if cached_candidate:
            return ([cached_candidate], ident)
        if last_err and 'not found' not in last_err.lower() and ('no subtitle' not in last_err.lower()) and ("can't find" not in last_err.lower()):
            raise RuntimeError(last_err)
        raise RuntimeError('No %s subtitle found' % language_name)
    candidates = []
    for row in subtitles:
        if not isinstance(row, dict):
            continue
        release = str(row.get('release_name') or row.get('name') or language_name + ' subtitle')
        unpack = row.get('unpack_files') or []
        for f in unpack:
            if not isinstance(f, dict):
                continue
            fs = _safe_int(f.get('season'))
            fe = _safe_int(f.get('episode'))
            if ident['type'] == 'tv':
                if ident['season'] and fs and (fs != ident['season']):
                    continue
                if ident['episode'] and fe and (fe != ident['episode']):
                    continue
            lang = str(f.get('language') or '').upper()
            if lang and lang not in aliases:
                continue
            fmt = str(f.get('format') or '').lower()
            score = 100 + (50 if ident['episode'] and fe == ident['episode'] else 0) + (20 if ident['season'] and fs == ident['season'] else 0) + (10 if fmt == 'srt' else 0)
            url = str(f.get('url') or '')
            if url:
                candidates.append({'url': url, 'name': str(f.get('name') or release), 'format': fmt, 'archive': False, 'score': score})
        url = str(row.get('url') or '')
        if url:
            score = 20 + (20 if str(row.get('language') or '').upper() in aliases else 0) + (30 if ident['episode'] and _safe_int(row.get('episode')) == ident['episode'] else 0)
            candidates.append({'url': url, 'name': release, 'format': '', 'archive': True, 'score': score})
    candidates.sort(key=lambda x: int(x.get('score') or 0), reverse=True)
    if cached_candidate:
        candidates.insert(0, cached_candidate)
    if not candidates:
        raise RuntimeError('SubDL returned no downloadable %s subtitle' % language_name)
    return (candidates[:20], ident)

def _unique_tmp(path):
    return '%s.tmp.%d.%d' % (path, os.getpid(), threading.get_ident())

def _write_bytes_atomic(path, payload):
    """Write a cached subtitle so two parallel downloads can never interleave/truncate it."""
    tmp = _unique_tmp(path)
    try:
        with open(tmp, 'wb') as h:
            h.write(payload)
        os.replace(tmp, path)
    finally:
        try:
            os.unlink(tmp)
        except OSError:
            pass

def download_candidate(candidate, ident):
    if candidate.get('cached_path'):
        return {'path': candidate['cached_path'], 'cached': True, 'identity': ident, 'release': candidate.get('name') or _('Cached subtitle')}
    root = _ensure_cache()
    base = os.path.join(root, _cache_key(ident))
    data = _download(candidate.get('url') or '')
    is_archive = bool(candidate.get('archive')) or data[:2] == b'PK'
    if is_archive:
        zpath = _unique_tmp(base + '.zip')
        with open(zpath, 'wb') as h:
            h.write(data)
        try:
            with zipfile.ZipFile(zpath, 'r') as z:
                files = list((n for n in z.namelist() if os.path.splitext(n)[1].lower() in ('.srt', '.ass', '.ssa', '.vtt')))
                if not files:
                    raise RuntimeError('subtitle archive has no supported file')

                def fscore(n):
                    low = n.lower()
                    s = 10 if low.endswith('.srt') else 0
                    if ident.get('episode') and re.search('(?:e|ep|episode)[ ._-]*0*%d(?:\\D|$)' % ident['episode'], low):
                        s += 30
                    return s
                files.sort(key=fscore, reverse=True)
                raw = _zip_member_bytes(z, files[0])
                ext = os.path.splitext(files[0])[1].lower()
        finally:
            try:
                os.unlink(zpath)
            except Exception:
                pass
    else:
        raw = data
        fmt = str(candidate.get('format') or '').lower()
        ext = '.' + fmt if fmt else os.path.splitext(str(candidate.get('url') or '').split('?', 1)[0])[1].lower()
        if ext not in ('.srt', '.ass', '.ssa', '.vtt'):
            ext = '.srt'
    target = base + ext
    _write_bytes_atomic(target, _normalize_srt_bytes(raw) if ext in ('.srt', '.vtt') else raw)
    try:
        os.chmod(target, 384)
    except Exception:
        pass
    _finish_cached_subtitle(base, target)
    return {'path': target, 'cached': False, 'identity': ident, 'release': candidate.get('name') or 'Arabic'}
SUBSOURCE_LANGUAGE_SLUGS = {'EN': 'english', 'AR': 'arabic', 'DE': 'german', 'FR': 'french', 'TR': 'turkish', 'ES': 'spanish', 'IT': 'italian', 'PT_BR': 'portuguese', 'NL': 'dutch', 'PL': 'polish', 'RU': 'russian', 'EL': 'greek', 'CS': 'czech', 'SK': 'slovak', 'HU': 'hungarian', 'RO': 'romanian', 'SR': 'serbian', 'HR': 'croatian', 'BG': 'bulgarian', 'UK': 'ukrainian', 'SV': 'swedish', 'DA': 'danish', 'FI': 'finnish', 'ZH_CN': 'chinese', 'ZH_TW': 'chinese', 'JA': 'japanese', 'KO': 'korean', 'ID': 'indonesian', 'FA': 'farsi_persian'}

def _subsource_headers(api_key):
    return {'Accept': 'application/json', 'X-API-Key': str(api_key or '').strip(), 'User-Agent': 'UltraStalker/%s' % PLUGIN_VERSION}

def _subsource_json(api_key, endpoint, params=None, timeout=15):
    api_key = str(api_key or '').strip()
    if not api_key:
        raise RuntimeError('SubSource API key is not configured')
    url = SUBSOURCE_BASE + str(endpoint)
    if params:
        url += '?' + urlencode([(str(k), str(v)) for k, v in params.items() if v not in (None, '')])
    req = Request(url, headers=_subsource_headers(api_key))
    with urlopen(req, timeout=timeout) as res:
        payload = json.loads(res.read(2 * 1024 * 1024).decode('utf-8', 'replace'))
    if not isinstance(payload, dict) or not payload.get('success'):
        message = (payload or {}).get('message') or (payload or {}).get('error') or 'SubSource request failed'
        raise RuntimeError(str(message))
    return payload

def _subsource_release_text(value):
    if isinstance(value, (list, tuple)):
        return ' '.join((str(x or '').strip() for x in value if str(x or '').strip())).strip()
    return str(value or '').strip()

def _subsource_episode_match(release_info, season, episode):
    season = _safe_int(season)
    episode = _safe_int(episode)
    if not season or not episode:
        return False
    raw = _subsource_release_text(release_info).upper()
    compact = re.sub('[-._\\s]+', '', raw)
    patterns = ('S%02dE%02d' % (season, episode), 'S%dE%d' % (season, episode), 'S%02dE%d' % (season, episode), 'S%dE%02d' % (season, episode), '%dX%02d' % (season, episode), '%dX%d' % (season, episode))
    if any((p in compact for p in patterns)):
        return True
    if re.search('\\bS\\s*0*%d\\s*[-_. ]?\\s*E\\s*0*%d\\b' % (season, episode), raw, re.I):
        return True
    if re.search('\\b0*%d\\s*[xX]\\s*0*%d\\b' % (season, episode), raw, re.I):
        return True
    if re.search('(?:^|[^0-9])0*%d(?:[^0-9]|$)' % episode, raw):
        if not re.search('\\b(?:E|EP|EPISODE)\\s*0*\\d+\\b', raw, re.I):
            return True
    return False

def _subsource_season_pack(release_info, season):
    season = _safe_int(season)
    if not season:
        return False
    raw = _subsource_release_text(release_info).upper()
    compact = re.sub('[-._\\s]+', '', raw)
    if not re.search('\\b(?:COMPLETE|FULL|PACK|SEASON\\s*PACK)\\b', raw, re.I):
        return False
    return bool(re.search('(?:^|[^A-Z0-9])S(?:EASON)?0*%d(?:[^A-Z0-9]|$)' % season, raw, re.I)) or 'SEASON%d' % season in compact or 'S%02d' % season in compact

def _subsource_norm_text(value):
    text = us_casefold(unicodedata.normalize('NFKC', str(value or '')))
    return ''.join((ch for ch in text if ch.isalnum()))

def _subsource_search_titles(ident, item=None):
    raw = str((ident or {}).get('title') or '').strip()
    out = []
    for source in [raw] + _extra_item_titles(item, ident):
        source = str(source or '').strip()
        if not source:
            continue
        for value in [_subtitle_display_title(source)]:
            if value and value not in out:
                out.append(value)
        try:
            for value in _subtitle_search_aliases(source):
                value = str(value or '').strip()
                if value and value not in out:
                    out.append(value)
        except Exception:
            pass
        if source and source not in out:
            out.append(source)
    return out

def _subsource_row_values(row, keys):
    if not isinstance(row, dict):
        return []
    wanted = set((us_casefold(str(k)) for k in keys))
    out = []

    def collect(obj, depth=0):
        if not isinstance(obj, dict) or depth > 2:
            return
        for key, value in obj.items():
            lk = us_casefold(str(key))
            if lk in wanted and value not in (None, ''):
                out.append(value)
            elif isinstance(value, dict) and lk in ('movie', 'show', 'media', 'item', 'data'):
                collect(value, depth + 1)
    collect(row)
    return out

def _subsource_row_type(row):
    vals = _subsource_row_values(row, ('type', 'mediaType', 'media_type', 'movieType', 'kind', 'contentType'))
    for value in vals:
        text = us_casefold(str(value or '').strip())
        if any((tok in text for tok in ('series', 'tv', 'show'))):
            return 'tv'
        if any((tok in text for tok in ('movie', 'film'))):
            return 'movie'
    return ''

def _subsource_row_years(row):
    years = set()
    for value in _subsource_row_values(row, ('year', 'releaseYear', 'release_year', 'released', 'releaseDate', 'release_date')):
        year = _safe_int(value)
        if 1900 <= year <= 2100:
            years.add(year)
    for value in _subsource_row_values(row, ('title', 'name', 'movieTitle', 'movie_title', 'originalTitle', 'original_title', 'displayTitle')):
        for token in re.findall('(?:19|20)\\d{2}', str(value or '')):
            try:
                years.add(int(token))
            except Exception:
                pass
    return years

def _subsource_row_title_norms(row):
    out = set()
    vals = _subsource_row_values(row, ('title', 'name', 'movieTitle', 'movie_title', 'originalTitle', 'original_title', 'displayTitle', 'fullTitle'))
    for value in vals:
        raw = str(value or '').strip()
        if not raw:
            continue
        variants = [raw]
        try:
            variants.insert(0, _subtitle_display_title(raw))
        except Exception:
            pass
        for text in variants:
            text = re.sub('(?:^|[^0-9])(?:19|20)\\d{2}(?:[^0-9]|$)', ' ', str(text or ''))
            norm = _subsource_norm_text(text)
            if norm:
                out.add(norm)
    return out

def _subsource_row_imdb_values(row):
    out = set()
    for value in _subsource_row_values(row, ('imdb', 'imdbId', 'imdb_id', 'imdbID')):
        text = us_casefold(str(value or '').strip())
        if text:
            out.add(text)
    try:
        text = us_casefold(json.dumps(row, ensure_ascii=False, sort_keys=True))
        out.update(re.findall('tt\\d{5,12}', text))
    except Exception:
        pass
    return out

def _subsource_pick_movie_id(rows, ident, query_mode='text', extra_titles=None):
    """Return only a verified SubSource movieId; never pick row #1 blindly."""
    if not isinstance(rows, list):
        return ''
    expected_type = us_casefold(str((ident or {}).get('type') or '').strip())
    expected_year = _safe_int((ident or {}).get('year'))
    expected_imdb = us_casefold(str((ident or {}).get('imdb_id') or '').strip())
    expected_titles = set()
    for value in list(_subsource_search_titles(ident)) + list(extra_titles or ()):
        value = re.sub('(?:^|[^0-9])(?:19|20)\\d{2}(?:[^0-9]|$)', ' ', str(value or ''))
        norm = _subsource_norm_text(value)
        if norm:
            expected_titles.add(norm)
    scored = []
    for row in rows:
        if not isinstance(row, dict):
            continue
        mid = str(row.get('movieId') or row.get('id') or '').strip()
        if not mid:
            continue
        row_type = _subsource_row_type(row)
        if expected_type and row_type and (row_type != expected_type):
            continue
        row_years = _subsource_row_years(row)
        year_ok = bool(not expected_year or not row_years or any((abs(expected_year - ry) <= 1 for ry in row_years)))
        if not year_ok:
            continue
        row_titles = _subsource_row_title_norms(row)
        title_match = bool(expected_titles and row_titles and expected_titles.intersection(row_titles))
        if not title_match and expected_titles and row_titles:
            for et in expected_titles:
                for rt in row_titles:
                    if min(len(et), len(rt)) >= 6 and (et in rt or rt in et):
                        title_match = True
                        break
                if title_match:
                    break
        imdb_match = bool(expected_imdb and expected_imdb in _subsource_row_imdb_values(row))
        if str(query_mode) == 'imdb':
            if not (imdb_match or title_match or len(rows) == 1):
                continue
        elif not title_match:
            if not (len(rows) == 1 and expected_year and row_years and (expected_year in row_years)):
                continue
        score = 100 if imdb_match else 0
        if title_match:
            score += 60
        if expected_year and expected_year in row_years:
            score += 20
        elif expected_year and row_years and any((abs(expected_year - ry) <= 1 for ry in row_years)):
            score += 10
        if expected_type and row_type == expected_type:
            score += 10
        season = _safe_int((ident or {}).get('season'))
        if season:
            try:
                text = json.dumps(row, ensure_ascii=False, sort_keys=True)
            except Exception:
                text = ''
            if re.search('(?:season\\s*0*%d\\b|\\bs0*%d\\b)' % (season, season), text, re.I):
                score += 10
        scored.append((score, mid))
    scored.sort(key=lambda x: x[0], reverse=True)
    return scored[0][1] if scored else ''

def _subsource_movie_id(api_key, ident, item=None):
    attempts = []
    seen = set()
    all_titles = _subsource_search_titles(ident, item)
    if ident.get('imdb_id'):
        params = {'searchType': 'imdb', 'imdb': ident.get('imdb_id')}
        attempts.append((params, 'imdb'))
    for title in all_titles:
        title = str(title or '').strip()
        if not title:
            continue
        key = us_casefold(title)
        if key in seen:
            continue
        seen.add(key)
        params = {'searchType': 'text', 'q': title}
        if ident.get('type') == 'tv' and ident.get('season'):
            params['season'] = ident.get('season')
        attempts.append((params, 'text'))
    last_error = None
    for params, mode in attempts[:6]:
        try:
            payload = _subsource_json(api_key, '/movies/search', params)
            mid = _subsource_pick_movie_id(payload.get('data') or [], ident, mode, extra_titles=all_titles)
            if mid:
                return mid
        except Exception as exc:
            last_error = exc
    if last_error:
        raise last_error
    raise RuntimeError('SubSource could not safely match this title')

def _subsource_identity(item, media_type, display_name, language):
    code, _name, _aliases, _api_code = _language_spec(language)
    ident = _language_identity(item, media_type, display_name, code)
    ident['subtitle_provider'] = 'subsource'
    return ident

def cached_subsource_language(item, media_type, display_name='', language='AR'):
    ident = _subsource_identity(item, media_type, display_name, language)
    root = _ensure_cache()
    prefix = _cache_key(ident)
    for ext in ('.srt', '.ass', '.ssa', '.vtt'):
        path = os.path.join(root, prefix + ext)
        if os.path.isfile(path) and os.path.getsize(path) > 16:
            return (path, ident)
    return ('', ident)

def search_subsource_language(api_key, item, media_type, display_name='', language='AR'):
    api_key = str(api_key or '').strip()
    if not api_key:
        raise RuntimeError('SubSource API key is not configured')
    code, language_name, _aliases, _api_code = _language_spec(language)
    slug = SUBSOURCE_LANGUAGE_SLUGS.get(code)
    if not slug:
        raise RuntimeError('SubSource does not support this subtitle language')
    cached, ident = cached_subsource_language(item, media_type, display_name, code)
    cached_candidate = {'cached_path': cached, 'name': language_name + ' • cached', 'score': 10000, 'provider': 'subsource'} if cached else None
    movie_id = _subsource_movie_id(api_key, ident, item=item)
    rows = []
    seen = set()
    for page in range(1, 4):
        payload = _subsource_json(api_key, '/subtitles', {'movieId': movie_id, 'language': slug, 'sort': 'rating', 'limit': 100, 'page': page})
        batch = payload.get('data') or []
        if not isinstance(batch, list) or not batch:
            break
        fresh = 0
        for row in batch:
            if not isinstance(row, dict):
                continue
            sid = str(row.get('subtitleId') or row.get('id') or '').strip()
            if not sid or sid in seen:
                continue
            seen.add(sid)
            rows.append(row)
            fresh += 1
        if len(batch) < 100 or fresh == 0:
            break
    candidates = []
    for row in rows:
        sid = str(row.get('subtitleId') or row.get('id') or '').strip()
        if not sid:
            continue
        release = _subsource_release_text(row.get('releaseInfo') or row.get('release') or row.get('name')) or language_name + ' subtitle'
        score = 50
        if ident.get('type') == 'tv':
            exact = _subsource_episode_match(release, ident.get('season'), ident.get('episode'))
            pack = _subsource_season_pack(release, ident.get('season'))
            if ident.get('episode') and (not (exact or pack)):
                continue
            score += 180 if exact else 60 if pack else 0
        try:
            score += min(30, int(float(row.get('rating') or 0) * 3))
        except Exception:
            pass
        candidates.append({'subtitle_id': sid, 'name': release, 'archive': True, 'score': score, 'provider': 'subsource'})
    candidates.sort(key=lambda x: int(x.get('score') or 0), reverse=True)
    if cached_candidate:
        candidates.insert(0, cached_candidate)
    if not candidates:
        raise RuntimeError('No %s subtitle found' % language_name)
    return (candidates[:20], ident)

def download_subsource_candidate(api_key, candidate, ident):
    if candidate.get('cached_path'):
        return {'path': candidate['cached_path'], 'cached': True, 'identity': ident, 'release': candidate.get('name') or _('Cached subtitle')}
    api_key = str(api_key or '').strip()
    if not api_key:
        raise RuntimeError('SubSource API key is not configured')
    sid = str(candidate.get('subtitle_id') or '').strip()
    if not sid:
        raise RuntimeError('SubSource subtitle id is missing')
    req = Request(SUBSOURCE_BASE + '/subtitles/' + sid + '/download', headers={'X-API-Key': api_key, 'Accept': '*/*', 'User-Agent': 'UltraStalker/%s' % PLUGIN_VERSION})
    with urlopen(req, timeout=20) as res:
        data = res.read(8 * 1024 * 1024 + 1)
    if len(data) > 8 * 1024 * 1024:
        raise RuntimeError('subtitle download too large')
    root = _ensure_cache()
    base = os.path.join(root, _cache_key(ident))
    if data[:2] == b'PK':
        zpath = _unique_tmp(base + '.zip')
        with open(zpath, 'wb') as h:
            h.write(data)
        try:
            with zipfile.ZipFile(zpath, 'r') as z:
                files = [n for n in z.namelist() if os.path.splitext(n)[1].lower() in ('.srt', '.ass', '.ssa', '.vtt')]
                if not files:
                    raise RuntimeError('subtitle archive has no supported file')

                def fscore(name):
                    low = name.lower()
                    score = 10 if low.endswith('.srt') else 0
                    ep = _safe_int(ident.get('episode'))
                    if ep and re.search('(?:e|ep|episode)[ ._-]*0*%d(?:\\D|$)' % ep, low):
                        score += 50
                    if ep and re.search('(?:^|[^0-9])0*%d(?:[^0-9]|$)' % ep, low):
                        score += 20
                    return score
                files.sort(key=fscore, reverse=True)
                raw = _zip_member_bytes(z, files[0])
                ext = os.path.splitext(files[0])[1].lower()
        finally:
            try:
                os.unlink(zpath)
            except Exception:
                pass
    else:
        raw = data
        ext = '.srt'
    target = base + ext
    _write_bytes_atomic(target, _normalize_srt_bytes(raw) if ext in ('.srt', '.vtt') else raw)
    try:
        os.chmod(target, 384)
    except Exception:
        pass
    _finish_cached_subtitle(base, target)
    return {'path': target, 'cached': False, 'identity': ident, 'release': candidate.get('name') or 'SubSource subtitle'}

def parse_srt(path):
    with open(path, 'rb') as h:
        text = _decode_text(h.read(8 * 1024 * 1024))
    text = text.replace('\r\n', '\n').replace('\r', '\n')
    cues = []
    ext = os.path.splitext(path)[1].lower()
    if ext in ('.ass', '.ssa'):
        atime = re.compile('(\\d+):(\\d{2}):(\\d{2})[.](\\d{1,2})')
        for line in text.split('\n'):
            if not line.lstrip().lower().startswith('dialogue:'):
                continue
            parts = line.split(',', 9)
            if len(parts) < 10:
                continue
            sm = atime.search(parts[1])
            em = atime.search(parts[2])
            if not sm or not em:
                continue
            sv = list((int(x) for x in sm.groups()))
            ev = list((int(x) for x in em.groups()))
            start = (sv[0] * 3600 + sv[1] * 60 + sv[2]) * 1000 + sv[3] * 10
            end = (ev[0] * 3600 + ev[1] * 60 + ev[2]) * 1000 + ev[3] * 10
            body = parts[9].replace('\\N', '\n').replace('\\n', '\n')
            body = re.sub('\\{[^}]*\\}', '', body)
            body = re.sub('<[^>]+>', '', body).strip()
            if body and end > start:
                cues.append((start, end, body[:500]))
        cues.sort(key=lambda cue: (cue[0], cue[1]))
        return cues
    timing = re.compile('^(?:(\\d{1,4}):)?(\\d{2}):(\\d{2})[,.](\\d{1,3})\\s*-->\\s*(?:(\\d{1,4}):)?(\\d{2}):(\\d{2})[,.](\\d{1,3})(?:\\s+.*)?$')
    is_vtt = ext == '.vtt' or text.lstrip('\ufeff \n').startswith('WEBVTT')
    for block in re.split('\\n\\s*\\n', text):
        lines = list((x.strip('\ufeff ') for x in block.split('\n') if x.strip()))
        if not lines:
            continue
        if is_vtt and (lines[0] == 'NOTE' or lines[0].startswith('NOTE ') or lines[0] in ('STYLE', 'REGION')):
            continue
        ti = -1
        m = None
        for idx, line in enumerate(lines[:3]):
            m = timing.match(line)
            if m:
                ti = idx
                break
        if not m:
            continue

        def timestamp(hour, minute, second, fraction):
            minute = int(minute)
            second = int(second)
            if minute > 59 or second > 59:
                return None
            return (int(hour or 0) * 3600 + minute * 60 + second) * 1000 + int(fraction.ljust(3, '0')[:3])
        start = timestamp(*m.groups()[:4])
        end = timestamp(*m.groups()[4:])
        if start is None or end is None:
            continue
        body = '\n'.join(lines[ti + 1:])
        body = body.replace('\\N', '\n').replace('\\n', '\n')
        body = re.sub('\\{[^}]*\\}', '', body)
        body = re.sub('<[^>]+>', '', body).strip()
        if body and end > start:
            cues.append((start, end, body[:500]))
    cues.sort(key=lambda cue: (cue[0], cue[1]))
    return cues
