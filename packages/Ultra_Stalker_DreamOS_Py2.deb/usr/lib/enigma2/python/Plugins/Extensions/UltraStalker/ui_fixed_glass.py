# -*- coding: utf-8 -*-
"""Fixed-green application chrome rendered with the clean-glass material (R5.13).

Home, Settings, Portals and the cold-start Cinematic/Backdrop surfaces used old
nine-sliced PNGs.  They now use exactly the same recipes as the adaptive
builders (rows = Cinematic premium rows incl. the bright focus indicator,
panels/boxes = Details chrome), only with one fixed green palette instead of a
poster palette.  Shipped sizes are pre-rendered; other sizes render once.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str, int, max, min

from .ui_clean_glass import glass as _glass_raw, flagify as _flagify
from .asset_paths import canonical_asset as _canonical_asset


def _glass(*a, **k):
    """Fixed (non-adaptive) cards always use the Palestine flag ramp."""
    """Fixed (non-adaptive) surfaces use the unified Portal tile."""
    try:
        from .ui_clean_glass import portal_tile
        size = a[0]
        rim = int(k.get("rim_alpha", 200)); glow = int(k.get("glow_alpha", 0))
        sel = (rim >= 200 and glow >= 150) or glow >= 220
        return portal_tile(size, sel, 0, frame=(int(k.get("fill_alpha", 96)) <= 0))
    except Exception:
        return _flagify(_glass_raw(*a, **k))
from .ui_helpers import _lift_dynamic_accent, _mix_rgb

PRIMARY = (60, 200, 140)
SECONDARY = (40, 150, 110)
WHITE = (255, 255, 255)


def _acc(l=0.48, s=0.46):
    return _lift_dynamic_accent(PRIMARY, l, s)


def row(w, h, selected=False, radius=22):
    """Exactly the Cinematic premium row recipe (normal / bright focus)."""
    a = _acc()
    if selected:
        return _glass((w, h), radius, a, fill=_mix_rgb((3, 10, 15), a, 0.055), fill_alpha=82, fill_inset=2.0,
                      rim_alpha=255, rim_w=3.0, rim_inset=2.0, hair_alpha=150, hair_inset=5.0, hair_color=WHITE,
                      sheen_alpha=int(42 * 1.7), glow_alpha=250, glow_w=5.0, glow_inset=6.0, glow_blur=6)
    return _glass((w, h), radius, a, fill=_mix_rgb((3, 10, 15), a, 0.040), fill_alpha=68, fill_inset=2.0,
                  rim_alpha=104, rim_w=1.0, rim_inset=2.0, hair_alpha=26, hair_inset=5.0, hair_color=WHITE,
                  sheen_alpha=int(10 * 1.7), glow_alpha=54, glow_w=2.0, glow_inset=6.0, glow_blur=6)


def box(w, h, kind="pill", radius=None):
    """Details chrome recipe: kind = panel | overview | card | pill."""
    a = _acc()
    inner = _mix_rgb(a, WHITE, 0.40)
    base = (3, 12, 20)
    is_panel = kind in ("panel", "overview", "card")
    if radius is None:
        radius = 30 if kind == "panel" else (18 if kind == "card" else 22)
    fill = _mix_rgb(base, a, 0.10 if is_panel else 0.14)
    if kind == "panel":
        fa, ba = 62, 174
    elif kind == "overview":
        fa, ba = 82, 188
    elif kind == "card":
        fa, ba = 88, 184
    else:
        fa, ba = 98, 196
    sheen = 17 if kind == "panel" else (15 if is_panel else 13)
    return _glass((w, h), radius, a, fill=fill, fill_alpha=fa,
                  fill_inset=2.0, fill_radius=None,
                  rim_alpha=ba, rim_w=1.0, rim_inset=2.0,
                  hair_alpha=22, hair_inset=7.0, hair_color=inner,
                  sheen_alpha=int(sheen * 1.7),
                  glow_alpha=(92 if is_panel else 78), glow_w=3.0, glow_inset=6.0, glow_blur=(7 if is_panel else 5))


def home_card(w, h, radius, menu=True):
    """Home mood glass recipe."""
    p = _lift_dynamic_accent(PRIMARY, 0.54, 0.64)
    q = _lift_dynamic_accent(SECONDARY, 0.48, 0.56)
    basec = _mix_rgb((3, 8, 12), p, 0.070 if menu else 0.050)
    innerc = _mix_rgb((8, 15, 20), q, 0.060 if menu else 0.042)
    return _glass((w, h), radius, p, fill=basec, fill_alpha=242, fill_inset=2.0, rim_alpha=142, rim_w=2.0, rim_inset=2.0,
                  hair_alpha=68, hair_inset=7.0, hair_color=_mix_rgb(p, WHITE, 0.30),
                  inner_fill=(innerc, 82, 7), sheen_alpha=int((30 if menu else 22) * 1.7),
                  shade_alpha=34, depth_alpha=110, depth_blur=6, depth_dy=2.0, depth_inset=5.0)


def home_focus(w, h, radius, menu=True):
    """Home adaptive focus recipe."""
    a = _lift_dynamic_accent(PRIMARY, 0.72, 0.82)
    a2 = _lift_dynamic_accent(SECONDARY, 0.62, 0.72)
    inner = _mix_rgb(a2, WHITE, 0.36)
    fill = _mix_rgb((6, 13, 18), a, 0.19 if menu else 0.145)
    return _glass((w, h), radius, a, fill=fill, fill_alpha=78, fill_inset=3.0, rim_alpha=245, rim_w=3.0, rim_inset=2.0,
                  hair_alpha=92, hair_inset=7.0, hair_color=inner, sheen_alpha=36,
                  glow_alpha=190, glow_w=4.0, glow_inset=4.0, glow_blur=4)


def for_nine_slice(width, height, selected=False):
    """Portal-tile material (R5.126): one look for the whole plugin."""
    os = _us_env.os
    from PIL import Image
    base = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets_fhd",
                        "pt_tile_sel_380x148.png" if selected else "pt_tile_380x148.png")
    im = Image.open(base).convert("RGBA")
    width = int(width); height = int(height)
    c = max(8, min(22, width // 3, height // 3))
    sw, sh = im.size
    o = Image.new("RGBA", (width, height))
    xs = [(0, c, 0, c), (c, sw - c, c, width - c), (sw - c, sw, width - c, width)]
    ys = [(0, c, 0, c), (c, sh - c, c, height - c), (sh - c, sh, height - c, height)]
    for sx0, sx1, dx0, dx1 in xs:
        for sy0, sy1, dy0, dy1 in ys:
            o.paste(im.crop((sx0, sy0, sx1, sy1)).resize((max(1, dx1 - dx0), max(1, dy1 - dy0)), Image.BILINEAR), (dx0, dy0))
    return o


def surface_for_tag(tag, width, height):
    tag = str(tag or "")
    if "panel" in tag:
        return box(width, height, "panel", 30)
    if "overview" in tag:
        return box(width, height, "overview", 22)
    return box(width, height, "pill", 22)


# ---------------------------------------------------------------------------
# Fixed-green Details family (Details / Seasons / Episodes cold state).  Same keys
# and sizes as the adaptive Details chrome, shipped pre-rendered in the IPK.
_os = _us_env.os

DETAILS_DIR = _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), "assets_fhd", "fixed_green_details")
DETAILS_SPECS = {
    "panel": ((1388, 410), "panel", 30),
    "panel_detail": ((1410, 360), "panel", 30),
    "overview": ((1283, 142), "overview", 22),
    "overview_detail": ((1318, 170), "overview", 22),
    "cast_card": ((585, 106), "card", 18),
    "director_card": ((285, 106), "card", 18),
    "writer_card": ((418, 106), "card", 18),
    "cast_card_ep": ((555, 106), "card", 18),
    "director_card_ep": ((260, 106), "card", 18),
    "writer_card_ep": ((430, 106), "card", 18),
    "poster_footer": ((320, 86), "pill", 18),
    "poster_footer_detail": ((360, 86), "pill", 18),
    "quality": ((150, 50), "pill", 22),
    "year": ((130, 50), "pill", 22),
    "runtime": ((150, 50), "pill", 22),
    "country": ((160, 50), "pill", 22),
    "genre": ((815, 40), "pill", 19),
    "genre_detail": ((680, 50), "pill", 22),
    "cast_detail": ((1318, 50), "pill", 22),
    "rating_pill": ((130, 42), "pill", 18),
    "episodes_panel": ((430, 782), "panel", 20),
    "series_row": ((426, 72), "row", 22),
    "series_row_selected": ((426, 72), "row_selected", 22),
}


def render_details_item(name):
    (w, h), kind, radius = DETAILS_SPECS[name]
    if kind == "row":
        return row(w, h, False, radius)
    if kind == "row_selected":
        return row(w, h, True, radius)
    return box(w, h, kind, radius)


def accent_hex():
    a = _acc()
    return "#%02x%02x%02x" % (int(a[0]), int(a[1]), int(a[2]))


def fixed_details_chrome():
    """Bundled fixed-green Details chrome; only existing files are returned."""
    out = {}
    for name in DETAILS_SPECS:
        path = _canonical_asset(_os.path.join(DETAILS_DIR, name + ".png"))
        if _os.path.isfile(path):
            out[name] = path
    out["accent_color"] = accent_hex()
    return out

