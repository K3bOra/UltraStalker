# -*- coding: utf-8 -*-
"""Response unwrapping, adaptive timeouts, circuit breaker and response cache.

Methods moved verbatim out of ``StalkerClient`` (client.py); behaviour is unchanged.
This module is imported by client.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, max, min
from .client import (
    CACHE,
    CachePolicy,
    PortalError,
    time,
)


class ClientResilienceMixin(object):
    """Response unwrapping, adaptive timeouts, circuit breaker and response cache."""

    @staticmethod
    def _unwrap(data):
        if isinstance(data, dict) and "js" in data:
            return data.get("js")
        return data

    @staticmethod
    def _as_list(js):
        if isinstance(js, list):
            return js
        if isinstance(js, dict):
            for key in ("data", "items", "episodes", "seasons", "series"):
                value = js.get(key)
                if isinstance(value, list):
                    return value
        return []

    @staticmethod
    def _int_value(value, default=0):
        try:
            return int(value)
        except (TypeError, ValueError, OverflowError):
            return int(default)

    @staticmethod
    def _item_identity(row):
        if not isinstance(row, dict):
            return str(row)
        return str(row.get("id") or row.get("ch_id") or row.get("movie_id") or row.get("series_id") or row.get("cmd") or row.get("name") or row.get("title") or repr(sorted(row.items())))

    def _adaptive_timeout(self):
        samples = self._latency_state.get(self._portal_key(), [])
        if not samples:
            return self.timeout
        avg_ms = sum(samples) / float(len(samples))
        return int(max(5, min(18, (avg_ms / 1000.0) * 4.0 + 3.0)))

    def _record_success(self, elapsed_ms):
        key = self._portal_key()
        samples = list(self._latency_state.get(key, []))[-4:]
        samples.append(max(1, int(elapsed_ms)))
        self._latency_state[key] = samples
        self._circuit_state[key] = {"failures": 0, "opened_at": 0}

    def _record_failure(self):
        # The shared breaker protects catalogue/artwork/background traffic.
        # Explicit user playback has its own bounded retry/auth policy and must
        # neither inherit nor poison that background failure budget.
        if bool(getattr(self._priority_local, "playback", False)):
            return
        key = self._portal_key()
        state = dict(self._circuit_state.get(key, {"failures": 0, "opened_at": 0}))
        state["failures"] = int(state.get("failures", 0)) + 1
        if state["failures"] >= self.CIRCUIT_FAILURE_LIMIT:
            state["opened_at"] = time.monotonic()
        self._circuit_state[key] = state

    def reset_failure_backoff(self):
        """Clear only transient request backoff for this portal.

        UI navigation and preview cancellation are expected control flow and must
        never strand the whole portal behind the circuit breaker.
        Authorization/cookies remain untouched.
        """
        self._circuit_state[self._portal_key()] = {"failures": 0, "opened_at": 0}

    def _check_circuit(self):
        # Explicit user playback is a priority lane.  Background artwork or
        # metadata failures may protect themselves with the shared breaker, but
        # they must never prevent create_link/authorize from reaching a healthy
        # portal.  The flag is thread-local, so normal/background callers keep
        # the existing protection unchanged.
        if bool(getattr(self._priority_local, "playback", False)):
            return
        state = self._circuit_state.get(self._portal_key()) or {}
        opened_at = float(state.get("opened_at", 0) or 0)
        if not opened_at:
            return
        # Keep protection against a genuinely dead portal, but never lock the
        # interactive browser for a full minute.  After a very short quiet
        # period allow one normal request to recover the connection; success
        # resets the state in _record_success().
        age = time.monotonic() - opened_at
        if age < 2.0:
            raise PortalError("Portal temporarily paused after repeated failures (%ds)" % max(1, int(2.0-age+0.999)))
        self._circuit_state[self._portal_key()] = {"failures": 0, "opened_at": 0}

    def _cache_key(self, params):
        scoped=dict(params or {})
        scoped["_us_content_generation"]=str(max(0,int(getattr(self,"_content_cache_generation",0) or 0)))
        return CACHE.key(self.host, self.mac, scoped)

    def _cache_get(self, params):
        return CACHE.get(self._cache_key(params))

    def _cache_put(self, params, value):
        CACHE.put(self._cache_key(params), value, CachePolicy.ttl(params.get("action"), 90))

    def _cache_put_usable(self, params, value):
        """R5.63: never cache an empty/auth-error catalogue answer.

        A transient {"js":[]} (busy portal, connection limit) used to be cached
        for up to 6 h (genres) / 30 min (pages), in RAM and SQLite, so a short
        hiccup left a category blank long after the portal recovered."""
        try:
            js = self._unwrap(value)
            usable = bool(self._as_list(js))
            if not usable and isinstance(js, dict):
                usable = self._int_value(js.get("total_items"), 0) > 0
        except Exception:
            usable = False
        if usable:
            self._cache_put(params, value)
