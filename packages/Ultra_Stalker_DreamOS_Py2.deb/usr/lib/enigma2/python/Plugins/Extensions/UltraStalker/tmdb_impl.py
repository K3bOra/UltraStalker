# -*- coding: utf-8 -*-
"""TMDB metadata enrichment for Ultra Stalker.

The Stalker portal remains the playback/content authority. TMDB is optional and
is used only to enrich metadata/artwork when a user supplies their own API
credential.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str, int, open, round, max, min, OSError, us_clear, us_casefold
__metaclass__ = type
os = _us_env.os
re = _us_env.re
json = _us_env.json
time = _us_env.time
hashlib = _us_env.hashlib
import difflib
import logging
threading = _us_env.threading
import weakref
import unicodedata
urllib = _us_env.urllib
urllib = _us_env.urllib
from .securefs import secure_private_dir
from .log import diagnostic_failure
urllib = _us_env.urllib
from .netsec import credential_urlopen, SafeMediaRedirectHandler, validate_remote_media_url, build_safe_media_opener, build_safe_https_media_opener
from .tmdb_stages import query_list as _enrich_query_list, external_imdb_id as _external_imdb_id, direct_tmdb_identity as _direct_tmdb_identity
from .age_rating import certification_from_tmdb, rating_endpoint
try:
    from PIL import Image as _PILImage, ImageFilter as _PILImageFilter, ImageStat as _PILImageStat
except Exception:
    _PILImage = None
    _PILImageFilter = None
    _PILImageStat = None
CONFIG_DIR = '/etc/enigma2/ultrastalker'
from .persistent_cache import INDEX as CACHE_DIR, POSTERS as POSTER_CACHE_DIR, BACKDROPS as BACKDROP_CACHE_DIR, GENERATED as IMAGE_CACHE_DIR, SOURCE_POSTERS as SOURCE_POSTER_CACHE_DIR, SOURCE_BACKDROPS as SOURCE_BACKDROP_CACHE_DIR, hdd_ready, hdd_read_ready, ensure_persistent_dirs, persistent_write_gate
from .title_clean import clean_title as _shared_clean_title, tmdb_search_aliases
from .identity_hints import country_hint as _origin_country_hint, language_for_country as _origin_language, hints_compatible as _hints_compatible, original_language as _original_language
from .media_library import load as load_media_record, save as save_media_record, ensure_adaptive as ensure_media_adaptive, item_paths as media_item_paths
from .core.image_budget import image_budgeted
_IMAGE_LOCK_GUARD = threading.Lock()
_IMAGE_LOCKS = weakref.WeakValueDictionary()
API_BASE = 'https://api.themoviedb.org/3'
IMAGE_BASE = 'https://image.tmdb.org/t/p'
CACHE_TTL = None
CACHE_SCHEMA = 21
LEGACY_METADATA_CACHE_SCHEMAS = ()
UA = 'UltraStalker-Nova/10'
LOG = logging.getLogger('UltraStalker.TMDB')
_MEM_CACHE = {}
_MEM_CACHE_ORDER = []
_MEM_CACHE_LOCK = threading.RLock()
_MEM_CACHE_LIMIT = 160
_NEG_CACHE = {}
_NEG_CACHE_TTL = 900.0
_LAST_ERROR_TS = [0.0]

def _neg_hit(key):
    ts = _NEG_CACHE.get(key)
    if ts is None:
        return False
    if time.time() - ts > _NEG_CACHE_TTL:
        _NEG_CACHE.pop(key, None)
        return False
    return True

def _neg_put(key):
    if len(_NEG_CACHE) > 1500:
        us_clear(_NEG_CACHE)
    _NEG_CACHE[key] = time.time()

def _mem_get(key):
    with _MEM_CACHE_LOCK:
        value = _MEM_CACHE.get(key)
        if value is not None:
            try:
                _MEM_CACHE_ORDER.remove(key)
            except ValueError:
                pass
            _MEM_CACHE_ORDER.append(key)
            return dict(value) if isinstance(value, dict) else value
    return None

def _mem_put(key, value):
    if value is None:
        return
    with _MEM_CACHE_LOCK:
        _MEM_CACHE[key] = dict(value) if isinstance(value, dict) else value
        try:
            _MEM_CACHE_ORDER.remove(key)
        except ValueError:
            pass
        _MEM_CACHE_ORDER.append(key)
        while len(_MEM_CACHE_ORDER) > _MEM_CACHE_LIMIT:
            old = _MEM_CACHE_ORDER.pop(0)
            _MEM_CACHE.pop(old, None)

def shutdown_tmdb_workers(wait=False):
    return True

def _tmdb_certification(details, media_type, supplemental=None):
    return certification_from_tmdb(details, media_type, supplemental=supplemental)

def _path_lock(path):
    key = os.path.abspath(str(path or ''))
    with _IMAGE_LOCK_GUARD:
        lock = _IMAGE_LOCKS.get(key)
        if lock is None:
            lock = threading.RLock()
            _IMAGE_LOCKS[key] = lock
        return lock

def _valid_image_file(path, min_bytes=1024):
    """Cheap structural validation for cached artwork without a Pillow dependency."""
    try:
        size = os.path.getsize(path) if os.path.isfile(path) else 0
        if size <= int(min_bytes):
            return False
        with open(path, 'rb') as handle:
            head = handle.read(32)
            handle.seek(max(0, size - 64))
            tail = handle.read(64)
        if head.startswith(b'\x89PNG\r\n\x1a\n'):
            return head[12:16] == b'IHDR' and b'IEND' in tail
        if head.startswith(b'\xff\xd8\xff'):
            return b'\xff\xd9' in tail
        if head[:4] == b'RIFF' and head[8:12] == b'WEBP':
            try:
                from .pil_compat import supports_webp as _sw
                if not _sw():
                    return False
            except Exception:
                return False
            if len(head) < 12:
                return False
            declared = int.from_bytes(head[4:8], 'little') + 8
            return 12 <= declared <= size
        return False
    except Exception:
        return False
_TECH = {'4k', '8k', 'uhd', 'fhd', 'hd', '2160p', '1080p', '720p', '3840p', '4320p', 'hdr', 'hdr10', 'dolby', 'atmos', 'hevc', 'h265', 'h264', 'avc', 'top', 'vip', 'subs', 'sub', 'dub', 'dubs', 'raw', 'bluray', 'bdrip', 'brrip', 'hdrip', 'webrip', 'webdl', 'x264', 'x265', 'multi', 'audio', 'vod', 'movie', 'movies', 'series', 'tv', 'ar', 'en', 'tr', 's', 'do', 'fr', 'de', 'es', 'it', 'pl', 'nl', 'ru', 'pt', 'br', 'us', 'uk', 'eg', 'ksa', 'uae', 'arabic', 'english', 'turkish', ' مترجم', 'مدبلج'}

def _ensure():
    if not hdd_ready():
        return False
    return ensure_persistent_dirs(CACHE_DIR, IMAGE_CACHE_DIR, POSTER_CACHE_DIR, BACKDROP_CACHE_DIR)

def _year(value):
    text = str(value or '')
    m = re.search('[\\[(]\\s*((?:19|20)\\d{2})\\s*[\\])]?\\s*$', text) or re.search('[\\[(]\\s*((?:19|20)\\d{2})\\s*[\\])]', text)
    if not m and (not re.search('[^\\W\\d_]', text, re.UNICODE)):
        m = re.search('((?:19|20)\\d{2})', text)
    if not m:
        m = re.search('[-|,/]\\s*((?:19|20)\\d{2})\\s*$', text)
    if not m:
        return None
    return int(m.group(1))

def _country_hint(item, raw=''):
    return _origin_country_hint(item, raw)

def _language_for_country(code):
    return _origin_language(code)

def _has_arabic(value):
    return bool(re.search('[\\u0600-\\u06ff]', str(value or '')))

def _latin_heavy(value):
    text = str(value or '').strip()
    if not text:
        return False
    latin = len(re.findall('[A-Za-z]', text))
    letters = len(re.findall('[^\\W\\d_]', text, re.UNICODE))
    return latin >= max(2, int(letters * 0.55))

def _normalize_unicode_digits(value):
    """Normalize Arabic-Indic/Persian and other Unicode decimal digits to ASCII.

    TMDB Arabic translations frequently use ٠١٢٣٤٥٦٧٨٩ while Stalker
    catalogues use 0123456789.  Treating those as different broke otherwise
    exact identities such as ``السفارة 87`` vs ``السفارة ٨٧``.
    """
    text = str(value or '')
    out = []
    for ch in text:
        try:
            if unicodedata.category(ch) == 'Nd':
                out.append(str(unicodedata.digit(ch)))
            else:
                out.append(ch)
        except Exception:
            out.append(ch)
    return ''.join(out)

def clean_title(value):
    return _shared_clean_title(value)

def _ascii_search_title(value):
    """Aggressive Stalker/TMDB search title.

    MAG/Stalker catalogues often combine a routing prefix, a Latin title and a
    translated Arabic title in one display name. TMDB matching is much more
    reliable when the routing prefix and translated suffix are not sent as if
    they were part of the canonical title.
    """
    text = str(value or '').strip()
    if not text:
        return ''
    text = re.sub('\\[[^\\]]*\\]', ' ', text)
    text = re.sub('\\([^)]*\\)', ' ', text)

    def _drop_route(m):
        toks = re.split('[-_]', m.group(1))
        known = {'4K', '8K', 'UHD', 'FHD', 'HD', 'AR', 'EN', 'TR', 'DO', 'S', 'D', 'AS', 'KR', 'JP', 'CN', 'IN', 'US', 'UK', 'EG', 'FR', 'DE', 'ES', 'IT', 'RU', 'SUBS', 'SUB', 'DUB', 'DUBS', 'VIP', 'TOP', 'RAW', 'ARA', 'ENG', 'MOVIES', 'MOVIE', 'SERIES', 'TV', 'VOD'}
        return ' ' if all((t.upper() in known for t in toks)) else m.group(0)
    text = re.sub('^((?:[A-Za-z0-9]{1,6}(?:[-_][A-Za-z0-9]{1,8}){1,6}))\\s*[-|:]\\s*', _drop_route, text)
    text = clean_title(text)
    ascii_text = unicodedata.normalize('NFKD', text).encode('ascii', 'ignore').decode('ascii', 'ignore')
    ascii_text = re.sub('\\b(?:4K|8K|UHD|FHD|HD|RAW|SUBS?|DUBS?|DUBBED|TOP|VIP|AR|EN|TR|DO)\\b', ' ', ascii_text, flags=re.I)
    ascii_text = re.sub('\\s+', ' ', ascii_text).strip(' -_|:.')
    return ascii_text

def _query_variants(value):
    raw = str(value or '').strip()
    if not raw:
        return []
    search_raw = re.sub('\\s*[\\[(]\\s*(?:19|20)\\d{2}\\s*[\\])]?[\\s]*$', ' ', raw).strip()
    search_raw = re.sub('^\\s*0\\d{2,3}\\s*[-.:]\\s*(?=\\S)', '', search_raw).strip() or raw
    try:
        from .title_clean import protect_title_wrappers as _protect
        search_raw = _protect(search_raw) or search_raw
    except Exception:
        pass
    _no_groups = re.sub('\\s*[\\(\\[\\{][^\\)\\]\\}]*[\\)\\]\\}]', ' ', search_raw)
    if len(re.sub('[\\W_]+', '', _no_groups, flags=re.UNICODE)) >= 2:
        search_raw = re.sub('\\s+', ' ', _no_groups).strip()
    clean = clean_title(search_raw)
    ascii_title = _ascii_search_title(search_raw)
    if all((ord(ch) < 128 for ch in clean)) and clean:
        try:
            from .title_clean import tmdb_search_title as _safe_search_title
            ascii_title = _safe_search_title(search_raw)
            _ct = set(re.findall('\\w+', us_casefold(clean)))
            _at = set(re.findall('\\w+', us_casefold(ascii_title)))
            if not _at or not _at <= _ct:
                ascii_title = ''
        except Exception:
            ascii_title = ''
    variants = []
    has_ascii = bool(re.search('[A-Za-z]', clean))
    has_ar = bool(re.search('[\\u0600-\\u06ff]', clean))
    order = (ascii_title, clean) if has_ascii and has_ar else (clean, ascii_title)
    expanded = []
    for q in order:
        q = re.sub('\\s+', ' ', str(q or '')).strip(' -_|:.')
        if not q:
            continue
        expanded.append(q)
        q2 = re.sub('\\s+[-|:]\\s*\\d{1,2}\\s*$', '', q).strip(' -_|:.')
        if q2 and q2 != q:
            expanded.append(q2)
    for q in expanded:
        nq = re.sub('[\\W_]+', ' ', us_casefold(q), flags=re.UNICODE).strip()
        if nq and all((re.sub('[\\W_]+', ' ', us_casefold(x), flags=re.UNICODE).strip() != nq for x in variants)):
            variants.append(q)
    _stop = {'the', 'a', 'an', 'of', 'in', 'on', 'at', 'to', 'and', 'for', 'le', 'la', 'el', 'al', 'de', 'un', 'il'}
    good = [v for v in variants if len(re.sub('[\\W_]+', '', v, flags=re.UNICODE)) >= 3 and len(re.findall('[^\\W\\d_]', v, flags=re.UNICODE)) >= 2 and (us_casefold(v) not in _stop)]
    safe = tmdb_search_aliases(raw)
    return list(dict.fromkeys(safe + (good or variants)))

def _norm(value):
    text = us_casefold(_normalize_unicode_digits(clean_title(value)))
    text = text.translate(str.maketrans({'أ': 'ا', 'إ': 'ا', 'آ': 'ا', 'ٱ': 'ا', 'ى': 'ي', 'ئ': 'ي', 'ؤ': 'و', 'ة': 'ه', 'ـ': ''}))
    text = re.sub('[^\\w\\u0600-\\u06ff]+', ' ', text, flags=re.UNICODE)
    text = ' '.join(text.split())
    return text.replace('يا ما', 'ياما')

def _description_similarity(a, b):
    a = _norm(a)
    b = _norm(b)
    if len(a) < 24 or len(b) < 24:
        return 0.0
    sa = set((x for x in a.split() if len(x) > 2))
    sb = set((x for x in b.split() if len(x) > 2))
    if not sa or not sb:
        return 0.0
    return float(len(sa & sb)) / float(max(1, len(sa | sb)))

def _tmdb_country_codes(details, media_type):
    """Return display-country codes in TMDb identity order.

    TV shows expose ``origin_country`` specifically for where the programme
    originates; ``production_countries`` may instead describe financing/studios.
    Movies do not normally expose origin_country, so production_countries remains
    the primary movie source.  The secondary source is appended only as fallback.
    """
    details = details if isinstance(details, dict) else {}
    mt = 'tv' if str(media_type or '').lower() in ('tv', 'series', 'show', 'episode') else 'movie'
    primary = details.get('origin_country') or [] if mt == 'tv' else details.get('production_countries') or []
    secondary = details.get('production_countries') or [] if mt == 'tv' else details.get('origin_country') or []
    out = []
    for row in list(primary or []) + list(secondary or []):
        value = row.get('iso_3166_1') or row.get('name') if isinstance(row, dict) else row
        value = str(value or '').strip()
        if value and value not in out:
            out.append(value)
    return out

def _identity_match_evidence(query, result, media_type, wanted_year=None, country_hint='', description_hint='', aliases=None):
    """Validate a candidate without letting a provider TMDb id certify itself.

    The important failure mode is an exact but ambiguous one-word title such as
    ``Mouse`` or ``Sugar``.  Exact text alone cannot distinguish an original from
    a remake, so those titles require one independent clue: compatible year,
    country/original-language, provider synopsis, or a distinct provider alias.
    """
    result = result if isinstance(result, dict) else {}
    q = _norm(query)
    names = [_norm(result.get('title') or result.get('name') or ''), _norm(result.get('original_title') or result.get('original_name') or '')]
    names = list((x for x in names if x))
    exact = bool(q and q in names)
    qtokens = list((x for x in q.split() if x))
    strong = False
    if exact:
        strong = True
    elif q and names:
        for name in names:
            if min(len(q), len(name)) >= 8:
                qset = set(q.split())
                nset = set(name.split())
                overlap = float(len(qset & nset)) / float(max(1, max(len(qset), len(nset))))
                ratio = difflib.SequenceMatcher(None, q, name).ratio()
                if (q in name or name in q) and overlap >= 0.75:
                    strong = True
                    break
                if overlap >= 0.75 and ratio >= 0.78:
                    strong = True
                    break
    date = result.get('release_date') if str(media_type) == 'movie' else result.get('first_air_date')
    result_year = _year(date)
    year_close = bool(wanted_year and result_year and (abs(int(wanted_year) - int(result_year)) <= 1))
    year_conflict = bool(wanted_year and result_year and (abs(int(wanted_year) - int(result_year)) >= 3))
    country_match = False
    if country_hint:
        code = str(country_hint or '').upper()
        wanted_lang = _language_for_country(code)
        original_lang = str(result.get('original_language') or '').lower()
        origins = list((str(x).upper() for x in result.get('origin_country') or []))
        country_match = bool(code in origins or (wanted_lang and original_lang == wanted_lang))
    desc_sim = _description_similarity(description_hint, result.get('overview') or '')
    description_match = bool(desc_sim >= 0.16)
    alias_match = False
    for alias in aliases or []:
        an = _norm(alias)
        if not an or an == q:
            continue
        if an in names:
            alias_match = True
            break
    independent = int(year_close) + int(country_match) + int(description_match) + int(alias_match)
    ambiguous = bool(len(qtokens) <= 1)
    country_conflict = not _hints_compatible({'country_code': country_hint}, result)
    trusted = bool(strong and (not year_conflict) and (not country_conflict) and (not ambiguous or independent >= 1))
    return {'trusted': trusted, 'strong_title': strong, 'exact': exact, 'ambiguous': ambiguous, 'year_close': year_close, 'year_conflict': year_conflict, 'country_match': country_match, 'country_conflict': country_conflict, 'description_match': description_match, 'description_similarity': desc_sim, 'alias_match': alias_match, 'independent_evidence': independent, 'result_year': result_year}

def _score(query, result, media_type, wanted_year=None, requested_type=None, country_hint='', description_hint=''):
    title = result.get('title') if media_type == 'movie' else result.get('name')
    original = result.get('original_title') if media_type == 'movie' else result.get('original_name')
    q = _norm(query)
    t = _norm(title or '')
    o = _norm(original or '')
    base = max(difflib.SequenceMatcher(None, q, t).ratio(), difflib.SequenceMatcher(None, q, o).ratio())
    if q and (q == t or q == o):
        base = 1.0
    else:
        q_tokens = q.split()
        for candidate in (t, o):
            if not q or not candidate:
                continue
            if candidate.startswith(q + ' ') or q.startswith(candidate + ' '):
                base = max(base, 0.96)
                continue
            c_tokens = candidate.split()
            if len(q_tokens) >= 2 and len(c_tokens) >= len(q_tokens):
                qset = set(q_tokens)
                cset = set(c_tokens)
                if qset and qset.issubset(cset) and (len(cset - qset) <= 3):
                    base = max(base, 0.91)
    date = result.get('release_date') if media_type == 'movie' else result.get('first_air_date')
    ry = _year(date)
    if wanted_year and ry:
        diff = abs(int(wanted_year) - int(ry))
        if diff == 0:
            base += 0.16
        elif diff == 1:
            base += 0.05
        elif diff >= 3:
            base -= 0.18
    if requested_type and media_type != requested_type:
        base -= 0.24
    if country_hint:
        wanted_lang = _language_for_country(country_hint)
        original_lang = str(result.get('original_language') or '').lower()
        origin = [str(x).upper() for x in result.get('origin_country') or []]
        if wanted_lang and original_lang == wanted_lang:
            base += 0.12
        if country_hint.upper() in origin:
            base += 0.12
        if wanted_lang and original_lang and (original_lang != wanted_lang):
            base -= 0.08
    ds = _description_similarity(description_hint, result.get('overview') or '')
    if ds >= 0.28:
        base += 0.16
    elif ds >= 0.16:
        base += 0.08
    elif description_hint and len(str(description_hint)) > 80 and result.get('overview') and (ds < 0.04):
        base -= 0.1
    try:
        pop = float(result.get('popularity') or 0)
        base += min(0.02, pop / 15000.0)
    except Exception as exc:
        diagnostic_failure('tmdb.failsoft', exc)
    return max(0.0, min(1.0, base))
from .tmdb import TMDBError

class TMDBClient:

    def __init__(self, credential, language='ar-EG', timeout=8):
        self.credential = str(credential or '').strip()
        self.language = str(language or 'ar-EG').strip() or 'ar-EG'
        self.timeout = max(3, min(20, int(timeout or 8)))
        _ensure()

    @property
    def configured(self):
        return bool(self.credential)

    def _auth(self, params):
        headers = {'User-Agent': UA, 'Accept': 'application/json'}
        if len(self.credential) <= 64 and re.match('^[A-Za-z0-9_-]+$', self.credential):
            params['api_key'] = self.credential
        else:
            headers['Authorization'] = 'Bearer ' + self.credential
        return headers

    def _get(self, path, params=None):
        from .shared_tmdb_cache import request_json
        if path == '/configuration':
            return self._get_uncached(path, params)
        try:
            return request_json(self.credential, path, dict(params or {}), lambda: self._get_uncached(path, params))
        except Exception:
            _LAST_ERROR_TS[0] = time.time()
            raise

    def _get_uncached(self, path, params=None):
        if not self.configured:
            raise TMDBError('TMDB credential is not configured')
        params = dict(params or {})
        headers = self._auth(params)
        url = API_BASE + path
        if params:
            url += '?' + urllib.parse.urlencode(params)
        req = urllib.request.Request(url, headers=headers)
        try:
            data = None
            for _attempt in (0, 1, 2):
                try:
                    with credential_urlopen(req, timeout=self.timeout) as response:
                        data = response.read(2 * 1024 * 1024 + 1)
                    break
                except urllib.error.HTTPError as rate_exc:
                    if rate_exc.code != 429 or _attempt >= 2:
                        raise
                    try:
                        wait = float((rate_exc.headers or {}).get('Retry-After') or 1)
                    except Exception:
                        wait = 1.0
                    time.sleep(max(0.5, min(4.0, wait)))
            if len(data) > 2 * 1024 * 1024:
                raise TMDBError('TMDB response too large')
            payload = json.loads(data.decode('utf-8', 'replace'))
            if isinstance(payload, dict) and payload.get('success') is False:
                raise TMDBError(str(payload.get('status_message') or 'TMDB request failed'))
            return payload
        except urllib.error.HTTPError as exc:
            _LAST_ERROR_TS[0] = time.time()
            try:
                body = exc.read(8192).decode('utf-8', 'replace')
                msg = json.loads(body).get('status_message')
            except Exception:
                msg = None
            raise TMDBError(msg or 'TMDB HTTP %s' % exc.code)
        except urllib.error.URLError as exc:
            _LAST_ERROR_TS[0] = time.time()
            raise TMDBError('TMDB network error: %s' % getattr(exc, 'reason', exc))
        except ValueError as exc:
            raise TMDBError('Invalid TMDB response: %s' % exc)

    def test(self):
        data = self._get('/configuration')
        return bool(isinstance(data, dict) and data.get('images'))

    def _cache_key(self, media_type, query, year, country='', identity='', schema=None):
        if schema is None:
            schema = CACHE_SCHEMA
        raw = '%s|%s|%s|%s|%s|%s|v%s' % (media_type, _norm(query), year or '', str(country or '').upper(), str(identity or ''), self.language, int(schema))
        return hashlib.sha1(raw.encode('utf-8', 'ignore')).hexdigest()

    def _cache_read(self, key):
        hot = _mem_get(key)
        if hot is not None:
            return hot
        if not hdd_read_ready(force=True):
            return None
        path = os.path.join(CACHE_DIR, key + '.json')
        try:
            if CACHE_TTL not in (None, 0, False) and time.time() - os.path.getmtime(path) > CACHE_TTL:
                return None
            with open(path, 'r', encoding='utf-8') as h:
                data = json.load(h)
            if isinstance(data, dict):
                _mem_put(key, data)
                return data
            return None
        except Exception:
            return None

    def _cache_write(self, key, data):
        path = os.path.join(CACHE_DIR, key + '.json')
        lock = _path_lock(path)
        temp = path + '.tmp.%d.%d' % (os.getpid(), threading.get_ident())
        _mem_put(key, data)
        with lock:
            if not hdd_ready() or not ensure_persistent_dirs(CACHE_DIR):
                return False
            try:
                with open(temp, 'w', encoding='utf-8') as h:
                    json.dump(data, h, ensure_ascii=False, separators=(',', ':'))
                    h.flush()
                os.chmod(temp, 384)
                os.replace(temp, path)
                _mem_put(key, data)
                return True
            except Exception:
                try:
                    if os.path.exists(temp) and persistent_write_gate(temp):
                        os.unlink(temp)
                except Exception as exc:
                    diagnostic_failure('tmdb.failsoft', exc)
                return False

    @staticmethod
    def image_url(path, size):
        path = str(path or '').strip()
        if not path:
            return None
        if not path.startswith('/'):
            path = '/' + path
        return IMAGE_BASE + '/' + size + path

    def _cached_image_path(self, url, tag):
        """Return an already-downloaded TMDB image without scheduling I/O/network.

        This is the cold-boot fast path: metadata survives power loss and the
        deterministic URL+tag filename lets us reopen HDD artwork immediately.
        """
        if not url or not hdd_read_ready():
            return None
        if 'backdrop' in str(tag or '').lower():
            from .shared_tmdb_cache import cached_backdrop
            shared = cached_backdrop(url)
            if shared:
                return shared
        digest = hashlib.sha1(url.encode('utf-8', 'ignore')).hexdigest()
        ext = '.png' if url.lower().split('?')[0].endswith('.png') else '.jpg'
        lowtag = str(tag or '').lower()
        if 'backdrop' in lowtag:
            cache_dir = SOURCE_BACKDROP_CACHE_DIR
        elif 'poster' in lowtag:
            cache_dir = SOURCE_POSTER_CACHE_DIR
        else:
            cache_dir = IMAGE_CACHE_DIR
        path = os.path.join(cache_dir, '%s_%s%s' % (tag, digest, ext))
        return path if _valid_image_file(path) else None

    def _download_image(self, url, tag):
        if 'backdrop' in str(tag or '').lower():
            from .shared_tmdb_cache import fetch_backdrop, original_url
            if original_url(url):
                return fetch_backdrop(url, self.timeout)
        if not url or not hdd_ready():
            return None
        digest = hashlib.sha1(url.encode('utf-8', 'ignore')).hexdigest()
        ext = '.png' if url.lower().split('?')[0].endswith('.png') else '.jpg'
        lowtag = str(tag or '').lower()
        if 'backdrop' in lowtag:
            cache_dir = SOURCE_BACKDROP_CACHE_DIR
        elif 'poster' in lowtag:
            cache_dir = SOURCE_POSTER_CACHE_DIR
        else:
            cache_dir = IMAGE_CACHE_DIR
        path = os.path.join(cache_dir, '%s_%s%s' % (tag, digest, ext))
        lock = _path_lock(path)
        with lock:
            temp = path + '.tmp.%d.%d' % (os.getpid(), threading.get_ident())
            try:
                if _valid_image_file(path):
                    return path
                try:
                    if os.path.exists(path) and persistent_write_gate(path):
                        os.unlink(path)
                except OSError:
                    pass
                validate_remote_media_url(url)
                req = urllib.request.Request(url, headers={'User-Agent': UA, 'Accept': 'image/jpeg,image/png'})
                opener = build_safe_media_opener()
                with opener.open(req, timeout=min(max(float(self.timeout), 2.5), 6.0)) as response:
                    media_cap = 8 * 1024 * 1024
                    data = response.read(media_cap + 1)
                if not 1024 < len(data) <= media_cap:
                    return None
                head = data[:16]
                if not (head.startswith(b'\x89PNG\r\n\x1a\n') or head.startswith(b'\xff\xd8\xff') or (head[:4] == b'RIFF' and head[8:12] == b'WEBP')):
                    return None
                if not persistent_write_gate(temp):
                    return None
                with open(temp, 'wb') as h:
                    h.write(data)
                if not persistent_write_gate(path):
                    return None
                os.replace(temp, path)
                return path if _valid_image_file(path) else None
            except Exception:
                return None
            finally:
                try:
                    if os.path.exists(temp) and persistent_write_gate(temp):
                        os.unlink(temp)
                except OSError:
                    pass

    def enrich(self, portal_media_type, item, artwork_mode='full'):
        from .manual_identity import selected
        manual = selected(item)
        requested_type = 'tv' if str(portal_media_type).lower() in ('series', 'tv') else 'movie'
        alternate_type = 'movie' if requested_type == 'tv' else 'tv'
        item = item if isinstance(item, dict) else {}
        raw = str(item.get('name') or item.get('title') or '').strip()
        description_hint = str(item.get('description') or item.get('descr') or item.get('overview') or item.get('plot') or '').strip()
        wanted_year = None
        for k in ('year', 'release_year', 'released', 'release_date', 'first_air_date', 'date'):
            wanted_year = _year(item.get(k))
            if wanted_year:
                break
        if not wanted_year:
            wanted_year = _year(item.get('_raw_name') or item.get('_provider_name') or raw)
        country_hint = _country_hint(item, raw)
        query_fields = ('_raw_name', '_provider_name', 'original_name', 'original_title', 'o_name', 'movie_name', 'series_name', 'title', 'name', 'display_name')
        queries = _enrich_query_list(item, raw, query_fields, _query_variants, _norm, limit=4)
        if not queries:
            return None
        query = queries[0]
        locked_tmdb_id = None
        try:
            locked_tmdb_id = int(item.get('_locked_tmdb_id') or 0) or None
        except Exception:
            locked_tmdb_id = None
        locked_tmdb_type = str(item.get('_locked_tmdb_type') or '').strip().lower()
        explicit_tmdb_type = str(item.get('tmdb_type') or item.get('tmdb_media_type') or '').strip().lower()
        if explicit_tmdb_type in ('series', 'show'):
            explicit_tmdb_type = 'tv'
        if explicit_tmdb_type in ('vod', 'film'):
            explicit_tmdb_type = 'movie'
        direct_tmdb_id, portal_tmdb_id = _direct_tmdb_identity(item, locked_tmdb_id)
        provided_iid = _external_imdb_id(item)
        identity_discriminator = 'tmdb:%s:%s' % (explicit_tmdb_type or locked_tmdb_type or requested_type, direct_tmdb_id) if direct_tmdb_id else 'imdb:' + provided_iid if provided_iid else 'search'
        if _original_language(item):
            identity_discriminator += '|origin_lang:' + _original_language(item)
        key = self._cache_key(requested_type, query, wanted_year, country_hint, identity_discriminator)
        cached = self._cache_read(key)
        _enrich_started = time.time()
        if cached is None and (not manual) and _neg_hit(key):
            return {'matched': False, 'query': query, 'confidence': 0.0, 'reason': 'no_results'}
        if cached is None and str(artwork_mode or 'full').lower() == 'metadata':
            for _legacy_schema in LEGACY_METADATA_CACHE_SCHEMAS:
                try:
                    _legacy_key = self._cache_key(requested_type, query, wanted_year, country_hint, identity_discriminator, schema=_legacy_schema)
                    _legacy = self._cache_read(_legacy_key)
                except Exception:
                    _legacy = None
                if not isinstance(_legacy, dict):
                    continue
                cached = dict(_legacy)
                cached['_metadata_cache_bridge_schema'] = int(_legacy_schema)
                for _art_key in ('poster_url', 'poster_local', 'poster_path', 'backdrop_url', 'backdrop_urls', 'backdrop_local', 'backdrop_path'):
                    cached.pop(_art_key, None)
                for _text_key in ('overview', 'overview_language', 'description', 'descr', 'plot'):
                    cached.pop(_text_key, None)
                cached['_metadata_cache_bridge_textless'] = True
                break
        if manual and cached and (str(cached.get('tmdb_id')) != str(manual['tmdb_id']) or cached.get('media_type') != manual['media_type']):
            cached = None
        if cached and (not manual) and (not _hints_compatible(item, cached, require_known=bool(country_hint or _original_language(item)))):
            cached = None
        if cached:
            cq = _norm(query)
            ct = [_norm(cached.get('title') or ''), _norm(cached.get('original_title') or '')]
            ct = list((x for x in ct if x))
            structured_same = bool(provided_iid and str(cached.get('imdb_id') or '').lower() == str(provided_iid).lower())
            title_same = bool(cq and any((cq == x or (min(len(cq), len(x)) >= 8 and (cq in x or x in cq) and (len(set(cq.split()) & set(x.split())) >= max(1, int(min(len(set(cq.split())), len(set(x.split()))) * 0.8)))) for x in ct)))
            if not manual and (not structured_same) and (not title_same):
                cached = None
        if cached:
            if cached.get('poster_local') and (not _valid_image_file(cached.get('poster_local'))):
                cached['poster_local'] = None
            if cached.get('backdrop_local') and (not _valid_image_file(cached.get('backdrop_local'))):
                cached['backdrop_local'] = None
            urls = []
            for value in (cached.get('backdrop_urls') or []) + ([cached.get('backdrop_url')] if cached.get('backdrop_url') else []):
                value = str(value or '').strip()
                for candidate in (value, value.replace('/w1280/', '/w780/') if '/w1280/' in value else ''):
                    if candidate and candidate not in urls:
                        urls.append(candidate)
            metadata_only = str(artwork_mode or 'full').lower() == 'metadata'
            if not metadata_only and cached.get('poster_url') and (not cached.get('poster_local')):
                cached['poster_local'] = self._cached_image_path(cached.get('poster_url'), 'poster')
                if not cached.get('poster_local'):
                    try:
                        cached['poster_local'] = self._download_image(cached.get('poster_url'), 'poster')
                    except Exception as exc:
                        diagnostic_failure('tmdb.cached_poster', exc)
            poster_only = str(artwork_mode or 'full').lower() == 'poster'
            if not metadata_only and (not poster_only) and (not cached.get('backdrop_local')):
                for idx, url in enumerate(urls[:3]):
                    local = self._cached_image_path(url, 'backdrop_cached_%d' % idx)
                    if not local:
                        try:
                            local = self._download_image(url, 'backdrop_cached_%d' % idx)
                        except Exception as exc:
                            diagnostic_failure('tmdb.cached_backdrop', exc)
                            local = None
                    if local:
                        cached['backdrop_local'] = local
                        cached['backdrop_url'] = url
                        break
            return cached
        ranked = []
        seen = set()

        def add_results(rows, media_type, q):
            if not isinstance(rows, list):
                return
            for row in rows[:20]:
                if not isinstance(row, dict) or not row.get('id'):
                    continue
                if not _hints_compatible(item, row):
                    continue
                sig = (media_type, str(row.get('id')))
                if sig in seen:
                    continue
                seen.add(sig)
                if country_hint and _language_for_country(country_hint):
                    wanted_lang = _language_for_country(country_hint)
                    ol = str(row.get('original_language') or '').lower()
                    origins = [str(x).upper() for x in row.get('origin_country') or [] if str(x or '').strip()]
                    if origins and country_hint not in origins and ol and wanted_lang and (ol != wanted_lang):
                        continue
                score = _score(q, row, media_type, wanted_year, requested_type, country_hint, description_hint)
                ranked.append((score, row, media_type, q))
        authoritative_direct = False
        if direct_tmdb_id:
            direct_candidates = []
            namespaces = []
            preferred_direct_type = locked_tmdb_type if locked_tmdb_type in ('movie', 'tv') else explicit_tmdb_type if explicit_tmdb_type in ('movie', 'tv') else requested_type
            namespaces.append(preferred_direct_type)
            if locked_tmdb_id and alternate_type not in namespaces and (not manual):
                namespaces.append(alternate_type)
            for media_type in namespaces:
                try:
                    row = self._get('/%s/%s' % (media_type, direct_tmdb_id), {'language': self.language})
                    if not isinstance(row, dict) or not row.get('id') or (manual and str(row['id']) != str(manual['tmdb_id'])) or (not manual and (not _hints_compatible(item, row))):
                        continue
                    best_direct = 0.0
                    best_q = query
                    for q in queries:
                        value = _score(q, row, media_type, wanted_year, requested_type, country_hint, description_hint)
                        if value > best_direct:
                            best_direct = value
                            best_q = q
                    direct_aliases = list((item.get(k) for k in ('original_name', 'original_title', 'o_name', 'movie_name', 'series_name', 'english_name', 'english_title', 'display_name', 'title', 'name') if item.get(k)))
                    proof = _identity_match_evidence(best_q, row, media_type, wanted_year, country_hint, description_hint, aliases=direct_aliases)
                    internally_verified = bool(locked_tmdb_id and str(item.get('_ultra_search_verified_tmdb_id') or '') == str(locked_tmdb_id))
                    original_name = str(row.get('original_title') or row.get('original_name') or row.get('title') or row.get('name') or '')
                    cross_script = bool(_has_arabic(best_q)) != bool(_has_arabic(original_name))
                    country_codes = []
                    for value in row.get('origin_country') or []:
                        text = str(value or '').strip().upper()
                        if text:
                            country_codes.append(text)
                    for value in row.get('production_countries') or []:
                        text = str((value.get('iso_3166_1') if isinstance(value, dict) else value) or '').strip().upper()
                        if text:
                            country_codes.append(text)
                    country_conflict = bool(country_hint and country_codes and (str(country_hint).upper() not in country_codes))
                    if internally_verified or (proof.get('trusted') and int(proof.get('independent_evidence') or 0) >= 1 and (best_direct >= 0.62)):
                        bonus = 0.997 if internally_verified else min(0.97, best_direct + 0.03)
                        direct_candidates.append((bonus, row, media_type, best_q))
                    elif cross_script and (not proof.get('year_conflict')) and (not country_conflict):
                        direct_candidates.append((0.9, row, media_type, best_q))
                    else:
                        LOG.info('Rejected direct TMDB id=%s namespace=%s title=%r score=%.3f evidence=%s', direct_tmdb_id, media_type, row.get('title') or row.get('name'), best_direct, proof.get('independent_evidence'))
                except Exception as exc:
                    LOG.debug('Direct TMDB lookup failed id=%s namespace=%s: %s', direct_tmdb_id, media_type, exc)
            for candidate in direct_candidates:
                score, row, media_type, q = candidate
                sig = (media_type, str(row.get('id')))
                if sig in seen:
                    continue
                seen.add(sig)
                ranked.append(candidate)
            if direct_candidates and (locked_tmdb_id or portal_tmdb_id):
                direct_candidates.sort(key=lambda x: x[0], reverse=True)
                ranked = [direct_candidates[0]]
                authoritative_direct = True
        if manual and (not authoritative_direct):
            return {'matched': False, 'tmdb_id': manual['tmdb_id'], 'media_type': manual['media_type'], 'reason': 'manual_selection_unavailable'}
        iid = provided_iid
        if iid and (not authoritative_direct):
            try:
                found = self._get('/find/%s' % iid, {'external_source': 'imdb_id', 'language': self.language})
                add_results(found.get('movie_results'), 'movie', query)
                add_results(found.get('tv_results'), 'tv', query)
            except Exception as exc:
                try:
                    LOG.info('TMDB find failed imdb=%s: %s', iid, exc)
                except Exception as exc:
                    diagnostic_failure('tmdb.failsoft', exc)

        def _search_languages(q):
            langs = []
            if _has_arabic(q) or _has_arabic(raw):
                for lang in (self.language or 'ar', 'en-US'):
                    if lang and lang not in langs:
                        langs.append(lang)
                return langs or ['ar']
            if _latin_heavy(q) and (country_hint in ('KR', 'TR', 'IN', 'MY', 'ID', 'TH', 'JP', 'CN', 'PH') or any((ord(ch) > 127 for ch in raw))):
                return ['en-US']
            return [self.language or 'en-US']
        if not authoritative_direct and (not ranked or max(list((x[0] for x in ranked)) or [0]) < 0.84):
            for q in queries:
                media_type = requested_type
                attempts = [True, False] if wanted_year else [False]
                for with_year in attempts:
                    for search_language in _search_languages(q):
                        params = {'query': q, 'language': search_language, 'include_adult': 'false'}
                        if with_year and wanted_year:
                            params['year' if media_type == 'movie' else 'first_air_date_year'] = wanted_year
                        try:
                            payload = self._get('/search/' + media_type, params)
                            add_results(payload.get('results'), media_type, q)
                        except Exception as exc:
                            try:
                                LOG.info('TMDB search failed type=%s q=%r year=%s: %s', media_type, q, wanted_year if with_year else None, exc)
                            except Exception as exc:
                                diagnostic_failure('tmdb.failsoft', exc)
                        if ranked and max((x[0] for x in ranked)) >= 0.91:
                            break
                    if ranked and max((x[0] for x in ranked)) >= 0.91:
                        break
                if ranked and max((x[0] for x in ranked)) >= 0.86:
                    break
            requested_best = max(list((x[0] for x in ranked if x[2] == requested_type)) or [0])
            alternate_gate = 0.88 if country_hint else 0.66
            if requested_best < alternate_gate:
                for q in queries[:3]:
                    media_type = alternate_type
                    for search_language in _search_languages(q):
                        params = {'query': q, 'language': search_language, 'include_adult': 'false'}
                        if wanted_year:
                            params['year' if media_type == 'movie' else 'first_air_date_year'] = wanted_year
                        try:
                            payload = self._get('/search/' + media_type, params)
                            add_results(payload.get('results'), media_type, q)
                        except Exception as exc:
                            diagnostic_failure('tmdb.failsoft', exc)
                        if ranked and max((x[0] for x in ranked)) >= 0.9:
                            break
                    if ranked and max((x[0] for x in ranked)) >= 0.9:
                        break
        requested_best = max(list((x[0] for x in ranked if x[2] == requested_type)) or [0])
        if not authoritative_direct and (not ranked or requested_best < 0.48) and (not wanted_year):
            for q in queries[:1]:
                try:
                    for search_language in _search_languages(q):
                        payload = self._get('/search/multi', {'query': q, 'language': search_language, 'include_adult': 'false'})
                        for row in payload.get('results') or []:
                            mt = str(row.get('media_type') or '')
                            if mt in ('movie', 'tv'):
                                add_results([row], mt, q)
                        if ranked and max((x[0] for x in ranked)) >= 0.86:
                            break
                except Exception as exc:
                    diagnostic_failure('tmdb.failsoft', exc)
        ranked.sort(key=lambda x: x[0], reverse=True)
        if not ranked:
            try:
                LOG.info('TMDB no result raw=%r cleaned=%r year=%r', raw, queries, wanted_year)
            except Exception as exc:
                diagnostic_failure('tmdb.failsoft', exc)
            if _LAST_ERROR_TS[0] < _enrich_started:
                _neg_put(key)
            return {'matched': False, 'query': query, 'confidence': 0.0, 'reason': 'no_results'}
        confidence, best, media_type, matched_query = ranked[0]
        by = _year(best.get('release_date') if media_type == 'movie' else best.get('first_air_date'))
        threshold = 0.54 if wanted_year and by and (abs(int(wanted_year) - int(by)) <= 1) else 0.62
        if media_type != requested_type:
            threshold = max(threshold, 0.86)
        if wanted_year and by and (abs(int(wanted_year) - int(by)) >= 3):
            threshold = max(threshold, 0.76)
        if confidence < threshold:
            try:
                LOG.info('TMDB low confidence raw=%r cleaned=%r best=%r score=%.3f', raw, queries, best.get('title') or best.get('name'), confidence)
            except Exception as exc:
                diagnostic_failure('tmdb.failsoft', exc)
            return {'matched': False, 'query': query, 'confidence': confidence, 'reason': 'low_confidence'}
        best_title = best.get('title') if media_type == 'movie' else best.get('name')
        best_original = best.get('original_title') if media_type == 'movie' else best.get('original_name')
        title_exact = bool(_norm(matched_query) and _norm(matched_query) in (_norm(best_title or ''), _norm(best_original or '')))
        title_tokens = list((x for x in _norm(matched_query).split() if x))
        evidence = 1 if title_exact else 0
        if title_exact and (len(title_tokens) >= 2 or len(_norm(matched_query)) >= 12):
            evidence += 1
        if wanted_year and by and (abs(int(wanted_year) - int(by)) <= 1):
            evidence += 1
        if country_hint:
            wanted_lang = _language_for_country(country_hint)
            ol = str(best.get('original_language') or '').lower()
            origins = list((str(x).upper() for x in best.get('origin_country') or []))
            if wanted_lang and ol == wanted_lang or country_hint in origins:
                evidence += 1
        desc_sim = _description_similarity(description_hint, best.get('overview') or '')
        if desc_sim >= 0.16:
            evidence += 1
        raw_primary = _norm(tmdb_search_aliases(item.get('_raw_name') or raw)[0] if tmdb_search_aliases(item.get('_raw_name') or raw) else raw)
        candidate_titles = [_norm(best_title or ''), _norm(best_original or '')]
        primary_exact = bool(raw_primary and raw_primary in candidate_titles)
        primary_tokens = set(raw_primary.split())
        candidate_token_sets = list((set(x.split()) for x in candidate_titles if x))
        primary_overlap = max(list((float(len(primary_tokens & x)) / float(max(1, max(len(primary_tokens), len(x)))) for x in candidate_token_sets)) or [0.0])
        strong_primary = bool(primary_exact or (len(raw_primary) >= 8 and primary_overlap >= 0.75 and (max(list((difflib.SequenceMatcher(None, raw_primary, x).ratio() for x in candidate_titles if x)) or [0.0]) >= 0.78)))
        structured_independent = bool(provided_iid or (authoritative_direct and (locked_tmdb_id or portal_tmdb_id)))
        identity_verified = bool(structured_independent or (strong_primary and evidence >= 2))
        structured_evidence = bool(provided_iid or (authoritative_direct and (locked_tmdb_id or portal_tmdb_id)) or (wanted_year and by and (abs(int(wanted_year) - int(by)) <= 1)))
        if country_hint:
            wanted_lang = _language_for_country(country_hint)
            ol = str(best.get('original_language') or '').lower()
            origins = list((str(x).upper() for x in best.get('origin_country') or []))
            structured_evidence = structured_evidence or bool(wanted_lang and ol == wanted_lang or country_hint in origins)
        if len(title_tokens) <= 1 and (not structured_evidence):
            identity_verified = False
        if not identity_verified and (_has_arabic(matched_query) or _has_arabic(raw)):
            qn = _norm(matched_query)
            close = bool(qn and qn in candidate_titles and (len(qn.split()) >= 2 or len(qn) >= 8))
            if not close and qn:
                qset = set(qn.split())
                for name in candidate_titles:
                    if not name or min(len(qn), len(name)) < 6:
                        continue
                    nset = set(name.split())
                    overlap = float(len(qset & nset)) / float(max(1, max(len(qset), len(nset))))
                    ratio = difflib.SequenceMatcher(None, qn, name).ratio()
                    if overlap >= 0.75 and ratio >= 0.72:
                        close = True
                        break
                    if len(qset) >= 2 and overlap >= 0.66 and (qn in name or name in qn):
                        close = True
                        break
            year_conflict = bool(wanted_year and by and (abs(int(wanted_year) - int(by)) >= 3))
            olang = str(best.get('original_language') or '').lower()
            exact_ar = bool(qn and _has_arabic(qn) and (qn in candidate_titles))
            if exact_ar and (not year_conflict) and (len(title_tokens) > 1 or olang == 'ar' or desc_sim >= 0.12):
                identity_verified = True
            elif close and (not year_conflict) and (len(title_tokens) > 1):
                identity_verified = True
        if not identity_verified:
            try:
                LOG.info('TMDB rejected ambiguous identity raw=%r best=%r score=%.3f evidence=%s', raw, best_title, confidence, evidence)
            except Exception as exc:
                diagnostic_failure('tmdb.failsoft', exc)
            return {'matched': False, 'query': query, 'confidence': confidence, 'reason': 'ambiguous_identity'}
        if authoritative_direct:
            identity_source = 'locked_cache' if locked_tmdb_id else 'portal_tmdb_id'
        elif provided_iid:
            identity_source = 'portal_imdb_id'
        else:
            identity_source = 'verified_search'
        tmdb_id = best.get('id')
        try:
            _rating_append = 'release_dates' if media_type == 'movie' else 'content_ratings'
            details = self._get('/%s/%s' % (media_type, tmdb_id), {'language': self.language, 'append_to_response': 'credits,images,external_ids,%s' % _rating_append, 'include_image_language': 'ar,en,null'})
        except Exception as exc:
            return {'matched': False, 'query': query, 'confidence': confidence, 'error': str(exc), 'reason': 'details_failed'}
        fallback = None
        overview = str(details.get('overview') or '').strip()
        overview_language = self.language if overview else ''
        if not overview:
            try:
                fallback = self._get('/%s/%s' % (media_type, tmdb_id), {'language': 'en-US', 'append_to_response': 'credits,external_ids'})
            except Exception:
                fallback = None
            overview = str((fallback or {}).get('overview') or '').strip()
            overview_language = 'en-US' if overview else ''
        title = details.get('title') if media_type == 'movie' else details.get('name')
        original_title = details.get('original_title') if media_type == 'movie' else details.get('original_name')
        date = details.get('release_date') if media_type == 'movie' else details.get('first_air_date')
        genres = list((str(x.get('name')) for x in details.get('genres') or [] if isinstance(x, dict) and x.get('name')))
        if not genres and self.language.lower() != 'en-us':
            if fallback is None:
                try:
                    fallback = self._get('/%s/%s' % (media_type, tmdb_id), {'language': 'en-US', 'append_to_response': 'credits,external_ids'})
                except Exception:
                    fallback = {}
            genres = list((str(x.get('name')) for x in (fallback or {}).get('genres') or [] if isinstance(x, dict) and x.get('name')))
        runtime = details.get('runtime')
        if media_type == 'tv' and (not runtime):
            runtimes = details.get('episode_run_time') or []
            runtime = runtimes[0] if isinstance(runtimes, list) and runtimes else None
        credits = details.get('credits') if isinstance(details.get('credits'), dict) else {}
        cast = list((str(p.get('name')) for p in (credits.get('cast') or [])[:6] if isinstance(p, dict) and p.get('name')))
        directors = []
        writers = []
        crew = []
        for p in credits.get('crew') or []:
            if not isinstance(p, dict) or not p.get('name'):
                continue
            name = str(p.get('name'))
            job = str(p.get('job') or '')
            dept = str(p.get('department') or '')
            if job == 'Director' and name not in directors:
                directors.append(name)
            if job in ('Writer', 'Screenplay', 'Story', 'Teleplay', 'Original Story', 'Novel') or dept == 'Writing':
                if name not in writers:
                    writers.append(name)
            if job in ('Director', 'Creator', 'Executive Producer') and name not in crew:
                crew.append(name)
        if media_type == 'tv':
            for p in details.get('created_by') or []:
                if isinstance(p, dict) and p.get('name'):
                    name = str(p.get('name'))
                    if name not in writers:
                        writers.insert(0, name)
                    if name not in crew:
                        crew.insert(0, name)
        external_ids = details.get('external_ids') if isinstance(details.get('external_ids'), dict) else {}
        imdb_id = str(external_ids.get('imdb_id') or iid or '').strip()
        countries = _tmdb_country_codes(details, media_type)
        certification = _tmdb_certification(details, media_type)
        if not certification:
            try:
                rating_payload = self._get(rating_endpoint(media_type, tmdb_id)) or {}
            except Exception as exc:
                try:
                    LOG.info('TMDB age-rating lookup failed type=%s id=%s: %s', media_type, tmdb_id, exc)
                except Exception:
                    pass
                rating_payload = {}
            certification = _tmdb_certification(details, media_type, supplemental=rating_payload)
        if self.language.lower() != 'en-us' and (not cast or not directors or (not writers)):
            try:
                if fallback is None or not isinstance((fallback or {}).get('credits'), dict):
                    fallback = self._get('/%s/%s' % (media_type, tmdb_id), {'language': 'en-US', 'append_to_response': 'credits,external_ids'}) or {}
                encredits = fallback.get('credits') if isinstance(fallback.get('credits'), dict) else {}
                if not cast:
                    cast = list((str(p.get('name')) for p in (encredits.get('cast') or [])[:6] if isinstance(p, dict) and p.get('name')))
                if not directors or not writers:
                    edirectors = []
                    ewriters = []
                    for p in encredits.get('crew') or []:
                        if not isinstance(p, dict) or not p.get('name'):
                            continue
                        ename = str(p.get('name'))
                        job = str(p.get('job') or '')
                        dept = str(p.get('department') or '')
                        if job == 'Director' and ename not in edirectors:
                            edirectors.append(ename)
                        if job in ('Writer', 'Screenplay', 'Story', 'Teleplay', 'Original Story', 'Novel') or dept == 'Writing':
                            if ename not in ewriters:
                                ewriters.append(ename)
                    if media_type == 'tv':
                        for p in fallback.get('created_by') or []:
                            if isinstance(p, dict) and p.get('name') and (str(p.get('name')) not in ewriters):
                                ewriters.insert(0, str(p.get('name')))
                    if not directors and edirectors:
                        directors = edirectors[:3]
                    if not writers and ewriters:
                        writers = ewriters[:4]
            except Exception as exc:
                LOG.debug('English credit fallback failed id=%s: %s', tmdb_id, exc)
        images = details.get('images') if isinstance(details.get('images'), dict) else {}
        logo_path = ''
        logo_language = ''
        logos = images.get('logos') if isinstance(images, dict) else []
        if logos:
            try:
                from .title_logo_runtime import title_logo_policy_languages
                _policy_row = {'original_language': str(details.get('original_language') or best.get('original_language') or '').lower(), 'origin_country': details.get('origin_country') or best.get('origin_country') or [], 'countries': details.get('production_countries') or []}
                _allowed = title_logo_policy_languages({}, _policy_row) or ('en',)
                _logo_rows = list((x for x in logos if isinstance(x, dict) and x.get('file_path')))
                _picked = None
                for _wanted in _allowed:
                    _same = list((x for x in _logo_rows if str(x.get('iso_639_1') or '').lower() == _wanted))
                    _same.sort(key=lambda x: (float(x.get('vote_average') or 0), int(x.get('width') or 0)), reverse=True)
                    if _same:
                        _picked = _same[0]
                        break
                if _picked is None:
                    _neutral = list((x for x in _logo_rows if x.get('iso_639_1') in (None, '')))
                    _neutral.sort(key=lambda x: (float(x.get('vote_average') or 0), int(x.get('width') or 0)), reverse=True)
                    if _neutral:
                        _picked = _neutral[0]
                if _picked is None:
                    _other = list((x for x in _logo_rows if str(x.get('iso_639_1') or '').lower() not in set(_allowed) and x.get('iso_639_1') not in (None, '')))
                    _other.sort(key=lambda x: (float(x.get('vote_average') or 0), int(x.get('width') or 0)), reverse=True)
                    if _other:
                        _picked = _other[0]
                if _picked:
                    logo_path = str(_picked.get('file_path') or '')
                    logo_language = str(_picked.get('iso_639_1') or '').lower()
            except Exception:
                logo_path = ''
                logo_language = ''
        backdrop_path = str(details.get('backdrop_path') or '').strip()
        poster_path = str(details.get('poster_path') or '').strip()
        backdrop_paths = []

        def _add_backdrop_path(value):
            value = str(value or '').strip()
            if value and value not in backdrop_paths:
                backdrop_paths.append(value)
        _add_backdrop_path(backdrop_path)
        if not backdrop_path or not poster_path:
            try:
                primary_fallback = self._get('/%s/%s' % (media_type, tmdb_id), {}) or {}
            except Exception:
                primary_fallback = {}
            if not backdrop_path:
                backdrop_path = str(primary_fallback.get('backdrop_path') or '').strip()
                _add_backdrop_path(backdrop_path)
            if not poster_path:
                poster_path = str(primary_fallback.get('poster_path') or '').strip()
        if not backdrop_path or not poster_path:
            try:
                image_payload = self._get('/%s/%s/images' % (media_type, tmdb_id), {'include_image_language': 'ar,en,null'}) or {}
            except Exception as exc:
                try:
                    LOG.info('TMDB images fallback lookup failed type=%s id=%s: %s', media_type, tmdb_id, exc)
                except Exception:
                    pass
                image_payload = {}
            if not backdrop_path:
                backs = list((x for x in image_payload.get('backdrops') or [] if isinstance(x, dict) and x.get('file_path') and (int(x.get('width') or 0) >= int(x.get('height') or 1))))
                backs.sort(key=lambda x: (int(x.get('width') or 0), float(x.get('vote_average') or 0), int(x.get('vote_count') or 0)), reverse=True)
                if backs:
                    backdrop_path = str(backs[0].get('file_path') or '').strip()
                    _add_backdrop_path(backdrop_path)
            if not poster_path:
                posts = list((x for x in image_payload.get('posters') or [] if isinstance(x, dict) and x.get('file_path') and (int(x.get('height') or 0) > int(x.get('width') or 0))))
                lang = str(self.language or '').split('-')[0].lower()

                def _poster_rank(row):
                    iso = str(row.get('iso_639_1') or '').lower()
                    lang_bonus = 3 if iso == lang else 2 if iso == 'en' else 1 if not iso else 0
                    return (lang_bonus, int(row.get('width') or 0), float(row.get('vote_average') or 0), int(row.get('vote_count') or 0))
                posts.sort(key=_poster_rank, reverse=True)
                if posts:
                    poster_path = str(posts[0].get('file_path') or '').strip()
        _add_backdrop_path(backdrop_path)
        result = {'matched': True, 'identity_verified': True, 'identity_source': identity_source, 'identity_evidence': int(evidence), 'source': 'TMDB', 'media_type': media_type, 'tmdb_id': tmdb_id, 'confidence': round(float(confidence), 3), 'query': matched_query, 'title': str(title or query), 'original_title': str(original_title or ''), 'original_language': str(details.get('original_language') or best.get('original_language') or '').lower(), 'overview': overview, 'overview_language': overview_language, 'country_hint': country_hint, 'year': _year(date), 'release_date': date or '', 'rating': details.get('vote_average'), 'vote_count': details.get('vote_count'), 'certification': certification, 'age_rating': certification, 'genres': genres, 'runtime': runtime, 'number_of_seasons': details.get('number_of_seasons') or 0, 'number_of_episodes': details.get('number_of_episodes') or 0, 'cast': cast, 'crew': crew[:4], 'directors': directors[:3], 'writers': writers[:4], 'status': str(details.get('status') or ''), 'tagline': str(details.get('tagline') or ''), 'production_companies': list((str(x.get('name')) for x in (details.get('production_companies') or [])[:4] if isinstance(x, dict) and x.get('name'))), 'production_countries': list((str(x.get('name') or x.get('iso_3166_1') or '') for x in (details.get('production_countries') or [])[:4] if isinstance(x, dict) and (x.get('name') or x.get('iso_3166_1')))), 'budget': details.get('budget') or 0, 'revenue': details.get('revenue') or 0, 'networks': list((str(x.get('name')) for x in (details.get('networks') or [])[:4] if isinstance(x, dict) and x.get('name'))), 'created_by': list((str(x.get('name')) for x in (details.get('created_by') or [])[:4] if isinstance(x, dict) and x.get('name'))), 'type': str(details.get('type') or ''), 'in_production': details.get('in_production') if isinstance(details.get('in_production'), bool) else None, 'episode_run_time': details.get('episode_run_time') or [], 'original_name': str(original_title or ''), 'last_air_date': str(details.get('last_air_date') or ''), 'imdb_id': imdb_id, 'countries': countries[:3], 'poster_url': self.image_url(poster_path, 'w500'), 'logo_url': self.image_url(logo_path, 'w500') if logo_path else '', 'logo_language': logo_language, 'backdrop_url': self.image_url(backdrop_paths[0] if backdrop_paths else backdrop_path, 'original'), 'backdrop_urls': list((self.image_url(x, 'original') for x in backdrop_paths[:6] if self.image_url(x, 'original')))}
        try:
            LOG.info('TMDB match raw=%r query=%r -> %r type=%s score=%.3f id=%s', raw, matched_query, title, media_type, confidence, tmdb_id)
        except Exception as exc:
            diagnostic_failure('tmdb.failsoft', exc)
        result.pop('poster_local', None)
        result.pop('backdrop_local', None)
        try:
            self._cache_write(key, {k: v for k, v in result.items() if k not in ('poster_local', 'backdrop_local')})
        except Exception as exc:
            diagnostic_failure('tmdb.failsoft', exc)
        return result
