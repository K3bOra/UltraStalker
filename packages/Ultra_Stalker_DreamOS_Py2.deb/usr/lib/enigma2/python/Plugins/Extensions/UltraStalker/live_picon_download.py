"""Bounded, atomic Live picon downloads using the caller's validated opener."""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str, int, open, max, min, OSError, TimeoutError, ConnectionError
__metaclass__ = type  # new-style classes on Python 2
import gzip
os = _us_env.os
socket = _us_env.socket
import struct
import tempfile
threading = _us_env.threading
time = _us_env.time
urllib = _us_env.urllib
OrderedDict = _us_env.collections.OrderedDict

try:
    from PIL import Image
except ImportError:
    Image=None

try:
    from .pil_compat import supports_webp as _supports_webp
except Exception:
    _supports_webp = lambda: False


_FAILURES=OrderedDict()
_FAILURE_LOCK=threading.Lock()
_VALIDATIONS=OrderedDict()
_VALIDATION_PENDING=set()
_VALIDATION_LOCK=threading.Lock()


class _Deadline:
    """One time budget across redirects, header retries and streaming reads."""
    def __init__(self,seconds):
        self.until=time.monotonic()+seconds
        self._lock=threading.Lock()
        self._sockets=[]
        self._expired=False
        self._timer=threading.Timer(seconds,self._abort)
        self._timer.daemon=True
        self._timer.start()

    def check(self):
        remaining=self.until-time.monotonic()
        if self._expired or remaining<=0:raise TimeoutError('Live picon total time limit')
        return remaining

    @staticmethod
    def _close(sock):
        try:sock.shutdown(socket.SHUT_RDWR)
        except OSError:pass
        try:sock.close()
        except OSError:pass

    def attach(self,sock):
        with self._lock:
            if not self._expired:
                self._sockets.append(sock)
                return
        self._close(sock)
        self.check()

    def _abort(self):
        with self._lock:
            self._expired=True
            sockets=self._sockets[:]
        for sock in sockets:self._close(sock)

    def close(self):
        self._timer.cancel()
        with self._lock:self._sockets=[]


def _fingerprint(path):
    try:
        st=os.stat(path)
        return (st.st_dev,st.st_ino,st.st_size,getattr(st, "st_mtime_ns", int(st.st_mtime * 1000000000)),
                getattr(st, "st_ctime_ns", int(st.st_ctime * 1000000000)))
    except OSError:return None


def cache_status(path):
    """True/False for a checked file, None for a new/replaced file; GUI-cheap."""
    stamp=_fingerprint(path)
    if stamp is None:return False
    with _VALIDATION_LOCK:
        cached=_VALIDATIONS.get(path)
        if cached and cached[0]==stamp:
            _VALIDATIONS.move_to_end(path)
            return cached[1]
    return None


def _remember_validity(path,stamp,valid):
    if stamp is None:return
    with _VALIDATION_LOCK:
        _VALIDATIONS[path]=(stamp,bool(valid))
        _VALIDATIONS.move_to_end(path)
        while len(_VALIDATIONS)>1024:_VALIDATIONS.popitem(last=False)


def _native_container_valid(path):
    """Fallback for native PNG/JPEG/WebP when that Pillow codec is unavailable."""
    size=os.path.getsize(path)
    if not 16<size<=8*1024*1024:return False
    with open(path,'rb') as handle:
        head=handle.read(16)
        if head.startswith(b'RIFF') and head[8:12]==b'WEBP':
            return 12<struct.unpack('<I',head[4:8])[0]+8<=size
        if head.startswith(b'\xff\xd8\xff'):
            handle.seek(max(0,size-4096));return b'\xff\xd9' in handle.read()
        if head.startswith(b'\x89PNG\r\n\x1a\n'):
            import zlib
            handle.seek(8);has_header=False
            while handle.tell()+12<=size:
                length,kind=struct.unpack('>I4s',handle.read(8))
                if length>size-handle.tell()-4:return False
                payload=handle.read(length);crc=handle.read(4)
                if zlib.crc32(kind+payload)&0xffffffff!=struct.unpack('>I',crc)[0]:return False
                if kind==b'IHDR':
                    if length!=13:return False
                    width,height=struct.unpack('>II',payload[:8])
                    if not 0<width*height<=4*1024*1024:return False
                    has_header=True
                if kind==b'IEND':return has_header and length==0
    return False


def validate_cached(path):
    """Decode existing logos off the GUI thread; never delete unrelated cache."""
    stamp=_fingerprint(path)
    if stamp is None:return False
    known=cache_status(path)
    if known is not None:return known
    valid=False
    try:
        if not 16<stamp[2]<=8*1024*1024:raise ValueError('Live picon cache size limit')
        if Image is None:
            valid=_native_container_valid(path)
        else:
            native_webp=False
            if str(path).lower().endswith('.webp'):
                try:
                    from PIL import features
                    native_webp=not features.check('webp')
                except Exception:
                    native_webp=not _supports_webp()
            if native_webp:
                valid=_native_container_valid(path)
            else:
                try:
                    with Image.open(path) as image:
                        if not 0<image.width*image.height<=4*1024*1024:raise ValueError('Live picon pixel limit')
                        image.verify()
                    with Image.open(path) as image:image.load()
                    valid=True
                except ValueError:
                    raise
                except Exception:
                    valid=_native_container_valid(path)
    except Exception:valid=False
    if _fingerprint(path)!=stamp:return False
    _remember_validity(path,stamp,valid)
    return valid


def cached_file(path,validate=False):
    """First paint can use legacy cache while a bounded local job verifies it."""
    status=cache_status(path)
    if status is not None:return status
    if validate:return validate_cached(path)
    with _VALIDATION_LOCK:
        if path in _VALIDATION_PENDING or len(_VALIDATION_PENDING)>=64:return True
        _VALIDATION_PENDING.add(path)
    def worker():
        try:validate_cached(path)
        finally:
            with _VALIDATION_LOCK:_VALIDATION_PENDING.discard(path)
    try:
        from .core.shared_executors import LIVE_PICON_RENDER_EXECUTOR
        future=LIVE_PICON_RENDER_EXECUTOR.submit(worker,priority=2,_task_key='live-picon-check:'+path)
        def finished(_future):
            with _VALIDATION_LOCK:_VALIDATION_PENDING.discard(path)
        future.add_done_callback(finished)
    except Exception:
        with _VALIDATION_LOCK:_VALIDATION_PENDING.discard(path)
    return True


def retry_allowed(digest):
    with _FAILURE_LOCK:
        until=_FAILURES.get(digest,0)
        if time.monotonic()<until:return False
        _FAILURES.pop(digest,None)
        return True


def note_failure(digest):
    # One dead shared logo must not hold every channel's fallback behind the
    # same failing download. Hashes include the full URL, including its token.
    with _FAILURE_LOCK:
        _FAILURES[digest]=time.monotonic()+30
        _FAILURES.move_to_end(digest)
        while len(_FAILURES)>512:_FAILURES.popitem(last=False)


def download(url,root,digest,opener,headers,alternate_headers=None,timeout=5.5,max_bytes=2*1024*1024,total_timeout=None):
    seconds=max(0.1,float(total_timeout)) if total_timeout is not None else min(12.0,max(2.0,float(timeout)*2))
    deadline=_Deadline(seconds)
    try:
        return _download(url,root,digest,opener,headers,alternate_headers,timeout,max_bytes,deadline)
    finally:deadline.close()


def _download(url,root,digest,opener,headers,alternate_headers,timeout,max_bytes,deadline):
    limit=max(256*1024,min(8*1024*1024,int(max_bytes or 2*1024*1024)))
    attempts=[headers]+([alternate_headers] if alternate_headers is not None else [])
    for position,source_headers in enumerate(attempts):
        paths=[]
        try:
            deadline.check()
            fd,raw=tempfile.mkstemp(prefix='.'+digest+'-',suffix='.download',dir=root)
            os.close(fd);paths.append(raw)
            request_headers=dict(source_headers)
            request_headers['Accept-Encoding']='identity'
            if not _supports_webp():
                request_headers['Accept']='image/png,image/jpeg,image/*;q=0.8,*/*;q=0.1'
            request_headers.pop('Range',None)
            request=urllib.request.Request(url,headers=request_headers)
            request._media_deadline=deadline
            total=0
            with opener.open(request,timeout=min(max(0.1,min(float(timeout),7.0)),deadline.check())) as response,open(raw,'wb') as handle:
                read=getattr(response,'read1',response.read)
                while True:
                    deadline.check()
                    chunk=read(65536)
                    deadline.check()
                    if not chunk:break
                    total+=len(chunk)
                    if total>limit:raise ValueError('Live picon size limit')
                    handle.write(chunk)
            with open(raw,'rb') as handle:head=handle.read(16)
            if head.startswith(b'\x1f\x8b'):
                fd,decoded=tempfile.mkstemp(prefix='.'+digest+'-',suffix='.decoded',dir=root)
                os.close(fd);paths.append(decoded)
                total=0
                with gzip.open(raw,'rb') as source,open(decoded,'wb') as handle:
                    while True:
                        deadline.check()
                        chunk=source.read(65536)
                        if not chunk:break
                        total+=len(chunk)
                        if total>limit:raise ValueError('Live picon decoded size limit')
                        handle.write(chunk)
                raw=decoded
                with open(raw,'rb') as handle:head=handle.read(16)
            if total<=16:raise ValueError('Empty live picon')
            if Image is not None:
                fd,converted=tempfile.mkstemp(prefix='.'+digest+'-',suffix='.png',dir=root)
                os.close(fd);paths.append(converted)
                try:
                    with Image.open(raw) as image:
                        if image.width*image.height>4*1024*1024:raise ValueError('Live picon pixel limit')
                        image.seek(0)
                        resampling=getattr(Image,'Resampling',Image)
                        image.thumbnail((360,360),resampling.LANCZOS)
                        image=image.convert('RGBA' if 'A' in image.getbands() or 'transparency' in image.info else 'RGB')
                        image.save(converted,'PNG',compress_level=1,optimize=False)
                    raw=converted;ext='.png'
                except ValueError:
                    raise
                except Exception:
                    if head.startswith(b'\x89PNG\r\n\x1a\n') and _native_container_valid(raw):ext='.png'
                    elif head.startswith(b'\xff\xd8\xff') and _native_container_valid(raw):ext='.jpg'
                    else:raise
            elif head.startswith(b'\x89PNG\r\n\x1a\n'):ext='.png'
            elif head.startswith(b'\xff\xd8\xff'):ext='.jpg'
            else:raise ValueError('Unsupported live picon format')
            if Image is None and not _native_container_valid(raw):raise ValueError('Invalid native live picon')
            target=os.path.join(root,digest+ext)
            deadline.check()
            os.chmod(raw,0o600)
            os.replace(raw,target)
            _remember_validity(target,_fingerprint(target),True)
            return target
        except Exception as exc:
            close=getattr(exc,'close',None)
            if callable(close):close()
            # A different User-Agent cannot repair an unreachable host or HTTP 404/410.
            http_not_found=isinstance(exc,urllib.error.HTTPError) and int(getattr(exc,'code',0) or 0) in (404,410)
            unreachable=(isinstance(exc,(TimeoutError,ConnectionError,urllib.error.URLError)) and not isinstance(exc,urllib.error.HTTPError)) or http_not_found
            if position+1==len(attempts) or unreachable:raise
        finally:
            for path in paths:
                try:os.unlink(path)
                except OSError:pass
    return None
