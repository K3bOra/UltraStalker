"""Portal browser screen extracted from ui.py without changing class behavior."""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str, int, max, min, OSError, us_func

from .core.parental import authorize_settings_change as _authorize_parental_change

from .ui_compact_footer import compact_footer_skin, install_compact_footer
from . import _
from .ui_floating_notice import show_notice
from Screens.Screen import Screen
from .ui_async import AsyncScreenMixin
from .ui_image_loader import ImageLoaderMixin
from .ui_transition import TransitionMixin
from .ui_fixed_adaptive import fixed_home_assets
time = _us_env.time
os = _us_env.os
import weakref
OrderedDict = _us_env.collections.OrderedDict
from .core.runtime_log import diagnostic_breadcrumb as _ui_diag
from .log import diagnostic_failure, get_logger, memory_snapshot as _mem34
LOG = get_logger()
from .core.call_compat import call_compatible
from .category_visibility import category_id as _visibility_category_id, hidden_ids as _profile_hidden_ids, hidden_update as _profile_hidden_update
from .ui_settings_inline_choice import SettingsInlineChoiceOverlay
from .live_folder_tools import LiveFolderToolsMixin, lft_menu_choices, LFT_ACTIONS
from .m3u_export import safe_m3u_filename, write_m3u
from .localization import localized_strftime as _lstrf

BROWSER_SKIN = ""


from .label_align import halign as _lbl_h, valign as _lbl_v

def _provider_display_raw(item, clean_titles=True, default=""):
    item=item if isinstance(item,dict) else {}
    raw=item.get("_raw_name")
    if raw not in (None,""):
        return str(raw)
    return str(item.get("name") or item.get("title") or default or "")

def _cat_glass_skin_xml():
    """R5.66 Movies/Series category page widgets (appended to the Browser skin only)."""
    def lab(name,x,y,w,h,font,color,halign="left",z=8):
        return ' <widget name="%s" position="%d,%d" size="%d,%d" font="Regular;%d" halign="%s" valign="center" foregroundColor="%s" transparent="1" noWrap="1" shadowColor="#000000" shadowOffset="1,1" zPosition="%d"/>\n'%(name,x,y,w,h,font,halign,color,z)
    def pix(name,x,y,w,h,z):
        return ' <widget name="%s" position="%d,%d" size="%d,%d" alphatest="blend" scale="1" transparent="1" zPosition="%d"/>\n'%(name,x,y,w,h,z)
    xml=lab("cat_hdr_title",2000,0,1,1,12,"#ffffff")+lab("cat_hdr_sub",66,20,760,34,24,"#c9ccd1")+pix("cat_hdr_line",66,58,120,4,8)+pix("cat_scrim",0,0,1000,1080,3)
    # R5.342: brief export result above the bottom-right color keys, not in the header.
    # No opaque panel; remains hidden except during an inline notification.
    xml+=lab("cat_inline_notice",1000,967,872,36,22,"#e5eeea","right",22)
    xml+=pix("cat_footer",2000,0,24,64,24)+pix("cat_footer_fade_left",2000,0,1,64,24)+pix("cat_footer_middle",2000,0,1,64,24)+pix("cat_footer_fade_right",2000,0,1,64,24)+pix("cat_footer_right",2000,0,24,64,24)
    xml+=pix("cat_focus",54,71,824,56,4)+pix("cat_scroll_track",2000,0,1,1,6)
    xml+=' <widget name="cat_scroll_thumb" position="2000,0" size="1,1" backgroundColor="#46e196" transparent="0" zPosition="7"/>\n'
    xml+=pix("cat_pv_panel",1100,550,760,500,3)+pix("cat_pv_ph",1120,556,720,392,4)+pix("cat_pv_fan",1120,556,720,392,5)
    xml+=' <widget name="cat_pv_name" position="1130,950" size="540,56" font="Regular;26" halign="left" valign="center" foregroundColor="#ffffff" transparent="1" noWrap="0" shadowColor="#000000" shadowOffset="1,1" zPosition="8"/>\n'
    xml+=lab("cat_pv_count",1680,950,160,56,22,"#9fd6bf","right")
    for i in range(3):
        xml+=pix("cat_pv_chipbg%d"%i,2000,0,1,1,6)+lab("cat_pv_chip%d"%i,2000,0,1,1,12,"#e8eaed","center")
    xml+=lab("cat_pv_upd",1130,1008,710,30,17,"#8e9aa3","left")
    return xml

_CAT_GLASS_WIDGETS=("cat_footer","cat_footer_fade_left","cat_footer_middle","cat_footer_fade_right","cat_footer_right","cat_scrim","cat_hdr_title","cat_hdr_sub","cat_inline_notice","cat_hdr_line","cat_focus","cat_scroll_track","cat_scroll_thumb","cat_pv_panel","cat_pv_ph","cat_pv_fan","cat_pv_name","cat_pv_count","cat_pv_chipbg0","cat_pv_chipbg1","cat_pv_chipbg2","cat_pv_chip0","cat_pv_chip1","cat_pv_chip2","cat_pv_upd")
_CAT_GLASS_PIXMAPS=("cat_footer","cat_footer_fade_left","cat_footer_middle","cat_footer_fade_right","cat_footer_right","cat_scrim","cat_hdr_line","cat_focus","cat_scroll_track","cat_pv_panel","cat_pv_ph","cat_pv_fan","cat_pv_chipbg0","cat_pv_chipbg1","cat_pv_chipbg2")
_CAT_GLASS_KEYS=("red_bg","green_bg","yellow_bg","blue_bg","red","green","yellow","blue")

def _browser_menu_scrim_skin(skin):
    value=str(skin or "")
    if 'name="cat_hdr_title"' not in value:
        xml=_cat_glass_skin_xml()
        try:
            from . import ui as _ui_mod
            xml=_ui_mod._prepare_runtime_skin(xml)
        except Exception:pass
        value=value.replace('</screen>',xml+'</screen>',1)
    if 'name="category_menu_scrim"' in value:
        return value
    widget='\n <widget name="category_menu_scrim" position="0,0" size="1920,1080" alphatest="blend" scale="1" transparent="1" zPosition="29"/>\n'
    try:
        from .wqhd_layout import scale_skin as _scale_scrim
        widget=_scale_scrim(widget)
    except Exception:pass
    marker='<widget name="category_menu_list"'
    pos=value.find(marker)
    if pos>=0:
        return value[:pos]+widget+value[pos:]
    return value.replace('</screen>',widget+'</screen>',1)


def configure_browser_screen(**deps):
    globals().update(deps)
    for _mixin_module in _MIXIN_MODULES:
        _mixin_module.__dict__.update(deps)
    if "BROWSER_SKIN" in deps:
        PortalBrowserScreen.skin = compact_footer_skin(_browser_menu_scrim_skin(deps["BROWSER_SKIN"]))


def _export_attach_posters(profile, client, rows, limit=80, progress=None):
    missing = list(row for row in (rows or []) if isinstance(row, dict) and not (row.get("_receiver_picon_local") and os.path.isfile(str(row.get("_receiver_picon_local")))))[: max(0, int(limit or 0))]
    if not missing:
        return
    def one(row):
        path = _export_one_poster(profile, client, row)
        if path:
            row["_receiver_picon_local"] = path
        if progress is not None:
            try: progress.tick()
            except Exception: pass
    if progress is not None:
        try: progress.set(done=0, total=len(missing))
        except Exception: pass
    pool = ThreadPoolExecutor(max_workers=min(4, len(missing)))
    try:
        list(pool.map(one, missing))
    finally:
        pool.shutdown(wait=True)


def _export_one_poster(profile, client, item):
    """Download one series poster. Every episode reuses this same file."""
    try:
        url = _image_url(item)
    except Exception:
        url = ""
    if not url:
        return ""
    try:
        path = _download_live_portal_temp_picon(url, profile, client, item=item, timeout=8.0, max_bytes=8 * 1024 * 1024) or ""
    except Exception:
        return ""
    return path if path and os.path.isfile(path) else ""


def _series_poster_path(profile, item, client=None):
    """One local poster for a whole series. Episodes must not each fetch their own."""
    item = item if isinstance(item, dict) else {}
    for key in (
        "_receiver_picon_local", "_player_poster", "_ultra_poster_source",
        "_adaptive_source_local", "poster_local", "cover_local", "image_local",
        "picon_local", "logo_local",
    ):
        path = str(item.get(key) or "")
        try:
            if path and os.path.isfile(path) and os.path.getsize(path) > 100:
                return path
        except OSError:
            pass
    try:
        from .persistent_cache import load_detail_snapshot
        snap = load_detail_snapshot(profile, "series", item) or {}
        for key in ("poster_local", "backdrop_local"):
            path = str(snap.get(key) or "")
            if path and os.path.isfile(path) and os.path.getsize(path) > 100:
                return path
    except Exception:
        pass
    try:
        bundle = _load_visual_bundle(profile, "series", item) or {}
        path = str(bundle.get("poster") or "")
        if path and os.path.isfile(path) and os.path.getsize(path) > 100:
            return path
    except Exception:
        pass
    try:
        tid = str(item.get("tmdb_id") or item.get("tmdbid") or "").strip()
        if tid:
            from .artwork_v2 import canonical_art_paths
            path = str((canonical_art_paths("series", tid) or {}).get("poster") or "")
            if path and os.path.isfile(path) and os.path.getsize(path) > 100:
                return path
    except Exception:
        pass
    return _export_one_poster(profile, client, item)


def _episode_link_token(row):
    row = row if isinstance(row, dict) else {}
    return row.get("id") or row.get("episode_id") or row.get("series") or row.get("number") or ""


def _stamp_episode_export(row, poster):
    row["_receiver_media_type"] = "episode"
    token = _episode_link_token(row)
    if token not in (None, ""):
        row["_receiver_link_series"] = token
    if poster and os.path.isfile(str(poster)):
        row["_receiver_picon_local"] = poster


def _live_screen_class(classic):
    """R5.64: 3-column Live screen unless the user picked the classic list."""
    try:
        mode = str((load_settings() or {}).get("live_view_mode") or "columns").lower()
        if mode == "classic":
            return classic
        if mode == "wall":
            from .ui_live_wall import PremiumLiveWallScreen
            return PremiumLiveWallScreen
        from .ui_live_columns import PremiumLiveColumnsScreen
        return PremiumLiveColumnsScreen
    except Exception as exc:
        try:optional_failure("ui.live_columns_import",exc)
        except Exception:pass
        return classic


def _poster_grid3_screen():
    """Lazy: Poster Grid 3 (spotlight panel) lives in its own module."""
    from .ui_poster_grid3 import PremiumPosterGrid3Screen
    return PremiumPosterGrid3Screen

_ROOT_COUNTS_CACHE={}

# Split: related method groups live in ui_browser_mixin_*.py modules. They are imported here, after every module-level helper above exists,
# and listed BEFORE the other bases so they override them exactly like the methods that used to sit in this class body.
from .ui_browser_mixin_chrome import BrowserChromeMixin
from .ui_browser_mixin_catchup import BrowserCatchupMixin
from .ui_browser_mixin_lifecycle import BrowserLifecycleMixin
from .ui_browser_mixin_catglass import BrowserCategoryGlassMixin
from .ui_browser_mixin_navigation import BrowserNavigationMixin
from .ui_browser_mixin_menus import BrowserMenusMixin
from .ui_browser_mixin_bouquet import BrowserBouquetMixin
from .ui_browser_mixin_export import BrowserExportMixin
from .ui_browser_mixin_tools import BrowserToolsMixin
from .ui_browser_mixin_favorites import BrowserFavoritesMixin
from .ui_browser_mixin_favcards import BrowserFavCardsMixin
from .ui_browser_mixin_search import BrowserSearchMixin
from .ui_browser_mixin_actions import BrowserActionsMixin
from .ui_browser_mixin_content import BrowserContentMixin
from .ui_browser_mixin_parental import BrowserParentalMixin
import sys as _split_sys
_MIXIN_MODULES = tuple(_split_sys.modules[_m.__module__] for _m in (BrowserChromeMixin, BrowserCatchupMixin, BrowserLifecycleMixin, BrowserCategoryGlassMixin, BrowserNavigationMixin, BrowserMenusMixin, BrowserBouquetMixin, BrowserExportMixin, BrowserToolsMixin, BrowserFavoritesMixin, BrowserFavCardsMixin, BrowserSearchMixin, BrowserActionsMixin, BrowserContentMixin, BrowserParentalMixin,))


class PortalBrowserScreen(
    BrowserChromeMixin,
    BrowserCatchupMixin,
    BrowserLifecycleMixin,
    BrowserCategoryGlassMixin,
    BrowserNavigationMixin,
    BrowserMenusMixin,
    BrowserBouquetMixin,
    BrowserExportMixin,
    BrowserToolsMixin,
    BrowserFavoritesMixin,
    BrowserFavCardsMixin,
    BrowserSearchMixin,
    BrowserActionsMixin,
    BrowserContentMixin,
    BrowserParentalMixin,
    LiveFolderToolsMixin,
    Screen,
    AsyncScreenMixin,
    ImageLoaderMixin,
    TransitionMixin,
):
    skin = BROWSER_SKIN
    ALL_MODES = (
        ("Live TV", "itv", "settings_icons_40/channel_list.png"),
        ("Movies", "vod", "settings_icons_40/artwork.png"),
        ("Series", "series", "settings_icons_40/next_episode.png"),
        ("Catch-up TV", "catchup", "settings_icons_40/catchup.png"),
        ("Favorites", "favorites", "settings_icons_40/watched.png"),
        ("Continue Watching", "recent", "settings_icons_40/resume.png"),
        ("Account Information", "account", "settings_icons_40/web_access.png"),
        ("Global Search", "search", "settings_icons_40/multi_search.png"),
        ("Settings", "settings", "settings_icons_40/advanced.png"),
    )
    MODES = ALL_MODES

    def __init__(self, session, profile, initial_action=None, shared_client=None, adaptive_source=None):
        _perf29_init_t0=time.monotonic()
        LOG.info("PERF29 browser init_begin action=%s mono_ms=%d",str(initial_action or "root"),int(_perf29_init_t0*1000))
        us_func(Screen.__init__)(self, session)
        self._async_init(); self.onClose.append(self._stop_async); self.onClose.append(self._image_stop)
        self._ui_diag_open_mono=time.monotonic();_ui_diag("ui_open",screen="browser")
        self.profile = profile
        self.initial_action = initial_action
        self._home_adaptive_source = str(adaptive_source or "")
        self._initial_action_done = False
        self._initial_action_scheduled = False
        self._initial_action_timer=eTimer();self._initial_action_timer_conn=None
        try:self._initial_action_timer_conn=self._initial_action_timer.timeout.connect(self._activate_initial_action)
        except Exception:self._initial_action_timer.callback.append(self._activate_initial_action)
        self.onClose.append(self._stop_initial_action_timer)
        self._home_entry = bool(initial_action)
        initial_cfg=load_settings();self._selection_cfg=self._selection_snapshot(initial_cfg);self._selection_cfg_mono=time.monotonic()
        self.portal_session = None if shared_client is not None else PortalSession(profile, timeout=initial_cfg.get("timeout", 10))
        self.client = shared_client if shared_client is not None else self.portal_session.client
        self._epg_jobs = queue.Queue(); self._epg_token = 0; self._epg_cache = {}; self._epg_future = None
        self._live_picon_cache_progress=queue.Queue();self._live_picon_cache_running=False;self._live_picon_cache_future=None
        self._epg_timer = eTimer(); self._epg_timer_conn = None
        try: self._epg_timer_conn = self._epg_timer.timeout.connect(self._fetch_selected_epg)
        except Exception: self._epg_timer.callback.append(self._fetch_selected_epg)
        self.onClose.append(self._stop_epg_preview)
        self.onClose.append(self._release_browser_pixmaps)
        self.onClose.append(self._stop_browser_ui_hooks)
        self.onClose.append(self._ui_diag_browser_close)
        try:self.onShown.append(self._browser_shown_reset)
        except Exception as exc:optional_failure("ui",exc)
        try:self.onHide.append(self._browser_hidden_release)
        except Exception as exc:optional_failure("ui.browser_hide_hook",exc)
        self.level = "root"; self.media_type = None; self.genre = None; self.content_items = []; self.page = 1; self.catchup_channel = None; self.active_modes = []
        self._category_select_mode=False; self._category_selected_ids=set(); self._category_known_items=[]
        self._bouquet_select_mode=False; self._bouquet_selected_rows={}
        self["brand_header"] = Pixmap()
        self["title"] = Label("")
        self["counter"] = Label(_("Portal sections"))
        self["section"] = Label(profile.get("portal", ""))
        self["top_divider"] = Label("")
        self["list"] = IconMenuList([], width=720, item_height=74, icon_size=58, primary_font=29, secondary_font=19)
        self["category_menu_scrim"] = Pixmap()
        try:self["category_menu_scrim"].hide()
        except Exception:pass
        self["category_menu_list"] = IconMenuList([], width=434, item_height=80, icon_size=0, primary_font=22, secondary_font=16, row_style="settings_dialog")
        self._category_menu_active=False; self._category_menu_level=None; self._category_menu_parent=None; self._category_menu_choices=[]; self._category_menu_last_idx=0
        self._category_menu_overlay=SettingsInlineChoiceOverlay(self,"category_menu_list","category_menu_overlay_actions",asset,_,optional_failure)
        self["category_clean_bg"] = Label(" ")
        self["page_adaptive_bg"] = Pixmap(); self["preview"] = Pixmap(); self["accent_frame"] = Pixmap(); self["info_title"] = Label(_("Choose a section"))
        self["info_card1"] = Pixmap(); self["info_card2"] = Pixmap(); self["info_card3"] = Pixmap()
        self["info_icon1"] = Pixmap(); self["info_icon2"] = Pixmap(); self["info_icon3"] = Pixmap()
        self._category_chrome = {}
        self._movies_category_visual_ready = False
        self._category_static_bg_loaded = ""
        self["info"] = Label(_("Live, Movies, Series, Favorites and Continue Watching"))
        self["status"] = Label(_("Ready"))
        self._favorite_card_index=0;self._favorite_card_entries=[];self._favorite_card_page=0
        self._favorite_root_index=0;self._favorites_bucket_type=None
        self._favorite_folder_id=None;self._favorite_folder_name=""
        self._favorite_reorder_active=False;self._favorite_reorder_original=[];self._favorite_move_source_index=-1
        self._favorite_art_jobs=queue.Queue();self._favorite_art_pending=set();self._favorite_art_futures=set();self._favorite_art_generation=0;self._favorite_art_local={}
        self.onClose.append(self._stop_favorite_art_jobs)
        # R5.65 Favorites: one page - header, three category tabs with count
        # badges, a poster / channel rail and a details block for the focused item.
        self["fv_title"]=Label("");self["fv_sub"]=Label("");self["fv_underline"]=Pixmap()
        for _fi in range(3):
            self["fv_tab_bg%d"%_fi]=Pixmap();self["fv_tab_icon%d"%_fi]=Pixmap();self["fv_tab_text%d"%_fi]=Label("");self["fv_tab_badge%d"%_fi]=Pixmap();self["fv_tab_cnt%d"%_fi]=Label("")
        self["fv_empty"]=Label("");self["fv_d_title"]=Label("");self["fv_pos"]=Label("");self["fv_d_meta"]=Label("");self["fv_d_desc"]=Label("")
        self._favorite_tab_state={};self._favorite_slot_state={};self._favorite_counts=(0,0,0)
        self._favorite_loc={};self._favorite_loc_requested=set();self._favorite_meta_jobs=queue.Queue();self._favorite_meta_token=0
        for _fi in range(7):
            self["fav_card%d"%_fi]=Pixmap();self["fav_sel%d"%_fi]=Pixmap();self["fav_art%d"%_fi]=Pixmap();self["fav_title%d"%_fi]=Label("");self["fav_meta%d"%_fi]=Label("")
        self["fav_red_bg"]=Pixmap();self["fav_green_bg"]=Pixmap();self["fav_yellow_bg"]=Pixmap();self["fav_blue_bg"]=Pixmap()
        self["fav_red"]=Label(_("Back"));self["fav_green"]=Label(_("Unfavorite"));self["fav_yellow"]=Label(_("Move"));self["fav_blue"]=Label(_("Create Folder"))
        self._hide_favorite_ui()
        # R5.66 Movies/Series category page (glass rail + cache-only poster preview).
        for _gn in _CAT_GLASS_WIDGETS:
            self[_gn]=Label("") if _gn in ("cat_hdr_title","cat_hdr_sub","cat_inline_notice","cat_scroll_thumb","cat_pv_name","cat_pv_count","cat_pv_chip0","cat_pv_chip1","cat_pv_chip2","cat_pv_upd") else Pixmap()
        self._cat_glass_on=False;self._cat_glass_pix=set();self._cat_glass_txt={};self._cat_focus_pos=None;self._cat_scroll_sig=None
        self._cat_pv_token=0;self._cat_pv_pending=0;self._cat_pv_queue=queue.Queue();self._cat_pv_ram=OrderedDict();self._cat_pv_fan_path="";self._cat_pv_state="";self._cat_pv_key=""
        self._cat_pv_timer=eTimer();self._cat_pv_timer_conn=None
        try:self._cat_pv_timer_conn=self._cat_pv_timer.timeout.connect(self._cat_pv_dwell)
        except Exception:self._cat_pv_timer.callback.append(self._cat_pv_dwell)
        self._cat_warm_timer=eTimer();self._cat_warm_conn=None;self._cat_warm_done=set();self._cat_warm_busy=False
        try:self._cat_warm_conn=self._cat_warm_timer.timeout.connect(self._cat_warm_fire)
        except Exception:self._cat_warm_timer.callback.append(self._cat_warm_fire)
        self._cat_pv_drain_timer=eTimer();self._cat_pv_drain_conn=None
        try:self._cat_pv_drain_conn=self._cat_pv_drain_timer.timeout.connect(self._cat_pv_drain)
        except Exception:self._cat_pv_drain_timer.callback.append(self._cat_pv_drain)
        self.onClose.append(self._cat_pv_close)
        self._category_glass_hide_widgets()
        self["red_bg"] = Pixmap(); self["green_bg"] = Pixmap(); self["yellow_bg"] = Pixmap(); self["blue_bg"] = Pixmap()
        self["red"] = Label(_("Back")); self["green"] = Label(_("Authorize"))
        self["yellow"] = Label(_("Refresh")); self["blue"] = Label(_("Open / Play"))
        self._category_row_card_w = 426
        self._category_title_font = 0
        self._image_init("preview", (530,382), profile, self.client)
        self.onLayoutFinish.append(self._layout_ready)
        install_compact_footer(self)
        self["list"].onSelectionChanged.append(self._selection_changed)
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "MenuActions","UltraStalkerMenuActions", "DirectionActions", "InfobarAudioSelectionActions", "InfobarSubtitleSelectionActions", "InfobarEPGActions"], {
            "cancel": self.back, "red": self.red_action, "green": self.green_action,
            "yellow": self.yellow_action, "blue": self.blue_action, "ok": self.select,
            "up": self._nav_up, "down": self._nav_down,
            "left": self._nav_left, "right": self._nav_right,
            "menu": self.open_tools, "audioSelection": self.open_audio, "subtitleSelection": self.open_subtitles, "showEventInfo": self.show_selected_epg,
        }, -1)
        if self.initial_action in ("itv", "vod", "series"):
            # Cold-start direct entry from Home.  Never seed the legacy Browser
            # root list, otherwise an uncached category request can expose it for
            # 2-3 seconds after an Enigma2 restart.
            self.media_type = self.initial_action
            self.level = "genres_loading"
            try:self["list"].set_icon_rows([]);self["list"].hide()
            except Exception as exc:optional_failure("ui.category_cold_empty", exc)
            self._set_category_clean_visibility(True)
        elif self.initial_action in ("catchup","favorites","account"):
            # utility pages entered from Home start blank/hero-first.
            # Do not seed the generic Browser root labels/list because OpenBH can
            # paint one frame of Ready/Back/Authorize/Refresh before the utility
            # layout takes over.  Actions stay bound; only transient chrome is
            # suppressed.
            self.level = "utility_loading"
            try:self["list"].set_icon_rows([]);self["list"].hide()
            except Exception as exc:optional_failure("ui.utility_cold_empty",exc)
            for _n in ("title","counter","section","top_divider","info_title","info","status","red","green","yellow","blue"):
                try:self[_n].setText("")
                except Exception:pass
        else:
            self._set_root_rows()
        LOG.info("PERF29 browser init_done action=%s elapsed_ms=%d",str(initial_action or "root"),int((time.monotonic()-_perf29_init_t0)*1000))
        _mem34("browser_init_done", action=str(initial_action or "root"))


    def _favorite_localized(self, mt, item):
        """Per-item cached localized text; schedules a background fetch when missing."""
        key=self._favorite_entry_key(mt,item);loc=self._favorite_loc.get(key)
        if loc is None:
            loc=self._favorite_loc_lookup(self.profile,mt,item);self._favorite_loc[key]=loc
        if not loc.get("ready") and key not in self._favorite_loc_requested:
            self._favorite_loc_requested.add(key)
            try:
                cfg=dict(load_settings() or {})
                if str(cfg.get("tmdb_credential") or "").strip() and cfg.get("tmdb_enabled",True):
                    token=int(self._favorite_meta_token);profile=dict(self.profile or {});item_copy=dict(item or {})
                    def work(_k=key,_item=item_copy,_mt=mt,_t=token,_cfg=cfg):
                        res=None
                        try:
                            from .details_authority import resolve_metadata_fast
                            resolve_metadata_fast(profile,_mt,_item,settings=_cfg)
                            res=PortalBrowserScreen._favorite_loc_lookup(profile,_mt,_item)
                        except Exception as exc:optional_failure("ui.favorite_loc_worker",exc)
                        try:self._favorite_meta_jobs.put((_t,_k,res))
                        except Exception:pass
                    future=_IMAGE_EXECUTOR.submit(work);self._favorite_art_futures.add(future)
                    future.add_done_callback(lambda f,s=self: s._favorite_art_futures.discard(f))
            except Exception as exc:optional_failure("ui.favorite_loc_submit",exc)
        return loc

    def _force_category_list_redraw(self):
        """Force a native repaint after a category check-state change (DreamOS)."""
        try:
            self["list"].l.setList(self["list"].list)
        except Exception as exc:
            optional_failure("ui.category_force_redraw",exc)

# R5.245: plugin-owned front-panel identity.
try:
    from .frontpanel_plugin import bind_plugin_front_summary as _bind_plugin_front_summary
    _bind_plugin_front_summary(PortalBrowserScreen)
except Exception:
    pass

