# -*- coding: utf-8 -*-
"""Poster identity, local cache and scheduling.

Methods moved verbatim out of ``PortalGlobalSearchScreen`` (ui_screens_search.py); behaviour is unchanged.
This module is imported by ui_screens_search.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, open, OSError, us_casefold
from .ui_screens_search import ArtworkV2, SearchCancel, VISIBLE_PROVIDER_ARTWORK_EXECUTOR, _SEARCH_ART_EXECUTOR, _image_url, _uil, _valid, catalogue_title, hashlib, load_artwork_v2_manifest, load_detail_snapshot, load_shared_detail_snapshot, os, queue, re, threading, urllib, weakref

class SearchPostersMixin(object):
    """Poster identity, local cache and scheduling."""

    def _poster_identity(self, item):
        if isinstance(item, dict) and item.get('_search_group'):
            return 'group:%s:%s' % tuple(item.get('_search_group_key') or self._group_key(item))
        return '%s:%s:%s' % (self._profile_key(item.get('_search_profile') or self.profile), item.get('_search_media_type') or 'vod', item.get('id') or item.get('movie_id') or item.get('series_id') or item.get('name') or item.get('title') or '')

    def _absolute_art_url(self, value, profile):
        text = str(value or '').strip()
        if not text:
            return ''
        if text.startswith('//'):
            scheme = urllib.parse.urlsplit(str((profile or {}).get('portal') or 'http://')).scheme or 'http'
            return scheme + ':' + text
        if text.startswith(('http://', 'https://')):
            return text
        return urllib.parse.urljoin(str((profile or {}).get('portal') or '').rstrip('/') + '/', text.lstrip('/'))

    def _local_search_poster(self, item, deferred=None):
        rows = self._group_copies(item)
        if not rows:
            rows = [item]
        for row in rows:
            if not isinstance(row, dict):
                continue
            profile = row.get('_search_profile') if isinstance(row.get('_search_profile'), dict) else self.profile
            typ = row.get('_search_media_type') or item.get('_search_media_type') or 'vod'
            clean = dict(row)
            clean.pop('_search_profile', None)
            clean.pop('_search_portal_name', None)
            candidates = []
            snapshots = []
            try:
                snap = load_artwork_v2_manifest(profile, typ, clean) or {}
                snapshots.append(snap)
                candidates.append(str(snap.get('poster_local') or ''))
            except Exception:
                pass
            try:
                snap = load_shared_detail_snapshot(profile, typ, clean) if clean.get('_xtream') else load_detail_snapshot(profile, typ, clean)
                snapshots.append(snap or {})
                candidates.append(str((snap or {}).get('poster_local') or ''))
            except Exception:
                pass
            for snap in snapshots:
                try:
                    if not isinstance(snap, dict) or not snap.get('tmdb_id'):
                        continue
                    trusted = bool(snap.get('identity_pointer_verified') or snap.get('identity_verified') or snap.get('_details_authority_ready'))
                    if not trusted or not identity_cache_compatible(clean, snap):
                        continue
                    row['_locked_tmdb_id'] = snap.get('tmdb_id')
                    row['_locked_tmdb_type'] = snap.get('media_type') or ('tv' if str(typ).lower() in ('series', 'tv') else 'movie')
                    row['_ultra_search_verified_tmdb_id'] = snap.get('tmdb_id')
                    break
                except Exception:
                    continue
            for p in candidates:
                if not _valid(p):
                    continue
                digest = hashlib.sha1((p + '|search206x310').encode('utf-8', 'ignore')).hexdigest()
                thumb = _uil._thumb_path(digest, self.POSTER_SIZE)
                if _valid(thumb):
                    return thumb
                if isinstance(deferred, list):
                    deferred.append((p, thumb))
                    return ''
                try:
                    return _uil._build_thumbnail(p, thumb, self.POSTER_SIZE) or p
                except Exception:
                    return p
        return ''

    def _search_poster_key(self, item):
        """Visual sharing only; raw result labels and playable copies stay intact."""
        typ = 'series' if str(item.get('_search_media_type') or 'vod').lower() in ('series', 'tv') else 'vod'
        raw = str(item.get('_raw_name') or item.get('name') or item.get('title') or '')
        locked = str(item.get('_locked_tmdb_id') or item.get('_ultra_search_verified_tmdb_id') or '')
        if locked.isdigit() and int(locked) > 0:
            return (typ, 'tmdb', locked)
        year = ''
        for value in (item.get('year'), item.get('release_date'), item.get('first_air_date'), raw):
            found = re.search('\\b(?:19|20)\\d{2}\\b', str(value or ''))
            if found:
                year = found.group(0)
                break
        title = ' '.join(us_casefold(str(catalogue_title(raw) or raw)).split())
        return (typ, 'title', title, year) if title else (typ, 'item', self._poster_identity(item))

    def _schedule_poster(self, generation, slot, item):
        ident = self._poster_identity(item)
        ready = self._poster_ready_get(ident)
        if ready:
            self._poster_jobs.put((generation, slot, ident, ready))
            return None
        cancel_event = self._poster_cancel_event
        flights = self._search_poster_flights
        key = self._search_poster_key(item)
        poster_jobs = self._poster_jobs
        poster_size = tuple(self.POSTER_SIZE)
        settings = dict(getattr(self, '_search_settings', {}) or load_settings() or {})
        if not settings.get('load_images', True):
            return None

        def receive(path):
            if not cancel_event.is_set() and _valid(path):
                poster_jobs.put((generation, slot, ident, path))
        local_build = []
        local = self._local_search_poster(item, local_build)
        if local:
            flights.request(key, receive, [])
            flights.publish(key, local)
            return None
        rows = self._group_copies(item)
        for peer in self.results:
            if peer is not item and self._search_poster_key(peer) == key:
                rows.extend(self._group_copies(peer))
        if not rows:
            rows = [item]
        prepared, seen = ([], set())
        for row in rows:
            if not isinstance(row, dict):
                continue
            profile = row.get('_search_profile') if isinstance(row.get('_search_profile'), dict) else self.profile
            typ = str(row.get('_search_media_type') or item.get('_search_media_type') or 'vod').lower()
            clean = self._clean_search_copy(row)
            try:
                raw_url = self._absolute_art_url(_image_url(row), profile)
            except Exception:
                raw_url = ''
            if raw_url:
                try:
                    raw_url = _uil._optimized_artwork_url(raw_url, False) or raw_url
                except Exception:
                    pass
            lane = ('provider', self._profile_key(profile), raw_url)
            if raw_url and lane not in seen:
                seen.add(lane)
                prepared.append((lane, dict(profile or {}), typ, clean, raw_url))
            if len(prepared) >= 3:
                break
        credential = str(settings.get('tmdb_credential') or '').strip()
        lanes = [entry[0] for entry in prepared]
        canonical_lane = ('canonical',)
        canonical_enabled = bool(settings.get('tmdb_enabled', True) and credential)
        local_lane = ('local',)
        if local_build:
            prepared = []
            canonical_enabled = False
            lanes = [local_lane]
        if canonical_enabled:
            lanes.append(canonical_lane)
        fresh = set(flights.request(key, receive, lanes))
        if not fresh:
            return None
        futures = self._poster_futures
        screen_ref = weakref.ref(self)
        base_client = self.client
        current_profile_key = self._profile_key(self.profile)
        page_settings = dict(settings)

        def submit(executor, lane, worker):

            def run():
                try:
                    if not cancel_event.is_set() and (not flights.ready(key)):
                        path = worker()
                        if not cancel_event.is_set() and _valid(path):
                            flights.publish(key, path)
                except Exception as exc:
                    if not cancel_event.is_set():
                        optional_failure('ui.search_poster', exc)
                finally:
                    flights.finish(key)
            try:
                future = executor.submit(run, _task_key='search-poster:%x:%s:%s:%s' % (id(flights), generation, key, lane))
                futures.add(future)

                def forget(done, owned=futures, ref=screen_ref):
                    owned.discard(done)
                future.add_done_callback(forget)
            except Exception as exc:
                flights.finish(key)
                optional_failure('ui.search_poster_submit', exc)
        for lane, profile, typ, clean, url in prepared:
            if lane not in fresh:
                continue
            image_client = base_client if self._profile_key(profile) == current_profile_key else None

            def provider_worker(profile=profile, clean=clean, url=url, image_client=image_client):
                token = SearchCancel(cancel_event, 5.0)
                digest = hashlib.sha1(url.encode('utf-8', 'ignore')).hexdigest()
                thumb = _uil._thumb_path(digest, poster_size)
                if _uil._valid_cache_file(thumb):
                    return thumb
                temp = None
                try:
                    try:
                        headers = _uil._safe_image_headers(url, profile, image_client, clean)
                    except TypeError:
                        headers = _uil._safe_image_headers(url, profile, image_client)
                    req = urllib.request.Request(url, headers=headers)
                    try:
                        opener = _uil._safe_image_opener(url, profile)
                    except Exception:
                        opener = None
                    temp = os.path.join(os.path.dirname(thumb), 'search_%s.download.%d.%d' % (digest, os.getpid(), threading.get_ident()))
                    _uil._persistent_write_require(temp)
                    response_ctx = opener.open(req, timeout=3.0) if opener is not None else provider_urlopen(req, timeout=3.0)
                    total = 0
                    with response_ctx as response, open(temp, 'wb') as handle:
                        while not token.is_set() and (not flights.ready(key)):
                            chunk = response.read(64 * 1024)
                            if not chunk:
                                break
                            total += len(chunk)
                            if total > 5 * 1024 * 1024:
                                raise ValueError('poster too large')
                            handle.write(chunk)
                    if token.is_set() or flights.ready(key) or total <= 256:
                        return ''
                    return _uil._build_thumbnail(temp, thumb, poster_size) or ''
                finally:
                    if temp:
                        try:
                            os.unlink(temp)
                        except OSError:
                            pass
            submit(VISIBLE_PROVIDER_ARTWORK_EXECUTOR, lane, provider_worker)
        if local_lane in fresh and local_build:
            local_src, local_thumb = local_build[0]

            def local_worker(src=local_src, thumb=local_thumb):
                if cancel_event.is_set():
                    return ''
                return _uil._build_thumbnail(src, thumb, poster_size) or src
            submit(_SEARCH_ART_EXECUTOR, local_lane, local_worker)
        if canonical_lane in fresh:
            profile = item.get('_search_profile') if isinstance(item.get('_search_profile'), dict) else self.profile
            typ = item.get('_search_media_type') or 'vod'
            clean = self._clean_search_copy(item)

            def canonical_worker():
                token = SearchCancel(cancel_event, 16.0)
                resolver = ArtworkV2(credential, str(page_settings.get('tmdb_language') or 'ar-EG'), 3)

                def component(kind, payload):
                    if kind == 'poster' and (not token.is_set()):
                        path = str((payload or {}).get('poster_local') or '')
                        if _valid(path):
                            digest = hashlib.sha1((path + '|search206x310').encode('utf-8', 'ignore')).hexdigest()
                            thumb = _uil._thumb_path(digest, poster_size)
                            out = thumb if _valid(thumb) else _uil._build_thumbnail(path, thumb, poster_size) or path
                            flights.publish(key, out)
                resolved = resolver.resolve(dict(profile or {}), typ, clean, full=False, cancel_event=token, component_callback=component) or {}
                if token.is_set():
                    return ''
                canonical = str(resolved.get('poster_local') or '')
                if not _valid(canonical):
                    return ''
                digest = hashlib.sha1((canonical + '|search206x310').encode('utf-8', 'ignore')).hexdigest()
                thumb = _uil._thumb_path(digest, poster_size)
                return thumb if _valid(thumb) else _uil._build_thumbnail(canonical, thumb, poster_size) or canonical
            submit(_SEARCH_ART_EXECUTOR, canonical_lane, canonical_worker)

    def _drain_poster_jobs(self):
        view_rows = self._view_results()
        page = self.index // self.PAGE_SIZE if view_rows else 0
        start = page * self.PAGE_SIZE
        rows = view_rows[start:start + self.PAGE_SIZE]
        while True:
            try:
                generation, slot, ident, path = self._poster_jobs.get_nowait()
            except queue.Empty:
                break
            except Exception:
                break
            if generation != self._poster_generation or slot >= len(rows) or (not _valid(path)):
                continue
            if ident != self._poster_identity(rows[slot]):
                continue
            try:
                self._poster_ready_put(ident, path)
                w = self['result_art%d' % slot]
                if w.instance is not None:
                    w.instance.setPixmapFromFile(path)
                w.show()
            except Exception as exc:
                optional_failure('ui.search_poster_apply', exc)
