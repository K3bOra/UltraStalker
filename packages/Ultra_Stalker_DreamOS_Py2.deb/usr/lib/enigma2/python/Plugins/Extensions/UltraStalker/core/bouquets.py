# -*- coding: utf-8 -*-
"""Enigma2 bouquet and EPGImport integration with dynamic Stalker links.

Exported bouquets never persist short-lived provider URLs.  They point to a
loopback-only proxy which resolves a fresh Stalker link at tune time.  The
registry also owns the exported files, so an export can be removed cleanly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .. import us_env as _us_env
from ..us_env import str, int, open, max, min, OSError, FileNotFoundError, us_clear, us_func

hashlib = _us_env.hashlib
import datetime
hmac = _us_env.hmac
ipaddress = _us_env.ipaddress
json = _us_env.json
os = _us_env.os
re = _us_env.re
secrets = _us_env.secrets
shutil = _us_env.shutil
socket = _us_env.socket
threading = _us_env.threading
import tempfile
time = _us_env.time
urllib = _us_env.urllib
ThreadPoolExecutor = _us_env.concurrent_futures.ThreadPoolExecutor
BaseHTTPRequestHandler = _us_env.http_server.BaseHTTPRequestHandler; ThreadingHTTPServer = _us_env.http_server.ThreadingHTTPServer
from xml.sax.saxutils import escape

from ..client import StalkerClient
from ..title_clean import clean_title, catalogue_title
from ..storage import CONFIG_DIR, load_settings, load_json_file, _fsync_parent_dir
from ..log import get_logger
from .recording import event_times
from .export_metadata import prepare as _prepare_media_metadata, seed as _media_metadata_seed, fields as _media_metadata_fields

REGISTRY_FILE = os.path.join(CONFIG_DIR, "bouquet_registry.json")
PROXY_HOST = "127.0.0.1"
PROXY_PORT = 17999  # Backwards-compatible default; persisted exports own their actual port.
PROXY_PORT_FALLBACK_END = 18019
EPGIMPORT_DIR = "/etc/epgimport"
ENIGMA2_DIR = "/etc/enigma2"
_XMLTV_TTL = 2 * 3600
_XMLTV_BACKGROUND_AFTER = 45 * 60
_XMLTV_DEFAULT_BUDGET = 45
_SERVER = None
_SERVER_THREAD = None
_SERVER_PORT = None
_REGISTRY_LOCK = threading.RLock()
_XMLTV_LOCKS = {}
_XMLTV_REFRESHING = set()
_XMLTV_REFRESH_LOCK = threading.RLock()
_EPG_MANAGER_THREAD = None
_EPG_MANAGER_STOP = threading.Event()
_LAST_PROXY_ERROR = ""
_PROXY_LOCK = threading.RLock()
_PROXY_STOP_THREAD = None
_XMLTV_PAUSED = threading.Event()
_XMLTV_ACTIVE = {}
_XMLTV_ORPHANS = {}
_XMLTV_ORPHAN_MAX_THREADS = 12
_PROXY_REQUEST_SLOTS = threading.BoundedSemaphore(8)
_PROXY_SOCKET_TIMEOUT = 12.0
LOG = get_logger()
_PICON_EXPORT_EXECUTOR = ThreadPoolExecutor(max_workers=2, thread_name_prefix="ultrastalker-export-picon")

# Exported Movies/Series are opened by UltraStalkerPlayer from the loopback
# proxy request itself. This is the one path every exported VOD tune must hit,
# regardless of ChannelSelection/InfoBar differences between Enigma2 images.
_EXPORT_PLAYER_SESSION = None
_EXPORT_PLAYER_LOCK = threading.RLock()
_EXPORT_PLAYER_LAST_KEY = ""
_EXPORT_PLAYER_LAST_AT = 0.0
_EXPORT_SERIES_ACTIVE = set()
_EXPORT_PLAYER_MEDIA = ("vod", "movie", "series", "episode")


def set_export_player_session(session):
    global _EXPORT_PLAYER_SESSION
    _EXPORT_PLAYER_SESSION = session
    return session


def _export_return_service(session):
    """Best-effort previous non-proxy service for Player EXIT restore."""
    current_text = ""
    try:
        current = session.nav.getCurrentlyPlayingServiceOrGroup()
        current_text = current.toString() if current is not None else ""
    except Exception:
        current_text = ""
    try:
        from Screens.InfoBar import InfoBar
        info = getattr(InfoBar, "instance", None)
        slist = getattr(info, "servicelist", None) if info is not None else None
        history = list(getattr(slist, "history", None) or [])
        for row in reversed(history):
            ref = row[-1] if isinstance(row, (list, tuple)) and row else row
            if ref is None:
                continue
            try:
                text = ref.toString() or ""
            except Exception:
                text = str(ref or "")
            if not text or text == current_text:
                continue
            decoded = urllib.parse.unquote(urllib.parse.unquote(text)).lower()
            if "127.0.0.1" in decoded or "localhost" in decoded:
                continue
            return text
    except Exception:
        pass
    return ""


def _open_export_player(session, direct_url, channel, profile, media_type, engine, dedupe_key, resume_key=""):
    global _EXPORT_PLAYER_LAST_KEY, _EXPORT_PLAYER_LAST_AT
    try:
        if session is None or not direct_url:
            return
        payload = dict(channel or {})
        profile = dict(profile or {})
        media_type = str(media_type or "vod").lower()
        # Player's VOD progress, seek, and Resume lifecycle use the canonical
        # "vod" media type. Some exports label the same content "movie".
        if media_type == "movie":
            media_type = "vod"
        payload["_media_type"] = media_type
        payload["_receiver_media_type"] = media_type
        payload["_external_export_playback"] = True
        payload["_history_item"] = dict(channel or {})
        payload["_history_item"]["_external_export_playback"] = True
        # Exported playback has no UltraStalker History/Resume side effects.
        # The receiver's native ResumePoints cache owns this stable bouquet ID.
        try:
            from .export_native_resume import read_export_resume
            payload["_export_native_resume_key"] = str(resume_key or "")
            payload["_export_native_resume"] = True
            resume_pos, resume_len = read_export_resume(payload["_export_native_resume_key"])
            payload["_resume_position"] = resume_pos
            payload["_resume_duration"] = resume_len
        except Exception as exc:
            LOG.debug("Export native resume read unavailable: %s", exc)
            payload["_export_native_resume"] = True
            payload["_export_native_resume_key"] = str(resume_key or "")
            payload["_resume_position"] = 0
            payload["_resume_duration"] = 0
        payload["_portal"] = str(profile.get("portal") or "")
        payload["_mac"] = str(profile.get("mac") or "")
        payload["_server_name"] = str(profile.get("name") or "")
        payload["_source_type"] = str(profile.get("source_type") or payload.get("_source_type") or "")
        payload["_allow_http_fallback"] = bool(profile.get("allow_http_fallback", False))
        payload["_tls_mode"] = str(profile.get("tls_mode") or "auto")
        payload["_device_profile"] = str(profile.get("device_profile") or "auto")
        payload["_tls_fallback_accepted"] = bool(profile.get("tls_fallback_accepted", False))
        payload["_http_fallback_accepted"] = bool(profile.get("http_fallback_accepted", False))
        return_ref = _export_return_service(session)
        if return_ref:
            payload["_return_service_ref_string"] = return_ref

        # The exporter already persisted the authoritative poster path used for
        # receiver picons. Hand that exact local file to our Player so exported
        # playback has the same poster surface as in-plugin playback.
        for key in ("_player_poster", "_receiver_picon_local", "_receiver_picon_source_local", "poster_local"):
            candidate = str(payload.get(key) or "")
            if candidate and os.path.isfile(candidate):
                payload["_player_poster"] = candidate
                payload["_ultra_poster_source"] = candidate
                payload["_adaptive_source_local"] = candidate
                break

        name = _receiver_name(payload, media_type)
        try:
            from ..services.player import UltraStalkerPlayer
            try:
                session.nav.stopService()
            except Exception:
                pass
            try:
                current = getattr(session, "current_dialog", None)
                if current is not None and current.__class__.__name__ in ("ChannelSelection", "SimpleChannelSelection"):
                    current.close(None)
            except Exception:
                pass
            session.open(UltraStalkerPlayer, str(direct_url), name, media_type, int(engine or 4097), payload)
            with _EXPORT_PLAYER_LOCK:
                _EXPORT_PLAYER_LAST_KEY = str(dedupe_key or "")
                _EXPORT_PLAYER_LAST_AT = time.monotonic()
            LOG.info("Export Player opened media=%s engine=%s", media_type, int(engine or 4097))
        except Exception as exc:
            LOG.warning("Export Player open failed: %s", exc)
    except Exception as exc:
        LOG.warning("Export Player dispatch failed: %s", exc)


def _queue_export_player(entry, channel, media_type, direct_url, channel_key=""):
    session = _EXPORT_PLAYER_SESSION
    media_type = str(media_type or "").lower()
    if session is None or media_type not in _EXPORT_PLAYER_MEDIA or not direct_url:
        return False
    dedupe_key = "%s|%s" % (str(channel_key or ""), media_type)
    now = time.monotonic()
    with _EXPORT_PLAYER_LOCK:
        if dedupe_key and dedupe_key == _EXPORT_PLAYER_LAST_KEY and now - _EXPORT_PLAYER_LAST_AT < 2.5:
            return True
    profile = dict((entry or {}).get("profile") or {})
    try:
        from .export_native_resume import export_resume_key
        resume_key = export_resume_key(_profile_key(profile), channel_key)
    except Exception:
        resume_key = ""
    try:
        engine = int((entry or {}).get("service_type") or 4097)
    except Exception:
        engine = 4097
    try:
        from twisted.internet import reactor
        reactor.callFromThread(_open_export_player, session, str(direct_url), dict(channel or {}), profile, media_type, engine, dedupe_key, resume_key)
        return True
    except Exception as exc:
        LOG.warning("Export Player queue failed: %s", exc)
        return False


def _queue_export_series(entry, channel, channel_key):
    session = _EXPORT_PLAYER_SESSION
    if session is None: return False
    dedupe_key = _profile_key(entry.get("profile") or {}) + "|" + str(channel_key)
    with _EXPORT_PLAYER_LOCK:
        if dedupe_key in _EXPORT_SERIES_ACTIVE: return True
        _EXPORT_SERIES_ACTIVE.add(dedupe_key)
    def finished():
        with _EXPORT_PLAYER_LOCK:
            _EXPORT_SERIES_ACTIVE.discard(dedupe_key)
    def open_saved():
        try:
            from .export_series import open_series
            open_series(session, entry, channel, _client, finished)
        except Exception as exc:
            finished()
            LOG.warning("Export Series open failed: %s", exc)
    try:
        from twisted.internet import reactor
        reactor.callFromThread(open_saved)
        return True
    except Exception as exc:
        finished()
        LOG.warning("Export Series queue failed: %s", exc)
        return False


def _profile_key(profile):
    raw = "%s|%s" % (
        str((profile or {}).get("portal") or "").rstrip("/").lower(),
        str((profile or {}).get("mac") or "").upper(),
    )
    return hashlib.sha1(raw.encode("utf-8", "ignore")).hexdigest()[:16]


def _channel_key(channel):
    raw = "%s|%s" % (
        str((channel or {}).get("id") or (channel or {}).get("ch_id") or ""),
        str((channel or {}).get("cmd") or (channel or {}).get("command") or (channel or {}).get("url") or ""),
    )
    return hashlib.sha1(raw.encode("utf-8", "ignore")).hexdigest()[:16]


def _read_registry():
    return load_json_file(REGISTRY_FILE, dict, {})


def _write_registry(data):
    if _fs_free_bytes(CONFIG_DIR if os.path.isdir(CONFIG_DIR) else os.path.dirname(CONFIG_DIR) or "/") < 6 * 1024 * 1024:
        _reclaim_export_space()
    os.makedirs(CONFIG_DIR, mode=0o700, exist_ok=True)
    try:
        os.chmod(CONFIG_DIR, 0o700)
    except OSError:
        pass
    temp = None
    try:
        fd, temp = tempfile.mkstemp(prefix="bouquet_registry.", suffix=".tmp", dir=CONFIG_DIR)
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(data, handle, ensure_ascii=False, indent=2, sort_keys=True)
            handle.flush(); os.fsync(handle.fileno())
        os.chmod(temp, 0o600)
        os.replace(temp, REGISTRY_FILE); _fsync_parent_dir(REGISTRY_FILE); temp = None
    finally:
        if temp:
            try: os.unlink(temp)
            except OSError: pass


def _registry_entries(registry):
    return {
        key: value for key, value in (registry or {}).items()
        if key != "_meta" and isinstance(value, dict) and isinstance(value.get("channels"), dict)
    }


def _setting_port():
    try:
        value = int(load_settings().get("proxy_port", PROXY_PORT) or PROXY_PORT)
    except (TypeError, ValueError):
        value = PROXY_PORT
    return value if 1024 <= value <= 65535 else PROXY_PORT


def _registry_port(registry=None):
    registry = registry if isinstance(registry, dict) else _read_registry()
    meta = registry.get("_meta") if isinstance(registry.get("_meta"), dict) else {}
    try:
        value = int(meta.get("proxy_port") or 0)
        if 1024 <= value <= 65535:
            return value
    except (TypeError, ValueError):
        pass
    for entry in _registry_entries(registry).values():
        try:
            value = int(entry.get("proxy_port") or 0)
            if 1024 <= value <= 65535:
                return value
        except (TypeError, ValueError):
            pass
    return _setting_port()


def _port_available(port):
    if _SERVER is not None and _SERVER_PORT == int(port):
        return True
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind((PROXY_HOST, int(port)))
        return True
    except OSError:
        return False
    finally:
        try: sock.close()
        except OSError: pass


def _choose_export_port(registry):
    entries = _registry_entries(registry)
    if entries:
        port = _registry_port(registry)
        if not _port_available(port):
            raise RuntimeError(
                "Dynamic bouquet proxy port %d is already in use. Existing Stalker bouquets use this port; "
                "stop the conflicting service or remove/re-export the Stalker bouquets." % port
            )
        return port
    preferred = _setting_port()
    candidates = [preferred]
    for port in range(PROXY_PORT, PROXY_PORT_FALLBACK_END + 1):
        if port not in candidates:
            candidates.append(port)
    for port in candidates:
        if _port_available(port):
            return port
    raise RuntimeError("No free loopback port is available for the dynamic Stalker bouquet proxy")


def _client(profile):
    cfg = load_settings()
    profile = profile if isinstance(profile, dict) else {}
    portal = str(profile.get("portal") or "")
    source_type = str(profile.get("source_type") or "").strip().lower()
    low = portal.lower()
    if not source_type:
        source_type = "m3u" if (".m3u" in low or "type=m3u" in low or "output=m3u" in low or ("get.php" in low and ("username=" in low or "password=" in low))) else "stalker"
    if source_type == "m3u":
        from ..m3u_adapter import M3UClient
        return M3UClient(portal, profile.get("mac") or "M3U", timeout=cfg.get("timeout", 10))
    return StalkerClient(
        portal, profile.get("mac"), timeout=cfg.get("timeout", 10),
        allow_http_fallback=profile.get("allow_http_fallback", False),
        tls_mode=profile.get("tls_mode", "auto"),
        device_profile=profile.get("device_profile", "auto"),
        allow_tls_fallback=profile.get("tls_fallback_accepted", False),
        http_fallback_accepted=profile.get("http_fallback_accepted", False),
    )


def _xmltv_id(profile_key, channel_key):
    return "spobh.%s.%s" % (profile_key, channel_key)


def _new_proxy_token():
    # Capability token for loopback proxy URLs.  24 random bytes gives ample
    # entropy while keeping exported service references reasonably short.
    return secrets.token_urlsafe(24)


def _proxy_url(profile_key, channel_key, port=None, token=None):
    base = "http://%s:%d/stream" % (PROXY_HOST, int(port or _registry_port()))
    if token:
        return "%s/%s/%s/%s" % (base, token, profile_key, channel_key)
    # Legacy registry entries created before capability tokens existed.
    return "%s/%s/%s" % (base, profile_key, channel_key)


def _xmltv_url(profile_key, port=None, token=None):
    base = "http://%s:%d/xmltv" % (PROXY_HOST, int(port or _registry_port()))
    if token:
        return "%s/%s/%s" % (base, token, profile_key)
    return "%s/%s" % (base, profile_key)


def _is_loopback_address(value):
    try:
        return ipaddress.ip_address(str(value or "").split("%", 1)[0]).is_loopback
    except ValueError:
        return False


def _assert_loopback_bind():
    # Keep this explicit guard even though PROXY_HOST is currently a constant.
    # It prevents a future configuration/refactor from accidentally exposing
    # an unaudited proxy listener to the LAN/WAN.
    if not _is_loopback_address(PROXY_HOST):
        raise RuntimeError("Refusing to start bouquet proxy on non-loopback host %r" % (PROXY_HOST,))


def _token_matches(entry, supplied):
    expected = str((entry or {}).get("proxy_token") or "")
    if not expected or supplied is None:
        return False
    return hmac.compare_digest(expected, str(supplied))


def _replace_required(path, replacements):
    """Atomically replace legacy proxy references in an existing export.

    Missing generated files are harmless (there is no consumer to migrate), but
    an existing file must contain every expected legacy reference.  Refusing a
    partial rewrite prevents publishing a token that would strand an old bouquet.
    """
    if not os.path.exists(path):
        return False
    with open(path, "r", encoding="utf-8", errors="replace") as handle:
        text = handle.read()
    changed = text
    for old, new in replacements:
        if old not in changed:
            raise ValueError("legacy proxy reference not found in %s" % path)
        changed = changed.replace(old, new)
    if changed != text:
        try:
            mode = os.stat(path).st_mode & 0o777
        except OSError:
            mode = 0o644
        _atomic_text(path, changed, mode)
        return True
    return False


def _migrate_legacy_proxy_tokens(registry=None):
    """Upgrade tokenless bouquet exports atomically before the proxy serves them.

    Registry publication is the commit point.  Existing bouquet/EPGImport files
    are rewritten first and rolled back on any failure, so a legacy export never
    becomes unusable halfway through migration.
    """
    with _REGISTRY_LOCK:
        original = registry if isinstance(registry, dict) else _read_registry()
        legacy = [(key, value) for key, value in _registry_entries(original).items()
                  if not str(value.get("proxy_token") or "")]
        if not legacy:
            return original
        working = dict(original)
        touched = {}
        try:
            for pkey, old_entry in legacy:
                entry = dict(old_entry)
                token = _new_proxy_token()
                port = int(entry.get("proxy_port") or _registry_port(original))
                service_type = int(entry.get("service_type") or 4097)
                paths = _bouquet_paths(pkey)
                channel_replacements = []
                for ckey in (entry.get("channels") or {}):
                    old_ref = _service_ref(_proxy_url(pkey, ckey, port, None), service_type)
                    new_ref = _service_ref(_proxy_url(pkey, ckey, port, token), service_type)
                    channel_replacements.append((old_ref, new_ref))
                file_jobs = [
                    (paths["bouquet"], channel_replacements),
                    (paths["epg_channels"], channel_replacements),
                    (paths["epg_source"], [(_xmltv_url(pkey, port, None), _xmltv_url(pkey, port, token))]),
                ]
                for path, replacements in file_jobs:
                    if path not in touched:
                        touched[path] = _snapshot_file(path)
                    _replace_required(path, replacements)
                entry["proxy_token"] = token
                entry["updated_at"] = int(time.time())
                working[pkey] = entry
            meta = dict(working.get("_meta") or {})
            meta.update({"format": 3, "proxy_port": _registry_port(working), "updated_at": int(time.time())})
            working["_meta"] = meta
            _write_registry(working)
            return working
        except Exception:
            for path, snapshot in reversed(list(touched.items())):
                _restore_snapshot(path, snapshot)
            raise


def _service_ref(url, service_type=4097, identity=None):
    encoded = urllib.parse.quote(str(url or ""), safe="")
    if identity not in (None, ""):
        digest = hashlib.sha1(str(identity).encode("utf-8", "ignore")).hexdigest().upper()
        sid, tsid, onid = digest[:4], digest[4:8], digest[8:12]
        return "%d:0:1:%s:%s:%s:0:0:0:0:%s" % (int(service_type or 4097), sid, tsid, onid, encoded)
    return "%d:0:1:0:0:0:0:0:0:0:%s" % (int(service_type or 4097), encoded)


def _safe_name(value):
    return " ".join(str(value or "").replace("\r", " ").replace("\n", " ").split())[:180]


def _receiver_name(row, media_type="itv"):
    # When the browser supplies _receiver_name it is the exact final display
    # title already shown inside Ultra Stalker. Do not run a second, different
    # cleanup pass during receiver export.
    explicit = (row or {}).get("_receiver_name")
    if explicit not in (None, ""):
        return _safe_name(explicit)
    raw = (row or {}).get("name") or (row or {}).get("title") or "Item"
    if str(media_type or "itv").lower() in ("vod", "movie", "series"):
        return _safe_name(catalogue_title(raw))
    if str(media_type or "itv").lower() == "episode":
        return _safe_name(raw)
    return _safe_name(clean_title(raw))


def _picon_directories():
    """Writable picon folders Enigma2 actually searches.

    OpenATV/OpenPLi remember the first folder that already contains a picon and
    then only look there. Writing solely to /media/hdd/picon therefore shows
    nothing when satellite picons already live in /usr/share/enigma2/picon.
    """
    found = []
    seen = set()
    for root in (
        "/usr/share/enigma2/picon",
        "/picon",
        "/media/hdd/picon",
        "/media/usb/picon",
        "/media/mmc/picon",
        "/etc/enigma2/picon",
    ):
        root = os.path.abspath(root)
        if root in seen:
            continue
        parent = os.path.dirname(root) or "/"
        try:
            if not os.path.isdir(root):
                # Do not create a picon folder on the small root flash when it
                # is already tight. That folder is searched first and a full
                # poster copied there is what fills the receiver.
                if root.startswith(("/usr", "/etc", "/picon")) and _fs_free_bytes(parent) < 20 * 1024 * 1024:
                    continue
                if not (os.path.isdir(parent) and os.access(parent, os.W_OK)):
                    continue
                os.makedirs(root, exist_ok=True)
            if os.path.isdir(root) and os.access(root, os.W_OK):
                found.append(root)
                seen.add(root)
        except OSError:
            continue
    return found


def _picon_root():
    roots = _picon_directories()
    return roots[0] if roots else None


def _sanitize_picon_stem(name):
    import unicodedata
    text = unicodedata.normalize("NFKD", _safe_name(name))
    text = "".join(ch for ch in text if ch not in '\\/:*?"<>|' and ord(ch) > 31).strip().rstrip(". ")
    return text.lower()


def _picon_filenames(service_ref, channel_name=""):
    """SRP names plus the UTF-8 / legacy service-name fallbacks skins try next."""
    names = []

    def add(value):
        value = str(value or "").strip()
        if value and value not in names and value not in (".png", "__.png"):
            names.append(value)

    parts = str(service_ref or "").split(":")[:10]
    if len(parts) >= 10 and all(parts):
        add("_".join(parts) + ".png")
        alt = list(parts)
        alt[0] = "1"
        add("_".join(alt) + ".png")
    stem = _sanitize_picon_stem(channel_name)
    if stem and stem != "__":
        add(stem + ".png")
        legacy = re.sub(r"[^a-z0-9]", "", stem.replace("&", "and").replace("+", "plus").replace("*", "star"))
        if legacy:
            add(legacy + ".png")
    return names


def _picon_filename(service_ref):
    names = _picon_filenames(service_ref)
    return names[0] if names else ""


def _fs_free_bytes(path):
    try:
        target = path if path and os.path.isdir(path) else (os.path.dirname(path or "") or "/")
        st = os.statvfs(target or "/")
        return int(st.f_bavail) * int(st.f_frsize)
    except Exception:
        return 0


def _same_device(left, right):
    try:
        return os.stat(left).st_dev == os.stat(right).st_dev
    except OSError:
        return False


_RECLAIM_LOCK = threading.Lock()


def _reclaim_export_space():
    """Free the space a previous export spent on full-size poster copies.

    Bouquet files live on the receiver flash. Copying every movie poster into
    the picon folder at original size fills that flash, and the next export
    then fails before it can write a single bouquet line.
    """
    if not _RECLAIM_LOCK.acquire(False):
        return 0
    removed = 0
    try:
        tmp = "/tmp"
        try:
            names = os.listdir(tmp)
        except OSError:
            names = []
        for name in names:
            if not (name.startswith("us-picon.") or name.startswith("us_r188_fast_bd_") or name.startswith("us_r243_original_")):
                continue
            path = os.path.join(tmp, name)
            try:
                if os.path.isdir(path):
                    shutil.rmtree(path, ignore_errors=True)
                elif os.path.isfile(path) or os.path.islink(path):
                    os.unlink(path)
                removed += 1
            except OSError:
                pass
        anchor = ENIGMA2_DIR if os.path.isdir(ENIGMA2_DIR) else "/"
        if _fs_free_bytes(anchor) >= 8 * 1024 * 1024:
            return removed
        # Never delete files in the satellite picon folders. Those logos are
        # not ours, and removing them is what made the channel list look dead.
        return removed
    finally:
        _RECLAIM_LOCK.release()


def _publish_picon(service_ref, source_path, channel_name=""):
    source = str(source_path or "")
    if not source or not os.path.isfile(source):
        return ""
    roots = _picon_directories()
    names = _picon_filenames(service_ref, channel_name)
    if not roots or not names:
        return ""
    srp_names = set()
    parts = str(service_ref or "").split(":")[:10]
    if len(parts) >= 10 and all(parts):
        srp_names.add("_".join(parts) + ".png")
        alt = list(parts)
        alt[0] = "1"
        srp_names.add("_".join(alt) + ".png")
    temp_dir = ""
    try:
        try:
            temp_dir = tempfile.mkdtemp(prefix="us-picon.")
        except OSError:
            _reclaim_export_space()
            temp_dir = tempfile.mkdtemp(prefix="us-picon.")
        temp_png = os.path.join(temp_dir, "picon.png")
        # Do not trust the filename extension. A number of IPTV servers return
        # JPEG/WebP data behind a .png URL; Enigma2 can render that inside the
        # plugin while the native picon loader later rejects the copied file.
        # Re-encode every exported picon as a small real PNG. The old path
        # saved the full poster and filled the receiver flash.
        try:
            from PIL import Image, ImageOps
            with Image.open(source) as image:
                try: image.seek(0)
                except Exception: pass
                try: image = ImageOps.exif_transpose(image)
                except Exception: pass
                image = image.convert("RGBA")
                resample = getattr(Image, "LANCZOS", 1)
                image.thumbnail((400, 600), resample)
                image.save(temp_png, "PNG", compress_level=9, optimize=False)
        except Exception as pil_exc:
            # Minimal fallback for images without Pillow: only copy files that
            # are genuinely PNG instead of trusting a misleading extension.
            try:
                with open(source, "rb") as handle: head = handle.read(8)
            except Exception: head = b""
            if head != b"\x89PNG\r\n\x1a\n":
                LOG.debug("Receiver picon conversion failed for %s: %s", source, pil_exc)
                return ""
            shutil.copyfile(source, temp_png)
        if not os.path.isfile(temp_png) or os.path.getsize(temp_png) <= 100:
            return ""
        written = ""
        for root in roots:
            if _fs_free_bytes(root) < 1024 * 1024:
                continue
            for name in names:
                if os.path.basename(name) != name:
                    continue
                target = os.path.join(root, name)
                # Never replace a logo that is already on the receiver.
                # Satellite picons live in this same folder.
                try:
                    if os.path.lexists(target):
                        continue
                except OSError:
                    pass
                temp = target + ".tmp.%d.%d" % (os.getpid(), threading.get_ident())
                try:
                    shutil.copyfile(temp_png, temp)
                    os.replace(temp, target)
                    written = target
                except OSError as exc:
                    LOG.debug("Receiver picon copy failed %s: %s", target, exc)
                    try:
                        if os.path.exists(temp): os.unlink(temp)
                    except OSError:
                        pass
        return written
    except Exception as exc:
        LOG.debug("Receiver picon publish failed: %s", exc)
        return ""
    finally:
        if temp_dir:
            shutil.rmtree(temp_dir, ignore_errors=True)


def _link_shared_picon(master, target):
    """Point target at the one converted poster. Never replace a file already there."""
    if os.path.lexists(target):
        try:
            return bool(os.path.isfile(target) and os.path.samefile(master, target))
        except OSError:
            return True
    temp = target + ".tmp.%d.%d" % (os.getpid(), threading.get_ident())
    try:
        try:
            os.link(master, temp)
        except OSError:
            shutil.copyfile(master, temp)
        os.replace(temp, target)
        return True
    except OSError as exc:
        LOG.debug("Shared picon link failed %s: %s", target, exc)
        try:
            if os.path.exists(temp):
                os.unlink(temp)
        except OSError:
            pass
        return False


def _publish_shared_picons(entries):
    """Convert each series poster once, then every episode name points at it.

    Enigma2 keeps using the first picon folder that already contains a file.
    A copy on the hard disk is invisible when satellite picons already live in
    /usr/share/enigma2/picon, which is why the channel list stayed blank.
    """
    groups = {}
    order = []
    for item in entries or []:
        ref = str(item[0] or "")
        source = str(item[1] or "")
        name = str(item[2] or "") if len(item) > 2 else ""
        if not ref or not source or not os.path.isfile(source):
            continue
        if source not in groups:
            groups[source] = []
            order.append(source)
        groups[source].append((ref, name))
    if not order:
        return 0
    roots = _picon_directories()
    if not roots:
        return 0
    primary = []
    rest = []
    for root in roots:
        try:
            names = os.listdir(root)
        except OSError:
            names = []
        if any(str(name).lower().endswith(".png") for name in names):
            primary.append(root)
        else:
            rest.append(root)
    # Prefer the folder Enigma is already searching, then every other writable
    # folder. Stopping at the first one left series posters invisible when that
    # folder was full or was not the folder this image actually displays.
    roots = primary + list(root for root in rest if root not in primary)
    if primary and _fs_free_bytes(primary[0]) < 1024 * 1024:
        _reclaim_export_space()
    linked = 0
    for source in order:
        temp_dir = ""
        try:
            try:
                temp_dir = tempfile.mkdtemp(prefix="us-picon.")
            except OSError:
                _reclaim_export_space()
                temp_dir = tempfile.mkdtemp(prefix="us-picon.")
            temp_png = os.path.join(temp_dir, "picon.png")
            converted = False
            try:
                from PIL import Image, ImageOps
                with Image.open(source) as image:
                    try: image.seek(0)
                    except Exception: pass
                    try: image = ImageOps.exif_transpose(image)
                    except Exception: pass
                    image = image.convert("RGBA")
                    image.thumbnail((400, 600), getattr(Image, "LANCZOS", 1))
                    image.save(temp_png, "PNG", compress_level=9, optimize=False)
                    converted = True
            except Exception as exc:
                LOG.debug("Shared picon convert failed %s: %s", source, exc)
            if not converted:
                try:
                    with open(source, "rb") as handle:
                        head = handle.read(8)
                    if head == b"\x89PNG\r\n\x1a\n":
                        shutil.copyfile(source, temp_png)
                        converted = True
                except OSError:
                    converted = False
            if not converted or not os.path.isfile(temp_png) or os.path.getsize(temp_png) <= 100:
                continue
            for root in roots:
                master = ""
                for ref, channel_name in groups[source]:
                    filenames = []
                    for filename in _picon_filenames(ref, channel_name):
                        if os.path.basename(filename) != filename:
                            continue
                        filenames.append(filename)
                        lower = filename.lower()
                        if lower not in filenames:
                            filenames.append(lower)
                    for filename in filenames:
                        target = os.path.join(root, filename)
                        if not master:
                            if os.path.lexists(target):
                                continue
                            stage = target + ".tmp.%d.%d" % (os.getpid(), threading.get_ident())
                            try:
                                shutil.copyfile(temp_png, stage)
                                os.chmod(stage, 0o644)
                                os.replace(stage, target)
                                master = target
                                linked += 1
                            except OSError:
                                _reclaim_export_space()
                                try:
                                    shutil.copyfile(temp_png, stage)
                                    os.chmod(stage, 0o644)
                                    os.replace(stage, target)
                                    master = target
                                    linked += 1
                                except OSError as exc:
                                    LOG.debug("Shared picon master failed %s: %s", target, exc)
                                    try:
                                        if os.path.exists(stage):
                                            os.unlink(stage)
                                    except OSError:
                                        pass
                            continue
                        if _link_shared_picon(master, target):
                            linked += 1
        except Exception as exc:
            LOG.debug("Shared picon publish failed: %s", exc)
        finally:
            if temp_dir:
                shutil.rmtree(temp_dir, ignore_errors=True)
    return linked


def _queue_picon_publish(service_ref, source_path, channel_name=""):
    """Publish cached artwork after bouquet commit so VOD/Series export never waits on image conversion."""
    source = str(source_path or "")
    if not source or not os.path.isfile(source):
        return False
    try:
        _PICON_EXPORT_EXECUTOR.submit(_publish_picon, service_ref, source, channel_name)
        return True
    except Exception as exc:
        LOG.debug("Receiver picon queue failed: %s", exc)
        return False


def _append_bouquet_index(bouquet_name, drop_names=()):
    """Add one plugin bouquet without rewriting the satellite list.

    If bouquets.tv cannot be read, leave it untouched. Replacing it with a
    fresh file is what removes every satellite bouquet from the receiver.
    """
    path = os.path.join(ENIGMA2_DIR, "bouquets.tv")
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as handle:
            existing = handle.read().splitlines()
    except OSError:
        LOG.warning("Skipped bouquet index update because bouquets.tv could not be read")
        return False
    drop = list(str(name) for name in (drop_names or ()) if name and "ultrastalker" in str(name))
    kept = list(line for line in existing if not any(name in line for name in drop))
    include = '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % bouquet_name
    if not any(str(bouquet_name) in line for line in kept):
        kept.append(include)
    for line in existing:
        if "ultrastalker" in line:
            continue
        if line not in kept:
            LOG.warning("Refusing bouquet index update that would drop a non-plugin line")
            return False
    _atomic_text(path, "\n".join(kept) + "\n", 0o644)
    return True


def _atomic_text(path, text, mode=0o644):
    parent = os.path.dirname(path) or "/"
    if _fs_free_bytes(parent) < 6 * 1024 * 1024:
        _reclaim_export_space()
    os.makedirs(parent, exist_ok=True)
    temp = "%s.tmp.%d.%d" % (path, os.getpid(), threading.get_ident())
    try:
        with open(temp, "w", encoding="utf-8") as handle:
            handle.write(text)
            handle.flush(); os.fsync(handle.fileno())
        try: os.chmod(temp, mode)
        except OSError: pass
        os.replace(temp, path)
        _fsync_parent_dir(path)
    finally:
        try:
            if os.path.exists(temp): os.unlink(temp)
        except OSError:
            pass


def _bouquet_paths(profile_key):
    bouquet_name = "userbouquet.ultrastalker_%s.tv" % profile_key
    return {
        "bouquet_name": bouquet_name,
        "bouquet": os.path.join(ENIGMA2_DIR, bouquet_name),
        "epg_channels": os.path.join(EPGIMPORT_DIR, "ultrastalker_%s.channels.xml" % profile_key),
        "epg_source": os.path.join(EPGIMPORT_DIR, "ultrastalker_%s.sources.xml" % profile_key),
        "xmltv_cache": _xmltv_cache_path(profile_key),
    }



def _snapshot_file(path):
    try:
        with open(path, "rb") as handle:
            data = handle.read()
        try: mode = os.stat(path).st_mode & 0o777
        except OSError: mode = 0o644
        return True, data, mode
    except OSError:
        return False, b"", 0o644


def _restore_snapshot(path, snapshot):
    existed, data, mode = snapshot
    try:
        if existed:
            os.makedirs(os.path.dirname(path), exist_ok=True)
            temp = path + ".rollback.%d.%d" % (os.getpid(), threading.get_ident())
            with open(temp, "wb") as handle:
                handle.write(data); handle.flush(); os.fsync(handle.fileno())
            try: os.chmod(temp, mode)
            except OSError: pass
            os.replace(temp, path)
            _fsync_parent_dir(path)
        else:
            try:
                os.unlink(path)
                _fsync_parent_dir(path)
            except OSError:
                pass
    except Exception as exc:
        LOG.warning("Bouquet rollback failed path=%s: %s", path, exc)


def export_live_integration(profile, channels, service_type=4097):
    """Atomically export dynamic bouquet + EPGImport state.

    Registry publication is the final commit point. If any file write fails,
    every touched file is restored so Enigma2 never sees a half-exported portal.
    """
    profile = dict(profile or {})
    rows = list(dict(row) for row in (channels or []) if isinstance(row, dict) and (row.get("cmd") or row.get("command") or row.get("url")))
    if not rows:
        raise ValueError("Portal returned no exportable live channels")
    pkey = _profile_key(profile)
    paths = _bouquet_paths(pkey)
    bouquet_index = os.path.join(ENIGMA2_DIR, "bouquets.tv")
    touched = [paths["bouquet"], bouquet_index, paths["epg_channels"], paths["epg_source"], REGISTRY_FILE]
    snapshots = {path: _snapshot_file(path) for path in touched}
    old_registry = _read_registry()
    old_entries = _registry_entries(old_registry)
    proxy_started_for_export = False
    try:
        with _REGISTRY_LOCK:
            registry = _read_registry()
            port = _choose_export_port(registry)
            was_running = _SERVER is not None
            start_proxy_server(port=port, require_registry=False, strict=True)
            proxy_started_for_export = not was_running and _SERVER is not None
            entry = dict(registry.get(pkey) or {})
            proxy_token = str(entry.get("proxy_token") or "") or _new_proxy_token()

            registry_channels = dict(entry.get("channels") or {})
            bouquet_lines = ["#NAME Live TV"]
            channel_xml = ['<?xml version="1.0" encoding="utf-8"?>', "<channels>"]
            pending_epg = []
            for row in rows:
                ckey = _channel_key(row); registry_channels[ckey] = row
                row["_receiver_media_type"] = "itv"
                name = _receiver_name(row, "itv")
                ref = _service_ref(_proxy_url(pkey, ckey, port, proxy_token), service_type, identity=ckey)
                bouquet_lines.append("#SERVICE %s:%s" % (ref, name)); bouquet_lines.append("#DESCRIPTION %s" % name)
                _publish_picon(ref, row.get("_receiver_picon_local") or row.get("_receiver_picon_source_local"), name)
                pending_epg.append((ref, dict(row)))
                channel_xml.append('  <channel id="%s">%s</channel>' % (escape(_xmltv_id(pkey, ckey), {'"': '&quot;'}), escape(ref + ":" + name)))
            channel_xml.append("</channels>")

            _atomic_text(paths["bouquet"], "\n".join(bouquet_lines) + "\n", 0o644)
            _append_bouquet_index(paths["bouquet_name"])
            _atomic_text(paths["epg_channels"], "\n".join(channel_xml) + "\n", 0o644)
            xmltv_url = _xmltv_url(pkey, port, proxy_token)
            source_xml = (
                '<?xml version="1.0" encoding="utf-8"?>\n<sources>\n'
                '  <sourcecat sourcecatname="Ultra Stalker">\n'
                '    <source type="gen_xmltv" nocheck="1" channels="%s">\n'
                '      <description>%s</description>\n      <url>%s</url>\n'
                '    </source>\n  </sourcecat>\n</sources>\n'
            ) % (escape(paths["epg_channels"]), escape("Ultra Stalker - " + _safe_name(profile.get("name") or profile.get("portal") or "Portal")), escape(xmltv_url))

            _atomic_text(paths["epg_source"], source_xml, 0o644)

            registry["_meta"] = {"format": 2, "proxy_port": port, "updated_at": int(time.time())}
            registry[pkey] = {
                "profile": profile, "service_type": int(service_type or entry.get("service_type") or 4097), "channels": registry_channels,
                "media_metadata": dict(entry.get("media_metadata") or {}),
                "updated_at": int(time.time()),
                "epg_hours": max(2, min(24, int(load_settings().get("epg_hours", 4) or 4))),
                "proxy_port": port,
                "proxy_token": proxy_token,
                "category_exports": dict(entry.get("category_exports") or {}),
                "series_category_exports": dict(entry.get("series_category_exports") or {}),
                "vod_category_exports": dict(entry.get("vod_category_exports") or {}),
                "smart_exports": dict(entry.get("smart_exports") or {}),
                "manual_exports": dict(entry.get("manual_exports") or {}),
            }
            _write_registry(registry)

        _ensure_xmltv_placeholder(pkey)
        epg_seed = _live_export_epg_seed(profile, pending_epg)
        return {"profile_key": pkey, "channels": len(rows), "bouquet": paths["bouquet"],
                "epg_channels": paths["epg_channels"], "epg_source": paths["epg_source"],
                "xmltv_url": xmltv_url, "proxy_port": port,
                "epg_seed": epg_seed, "epg_seed_channels": len(epg_seed)}
    except Exception:
        for path in reversed(touched): _restore_snapshot(path, snapshots[path])
        if proxy_started_for_export and not old_entries:
            try: stop_proxy_server()
            except Exception as exc: LOG.debug("Bouquet export rollback proxy stop failed: %s", exc)
        raise



def export_live_category_bouquet(profile, channels, category_name, category_id=None, service_type=4097):
    """Export one Live category as its own Enigma2 TV bouquet.

    This intentionally does not reload the plugin/browser screen.  The dynamic
    proxy registry is merged in-place so exported channels keep working outside
    Ultra Stalker while the caller can preserve its exact category selection.
    Re-exporting the same category overwrites the same bouquet file atomically.
    """
    profile = dict(profile or {})
    rows = list(dict(row) for row in (channels or []) if isinstance(row, dict) and (row.get("cmd") or row.get("command") or row.get("url")))
    if not rows:
        raise ValueError("Category returned no exportable live channels")

    pkey = _profile_key(profile)
    label = _safe_name(category_name or "Live")
    identity = str(category_id or category_name or "live")
    digest = hashlib.sha1(identity.encode("utf-8", "ignore")).hexdigest()[:10]
    bouquet_name = "userbouquet.ultrastalker_%s_cat_%s.tv" % (pkey, digest)
    bouquet_path = os.path.join(ENIGMA2_DIR, bouquet_name)
    bouquet_index = os.path.join(ENIGMA2_DIR, "bouquets.tv")
    shared_paths = _bouquet_paths(pkey)
    touched = [bouquet_path, bouquet_index, shared_paths["epg_channels"], shared_paths["epg_source"], REGISTRY_FILE]
    snapshots = {path: _snapshot_file(path) for path in touched}
    old_registry = _read_registry()
    old_entries = _registry_entries(old_registry)
    proxy_started_for_export = False

    try:
        with _REGISTRY_LOCK:
            registry = _read_registry()
            port = _choose_export_port(registry)
            was_running = _SERVER is not None
            start_proxy_server(port=port, require_registry=False, strict=True)
            proxy_started_for_export = not was_running and _SERVER is not None

            entry = dict(registry.get(pkey) or {})
            existing_channels = dict(entry.get("channels") or {})
            token = str(entry.get("proxy_token") or "") or _new_proxy_token()
            bouquet_lines = ["#NAME %s" % label]
            exported_keys = []
            pending_epg = []
            for row in rows:
                ckey = _channel_key(row)
                existing_channels[ckey] = row
                exported_keys.append(ckey)
                row["_receiver_media_type"] = "itv"
                name = _receiver_name(row, "itv")
                ref = _service_ref(_proxy_url(pkey, ckey, port, token), service_type, identity=ckey)
                bouquet_lines.append("#SERVICE %s:%s" % (ref, name))
                bouquet_lines.append("#DESCRIPTION %s" % name)
                _publish_picon(ref, row.get("_receiver_picon_local") or row.get("_receiver_picon_source_local"), name)
                pending_epg.append((ref, dict(row)))

            _atomic_text(bouquet_path, "\n".join(bouquet_lines) + "\n", 0o644)
            _append_bouquet_index(bouquet_name)

            # Category exports now publish the same EPGImport mapping as full exports.
            # Previously the bouquet could play perfectly but ChannelSelection had no EPG source.
            os.makedirs(EPGIMPORT_DIR, mode=0o755, exist_ok=True)
            channel_xml = ['<?xml version="1.0" encoding="utf-8"?>', '<channels>']
            for map_key, map_row in existing_channels.items():
                if not isinstance(map_row, dict) or str(map_row.get("_receiver_media_type") or "itv").lower() != "itv":
                    continue
                map_ref = _service_ref(_proxy_url(pkey, map_key, port, token), service_type, identity=map_key)
                channel_xml.append('  <channel id="%s">%s</channel>' % (escape(_xmltv_id(pkey, map_key), {'"': '&quot;'}), escape(map_ref + ":" + _receiver_name(map_row, "itv"))))
            channel_xml.append('</channels>')
            xmltv_url = _xmltv_url(pkey, port, token)
            source_xml = (
                '<?xml version="1.0" encoding="utf-8"?>\n<sources>\n'
                '  <sourcecat sourcecatname="Ultra Stalker">\n'
                '    <source type="gen_xmltv" nocheck="1" channels="%s">\n'
                '      <description>%s</description>\n      <url>%s</url>\n'
                '    </source>\n  </sourcecat>\n</sources>\n'
            ) % (escape(shared_paths["epg_channels"]), escape("Ultra Stalker - " + _safe_name(profile.get("name") or profile.get("portal") or "Portal")), escape(xmltv_url))
            _atomic_text(shared_paths["epg_channels"], "\n".join(channel_xml) + "\n", 0o644)
            _atomic_text(shared_paths["epg_source"], source_xml, 0o644)

            exports = dict(entry.get("category_exports") or {})
            exports[digest] = {
                "category_id": identity, "category_name": label,
                "bouquet_name": bouquet_name, "channels": exported_keys,
                "updated_at": int(time.time()),
            }
            registry["_meta"] = {"format": 2, "proxy_port": port, "updated_at": int(time.time())}
            registry[pkey] = {
                "profile": profile,
                "service_type": int(service_type or entry.get("service_type") or 4097),
                "channels": existing_channels,
                "media_metadata": dict(entry.get("media_metadata") or {}),
                "updated_at": int(time.time()),
                "epg_hours": max(2, min(24, int(load_settings().get("epg_hours", 4) or 4))),
                "proxy_port": port,
                "proxy_token": token,
                "category_exports": exports,
                "series_category_exports": dict(entry.get("series_category_exports") or {}),
                "vod_category_exports": dict(entry.get("vod_category_exports") or {}),
                "smart_exports": dict(entry.get("smart_exports") or {}),
                "manual_exports": dict(entry.get("manual_exports") or {}),
            }
            _write_registry(registry)

        _ensure_xmltv_placeholder(pkey)
        epg_seed = _cached_receiver_epg_seed(profile, pending_epg)
        refresh_xmltv_async(pkey, force=True)
        return {
            "profile_key": pkey, "channels": len(rows), "bouquet": bouquet_path,
            "bouquet_name": bouquet_name, "category": label, "proxy_port": port,
            "epg_seed": epg_seed, "epg_seed_channels": len(epg_seed),
        }
    except Exception:
        for path in reversed(touched):
            _restore_snapshot(path, snapshots[path])
        if proxy_started_for_export and not old_entries:
            try: stop_proxy_server()
            except Exception as exc: LOG.debug("Category bouquet rollback proxy stop failed: %s", exc)
        raise


def _prepare_export_metadata(profile,item,media_type="vod",season_count=0):
    """Export-worker text hydration. Background EPG reimports remain cache-only."""
    cached=_prepare_media_metadata(profile,item,media_type,season_count)
    if cached.get("description") and cached.get("summary"):return cached
    client=None
    try:
        source=dict(item or {})
        if source.get("_xtream"):
            client=_client(profile)
            enrich=getattr(client,"enrich_provider_artwork",None)
            if callable(enrich):
                try:
                    from .call_compat import call_compatible
                    kind="series" if media_type in ("series","episode","tv") else "vod"
                    enriched=call_compatible(enrich,(((dict(source),kind),{"force":True}),((dict(source),kind),{})))
                    if isinstance(enriched,dict):source.update(enriched)
                except Exception as exc:LOG.debug("Export provider metadata unavailable: %s",exc.__class__.__name__)
        fresh=_prepare_media_metadata(profile,source,media_type,season_count,hydrate=True,provider_client=client)
        # Preserve approved text even if only genres/year needed enrichment.
        fresh.update({k:v for k,v in cached.items() if v not in (None,"",[],{}) and not k.startswith("_") and k!="summary"})
        fresh["summary"]=_media_metadata_fields(fresh,{},media_type,season_count)["summary"]
        return fresh
    finally:
        if client is not None:
            try:client.close()
            except Exception:pass


def export_receiver_items(profile, items, media_type, label=None, service_type=4097):
    """Append selected Live/VOD/Episode items to a receiver-side bouquet.

    The bouquet always uses stable loopback proxy references so expiring provider
    links are resolved only when Enigma2 tunes the item. Cached artwork is
    published as a native picon when the caller supplies _receiver_picon_local.
    """
    profile = dict(profile or {})
    media_type = str(media_type or "itv").lower()
    if media_type == "movie":
        media_type = "vod"
    if media_type not in ("itv", "vod", "episode"):
        raise ValueError("Unsupported receiver media type: %s" % media_type)
    rows = list(dict(row) for row in (items or []) if isinstance(row, dict) and (row.get("cmd") or row.get("command") or row.get("url")))
    if not rows:
        raise ValueError("No playable items to export")

    if media_type != "itv":
        for row in rows:
            row["_receiver_metadata"] = _prepare_export_metadata(profile, row, media_type)
    pkey = _profile_key(profile)
    group = "live" if media_type == "itv" else ("movies" if media_type == "vod" else "series")
    bouquet_name = "userbouquet.ultrastalker_%s_smart_%s.tv" % (pkey, group)
    bouquet_path = os.path.join(ENIGMA2_DIR, bouquet_name)
    bouquet_index = os.path.join(ENIGMA2_DIR, "bouquets.tv")
    shared_paths = _bouquet_paths(pkey)
    touched = [bouquet_path, bouquet_index, REGISTRY_FILE]
    if media_type == "itv":
        touched += [shared_paths["epg_channels"], shared_paths["epg_source"]]
    snapshots = {path: _snapshot_file(path) for path in touched}
    old_registry = _read_registry()
    old_entries = _registry_entries(old_registry)
    proxy_started_for_export = False

    try:
        with _REGISTRY_LOCK:
            registry = _read_registry()
            port = _choose_export_port(registry)
            was_running = _SERVER is not None
            start_proxy_server(port=port, require_registry=False, strict=True)
            proxy_started_for_export = not was_running and _SERVER is not None

            entry = dict(registry.get(pkey) or {})
            channels = dict(entry.get("channels") or {})
            token = str(entry.get("proxy_token") or "") or _new_proxy_token()
            smart = dict(entry.get("smart_exports") or {})
            saved = dict((smart.get(group) or {}).get("items") or {})
            pending_epg = []

            for row in rows:
                row["_receiver_media_type"] = media_type
                ckey = _channel_key(row)
                channels[ckey] = row
                saved[ckey] = True

            display_label = _safe_name(label or ("Live" if group == "live" else ("Movies" if group == "movies" else "Series")))
            bouquet_lines = ["#NAME %s" % display_label]
            for ckey in saved:
                row = channels.get(ckey)
                if not isinstance(row, dict):
                    continue
                row_type = str(row.get("_receiver_media_type") or media_type).lower()
                ref = _service_ref(_proxy_url(pkey, ckey, port, token), service_type, identity=ckey)
                name = _receiver_name(row, row_type)
                bouquet_lines.append("#SERVICE %s:%s" % (ref, name))
                bouquet_lines.append("#DESCRIPTION %s" % name)
                art = row.get("_receiver_picon_local") or row.get("_receiver_picon_source_local")
                if row_type == "itv":
                    _publish_picon(ref, art, name)
                    pending_epg.append((ref, dict(row)))
                else:
                    _queue_picon_publish(ref, art, name)

            _atomic_text(bouquet_path, "\n".join(bouquet_lines) + "\n", 0o644)
            _append_bouquet_index(bouquet_name)

            smart[group] = {"bouquet_name": bouquet_name, "items": saved, "updated_at": int(time.time())}
            registry["_meta"] = {"format": 2, "proxy_port": port, "updated_at": int(time.time())}
            registry[pkey] = {
                "profile": profile,
                "service_type": int(service_type or entry.get("service_type") or 4097),
                "channels": channels,
                "media_metadata": dict(entry.get("media_metadata") or {}),
                "updated_at": int(time.time()),
                "epg_hours": max(2, min(24, int(load_settings().get("epg_hours", 4) or 4))),
                "proxy_port": port,
                "proxy_token": token,
                "category_exports": dict(entry.get("category_exports") or {}),
                "series_category_exports": dict(entry.get("series_category_exports") or {}),
                "vod_category_exports": dict(entry.get("vod_category_exports") or {}),
                "smart_exports": smart,
                "manual_exports": dict(entry.get("manual_exports") or {}),
            }
            _write_registry(registry)

        if media_type == "itv":
            # Reuse the normal profile EPGImport mapping for Smart Live items.
            entry = _read_registry().get(pkey) or {}
            channels = entry.get("channels") or {}
            token = str(entry.get("proxy_token") or "")
            port = int(entry.get("proxy_port") or _registry_port())
            channel_xml = ['<?xml version="1.0" encoding="utf-8"?>', '<channels>']
            for ckey, row in channels.items():
                if not isinstance(row, dict) or str(row.get("_receiver_media_type") or "itv").lower() != "itv":
                    continue
                ref = _service_ref(_proxy_url(pkey, ckey, port, token), service_type, identity=ckey)
                channel_xml.append('  <channel id="%s">%s</channel>' % (escape(_xmltv_id(pkey, ckey), {'"': '&quot;'}), escape(ref + ":" + _receiver_name(row, "itv"))))
            channel_xml.append('</channels>')
            os.makedirs(EPGIMPORT_DIR, mode=0o755, exist_ok=True)
            xmltv_url = _xmltv_url(pkey, port, token)
            source_xml = (
                '<?xml version="1.0" encoding="utf-8"?>\n<sources>\n'
                '  <sourcecat sourcecatname="Ultra Stalker">\n'
                '    <source type="gen_xmltv" nocheck="1" channels="%s">\n'
                '      <description>%s</description>\n      <url>%s</url>\n'
                '    </source>\n  </sourcecat>\n</sources>\n'
            ) % (escape(shared_paths["epg_channels"]), escape("Ultra Stalker - " + _safe_name(profile.get("name") or profile.get("portal") or "Portal")), escape(xmltv_url))
            _atomic_text(shared_paths["epg_channels"], "\n".join(channel_xml) + "\n", 0o644)
            _atomic_text(shared_paths["epg_source"], source_xml, 0o644)
            _ensure_xmltv_placeholder(pkey)

        epg_seed = _live_export_epg_seed(profile, pending_epg) if media_type == "itv" else []
        if media_type != "itv":
            _queue_exported_media_metadata(registry.get(pkey) or {}, force=True)
        return {"profile_key": pkey, "items": len(rows), "bouquet": bouquet_path, "bouquet_name": bouquet_name, "group": group,
                "epg_seed": epg_seed, "epg_seed_channels": len(epg_seed)}
    except Exception:
        for path in reversed(touched):
            _restore_snapshot(path, snapshots[path])
        if proxy_started_for_export and not old_entries:
            try: stop_proxy_server()
            except Exception as exc: LOG.debug("Smart receiver export rollback proxy stop failed: %s", exc)
        raise



def export_series_category_bouquets(profile, series_groups, category_name, category_id=None, service_type=4097):
    """Export direct Series entries, with a persisted season/episode hierarchy.

    series_groups: [{"name": str, "poster": path, "episodes": [playable rows]}]
    This deliberately leaves Live export untouched and writes all files atomically before
    publishing cached artwork in the background.
    """
    profile = dict(profile or {})
    groups = []
    for group in (series_groups or []):
        if not isinstance(group, dict):
            continue
        seasons_out = []
        for season in group.get("seasons") or []:
            if not isinstance(season, dict):
                continue
            season_eps = list(dict(row) for row in (season.get("episodes") or [])
                          if isinstance(row, dict) and (row.get("cmd") or row.get("command") or row.get("url")))
            if season_eps:
                seasons_out.append({"name": _safe_name(season.get("name") or "Season"), "episodes": season_eps})
        episodes = list(dict(row) for row in (group.get("episodes") or [])
                    if isinstance(row, dict) and (row.get("cmd") or row.get("command") or row.get("url")))
        if not seasons_out and not episodes:
            continue
        groups.append({"name": _safe_name(group.get("name") or "Series"),
                       "poster": str(group.get("poster") or ""), "episodes": episodes, "seasons": seasons_out,
                       "metadata": _prepare_media_metadata(profile, group.get("metadata") or {"name":group.get("name")}, "series", len(seasons_out))})
    if not groups:
        raise ValueError("No playable series episodes to export")

    pkey = _profile_key(profile)
    label = _safe_name(category_name or "Series")
    identity = str(category_id or label or "series")
    digest = hashlib.sha1(identity.encode("utf-8", "ignore")).hexdigest()[:10]
    parent_name = "userbouquet.ultrastalker_%s_seriescat_%s.tv" % (pkey, digest)
    parent_path = os.path.join(ENIGMA2_DIR, parent_name)
    bouquet_index = os.path.join(ENIGMA2_DIR, "bouquets.tv")
    old_flat_name = "userbouquet.ultrastalker_%s_smart_series.tv" % pkey
    old_flat_path = os.path.join(ENIGMA2_DIR, old_flat_name)

    child_specs = []
    nest_under_series = not (len(groups) == 1 and groups[0]["name"] == label and groups[0].get("seasons"))
    for pos, group in enumerate(groups):
        sdigest = hashlib.sha1((identity + "|" + group["name"] + "|" + str(pos)).encode("utf-8", "ignore")).hexdigest()[:10]
        child_name = "userbouquet.ultrastalker_%s_series_%s.tv" % (pkey, sdigest)
        child_specs.append((group, child_name, os.path.join(ENIGMA2_DIR, child_name)))

    touched = [parent_path, bouquet_index, old_flat_path, REGISTRY_FILE] + [x[2] for x in child_specs]
    snapshots = {path: _snapshot_file(path) for path in touched}
    old_registry = _read_registry()
    old_entries = _registry_entries(old_registry)
    proxy_started_for_export = False
    pending_picons = []

    try:
        with _REGISTRY_LOCK:
            registry = _read_registry()
            port = _choose_export_port(registry)
            was_running = _SERVER is not None
            start_proxy_server(port=port, require_registry=False, strict=True)
            proxy_started_for_export = not was_running and _SERVER is not None
            entry = dict(registry.get(pkey) or {})
            channels = dict(entry.get("channels") or {})
            metadata_records = dict(entry.get("media_metadata") or {})
            token = str(entry.get("proxy_token") or "") or _new_proxy_token()

            parent_lines = ["#NAME %s" % label]
            total = 0
            export_children = []

            def _append_episode(lines, row, poster_fallback, metadata):
                row["_receiver_media_type"] = "episode"
                metadata = dict(metadata or {})
                metadata_key = hashlib.sha1(json.dumps(metadata,sort_keys=True,ensure_ascii=False).encode("utf-8")).hexdigest()[:24]
                metadata_records[metadata_key] = metadata
                row["_receiver_metadata_key"] = metadata_key
                row.pop("_receiver_metadata",None)
                if row.get("_receiver_link_series") in (None, ""):
                    row["_receiver_link_series"] = row.get("id") or row.get("episode_id") or row.get("series") or row.get("number") or ""
                ckey = _channel_key(row)
                channels[ckey] = row
                ref = _service_ref(_proxy_url(pkey, ckey, port, token), service_type, identity=ckey)
                name = _receiver_name(row, "episode")
                lines.append("#SERVICE %s:%s" % (ref, name))
                lines.append("#DESCRIPTION %s" % name)
                poster = str(row.get("_receiver_picon_local") or "")
                if not (poster and os.path.isfile(poster)):
                    poster = str(poster_fallback or "")
                if poster and os.path.isfile(poster):
                    row["_receiver_picon_local"] = poster
                    pending_picons.append((ref, poster, name))
                return ckey

            from .export_series import launcher_row
            for group, child_name, child_path in child_specs:
                episode_keys = []
                saved_seasons = []
                seasons = list(group.get("seasons") or [])
                if not seasons:
                    seasons = [{"name": "Season 1", "episodes": group.get("episodes") or []}]
                for number, season in enumerate(seasons, 1):
                    keys = []
                    for row in season.get("episodes") or []:
                        key = _append_episode([], row, group.get("poster"), group.get("metadata"))
                        keys.append(key)
                        episode_keys.append(key)
                        total += 1
                    match = re.search(r"(?:season\s*|^S)(\d+)", str(season.get("name") or ""), re.I)
                    season_number = int(match.group(1)) if match else number
                    saved_seasons.append({"id": str(season_number), "season_number": season_number,
                                          "name": season.get("name") or "Season %d" % number,
                                          "episode_keys": keys})
                metadata_key = channels[episode_keys[0]]["_receiver_metadata_key"]
                launcher = launcher_row(identity, group["name"], metadata_key, group.get("poster"), saved_seasons)
                launch_key = _channel_key(launcher)
                channels[launch_key] = launcher
                ref = _service_ref(_proxy_url(pkey, launch_key, port, token), service_type, identity=launch_key)
                name = _receiver_name(launcher, "series")
                parent_lines.extend(["#SERVICE %s:%s" % (ref, name), "#DESCRIPTION %s" % name])
                poster = str(group.get("poster") or "")
                if poster and os.path.isfile(poster):
                    pending_picons.append((ref, poster, name))
                export_children.append({"name": group["name"], "launcher_key": launch_key,
                                        "episodes": episode_keys, "seasons": saved_seasons})

            _atomic_text(parent_path, "\n".join(parent_lines) + "\n", 0o644)
            _append_bouquet_index(parent_name, drop_names=(old_flat_name,))
            try:
                if os.path.isfile(old_flat_path):
                    os.unlink(old_flat_path)
                    _fsync_parent_dir(old_flat_path)
            except OSError:
                pass

            exports = dict(entry.get("series_category_exports") or {})
            exports[digest] = {"category_id": identity, "category_name": label, "bouquet_name": parent_name,
                               "children": export_children, "updated_at": int(time.time())}
            registry["_meta"] = {"format": 2, "proxy_port": port, "updated_at": int(time.time())}
            registry[pkey] = {
                "profile": profile,
                "service_type": int(service_type or entry.get("service_type") or 4097),
                "channels": channels,
                "media_metadata": metadata_records,
                "updated_at": int(time.time()),
                "epg_hours": max(2, min(24, int(load_settings().get("epg_hours", 4) or 4))),
                "proxy_port": port,
                "proxy_token": token,
                "category_exports": dict(entry.get("category_exports") or {}),
                "series_category_exports": exports,
                "vod_category_exports": dict(entry.get("vod_category_exports") or {}),
                "smart_exports": dict(entry.get("smart_exports") or {}),
                "manual_exports": dict(entry.get("manual_exports") or {}),
            }
            _write_registry(registry)

        for _, _, child_path in child_specs:
            try:
                if os.path.isfile(child_path): os.unlink(child_path)
            except OSError: pass
        from .export_series import prepare_native_series_bouquets
        _publish_shared_picons(pending_picons)
        prepare_native_series_bouquets(registry.get(pkey) or {})
        # Publish this category, not every previously exported episode. Visible
        # series entries precede their episodes, including on a busy receiver.
        new_keys = list(child["launcher_key"] for child in export_children)
        new_keys.extend(key for child in export_children for key in child["episodes"])
        current = dict(registry.get(pkey) or {})
        current["channels"] = {key:channels[key] for key in new_keys}
        _queue_exported_media_metadata(current, force=True)
        _queue_category_metadata_refresh(pkey, channel_keys=new_keys)
        return {"profile_key": pkey, "items": total, "series": len(groups), "bouquet": parent_path,
                "bouquet_name": parent_name, "category": label, "proxy_port": port}
    except Exception:
        for path in reversed(touched):
            _restore_snapshot(path, snapshots[path])
        if proxy_started_for_export and not old_entries:
            try: stop_proxy_server()
            except Exception as exc: LOG.debug("Series category rollback proxy stop failed: %s", exc)
        raise


def export_vod_category_bouquet(profile, items, category_name, category_id=None, service_type=4097):
    """Export one Movies folder as its own bouquet. Does not merge other folders."""
    profile = dict(profile or {})
    rows = list(dict(row) for row in (items or []) if isinstance(row, dict) and (row.get("cmd") or row.get("command") or row.get("url")))
    if not rows:
        raise ValueError("No playable movies to export")
    for row in rows:
        row["_receiver_metadata"] = _prepare_media_metadata(profile, row, "vod")
    pkey = _profile_key(profile)
    label = _safe_name(category_name or "Movies")
    identity = str(category_id or label or "vod")
    digest = hashlib.sha1(("vod|" + identity).encode("utf-8", "ignore")).hexdigest()[:10]
    bouquet_name = "userbouquet.ultrastalker_%s_vodcat_%s.tv" % (pkey, digest)
    bouquet_path = os.path.join(ENIGMA2_DIR, bouquet_name)
    bouquet_index = os.path.join(ENIGMA2_DIR, "bouquets.tv")
    touched = [bouquet_path, bouquet_index, REGISTRY_FILE]
    snapshots = {path: _snapshot_file(path) for path in touched}
    old_registry = _read_registry()
    old_entries = _registry_entries(old_registry)
    proxy_started_for_export = False
    pending_picons = []
    try:
        with _REGISTRY_LOCK:
            registry = _read_registry()
            port = _choose_export_port(registry)
            was_running = _SERVER is not None
            start_proxy_server(port=port, require_registry=False, strict=True)
            proxy_started_for_export = not was_running and _SERVER is not None
            entry = dict(registry.get(pkey) or {})
            channels = dict(entry.get("channels") or {})
            token = str(entry.get("proxy_token") or "") or _new_proxy_token()
            lines = ["#NAME %s" % label]
            for row in rows:
                row["_receiver_media_type"] = "vod"
                ckey = _channel_key(row)
                channels[ckey] = row
                ref = _service_ref(_proxy_url(pkey, ckey, port, token), service_type, identity=ckey)
                name = _receiver_name(row, "vod")
                lines.append("#SERVICE %s:%s" % (ref, name))
                lines.append("#DESCRIPTION %s" % name)
                art = row.get("_receiver_picon_local") or row.get("_receiver_picon_source_local")
                if art:
                    pending_picons.append((ref, art, name))
            _atomic_text(bouquet_path, "\n".join(lines) + "\n", 0o644)
            _append_bouquet_index(bouquet_name)
            exports = dict(entry.get("vod_category_exports") or {})
            exports[digest] = {"category_id": identity, "category_name": label, "bouquet_name": bouquet_name, "updated_at": int(time.time())}
            registry["_meta"] = {"format": 2, "proxy_port": port, "updated_at": int(time.time())}
            registry[pkey] = {
                "profile": profile,
                "service_type": int(service_type or entry.get("service_type") or 4097),
                "channels": channels,
                "media_metadata": dict(entry.get("media_metadata") or {}),
                "updated_at": int(time.time()),
                "epg_hours": max(2, min(24, int(load_settings().get("epg_hours", 4) or 4))),
                "proxy_port": port,
                "proxy_token": token,
                "category_exports": dict(entry.get("category_exports") or {}),
                "series_category_exports": dict(entry.get("series_category_exports") or {}),
                "vod_category_exports": exports,
                "smart_exports": dict(entry.get("smart_exports") or {}),
                "manual_exports": dict(entry.get("manual_exports") or {}),
            }
            _write_registry(registry)
        for ref, art, name in pending_picons:
            _queue_picon_publish(ref, art, name)
        new_keys = list(_channel_key(row) for row in rows)
        current = dict(registry.get(pkey) or {})
        current["channels"] = {key:channels[key] for key in new_keys}
        _queue_exported_media_metadata(current, force=True)
        _queue_category_metadata_refresh(pkey, channel_keys=new_keys)
        return {"profile_key": pkey, "items": len(rows), "bouquet": bouquet_path, "bouquet_name": bouquet_name, "category": label}
    except Exception:
        for path in reversed(touched):
            _restore_snapshot(path, snapshots[path])
        if proxy_started_for_export and not old_entries:
            try: stop_proxy_server()
            except Exception as exc: LOG.debug("Movie category rollback proxy stop failed: %s", exc)
        raise


def _filter_export_services(text, matches):
    """Remove a service and its adjacent description, preserving all other bytes."""
    kept = []
    skip_description = False
    for line in text.splitlines(True):
        if line.startswith("#SERVICE "):
            skip_description = bool(matches(line[len("#SERVICE "):].rstrip("\r\n")))
            if skip_description:
                continue
        elif skip_description and line.startswith("#DESCRIPTION "):
            skip_description = False
            continue
        else:
            skip_description = False
        kept.append(line)
    return "".join(kept)


def _is_export_proxy_service(service, pkey, channel_keys, port):
    """Match only this source's recorded loopback stream references."""
    try:
        fields = service.split(":", 11)
        if len(fields) < 11:
            return False
        url = urllib.parse.urlsplit(urllib.parse.unquote(fields[10]))
        parts = url.path.strip("/").split("/")
        return (url.scheme == "http" and url.hostname in ("127.0.0.1", "localhost", "::1")
                and url.port == int(port) and len(parts) in (3, 4) and parts[0] == "stream"
                and parts[-2] == pkey and parts[-1] in channel_keys)
    except (ValueError, TypeError):
        return False


def unexport_live_integration(profile_or_key, reload=True):
    """Remove all exports of one source; keep other sources and personal channels."""
    pkey = str(profile_or_key or "") if isinstance(profile_or_key, str) else _profile_key(profile_or_key or {})
    paths = _bouquet_paths(pkey)
    removed = []
    with _REGISTRY_LOCK:
        registry = _read_registry()
        entry = registry.get(pkey) or {}
        prefix = "userbouquet.ultrastalker_%s_" % pkey
        owned = {paths["bouquet_name"]}
        try:
            owned.update(name for name in os.listdir(ENIGMA2_DIR)
                         if name.startswith(prefix) and name.endswith(".tv"))
        except OSError as exc:
            if not isinstance(exc, FileNotFoundError): raise
            pass
        delete_paths = {paths[key] for key in ("bouquet", "epg_channels", "epg_source", "xmltv_cache")}
        delete_paths.update(os.path.join(ENIGMA2_DIR, name) for name in owned)
        edits = {}
        for filename, keys in (entry.get("manual_exports") or {}).items():
            if not isinstance(filename, str) or os.path.basename(filename) != filename or not filename.endswith(".tv"):
                continue
            path = os.path.join(ENIGMA2_DIR, filename)
            if path in delete_paths:
                continue
            if os.path.islink(path):
                raise ValueError("Export target must not be a symbolic link")
            try:
                with open(path, "r", encoding="utf-8", newline="") as handle:
                    original = handle.read()
            except OSError as exc:
                if not isinstance(exc, FileNotFoundError): raise
                continue
            channel_keys = set(str(key) for key in (keys or []))
            port = int(entry.get("proxy_port") or _registry_port(registry))
            filtered = _filter_export_services(original,
                lambda service: _is_export_proxy_service(service, pkey, channel_keys, port))
            if filtered != original:
                edits[path] = filtered
        bouquet_index = os.path.join(ENIGMA2_DIR, "bouquets.tv")
        try:
            with open(bouquet_index, "r", encoding="utf-8", newline="") as handle:
                original = handle.read()
            def owned_reference(service):
                match = re.search(r'FROM BOUQUET "([^"\r\n]+)"', service)
                return bool(match and match.group(1) in owned)
            filtered = _filter_export_services(original, owned_reference)
            if filtered != original:
                edits[bouquet_index] = filtered
        except OSError as exc:
            if not isinstance(exc, FileNotFoundError): raise
            pass
        touched = delete_paths | set(edits) | {REGISTRY_FILE}
        snapshots = {}
        for path in touched:
            if os.path.islink(path):
                raise ValueError("Export cleanup path must not be a symbolic link")
            snapshot = _snapshot_file(path)
            if not snapshot[0] and os.path.lexists(path):
                raise OSError("Could not snapshot export cleanup path: %s" % path)
            snapshots[path] = snapshot
        try:
            for path, text in edits.items():
                _atomic_text(path, text, snapshots[path][2])
            for path in sorted(delete_paths):
                try:
                    os.unlink(path)
                except OSError as exc:
                    if not isinstance(exc, FileNotFoundError): raise
                    continue
                _fsync_parent_dir(path)
                removed.append(path)
            registry.pop(pkey, None)
            if _registry_entries(registry):
                registry["_meta"] = {"format": 2, "proxy_port": _registry_port(registry), "updated_at": int(time.time())}
                _write_registry(registry)
            else:
                try:
                    os.unlink(REGISTRY_FILE)
                    _fsync_parent_dir(REGISTRY_FILE)
                    removed.append(REGISTRY_FILE)
                except OSError as exc:
                    if not isinstance(exc, FileNotFoundError): raise
                    pass
        except Exception:
            for path, snapshot in snapshots.items():
                _restore_snapshot(path, snapshot)
            raise

    if not _registry_entries(_read_registry()):
        stop_proxy_server()
    if reload:
        reload_bouquets()
    return {"profile_key": pkey, "removed": removed}


def unexport_all_live_integrations(reload=True):
    """Remove every plugin-owned dynamic bouquet/EPGImport export."""
    registry = _read_registry(); keys = list(_registry_entries(registry).keys())
    removed=[]; errors=[]
    for pkey in keys:
        try:
            result = unexport_live_integration(pkey, reload=False)
            removed.extend(result.get("removed", []))
        except Exception as exc:
            LOG.warning("Could not remove stale live integration %s: %s", pkey, exc)
            errors.append(pkey)
    if errors:
        raise RuntimeError("Export cleanup incomplete for %d source(s); their registry was retained" % len(errors))
    # Also clean orphaned generated files if registry state was damaged/missing.
    import glob
    patterns = [
        os.path.join(ENIGMA2_DIR, "userbouquet.ultrastalker_*.tv"),
        os.path.join(EPGIMPORT_DIR, "ultrastalker_*.channels.xml"),
        os.path.join(EPGIMPORT_DIR, "ultrastalker_*.sources.xml"),
        os.path.join(CONFIG_DIR, "xmltv_*.xml"),
        os.path.join(_xmltv_cache_dir(), "xmltv_*.xml"),
    ]
    for pattern in patterns:
        for path in glob.glob(pattern):
            try: os.unlink(path); _fsync_parent_dir(path); removed.append(path)
            except OSError: pass
    try: os.unlink(REGISTRY_FILE); _fsync_parent_dir(REGISTRY_FILE)
    except OSError: pass
    bouquet_index=os.path.join(ENIGMA2_DIR,"bouquets.tv")
    try:
        with open(bouquet_index,"r",encoding="utf-8",errors="replace") as handle: lines=handle.read().splitlines()
        filtered=[line for line in lines if "userbouquet.ultrastalker_" not in line]
        if filtered != lines: _atomic_text(bouquet_index,"\n".join(filtered)+"\n",0o644)
    except OSError: pass
    stop_proxy_server()
    if reload: reload_bouquets()
    return {"exports_removed": len(keys), "files_removed": len(set(removed))}



def list_tv_bouquets():
    """Return receiver TV bouquets in the same order as bouquets.tv.

    Each row is a small dict with ``name`` (display label) and ``filename``.
    Only local ``*.tv`` bouquet files referenced by the receiver index are
    returned; malformed/path-traversal entries are ignored.
    """
    index_path=os.path.join(ENIGMA2_DIR,"bouquets.tv")
    try:
        with open(index_path,"r",encoding="utf-8",errors="replace") as handle:
            lines=handle.read().splitlines()
    except OSError:
        return []
    out=[];seen=set()
    for line in lines:
        if 'FROM BOUQUET "' not in line:
            continue
        try:filename=line.split('FROM BOUQUET "',1)[1].split('"',1)[0].strip()
        except Exception:continue
        if not filename or filename in seen or os.path.basename(filename)!=filename or not filename.endswith('.tv'):
            continue
        path=os.path.join(ENIGMA2_DIR,filename)
        if not os.path.isfile(path):
            continue
        label=filename
        try:
            with open(path,"r",encoding="utf-8",errors="replace") as handle:
                first=handle.readline().strip()
            if first.startswith('#NAME '):label=first[6:].strip() or filename
        except OSError:
            pass
        out.append({"name":label,"filename":filename,"path":path});seen.add(filename)
    return out


def _refresh_profile_epg_mapping(profile,pkey,entry,service_type):
    """Refresh the shared EPGImport mapping after Live rows are registered."""
    shared_paths=_bouquet_paths(pkey)
    channels=entry.get("channels") or {}
    token=str(entry.get("proxy_token") or "")
    port=int(entry.get("proxy_port") or _registry_port())
    channel_xml=['<?xml version="1.0" encoding="utf-8"?>','<channels>']
    for ckey,row in channels.items():
        if not isinstance(row,dict) or str(row.get("_receiver_media_type") or "itv").lower()!="itv":
            continue
        ref=_service_ref(_proxy_url(pkey,ckey,port,token),service_type,identity=ckey)
        channel_xml.append('  <channel id="%s">%s</channel>'%(escape(_xmltv_id(pkey,ckey),{'"':'&quot;'}),escape(ref+":"+_receiver_name(row,"itv"))))
    channel_xml.append('</channels>')
    os.makedirs(EPGIMPORT_DIR,mode=0o755,exist_ok=True)
    xmltv_url=_xmltv_url(pkey,port,token)
    source_xml=(
        '<?xml version="1.0" encoding="utf-8"?>\n<sources>\n'
        '  <sourcecat sourcecatname="Ultra Stalker">\n'
        '    <source type="gen_xmltv" nocheck="1" channels="%s">\n'
        '      <description>%s</description>\n      <url>%s</url>\n'
        '    </source>\n  </sourcecat>\n</sources>\n'
    )%(escape(shared_paths["epg_channels"]),escape("Ultra Stalker - "+_safe_name(profile.get("name") or profile.get("portal") or "Portal")),escape(xmltv_url))
    _atomic_text(shared_paths["epg_channels"],"\n".join(channel_xml)+"\n",0o644)
    _atomic_text(shared_paths["epg_source"],source_xml,0o644)
    _ensure_xmltv_placeholder(pkey)


def _epg_candidate_ids(row):
    row=row if isinstance(row,dict) else {}
    out=[]
    preset=row.get("_receiver_epg_candidates")
    if isinstance(preset,(list,tuple)):
        for value in preset:
            value=str(value or "").strip()
            if value and value not in out:out.append(value)
    for key in ("id","ch_id","channel_id","stream_id","epg_id","tvg_id","xmltv_id"):
        value=row.get(key)
        if value in (None,""):continue
        value=str(value).strip()
        if value and value not in out:out.append(value)
    return out


def _live_export_epg_seed(profile, ref_rows):
    """Now/Next seed for a live export. A fetch failure must not roll the bouquet back."""
    global _NATIVE_EPG_LAST_EXPORT_AT
    _NATIVE_EPG_LAST_EXPORT_AT = time.monotonic()
    try:
        hours = max(2, min(12, int(load_settings().get("epg_hours", 4) or 4)))
    except Exception:
        hours = 4
    try:
        return _receiver_epg_seed(profile, ref_rows, hours)
    except Exception as exc:
        LOG.debug("Receiver EPG seed preparation failed: %s", exc)
        return _cached_receiver_epg_seed(profile, ref_rows)


def _export_epg_clock(value):
    """Epoch for MAG guide fields, including HH:MM and local date strings."""
    if value is None or value == "":
        return 0
    if isinstance(value, (int, float)):
        number = int(value)
        return number // 1000 if number >= 100000000000 else number
    raw = str(value).strip()
    try:
        if raw.isdigit():
            number = int(raw)
            return number // 1000 if number >= 100000000000 else number
    except (TypeError, ValueError):
        return 0
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M", "%d-%m-%Y %H:%M", "%H:%M:%S", "%H:%M"):
        try:
            parsed = datetime.datetime.strptime(raw, fmt)
            if fmt.startswith("%H"):
                today = datetime.date.today()
                parsed = parsed.replace(year=today.year, month=today.month, day=today.day)
            return int(time.mktime(parsed.timetuple()))
        except (TypeError, ValueError, OverflowError):
            continue
    return 0


def _export_event_times(row, now=None):
    """Use the same MAG time/time_to priority as the verified R5.334 Live grid."""
    if not isinstance(row, dict):
        return 0, 0
    now = int(time.time() if now is None else now)
    def choose(keys):
        for key in keys:
            stamp = _export_epg_clock(row.get(key))
            if stamp:
                return stamp
        return 0
    start = choose(("time", "start_timestamp", "start", "utc"))
    stop = choose(("time_to", "stop_timestamp", "stop", "end"))
    if stop and start and stop <= start:
        if stop < 86400:  # MAG time_to can be a duration instead of an absolute date.
            stop = start + stop
        elif start - stop < 24 * 3600:  # HH:MM crossed midnight.
            stop += 86400
        else:
            stop = 0
    if not stop and start:
        try:
            duration = int(float(row.get("duration") or row.get("length") or 0))
        except (TypeError, ValueError, OverflowError):
            duration = 0
        stop = start + (duration if 60 <= duration <= 24 * 3600 else 3600)
    if not (start and stop and 0 < stop - start <= 24 * 3600):
        return 0, 0
    # Old time series are not usable as receiver NOW/NEXT despite being nonempty.
    if stop < now - 3 * 3600 or start > now + 7 * 86400:
        return 0, 0
    return start, stop


def _export_epg_pack(rows, now=None):
    """Receiver-safe Now/Next timeline.

    MAG portals can include several competing windows for the very same
    programme (same title, overlapping clocks). Feeding all windows to the
    DVB time map makes event ordering dependent on insertion order, which
    can leave Now empty on some Enigma2 implementations.

    Coalesce overlapping windows of the *same* programme, then trim an
    earlier different programme to the following event's start. We never
    fabricate guide entries or move an event to another service.
    """
    now = int(time.time() if now is None else now)
    raw = []
    for ev in (rows if isinstance(rows, list) else []):
        if not isinstance(ev, dict):
            continue
        start, stop = _export_event_times(ev, now=now)
        if not start:
            continue
        title = _safe_name(ev.get("name") or ev.get("title") or ev.get("descr") or "Programme")
        short = _safe_name(ev.get("descr") or ev.get("description") or "")
        extended = _safe_name(ev.get("description") or ev.get("plot") or ev.get("descr") or "")
        raw.append([int(start), int(stop), title, short, extended])
    raw.sort(key=lambda item: (item[0], item[1], item[2]))
    # Merge overlapping reports of the same programme, including reports
    # separated by a different entry in the unsorted provider payload.
    coalesced = []
    for start, stop, title, short, extended in raw:
        label = " ".join(title.lower().split())
        found = None
        for existing in coalesced:
            if existing[5] == label and start < existing[1] and stop > existing[0]:
                found = existing
                break
        if found is None:
            coalesced.append([start, stop, title, short, extended, label])
        else:
            found[0] = min(found[0], start)
            found[1] = max(found[1], stop)
            if len(short) > len(found[3]):
                found[3] = short
            if len(extended) > len(found[4]):
                found[4] = extended
    coalesced.sort(key=lambda item: (item[0], item[1], item[2]))
    timeline = []
    # Chronological, strictly non-overlapping intervals are what Enigma2's
    # DVB EPG time map expects. Clip older conflicting entries, not their
    # successors; omit entries truncated down to zero.
    for index, item in enumerate(coalesced):
        start, stop, title, short, extended = item[:5]
        if index + 1 < len(coalesced):
            stop = min(stop, coalesced[index + 1][0])
        if stop <= start:
            continue
        timeline.append((int(start), int(stop - start), title, short, extended))
    # Provider event IDs are not always unique within the 16-bit DVB range.
    # Derive stable per-channel EIT IDs from the normalized event identity.
    used_ids = set()
    packed = []
    for start, duration, title, short, extended in timeline:
        event_key = (str(start) + "|" + title).encode("utf-8", "ignore")
        event_id = int(hashlib.sha1(event_key).hexdigest()[:4], 16) or 1
        while event_id in used_ids:
            event_id = (event_id + 1) & 0xFFFF or 1
        used_ids.add(event_id)
        packed.append((start, duration, title, short, extended, event_id))
    return packed


def _export_now_covered(packed, now=None):
    now = int(time.time() if now is None else now)
    return any(event[0] <= now < event[0] + event[1] for event in packed)


def _epg_snapshot_alive(events, now=None):
    """A channel's saved batch belongs to it until its final event ends."""
    now = int(time.time() if now is None else now)
    for ev in events or []:
        try:
            if len(ev) >= 6 and int(ev[1]) > 0 and int(ev[0]) + int(ev[1]) > now:
                return True
        except (TypeError, ValueError, OverflowError):
            continue
    return False


_EPG_LEAD_SECONDS = 20 * 60
_EPG_SOFT_REFRESH_GAP = 10 * 60


def _epg_last_end(events):
    last = 0
    for ev in events or []:
        try:
            last = max(last, int(ev[0]) + int(ev[1]))
        except (TypeError, ValueError, IndexError, OverflowError):
            continue
    return last


def _epg_snapshot_fresh(events, now=None):
    """Batch still covers at least the refresh lead time.

    A batch used to be replaced only after its LAST event had ended, which left
    a visible gap (no NOW/NEXT) until the next sweep reached that channel.
    Refreshing while the batch still has ~20 min left closes that gap.
    """
    now = int(time.time() if now is None else now)
    return _epg_last_end(events) > now + _EPG_LEAD_SECONDS


def _publish_epg_snapshot(profile_key, state):
    # Same profile lock protects cursor state and the export seed from races.
    # Publish XML first: on interruption the previous persistent batch remains.
    entry = (_read_registry() or {}).get(profile_key) or {}
    channels = _live_registry_channels(entry)
    lines = _xmltv_channel_lines(profile_key, channels)
    for key, _row in channels:
        for event in (state.get("programmes") or {}).get(key) or []:
            xml = _compact_event_xml(profile_key, key, event)
            if xml:
                lines.append(xml)
    lines.append("</tv>")
    _atomic_text(_xmltv_cache_path(profile_key), "\n".join(lines) + "\n", 0o600)
    _save_xmltv_state(profile_key, state)


def _cached_receiver_epg_seed(profile, ref_rows):
    key = _profile_key(profile)
    with _XMLTV_LOCKS.setdefault(key, threading.RLock()):
        programmes = _load_xmltv_state(key).get("programmes") or {}
        return [{"service_ref": str(ref), "service_name": _receiver_name(row, "itv"),
                 "events": [tuple(ev) for ev in programmes[_channel_key(row)]]}
                for ref, row in ref_rows if _epg_snapshot_alive(programmes.get(_channel_key(row)))]


def _receiver_epg_seed(profile, ref_rows, hours=4):
    """Export real guide immediately, reuse persisted batches until expiry.

    No first-120-channel cap. Network work is bounded and missing channels
    remain eligible for the background sweep. Nothing fabricates an event.
    """
    jobs = list((str(ref), dict(row)) for ref, row in (ref_rows or [])
            if ref and isinstance(row, dict))
    if not jobs:
        return []
    pkey = _profile_key(profile)
    with _XMLTV_LOCKS.setdefault(pkey, threading.RLock()):
        state = _load_xmltv_state(pkey)
        programmes = state.setdefault("programmes", {})
        now = int(time.time())
        result = {pos: programmes[_channel_key(row)] for pos, (_ref, row) in enumerate(jobs)
                  if _epg_snapshot_alive(programmes.get(_channel_key(row)), now)}
        pending = list(pos for pos in range(len(jobs)) if pos not in result)
        client = None
        changed = False
        cancel = threading.Event()
        timer = threading.Timer(60.0, cancel.set)
        timer.daemon = True
        if pending:
            timer.start()
        try:
            if pending:
                try:
                    client = _client(profile)
                except Exception as exc:
                    LOG.warning("Native EPG client unavailable: %s", exc.__class__.__name__)
            for start in range(0, len(pending), 48):
                if cancel.is_set():
                    break
                unresolved = pending[start:start + 48]
                for tier in range(3):
                    if client is None or not unresolved or cancel.is_set():
                        break
                    lookup = {}
                    for pos in unresolved:
                        ids = _epg_candidate_ids(jobs[pos][1])
                        if tier < len(ids):
                            lookup.setdefault(ids[tier], []).append(pos)
                    if not lookup:
                        continue
                    try:
                        found = client.epg_many(list(lookup), max(10, min(12, int(hours or 10))), cancel_event=cancel) or {}
                    except Exception as exc:
                        LOG.warning("Native EPG fetch tier=%d failed: %s", tier + 1, exc.__class__.__name__)
                        found = {}
                    for cid, positions in lookup.items():
                        packed = _export_epg_pack(found.get(cid), now=now)
                        if not _epg_snapshot_alive(packed, now):
                            continue
                        for pos in positions:
                            previous = result.get(pos)
                            if previous is None or (not _export_now_covered(previous, now) and _export_now_covered(packed, now)):
                                result[pos] = packed
                    unresolved = list(pos for pos in unresolved if not _export_now_covered(result.get(pos) or [], now))
            for pos in pending:
                if pos in result:
                    programmes[_channel_key(jobs[pos][1])] = list(list(ev) for ev in result[pos])
                    changed = True
            if changed:
                state["updated_at"] = int(time.time())
                try:
                    _publish_epg_snapshot(pkey, state)
                except Exception as exc:
                    LOG.warning("Native EPG snapshot persistence failed: %s", exc.__class__.__name__)
        finally:
            timer.cancel()
            if client is not None:
                try:
                    client.close()
                except Exception:
                    pass
        seed = list({"service_ref": ref, "service_name": _receiver_name(row, "itv"),
                 "events": list(tuple(ev) for ev in result[pos])}
                for pos, (ref, row) in enumerate(jobs) if result.get(pos))
        LOG.info("Native EPG snapshot: channels=%d with_guide=%d cached=%d missing=%d",
                 len(jobs), len(seed), len(jobs) - len(pending), len(jobs) - len(seed))
        return seed


def _receiver_epg_ref_variants(service_ref,service_name=""):
    """Return compatible Enigma2 service-reference forms for immediate EPG import."""
    ref=str(service_ref or "").strip()
    if not ref:return []
    out=[]
    def add(value):
        value=str(value or "").strip()
        if value and value not in out:out.append(value)
    add(ref)
    parts=ref.split(":")
    if len(parts)>=10:
        # Some images key IPTV EPG by the DVB identity tuple rather than the
        # URL-bearing 4097 reference. Seed both without changing the bouquet.
        identity=parts[:10]
        add(":".join(identity)+":")
        identity1=list(identity);identity1[0]="1"
        add(":".join(identity1)+":")
    if service_name:
        named=ref+":"+_safe_name(service_name)
        out=[named]+list(value for value in out if value!=named)
    return out


def _receiver_epg_now_present(cache, refs):
    """Read back NOW from the *receiver*, not just the network response.

    None means this image cannot expose a compatible lookup API; do not
    mistake unsupported readback for proof that the import failed.
    """
    try:
        from enigma import eServiceReference
        lookup = getattr(cache, "lookupEventTime", None)
        if not callable(lookup):
            return None
    except Exception:
        return None
    attempted = False
    for value in refs:
        try:
            attempted = True
            event = lookup(eServiceReference(str(value)), -1)
            if event is not None:
                return True
        except Exception:
            continue
    return False if attempted else None


def import_receiver_epg_seed(seed):
    """Best-effort immediate Enigma2 EPG cache import for exported Live rows.

    OpenATV/OpenPLi importEvents treats a *tuple* as one DVB triplet
    (onid, tsid, sid). A tuple of service-reference strings is rejected inside
    C++ without raising, so the old call reported success and stored nothing.
    A list of reference strings is the form that actually lands in the cache.
    Field 6 of each event is the content type; the event id is field 7. Putting
    the id in field 6 makes every programme share event id 0 and only one survives.
    """
    rows=list(row for row in (seed or []) if isinstance(row,dict) and row.get("service_ref") and row.get("events"))
    if not rows:return 0
    try:
        from enigma import eEPGCache
        cache=eEPGCache.getInstance()
    except Exception:
        return 0
    imported=0
    verified=0
    missing_now=[]
    for row in rows:
        events=[]
        for ev in row.get("events") or []:
            if not isinstance(ev,(tuple,list)) or len(ev)<6:continue
            try:
                event_id=int(ev[6] if len(ev)>6 else ev[5]) & 0xFFFF
                events.append((int(ev[0]), int(ev[1]), str(ev[2] or ""), str(ev[3] or ""), str(ev[4] or ""), 0, event_id))
            except Exception:
                continue
        if not events:continue
        refs=_receiver_epg_ref_variants(row.get("service_ref"),row.get("service_name"))
        if not refs:continue
        stored=False
        try:
            cache.importEvents(list(refs), list(events))
            stored=True
        except Exception as exc:
            LOG.debug("Native receiver EPG list import failed refs=%s: %s", refs, exc)
        if not stored:
            for ref_text in refs:
                try:
                    cache.importEvents(str(ref_text), list(events))
                    stored=True
                    break
                except Exception as exc:
                    LOG.debug("Native receiver EPG string import failed ref=%s: %s", ref_text, exc)
        if not stored:
            fallback=getattr(cache,"importEvent",None)
            if callable(fallback):
                for ref_text in refs:
                    try:
                        fallback(str(ref_text), list(events))
                        stored=True
                        break
                    except Exception as exc:
                        LOG.debug("Native receiver legacy EPG import failed ref=%s: %s", ref_text, exc)
        if stored:
            imported+=len(events)
            expected_now = any(event[0] <= time.time() < event[0] + event[1] for event in events)
            if expected_now:
                present = _receiver_epg_now_present(cache, refs)
                if present is False:
                    # Some receiver images silently ignore the combined list.
                    # Retry *one* actual bouquet service ref; never loop on failure.
                    try:
                        cache.importEvents([str(row.get("service_ref"))], list(events))
                    except Exception:
                        pass
                    present = _receiver_epg_now_present(cache, refs)
                if present is True:
                    verified += 1
                elif present is False:
                    missing_now.append(str(row.get("service_name") or "Channel")[:54])
    if rows:
        LOG.info("Native EPG cache readback: channels=%d event_rows=%d verified_now=%d missing_now=%s",
                 len(rows), imported, verified, ", ".join(missing_now[:14]) or "none or unavailable")
    # Enigma2 owns persistence of the EPG cache. Calling cache.save() from the
    # live GUI callback can synchronously flush the entire guide and freeze the
    # receiver (observed spinner regression on the previous EPG builds).
    return imported


def append_receiver_items_to_bouquet(profile,items,media_type,bouquet_filename,service_type=4097,progress=None):
    """Append selected playable rows to one existing receiver TV bouquet.

    Provider URLs are never persisted directly.  As with the plugin's normal
    exports, each service points at the loopback resolver so Stalker/Xtream links
    can be refreshed at tune time. Existing bouquet content is preserved.
    """
    profile=dict(profile or {})
    media_type=str(media_type or "itv").lower()
    if media_type=="movie":media_type="vod"
    if media_type not in ("itv","vod","episode"):
        raise ValueError("Unsupported receiver media type: %s"%media_type)
    filename=str(bouquet_filename or "").strip()
    if not filename or os.path.basename(filename)!=filename or not filename.endswith('.tv'):
        raise ValueError("Invalid bouquet filename")
    bouquet_path=os.path.join(ENIGMA2_DIR,filename)
    if not os.path.isfile(bouquet_path):
        raise ValueError("Receiver bouquet does not exist")
    rows=list(dict(row) for row in (items or []) if isinstance(row,dict) and (row.get("cmd") or row.get("command") or row.get("url")))
    if not rows:raise ValueError("No playable items to export")

    if media_type!="itv":
        total_rows=len(rows)
        for number,row in enumerate(rows,1):
            if not isinstance(row.get("_receiver_metadata"), dict) or not row["_receiver_metadata"]:
                row["_receiver_metadata"]=_prepare_export_metadata(profile,row,media_type)
            if callable(progress):
                try:progress(number,total_rows)
                except Exception:pass

    pkey=_profile_key(profile);shared_paths=_bouquet_paths(pkey)
    touched=[bouquet_path,REGISTRY_FILE]
    if media_type=="itv":touched += [shared_paths["epg_channels"],shared_paths["epg_source"]]
    snapshots={path:_snapshot_file(path) for path in touched}
    old_registry=_read_registry();old_entries=_registry_entries(old_registry);proxy_started_for_export=False
    pending_picons=[];pending_epg=[]
    try:
        with _REGISTRY_LOCK:
            registry=_read_registry();port=_choose_export_port(registry)
            was_running=_SERVER is not None
            start_proxy_server(port=port,require_registry=False,strict=True)
            proxy_started_for_export=not was_running and _SERVER is not None
            entry=dict(registry.get(pkey) or {});channels=dict(entry.get("channels") or {})
            token=str(entry.get("proxy_token") or "") or _new_proxy_token()
            manual=dict(entry.get("manual_exports") or {});saved=list(manual.get(filename) or [])
            try:
                with open(bouquet_path,"r",encoding="utf-8",errors="replace") as handle:
                    bouquet_lines=handle.read().splitlines()
            except OSError:
                bouquet_lines=[]
            if not bouquet_lines:
                bouquet_lines=["#NAME %s"%_safe_name(filename.rsplit('.',1)[0])]
            existing_text="\n".join(bouquet_lines)
            added=0
            for row in rows:
                row["_receiver_media_type"]=media_type
                ckey=_channel_key(row);channels[ckey]=row
                ref=_service_ref(_proxy_url(pkey,ckey,port,token),service_type,identity=ckey)
                name=_receiver_name(row,media_type)
                service_line="#SERVICE %s:%s"%(ref,name)
                # De-duplicate by the stable service reference, not by display name.
                if ("#SERVICE %s:"%ref) not in existing_text:
                    bouquet_lines.append(service_line);bouquet_lines.append("#DESCRIPTION %s"%name)
                    existing_text += "\n"+service_line
                    added += 1
                if ckey not in saved:saved.append(ckey)
                pending_picons.append((ref,row.get("_receiver_picon_local") or row.get("_receiver_picon_source_local"),media_type,name))
                if media_type=="itv":pending_epg.append((ref,dict(row)))
            _atomic_text(bouquet_path,"\n".join(bouquet_lines)+"\n",0o644)
            manual[filename]=saved
            registry["_meta"]={"format":2,"proxy_port":port,"updated_at":int(time.time())}
            registry[pkey]={
                "profile":profile,
                "service_type":int(service_type or entry.get("service_type") or 4097),
                "channels":channels,
                "media_metadata":dict(entry.get("media_metadata") or {}),
                "updated_at":int(time.time()),
                "epg_hours":max(2,min(24,int(load_settings().get("epg_hours",4) or 4))),
                "proxy_port":port,"proxy_token":token,
                "category_exports":dict(entry.get("category_exports") or {}),
                "series_category_exports":dict(entry.get("series_category_exports") or {}),
                "vod_category_exports":dict(entry.get("vod_category_exports") or {}),
                "smart_exports":dict(entry.get("smart_exports") or {}),
                "manual_exports":manual,
            }
            _write_registry(registry)
        picons_published=0;picons_missing=0
        for item in pending_picons:
            ref,picon,row_type=item[0],item[1],item[2]
            channel_name=item[3] if len(item)>3 else ""
            if row_type=="itv":
                if _publish_picon(ref,picon,channel_name):picons_published+=1
                else:picons_missing+=1
            else:
                if _queue_picon_publish(ref,picon,channel_name):picons_published+=1
                else:picons_missing+=1
        epg_seed=[]
        if media_type=="itv":
            _refresh_profile_epg_mapping(profile,pkey,_read_registry().get(pkey) or {},service_type)
            try:epg_seed=_receiver_epg_seed(profile,pending_epg,max(2,min(12,int(load_settings().get("epg_hours",4) or 4))))
            except Exception as exc:LOG.debug("Receiver EPG seed preparation failed: %s",exc)
        else:
            _queue_exported_media_metadata(registry.get(pkey) or {},force=True)
        return {"profile_key":pkey,"items":len(rows),"added":added,"bouquet":bouquet_path,"bouquet_name":filename,
                "epg_seed":epg_seed,"epg_seed_channels":len(epg_seed),"picons_published":picons_published,"picons_missing":picons_missing}
    except Exception:
        for path in reversed(touched):_restore_snapshot(path,snapshots[path])
        if proxy_started_for_export and not old_entries:
            try:stop_proxy_server()
            except Exception as exc:LOG.debug("Manual bouquet rollback proxy stop failed: %s",exc)
        raise

def reload_bouquets():
    try:
        from enigma import eDVBDB
        db = eDVBDB.getInstance()
        db.reloadBouquets()
        try: db.reloadServicelist()
        except Exception: pass
        return True
    except Exception:
        return False


def _xmltv_cache_dir():
    """R5.152: the generated guide is rewritten about hourly - keep it off the flash.

    HDD when mounted and writable, otherwise RAM (/tmp); it is regenerated on demand.
    """
    for base in ("/media/hdd", "/media/usb"):
        try:
            if os.path.ismount(base) and os.access(base, os.W_OK):
                path = os.path.join(base, "UltraStalker", "xmltv")
                os.makedirs(path, mode=0o700, exist_ok=True)
                return path
        except Exception:
            pass
    path = os.path.join("/tmp", "ultrastalker", "xmltv")
    try:
        os.makedirs(path, mode=0o700, exist_ok=True)
    except Exception:
        pass
    return path


def _xmltv_cache_path(profile_key):
    legacy = os.path.join(CONFIG_DIR, "xmltv_%s.xml" % profile_key)
    try:
        if os.path.isfile(legacy):
            os.unlink(legacy)
    except Exception:
        pass
    return os.path.join(_xmltv_cache_dir(), "xmltv_%s.xml" % profile_key)


def _xmltv_channel_lines(profile_key, channels):
    lines = ['<?xml version="1.0" encoding="utf-8"?>', '<tv generator-info-name="UltraStalker">']
    for ckey, channel in channels:
        name = _safe_name(channel.get("name") or channel.get("title") or "Channel")
        cid = _xmltv_id(profile_key, ckey)
        lines.append('  <channel id="%s"><display-name>%s</display-name></channel>' % (escape(cid, {'"': '&quot;'}), escape(name)))
    return lines


def _ensure_xmltv_placeholder(profile_key):
    cache = _xmltv_cache_path(profile_key)
    try:
        if os.path.getsize(cache) > 100:
            return cache
    except OSError:
        pass
    entry = _read_registry().get(profile_key) or {}
    live = _live_registry_channels(entry)
    with _XMLTV_LOCKS.setdefault(profile_key, threading.RLock()):
        state = _load_xmltv_state(profile_key)
        if state.get("programmes"):
            _publish_epg_snapshot(profile_key, state)
            return cache
    channels = live
    lines = _xmltv_channel_lines(profile_key, channels)
    lines.append("</tv>")
    _atomic_text(cache, "\n".join(lines) + "\n", 0o600)
    return cache


def _event_xml(profile_key, channel_key, row):
    start, stop = event_times(row)
    if not start:
        return ""
    if not stop:
        stop = start + max(60, int(row.get("duration") or 3600))
    channel_id = _xmltv_id(profile_key, channel_key)
    start_text = time.strftime("%Y%m%d%H%M%S %z", time.localtime(start))
    stop_text = time.strftime("%Y%m%d%H%M%S %z", time.localtime(stop))
    title = _safe_name(row.get("name") or row.get("title") or row.get("descr") or "Programme")
    desc = _safe_name(row.get("description") or row.get("descr") or row.get("plot") or "")
    parts = ['  <programme start="%s" stop="%s" channel="%s">' % (start_text, stop_text, escape(channel_id))]
    parts.append("    <title>%s</title>" % escape(title))
    if desc and desc != title:
        parts.append("    <desc>%s</desc>" % escape(desc))
    parts.append("  </programme>")
    return "\n".join(parts)


def _epg_worker(profile, work, hours, deadline, cancel_event=None, clients=None, clients_lock=None, frozen_keys=None):
    if all(key in (frozen_keys or ()) for key, _row in work):
        return [], len(work)
    client = _client(profile)
    if clients is not None:
        lock = clients_lock or _XMLTV_REFRESH_LOCK
        with lock: clients.add(client)
    out = []
    consumed = 0
    try:
        for ckey, channel in work:
            if (cancel_event is not None and cancel_event.is_set()) or time.monotonic() >= deadline: break
            consumed += 1
            if ckey in (frozen_keys or ()):
                continue
            ids=_epg_candidate_ids(channel)
            if not ids:continue
            rows=None
            for cid in ids:
                try:rows=client.epg(cid,hours,cancel_event=cancel_event,use_cache=False)
                except Exception as exc:
                    if not (cancel_event is not None and cancel_event.is_set()):LOG.debug("EPG channel refresh failed channel=%s: %s",cid,exc)
                    rows=None
                    low=str(exc).lower()
                    if "429" in low or "rate limit" in low or "throttl" in low or "too many" in low:
                        # R5.64: back off only when the portal is throttling us.
                        if cancel_event is not None:cancel_event.wait(2.0)
                        else:time.sleep(2.0)
                if rows:
                    returned = {str(ev.get("ch_id")) for ev in rows if isinstance(ev, dict) and ev.get("ch_id") not in (None, "", 0, "0")}
                    if returned and returned != {str(cid)}:
                        rows = None
                    elif _epg_snapshot_alive(_compact_epg_rows(rows)):
                        break
                if (cancel_event is not None and cancel_event.is_set()) or time.monotonic() >= deadline:break
            if rows is not None:out.append((ckey,rows))
        return out, consumed
    finally:
        if clients is not None:
            lock = clients_lock or _XMLTV_REFRESH_LOCK
            with lock: clients.discard(client)
        try: client.close()
        except Exception as exc: LOG.debug("EPG worker client close failed: %s", exc)


def _live_registry_channels(entry):
    """Live rows only, in registry order. VOD and episodes are not an EPG source."""
    out = []
    channels = (entry or {}).get("channels") or {}
    if not isinstance(channels, dict):
        return out
    for ckey, row in channels.items():
        if not isinstance(row, dict):
            continue
        if str(row.get("_receiver_media_type") or "itv").lower() != "itv":
            continue
        out.append((str(ckey), row))
    return out


def _installed_live_bouquet_rows(profile_key, entry, limit=None):
    """Read receiver's actual exported service references, without rewriting bouquets.

    Only registered Live identities count. Scan only UltraStalker files for this
    profile and only short text service lines, not playlists or network URLs.
    """
    channels = dict((entry or {}).get("channels") or {})
    if not channels:
        return []
    found = {}
    prefix = "userbouquet.ultrastalker_%s" % profile_key
    try:
        names = sorted(os.listdir(ENIGMA2_DIR))
    except OSError:
        return []
    for name in names:
        if not name.startswith(prefix) or not name.endswith(".tv") or "vodcat_" in name or "series" in name:
            continue
        try:
            with open(os.path.join(ENIGMA2_DIR, name), "r", encoding="utf-8", errors="replace") as fh:
                for index, raw in enumerate(fh):
                    if limit is not None and len(found) >= limit:
                        break
                    if not raw.startswith("#SERVICE "):
                        continue
                    service = raw[len("#SERVICE "):].strip()
                    fields = service.split(":", 11)
                    if len(fields) < 11:
                        continue
                    ref = ":".join(fields[:11])
                    decoded = urllib.parse.unquote(fields[10])
                    marker = "/%s/" % profile_key
                    if marker not in decoded:
                        continue
                    key = decoded.split(marker, 1)[1].split("/", 1)[0].split("?", 1)[0]
                    row = channels.get(key)
                    if not isinstance(row, dict) or str(row.get("_receiver_media_type") or "itv").lower() != "itv":
                        continue
                    found.setdefault(key, (ref, dict(row)))
        except OSError:
            continue
        if limit is not None and len(found) >= limit:
            break
    return list(found.values())


def _xmltv_state_path(profile_key):
    return os.path.join(_xmltv_cache_dir(), "xmltv_%s.state.json" % profile_key)


def _load_xmltv_state(profile_key):
    try:
        with open(_xmltv_state_path(profile_key), "r", encoding="utf-8") as handle:
            data = json.load(handle)
        if isinstance(data, dict):
            programmes = data.get("programmes")
            data["programmes"] = programmes if isinstance(programmes, dict) else {}
            return data
    except Exception:
        pass
    return {"cursor": 0, "programmes": {}}


def _save_xmltv_state(profile_key, state):
    _atomic_text(_xmltv_state_path(profile_key), json.dumps(state, ensure_ascii=False), 0o600)


def _epg_safe_prefix(consumed, workers, window_len):
    """How far a strided fetch got with no holes. A later slot must not skip a miss."""
    done = set()
    width = max(1, int(workers or 1))
    for worker_index, count in enumerate(consumed or []):
        for step in range(max(0, int(count or 0))):
            index = step * width + worker_index
            if index < window_len:
                done.add(index)
    prefix = 0
    while prefix in done:
        prefix += 1
    return prefix


def _compact_epg_rows(events):
    return [list(event) for event in _export_epg_pack(events)]


def _compact_event_xml(profile_key, channel_key, ev):
    try:
        start, duration, title, short, extended = int(ev[0]), int(ev[1]), ev[2], ev[3], ev[4]
    except Exception:
        return ""
    if start <= 0 or duration <= 0:
        return ""
    channel_id = _xmltv_id(profile_key, channel_key)
    start_text = time.strftime("%Y%m%d%H%M%S %z", time.localtime(start))
    stop_text = time.strftime("%Y%m%d%H%M%S %z", time.localtime(start + duration))
    title = _safe_name(title or "Programme")
    desc = _safe_name(extended or short or "")
    parts = ['  <programme start="%s" stop="%s" channel="%s">' % (start_text, stop_text, escape(channel_id))]
    parts.append("    <title>%s</title>" % escape(title))
    if desc and desc != title:
        parts.append("    <desc>%s</desc>" % escape(desc))
    parts.append("  </programme>")
    return "\n".join(parts)


def _queue_receiver_epg_seed(seed):
    """Import Now/Next on Enigma2's main thread. The network sweep must not touch eEPGCache."""
    rows = [row for row in (seed or []) if isinstance(row, dict) and row.get("events")]
    if not rows:
        return
    try:
        from twisted.internet import reactor
    except Exception as exc:
        LOG.debug("Receiver EPG import skipped; reactor unavailable: %s", exc)
        return

    def run(chunk):
        try:
            import_receiver_epg_seed(chunk)
        except Exception as exc:
            LOG.debug("Receiver EPG background import failed: %s", exc)

    def step(index=0):
        run(rows[index:index + 8])
        if index + 8 < len(rows):
            reactor.callLater(0.03, step, index + 8)
    try:
        reactor.callFromThread(step)
    except Exception as exc:
        LOG.debug("Receiver EPG import schedule failed: %s", exc)


def generate_xmltv(profile_key, force=False, max_seconds=None, cancel_event=None, active_clients=None, active_clients_lock=None):
    registry = _read_registry(); entry = registry.get(profile_key) if isinstance(registry, dict) else None
    if not isinstance(entry, dict) or not isinstance(entry.get("channels"), dict): raise ValueError("Unknown Stalker bouquet")
    cache = _xmltv_cache_path(profile_key)
    if not force:
        try:
            if os.path.getsize(cache) > 100 and time.time() - os.path.getmtime(cache) < _XMLTV_TTL:
                return {"cache": cache, "wrapped": True, "advanced": 0}
        except OSError: pass
    lock = _XMLTV_LOCKS.setdefault(profile_key, threading.RLock())
    with lock:
        # An export may have extended the registry while this sweep waited.
        entry = (_read_registry() or {}).get(profile_key)
        if not isinstance(entry, dict) or not isinstance(entry.get("channels"), dict):
            raise ValueError("Unknown Stalker bouquet")
        if not force:
            try:
                if os.path.getsize(cache) > 100 and time.time() - os.path.getmtime(cache) < _XMLTV_TTL:
                    return {"cache": cache, "wrapped": True, "advanced": 0}
            except OSError: pass
        cancel_event = cancel_event or threading.Event()
        profile = entry.get("profile") or {}
        live_channels = _live_registry_channels(entry)
        # Registry is authoritative; a truncated file scan must never erase guide rows.
        total = len(live_channels)
        if not total:
            return {"cache": cache, "wrapped": True, "advanced": 0, "cursor": 0, "total": 0}
        state = _load_xmltv_state(profile_key)
        sig = hashlib.sha1("\n".join(ckey for ckey, _row in live_channels).encode("utf-8", "ignore")).hexdigest()[:16]
        programmes = {}
        live_keys = {key for key, _row in live_channels}
        for ckey, packed in (state.get("programmes") or {}).items():
            if ckey in live_keys and isinstance(packed, list) and packed:
                programmes[str(ckey)] = packed
        if state.get("sig") != sig:
            cursor = 0
        else:
            try: cursor = int(state.get("cursor") or 0)
            except (TypeError, ValueError): cursor = 0
        if cursor < 0 or cursor >= total:
            cursor = 0
        window = live_channels[cursor:]
        frozen = {key for key, _row in window if _epg_snapshot_fresh(programmes.get(key))}
        hours = 12
        if max_seconds is None:
            try: max_seconds = int(load_settings().get("epg_refresh_budget", _XMLTV_DEFAULT_BUDGET) or _XMLTV_DEFAULT_BUDGET)
            except (TypeError, ValueError): max_seconds = _XMLTV_DEFAULT_BUDGET
        max_seconds = max(10, min(20, int(max_seconds))); deadline = time.monotonic() + max_seconds
        _plow = str(profile.get("portal") or "").lower()
        _is_xt = str(profile.get("source_type") or "").strip().lower() == "m3u" or "get.php" in _plow or ".m3u" in _plow or "output=m3u" in _plow
        # Xtream panels commonly allow one connection: one EPG worker only.
        workers = 1 if _is_xt else min(3, max(1, len(window))); chunks = list(window[index::workers] for index in range(workers))
        results = []; result_lock = threading.Lock(); threads = []; consumed = [0] * workers
        clients = active_clients if active_clients is not None else set(); clients_lock = active_clients_lock or threading.RLock()
        def run_chunk(index, chunk):
            try:
                rows, count = _epg_worker(profile, chunk, hours, deadline, cancel_event, clients, clients_lock, frozen_keys=frozen)
                with result_lock:
                    results.extend(rows)
                    consumed[index] = count
            except Exception as exc:
                if not cancel_event.is_set(): LOG.warning("EPG worker failed profile=%s: %s", profile_key, exc)
        for index, chunk in enumerate(chunks):
            if not chunk: continue
            thread = threading.Thread(target=run_chunk, args=(index, chunk), name="stalker-epg-worker-%d" % index, daemon=True)
            thread.start(); threads.append(thread)
        for thread in threads:
            remaining = deadline - time.monotonic()
            if remaining <= 0: break
            thread.join(remaining)
        alive = list(thread for thread in threads if thread.is_alive())
        if alive:
            cancel_event.set()
            with clients_lock: open_clients = list(clients)
            for client in open_clients:
                try: client.cancel_pending_requests()
                except Exception as exc: LOG.debug("EPG client cancellation failed: %s", exc)
            grace_deadline = time.monotonic() + 3.0
            for thread in alive:
                remaining = grace_deadline - time.monotonic()
                if remaining <= 0: break
                thread.join(remaining)
            still_threads = list(thread for thread in threads if thread.is_alive())
            if still_threads:
                LOG.warning("EPG workers exceeded cancellation grace; abandoning this generation without blocking forever: %s", ",".join(thread.name for thread in still_threads))
                final_deadline=time.monotonic()+2.0
                for thread in still_threads:
                    remaining=final_deadline-time.monotonic()
                    if remaining<=0:break
                    thread.join(remaining)
                still_threads=list(thread for thread in still_threads if thread.is_alive())
                if still_threads:
                    LOG.error("EPG workers abandoned after bounded shutdown: %s", ",".join(thread.name for thread in still_threads))
                    with _XMLTV_REFRESH_LOCK:
                        _XMLTV_ORPHANS[profile_key] = {
                            "threads": list(still_threads),
                            "cancel": cancel_event,
                            "clients": clients,
                            "clients_lock": clients_lock,
                            "since": time.monotonic(),
                        }
        with result_lock:
            completed_results = list(results)
            prefix = _epg_safe_prefix(consumed, workers, len(window))
        if prefix <= 0:
            LOG.info("XMLTV sweep made no progress profile=%s cursor=%d/%d", profile_key, cursor, total)
            return {"cache": cache, "wrapped": False, "advanced": 0, "cursor": cursor, "total": total}
        index_of = {ckey: index for index, (ckey, _row) in enumerate(live_channels)}
        channel_by_key = {ckey: row for ckey, row in live_channels}
        updated = []
        limit = cursor + prefix
        for ckey, events in completed_results:
            pos = index_of.get(ckey)
            if pos is None or pos < cursor or pos >= limit:
                continue
            compact = _compact_epg_rows(events)
            previous = programmes.get(ckey)
            if not _epg_snapshot_alive(compact) or _epg_snapshot_fresh(previous):
                continue
            if _epg_snapshot_alive(previous) and _epg_last_end(compact) <= _epg_last_end(previous):
                continue
            programmes[ckey] = compact
            updated.append(ckey)
        new_cursor = limit
        wrapped = new_cursor >= total
        if wrapped:
            new_cursor = 0
        state = {"cursor": new_cursor, "sig": sig, "programmes": programmes, "updated_at": int(time.time())}
        lines = _xmltv_channel_lines(profile_key, live_channels)
        events_written = 0
        for ckey, _row in live_channels:
            for ev in programmes.get(ckey) or []:
                xml = _compact_event_xml(profile_key, ckey, ev)
                if xml:
                    lines.append(xml); events_written += 1
        if events_written == 0:
            try:
                if os.path.getsize(cache) > 100:
                    with open(cache, "rb") as handle:
                        if b"<programme" in handle.read(262144):
                            LOG.warning("XMLTV refresh produced no events; keeping previous guide %s", cache)
                            return {"cache": cache, "wrapped": wrapped, "advanced": prefix, "cursor": new_cursor, "total": total}
            except OSError:
                pass
        lines.append("</tv>"); _atomic_text(cache, "\n".join(lines) + "\n", 0o600)
        _save_xmltv_state(profile_key, state)
        seed = []
        try:
            port = int(entry.get("proxy_port") or 0) or _registry_port()
        except (TypeError, ValueError):
            port = _registry_port()
        token = str(entry.get("proxy_token") or "")
        try:
            service_type = int(entry.get("service_type") or 4097)
        except (TypeError, ValueError):
            service_type = 4097
        for ckey in updated:
            ref = _service_ref(_proxy_url(profile_key, ckey, port, token), service_type, identity=ckey)
            seed.append({
                "service_ref": ref,
                "service_name": _receiver_name(channel_by_key.get(ckey), "itv"),
                "events": list(tuple(ev) for ev in programmes.get(ckey) or []),
            })
        _queue_receiver_epg_seed(seed)
        LOG.info("XMLTV sweep profile=%s cursor=%d/%d stored=%d new=%d wrapped=%s", profile_key, limit, total, len(programmes), len(updated), wrapped)
        return {"cache": cache, "wrapped": wrapped, "advanced": prefix, "cursor": new_cursor, "total": total}


def _orphan_threads(state):
    if isinstance(state, dict):
        return list(state.get("threads") or ())
    return list(state or ())


def _reap_xmltv_orphans_locked():
    alive_total = 0
    for profile_key, state in list(_XMLTV_ORPHANS.items()):
        alive = [thread for thread in _orphan_threads(state) if thread.is_alive()]
        if not alive:
            _XMLTV_ORPHANS.pop(profile_key, None)
            continue
        alive_total += len(alive)
        if isinstance(state, dict):
            state["threads"] = alive
        else:
            _XMLTV_ORPHANS[profile_key] = {"threads": alive, "cancel": None, "clients": set(), "clients_lock": threading.RLock(), "since": time.monotonic()}
    return alive_total


def _cancel_xmltv_state(state):
    if not isinstance(state, dict):
        return
    cancel_event = state.get("cancel")
    if cancel_event is not None:
        cancel_event.set()
    clients_lock = state.get("clients_lock") or _XMLTV_REFRESH_LOCK
    try:
        with clients_lock:
            clients = list(state.get("clients") or ())
    except Exception as exc:
        LOG.debug("XMLTV cancellation client snapshot failed: %s", exc)
        clients = []
    for client in clients:
        try: client.cancel_pending_requests()
        except Exception as exc: LOG.debug("XMLTV client cancellation failed: %s", exc)


def refresh_xmltv_async(profile_key, force=True):
    if _XMLTV_PAUSED.is_set(): return False
    with _XMLTV_REFRESH_LOCK:
        orphan_total = _reap_xmltv_orphans_locked()
        own_orphans = _orphan_threads(_XMLTV_ORPHANS.get(profile_key, ()))
        if own_orphans:
            return False
        if orphan_total >= _XMLTV_ORPHAN_MAX_THREADS:
            LOG.warning("XMLTV refresh suppressed: orphan worker cap reached (%d)", orphan_total)
            return False
        if profile_key in _XMLTV_REFRESHING: return False
        _XMLTV_REFRESHING.add(profile_key)
        cancel_event = threading.Event(); clients = set(); clients_lock = threading.RLock()
        state = {"thread": None, "cancel": cancel_event, "clients": clients, "clients_lock": clients_lock}
        _XMLTV_ACTIVE[profile_key] = state
    def worker():
        again = False
        try:
            status = generate_xmltv(profile_key, force=force, cancel_event=cancel_event, active_clients=clients, active_clients_lock=clients_lock)
            again = isinstance(status, dict) and int(status.get("advanced") or 0) > 0 and not status.get("wrapped")
        except Exception as exc:
            if not cancel_event.is_set(): LOG.warning("XMLTV refresh failed profile=%s: %s", profile_key, exc)
        finally:
            with _XMLTV_REFRESH_LOCK:
                _XMLTV_REFRESHING.discard(profile_key); _XMLTV_ACTIVE.pop(profile_key, None)
        # Never spin up back-to-back network sweeps; leave the remaining rows
        # to the normal 15-minute manager cadence, without starving the GUI.
        if again:
            LOG.info("XMLTV sweep paused until next manager tick profile=%s", profile_key)
    thread = threading.Thread(target=worker, name="stalker-epg-%s" % profile_key[:6], daemon=True)
    state["thread"] = thread; thread.start(); return True


def pause_xmltv_refreshes(wait=True, timeout=8.0):
    _XMLTV_PAUSED.set()
    with _XMLTV_REFRESH_LOCK:
        _reap_xmltv_orphans_locked()
        states = list(_XMLTV_ACTIVE.values())
        orphan_states = list(state for state in _XMLTV_ORPHANS.values() if isinstance(state, dict))
    for state in states + orphan_states:
        _cancel_xmltv_state(state)
    if wait:
        deadline = time.monotonic() + max(0.0, float(timeout or 0.0))
        threads = []
        for state in states:
            thread = state.get("thread")
            if thread is not None: threads.append(thread)
        for state in orphan_states:
            threads.extend(_orphan_threads(state))
        seen = set()
        for thread in threads:
            marker = id(thread)
            if marker in seen or not thread.is_alive(): continue
            seen.add(marker)
            remaining = deadline - time.monotonic()
            if remaining <= 0: break
            thread.join(remaining)
    with _XMLTV_REFRESH_LOCK:
        _reap_xmltv_orphans_locked()
        active_alive = any((state.get("thread") is not None and state["thread"].is_alive()) for state in _XMLTV_ACTIVE.values())
        orphan_alive = any(_orphan_threads(state) for state in _XMLTV_ORPHANS.values())
        return not active_alive and not orphan_alive


def resume_xmltv_refreshes():
    us_clear(_XMLTV_PAUSED)


def _xmltv_for_http(profile_key):
    entry = _read_registry().get(profile_key) or {}
    if not isinstance(entry, dict) or not isinstance(entry.get("channels"), dict):
        raise ValueError("Unknown Stalker bouquet")
    cache = _ensure_xmltv_placeholder(profile_key)
    try:
        age = time.time() - os.path.getmtime(cache)
    except OSError:
        age = _XMLTV_TTL + 1
    if age >= _XMLTV_TTL:
        refresh_xmltv_async(profile_key, force=True)
    return cache


_MEDIA_METADATA_DAYS = {}
_MEDIA_METADATA_PENDING = {}
_MEDIA_METADATA_WAITING = {}
_MEDIA_METADATA_LOCK = threading.RLock()


def _series_epg_parents(entry):
    """Native EPG pointers for managed series, with no disk/network access."""
    channels = entry.get("channels") or {}
    parents = {}
    for export in (entry.get("series_category_exports") or {}).values():
        for child in export.get("children") or []:
            key = child.get("launcher_key")
            launcher = channels.get(key) or {}
            hierarchy = launcher.get("_receiver_series_launcher") or {}
            if not key or not hierarchy:continue
            for season in hierarchy.get("seasons") or []:
                for ep_key in season.get("episode_keys") or []:parents[ep_key] = key
    return parents


def _series_info_seed(pairs, entry, now=None):
    """One series payload, shared with its distinct native episode services.

    Keep R419's episode identities for native navigation. Only lightweight
    reference strings are added; metadata preparation is performed for the
    parent once. Native importEvents builds the descriptors once per group.
    Bound groups so a large series cannot monopolize the GUI import queue.
    """
    parents = _series_epg_parents(entry)
    profile = entry.get("profile") or {}
    pkey = _profile_key(profile)
    port = entry.get("proxy_port") or _registry_port()
    token = entry.get("proxy_token") or ""
    engine = entry.get("service_type") or 4097
    aliases = {}
    for episode, parent in parents.items():
        parent_ref = _service_ref(_proxy_url(pkey,parent,port,token),engine,identity=parent)
        episode_ref = _service_ref(_proxy_url(pkey,episode,port,token),engine,identity=episode)
        aliases.setdefault(parent_ref,[]).append(episode_ref)
    result = []
    for row in _media_metadata_seed(pairs,now):
        refs = [row["service_ref"]] + aliases.get(row["service_ref"],[])
        if len(refs) == 1:
            result.append(row)
            continue
        for offset in range(0,len(refs),64):
            batch = refs[offset:offset+64]
            result.append(dict(row,service_ref=batch[0],service_refs=batch))
    return result


_CATEGORY_METADATA_EXECUTOR = ThreadPoolExecutor(max_workers=2, thread_name_prefix="ultrastalker-folder-info")
_CATEGORY_METADATA_ACTIVE = set()
_CATEGORY_METADATA_AGAIN = set()
_CATEGORY_METADATA_GUARD = threading.Lock()


def _queue_category_metadata_refresh(pkey, channel_keys=None):
    """Hydrate incomplete folder text after commit; never block the export UI.

    One job per shared series metadata record, bounded to two profile workers.
    Registry writes merge into a fresh snapshot under its existing lock, so a
    subsequent export or unexport cannot be overwritten by a stale snapshot.
    """
    with _CATEGORY_METADATA_GUARD:
        if pkey in _CATEGORY_METADATA_ACTIVE:
            _CATEGORY_METADATA_AGAIN.add(pkey)
            return
        _CATEGORY_METADATA_ACTIVE.add(pkey)

    def work():
        try:
            entry = (_read_registry() or {}).get(pkey) or {}
            profile = entry.get("profile") or {}
            jobs = {}
            for key, row in (entry.get("channels") or {}).items():
                if channel_keys is not None and key not in selected_keys:continue
                if not isinstance(row, dict):continue
                kind = row.get("_receiver_media_type") or ""
                if kind not in ("vod","movie","episode","series"):continue
                mk = row.get("_receiver_metadata_key")
                md = row.get("_receiver_metadata") or (entry.get("media_metadata") or {}).get(mk) or {}
                if md.get("description") and md.get("summary"):continue
                jobs.setdefault((bool(mk),mk or key),(md.get("_source_item") or row,md.get("_media_type") or kind,md.get("season_count") or 0))
            updates = {}

            def flush():
                if not updates:return
                with _REGISTRY_LOCK:
                    registry = _read_registry()
                    current = registry.get(pkey)
                    if not isinstance(current,dict):us_clear(updates);return
                    channels = current.get("channels") or {}
                    records = current.setdefault("media_metadata",{})
                    affected = {}
                    for (shared,key),fresh in updates.items():
                        if shared:
                            if key not in records:continue
                            existing = records[key]
                        else:
                            if key not in channels:continue
                            existing = channels[key].get("_receiver_metadata") or {}
                        merged = dict(fresh)
                        merged.update({k:v for k,v in existing.items() if v not in (None,"",[],{}) and k!="summary"})
                        merged["summary"] = _media_metadata_fields(merged,{},merged.get("_media_type") or "vod",merged.get("season_count") or 0)["summary"]
                        if shared:records[key] = merged
                        else:channels[key]["_receiver_metadata"] = merged
                        for ckey,row in channels.items():
                            if (shared and row.get("_receiver_metadata_key")==key) or (not shared and ckey==key):affected[ckey]=row
                    _write_registry(registry)
                    # Only seed changed rows, without marking a partial batch as
                    # the whole profile's verified daily import.
                    pairs=[]
                    parents = _series_epg_parents(current)
                    for key,row in affected.items():
                        if key in parents:continue
                        md=row.get("_receiver_metadata") or records.get(row.get("_receiver_metadata_key")) or {}
                        ref=_service_ref(_proxy_url(pkey,key,current.get("proxy_port") or _registry_port(),current.get("proxy_token") or ""),current.get("service_type") or 4097,identity=key)
                        pairs.append((ref,dict(row,_receiver_metadata=md)))
                pairs.sort(key=lambda pair:pair[1].get("_receiver_media_type") != "series")
                _queue_receiver_media_seed(_series_info_seed(pairs,current),pkey,None)
                us_clear(updates)

            for identity,(source,kind,seasons) in jobs.items():
                if _EPG_MANAGER_STOP.is_set():break
                try:
                    fresh = _prepare_export_metadata(profile,source,kind,seasons)
                    if fresh.get("description") or fresh.get("summary"):updates[identity]=fresh
                    if len(updates)>=16:flush()
                except Exception as exc:LOG.debug("Folder information unavailable: %s",exc.__class__.__name__)
            flush()
        except Exception as exc:LOG.warning("Folder information background update failed: %s",exc.__class__.__name__)
        finally:
            with _CATEGORY_METADATA_GUARD:
                _CATEGORY_METADATA_ACTIVE.discard(pkey)
                again=pkey in _CATEGORY_METADATA_AGAIN
                _CATEGORY_METADATA_AGAIN.discard(pkey)
            if again:_queue_category_metadata_refresh(pkey)
    selected_keys = set(channel_keys) if channel_keys is not None else None
    try:_CATEGORY_METADATA_EXECUTOR.submit(work)
    except Exception:
        with _CATEGORY_METADATA_GUARD:_CATEGORY_METADATA_ACTIVE.discard(pkey)
        raise


def _queue_exported_media_metadata(entry, force=False):
    try:
        profile = entry.get("profile") or {}
        pkey = _profile_key(profile)
        now = int(time.time())
        signature = (now // 86400, int(entry.get("updated_at") or 0))
        with _MEDIA_METADATA_LOCK:
            if pkey in _MEDIA_METADATA_PENDING and not force: return []
            if not force and _MEDIA_METADATA_DAYS.get(pkey) == signature: return []
        port = int(entry.get("proxy_port") or _registry_port())
        token = str(entry.get("proxy_token") or "")
        service_type = int(entry.get("service_type") or 4097)
        pairs = []
        refreshed = {}
        parents = _series_epg_parents(entry)
        for key, row in (entry.get("channels") or {}).items():
            if key in parents:continue
            if not isinstance(row, dict): continue
            kind = str(row.get("_receiver_media_type") or "").lower()
            if kind not in ("vod","movie","episode","series"):continue
            metadata_key = row.get("_receiver_metadata_key")
            metadata = row.get("_receiver_metadata") or (entry.get("media_metadata") or {}).get(metadata_key) or {}
            if not isinstance(metadata,dict):metadata={}
            if not metadata.get("description") or not metadata.get("summary"):
                # All reads stay in the export worker. Never ask providers
                # or TMDb while ChannelSelection paints an EPG row.
                cache_key = metadata_key or key
                if cache_key not in refreshed:
                    source = metadata.get("_source_item") or row
                    fresh = _prepare_media_metadata(profile,source,metadata.get("_media_type") or kind,metadata.get("season_count") or 0)
                    refreshed[cache_key] = dict(metadata, **{k:v for k,v in fresh.items() if v not in (None,"",[],{})})
                metadata = refreshed[cache_key]
            row = dict(row,_receiver_metadata=metadata)
            ref = _service_ref(_proxy_url(pkey,key,port,token),service_type,identity=key)
            pairs.append((ref,row))
        pairs.sort(key=lambda pair:pair[1].get("_receiver_media_type") != "series")
        rows = _series_info_seed(pairs,entry,now)
        _queue_receiver_media_seed(rows,pkey,signature)
        LOG.info("Export media metadata: rows=%d missing_text=%d",len(rows),len(pairs)-len(rows))
        return rows
    except Exception as exc:
        LOG.debug("Receiver media information import skipped: %s",exc.__class__.__name__)
        return []


def _queue_receiver_media_seed(rows,pkey,signature):
    if not rows:return
    rows = list(rows)
    try:
        from twisted.internet import reactor
        from .export_media_epg import import_media_rows
    except Exception as exc:
        LOG.warning("Media EPG import unavailable: %s",exc.__class__.__name__);return
    with _MEDIA_METADATA_LOCK:
        pending = _MEDIA_METADATA_PENDING.get(pkey)
        if pending is not None:
            # Identical boot snapshots coalesce. New exports and hydrated text
            # must wait, rather than disappear while another batch is importing.
            if pending["rows"] == rows and pending["signature"] == signature:return
            waiting = _MEDIA_METADATA_WAITING.setdefault(pkey,{"rows":{},"signature":signature})
            for row in rows:waiting["rows"][row["service_ref"]] = row
            waiting["signature"] = signature
            return
        _MEDIA_METADATA_PENDING[pkey] = {"rows":rows,"signature":signature}
    accepted=[0]
    def finish(success=False):
        with _MEDIA_METADATA_LOCK:
            finished = _MEDIA_METADATA_PENDING.pop(pkey,None)
            if success:_MEDIA_METADATA_DAYS[pkey]=(finished or {}).get("signature")
            waiting = _MEDIA_METADATA_WAITING.pop(pkey,None)
        if waiting:
            _queue_receiver_media_seed(list(waiting["rows"].values()),pkey,waiting["signature"])
    def step(index=0):
        waiting = None
        try:
            # A new category/hydrated plot must not wait behind thousands of
            # old episode checks. Splice it before the next small native batch,
            # replacing stale pending versions of the same service reference.
            with _MEDIA_METADATA_LOCK:
                waiting = _MEDIA_METADATA_WAITING.pop(pkey,None)
                if waiting:
                    newest = waiting["rows"]
                    remaining = list(row for row in rows[index:] if row["service_ref"] not in newest)
                    rows[index:] = list(newest.values()) + remaining
                    _MEDIA_METADATA_PENDING[pkey]["signature"] = None
            # Native EPG imports execute on Enigma's GUI thread. Small batches
            # leave input and painting time between imports, even for big folders.
            accepted[0]+=import_media_rows(rows[index:index+2],LOG,primary_import=import_receiver_epg_seed)
            if index+2<len(rows):reactor.callLater(0.08,step,index+2)
            else:finish(accepted[0]==len(rows))
        except Exception as exc:
            if waiting:
                with _MEDIA_METADATA_LOCK:
                    recovery = _MEDIA_METADATA_WAITING.setdefault(pkey,{"rows":{},"signature":None})
                    for ref,row in waiting["rows"].items():recovery["rows"].setdefault(ref,row)
            finish()
            LOG.warning("Media EPG batch failed: %s",exc.__class__.__name__)
    try:reactor.callFromThread(step)
    except Exception as exc:
        finish()
        LOG.warning("Media EPG schedule failed: %s",exc.__class__.__name__)


def _epg_refresh_due(profile_key, entry):
    with _XMLTV_LOCKS.setdefault(profile_key, threading.RLock()):
        loaded = _load_xmltv_state(profile_key)
        programmes = loaded.get("programmes") or {}
        now = int(time.time())
        channels = _live_registry_channels(entry)
        if any(not _epg_snapshot_alive(programmes.get(key), now) for key, _row in channels):
            return True
        # Soft refresh: batches about to run out are renewed ahead of the gap,
        # at most once per _EPG_SOFT_REFRESH_GAP so short guides cannot loop.
        try:
            age = now - int(loaded.get("updated_at") or 0)
        except (TypeError, ValueError):
            age = _EPG_SOFT_REFRESH_GAP + 1
        if age >= _EPG_SOFT_REFRESH_GAP:
            return any(not _epg_snapshot_fresh(programmes.get(key), now) for key, _row in channels)
        return False


def _epg_manager_loop():
    # Expiry drives refresh, not the XML file age. A failed/missing channel
    # is retried once per minute; channels with a valid batch are not fetched.
    while not _EPG_MANAGER_STOP.wait(60):
        if _XMLTV_PAUSED.is_set():
            continue
        try:
            registry = _read_registry()
        except Exception as exc:
            LOG.warning("EPG manager registry read failed: %s", exc)
            continue
        for pkey in _registry_entries(registry):
            try:
                _queue_exported_media_metadata(registry.get(pkey) or {})
                if _epg_refresh_due(pkey, registry.get(pkey) or {}):
                    refresh_xmltv_async(pkey, force=True)
            except Exception as exc:
                LOG.warning("EPG expiry check failed: %s", exc.__class__.__name__)


_NATIVE_EPG_WARMUP_STARTED = False
_NATIVE_EPG_WARMUP_LOCK = threading.Lock()
_NATIVE_EPG_LAST_EXPORT_AT = float("-inf")  # monotonic() can be < 55 s right after boot


_MEDIA_BOOT_RESTORE_STARTED = False
_MEDIA_BOOT_RESTORE_LOCK = threading.Lock()


def migrate_saved_series_exports():
    """Upgrade managed legacy series folders using saved rows, without network."""
    from .export_series import launcher_row
    changed = 0
    pending_picons = []
    with _REGISTRY_LOCK:
        registry = _read_registry()
        snapshots = {REGISTRY_FILE: _snapshot_file(REGISTRY_FILE)}
        retired = []
        try:
            for pkey, entry in _registry_entries(registry).items():
                channels = entry.get("channels") or {}
                records = entry.get("media_metadata") or {}
                for exported in (entry.get("series_category_exports") or {}).values():
                    children = exported.get("children") or []
                    if not children or all(c.get("launcher_key") in channels for c in children):
                        continue
                    filename = str(exported.get("bouquet_name") or "")
                    if (os.path.basename(filename) != filename or not filename.startswith("userbouquet.ultrastalker_" + pkey + "_seriescat_") or not filename.endswith(".tv")):
                        continue
                    path = os.path.join(ENIGMA2_DIR, filename)
                    # An intentionally removed category must not be recreated.
                    if not os.path.isfile(path): continue
                    lines = ["#NAME " + _safe_name(exported.get("category_name") or "Series")]
                    upgraded = []
                    for child in children:
                        if child.get("launcher_key") in channels:
                            launcher = channels[child["launcher_key"]]
                            key = child["launcher_key"]
                        else:
                            keys = [k for k in child.get("episodes") or [] if isinstance(channels.get(k), dict)]
                            if not keys:
                                raise ValueError("Saved series has no episode records")
                            first = channels[keys[0]]
                            seasons = {}
                            # Exported SxxExx labels survive even when Enigma has
                            # overwritten the nested child bouquet with an empty file.
                            for ep_key in keys:
                                row = channels[ep_key]
                                match = re.search(r"\bS(\d+)E\d+\b", str(row.get("_receiver_name") or ""), re.I)
                                number = int(match.group(1)) if match else int(row.get("season_number") or row.get("season") or 1)
                                seasons.setdefault(number, []).append(ep_key)
                            saved_seasons = [{"id": str(n), "season_number": n, "name": "S%02d" % n,
                                              "episode_keys": eps} for n, eps in sorted(seasons.items())]
                            md_key = first.get("_receiver_metadata_key")
                            if not md_key:
                                md = dict(first.get("_receiver_metadata") or {})
                                md_key = hashlib.sha1(json.dumps(md, sort_keys=True, ensure_ascii=False).encode("utf-8")).hexdigest()[:24]
                                records[md_key] = md
                            launcher = launcher_row(exported.get("category_id"), child.get("name") or "Series", md_key,
                                                    first.get("_receiver_picon_local") or "", saved_seasons)
                            key = _channel_key(launcher)
                            channels[key] = launcher
                            child = dict(child, launcher_key=key, seasons=saved_seasons)
                            old_child = str(child.pop("bouquet_name", ""))
                            if (os.path.basename(old_child) == old_child and old_child.startswith("userbouquet.ultrastalker_" + pkey + "_series_") and old_child.endswith(".tv")):
                                retired.append(os.path.join(ENIGMA2_DIR, old_child))
                        ref = _service_ref(_proxy_url(pkey, key, entry.get("proxy_port") or _registry_port(), entry.get("proxy_token") or ""), entry.get("service_type") or 4097, identity=key)
                        name = _receiver_name(launcher, "series")
                        lines.extend(["#SERVICE %s:%s" % (ref, name), "#DESCRIPTION " + name])
                        poster = str(launcher.get("_receiver_picon_local") or "")
                        if poster and os.path.isfile(poster): pending_picons.append((ref, poster, name))
                        upgraded.append(child)
                    snapshots[path] = _snapshot_file(path)
                    _atomic_text(path, "\n".join(lines) + "\n", 0o644)
                    exported["children"] = upgraded
                    changed += 1
                entry["channels"] = channels
                entry["media_metadata"] = records
            if changed: _write_registry(registry)
        except Exception:
            for path, snapshot in reversed(list(snapshots.items())):
                _restore_snapshot(path, snapshot)
            raise
    if changed:
        for path in retired:
            try:
                if os.path.isfile(path): os.unlink(path)
            except OSError: pass
        _publish_shared_picons(pending_picons)
        from twisted.internet import reactor
        reactor.callFromThread(reload_bouquets)
    return changed


def restore_exported_media_on_session_start():
    """Restore persisted media text independently of proxy/provider readiness.

    A separate cache-only pass covers every profile before any Live network
    warmup. Bounded follow-up passes also cover a late native epg.dat load that
    replaces cache contents after the first import. Never saves/flushes Live EPG.
    """
    from ..runtime_policy import exports_needed
    if not exports_needed():return
    global _MEDIA_BOOT_RESTORE_STARTED
    with _MEDIA_BOOT_RESTORE_LOCK:
        if _MEDIA_BOOT_RESTORE_STARTED:return
        _MEDIA_BOOT_RESTORE_STARTED=True

    def work():
        for delay in (1.0,8.0,30.0):
            # This is a boot-only worker, independent of the proxy stop event;
            # a recording/proxy capability failure must not suppress saved text.
            time.sleep(delay)
            try:
                try:
                    migrate_saved_series_exports()
                except Exception as exc:
                    LOG.warning("Saved series upgrade deferred: %s", exc.__class__.__name__)
                registry=_read_registry()
                native_changed = False
                from .export_series import prepare_native_series_bouquets
                for key,entry in _registry_entries(registry).items():
                    try:
                        native_changed = prepare_native_series_bouquets(entry) or native_changed
                    except Exception as exc:
                        LOG.warning("Native series hierarchy restore failed: %s", exc.__class__.__name__)
                    _queue_exported_media_metadata(entry,force=True)
                if native_changed:
                    from twisted.internet import reactor
                    reactor.callFromThread(reload_bouquets)
                LOG.info("Saved media information restored: profiles=%d",len(_registry_entries(registry)))
            except Exception as exc:
                LOG.warning("Saved media information restoration failed: %s",exc.__class__.__name__)
    threading.Thread(target=work,name="ultrastalker-media-restore",daemon=True).start()


def _start_receiver_epg_warmup():
    """One bounded native EPG load per GUI session for existing exports.

    Network work stays entirely off the GUI thread; cache insertion is queued
    back to the GUI in small batches. Never spin a continuous refresh loop.
    """
    restore_exported_media_on_session_start()
    global _NATIVE_EPG_WARMUP_STARTED
    with _NATIVE_EPG_WARMUP_LOCK:
        if _NATIVE_EPG_WARMUP_STARTED:
            return
        _NATIVE_EPG_WARMUP_STARTED = True

    def work():
        # Leave portal UI and existing receiver services time to initialize.
        if _EPG_MANAGER_STOP.wait(2.0):
            return
        try:
            registry = _read_registry()
            for profile_key in _registry_entries(registry):
                if _EPG_MANAGER_STOP.is_set():
                    return
                entry = registry.get(profile_key) or {}
                if not isinstance(entry, dict):
                    continue
                _queue_category_metadata_refresh(profile_key)
                pairs = _installed_live_bouquet_rows(profile_key, entry)
                if not pairs:
                    continue
                if time.monotonic() - _NATIVE_EPG_LAST_EXPORT_AT < 55.0:
                    LOG.info("Native EPG warmup skipped: export is already populating the cache")
                    continue
                try:
                    cached = _cached_receiver_epg_seed(entry.get("profile") or {}, pairs)
                    _queue_receiver_epg_seed(cached)
                    seed = _receiver_epg_seed(entry.get("profile") or {}, pairs, hours=10)
                    restored_refs = {row["service_ref"] for row in cached}
                    seed = list(row for row in seed if row["service_ref"] not in restored_refs)
                except Exception as exc:
                    LOG.warning("Native EPG warmup failed: %s", exc.__class__.__name__)
                    continue
                _queue_receiver_epg_seed(seed)
                LOG.info("Native EPG warmup queued: discovered=%d with_guide=%d", len(pairs), len(seed))
                if _EPG_MANAGER_STOP.wait(5.0):
                    return
        except Exception as exc:
            LOG.warning("Native EPG warmup error: %s", exc.__class__.__name__)

    threading.Thread(target=work, name="ultrastalker-epg-once", daemon=True).start()


def _start_epg_manager():
    global _EPG_MANAGER_THREAD
    if _EPG_MANAGER_THREAD is not None and _EPG_MANAGER_THREAD.is_alive():
        return
    us_clear(_EPG_MANAGER_STOP)
    _EPG_MANAGER_THREAD = threading.Thread(target=_epg_manager_loop, name="stalker-epg-manager", daemon=True)
    _EPG_MANAGER_THREAD.start()


class _Handler(BaseHTTPRequestHandler):
    server_version = "UltraStalker/2"
    sys_version = ""

    def log_message(self, *args):
        return

    def setup(self):
        us_func(BaseHTTPRequestHandler.setup)(self)
        try:
            self.connection.settimeout(_PROXY_SOCKET_TIMEOUT)
        except (AttributeError, OSError):
            pass

    def _send_text(self, code, text):
        body = str(text).encode("utf-8", "replace")
        self.send_response(code)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _do_GET_inner(self):
        parsed = urllib.parse.urlsplit(self.path)
        parts = [part for part in parsed.path.split("/") if part]
        try:
            if parts and parts[0] == "stream" and len(parts) in (3, 4):
                if len(parts) == 4:
                    supplied_token, pkey, ckey = parts[1], parts[2], parts[3]
                else:
                    supplied_token, pkey, ckey = None, parts[1], parts[2]
                entry = _read_registry().get(pkey) or {}
                if not _token_matches(entry, supplied_token):
                    self._send_text(403, "Forbidden")
                    return
                channel = (entry.get("channels") or {}).get(ckey)
                if not isinstance(channel, dict):
                    self._send_text(404, "Unknown channel")
                    return
                if channel.get("_receiver_series_launcher"):
                    if not _queue_export_series(entry, channel, ckey):
                        self._send_text(503, "Series browser unavailable")
                        return
                    self.send_response(204)
                    self.send_header("Cache-Control", "no-store")
                    self.end_headers()
                    return
                client = _client(entry.get("profile") or {})
                media_type = str(channel.get("_receiver_media_type") or "itv").lower()
                link_type = "series" if media_type in ("episode", "series") else media_type
                series_token = None
                if link_type == "series":
                    series_token = channel.get("_receiver_link_series")
                    if series_token in (None, ""):
                        series_token = channel.get("id") or channel.get("episode_id") or channel.get("series") or channel.get("number")
                try: url = client.create_link(channel, link_type, series_token)
                finally:
                    try: client.close()
                    except Exception as exc: LOG.debug("Bouquet proxy client close failed: %s", exc)
                if not url:
                    raise RuntimeError("Portal returned no stream URL")
                # Movies/episodes exported to Enigma2 enter our own Player from
                # the proxy path itself. This avoids Channel InfoBar interception
                # entirely while leaving every Live request on the normal 302 path.
                if media_type in _EXPORT_PLAYER_MEDIA and _queue_export_player(entry, channel, media_type, url, ckey):
                    self.send_response(204)
                    self.send_header("Cache-Control", "no-store")
                    self.end_headers()
                    return
                location = str(url)
                try:
                    from ..stream_relay import wrap as _relay_wrap
                    location = _relay_wrap(location)
                except Exception as exc:
                    LOG.debug("Stream relay wrap failed: %s", exc)
                self.send_response(302)
                self.send_header("Location", location)
                self.send_header("Cache-Control", "no-store, no-cache, must-revalidate")
                self.end_headers()
                return
            if parts and parts[0] == "xmltv" and len(parts) in (2, 3):
                if len(parts) == 3:
                    supplied_token, pkey = parts[1], parts[2]
                else:
                    supplied_token, pkey = None, parts[1]
                entry = _read_registry().get(pkey) or {}
                if not _token_matches(entry, supplied_token):
                    self._send_text(403, "Forbidden")
                    return
                path = _xmltv_for_http(pkey)
                with open(path, "rb") as handle:
                    body = handle.read()
                self.send_response(200)
                self.send_header("Content-Type", "application/xml; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.send_header("Cache-Control", "max-age=900, stale-while-revalidate=3600")
                self.end_headers()
                self.wfile.write(body)
                return
            self._send_text(404, "Not found")
        except Exception as exc:
            # Never log self.path here: tokenized proxy URLs are capabilities.
            LOG.warning("Bouquet proxy request failed detail=%s", exc)
            self._send_text(502, "Stream resolution failed")

    def do_GET(self):
        client_host = self.client_address[0] if self.client_address else ""
        if not _is_loopback_address(client_host):
            self._send_text(403, "Loopback access only")
            return
        if not _PROXY_REQUEST_SLOTS.acquire(False):
            self._send_text(503, "Proxy busy")
            return
        try:
            self._do_GET_inner()
        finally:
            _PROXY_REQUEST_SLOTS.release()


def start_proxy_server(port=None, require_registry=True, strict=False):
    from ..runtime_policy import get_session
    session=get_session()
    if session is not None:set_export_player_session(session)
    with _PROXY_LOCK:
        pending = _PROXY_STOP_THREAD
        if pending is not None and pending.is_alive() and pending is not threading.current_thread():
            try: pending.join(5.0)  # let a background stop release the port/stop-event first
            except Exception: pass
        return _start_proxy_server_locked(port, require_registry, strict)


def _start_proxy_server_locked(port=None, require_registry=True, strict=False):
    global _SERVER, _SERVER_THREAD, _SERVER_PORT, _LAST_PROXY_ERROR
    # Import/UI fast path: if the proxy is already alive, do not touch the
    # registry just to rediscover the port. Explicit conflicting ports retain
    # the old strict/non-strict behaviour.
    if _SERVER is not None:
        if port is None or int(port) == int(_SERVER_PORT or 0):
            resume_xmltv_refreshes(); _start_epg_manager(); _start_receiver_epg_warmup(); return _SERVER
        message = "Dynamic bouquet proxy is already running on port %s" % _SERVER_PORT
        _LAST_PROXY_ERROR = message
        if strict: raise RuntimeError(message)
        return None
    resume_xmltv_refreshes()
    registry = _read_registry()
    try:
        registry = _migrate_legacy_proxy_tokens(registry)
    except Exception as exc:
        _LAST_PROXY_ERROR = "Legacy bouquet token migration failed: %s" % exc
        LOG.warning("%s", _LAST_PROXY_ERROR)
        if strict:
            raise RuntimeError(_LAST_PROXY_ERROR)
        return None
    if require_registry and not _registry_entries(registry):
        return None
    target_port = int(port or _registry_port(registry))
    if _SERVER is not None:
        if _SERVER_PORT == target_port:
            _start_epg_manager()
            return _SERVER
        message = "Dynamic bouquet proxy is already running on port %s" % _SERVER_PORT
        _LAST_PROXY_ERROR = message
        if strict: raise RuntimeError(message)
        return None
    try:
        _assert_loopback_bind()
        server = ThreadingHTTPServer((PROXY_HOST, target_port), _Handler)
        server.daemon_threads = True
        thread = threading.Thread(target=server.serve_forever, name="stalker-bouquet-proxy", daemon=True)
        thread.start()
        _SERVER = server; _SERVER_THREAD = thread; _SERVER_PORT = target_port; _LAST_PROXY_ERROR = ""
        _start_epg_manager()
        _start_receiver_epg_warmup()
        return server
    except OSError as exc:
        _LAST_PROXY_ERROR = "Cannot bind %s:%d: %s" % (PROXY_HOST, target_port, exc)
        if strict:
            raise RuntimeError(_LAST_PROXY_ERROR)
        return None


def proxy_status():
    registry = _read_registry()
    return {
        "running": _SERVER is not None,
        "port": _SERVER_PORT or _registry_port(registry),
        "exports": len(_registry_entries(registry)),
        "last_error": _LAST_PROXY_ERROR,
    }


def stop_proxy_server(wait=None):
    """Stop the proxy. On the GUI (main) thread the slow part (thread joins,
    server.shutdown) runs in a daemon worker; state is swapped synchronously so
    proxy_status() is immediately correct and start_proxy_server() waits for the
    worker. Other threads, or wait=True, stop synchronously."""
    global _SERVER, _SERVER_THREAD, _SERVER_PORT, _EPG_MANAGER_THREAD, _PROXY_STOP_THREAD
    if wait is None:
        wait = threading.current_thread() is not threading.main_thread()
    with _PROXY_LOCK:
        pause_xmltv_refreshes(wait=bool(wait), timeout=5.0)
        server = _SERVER; server_thread = _SERVER_THREAD; manager_thread = _EPG_MANAGER_THREAD
        _SERVER = None; _SERVER_THREAD = None; _SERVER_PORT = None
        _EPG_MANAGER_STOP.set(); _EPG_MANAGER_THREAD = None

        def _finish():
            if manager_thread is not None and manager_thread.is_alive():
                try: manager_thread.join(2.0)
                except Exception as exc: LOG.debug("EPG manager join failed: %s", exc)
            if server is not None:
                try: server.shutdown()
                except Exception as exc: LOG.debug("Proxy shutdown failed: %s", exc)
                try: server.server_close()
                except Exception as exc: LOG.debug("Proxy close failed: %s", exc)
            if server_thread is not None and server_thread.is_alive():
                try: server_thread.join(1.5)
                except Exception as exc: LOG.debug("Proxy thread join failed: %s", exc)

        if wait:
            _finish()
        else:
            worker = threading.Thread(target=_finish, name="stalker-proxy-stop", daemon=True)
            _PROXY_STOP_THREAD = worker
            worker.start()

