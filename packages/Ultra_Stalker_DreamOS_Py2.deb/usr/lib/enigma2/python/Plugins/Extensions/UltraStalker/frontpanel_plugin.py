# -*- coding: utf-8 -*-
"""Ultra Stalker front-panel identity outside the media Player.

Plugin-owned screens use one lightweight Summary so colour TFT front panels show
Ultra Stalker's own icon instead of falling back to the image/default clock.
The Player keeps its dedicated playback summary unchanged.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import int, round, max, min, us_func

os = _us_env.os

from Screens.Screen import Screen
from Components.Label import Label
from Components.Pixmap import Pixmap
from enigma import getDesktop


_PLUGIN_DIR = os.path.dirname(__file__)
_PLUGIN_ICON = os.path.join(_PLUGIN_DIR, "plugin.png")


def _display_geometry():
    """Return front-display geometry without assuming one receiver model."""
    try:
        desktop = getDesktop(1)
        size = desktop.size() if desktop is not None else None
        width = int(size.width()) if size is not None else 0
        height = int(size.height()) if size is not None else 0
        if width > 0 and height > 0:
            return width, height
    except Exception:
        pass
    return 132, 64


def _summary_skin(width, height):
    width = max(96, int(width or 132))
    height = max(48, int(height or 64))

    # Colour/TFT panels: show the actual plugin icon, centred on black.  Keep
    # native 300x120 proportions where possible; downscale only when required.
    if width >= 220 and height >= 100:
        max_w = max(120, width - max(20, width // 10))
        max_h = max(60, height - max(24, height // 4))
        logo_w = min(300, max_w)
        logo_h = max(48, int(round(float(logo_w) * 120.0 / 300.0)))
        if logo_h > max_h:
            logo_h = max_h
            logo_w = max(120, int(round(float(logo_h) * 300.0 / 120.0)))
        logo_x = max(0, (width - logo_w) // 2)
        logo_y = max(0, (height - logo_h) // 2)
        return '''<screen name="UltraStalkerPluginFrontSummary" position="0,0" size="%(w)d,%(h)d" backgroundColor="#000000" flags="wfNoBorder">
            <widget name="logo" position="%(x)d,%(y)d" size="%(lw)d,%(lh)d" pixmap="%(icon)s" alphatest="blend" scale="1" transparent="1" />
            <widget name="title" position="0,0" size="1,1" font="Regular;1" foregroundColor="#000000" backgroundColor="#000000" transparent="0" />
        </screen>''' % {
            "w": width, "h": height, "x": logo_x, "y": logo_y,
            "lw": logo_w, "lh": logo_h, "icon": _PLUGIN_ICON,
        }

    # Tiny monochrome/OLED panels cannot usefully render the artwork.  Keep a
    # clean plugin identity there instead of a broken/scaled colour bitmap.
    margin = 2
    font_size = max(12, min(18, height // 3))
    return '''<screen name="UltraStalkerPluginFrontSummary" position="0,0" size="%(w)d,%(h)d" backgroundColor="#000000" flags="wfNoBorder">
        <widget name="title" position="%(m)d,0" size="%(cw)d,%(h)d" font="Regular;%(fs)d" halign="center" valign="center" foregroundColor="#ffffff" backgroundColor="#000000" transparent="0" noWrap="1" />
        <widget name="logo" position="0,0" size="1,1" alphatest="blend" scale="1" transparent="1" />
    </screen>''' % {
        "w": width, "h": height, "m": margin,
        "cw": max(20, width - (2 * margin)), "fs": font_size,
    }


class UltraStalkerPluginFrontSummary(Screen):
    """Static plugin identity shown while browsing Ultra Stalker."""

    def __init__(self, session, parent):
        us_func(Screen.__init__)(self, session)
        width, height = _display_geometry()
        self.skin = _summary_skin(width, height)
        self["logo"] = Pixmap()
        self["title"] = Label("Ultra Stalker")


def plugin_front_create_summary(self):
    """Screen.createSummary-compatible hook for Ultra Stalker UI screens."""
    return UltraStalkerPluginFrontSummary


def bind_plugin_front_summary(*classes):
    """Attach the front-panel identity to plugin-owned screens only."""
    for cls in classes:
        try:
            if isinstance(cls, type):
                cls.createSummary = plugin_front_create_summary
        except Exception:
            pass
