"""Version the Details poster presentation independently from its source art."""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str, int
hashlib = _us_env.hashlib
os = _us_env.os

DETAIL_POSTER_PREFIX = "detailcover_square_v1_"
DETAIL_POSTER_SIZE = (352, 552)


def cover_cache_key(source_path, size=DETAIL_POSTER_SIZE):
    """Cache identity of the Details derivative of one exact source file.

    Shared by the builder (ui._detail_cover_artwork) and by cached_cover_path,
    so a lookup always finds what the builder wrote.
    """
    stamp = "%s:%s:%sx%s" % (source_path, os.path.getmtime(source_path), int(size[0]), int(size[1]))
    return hashlib.sha1(stamp.encode("utf-8", "ignore")).hexdigest()[:18]


def cached_cover_path(source_path, size=DETAIL_POSTER_SIZE):
    """The finished Details derivative already on disk for this exact source, or "".

    Pure lookup (a few stat calls, no image work), so it is safe on the GUI
    thread. Lets Details paint the finished 352x552 poster at once instead of
    painting the raw source first and swapping it a moment later.
    """
    try:
        source_path = str(source_path or "")
        if not source_path or not os.path.isfile(source_path):
            return ""
        from .persistent_cache import durable_view_path
        from .ui import _valid_cache_file
        name = "%s%s_%sx%s.png" % (DETAIL_POSTER_PREFIX, cover_cache_key(source_path, size), int(size[0]), int(size[1]))
        target = durable_view_path(name, source=source_path)
        return target if _valid_cache_file(target) else ""
    except Exception:
        return ""


def square_poster_bundle(bundle):
    """Retire rounded crops from disk bundles and fast screen handoffs."""
    data = dict(bundle) if isinstance(bundle, dict) else {}
    detail = str(data.get("detail_poster") or "")
    if not detail or not os.path.basename(detail).startswith(DETAIL_POSTER_PREFIX):
        for key in ("detail_poster", "detail_poster_source_fp", "detail_poster_final"):
            data.pop(key, None)
    poster = str(data.get("poster") or "")
    if os.path.basename(poster).startswith("detailcover_") and not os.path.basename(poster).startswith(DETAIL_POSTER_PREFIX):
        data.pop("poster", None)
        data.pop("poster_final", None)
    return data
