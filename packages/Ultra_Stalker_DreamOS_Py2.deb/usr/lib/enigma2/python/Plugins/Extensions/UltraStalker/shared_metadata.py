"""Share descriptive provider fallbacks by verified (media type, TMDb ID).

Canonical TMDb data stays separate. Only missing display fields are filled;
stream URLs, credentials, quality, episode identity and progress are never copied.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str
os = _us_env.os
from .persistent_cache import INDEX
from .core.shared_record_store import SharedRecordStore, PendingWriteLimitError
from .log import optional_failure
from .verified_identity import media_kind, positive_id

COMMON = frozenset(('countries', 'year', 'runtime', 'rating', 'certification',
                    'original_language', 'number_of_seasons', 'number_of_episodes'))
LOCALIZED = frozenset(('overview', 'genres', 'cast', 'directors', 'writers'))


def _merge_saved(old, new):
    import copy
    out = copy.deepcopy(old)
    groups = [(out.setdefault('common', {}), new.get('common') or {}, COMMON)]
    for locale, fields in (new.get('localized') or {}).items():
        groups.append((out.setdefault('localized', {}).setdefault(locale, {}), fields, LOCALIZED))
    for target, incoming, allowed in groups:
        for key, value in incoming.items():
            if key not in allowed or value in (None, '', [], {}, 0):
                continue
            current = target.get(key)
            if not current:
                target[key] = value
            elif key == 'overview' and len(str(value)) > len(str(current)):
                target[key] = value
            elif isinstance(current, list) and isinstance(value, list):
                target[key] = current + [v for v in value if v not in current]
    return out


_STORE = SharedRecordStore(os.path.join(INDEX, 'shared_metadata'), merge=_merge_saved)


def _key(kind, ident):
    ident = positive_id(ident)
    kind = media_kind(kind)
    return '%s_%s' % (kind, ident) if kind and ident else ''


def _locale(value):
    return str(value or '').strip().lower().replace('_', '-')


def load_shared_metadata(kind, ident, locale):
    key = _key(kind, ident)
    if not key:
        return {}
    row = _STORE.get(key)
    out = {k: v for k, v in (row.get('common') or {}).items() if k in COMMON}
    out.update({k: v for k, v in (row.get('localized', {}).get(_locale(locale)) or {}).items() if k in LOCALIZED})
    return out


def selected_locale(cfg=None):
    from .storage import load_settings
    from .language_catalog import normalize_description_choice, effective_description_language
    cfg = cfg if cfg is not None else load_settings() or {}
    choice = normalize_description_choice(cfg.get('description_language', 'ar-en'))
    return (cfg.get('tmdb_language', 'ar-EG') if choice == 'current' else
            effective_description_language(choice, cfg.get('plugin_language', 'en'))) or 'ar-EG'


def enrich_shared_metadata(record, cfg=None):
    """Read-only display overlay. Its provenance makes canonical writers strip it."""
    out = dict(record or {})
    if not (out.get('identity_verified') or out.get('identity_pointer_verified') or out.get('_details_authority_ready')):
        return out
    shared = load_shared_metadata(out.get('media_type'), out.get('tmdb_id'), selected_locale(cfg))
    fields = list(out.get('_details_provider_fields') or ())
    for key, value in shared.items():
        if not out.get(key) or key in fields:
            out[key] = value
            if key not in fields:
                fields.append(key)
    # Keep raw TMDb prose untouched while making the selected-language shared
    # synopsis available to RAM-only first paint as well as the worker result.
    if shared.get('overview'):
        out['_details_provider_overview'] = shared['overview']
    if fields:
        out['_details_provider_fields'] = fields
    return out


def save_shared_metadata(kind, ident, locale, fields):
    key = _key(kind, ident)
    if not key:
        return False
    if not any(k in COMMON | LOCALIZED and v not in (None, '', [], {}, 0) for k, v in (fields or {}).items()):
        return False
    with _STORE.lock:
        row = _STORE.get(key)
        common = row.setdefault('common', {})
        localized = row.setdefault('localized', {}).setdefault(_locale(locale), {})
        for key_name, value in (fields or {}).items():
            if value in (None, '', [], {}, 0) or str(value).strip().lower() in ('unknown', 'n/a', '--'):
                continue
            target = common if key_name in COMMON else localized if key_name in LOCALIZED else None
            if target is None:
                continue
            current = target.get(key_name)
            # Do not downgrade a richer shared synopsis/list with a sparse copy.
            if current:
                if key_name == 'overview' and len(str(current)) >= len(str(value)):
                    continue
                if isinstance(current, list) and isinstance(value, list):
                    value = list(current) + list(v for v in value if v not in current)
                elif key_name != 'overview':
                    continue
            target[key_name] = value
        try:return _STORE.put(key, row)
        except PendingWriteLimitError as exc:
            # The caller receives a failure; no existing accepted record is lost.
            optional_failure("shared_metadata.capacity",exc)
            return False
