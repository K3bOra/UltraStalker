# -*- coding: utf-8 -*-
"""Movie/series information in native EPG; capability-based across E2 images.

Run only on the receiver's main thread. No network or Live guide changes.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from ..us_env import str, int, min
from .export_metadata import text


def _identity(ref):
    try:
        parts=str(ref).split(":")
        sid,tsid,onid=(int(parts[i],16) for i in (3,4,5))
        if not any((sid,tsid,onid)):return None
        return onid & 65535,tsid & 65535,sid & 65535
    except (IndexError,ValueError,TypeError):return None


def _readback(cache,ref,expected):
    lookup=getattr(cache,"lookupEventTime",None)
    if not callable(lookup):return None
    try:
        from enigma import eServiceReference
        reference=eServiceReference(str(ref))
        try:event=lookup(reference,-1,0)
        except TypeError:event=lookup(reference,-1)
    except Exception:return None
    if event is None:return False
    try:
        for method,index in (("getEventName",2),("getShortDescription",3),("getExtendedDescription",4)):
            wanted=text(expected[index])
            if not wanted:continue
            getter=getattr(event,method,None)
            if not callable(getter):return None
            actual=text(getter())
            # Native DVB descriptors can truncate very long strings. Verify
            # real returned text, including the plot, rather than event presence.
            if not actual or not actual.startswith(wanted[:min(80,len(wanted))]):return False
        return True
    except Exception:return None


def import_media_rows(rows,logger,primary_import=None):
    try:
        from enigma import eEPGCache
        cache=eEPGCache.getInstance()
    except Exception:return 0
    accepted=verified=unsupported=0
    for row in rows or []:
        ref=str(row.get("service_ref") or "")
        identity=_identity(ref)
        events=[]
        for event in row.get("events") or []:
            if not isinstance(event,(list,tuple)) or len(event)<6:continue
            try:
                events.append((int(event[0]),int(event[1]),text(event[2],120),text(event[3],120),text(event[4]),0,int(event[6] if len(event)>6 else event[5])&65535))
            except (ValueError,TypeError):continue
        if not identity or not events:continue
        shared = row.get("service_refs")
        if shared:
            # These are native reference aliases, not per-episode metadata.
            # The same parent event payload is submitted once to each bounded
            # group. Enigma shares descriptor storage for identical text.
            refs = list(dict.fromkeys(str(value) for value in shared if _identity(value)))
            missing = list(value for value in refs if _readback(cache,value,events[0]) is not True)
            if not missing:
                accepted+=1;verified+=1
                continue
            modern = getattr(cache,"importEvents",None)
            stored = False
            if callable(modern):
                try:
                    modern(missing,list(events))
                    stored = True
                except Exception:pass
            failed = list(value for value in missing if not stored or _readback(cache,value,events[0]) is False)
            if failed:
                # Compatibility only: older images may reject a list of refs.
                # Reuse the already prepared payload; no metadata work or IO.
                fallback_rows = list(dict(service_ref=value,events=events) for value in failed)
                if import_media_rows(fallback_rows,logger,primary_import) != len(failed):
                    continue
            accepted+=1
            verified+=int(all(_readback(cache,value,events[0]) is True for value in refs))
            continue
        # Boot recovery also runs after Enigma's delayed epg.dat load. Keep
        # those checks, but never re-import already verified movie/series text.
        if _readback(cache,ref,events[0]) is True:
            accepted+=1
            verified+=1
            continue
        # Use the exact receiver importer already used by Live first. It owns
        # service-reference variants and the six-to-seven-field EIT conversion.
        # Keep the plot readback check: an unrelated event is not proof of success.
        if callable(primary_import):
            try:
                count=primary_import([dict(row,events=events)])
                result=_readback(cache,ref,events[0])
                if count and result is not False:
                    accepted+=1
                    verified+=int(result is True);unsupported+=int(result is None)
                    continue
            except Exception:pass
        # Compatibility fallbacks for images where native import/readback fails.
        # OpenATV, OpenPLi and compatible APIs accept (onid,tsid,sid).
        # Legacy images may expose only string imports or importEvent.
        methods=[]
        modern=getattr(cache,"importEvents",None)
        legacy=getattr(cache,"importEvent",None)
        if callable(modern):methods.extend(((modern,identity),(modern,[ref]),(modern,ref)))
        if callable(legacy):methods.append((legacy,ref))
        stored=False
        for method,target in methods:
            try:method(target,list(events))
            except Exception:continue
            result=_readback(cache,ref,events[0])
            if result is False:continue
            stored=True
            verified+=int(result is True);unsupported+=int(result is None)
            break
        if stored:accepted+=1
    logger.info("Media EPG readback: rows=%d accepted=%d verified_text=%d unavailable_readback=%d",len(rows or []),accepted,verified,unsupported)
    if accepted<len(rows or []):logger.warning("Media EPG text missing after import: %d rows",len(rows or [])-accepted)
    return accepted
