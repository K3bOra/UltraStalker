# -*- coding: utf-8 -*-
"""Debounced focus, detail prefetch, series hierarchy prefetch and visible poster watching.

Methods moved verbatim out of ``PremiumGridBase`` (ui_grid_base.py); behaviour is unchanged.
This module is imported by ui_grid_base.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, max, min
from .ui_grid_base import (
    _VISIBLE_POSTER_EXECUTOR,
    _VISIBLE_POSTER_HDD_EXECUTOR,
    _progressive_poster_item_detached,
    diagnostic_failure,
    os,
)


class GridFocusMixin(object):
    """Debounced focus, detail prefetch, series hierarchy prefetch and visible poster watching."""

    def _stop_series_hierarchy_prefetch(self):
        try:self._series_prefetch_timer.stop()
        except Exception as exc:optional_failure("ui.series_prefetch_timer_stop",exc)
        try:
            if getattr(self,"_series_prefetch_timer_conn",None) is not None:
                self._series_prefetch_timer_conn.disconnect()
                self._series_prefetch_timer_conn=None
        except Exception as exc:optional_failure("ui.series_prefetch_timer_disconnect",exc)
        try:
            if self._prefetch_selected_series_hierarchy in self._series_prefetch_timer.callback:
                self._series_prefetch_timer.callback.remove(self._prefetch_selected_series_hierarchy)
        except Exception as exc:optional_failure("ui.series_prefetch_timer_callback",exc)
        try:self._series_hierarchy_prefetch_cancel.set()
        except Exception as exc:optional_failure("ui.series_prefetch_cancel",exc)
        try:self._series_hierarchy_prefetch_token+=1
        except Exception:self._series_hierarchy_prefetch_token=1

    def _prefetch_selected_series_hierarchy(self):
        """Test69 Lean: Series hierarchy is fetched only when Details/Episodes needs it."""
        return

    def _apply_debounced_grid_focus(self):
        if self._screen_closed or not self.grid_items or self.media_type not in ("vod","series"):
            return
        try:
            from .core.shared_executors import METADATA_EXECUTOR
            key = self._page_visual_key(self.grid_items[self.index])
            generation = int(getattr(self, "_page_prefetch_generation", 0) or 0)
            METADATA_EXECUTOR.reprioritize("grid-tmdb:%x:%s:%s" % (id(self), generation, key), 0)
        except Exception as exc:
            optional_failure("ui.selected_metadata_priority", exc)
        # Test71: after focus settles, restore the previous card's normal
        # adaptive chrome, then build/apply a selected-clean chrome for the
        # current card. The laser stays a separate OUTER overlay, so the poster
        # itself keeps its full 206x310 geometry with no inner double frame.
        try:
            prev=int(getattr(self,"_grid_pending_prev_focus",-1))
            if prev>=0 and prev!=self.index:
                p=(getattr(self,"_grid_palette_sources",{}).get(prev) or self._grid_slot_paths.get(prev))
                if p and os.path.isfile(p):self._grid_schedule_adaptive_selector(self._grid_generation,prev,p)
        except Exception as exc:optional_failure("ui.grid_restore_prev_chrome",exc)
        self._grid_pending_prev_focus=-1
        self._grid_apply_current_selector(allow_build=True)
        try:self._apply_poster_live_hud(self.grid_items[self.index])
        except Exception as exc:optional_failure("ui.poster_hud_debounced",exc)
        # release: after focus is stable, hydrate this title's poster + real
        # backdrop automatically.  Rapid navigation never reaches this point.
        try:self._prefetch_focused_artwork()
        except Exception as exc:optional_failure("ui.auto_focus_hydrate",exc)

    def _warm_idle_grid_page(self):
        """Adaptive focus has its own debounce; no page-wide idle warming."""
        return

    def _stop_grid_idle_warm_timer(self):
        try:self._grid_idle_warm_timer.stop()
        except Exception as exc:optional_failure("ui.grid_idle_warm_stop",exc)
        try:
            if self._grid_idle_warm_conn is not None:self._grid_idle_warm_conn.disconnect()
        except Exception as exc:optional_failure("ui.grid_idle_warm_disconnect",exc)
        try:
            if self._warm_idle_grid_page in self._grid_idle_warm_timer.callback:self._grid_idle_warm_timer.callback.remove(self._warm_idle_grid_page)
        except Exception as exc:optional_failure("ui.grid_idle_warm_callback",exc)

    def _stop_grid_focus_timer(self):
        try:self._grid_focus_timer.stop()
        except Exception as exc:optional_failure("ui.silent_guard",exc)
        try:
            if self._grid_focus_timer_conn is not None:self._grid_focus_timer_conn.disconnect()
        except Exception as exc:optional_failure("ui.silent_guard",exc)
        try:
            if self._apply_debounced_grid_focus in self._grid_focus_timer.callback:self._grid_focus_timer.callback.remove(self._apply_debounced_grid_focus)
        except Exception as exc:optional_failure("ui.silent_guard",exc)

    def _stop_detail_prefetch(self):
        try:self._detail_prefetch_timer.stop()
        except Exception as exc:optional_failure("ui",exc)
        try:
            if self._detail_prefetch_conn is not None:self._detail_prefetch_conn.disconnect()
        except Exception as exc:optional_failure("ui",exc)
        try:
            if self._prefetch_selected_details in self._detail_prefetch_timer.callback:self._detail_prefetch_timer.callback.remove(self._prefetch_selected_details)
        except Exception as exc:optional_failure("ui.prefetch_timer_callback",exc)
        try:
            cancel=getattr(self,"_page_prefetch_cancel",None)
            if cancel is not None:cancel.set()
        except Exception as exc:optional_failure("ui.silent_guard",exc)
        self._cancel_detached_page_prefetch_futures()
        for future in list(getattr(self,"_page_prefetch_futures",[]) or []):
            try:future.cancel()
            except Exception as exc:optional_failure("ui.silent_guard",exc)
        self._page_prefetch_futures=[]

    def _prefetch_selected_details(self):
        # Navigation enrichment is strictly selected-card only. Neighbours are
        # loaded when focus actually reaches them, keeping the GUI thread and HDD
        # quiet while the user moves through a large catalogue.
        self._prefetch_visible_page_details(priority_index=self.index,max_items=1)

    def _explicit_item_quality(self, item):
        cache=getattr(self,"_explicit_quality_cache",None)
        key=id(item)
        if isinstance(cache,dict) and key in cache:return cache[key]
        try:
            values=[]
            def walk(v,depth=0):
                if depth>4:return
                if isinstance(v,dict):
                    for k,x in v.items():
                        if str(k).lower() in ("password","token","cookie"):continue
                        walk(x,depth+1)
                elif isinstance(v,(list,tuple)):
                    for x in v[:40]:walk(x,depth+1)
                elif v is not None: values.append(str(v))
            walk(item if isinstance(item,dict) else {})
            result=normalize_quality(" ".join(values))
            if isinstance(cache,dict):cache[key]=result
            return result
        except Exception:
            if isinstance(cache,dict):cache[key]=""
            return ""

    # Portal artwork is completely disabled for VOD/Series. TMDB artwork only.
    def _stop_visible_poster_watch(self):
        try:
            self._poster_defer_pending=[]
            _t=getattr(self,"_poster_defer_timer",None)
            if _t is not None:
                _t.stop()
                try:
                    if self._poll_visible_poster_cache_deferred in _t.callback:_t.callback.remove(self._poll_visible_poster_cache_deferred)
                except Exception:pass
            _dc=getattr(self,"_poster_defer_conn",None)
            if _dc is not None:
                _dc.disconnect()
                self._poster_defer_conn=None
        except Exception as exc:optional_failure("ui.poster_defer_stop",exc)
        try:
            _st=getattr(self,"_search_art_timer",None)
            if _st is not None:
                _st.stop()
                try:
                    if self._run_deferred_search_art in _st.callback:_st.callback.remove(self._run_deferred_search_art)
                except Exception:pass
            _sc=getattr(self,"_search_art_conn",None)
            if _sc is not None:
                _sc.disconnect()
                self._search_art_conn=None
        except Exception as exc:optional_failure("ui.search_art_stop",exc)
        try:self._visible_poster_watch_timer.stop()
        except Exception as exc:optional_failure("ui.visible_poster_watch_stop",exc)
        try:
            if self._visible_poster_watch_conn is not None:
                self._visible_poster_watch_conn.disconnect()
                self._visible_poster_watch_conn=None
        except Exception as exc:optional_failure("ui.visible_poster_watch_disconnect",exc)
        try:
            if self._poll_visible_poster_cache in self._visible_poster_watch_timer.callback:self._visible_poster_watch_timer.callback.remove(self._poll_visible_poster_cache)
        except Exception as exc:optional_failure("ui.visible_poster_watch_callback",exc)

    def _start_visible_poster_watch(self):
        """Test69 Lean: provider/BLUE queues repaint explicitly; no 120ms HDD scanner."""
        return

    def _poster_slot_needs_probe(self,pos):
        """RAM-only filter: False when the slot already owns real/prepared art."""
        try:
            prepared=(getattr(self,"_grid_prepared_art",{}) or {}).get(pos) or {}
            if prepared.get("display") or prepared.get("poster"):return False
        except Exception:pass
        existing=str((getattr(self,"_grid_slot_paths",{}) or {}).get(pos) or "")
        if existing:
            bn=os.path.basename(existing).lower()
            if not ("placeholder" in bn or bn.startswith("poster_movie") or bn.startswith("poster_series")):return False
        return True

    def _poll_visible_poster_cache_staged(self):
        """Probe the focused slot + nearest neighbours inline; defer the rest.

        The full probe costs several JSON/stat reads per placeholder card; running
        it for 27 cards inside the render stalled the GUI thread. Cached posters
        outside the inline set still appear, a few hundred ms later, in small
        chunks driven by a one-shot timer.
        """
        if self._screen_closed or self.media_type not in ("vod","series"):return
        count=min(len(self.grid_items),self.page_size)
        selected_row,selected_col=divmod(int(getattr(self,"index",0) or 0),self.columns)
        order=sorted(range(count),key=lambda p:(abs(p//self.columns-selected_row)+abs(p%self.columns-selected_col),p))
        need=list(p for p in order if self._poster_slot_needs_probe(p))
        inline=set(need[:4]);rest=need[4:]
        if inline:self._poll_visible_poster_cache(positions=inline)
        self._poster_defer_pending=rest
        self._poster_defer_generation=int(getattr(self,"_grid_generation",0) or 0)
        if not rest:return
        try:
            timer=getattr(self,"_poster_defer_timer",None)
            if timer is None:
                timer=self._poster_defer_timer=eTimer()
                try:self._poster_defer_conn=timer.timeout.connect(self._poll_visible_poster_cache_deferred)
                except Exception:timer.callback.append(self._poll_visible_poster_cache_deferred)
            timer.stop();timer.start(150,True)
        except Exception as exc:
            optional_failure("ui.poster_defer_timer",exc)
            self._poster_defer_pending=[]
            self._poll_visible_poster_cache()

    def _poll_visible_poster_cache_deferred(self):
        if self._screen_closed:return
        pending=list(getattr(self,"_poster_defer_pending",[]) or [])
        if not pending:return
        if int(getattr(self,"_poster_defer_generation",-1))!=int(getattr(self,"_grid_generation",0) or 0):
            self._poster_defer_pending=[];return
        chunk=[p for p in pending[:5] if self._poster_slot_needs_probe(p)]
        self._poster_defer_pending=pending[5:]
        if chunk:self._poll_visible_poster_cache(positions=set(chunk))
        if self._poster_defer_pending:
            try:self._poster_defer_timer.start(80,True)
            except Exception:self._poster_defer_pending=[]

    def _poll_visible_poster_cache(self,positions=None,refresh=False):
        """Paint newly persisted visible posters without any network activity."""
        if self._screen_closed or self.media_type not in ("vod","series"):return
        try:
            generation=int(getattr(self,"_grid_generation",0) or 0)
            current_items=list(self.grid_items[:self.page_size])
            for pos,item in enumerate(current_items):
                if positions is not None and pos not in positions:continue
                if not isinstance(item,dict):continue

                # Already displaying a real local poster: nothing to do.
                existing=str((getattr(self,"_grid_slot_paths",{}) or {}).get(pos) or "")
                if existing and os.path.isfile(existing) and not refresh:
                    # Ignore shipped placeholders; they are local files too.
                    bn=os.path.basename(existing).lower()
                    if not ("placeholder" in bn or bn.startswith("poster_movie") or bn.startswith("poster_series")):
                        continue

                poster=""
                snapshot={}
                try:
                    from .artwork_v2 import load_fast_local_poster as _fast_lp_poll
                    snapshot=_fast_lp_poll(self.profile,self.media_type,item) or load_artwork_v2_manifest(self.profile,self.media_type,item) or {}
                    if snapshot:
                        try:
                            from .ui_grid_v2_premium import merge_badge_metadata
                            merge_badge_metadata(self,item,snapshot)
                            self._card_rating_layout(item,pos,self._card_meta(item,pos))
                        except Exception:
                            pass
                    candidate=str(snapshot.get("poster_local") or "")
                    if candidate and os.path.isfile(candidate) and os.path.getsize(candidate)>256:
                        poster=candidate
                except Exception:
                    snapshot={}

                if not poster:
                    try:
                        bundle=_load_visual_bundle(self.profile,self.media_type,item,snapshot) or {}
                        candidate=str(bundle.get("poster") or bundle.get("grid_thumb") or "")
                        if candidate and os.path.isfile(candidate) and os.path.getsize(candidate)>256:
                            poster=candidate
                    except Exception as exc:
                        diagnostic_failure("ui.grid.failsoft.poster_bundle",exc)

                if not poster:
                    continue

                display=poster
                try:
                    thumb=self._grid_poster_thumb_path(poster) or ""
                    if thumb and _valid_cache_file(thumb,ttl=0):display=thumb
                except Exception:display=poster

                # Recheck that this same item still occupies this slot.
                if generation!=int(getattr(self,"_grid_generation",0) or 0):return
                if pos>=len(self.grid_items) or self.grid_items[pos] is not item:
                    # Item objects can be copied by some views; compare stable key.
                    try:
                        from .persistent_cache import content_cache_key
                        if content_cache_key(self.profile,self.media_type,self.grid_items[pos]) != content_cache_key(self.profile,self.media_type,item):
                            continue
                    except Exception:
                        continue
                if refresh:
                    (getattr(self,"_grid_visual_locks",{}) or {}).pop(pos,None)
                self._grid_palette_sources[pos]=poster
                if display==poster:
                    # No thumb yet: first paint now, thumbnail later. Never run
                    # Pillow synchronously from the 120ms UI watcher.
                    self._grid_use_persistent_poster(generation,pos,poster)
                else:
                    self._grid_queue_decode(generation,pos,display)
                    if pos==getattr(self,"index",-1):self._grid_schedule_page_mood(poster)
                self._remember_grid_visual(pos,display=display,poster=poster,palette=poster)
        except Exception as exc:
            optional_failure("ui.visible_poster_watch",exc)

    def _prefetch_visible_page_details(self, priority_index=None, max_items=None):
        """Hydrate visible posters with a detached, HDD-first page worker.

        The serialized HDD worker and any network miss workers capture only
        immutable/page-local values plus result queues. They never retain the
        Grid Screen, so closing or flipping pages cannot leave a stale Screen
        alive behind slow disk/network work.
        """
        if self._screen_closed or self.media_type not in ("vod","series") or not self.grid_items:return
        generation=int(getattr(self,"_page_prefetch_generation",0) or 0)
        cancel_event=getattr(self,"_page_prefetch_cancel",None)
        rows=list(enumerate(self.grid_items[:self.page_size]))
        if priority_index is None:priority_index=self.index
        try:priority_index=int(priority_index)
        except Exception:priority_index=0
        rows.sort(key=lambda pair:(0 if pair[0]==priority_index else 1,abs(pair[0]-priority_index),pair[0]))
        if max_items is not None:
            try:rows=rows[:max(1,int(max_items))]
            except Exception:pass

        selected=[]
        for pos,item in rows:
            if not isinstance(item,dict):continue
            key=self._page_visual_key(item)
            if not key:continue
            try:
                with self._page_prefetch_lock:
                    if key in self._page_prefetch_seen:continue
                    self._page_prefetch_seen.add(key)
            except Exception:continue
            selected.append((pos,dict(item),key))
        if not selected:return

        profile=dict(self.profile or {});media_type=str(self.media_type or "")
        cfg=dict(self._grid_settings or {});client=self.client
        result_q=self._art_prefetch_jobs;future_q=self._page_prefetch_future_jobs
        selected_index=int(priority_index)

        def submit_miss(pos,it,key):
            if cancel_event is not None and cancel_event.is_set():return
            def hydrate_visible(it=dict(it),k=key,gen=generation,cancel=cancel_event):
                if cancel is not None and cancel.is_set():return False
                poster,data=_progressive_poster_item_detached(profile,media_type,it,cfg,client,cancel)
                if cancel is not None and cancel.is_set():return False
                has_poster=bool(poster and os.path.isfile(poster))
                has_meta=bool(isinstance(data,dict) and (data.get("tmdb_id") or data.get("rating") or data.get("vote_average") or data.get("year") or data.get("release_date") or data.get("first_air_date") or data.get("certification") or data.get("age_rating") or data.get("_age_rating_checked") or data.get("number_of_seasons") is not None))
                if has_poster or has_meta:
                    result_q.put((gen,k,poster if has_poster else "",{
                        "tmdb_id":data.get("tmdb_id") if isinstance(data,dict) else None,
                        "identity_verified":bool(isinstance(data,dict) and (data.get("identity_verified") or data.get("identity_pointer_verified") or data.get("matched") or data.get("tmdb_id"))),
                        "media_type":(data.get("media_type") if isinstance(data,dict) else None) or ("tv" if media_type=="series" else "movie"),
                        "rating":(data.get("rating") or data.get("vote_average")) if isinstance(data,dict) else None,
                        "year":(data.get("year") or data.get("release_date") or data.get("first_air_date")) if isinstance(data,dict) else None,
                        "release_date":(data.get("release_date") or data.get("first_air_date") or "") if isinstance(data,dict) else "",
                        "certification":(data.get("certification") or data.get("age_rating") or "") if isinstance(data,dict) else "",
                        "age_rating":(data.get("age_rating") or data.get("certification") or "") if isinstance(data,dict) else "",
                        "_age_rating_checked":bool(isinstance(data,dict) and (data.get("_age_rating_checked") or data.get("certification") or data.get("age_rating"))),
                        "number_of_seasons":(data.get("number_of_seasons") if isinstance(data,dict) else None),
                        "backdrop_local":data.get("backdrop_local") if isinstance(data,dict) else None,
                        "palette_source":poster if has_poster else "",
                    }))
                    if has_poster:
                        return True
                # A transient visible-card miss used to leave this key marked as
                # already-prefetched forever.  That made the card stay blank until
                # focus triggered the separate full-artwork path.  Feed the miss
                # into the existing bounded retry lane: it clears the seen marker
                # and retries this one visible slot once, never as a page-wide loop.
                result_q.put((gen,k,"__RETRY__",None))
                return False
            try:
                priority=0 if pos==selected_index else 1
                # release: visible posters have their own small 3-worker lane.
                # This keeps first-open pages fast without contending with the
                # independent TMDb metadata lane or opening 14 downloads at once.
                future=_VISIBLE_POSTER_EXECUTOR.submit(hydrate_visible,_task_key="grid-poster:%x:%s:%s"%(id(self),generation,key))
                future_q.put((generation,key,future))
            except Exception:
                result_q.put((generation,key,"__RETRY__",None))

        def hdd_batch():
            from .artwork_v2 import load_fast_local_poster as _fast_local_poster_fn
            for pos,it,key in selected:
                if cancel_event is not None and cancel_event.is_set():return
                try:
                    snap=_fast_local_poster_fn(profile,media_type,it) or {}
                    poster=str(snap.get("poster_local") or "")
                    meta={
                        "tmdb_id":snap.get("tmdb_id"),
                        "identity_verified":bool(snap.get("identity_verified") or snap.get("identity_pointer_verified") or snap.get("matched") or snap.get("tmdb_id")),
                        "media_type":snap.get("media_type") or ("tv" if media_type=="series" else "movie"),
                        "rating":snap.get("rating") or snap.get("vote_average"),
                        "year":snap.get("year") or snap.get("release_date") or snap.get("first_air_date"),
                        "release_date":snap.get("release_date") or snap.get("first_air_date") or "",
                        "certification":snap.get("certification") or snap.get("age_rating") or "",
                        "age_rating":snap.get("age_rating") or snap.get("certification") or "",
                        "_age_rating_checked":bool(snap.get("_age_rating_checked") or snap.get("certification") or snap.get("age_rating")),
                        "number_of_seasons":snap.get("number_of_seasons"),
                        "backdrop_local":snap.get("backdrop_local"),
                        "palette_source":poster if poster and os.path.isfile(poster) else "",
                    }
                    if meta.get("tmdb_id") or meta.get("rating") or meta.get("year") or meta.get("certification") or meta.get("_age_rating_checked") or meta.get("number_of_seasons") is not None:
                        result_q.put((generation,key,poster if poster and os.path.isfile(poster) and os.path.getsize(poster)>256 else "",meta))
                    if poster and os.path.isfile(poster) and os.path.getsize(poster)>256:
                        continue
                except Exception:pass
                if cancel_event is not None and cancel_event.is_set():return
                submit_miss(pos,it,key)
        try:
            future=_VISIBLE_POSTER_HDD_EXECUTOR.submit(hdd_batch,_task_key="grid-hdd:%x:%s"%(id(self),generation))
            self._page_prefetch_futures.append(future)
            try:self._async_set_poll_interval(120)
            except Exception:pass
        except Exception as exc:
            for _pos,_it,key in selected:
                try:
                    with self._page_prefetch_lock:self._page_prefetch_seen.discard(key)
                except Exception:pass
            optional_failure("ui.visible_hdd_batch_submit",exc)
