# -*- coding: utf-8 -*-
"""High-quality backdrop replacement.

Methods moved verbatim out of ``PremiumGlobalCinematicScreen`` (ui_cinematic_global.py); behaviour is unchanged.
This module is imported by ui_cinematic_global.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, max, min
from .ui_cinematic_global import (
    BACKDROPS,
    MessageBox,
    TMDBClient,
    _,
    _HQ_BACKDROP_EXECUTOR,
    _media_library_ensure_adaptive,
    _media_library_load,
    _media_library_save,
    _page_backdrop_fetch_original_q60,
    canonical_art_paths,
    load_manifest,
    load_settings,
    optional_failure,
    os,
    re,
    show_notice,
    time,
)


class CineHqBackdropMixin(object):
    """High-quality backdrop replacement."""

    @staticmethod
    def _hq_backdrop_file_path(value):
        """Normalize a TMDb image URL/file_path to the gallery file_path form."""
        text=str(value or "").strip()
        if not text:return ""
        if text.startswith("/"):return text
        m=re.search(r"image\.tmdb\.org/t/p/(?:original|w\d+|h\d+)(/[^?#]+)",text,re.I)
        return m.group(1) if m else ""

    def _hq_backdrop_identity(self,item,row):
        """Return only an already-verified/current TMDb identity for manual HQ replacement."""
        item=item if isinstance(item,dict) else {};row=row if isinstance(row,dict) else {}
        mt="tv" if str(self.media_type or "").lower() in ("series","tv") else "movie"
        verified_row_id=row.get("tmdb_id") if (row.get("identity_verified") or row.get("identity_pointer_verified")) else None
        for value in (verified_row_id,item.get("_ultra_search_verified_tmdb_id"),item.get("_locked_tmdb_id")):
            try:
                text=str(value or "").strip()
                if re.fullmatch(r"\d{1,12}",text):return mt,int(text)
            except Exception:pass
        try:
            hot=load_manifest(self.profile,self.media_type,item) or {}
            text=str(hot.get("tmdb_id") or "").strip()
            if re.fullmatch(r"\d{1,12}",text):
                hmt="tv" if str(hot.get("media_type") or mt).lower() in ("series","tv") else "movie"
                return hmt,int(text)
        except Exception as exc:optional_failure("cinematic.hq_backdrop_identity",exc)
        return mt,None

    def _replace_backdrop_hq(self):
        """Manual, one-title HQ Gallery replacement using the existing canonical Q60 authority."""
        if self.media_type not in ("vod","series") or not self.grid_items:return
        try:
            active=getattr(self,"_hq_backdrop_future",None)
            if active is not None and hasattr(active,"done") and not active.done():
                try:self["status"].setText(_("Backdrop replacement is already running"))
                except Exception:pass
                return
        except Exception:pass
        index=int(self.index);item=dict(self.grid_items[index] or {})
        row=dict((getattr(self,"_cin_page_records",{}) or {}).get(index,{}) or {})
        sig=self._page_visual_key(self.grid_items[index])
        mt,tmdb_id=self._hq_backdrop_identity(item,row)
        if not tmdb_id:
            try:show_notice(self.session, _("TMDb identity is not ready for this title"), timeout=4, owner=self)
            except Exception:pass
            return
        settings=(getattr(self,"_grid_settings",None) or load_settings() or {})
        credential=str(settings.get("tmdb_credential") or "").strip()
        language=str(settings.get("tmdb_language") or "en-US").strip() or "en-US"
        timeout=min(12,max(5,int(settings.get("timeout",7) or 7)))
        if not credential:
            try:show_notice(self.session, _("Add a TMDB API key or Read Access Token first."), timeout=4, owner=self)
            except Exception:pass
            return
        current_fp=self._hq_backdrop_file_path(row.get("manual_hq_backdrop_path") or row.get("backdrop_path") or row.get("backdrop_url") or "")
        try:self["status"].setText(_("Searching for another backdrop…"))
        except Exception:pass

        def worker():
            client=TMDBClient(credential,language,timeout)
            payload=client._get("/%s/%s/images"%(mt,int(tmdb_id)),{}) or {}
            rows=list(x for x in (payload.get("backdrops") or []) if isinstance(x,dict) and x.get("file_path"))
            lang=str(language or "en").split("-")[0].lower()
            valid=[];current=None
            for candidate in rows:
                fp=str(candidate.get("file_path") or "").strip()
                try:w=int(candidate.get("width") or 0);h=int(candidate.get("height") or 0)
                except Exception:w=h=0
                if not fp or w<h or w<1280 or h<600:continue
                iso=str(candidate.get("iso_639_1") or "").lower()
                lang_bonus=3 if not iso else (2 if iso==lang else (1 if iso=="en" else 0))
                score=(w*h,float(candidate.get("vote_average") or 0.0),int(candidate.get("vote_count") or 0),lang_bonus)
                packed=(score,candidate,w,h,fp)
                if fp==current_fp:current=packed
                else:valid.append(packed)
            if current is not None:valid.append(current)
            if not valid:return {"ok":False,"reason":"no_candidate","sig":sig}
            # Cycle through the gallery: best-scored first, then every press moves
            # to the next different backdrop (wrapping) until the viewer stops.
            # The chosen file is saved as this title's locked canonical backdrop,
            # so it stays after the viewer stops pressing.
            valid.sort(key=lambda x:x[0],reverse=True)
            total=len(valid)
            pos=-1
            for i,packed in enumerate(valid):
                if packed[4]==current_fp:pos=i;break
            if total<2 and pos>=0:return {"ok":False,"reason":"no_better","sig":sig}
            chosen=valid[(pos+1)%total]
            cycle_pos=(pos+1)%total+1
            _score,candidate,w,h,fp=chosen
            url=str(TMDBClient.image_url(fp,"original") or "")
            paths=canonical_art_paths(mt,tmdb_id) or {}
            target=str(paths.get("backdrop") or os.path.join(BACKDROPS,"%s_%s.jpg"%(mt,int(tmdb_id))))
            built=_page_backdrop_fetch_original_q60(url,target,timeout=timeout,replace_existing=True)
            if not (built and os.path.isfile(built) and os.path.getsize(built)>4096):
                return {"ok":False,"reason":"download","sig":sig}
            metadata=_media_library_load(mt,tmdb_id) or {}
            metadata.update({
                "backdrop_local":built,"backdrop_path":fp,"backdrop_url":url,
                "backdrop_source":"manual_hq_gallery:q60","clean_backdrop_selector_version":3,
                "manual_hq_backdrop_locked":True,"manual_hq_backdrop_path":fp,
                "manual_hq_backdrop_url":url,"manual_hq_backdrop_width":int(w),
                "manual_hq_backdrop_height":int(h),"manual_hq_backdrop_vote":float(candidate.get("vote_average") or 0.0),
                "manual_hq_backdrop_updated_at":int(time.time()),"identity_verified":True,
            })
            try:metadata=_media_library_ensure_adaptive(metadata) or metadata
            except Exception:pass
            _media_library_save(mt,tmdb_id,metadata)
            return {"ok":True,"cycle":cycle_pos,"cycle_total":total,"sig":sig,"index":index,"path":built,"file_path":fp,"url":url,"width":w,"height":h,"tmdb_id":tmdb_id,"media_type":mt}

        def completed(future):
            try:result=future.result()
            except Exception as exc:result={"ok":False,"reason":"error","error":str(exc),"sig":sig}
            if getattr(self,"_screen_closed",False):return
            try:self._jobs.put((self._replace_backdrop_hq_done,result,False))
            except Exception:pass
        try:
            future=_HQ_BACKDROP_EXECUTOR.submit(worker,_task_key="cin-hq-backdrop:%x"%id(self),_replace_task_key=True)
            self._hq_backdrop_future=future
            future.add_done_callback(completed)
            try:self._async_set_poll_interval(120)
            except Exception:pass
        except Exception as exc:
            optional_failure("cinematic.hq_backdrop_submit",exc)
            try:self.session.open(MessageBox,_("Backdrop replacement failed"),MessageBox.TYPE_ERROR,timeout=4)
            except Exception:pass

    def _replace_backdrop_hq_done(self,result):
        self._hq_backdrop_future=None
        result=result if isinstance(result,dict) else {}
        if not result.get("ok"):
            reason=str(result.get("reason") or "")
            message=_("No other backdrop available") if reason in ("no_candidate","no_better") else _("Backdrop replacement failed")
            # R131: "nothing better exists" is normal gallery feedback, not a
            # modal error.  Keep the current backdrop and show the message in
            # Cinematic's existing upper-right status lane above the overview.
            # This avoids the full black MessageBox detour on every miss.
            try:self["status"].setText(message)
            except Exception:pass
            if reason not in ("no_candidate","no_better"):
                try:show_notice(self.session, message, timeout=4, owner=self)
                except Exception:pass
            return
        path=str(result.get("path") or "")
        sig=str(result.get("sig") or "")
        try:
            if sig and sig==self._fast_bd_current_sig() and self.grid_items:
                idx=int(self.index);row=self._cin_page_records.get(idx,{}) or {}
                row.update({
                    "backdrop_local":path,"backdrop_path":result.get("file_path"),"backdrop_url":result.get("url"),
                    "backdrop_source":"manual_hq_gallery:q60","clean_backdrop_selector_version":3,
                    "manual_hq_backdrop_locked":True,"manual_hq_backdrop_path":result.get("file_path"),
                    "manual_hq_backdrop_url":result.get("url"),"manual_hq_backdrop_width":result.get("width"),
                    "manual_hq_backdrop_height":result.get("height"),"tmdb_id":result.get("tmdb_id"),
                })
                self._cin_page_records[idx]=row
                self._cin_page_backdrops[idx]=path
                self._fast_bd_locked_sig="";self._fast_bd_locked_path=""
                self._fast_bd_bind_local(path,sig,source="manual_hq_gallery_q60")
            try:
                if result.get("cycle_total"):self["status"].setText("%s %d/%d"%(_("Backdrop"),int(result.get("cycle") or 1),int(result.get("cycle_total") or 1)))
                else:self["status"].setText(_("HQ backdrop applied"))
            except Exception:pass
            try:pass
            except Exception:pass
        except Exception as exc:
            optional_failure("cinematic.hq_backdrop_apply",exc)
            try:self.session.open(MessageBox,_("Backdrop replacement failed"),MessageBox.TYPE_ERROR,timeout=4)
            except Exception:pass
