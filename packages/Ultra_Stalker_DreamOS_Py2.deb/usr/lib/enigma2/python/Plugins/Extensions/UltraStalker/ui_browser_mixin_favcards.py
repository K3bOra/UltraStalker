# -*- coding: utf-8 -*-
"""Favourite artwork, details, cards and re-ordering.

Methods moved verbatim out of ``PortalBrowserScreen`` (ui_screens_browser.py); behaviour is unchanged.
This module is imported by ui_screens_browser.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, max, min, us_clear, us_casefold
from .ui_screens_browser import (
    _,
    _lbl_h,
    _mem34,
    os,
)


class BrowserFavCardsMixin(object):
    """Favourite artwork, details, cards and re-ordering."""

    def _schedule_favorite_artwork(self, entries, media_type):
        """Hydrate only the visible favorite page so Favorites stays lightweight."""
        mt=str(media_type or "vod").lower();generation=int(getattr(self,"_favorite_art_generation",0) or 0);profile=dict(self.profile or {})
        for entry in list(entries or []):
            item=dict((entry or {}).get("item") or {})
            if not item:continue
            key=self._favorite_entry_key(mt,item)
            if key in self._favorite_art_pending:continue
            if mt=="itv":
                existing=self._favorite_live_icon(item)
                if existing and os.path.isfile(existing) and os.path.basename(existing)!="home_live_line.png" and "live_row_picon_fit" in existing:continue
            else:
                art,poster,_bundle,_snap=self._favorite_poster_path(mt,item)
                if art and os.path.isfile(art) and "placeholder" not in us_casefold(os.path.basename(art)):continue
            self._favorite_art_pending.add(key)
            _jobs_q=self._favorite_art_jobs;_futs=self._favorite_art_futures
            def work(_mt=mt,_item=item,_key=key,_gen=generation,_q=_jobs_q):
                path="";isolated=None
                try:
                    isolated=_new_isolated_source_client(profile,timeout=6)
                    if _mt=="itv":
                        raw=_image_url(_item)
                        path=_cached_live_picon_path(raw,profile,_item) or ""
                        if not path and raw:
                            try:path=_download_live_portal_temp_picon(raw,profile,isolated,item=_item,timeout=5.0) or ""
                            except Exception:path=_download_public_live_picon(raw,profile,item=_item,timeout=4.0) or ""
                        if path and os.path.isfile(path):
                            from .ui_artwork_helpers import _fit_live_row_picon_canvas as _fav_fit
                            path=_fav_fit(path,PERSISTENT_GENERATED_DIR,(184,110)) or ""
                    else:
                        snap=load_detail_snapshot(profile,_mt,_item) or {};bundle=_load_visual_bundle(profile,_mt,_item,snap) or {};poster=str(bundle.get("poster") or snap.get("poster_local") or "")
                        if not (poster and os.path.isfile(poster)):
                            raw=_image_url(_item);resolved=raw or ""
                            if resolved:poster=_download_portal_artwork(resolved,profile,isolated,False,5.5,None,item=_item) or ""
                            if poster and os.path.isfile(poster):
                                try:_save_visual_bundle(profile,_mt,_item,{"poster":poster},snapshot=snap)
                                except Exception:pass
                        if poster and os.path.isfile(poster):
                            digest=hashlib.sha1((poster+"|favorite-grid-206x310-v4").encode("utf-8","ignore")).hexdigest()[:20];thumb=os.path.join(PERSISTENT_GENERATED_DIR,"favorite_grid_%s.png"%digest)
                            if not os.path.isfile(thumb):_build_cover_thumbnail(poster,thumb,(206,310))
                            if os.path.isfile(thumb):
                                path=thumb
                                try:_save_visual_bundle(profile,_mt,_item,{"grid_thumb":thumb,"poster":poster},snapshot=snap)
                                except Exception:pass
                except Exception as exc:optional_failure("ui.favorite_art_worker",exc)
                finally:
                    if isolated is not None:
                        try:isolated.close()
                        except Exception:pass
                try:_q.put((_gen,_key,_mt,path))
                except Exception:pass
            try:
                future=_IMAGE_EXECUTOR.submit(work);_futs.add(future)
                future.add_done_callback(lambda f,s=_futs: s.discard(f))
            except Exception:
                self._favorite_art_pending.discard(key)

    def _drain_favorite_art_jobs(self):
        changed=False
        while True:
            try:gen,key,mt,path=self._favorite_art_jobs.get_nowait()
            except queue.Empty:break
            except Exception:break
            self._favorite_art_pending.discard(key)
            if int(gen)!=int(getattr(self,"_favorite_art_generation",0) or 0):continue
            if path and os.path.isfile(path):self._favorite_art_local[key]=path;changed=True
        if changed and self.level in ("favorites_cards","favorites_root"):
            try:self._render_favorite_cards(incremental=True)
            except Exception:pass

    def _hide_favorite_cards(self):
        for _fi in range(7):
            for _name in ("fav_card%d"%_fi,"fav_sel%d"%_fi,"fav_art%d"%_fi,"fav_title%d"%_fi,"fav_meta%d"%_fi):
                try:self[_name].hide()
                except Exception:pass

    def _favorite_poster_path(self, media_type, item):
        """Return the light 206x310 poster derivative plus its source."""
        try:
            key=self._favorite_entry_key(media_type,item)
            local=str((getattr(self,"_favorite_art_local",{}) or {}).get(key) or "")
            if local and os.path.isfile(local):return local,local,{},{}
            memo=getattr(self,"_favorite_poster_memo",None)
            if not isinstance(memo,dict):memo={};self._favorite_poster_memo=memo
            hit=memo.get(key)
            if hit and os.path.isfile(hit[0]):return hit
            snap=load_detail_snapshot(self.profile,media_type,item) or {}
            bundle=_load_visual_bundle(self.profile,media_type,item,snap) or {}
            poster=str(bundle.get("poster") or snap.get("poster_local") or "")
            thumb=str(bundle.get("grid_thumb") or "")
            if thumb and os.path.isfile(thumb):
                memo[key]=(thumb,poster or thumb,{},{})
                return thumb,poster or thumb,bundle,snap
            if poster and os.path.isfile(poster):
                key2=hashlib.sha1((poster+"|favorite-grid-206x310-v4").encode("utf-8","ignore")).hexdigest()[:20]
                out=os.path.join(PERSISTENT_GENERATED_DIR,"favorite_grid_%s.png"%key2)
                # The thumbnail is built by the artwork worker (off the GUI thread);
                # until then the placeholder is shown instead of stalling the render.
                if os.path.isfile(out):
                    try:_save_visual_bundle(self.profile,media_type,item,{"grid_thumb":out},snapshot=snap)
                    except Exception:pass
                    memo[key]=(out,poster,{},{})
                    return out,poster,bundle,snap
        except Exception as exc:optional_failure("ui.favorite_grid_art",exc)
        ph=asset("grid_placeholder_series_921.png" if media_type=="series" else "grid_placeholder_movie_921.png")
        return ph,ph,{},{}

    def _favorite_set_title_color(self, slot, selected):
        try:
            move=bool(getattr(self,"_favorite_reorder_active",False)) and bool(selected)
            self._favorite_set_color("fav_title%d"%slot,"#FFD54F" if move else "#FFFFFF")
        except Exception:pass

    @staticmethod
    def _favorite_text_list(value):
        if isinstance(value,(list,tuple)):
            parts=[]
            for v in value:
                parts.append(str((v.get("name") or v.get("title") or "") if isinstance(v,dict) else v).strip())
            return ", ".join([x for x in parts if x][:3])
        return str(value or "").strip()

    def _favorite_details(self, mt, entry):
        """(title, meta, description) for the focused favorite; cheap, no network."""
        if self._favorite_is_folder_entry(entry):
            n=int(entry.get("count") or 0)
            return str(entry.get("name") or _("Folder")),_("Folder")+"  •  "+(_("Channels: %d")%n),""
        item=dict((entry or {}).get("item") or {})
        title=self._favorite_clean_title(mt,item,120)
        if mt=="itv":
            cat=str(item.get("category") or item.get("genre") or item.get("tv_genre_name") or "").strip()
            cid=str(item.get("id") or item.get("ch_id") or "")
            summ=self._epg_cache.get(cid) if cid else None
            if isinstance(summ,dict) and (summ.get("now") or summ.get("next")):
                now=str(summ.get("now") or "").strip();nxt=str(summ.get("next") or "").strip()
                return title,((_("NOW  %s")%now)[:120] if now else _("Live channel")),((_("NEXT")+"  "+nxt)[:120] if nxt else "")
            if cid:
                try:self._schedule_epg_preview(item)
                except Exception as exc:optional_failure("ui.favorite_epg_schedule",exc)
            return title,(_("Live channel")+("  •  "+cat if cat else "")),""
        snap={}
        def pick(*keys):
            for src in (item,snap):
                for k in keys:
                    v=src.get(k) if isinstance(src,dict) else None
                    if v not in (None,"","0","N/A"):return v
            return ""
        desc=pick("description","descr","overview","plot")
        year=pick("year","release_year","release_date","first_air_date")
        if not (desc and year):
            try:snap=load_detail_snapshot(self.profile,mt,item) or {}
            except Exception:snap={}
            desc=desc or pick("description","descr","overview","plot");year=year or pick("year","release_year","release_date","first_air_date")
        genre=self._favorite_text_list(pick("genres_str","genre","genres"))
        # Same localized source as Details: Details-Authority snapshot (cache only here).
        loc=self._favorite_localized(mt,item)
        if loc.get("desc"):desc=loc["desc"]
        if loc.get("genre"):genre=loc["genre"]
        rating=str(pick("rating_imdb","rating","rating_kinopoisk","vote_average") or "").strip()
        meta=[]
        if year:meta.append(str(year)[:4])
        if genre:meta.append(genre)
        if rating:
            try:rating="%.1f"%float(rating)
            except Exception:pass
            if rating not in ("0.0","0"):meta.append("★ "+rating)
        return title,"  •  ".join(meta),_clean_display_text(str(desc or "").replace("\n"," "),0)

    @staticmethod
    def _favorite_loc_lookup(profile,mt,item):
        """Cache/disk-only read of the Details-Authority text (no network)."""
        out={"desc":"","genre":"","ready":False}
        try:
            from .details_authority import details_overview, load_canonical, metadata_language_ready
            from .persistent_cache import load_detail_snapshot_by_tmdb
            row=dict(load_canonical(profile,mt,item) or {})
            tid=row.get("tmdb_id") or (item or {}).get("_locked_tmdb_id")
            if tid:
                direct=load_detail_snapshot_by_tmdb(row.get("media_type") or (item or {}).get("_locked_tmdb_type") or mt,tid) or {}
                if direct:row.update(direct)
            ready=bool(metadata_language_ready(row))
            out["ready"]=ready
            # The synopsis comes from the authority even before the selected-language
            # snapshot is stored, so Favorites reads the same text as Details.
            text,ok=details_overview(profile,mt,item,row)
            if text:out["desc"]=str(text).replace("\n"," ")
            if ready:
                genres=row.get("genres") or []
                if isinstance(genres,(list,tuple)):
                    out["genre"]=" / ".join(str(x).strip() for x in genres[:3] if str(x or "").strip())
                elif genres:out["genre"]=str(genres).strip()
        except Exception as exc:optional_failure("ui.favorite_loc_lookup",exc)
        return out

    def _drain_favorite_meta_jobs(self):
        repaint=False
        while True:
            try:token,key,res=self._favorite_meta_jobs.get_nowait()
            except Exception:break
            if int(token)!=int(getattr(self,"_favorite_meta_token",0) or 0) or not isinstance(res,dict):continue
            self._favorite_loc[key]=res;repaint=True
        if repaint and self.level=="favorites_cards":
            try:
                self._favorite_details_cache={}
                self._favorite_refresh_details()
            except Exception:pass

    def _favorite_set_description(self, desc, media_type):
        # Live keeps its existing NEXT-programme slot. Media summaries wrap into
        # a compact six-line area below genre/year without crossing the page.
        width,height=(1180,86) if media_type=="itv" else (760,168)
        self._browser_geom("fv_d_desc",64,460,width,height)
        self["fv_d_desc"].setText(desc)
        try:
            from enigma import RT_HALIGN_LEFT, RT_HALIGN_RIGHT
            import unicodedata
            rtl=media_type!="itv" and next((unicodedata.bidirectional(c) in ("R","AL")
                      for c in str(desc or "")
                      if unicodedata.bidirectional(c) in ("L","R","AL")),False)
            inst=self["fv_d_desc"].instance
            if inst is not None:inst.setHAlign(_lbl_h("right") if rtl else _lbl_h("left"))
        except Exception as exc:optional_failure("ui.favorite_description_align",exc)
        self["fv_d_desc"].show() if desc else self["fv_d_desc"].hide()

    def _favorite_refresh_details(self):
        """Repaint the details block for the focused rail item (e.g. EPG just arrived)."""
        entries=list(getattr(self,"_favorite_card_entries",[]) or [])
        idx=int(getattr(self,"_favorite_card_index",0) or 0)
        if not (0<=idx<len(entries)) or getattr(self,"level","")!="favorites_cards":return
        title,meta,desc=self._favorite_details(self._favorite_active_mt(),entries[idx])
        self["fv_d_title"].setText(title);self["fv_d_title"].show()
        self["fv_d_meta"].setText(meta);self["fv_d_meta"].show() if meta else self["fv_d_meta"].hide()
        self._favorite_set_description(desc,self._favorite_active_mt())

    def _hide_favorite_details(self):
        for n in ("fv_d_title","fv_pos","fv_d_meta","fv_d_desc","fv_empty"):
            try:self[n].hide()
            except Exception:pass

    def _render_favorite_cards(self, incremental=False):
        """Render one rail page (7 tiles): posters for Movies/Series, glass logo cards for Live."""
        entries=list(getattr(self,"_favorite_card_entries",[]) or []);mt=self._favorite_active_mt()
        content=(getattr(self,"level","")=="favorites_cards")
        total=len(entries)
        if not incremental or total<=0:
            us_clear(self._favorite_slot_state)
            self._hide_favorite_cards();self._hide_favorite_details()
        if total<=0:
            try:
                self["fv_empty"].setText(_("No saved content"));self["fv_empty"].show()
                if not content:
                    self["fv_d_desc"].setText("");
            except Exception:pass
            self._render_favorite_action_buttons()
            _mem34("favorites_cards_rendered", media=mt, rows=0)
            return
        self._favorite_card_index=max(0,min(int(self._favorite_card_index),total-1))
        start=(self._favorite_card_index//7)*7;self._favorite_card_page=start
        self._favorite_page_drawn=None
        if not incremental:
            self._favorite_details_cache={}
        visible=entries[start:start+7]
        for _empty_slot in range(len(visible), 7):
            for _en in ("fav_card%d"%_empty_slot,"fav_sel%d"%_empty_slot,"fav_art%d"%_empty_slot,"fav_title%d"%_empty_slot,"fav_meta%d"%_empty_slot):
                try:self[_en].hide()
                except Exception:pass
        self._schedule_favorite_artwork([e for e in visible if not self._favorite_is_folder_entry(e)],mt)
        moving=bool(getattr(self,"_favorite_reorder_active",False))
        for slot,entry in enumerate(visible):
            pos=start+slot;selected=content and (pos==self._favorite_card_index);x=58+(262*slot)
            for n in ("fav_sel%d"%slot,"fav_meta%d"%slot):
                try:self[n].hide()
                except Exception:pass
            if mt=="itv":
                if self._favorite_is_folder_entry(entry):
                    art=asset("favorite_folder_220x132.png")
                    title=str(entry.get("name") or _("Folder"));count=int(entry.get("count") or 0)
                    if count>=0:title=("%s (%d)"%(title,count))[:44]
                else:
                    item=dict((entry or {}).get("item") or {});art=self._favorite_live_icon(item);title=self._favorite_clean_title("itv",item,42)
                try:
                    self._browser_geom("fav_card%d"%slot,x,640,232,240)
                    if self._favorite_slot_state.get(("c",slot))!="live":
                        self["fav_card%d"%slot].instance.setPixmapFromFile(asset("fav_live_card_232x240.png"));self._favorite_slot_state[("c",slot)]="live"
                    self["fav_card%d"%slot].show()
                except Exception:pass
                try:
                    if os.path.basename(art)=="home_live_line.png":self._browser_geom("fav_art%d"%slot,x+60,640+38,112,82)
                    else:self._browser_geom("fav_art%d"%slot,x+24,640+26,184,110)
                    if self._favorite_slot_state.get(("a",slot))!=art:
                        self["fav_art%d"%slot].instance.setPixmapFromFile(art);self._favorite_slot_state[("a",slot)]=art
                    self["fav_art%d"%slot].show()
                except Exception:pass
                try:
                    self._browser_geom("fav_title%d"%slot,x+10,640+150,212,76);self["fav_title%d"%slot].setText(title);self._favorite_set_title_color(slot,selected);self["fav_title%d"%slot].show()
                except Exception:pass
                sel_name="fav_sel_live%s_252x260.png"%("_move" if moving else "")
                sel_geom=(x-10,630,252,260)
            else:
                try:self["fav_card%d"%slot].hide()
                except Exception:pass
                item=dict((entry or {}).get("item") or {});art,poster,bundle,snap=self._favorite_poster_path(mt,item)
                try:
                    self._browser_geom("fav_art%d"%slot,x,640,232,348)
                    if self._favorite_slot_state.get(("a",slot))!=art:
                        self["fav_art%d"%slot].instance.setPixmapFromFile(art);self._favorite_slot_state[("a",slot)]=art
                    self["fav_art%d"%slot].show()
                except Exception:pass
                if "placeholder" in us_casefold(os.path.basename(str(art or ""))):
                    title=self._favorite_clean_title(mt,item,44)
                    try:self._browser_geom("fav_title%d"%slot,x+8,640+348-70,216,60);self["fav_title%d"%slot].setText(title);self._favorite_set_title_color(slot,selected);self["fav_title%d"%slot].show()
                    except Exception:pass
                else:
                    try:self["fav_title%d"%slot].hide()
                    except Exception:pass
                if moving:sel_name="fav_sel_poster_move_252x368.png";sel_geom=(x-10,630,252,368)
                else:sel_name="poster_cursor_fav_232x348.png";sel_geom=(x,640,232,348)
            if selected:
                try:
                    self._browser_geom("fav_sel%d"%slot,*sel_geom)
                    if self._favorite_slot_state.get(("s",slot))!=sel_name:
                        self["fav_sel%d"%slot].instance.setPixmapFromFile(asset(sel_name));self._favorite_slot_state[("s",slot)]=sel_name
                    self["fav_sel%d"%slot].show()
                except Exception:pass
        if content:
            try:
                sel=entries[self._favorite_card_index]
                title,meta,desc=self._favorite_details(mt,sel)
                self["fv_d_title"].setText(title);self["fv_d_title"].show()
                self["fv_d_meta"].setText(meta);self["fv_d_meta"].show() if meta else self["fv_d_meta"].hide()
                self._favorite_set_description(desc,self._favorite_active_mt())
                self["fv_pos"].setText("%d / %d"%(self._favorite_card_index+1,total));self["fv_pos"].show()
            except Exception as exc:optional_failure("ui.favorite_details",exc)
        else:
            try:
                self["fv_d_meta"].hide()
            except Exception:pass
        self._render_favorite_action_buttons()
        # Remember what is on screen so a move inside this page only has to
        # shift the focus frame (no 7-poster re-decode, no page re-render).
        self._favorite_page_drawn=(start,mt,total,moving,content)
        _mem34("favorites_cards_rendered", media=mt, rows=len(visible))

    def _favorite_fast_focus(self, old, new):
        """Move only the focus frame/title colour/details within the drawn page."""
        try:
            drawn=getattr(self,"_favorite_page_drawn",None)
            entries=list(getattr(self,"_favorite_card_entries",[]) or [])
            total=len(entries);mt=self._favorite_active_mt()
            start=(new//7)*7
            if not drawn or drawn!=(start,mt,total,False,True) or (old//7)*7!=start:return False
            if getattr(self,"_favorite_reorder_active",False):return False
            old_slot=old-start;new_slot=new-start
            x=58+(262*new_slot)
            if 0<=old_slot<7:
                try:self["fav_sel%d"%old_slot].hide()
                except Exception:pass
                self._favorite_set_title_color(old_slot,False)
            if mt=="itv":sel_name="fav_sel_live_252x260.png";sel_geom=(x-10,630,252,260)
            else:sel_name="poster_cursor_fav_232x348.png";sel_geom=(x,640,232,348)
            self._browser_geom("fav_sel%d"%new_slot,*sel_geom)
            if self._favorite_slot_state.get(("s",new_slot))!=sel_name:
                self["fav_sel%d"%new_slot].instance.setPixmapFromFile(asset(sel_name));self._favorite_slot_state[("s",new_slot)]=sel_name
            self["fav_sel%d"%new_slot].show()
            self._favorite_set_title_color(new_slot,True)
            cache=getattr(self,"_favorite_details_cache",None)
            if not isinstance(cache,dict) or len(cache)>64:
                cache={};self._favorite_details_cache=cache
            entry=entries[new]
            ckey=(mt,id(entry))
            if ckey not in cache:cache[ckey]=self._favorite_details(mt,entry)
            title,meta,desc=cache[ckey]
            self["fv_d_title"].setText(title);self["fv_d_title"].show()
            self["fv_d_meta"].setText(meta);self["fv_d_meta"].show() if meta else self["fv_d_meta"].hide()
            self._favorite_set_description(desc,self._favorite_active_mt())
            self["fv_pos"].setText("%d / %d"%(new+1,total));self["fv_pos"].show()
            return True
        except Exception as exc:
            optional_failure("ui.favorite_fast_focus",exc)
            return False

    def _favorite_move(self, delta):
        total=len(getattr(self,"_favorite_card_entries",[]) or [])
        if total<=0:return
        old=int(self._favorite_card_index)
        self._favorite_card_index=(old+int(delta))%total
        if self._favorite_fast_focus(old,int(self._favorite_card_index)):return
        self._render_favorite_cards()

    def _favorite_unfavorite_selected(self):
        entries=list(getattr(self,"_favorite_card_entries",[]) or [])
        if not entries or getattr(self,"_favorite_reorder_active",False):return
        idx=max(0,min(int(getattr(self,"_favorite_card_index",0) or 0),len(entries)-1));entry=entries[idx]
        if self._favorite_is_folder_entry(entry):return
        item=entry.get("item") or {};mt=str(entry.get("media_type") or getattr(self,"_favorites_bucket_type",None) or "vod")
        if not isinstance(item,dict):return
        try:
            from .repositories.content import FAVORITES, FAVORITE_FOLDERS
            # Remove folder membership first so no stale hidden assignment survives.
            if mt=="itv":FAVORITE_FOLDERS.remove_item(self.profile,mt,item)
            removed=bool(FAVORITES.remove_saved_entry(entry))
            if not removed and is_favorite(self.profile,mt,item):
                toggle_favorite(self.profile,mt,item);removed=True
            if not removed:
                optional_failure("ui.favorite_unfavorite",RuntimeError("saved favorite row not found"));return
        except Exception as exc:
            optional_failure("ui.favorite_unfavorite",exc);return
        self._favorite_refresh_bucket_entries(idx)
        self._render_favorites_root();self._render_favorite_cards()

    def _favorite_begin_move(self):
        entries=list(getattr(self,"_favorite_card_entries",[]) or [])
        if not entries or getattr(self,"_favorite_reorder_active",False):return
        idx=max(0,min(int(getattr(self,"_favorite_card_index",0) or 0),len(entries)-1))
        if self._favorite_is_folder_entry(entries[idx]):return
        # One channel can still be moved into a folder, so do not require >1 channels.
        if len(entries)<=1 and not getattr(self,"_favorite_folder_id",None):return
        self._favorite_reorder_original=list(entries);self._favorite_move_source_index=idx;self._favorite_reorder_active=True
        self._render_favorite_cards()

    def _favorite_reorder_step(self, delta):
        entries=list(getattr(self,"_favorite_card_entries",[]) or []);total=len(entries)
        if total<=0:return
        # Move only the destination cursor. The carried channel stays intact until OK,
        # which lets OK on a folder mean "drop this channel into that folder".
        self._favorite_card_index=(int(getattr(self,"_favorite_card_index",0) or 0)+int(delta))%total
        self._render_favorite_cards()

    @staticmethod
    def _favorite_move_list_item(rows, source_index, target_index):
        rows=list(rows or [])
        if not rows:return rows
        source_index=max(0,min(int(source_index),len(rows)-1));target_index=max(0,min(int(target_index),len(rows)-1))
        item=rows.pop(source_index)
        rows.insert(max(0,min(target_index,len(rows))),item)
        return rows

    def _favorite_commit_move(self):
        if not getattr(self,"_favorite_reorder_active",False):return False
        original=list(getattr(self,"_favorite_reorder_original",[]) or []);mt=str(getattr(self,"_favorites_bucket_type",None) or "vod").lower()
        src=max(0,min(int(getattr(self,"_favorite_move_source_index",0) or 0),max(0,len(original)-1)))
        target=max(0,min(int(getattr(self,"_favorite_card_index",0) or 0),max(0,len(original)-1)))
        source_entry=original[src] if original else None;target_entry=original[target] if original else None
        try:
            from .repositories.content import FAVORITES, FAVORITE_FOLDERS
            if source_entry and not self._favorite_is_folder_entry(source_entry):
                source_item=dict((source_entry or {}).get("item") or {})
                # Root Live: OK while the cursor is on a folder drops the channel into it.
                if mt=="itv" and not getattr(self,"_favorite_folder_id",None) and self._favorite_is_folder_entry(target_entry):
                    FAVORITE_FOLDERS.assign(self.profile,mt,source_item,str(target_entry.get("folder_id") or ""))
                    self._favorite_reorder_active=False;self._favorite_reorder_original=[];self._favorite_move_source_index=-1
                    self._favorite_refresh_bucket_entries(target);self._render_favorites_root();self._render_favorite_cards();return True
                if target_entry is not None and not self._favorite_is_folder_entry(target_entry):
                    if getattr(self,"_favorite_folder_id",None) and mt=="itv":
                        channel_rows=list(e for e in original if not self._favorite_is_folder_entry(e))
                        src_channel=channel_rows.index(source_entry);target_channel=channel_rows.index(target_entry)
                        reordered=self._favorite_move_list_item(channel_rows,src_channel,target_channel)
                        FAVORITE_FOLDERS.reorder(self.profile,mt,self._favorite_folder_id,list(dict((e or {}).get("item") or {}) for e in reordered))
                    else:
                        # Reorder the complete favorite shelf so hidden folder members keep
                        # their existing relative position when a root channel is moved.
                        all_saved=list(self._favorites_for_portal(mt))
                        source_key=self._favorite_content_key(mt,source_item)
                        target_item=dict((target_entry or {}).get("item") or {});target_key=self._favorite_content_key(mt,target_item)
                        keyed=list(self._favorite_content_key(mt,(e or {}).get("item") or {}) for e in all_saved)
                        if source_key in keyed and target_key in keyed:
                            reordered=self._favorite_move_list_item(all_saved,keyed.index(source_key),keyed.index(target_key))
                            FAVORITES.reorder(self.profile,mt,list(dict((e or {}).get("item") or {}) for e in reordered))
        except Exception as exc:
            optional_failure("ui.favorite_reorder_commit",exc)
        self._favorite_reorder_active=False;self._favorite_reorder_original=[];self._favorite_move_source_index=-1
        self._favorite_refresh_bucket_entries(target);self._render_favorite_cards();return True

    def _favorite_cancel_move(self):
        if not getattr(self,"_favorite_reorder_active",False):return False
        source=int(getattr(self,"_favorite_move_source_index",0) or 0)
        self._favorite_reorder_active=False;self._favorite_reorder_original=[];self._favorite_move_source_index=-1
        self._favorite_card_index=max(0,min(source,max(0,len(self._favorite_card_entries)-1)));self._render_favorite_cards();return True

    def _open_favorite_card(self):
        entries=list(getattr(self,"_favorite_card_entries",[]) or [])
        if not entries:return
        entry=entries[max(0,min(self._favorite_card_index,len(entries)-1))]
        if self._favorite_is_folder_entry(entry):
            self._favorite_open_folder(entry);return
        portal=str(self.profile.get("portal") or "").rstrip("/").lower();mac=str(self.profile.get("mac") or "").upper()
        if str(entry.get("portal") or "").rstrip("/").lower()!=portal or str(entry.get("mac") or "").upper()!=mac:
            return
        item=entry.get("item") or {};mt=str(entry.get("media_type") or "vod")
        if mt=="itv":
            old=self.media_type;self.media_type="itv";self.play_item(item);self.media_type=old
        else:
            self.session.openWithCallback(self._favorite_child_returned,ContentDetailsScreen,self.profile,self.client,mt,item)

    def _favorite_child_returned(self, result=None):
        if getattr(self,"level",None)!="favorites_cards":return
        mt=str(getattr(self,"_favorites_bucket_type",None) or "vod");keep=int(getattr(self,"_favorite_card_index",0) or 0)
        self._show_favorites_bucket(mt)
        if self.level=="favorites_cards":
            self._favorite_card_index=max(0,min(keep,max(0,len(self._favorite_card_entries)-1)));self._render_favorite_cards()
