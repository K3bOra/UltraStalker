# -*- coding: utf-8 -*-
"""Home menu window and icons.

Methods moved verbatim out of ``PortalHomeScreen`` (ui_screens_home.py); behaviour is unchanged.
This module is imported by ui_screens_home.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import int, max, min
from .ui_screens_home import (
    _,
    asset,
    home_boot_pixmap,
    optional_failure,
    os,
)


class HomeMenuMixin(object):
    """Home menu window and icons."""

    def _menu_slot(self):
        try:return max(0,min(self.VISIBLE_CARD_COUNT-1,int(self.index)-int(self._menu_window_start)))
        except Exception:return 0

    def _ensure_menu_window(self):
        old=int(getattr(self,"_menu_window_start",0) or 0)
        max_start=max(0,len(self.CARDS)-self.VISIBLE_CARD_COUNT)
        start=old
        if self.index < start:start=self.index
        elif self.index >= start+self.VISIBLE_CARD_COUNT:start=self.index-self.VISIBLE_CARD_COUNT+1
        start=max(0,min(max_start,int(start)))
        self._menu_window_start=start
        return start!=old

    def _render_menu_window(self, load_icons=True):
        """Bind the seven resident Home cards to the current logical window."""
        if getattr(self,"_sc_mode",False):
            self._sc_render();return
        self._ensure_menu_window()
        start=int(getattr(self,"_menu_window_start",0) or 0)
        for slot in range(self.VISIBLE_CARD_COUNT):
            logical=start+slot
            if logical>=len(self.CARDS):continue
            title,subtitle,_action,icon_name=self.CARDS[logical]
            try:self["card_title%d"%slot].setText(_(title))
            except Exception:pass
            try:self["card_sub%d"%slot].setText(_(subtitle))
            except Exception:pass
            if not load_icons:continue
            self._home_icon_state[slot]=(logical,False)
            try:
                path=asset(icon_name)
                if path and os.path.isfile(path) and os.path.getsize(path)>256:
                    pix=home_boot_pixmap(path) if callable(home_boot_pixmap) else None
                    if pix is not None:self["menu_icon%d"%slot].instance.setPixmap(pix)
                    else:self["menu_icon%d"%slot].instance.setPixmapFromFile(path)
                    self["menu_icon%d"%slot].show()
            except Exception as exc:
                optional_failure("ui.home_icon_%d"%slot,exc)

    def _load_menu_icons(self):
        """Reload the seven visible Home icon widgets for the active carousel window."""
        self._render_menu_window(load_icons=True)
