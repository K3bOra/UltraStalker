"""Paginate provider-filtered Search results without rescanning healthy portals."""
from __future__ import absolute_import, division, print_function, unicode_literals
from .. import us_env as _us_env
from ..us_env import str, max, us_casefold
time = _us_env.time


def search_native(client, query, media_types, limit, max_pages, cancel_event,
                  time_budget, on_partial, allow_catalogue_fallback=True):
    client._last_search_complete = False
    deadline = time.monotonic() + max(0.1, float(time_budget))
    needle = " ".join(us_casefold(str(query or "")).replace("_", " ").replace("-", " ").split())
    if not needle:
        client._last_search_complete = True
        return []
    out, seen, pending, unsupported = [], set(), [], []
    truncated = [False]

    def stopped():
        return time.monotonic() >= deadline or (cancel_event is not None and cancel_event.is_set())

    def matches(row):
        value = str(row.get("name") or row.get("title") or "")
        return needle in " ".join(us_casefold(value).replace("_", " ").replace("-", " ").split())

    def publish(rows, typ):
        added = 0
        for row in rows:
            marker = (typ, client._item_identity(row))
            if marker in seen or not matches(row):
                continue
            if len(out) >= limit:
                truncated[0] = True
                break
            seen.add(marker)
            item = dict(row)
            item["_search_media_type"] = typ
            out.append(item)
            added += 1
            if callable(on_partial):
                on_partial([dict(item)])
        return added

    def fetch(typ, key, page):
        js = client._unwrap(client._get(
            client._search_params(typ, page, key, query),
            use_cache=False, cancel_event=cancel_event))
        if isinstance(js, dict) and (js.get("error") or js.get("errors") or js.get("success") is False):
            raise ValueError("Provider search error: %s" % (js.get("error") or js.get("errors") or "success=false"))
        if not isinstance(js, (dict, list)):
            raise ValueError("Invalid provider search response")
        if isinstance(js, dict) and not any(isinstance(js.get(k), list) for k in
                ("data", "items", "episodes", "seasons", "series")) and not any(
                k in js for k in ("total_items", "total")):
            raise ValueError("Invalid provider search response")
        return js, [r for r in client._as_list(js) if isinstance(r, dict)]

    def exhausted(js, rows, page):
        if not rows:
            return True
        meta = js if isinstance(js, dict) else {}
        total = client._int_value(meta.get("total_items") or meta.get("total"), 0)
        size = client._int_value(meta.get("max_page_items") or meta.get("page_size"), 0)
        return bool((total and page * (size or len(rows)) >= total)
                    or (size and len(rows) < size))

    if not client.token:
        client.authorize(cancel_event=cancel_event)
    complete = True
    # Every type gets page one before continuing any long result list.
    for typ in media_types:
        if stopped() or len(out) >= limit:
            complete = False
            break
        accepted, unfiltered = False, False
        for key in ("search", "search_str", "name"):
            if stopped():
                break
            try:
                js, rows = fetch(typ, key, 1)
            except Exception as exc:
                if any(marker in str(exc).lower() for marker in
                       ("http 400", "http 404", "http 405", "unsupported", "unknown parameter", "invalid parameter")):
                    continue
                complete = False
                break
            if rows and not any(matches(r) for r in rows):
                unfiltered = True
                continue
            if rows:
                # An ignored query can return a mixed catalogue page. Do not
                # mistake it for a complete provider-filtered result list.
                if not all(matches(r) for r in rows):
                    unfiltered = True
                    publish(rows, typ)
                    continue
                publish(rows, typ)
                accepted = True
                if not exhausted(js, rows, 1):
                    pending.append((typ, key, 2, {tuple(client._item_identity(r) for r in rows)}))
                break
            meta = js if isinstance(js, dict) else {}
            explicit_empty = isinstance(js, list) or any(
                isinstance(meta.get(k), list) for k in ("data", "items", "episodes", "seasons", "series"))
            if (explicit_empty or any(k in meta for k in ("total_items", "total"))) and not unfiltered:
                accepted = True
                break
        if not accepted and unfiltered:
            unsupported.append(typ)
        elif not accepted:
            complete = False

    while pending and not stopped() and len(out) < limit:
        remaining = []
        for typ, key, page, fingerprints in pending:
            if stopped() or len(out) >= limit or page > max_pages:
                complete = False
                continue
            try:
                js, rows = fetch(typ, key, page)
            except Exception:
                complete = False
                continue
            fingerprint = tuple(client._item_identity(r) for r in rows)
            if rows and fingerprint in fingerprints:
                complete = False
                continue
            fingerprints.add(fingerprint)
            if rows and not all(matches(r) for r in rows):
                complete = False
                publish(rows, typ)
                continue
            publish(rows, typ)
            if not exhausted(js, rows, page):
                remaining.append((typ, key, page + 1, fingerprints))
        pending = remaining

    # Compatibility only: a portal that actually ignores every query key keeps
    # its established bounded catalogue search. Native hits never trigger it.
    for typ in unsupported:
        complete = False
        if not allow_catalogue_fallback:
            continue
        if stopped() or len(out) >= limit:
            break
        rows = client.search_content_fast(
            query, media_types=(typ,), limit=limit - len(out), max_pages=max_pages,
            cancel_event=cancel_event, time_budget=max(0.1, deadline - time.monotonic()),
            on_partial=on_partial)
        publish(rows or [], typ)
    client._last_search_complete = bool(complete and not pending and not stopped() and not truncated[0])
    return out
