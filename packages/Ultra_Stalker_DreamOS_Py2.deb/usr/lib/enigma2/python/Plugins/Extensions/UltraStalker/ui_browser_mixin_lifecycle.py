# -*- coding: utf-8 -*-
"""Layout-ready, initial action, job draining, list density and geometry.

Methods moved verbatim out of ``PortalBrowserScreen`` (ui_screens_browser.py); behaviour is unchanged.
This module is imported by ui_screens_browser.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, round, max, us_func
from .ui_screens_browser import (
    AsyncScreenMixin,
    LOG,
    _,
    _mem34,
    _ui_diag,
    diagnostic_failure,
    time,
)


class BrowserLifecycleMixin(object):
    """Layout-ready, initial action, job draining, list density and geometry."""

    def _layout_ready(self):
        _perf29_layout_t0=time.monotonic()
        LOG.info("PERF29 browser layout_begin action=%s level=%s",str(self.initial_action or "root"),str(getattr(self,"level","") or ""))
        try:_ui_diag("ui_ready",screen="browser",elapsed_ms=int((time.monotonic()-self._ui_diag_open_mono)*1000.0))
        except Exception as exc: diagnostic_failure("ui.browser.failsoft", exc)
        self._image_layout_ready()

        # Test15 cold-start path: Home already chose Live/Movies/Series.  Keep the
        # Browser root completely unpainted while categories are fetched.  The user
        # sees the final clean hero immediately, then the real rows appear once.
        if self.initial_action in ("catchup","favorites","account") and not self._initial_action_done:
            # PERF30: utility pages already use the approved bundled static
            # Palestine background. Do not enter the legacy category mood path,
            # which can synchronously build a 1920x1080 extended backdrop and was
            # responsible for multi-second Catch-up opens on cold cache.
            _utility_t0=time.monotonic()
            try:
                self._apply_utility_glass_mode();self["page_adaptive_bg"].show()
            except Exception as exc:optional_failure("ui.utility_cold_static",exc)
            LOG.info("PERF30 utility_static_ready action=%s elapsed_ms=%d",str(self.initial_action or "root"),int((time.monotonic()-_utility_t0)*1000))
            for _name in ("title","counter","section","top_divider","list","accent_frame","preview","info_card1","info_card2","info_card3","info_icon1","info_icon2","info_icon3","info_title","info","status","red_bg","green_bg","yellow_bg","blue_bg","red","green","yellow","blue"):
                try:self[_name].hide()
                except Exception:pass
            self._schedule_initial_action()
            LOG.info("PERF29 browser layout_ready action=%s elapsed_ms=%d scheduled=yes",str(self.initial_action or "root"),int((time.monotonic()-_perf29_layout_t0)*1000))
            _mem34("browser_layout_ready", action=str(self.initial_action or "root"), level=str(getattr(self,"level","") or ""))
            return

        if self.initial_action in ("itv","vod","series"):
            # R129 SPEED: one authority owns category first paint.  Older builds
            # applied category geometry/static background here and then repeated
            # the same work immediately inside load_genres().  Let load_genres()
            # do it once, preserving the exact final pixels with less UI-thread work.
            self.media_type = self.initial_action
            if self.level not in ("genres", "genres_loading"):
                self.level = "genres_loading"
            if not self._initial_action_done:
                self._initial_action_done=True
                self._open_media_with_parental(self.initial_action)
            elif self.level == "genres":
                self._reveal_browser_content()
            LOG.info("PERF29 browser layout_ready action=%s elapsed_ms=%d category_entry=yes",str(self.initial_action or "root"),int((time.monotonic()-_perf29_layout_t0)*1000))
            _mem34("browser_layout_ready", action=str(self.initial_action or "root"), level=str(getattr(self,"level","") or ""))
            return

        for _name in ("title", "counter", "section", "top_divider", "list", "accent_frame", "preview", "info_card1", "info_card2", "info_card3", "info_icon1", "info_icon2", "info_icon3", "info_title", "info", "status",  "red_bg", "green_bg", "yellow_bg", "blue_bg", "red", "green", "yellow", "blue"):
            try:
                self[_name].show()
            except Exception as exc:
                optional_failure("ui", exc)
        self._set_root_rows()
        self._decode_picture(asset("us80_section_live_530x382.png"))
        self._selection_changed()
        LOG.info("PERF29 browser layout_ready action=%s elapsed_ms=%d root=yes",str(self.initial_action or "root"),int((time.monotonic()-_perf29_layout_t0)*1000))
        _mem34("browser_layout_ready", action=str(self.initial_action or "root"), level=str(getattr(self,"level","") or ""))
        # Modal actions still wait for onShown; OpenATV rejects modal opens here.

    def _schedule_initial_action(self):
        if self._initial_action_done or self._initial_action_scheduled or not self.initial_action:return
        self._initial_action_scheduled=True
        try:self._initial_action_timer.start(1,True)
        except Exception:
            self._initial_action_scheduled=False
            self._activate_initial_action()

    def _stop_initial_action_timer(self):
        try:self._initial_action_timer.stop()
        except Exception as exc:optional_failure("ui.browser_initial_timer_stop",exc)
        try:
            if self._initial_action_timer_conn is not None:self._initial_action_timer_conn.disconnect()
            self._initial_action_timer_conn=None
        except Exception as exc:optional_failure("ui.browser_initial_timer_disconnect",exc)
        try:
            if self._activate_initial_action in self._initial_action_timer.callback:self._initial_action_timer.callback.remove(self._activate_initial_action)
        except Exception as exc:optional_failure("ui.browser_initial_timer_callback",exc)
        try:
            _ldt=getattr(self,"_live_direct_timer",None)
            if _ldt is not None:_ldt.stop()
            _ldc=getattr(self,"_live_direct_conn",None)
            if _ldc is not None:_ldc.disconnect();self._live_direct_conn=None
            _ldcb=getattr(self,"_live_direct_cb",None)
            if _ldt is not None and _ldcb is not None and _ldcb in _ldt.callback:_ldt.callback.remove(_ldcb)
            self._live_direct_cb=None
        except Exception:pass

    def _activate_initial_action(self):
        self._initial_action_scheduled=False
        if self._initial_action_done or not self.initial_action:
            return
        self._initial_action_done = True
        action = self.initial_action
        _perf29_action_t0=time.monotonic()
        LOG.info("PERF29 browser action_begin action=%s",str(action))
        if action in ("itv", "vod", "series"):
            self._open_media_with_parental(action)
        elif action == "catchup":
            self.load_catchup_channels()
        elif action == "favorites":
            self._show_saved_entries(load_favorites(), "Favorites")
        elif action == "recent":
            self._show_saved_entries(load_continue_watching(), "Continue Watching")
        elif action == "account":
            self.show_account_info()
        elif action == "settings":
            self.session.open(NovaSettingsScreen, self.profile, self.client)
        LOG.info("PERF29 browser action_return action=%s elapsed_ms=%d",str(action),int((time.monotonic()-_perf29_action_t0)*1000))

    def _drain_jobs(self):
        us_func(AsyncScreenMixin._drain_jobs)(self)
        if not self._screen_closed:
            self._drain_image_jobs(); self._drain_epg_jobs(); self._drain_favorite_art_jobs(); self._drain_favorite_meta_jobs()
            while True:
                try:msg=self._live_picon_cache_progress.get_nowait()
                except queue.Empty:break
                except Exception:break
                try:
                    phase=msg[0]
                    if phase=="scan":
                        _phase,done,total=msg
                        self["blue"].setText("%d / %d"%(done,total))
                        self["status"].setText(_("Scanning Live categories %d / %d")%(done,total))
                    elif phase=="cache":
                        _phase,done,total,cached,downloaded,unavailable=msg
                        self["blue"].setText("%d / %d"%(done,total))
                        self["status"].setText(_("Picons %d/%d • %d cached • %d downloaded • %d failed")%(
                            done,total,cached,downloaded,unavailable))
                    elif phase=="done":
                        _phase,done,total,cached,downloaded,unavailable=msg
                        self._live_picon_cache_running=False
                        self["blue"].setText(_("Cache Picons"))
                        self["status"].setText(_("Picons ready • %d/%d • %d cached • %d downloaded • %d failed")%(
                            done,total,cached,downloaded,unavailable))
                    elif phase=="error":
                        self._live_picon_cache_running=False
                        self["blue"].setText(_("Cache Picons"))
                        self["status"].setText(str(msg[1] if len(msg)>1 else _("Picon cache failed")))
                except Exception as exc:
                    optional_failure("ui.live_picon_cache_progress",exc)

    def _set_list_density(self, mode="root"):
        """Stable per-screen density. Never share cramped geometry across unrelated lists."""
        if mode == "root":
            self["list"].set_layout(72, 56, 31, 20, "double")
        elif mode == "genres" and str(getattr(self, "media_type", "") or "").lower() in ("vod", "series", "itv"):
            # Old 58px row and 24px title. The rail now runs down to the colour keys.
            self["list"].row_width = 800
            self["list"].set_layout(58, 36, 24, 19, "category_glass")
        elif mode == "genres":
            self["list"].row_width = max(434, int(getattr(self,"_category_row_card_w",426) or 426) + 8)
            if str(getattr(self, "media_type", "") or "").lower() in ("itv", "vod", "series"):
                # Approved Movies grammar copied verbatim to Series: floating
                # yellow folder + text only, no card/glass/pointer/animation.
                self["list"].set_layout(58, 36, 20, 14, "category_floating")
            else:
                self["list"].set_layout(66, 40, 22, 16, "category_portal")
        elif mode == "itv":
            cfg=getattr(self, "_grid_settings", None) or load_settings(); layout=cfg.get("channel_list_mode","epg")
            if layout == "large": self["list"].set_layout(70, 50, 27, 18, "channel")
            elif layout == "compact": self["list"].set_layout(52, 38, 23, 16, "single")
            else: self["list"].set_layout(62, 44, 24, 16, "channel")
        elif mode == "compact":
            self["list"].set_layout(54, 38, 25, 18, "compact_meta")
        else:
            self["list"].set_layout(56, 40, 26, 18, "compact_meta")

    def _browser_geom(self, name, x, y, w, h):
        """Move/resize one Browser widget using the same 1920x1080 design grid."""
        try:
            desktop=getDesktop(0).size(); sx=float(desktop.width())/1920.0; sy=float(desktop.height())/1080.0
            inst=self[name].instance
            if inst is not None:
                inst.move(ePoint(int(round(x*sx)), int(round(y*sy))))
                inst.resize(eSize(int(round(w*sx)), int(round(h*sy))))
        except Exception as exc:
            optional_failure("ui.browser_geom", exc)
