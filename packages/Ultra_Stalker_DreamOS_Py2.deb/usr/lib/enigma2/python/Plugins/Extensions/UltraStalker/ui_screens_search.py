# -*- coding: utf-8 -*-
"""Clean poster-first global Movies/Series search."""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .wqhd_layout import responsive_font as _ultra_rfont, factors as _ultra_factors

def _ultra_osd_scale():
    return _ultra_factors()[1]
from .us_env import str, int, max, min, us_casefold, us_func
hashlib = _us_env.hashlib
inspect = _us_env.inspect
os = _us_env.os
re = _us_env.re
queue = _us_env.queue
threading = _us_env.threading
time = _us_env.time
import unicodedata
urllib = _us_env.urllib
urllib = _us_env.urllib
from .core.shared_executors import VISIBLE_ARTWORK_EXECUTOR, VISIBLE_PROVIDER_ARTWORK_EXECUTOR
from .core.search_runtime import SearchCancel, SearchPosterFlights
from .title_clean import catalogue_title
OrderedDict = _us_env.collections.OrderedDict
import weakref
from enigma import gFont, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_VALIGN_CENTER
from Components.MultiContent import MultiContentEntryText
try:
    from Components.MultiContent import MultiContentEntryPixmapAlphaBlend
except ImportError:
    from Components.MultiContent import MultiContentEntryPixmapAlphaTest as MultiContentEntryPixmapAlphaBlend

from . import _
from Screens.Screen import Screen
try:
    from Screens.VirtualKeyBoard import VirtualKeyBoard
except Exception:
    VirtualKeyBoard = None
try:
    from Screens.InputBox import InputBox
except Exception:
    InputBox = None
try:
    from Screens.ChoiceBox import ChoiceBox
except Exception:
    ChoiceBox = None

from .ui_async import AsyncScreenMixin
from .ui_transition import TransitionMixin
from .persistent_cache import load_detail_snapshot, load_shared_detail_snapshot
from .ui_artwork_helpers import _image_url
from . import ui_image_loader as _uil
from .ui_parts.catalog import clean_display_text as _clean_display_text
from .category_visibility import hidden_ids as _hidden_category_ids
from .ui_settings_inline_choice import SettingsInlineChoiceOverlay
from .ui_settings_glass import SettingsGlassList, _png as _settings_cached_png
from .artwork_v2 import ArtworkV2, load_manifest as load_artwork_v2_manifest
from .ui_fixed_adaptive import fixed_home_assets
from .log import memory_snapshot as _mem34

SEARCH_SKIN = ""
_SEARCH_ART_EXECUTOR = VISIBLE_ARTWORK_EXECUTOR


_SRCH_EXTRA = (
    ' <widget name="srch_hdr" position="62,36" size="700,64" font="Regular;46" halign="left" valign="center" foregroundColor="#ffffff" transparent="1" noWrap="1" shadowColor="#000000" shadowOffset="1,1" zPosition="8"/>\n'
    ' <widget name="srch_sub" position="64,98" size="1100,34" font="Regular;22" halign="left" valign="center" foregroundColor="#c9ccd1" transparent="1" noWrap="1" shadowColor="#000000" shadowOffset="1,1" zPosition="8"/>\n'
    ' <widget name="sd_title" position="64,196" size="1300,46" font="Regular;34" halign="left" valign="center" foregroundColor="#ffffff" transparent="1" noWrap="1" shadowColor="#000000" shadowOffset="1,1" zPosition="8"/>\n'
    ' <widget name="sd_meta" position="64,246" size="1300,34" font="Regular;22" halign="left" valign="center" foregroundColor="#9fd6bf" transparent="1" noWrap="1" shadowColor="#000000" shadowOffset="1,1" zPosition="8"/>\n'
    ' <widget name="sd_desc" position="64,290" size="760,168" font="Regular;20" halign="left" valign="top" foregroundColor="#c9ccd1" transparent="1" shadowColor="#000000" shadowOffset="1,1" zPosition="8"/>\n'
)


# Search source selector: a narrow, top-right, in-screen premium Settings
# card. All eight complete 54px rows end above the first poster (y=664).
# Separate, pre-rendered assets avoid any per-key image scaling or loading.
_SOURCE_ROWS = 8
_SOURCE_ROW_WIDTH = 372
_SOURCE_ROW_HEIGHT = 54
_SEARCH_SOURCE_INLINE = (
    ' <widget name="source_panel" position="1478,24" size="412,602" alphatest="blend" transparent="1" zPosition="29"/>\n'
    ' <widget name="source_tile" position="1498,45" size="64,64" alphatest="blend" transparent="1" zPosition="30"/>\n'
    ' <widget name="source_icon" position="1510,57" size="40,40" alphatest="blend" transparent="1" zPosition="31"/>\n'
    ' <widget name="source_title" position="1575,48" size="284,60" font="Regular;25" halign="left" valign="center" foregroundColor="#ffffff" transparent="1" zPosition="31" shadowColor="#000000" shadowOffset="2,2"/>\n'
    ' <widget name="source_list" position="1498,125" size="372,432" foregroundColor="#ffffff" foregroundColorSelected="#ffffff" scrollbarMode="showNever" transparent="1" zPosition="32"/>\n'
    ' <widget name="source_hint" position="1498,565" size="372,35" font="Regular;18" halign="center" valign="center" foregroundColor="#9fd6bf" transparent="1" zPosition="31"/>\n'
)


from .label_align import halign as _lbl_h, valign as _lbl_v

class SearchSourceGlassList(SettingsGlassList):
    """Compact Search-only Settings rows; never touches the original Settings.

    Search owns the absolute selection index and supplies at most eight rows to
    the native eListbox. This is the same *windowed category* navigation
    grammar, with no hidden native viewport fighting the focus indicator.
    """

    def __init__(self):
        us_func(SettingsGlassList.__init__)(self, [], width=_SOURCE_ROW_WIDTH,
                                   item_height=_SOURCE_ROW_HEIGHT)
        self.l.setFont(30, _ultra_rfont("Regular", 21))
        self.l.setFont(31, _ultra_rfont("Regular", 20))

    def make_row(self, text, icon_path, data=None, secondary=""):
        meta = secondary if isinstance(secondary, dict) else {}
        selected = bool(meta.get("selected"))
        result = [data if data is not None else str(text or "")]
        png = _settings_cached_png("search_source_row_372x54_selected.png"
                                   if selected else "search_source_row_372x54.png")
        if png is not None:
            result.append(MultiContentEntryPixmapAlphaBlend(
                pos=(0, 0), size=(_SOURCE_ROW_WIDTH, _SOURCE_ROW_HEIGHT), png=png))
        title = " ".join(str(text or "").split())
        if len(title) > 25:
            title = title[:24].rstrip() + "…"
        result.append(MultiContentEntryText(
            pos=(12, 0), size=(229, _SOURCE_ROW_HEIGHT), font=30,
            flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER, text=title,
            color=0x00FFFFFF, color_sel=0x00FFFFFF))
        count = str(meta.get("value") or "")
        if count:
            result.append(MultiContentEntryText(
                pos=(242, 0), size=(115, _SOURCE_ROW_HEIGHT), font=31,
                flags=RT_HALIGN_RIGHT | RT_VALIGN_CENTER, text=count,
                color=0x9FD6BF if selected else 0xC9CCD1))
        from .wqhd_layout import scale_multicontent_row
        return scale_multicontent_row(result)


def configure_search_screen(**deps):
    globals().update(deps)
    for _mixin_module in _MIXIN_MODULES:
        _mixin_module.__dict__.update(deps)
    if "SEARCH_SKIN" in deps:
        _skin = str(deps["SEARCH_SKIN"] or "")
        if 'name="sd_title"' not in _skin:
            _skin = _skin.replace("</screen>", _wqhd_extra(_SRCH_EXTRA) + "</screen>", 1)
        if 'name="source_panel"' not in _skin:
            _skin = _skin.replace("</screen>", _wqhd_extra(_SEARCH_SOURCE_INLINE) + "</screen>", 1)
        PortalGlobalSearchScreen.skin = _skin


def _norm_search(value):
    return " ".join(us_casefold(str(value or "")).replace("_", " ").replace("-", " ").split())

def _canonical_search_title(value):
    """Raw provider-name identity for Search grouping.

    Search is intentionally exempt from Clean Names.  Quality/language/server
    decorations often distinguish different playable copies, so grouping on the
    cleaned catalogue title made several genuinely different rows look identical.
    We only normalize case and whitespace; raw decorations remain significant.
    """
    text = us_casefold(str(value or "").strip())
    return " ".join(text.split())

def _title_contains_query(item, term):
    raw = str((item or {}).get("name") or (item or {}).get("title") or "")
    needle = _norm_search(term)
    return bool(needle and needle in _norm_search(raw))

def _row_category_id(item):
    row = item if isinstance(item, dict) else {}
    return str(row.get("category_id") or row.get("genre_id") or row.get("category") or "").strip()

def _fast_client_search_detached(client, term, limit, cancel_event, settings, time_budget=5.0, max_pages=16, on_partial=None):
    if cancel_event is not None and cancel_event.is_set():return []
    settings=settings if isinstance(settings,dict) else {}
    fn=getattr(client,"search_content_fast",None) or getattr(client,"search_content",None)
    if callable(fn):
        budget = max(2.0, min(45.0, float(time_budget or 8.0)))
        kwargs = dict(media_types=("vod", "series"), limit=limit,
                      max_pages=min(int(max_pages or 16), int(settings.get("search_max_pages", 40) or 40)),
                      cancel_event=cancel_event, time_budget=budget, on_partial=on_partial)
        try:
            parameters = inspect.signature(fn).parameters
        except (TypeError, ValueError):
            parameters = None
        if parameters is not None:
            if "native_only" in parameters:
                kwargs["native_only"] = True
            if not any(p.kind == inspect.Parameter.VAR_KEYWORD for p in parameters.values()):
                kwargs = {k: v for k, v in kwargs.items() if k in parameters}
        # A real provider failure must be counted once, not silently followed
        # by another full catalogue scan (or a repeat after an internal TypeError).
        rows = fn(term, **kwargs) or []
        if "on_partial" not in kwargs and rows and callable(on_partial):
            on_partial(list(rows))
        return rows
    out=[];needle=_norm_search(term);deadline=time.monotonic()+max(1.0,float(time_budget or 5.0));max_local_pages=max(1,min(12,int(max_pages or 12)))
    for typ in ("vod","series"):
        if len(out)>=limit:break
        for page in range(1,max_local_pages+1):
            if time.monotonic()>=deadline or (cancel_event is not None and cancel_event.is_set()):break
            try:payload=client.ordered_page(typ,"*",page,cancel_event=cancel_event) or {}
            except Exception:break
            rows=[x for x in payload.get("items",[]) if isinstance(x,dict)]
            if not rows:break
            for raw in rows:
                hay=_norm_search(str(raw.get("name") or raw.get("title") or "")+" "+str(raw.get("description") or raw.get("descr") or ""))
                if needle and needle in hay:
                    item=dict(raw);item["_search_media_type"]=typ;out.append(item)
                    if callable(on_partial):
                        try:on_partial([dict(item)])
                        except Exception:pass
                    if len(out)>=limit:break
            if len(out)>=limit:break
    return out

def _valid(path):
    try:
        return bool(path and os.path.isfile(str(path)) and os.path.getsize(str(path)) > 100)
    except Exception:
        return False


# R5.205: search speed-ups. (1) per-source health memory so fast sources are tried
# first and dead/slow ones last; (2) short-lived result cache for repeated terms.
_SOURCE_HEALTH = {}          # profile key -> (finished_at, elapsed_seconds, failed)
_SEARCH_RESULT_CACHE = OrderedDict()   # query key -> (stored_at, rows, errors, count, mix, incomplete)
_SEARCH_CACHE_TTL = 600.0
_SEARCH_WORKERS = 10


def _source_health_rank(key, now=None):
    """0 = unknown/healthy-fast, larger = slower; recently failed sources go last."""
    hit = _SOURCE_HEALTH.get(key)
    if not hit:
        return 1.0
    now = time.time() if now is None else now
    finished, elapsed, failed = hit
    if failed and now - finished < 600.0:
        return 1000.0 + float(elapsed)
    return float(elapsed)


# Split: related method groups live in ui_search_mixin_*.py modules. They are imported here, after every module-level helper above exists,
# and listed BEFORE the other bases so they override them exactly like the methods that used to sit in this class body.
from .ui_search_mixin_lifecycle import SearchLifecycleMixin
from .ui_search_mixin_details import SearchDetailsMixin
from .ui_search_mixin_history import SearchHistoryMixin
from .ui_search_mixin_actions import SearchActionsMixin
from .ui_search_mixin_gateway import SearchGatewayMixin
from .ui_search_mixin_hooks import SearchHooksMixin
from .ui_search_mixin_rows import SearchRowsMixin
from .ui_search_mixin_keyboard import SearchKeyboardMixin
from .ui_search_mixin_query import SearchQueryMixin
from .ui_search_mixin_render import SearchRenderMixin
from .ui_search_mixin_posters import SearchPostersMixin
from .ui_search_mixin_picker import SearchPickerMixin
import sys as _split_sys
_MIXIN_MODULES = tuple(_split_sys.modules[_m.__module__] for _m in (SearchLifecycleMixin, SearchDetailsMixin, SearchHistoryMixin, SearchActionsMixin, SearchGatewayMixin, SearchHooksMixin, SearchRowsMixin, SearchKeyboardMixin, SearchQueryMixin, SearchRenderMixin, SearchPostersMixin, SearchPickerMixin,))


class PortalGlobalSearchScreen(
    SearchLifecycleMixin,
    SearchDetailsMixin,
    SearchHistoryMixin,
    SearchActionsMixin,
    SearchGatewayMixin,
    SearchHooksMixin,
    SearchRowsMixin,
    SearchKeyboardMixin,
    SearchQueryMixin,
    SearchRenderMixin,
    SearchPostersMixin,
    SearchPickerMixin,
    Screen,
    AsyncScreenMixin,
    TransitionMixin,
):
    skin = SEARCH_SKIN
    PAGE_SIZE = 7
    POSTER_SIZE = (206, 310)

    def __init__(self, session, profile, client):
        us_func(Screen.__init__)(self, session)
        self._async_init()
        self.onClose.append(self._stop_async)
        self.profile = profile
        self.client = client
        self.results = []
        # R52 Search hot path: keep pre-split grouped result lists beside the
        # authoritative all-results list. They contain the same group objects,
        # so switching/navigating Movies or Series never rescans/copies the
        # full federated result set.
        self._search_bucket_rows = {"vod": [], "series": []}
        self.query = ""
        self.index = 0
        # R51 Search gateway: the federated search engine still fills one shared
        # result list exactly as before.  This UI-only state decides whether the
        # user is looking at the two Home-style Movies/Series cards or one
        # filtered result bucket.
        self._search_gateway = False
        self._search_gateway_index = 0
        self._search_result_type = None
        self._search_gateway_visuals_bound = False
        self._search_partial_jobs = queue.Queue()
        self._poster_jobs = queue.Queue()
        self._poster_generation = 0
        self._poster_cancel_event = threading.Event()
        self._search_poster_flights = SearchPosterFlights()
        self._poster_futures = set()
        self._poster_ready_cache = OrderedDict()
        self._search_seen = set()
        self._search_groups = OrderedDict()
        self._search_errors = []
        self._search_portal_count = 0
        self._search_done_sources = 0
        self._search_last_shown_done = -1
        self._search_running = False
        self._search_source_mix = {"portal": 0, "xtream": 0}
        self._search_settings = {}
        self._search_generation = 0
        self._xtream_warm_generation = 0
        self._xtream_warm_cancel_event = threading.Event()
        self._xtream_warm_future = None
        self._render_signature = ()
        self._render_slot_signatures = [None] * self.PAGE_SIZE
        self._render_art_identities = [None] * self.PAGE_SIZE
        self._render_art_start = None
        self._render_selected_slot = None
        self["search_query"] = Label(_("Search"))
        self["srch_hdr"] = Label(_("SEARCH"));self["srch_sub"] = Label(_("Movies and series from all your sources"))
        self["sd_title"] = Label("");self["sd_meta"] = Label("");self["sd_desc"] = Label("")
        self._sd_cache = {}
        self["search_portal_hits"] = Label("")
        self["search_xtream_hits"] = Label("")
        self["search_portal_mix"] = Label("")
        self["search_mix_dot"] = Label("")
        self["search_xtream_mix"] = Label("")
        self._source_picker_active = False
        self._source_picker_stage = "servers"
        self._source_picker_buckets = []
        self._source_picker_entries = []
        self._source_picker_index = 0
        self._source_picker_top = 0
        self._source_picker_bucket = None
        self["source_panel"] = Pixmap()
        self["source_tile"] = Pixmap()
        self["source_icon"] = Pixmap()
        self["source_title"] = Label("")
        self["source_hint"] = Label("")
        self["source_list"] = SearchSourceGlassList()
        self["search_status"] = Label("")
        self["page_label"] = Label("")
        self["search_button_label"] = Label(_("Search"))
        self["menu_hint"] = Label(_("Recent searches"))
        self["menu_chip_label"] = Label(_("Menu"))
        # Exact Home/Favorites card component reused for the Search gateway.
        # Pixmaps are runtime-bound from fixed_home_assets(), so Search inherits
        # the same approved adaptive Home card/focus surfaces instead of owning
        # a parallel visual implementation.
        for i in range(2):
            self["search_root_bg%d" % i] = Pixmap()
            self["search_root_sel%d" % i] = Pixmap()
            self["search_root_icon%d" % i] = Pixmap()
            self["search_root_title%d" % i] = Label("")
            self["search_root_count%d" % i] = Label("")
        self._search_cursor_set = set()
        self._history_visible = False
        self._history_terms = []
        self._history_pending = None
        self._history_open_timer = eTimer()
        self._history_open_timer_conn = None
        try:
            self._history_open_timer_conn = self._history_open_timer.timeout.connect(self._history_open_deferred)
        except Exception:
            self._history_open_timer.callback.append(self._history_open_deferred)
        self.onClose.append(self._stop_history_open_timer)
        self._sd_pending_item = None
        self._sd_timer = eTimer()
        self._sd_timer_conn = None
        try:
            self._sd_timer_conn = self._sd_timer.timeout.connect(self._search_details_deferred)
        except Exception:
            self._sd_timer.callback.append(self._search_details_deferred)
        self.onClose.append(self._stop_sd_timer)
        _asset_root = os.path.join(os.path.dirname(__file__), "assets_fhd")
        self._history_overlay = SettingsInlineChoiceOverlay(
            self, "history_inline_list", "history_inline_actions",
            lambda name: os.path.join(_asset_root, str(name or "")), _,
            lambda *args, **kwargs: None, action_priority=-20000
        )
        for i in range(self.PAGE_SIZE):
            self["result_art%d" % i] = Pixmap()
            self["result_sel%d" % i] = Pixmap()
            self["result_title%d" % i] = Label("")
            self["result_meta%d" % i] = Label("")
        self["actions"] = ActionMap(
            ["OkCancelActions", "ColorActions", "DirectionActions", "MenuActions", "UltraStalkerMenuActions"],
            {
                "cancel": self._cancel_action,
                "red": self._cancel_action,
                "green": self._green_action,
                "menu": self._toggle_history,
                "ok": self._ok_action,
                "left": self._left_action,
                "right": self._right_action,
                "up": self._up_action,
                "down": self._down_action,
            },
            -1,
        )
        self._first_prompt_pending = True
        self._prompt_timer = eTimer()
        self._prompt_timer_conn = None
        try:
            self._prompt_timer_conn = self._prompt_timer.timeout.connect(self._open_first_prompt)
        except Exception:
            self._prompt_timer.callback.append(self._open_first_prompt)
        self.onClose.append(self._stop_prompt_timer)
        self.onClose.append(self._stop_search_hooks)
        self.onLayoutFinish.append(self._ready)
        self.onShown.append(self._shown)
        _mem34("search_init_done")


# R5.245: plugin-owned front-panel identity.
try:
    from .frontpanel_plugin import bind_plugin_front_summary as _bind_plugin_front_summary
    _bind_plugin_front_summary(PortalGlobalSearchScreen)
except Exception:
    pass


def _wqhd_extra(xml):
    from .wqhd_layout import scale_skin
    return scale_skin(xml)
