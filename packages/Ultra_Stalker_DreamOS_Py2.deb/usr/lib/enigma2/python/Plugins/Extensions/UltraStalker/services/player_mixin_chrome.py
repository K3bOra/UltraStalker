# -*- coding: utf-8 -*-
"""Adaptive chrome, memory fuse and hidden-visual timers.

Methods moved verbatim out of ``UltraStalkerPlayer`` (player_native.py); behaviour is unchanged.
This module is imported by player_native.py once its module-level helpers exist, so the
names below are taken from that module (partially initialised at this point) on purpose.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from ..us_env import str, int, us_clear
from .player_native import (
    _,
    _PROGRESS_FRAME_EXECUTOR,
    _PROGRESS_FRAME_LOCK,
    _PROGRESS_FRAME_PENDING,
    _adaptive_player_frames,
    _cached_poster,
    _fallback_player_frames,
    _laser_assets,
    _malloc_trim,
    _process_rss_kb,
    eTimer,
    gc,
    optional_failure,
    os,
    parseColor,
    runtime_breadcrumb,
)


class PlayerChromeMixin(object):
    """Adaptive chrome, memory fuse and hidden-visual timers."""

    def _memory_fuse_release_visuals(self, aggressive=False):
        # Playback service is deliberately left untouched. Only optional native
        # graphics/decoder helpers are released.
        # Never shed the core InfoBar glass.  With large portal libraries RSS can
        # already be above the old 430 MB threshold when Player opens; the old
        # fuse therefore stripped adaptive_main/keybar/chips a few seconds later
        # and left naked labels over video.  Only artwork/decorative layers are
        # disposable while playback continues.
        # Keep the core VOD/episode identity surfaces resident. They are small
        # compared with the video decoder and must survive InfoBar hide/show.
        # Only genuinely disposable live/progress pixmaps are shed here.
        for name in (
            "live_picon","adaptive_live_picon","progress_neon","progress_head"
        ):
            if name in ("progress_neon","progress_head"):
                self._laser_beam_path="";self._laser_head_path="";self._laser_end=-1
            try:
                widget=self[name]
                if widget.instance is not None:widget.instance.setPixmap(None)
                try:widget.hide()
                except Exception as exc:optional_failure("player.silent_guard",exc)
            except Exception as exc:optional_failure("player.silent_guard",exc)
        if aggressive:
            try:
                if hasattr(self.PicLoad.PictureData,"get"):self.PicLoad.PictureData.get().remove(self._decode_poster)
            except Exception as exc:optional_failure("player.silent_guard",exc)
            try:self.stream_info_timer.stop()
            except Exception as exc:optional_failure("player.silent_guard",exc)
        try:
            with _PROGRESS_FRAME_LOCK:us_clear(_PROGRESS_FRAME_PENDING)
        except Exception as exc:optional_failure("player.silent_guard",exc)
        try:gc.collect()
        except Exception as exc:optional_failure("player.silent_guard",exc)
        _malloc_trim()

    def _memory_fuse_tick(self):
        if self.restored or self._closing_playback:
            try:self.memory_fuse_timer.stop()
            except Exception as exc:optional_failure("player.silent_guard",exc)
            return
        rss=_process_rss_kb();self._memory_fuse_last_rss=rss
        if not rss:return
        # 430 MB: shed decorative native pixmaps and Python garbage.
        if rss >= 430*1024 and self._memory_fuse_level < 1:
            self._memory_fuse_level=1
            runtime_breadcrumb("player_memory_fuse",level=1,rss_kb=int(rss))
            self._memory_fuse_release_visuals(False)
        # 510 MB: stop all non-essential player image polling/decoding.
        if rss >= 510*1024 and self._memory_fuse_level < 2:
            self._memory_fuse_level=2
            runtime_breadcrumb("player_memory_fuse",level=2,rss_kb=int(rss))
            self._memory_fuse_release_visuals(True)
            try:self["connection"].setText(_("MEMORY PROTECTION  •  playback preserved"))
            except Exception as exc:optional_failure("player.silent_guard",exc)
        # 555 MB: protect Enigma2 itself. Better to leave the current Player
        # cleanly than let the kernel kill the entire GUI around 600 MB.
        if rss >= 555*1024 and not self._memory_fuse_emergency:
            self._memory_fuse_emergency=True
            runtime_breadcrumb("player_memory_fuse",level=3,rss_kb=int(rss))
            try:self["connection"].setText(_("MEMORY SAFETY EXIT"))
            except Exception as exc:optional_failure("player.silent_guard",exc)
            try:self._save_history_progress(force=True)
            except Exception as exc:optional_failure("player.silent_guard",exc)
            self._close_player(save_progress=False)

    def _pause_hidden_visual_timers(self):
        """Throttle purely visual/status polling while the InfoBar is hidden."""
        self._player_infobar_visible=False
        try:self.progress_visual_timer.stop()
        except Exception as exc:optional_failure("player.hidden_progress_visual_stop",exc)
        # Stream metadata is informational only. Keep a slow hidden refresh so
        # adaptive resolution changes are still learned without 1 Hz GUI I/O.
        if self.started and self._memory_fuse_level < 2 and not self.restored and not self._closing_playback:
            try:self.stream_info_timer.stop();self.stream_info_timer.start(5000,True)
            except Exception as exc:optional_failure("player.hidden_stream_info_throttle",exc)

    def _resume_hidden_visual_timers(self):
        """Restore normal visual/status cadence as soon as the InfoBar is shown."""
        self._player_infobar_visible=True
        if self.restored or self._closing_playback or not self.started:return
        if self._memory_fuse_level < 2:
            try:self.stream_info_timer.stop();self._update_stream_info()
            except Exception as exc:optional_failure("player.visible_stream_info_resume",exc)
        if self.media_type in ("vod","series","episode","catchup","trailer"):
            try:
                self.progress_visual_timer.stop();self._update_progress_visual();self.progress_visual_timer.start(1000,False)
            except Exception as exc:optional_failure("player.visible_progress_visual_resume",exc)

    def _restore_player_chrome_after_show(self):
        """Re-bind the exact glass pixmaps after every InfoBar show.

        Enigma2 can drop native pixmap surfaces while a Screen is hidden even
        though the Python widgets survive. Rebinding cached files is cheap and
        avoids regenerating adaptive artwork on every OK press.
        """
        if getattr(self,"restored",False) or getattr(self,"_closing_playback",False):return
        # Live picons can arrive asynchronously after playback starts. The old
        # InfoBar kept the neutral blue frames created at init forever, while the
        # later-opened Mini List already saw the real picon palette. Refresh from
        # the now-cached picon before rebinding the InfoBar. Generated frames are
        # persistent/cached, so subsequent OK presses do not redo image work.
        if self.media_type in ("itv","live"):
            try:
                palette_item=self.item
                if 0<=int(getattr(self,"_zap_index",0))<len(getattr(self,"_zap_channels",[]) or []):
                    row=(getattr(self,"_zap_channels",[]) or [])[int(self._zap_index)]
                    if isinstance(row,dict):palette_item=row
                live_art=_cached_poster(palette_item,self.name,self.media_type)
                self._load_live_picon(live_art)
                self._apply_adaptive_player_chrome()
            except Exception as exc:optional_failure("player.live_infobar_adaptive_refresh",exc)
        frames=dict(getattr(self,"_player_chrome_frames",{}) or _fallback_player_frames())
        mapping=(("main","adaptive_main"),("track","adaptive_progress_track"),("keybar","adaptive_keybar"))
        for key,name in mapping:
            try:
                path=frames.get(key)
                if path and os.path.isfile(path) and self[name].instance is not None:
                    self[name].instance.setPixmapFromFile(path);self[name].show()
            except Exception as exc:optional_failure("player.chrome_reshow",exc)
        self._hide_live_progress_strip()
        if self.media_type in ("itv","live"):
            # Adaptive chrome rebinds the shared progress-track pixmap. Re-apply
            # the Live-only layout immediately so EPG, not progress, owns that
            # strip every time the InfoBar is shown.
            try:self._apply_live_infobar_layout()
            except Exception as exc:optional_failure("player.live_layout_reshow",exc)
        self._fit_player_keybar_labels()
        self._bind_technical_glass_frames(force=True)
        self._sync_typographic_technical_row(force=True)
        # Artwork-specific chrome is restored without touching playback.
        try:
            if self.media_type in ("itv","live"):
                p=frames.get("live_picon")
                if p and os.path.isfile(p) and self["adaptive_live_picon"].instance is not None:
                    self["adaptive_live_picon"].instance.setPixmapFromFile(p);self["adaptive_live_picon"].show()
            else:
                # Poster is the bottom layer; both existing chrome layers sit above it.
                poster_path=str(getattr(self,"_poster_path","") or _cached_poster(self.item,self.name,self.media_type) or "")
                if poster_path and os.path.isfile(poster_path) and self["logo"].instance is not None:
                    self["logo"].instance.setPixmapFromFile(poster_path);self["logo"].show()
                p=frames.get("poster")
                if p and os.path.isfile(p) and self["adaptive_poster"].instance is not None:
                    self["adaptive_poster"].instance.setPixmapFromFile(p);self["adaptive_poster"].show()
        except Exception as exc:optional_failure("player.chrome_reshow_art",exc)
        if self.media_type not in ("itv","live") and not self._lb_active():
            try:
                for name in ("channel","category","quality","connection","now"):
                    try:self[name].hide()
                    except Exception:pass
                marker=self._episode_marker_text()
                if marker:
                    try:self["episode_marker"].setText(marker);self["episode_marker"].show()
                    except Exception:pass
                else:
                    try:self["episode_marker"].hide()
                    except Exception:pass
                logo=str(getattr(self,"_player_title_logo_path","") or "")
                if logo and os.path.isfile(logo) and self["title_logo"].instance is not None:
                    self["title_logo"].instance.setPixmapFromFile(logo);self["title_logo"].show();self["vod_title"].hide()
                else:
                    self["title_logo"].hide();self["vod_title"].show()
                self._episode_name_apply()
            except Exception as exc:optional_failure("player.title_reshow",exc)
        else:
            # R5.541: re-assert the Live bar after the shared chrome rebind above.
            self._live_bar_apply()

    def _apply_adaptive_player_chrome(self):
        try:
            palette_item=self.item
            if self.media_type in ("itv","live"):
                try:
                    if 0<=int(getattr(self,"_zap_index",0))<len(getattr(self,"_zap_channels",[]) or []):
                        row=(getattr(self,"_zap_channels",[]) or [])[int(self._zap_index)]
                        if isinstance(row,dict):palette_item=row
                except Exception:pass
            source=""
            if self.media_type not in ("itv","live") and isinstance(palette_item,dict):
                try:
                    candidate=str(palette_item.get("_ultra_palette_source") or palette_item.get("_adaptive_source_local") or "")
                    if candidate and os.path.isfile(candidate):source=candidate
                except Exception:pass
            if not source:source=_cached_poster(palette_item,self.name,self.media_type)
            self._player_chrome_source=str(source or "")
            fallback=_fallback_player_frames()
            # R5.17: never build Pillow chrome on the GUI thread while the Player
            # opens.  RAM hit -> immediate; otherwise paint the bundled glass now
            # and swap in the adaptive set when the background build finishes.
            # Same colour authority as Details: the title's library palette.
            # R5.177: the Player uses the same neutral glass as the rest of the
            # plugin (Home/Settings).  No poster-derived blue/green chrome, so
            # nothing changes colour after the Player opens.
            adaptive={}
            self._apply_player_frame_set(fallback,adaptive,source)
        except Exception as exc:optional_failure("player.adaptive_apply",exc)

    def _schedule_adaptive_player_chrome(self, source, palette=None):
        try:
            self._chrome_build_token=int(getattr(self,"_chrome_build_token",0) or 0)+1
            token=self._chrome_build_token;src=str(source or "")
            future=_PROGRESS_FRAME_EXECUTOR.submit(lambda:_adaptive_player_frames(src,palette))
            self._chrome_build_future=(token,src,future)
            timer=getattr(self,"_chrome_build_timer",None)
            if timer is None:
                timer=eTimer();self._chrome_build_timer=timer
                try:self._chrome_build_timer_conn=timer.timeout.connect(self._poll_adaptive_player_chrome)
                except Exception:timer.callback.append(self._poll_adaptive_player_chrome)
            timer.start(80,False)
        except Exception as exc:optional_failure("player.adaptive_schedule",exc)

    def _poll_adaptive_player_chrome(self):
        try:
            pending=getattr(self,"_chrome_build_future",None)
            if not pending:
                self._chrome_build_timer.stop();return
            token,src,future=pending
            if not future.done():return
            self._chrome_build_timer.stop();self._chrome_build_future=None
            if token!=getattr(self,"_chrome_build_token",0) or getattr(self,"restored",False) or getattr(self,"_closing_playback",False):return
            try:adaptive=future.result() or {}
            except Exception:adaptive={}
            if adaptive:self._apply_player_frame_set(_fallback_player_frames(),adaptive,src)
            else:self._adaptive_neon_ready=True  # build failed: fall back to the bundled accent
        except Exception as exc:optional_failure("player.adaptive_poll",exc)

    def _apply_player_frame_set(self, fallback, adaptive, source):
        try:
            self._player_chrome_applied_source=str(source or "") if adaptive else ""
            # Per-frame merge is deliberate.  A partially generated adaptive
            # set must never remove an otherwise valid neutral glass layer.
            frames=dict(fallback)
            if isinstance(adaptive,dict):
                for key,value in adaptive.items():
                    if value:
                        frames[key]=value
            self._player_chrome_frames=dict(frames)
            for key,name in (("main","adaptive_main"),("poster_halo","poster_neon_halo"),("poster","adaptive_poster"),("live_picon","adaptive_live_picon"),("track","adaptive_progress_track"),("keybar","adaptive_keybar")):
                path=frames.get(key)
                if path and os.path.isfile(path) and self[name].instance is not None:
                    self[name].instance.setPixmapFromFile(path);self[name].show()
                else:
                    # Only poster-specific decoration may disappear. Core glass
                    # should always exist from the bundled fallback assets.
                    if key in ("poster_halo","poster","live_picon"):
                        self[name].hide()
            self._hide_live_progress_strip()
            self._bind_technical_glass_frames(force=True)
            self._sync_typographic_technical_row()
            try:
                if self.media_type in ("itv","live"):
                    self["poster_neon_halo"].hide(); self["adaptive_poster"].hide();self["adaptive_live_picon"].show()
                    # R5.541: the Live bar carries its own picon card.
                    self._lb_suppress_legacy()
                else:
                    # VOD/episode layering is explicit and stable:
                    # real poster first, then the unchanged halo/frame layers above it.
                    self["adaptive_live_picon"].hide()
                    poster_path=str(getattr(self,"_poster_path","") or _cached_poster(self.item,self.name,self.media_type) or "")
                    if poster_path and os.path.isfile(poster_path) and self["logo"].instance is not None:
                        self["logo"].instance.setPixmapFromFile(poster_path);self["logo"].show()
                    self["poster_neon_halo"].hide()  # R5.195: no halo around the Player poster
                    self["adaptive_poster"].show()
                    self._lb_suppress_legacy()
            except Exception as exc:optional_failure("player.optional_guard",exc)
            accent=frames.get("accent") or "#b14b45"
            accent_soft=frames.get("accent_soft") or accent
            self._adaptive_accent_neon=frames.get("accent_neon") or accent_soft
            self._adaptive_neon_ready=True
            self._progress_neon_value=-1;self._laser_beam_path="";self._laser_head_path="";self._laser_end=-1
            try:_laser_assets(self._adaptive_accent_neon)  # warm the one-off beam/flare pair now
            except Exception:pass
            try:
                color=parseColor(accent)
                # Two-layer neon beam: a wide translucent aura plus a narrow white-hot
                # adaptive core.  No separate target/dot at the current position.
                hexrgb = accent.lstrip("#")
                # Status text follows the poster palette instead of fixed cyan.
                self["connection"].instance.setForegroundColor(parseColor(accent_soft))
                self["quality"].instance.setForegroundColor(parseColor(accent_soft))
            except Exception as exc: optional_failure("player.adaptive_colors",exc)
        except Exception as exc:optional_failure("player.adaptive_apply",exc)

    def _hide_live_progress_strip(self):
        """Live never shows the VOD progress strip (R5.132): hide it for good."""
        if self.media_type not in ("itv","live"):
            return
        for name in ("adaptive_progress_track","progress_neon","progress_head","buffer_glass","vod_progress","elapsed_time","total_time","remaining_time"):
            try:self[name].hide()
            except Exception:pass

    def _apply_live_infobar_layout(self):
        """Live-only compact layout: transparent Now/Next EPG owns the VOD progress strip."""
        if self.media_type not in ("itv","live"):
            if self._lb_active():
                self._live_bar_apply();return
            try:
                self["live_epg_now"].hide();self["live_epg_next"].hide();self["vod_progress"].show()
            except Exception:pass
            self._lb_hide()
            return
        for name in ("category","quality","now","connection","elapsed_time","total_time","remaining_time","adaptive_progress_track","progress_neon","progress_head","buffer_glass","vod_progress"):
            try:self[name].hide()
            except Exception:pass
        try:
            if not getattr(self,"_retry_visual_hold",False):
                self["retry_status"].setText("")
            self["retry_status"].show()
            if not self._lb_active():
                self["live_epg_now"].show();self["live_epg_next"].show()
        except Exception:pass
        # R5.541: the single Live InfoBar owns picon, title, chips, EPG and keys.
        self._live_bar_apply()
