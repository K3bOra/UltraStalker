# -*- coding: utf-8 -*-
"""Response tracking, catalogue generation and cache/mode-hint persistence.

Methods moved verbatim out of ``M3UClient`` (m3u_adapter.py); behaviour is unchanged.
This module is imported by m3u_adapter.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, open, max, OSError, us_clear
from .m3u_adapter import (
    LOG,
    _BoundedInfoCache,
    _CACHE_ROOT,
    _SERIES_PERSIST_EXECUTOR,
    _ensure_cache_root,
    _prepare_private_read,
    _private_replace,
    _safe_pickle_load,
    _unique_tmp,
    _us_abort_response,
    diagnostic_failure,
    hashlib,
    json,
    os,
    pickle,
    time,
    threading,
)


from .m3u_adapter import _MEM_LOCK

class M3UCacheMixin(object):
    """Response tracking, catalogue generation and cache/mode-hint persistence."""

    def _track_response(self,response):
        if response is None:return response
        with self._io_lock:
            self._active_responses.add(response)
        return response

    def _untrack_response(self,response):
        if response is None:return
        with self._io_lock:
            self._active_responses.discard(response)

    def _cancel_m3u_requests(self,permanent=False):
        # A cancelled Splash keeps its PortalSession for the next open. Cancel
        # the current generation without permanently closing that shared client.
        with self._epg_prepare_lock:
            self._epg_stop.set()
            if permanent:self._epg_closed=True
            if not self._epg_closed:
                self._epg_stop=threading.Event()
                self._epg_prepare_at=0.0
            with self._io_lock:
                responses=list(self._active_responses)
                us_clear(self._active_responses)
        for response in responses:
            try:_us_abort_response(response)
            except Exception:pass
            try:response.close()
            except Exception:pass
        return None

    def cancel_pending_requests(self):
        return self._cancel_m3u_requests()

    def close(self):
        return self._cancel_m3u_requests(permanent=True)

    def reset_failure_backoff(self):
        return None

    def _clear_catalogue_cache_files(self):
        """Remove this source's catalogue/index caches only; artwork stays untouched."""
        removed=0
        prefix=self._cache_key()
        paths=(self._cache_path(),self._fast_cache_path())
        for path in paths:
            try:
                if os.path.isfile(path):
                    os.unlink(path);removed+=1
            except OSError as exc:
                LOG.debug("M3U refresh cache remove failed %s: %s",os.path.basename(path),exc)
        try:
            if os.path.isdir(_CACHE_ROOT):
                cat_prefix=prefix+".cat."
                for name in os.listdir(_CACHE_ROOT):
                    if not (name.startswith(cat_prefix) and name.endswith(".pkl")):
                        continue
                    path=os.path.join(_CACHE_ROOT,name)
                    try:
                        if os.path.isfile(path):os.unlink(path);removed+=1
                    except OSError as exc:
                        LOG.debug("Xtream category refresh cache remove failed %s: %s",name,exc)
        except OSError as exc:
            LOG.debug("M3U refresh cache directory scan failed: %s",exc)
        return removed

    def _catalogue_cache_paths(self):
        """Every catalogue/index cache file that belongs to this source."""
        prefix=self._cache_key()
        paths=[self._cache_path(),self._fast_cache_path()]
        try:
            if os.path.isdir(_CACHE_ROOT):
                cat_prefix=prefix+".cat."
                for name in os.listdir(_CACHE_ROOT):
                    if name.startswith(cat_prefix) and name.endswith(".pkl"):
                        paths.append(os.path.join(_CACHE_ROOT,name))
        except OSError as exc:
            LOG.debug("M3U refresh cache directory scan failed: %s",exc)
        return paths

    def _stash_catalogue_cache_files(self):
        """Move this source's caches aside instead of deleting them.

        A refresh must not leave the user with no catalogue at all when the
        provider is down at that moment: the stash is discarded only after the
        fresh bootstrap succeeded and restored when it failed.
        """
        stash=[]
        for path in self._catalogue_cache_paths():
            try:
                if os.path.isfile(path) and not os.path.islink(path):
                    backup=path+".refresh-bak"
                    # A leftover from a crashed refresh is older than `path`.
                    if os.path.isfile(backup):
                        try:os.unlink(backup)
                        except OSError:pass
                    os.replace(path,backup)
                    stash.append((path,backup))
            except OSError as exc:
                LOG.debug("M3U refresh cache stash failed %s: %s",os.path.basename(path),exc)
        return stash

    def _discard_stashed_cache_files(self,stash):
        removed=0
        for path,backup in stash:
            try:
                os.unlink(backup);removed+=1
            except OSError as exc:
                LOG.debug("M3U refresh cache backup remove failed %s: %s",os.path.basename(backup),exc)
        return removed

    def _restore_stashed_cache_files(self,stash):
        for path,backup in stash:
            try:
                # A fresh file written by a partial bootstrap is not trusted;
                # the previous complete one wins.
                os.replace(backup,path)
            except OSError as exc:
                LOG.debug("M3U refresh cache restore failed %s: %s",os.path.basename(path),exc)

    def refresh_content(self,cancel_event=None):
        """Force a fresh M3U/Xtream catalogue bootstrap for this exact source.

        Direct M3U sources download and re-parse the playlist immediately. Xtream
        sources refresh account/category bootstrap and discard lazy category + rich
        series-info caches so the next folder/series open must hit the provider.
        Persistent artwork, TMDB metadata and title logos are intentionally preserved.
        """
        # Let any in-flight coalesced series persistence finish before deleting
        # this source's catalogue files, otherwise an older snapshot could win a
        # last-millisecond os.replace() after the explicit refresh starts.
        deadline=time.monotonic()+12.0
        self._bump_catalogue_generation()
        while True:
            with self._series_persist_lock:
                running=bool(self._series_persist_running)
                if not running:self._series_persist_dirty=False
            if not running:break
            if cancel_event is not None and cancel_event.is_set():
                raise RuntimeError("Content refresh cancelled")
            if time.monotonic()>=deadline:
                raise RuntimeError("Content refresh is waiting for catalogue storage to finish")
            time.sleep(0.05)
        with self._lock:
            snapshot={name:getattr(self,name) for name in (
                "_loaded","_loaded_at","_items","_genres","_series_index",
                "_xtream_categories","_xtream_category_ids","_xtream_loaded_categories",
                "_xtream_info_cache","_xtream_live_art_index","_xtream_series_name_index",
                "_last_error","_mode","_xtream_account","_live_epg_map","_live_native_refs","_xmltv_urls","_xmltv_header_pending")}
            ready_snapshot=set(getattr(self,"_xtream_category_ready",set()))
            stash=self._stash_catalogue_cache_files()
            self._xtream_category_ready=set()
            self._loaded=False;self._loaded_at=0.0
            self._items={"itv":[],"vod":[],"series":[]}
            self._genres={"itv":[],"vod":[],"series":[]}
            self._series_index={}
            self._xtream_categories={"itv":{},"vod":{},"series":{}}
            self._xtream_category_ids={"itv":{},"vod":{},"series":{}}
            self._xtream_loaded_categories={"itv":set(),"vod":set(),"series":set()}
            self._xtream_info_cache=_BoundedInfoCache()
            self._xtream_live_art_index=None
            self._xtream_series_name_index=None
            self._last_error=""
            try:
                self._ensure(cancel_event=cancel_event,force=True)
                if self._mode=="xtream":
                    for family in ("itv","vod","series"):
                        self.refresh_menu(family,cancel_event=cancel_event)
                    self._write_persistent()
            except BaseException:
                # Provider down / cancelled: keep what the user already had.
                self._restore_stashed_cache_files(stash)
                for name,value in snapshot.items():
                    setattr(self,name,value)
                self._xtream_category_ready=ready_snapshot
                raise
            removed=self._discard_stashed_cache_files(stash)
            mode=str(self._mode or "m3u").lower()
            # For Xtream, content lists are intentionally lazy. Their per-category
            # caches were deleted above, so every opened folder is now provider-fresh.
            # Direct M3U has already rebuilt all rows during _ensure(force=True).
            counts={k:len(v or []) for k,v in self._items.items()}
            categories={k:len(v or []) for k,v in self._genres.items()}
            genre_rows={k:[dict(row) if isinstance(row,dict) else row for row in (v or [])] for k,v in self._genres.items()}
            return {
                "ok":True,
                "source":"Xtream" if mode=="xtream" else "M3U",
                "mode":mode,
                "items":counts,
                "categories":categories,
                "genre_rows":genre_rows,
                "removed_catalogue_cache_files":removed,
            }

    def _cache_key(self):
        return hashlib.sha1(self.url.encode("utf-8","ignore")).hexdigest()

    def _generation_path(self):
        return os.path.join(_CACHE_ROOT, self._cache_key()+".gen")

    def _catalogue_generation(self):
        try:
            with open(self._generation_path(), "r", encoding="utf-8") as handle:
                return max(0, int((handle.read() or "0").strip() or "0"))
        except Exception:
            return 0

    def _bump_catalogue_generation(self):
        # Share publication ordering with category writers. Invalidation alone must
        # not destroy the state refresh_content is about to snapshot for rollback.
        ready=_ensure_cache_root()
        with _MEM_LOCK:
            gen=self._catalogue_generation()+1
            try:
                if ready:
                    path=self._generation_path();tmp=path+".tmp"
                    with open(tmp,"w",encoding="utf-8") as handle:handle.write(str(gen))
                    os.replace(tmp,path)
            except Exception as exc:LOG.debug("Xtream generation bump failed: %s",exc)
            self._applied_generation=gen
            return gen

    def _drop_stale_catalogue(self):
        """Drop RAM catalogue when another screen has refreshed this source."""
        gen = self._catalogue_generation()
        if getattr(self, "_applied_generation", None) == gen:
            return
        self._applied_generation = gen
        if self._mode=="xtream":
            self._xtream_category_ready=set()
            self._genres={"itv":[],"vod":[],"series":[]}
            self._xtream_categories={"itv":{},"vod":{},"series":{}}
            self._xtream_category_ids={"itv":{},"vod":{},"series":{}}
        self._items = {"itv": [], "vod": [], "series": []}
        self._series_index = {}
        self._xtream_loaded_categories = {"itv": set(), "vod": set(), "series": set()}
        self._xtream_info_cache = _BoundedInfoCache()

    def _cache_path(self):
        return os.path.join(_CACHE_ROOT,self._cache_key()+".json")

    def _fast_cache_path(self):
        return os.path.join(_CACHE_ROOT,self._cache_key()+".pkl")

    def _mode_path(self):
        return os.path.join(_CACHE_ROOT,self._cache_key()+".mode")

    def _read_mode_hint(self):
        try:
            path=self._mode_path()
            if os.path.isfile(path) and _prepare_private_read(path):
                with open(path,"r",encoding="utf-8") as f:
                    mode=str(f.read() or "").strip().lower()
                if mode in ("m3u","xtream"):
                    return mode

            # The old catalogue JSON already stored mode,
            # but there was no dedicated .mode file yet. Read only the marker,
            # then persist it in the new fast path.
            cache=self._cache_path()
            if os.path.isfile(cache) and _prepare_private_read(cache):
                with open(cache,"r",encoding="utf-8") as f:
                    data=json.load(f)
                mode=str(data.get("mode") or "").strip().lower() if isinstance(data,dict) else ""
                if mode in ("m3u","xtream"):
                    self._write_mode_hint(mode)
                    return mode
            return ""
        except (OSError,UnicodeError,json.JSONDecodeError,TypeError,ValueError) as exc:
            LOG.debug("M3U mode hint read failed: %s",exc)
            return ""

    def _write_mode_hint(self, mode):
        mode=str(mode or "").strip().lower()
        if mode not in ("m3u","xtream"):return
        tmp=""
        try:
            if not _ensure_cache_root():return
            path=self._mode_path();tmp=_unique_tmp(path)
            with open(tmp,"w",encoding="utf-8") as f:
                f.write(mode+"\n")
                f.flush();os.fsync(f.fileno())
            _private_replace(tmp,path)
        except (OSError,UnicodeError) as exc:
            LOG.warning("M3U mode hint write failed: %s",exc)
            try:
                if tmp and os.path.exists(tmp):os.unlink(tmp)
            except OSError:
                pass

    def _read_persistent(self):
        json_path=self._cache_path()
        fast_path=self._fast_cache_path()
        try:
            data=None
            source_path=""

            # Internal hot cache: same payload as JSON, much faster to decode on
            # low-power Enigma2 receivers with very large Xtream catalogues.
            if os.path.isfile(fast_path) and _prepare_private_read(fast_path):
                try:
                    with open(fast_path,"rb") as f:
                        candidate=_safe_pickle_load(f)
                    if isinstance(candidate,dict) and candidate.get("_fast_schema")==1:
                        data=candidate
                        source_path=fast_path
                except (OSError,pickle.PickleError,EOFError,TypeError,ValueError) as exc:
                    LOG.debug("M3U fast cache read failed: %s",exc)
                    data=None

            # Backward-compatible migration.
            if data is None:
                if not os.path.isfile(json_path) or not _prepare_private_read(json_path):return False
                with open(json_path,"r",encoding="utf-8") as f:
                    data=json.load(f)
                source_path=json_path
                if isinstance(data,dict):
                    try:self._write_fast_cache(data)
                    except Exception as exc: diagnostic_failure("m3u.failsoft", exc)

            if not isinstance(data,dict):return False
            cached_mode=str(data.get("mode") or self._mode or "m3u").lower()
            # M3U rows gained Xtream stream identity markers used for
            # provider picons/posters/backdrops. Old HDD catalogue rows cannot be
            # safely upgraded without their original stream URLs being re-parsed,
            # so rebuild this catalogue once while leaving artwork caches intact.
            try:catalog_schema=int(data.get("catalog_schema") or 0)
            except (TypeError, ValueError):catalog_schema=0
            if self._xtream and cached_mode=="m3u" and catalog_schema < 2:
                LOG.info("M3U catalogue schema upgrade required (%s -> 2)",catalog_schema)
                return False
            # Catalogue freshness is explicit (GREEN "Refresh Content" on Home, with a
            # visible "updated" stamp). Automatic expiry would re-download and re-parse
            # tens of MB on a low-RAM receiver, so no hidden TTL exists.
            self._items=data.get("items") or self._items
            self._genres=data.get("genres") or self._genres
            self._series_index=data.get("series_index") or {}
            self._xmltv_urls=list(data.get('xmltv_urls') or [])[:4]
            self._xmltv_header_pending=bool(data.get('xmltv_header_pending') or (cached_mode=='m3u' and catalog_schema<3))
            try:
                self._live_epg_map={str(r.get("id")):(str(r.get("stream_id") or ""),str(r.get("tvg_id") or ""),str(r.get("name") or ""))
                                    for r in (self._items.get("itv") or []) if isinstance(r,dict) and r.get("id")}
            except Exception:self._live_epg_map={}
            self._live_native_refs={}
            self._remember_epg_channels(self._items.get("itv",[]))
            self._xtream_categories=data.get("xtream_categories") or self._xtream_categories
            self._xtream_category_ids=data.get("xtream_category_ids") or {
                k:{name:cid for cid,name in (self._xtream_categories.get(k,{}) or {}).items()}
                for k in ("itv","vod","series")
            }
            self._mode=str(data.get("mode") or self._mode or "m3u")
            self._xtream_account=data.get("xtream_account") if isinstance(data.get("xtream_account"),dict) else self._xtream_account
            self._loaded=True;self._loaded_at=time.time()
            self._applied_generation=self._catalogue_generation()
            return True
        except Exception as exc:
            LOG.warning("M3U persistent cache read failed: %s",exc)
            return False

    def _write_fast_cache(self, payload):
        if not isinstance(payload,dict):return False
        tmp=""
        try:
            if not _ensure_cache_root():return False
            path=self._fast_cache_path();tmp=_unique_tmp(path)
            data=dict(payload);data["_fast_schema"]=1
            with open(tmp,"wb") as f:
                pickle.dump(data,f,protocol=pickle.HIGHEST_PROTOCOL)
                f.flush();os.fsync(f.fileno())
            _private_replace(tmp,path)
            return True
        except (OSError,pickle.PickleError,TypeError,ValueError) as exc:
            LOG.warning("M3U fast cache write failed: %s",exc)
            try:
                if tmp and os.path.exists(tmp):os.unlink(tmp)
            except OSError:
                pass
            return False

    def _write_persistent(self):
        tmp=""
        try:
            if not _ensure_cache_root():return False
            path=self._cache_path();tmp=_unique_tmp(path)
            payload={"catalog_schema":3,"items":self._items,"genres":self._genres,"series_index":self._series_index,
                     "xmltv_urls":getattr(self,'_xmltv_urls',[]) or [],
                     "xmltv_header_pending":bool(getattr(self,'_xmltv_header_pending',False)),
                     "mode":self._mode,"xtream_account":self._xtream_account,
                     "xtream_categories":self._xtream_categories,
                     "xtream_category_ids":self._xtream_category_ids}
            with open(tmp,"w",encoding="utf-8") as f:
                json.dump(payload,f,ensure_ascii=False,separators=(",",":"))
                f.flush();os.fsync(f.fileno())
            _private_replace(tmp,path)
            if not self._write_fast_cache(payload):
                # _read_persistent prefers the fast cache; a stale one would hide
                # the JSON that was just written.
                try:os.unlink(self._fast_cache_path())
                except OSError:pass
            return True
        except (OSError,UnicodeError,TypeError,ValueError) as exc:
            LOG.warning("M3U cache write failed: %s",exc)
            try:
                if tmp and os.path.exists(tmp):os.unlink(tmp)
            except OSError:
                pass
            return False

    def _series_persist_worker(self):
        while True:
            with self._series_persist_lock:
                if not self._series_persist_dirty:
                    self._series_persist_running=False
                    return
                self._series_persist_dirty=False
            self._write_persistent()

    def _schedule_series_persist(self):
        with self._series_persist_lock:
            self._series_persist_dirty=True
            if self._series_persist_running:
                return False
            self._series_persist_running=True
        try:
            _SERIES_PERSIST_EXECUTOR.submit(self._series_persist_worker)
            return True
        except Exception:
            with self._series_persist_lock:
                self._series_persist_running=False
            raise
