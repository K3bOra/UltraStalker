# -*- coding: utf-8 -*-
"""Runtime compatibility helpers for UltraStalker.

Keep this module free of Enigma2 imports so plugin discovery can diagnose a
broken/unsupported receiver image before importing the heavy UI/runtime tree.

Supported interpreters:
  * Python 3.8 and newer (OE-Alliance images, DreamOS OE2.6+)
  * Python 2.7 (DreamOS OE2.5) through the us_env compatibility layer
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str, int
os = _us_env.os
import platform
import sys

from . import us_env

MIN_PYTHON3 = (3, 8)
MAX_TESTED_PYTHON = (3, 15)
MAX_TESTED_PATCH = (3, 15, 0)
PYTHON2_SUPPORTED = ((2, 7),)
SUPPORTED_PYTHONS = PYTHON2_SUPPORTED + tuple((3, minor) for minor in range(8, 16))
# kept for callers that read it
MIN_PYTHON = (2, 7)


def python_version_tuple():
    info = sys.version_info
    return int(info[0]), int(info[1]), int(info[2])


def _gil_enabled():
    probe = getattr(sys, "_is_gil_enabled", None)
    if callable(probe):
        try:
            return bool(probe())
        except Exception:
            return True
    return True


def image_family():
    if us_env.IS_DREAMOS:
        return "DreamOS"
    return "OE-Alliance"


def python_compatibility():
    version = python_version_tuple()
    major_minor = version[:2]
    if major_minor[0] == 2:
        if major_minor in PYTHON2_SUPPORTED:
            status = "supported"
            supported = True
            message = "Python 2.7 compatibility mode (%s)" % image_family()
        else:
            status = "unsupported-old"
            supported = False
            message = "Python 2.7 or Python 3.8+ is required"
    elif major_minor < MIN_PYTHON3:
        status = "unsupported-old"
        supported = False
        message = "Python 2.7 or Python 3.8+ is required"
    elif major_minor in SUPPORTED_PYTHONS:
        if not _gil_enabled():
            status = "unsupported-free-threaded"
            supported = False
            message = "Free-threaded/no-GIL Python builds are not supported by Ultra Stalker on Enigma2"
        else:
            status = "supported"
            supported = True
            message = "Supported on Python 2.7 and Python 3.8 - 3.15 (standard GIL builds)"
    else:
        # Future CPython is allowed but reported as untested. Source-only code
        # should not brick plugin discovery just because the image moved ahead.
        status = "untested-newer"
        supported = True
        message = "Newer Python detected; running in forward-compatible mode"
    return {
        "version": "%d.%d.%d" % version,
        "status": status,
        "supported": supported,
        "message": message,
        "tested_min": "2.7 / 3.8",
        "tested_max": "%d.%d.%d" % MAX_TESTED_PATCH,
        "python2_mode": us_env.PY2,
        "image": image_family(),
        "python314_ready": major_minor == (3, 14),
        "python315_ready": major_minor == (3, 15),
        "gil_enabled": _gil_enabled(),
    }


def _module_available(name):
    """True when ``name`` can be imported, without importing it on Python 3."""
    if us_env.PY3:
        try:
            import importlib.util
            return importlib.util.find_spec(name) is not None
        except Exception:
            return False
    # Python 2: import it.  Everything checked here is imported by the plugin
    # anyway, and a real import also sees meta-path/zip/.pyo-only installs
    # that imp.find_module() misses.
    try:
        __import__(us_env.native_str(name))
        return True
    except Exception:
        pass
    try:
        import imp
        path = None
        parts = name.split(".")
        for index, part in enumerate(parts):
            prefix = ".".join(parts[:index + 1])
            if prefix in sys.modules:
                module = sys.modules[prefix]
                path = getattr(module, "__path__", None)
                if module is not None:
                    continue
            handle, filename, _desc = imp.find_module(us_env.native_str(part), path)
            if handle is not None:
                handle.close()
            path = [filename]
        return True
    except Exception:
        return False


def _package_names():
    if us_env.PY2:
        return {
            "sqlite3": "python-sqlite3",
            "pillow": "python-imaging",
            "twisted": "python-twisted-web",
        }
    return {
        "sqlite3": "python3-sqlite3",
        "pillow": "python3-pillow",
        "twisted": "python3-twisted",
    }


def dependency_report():
    """Check imports that correspond to package/runtime requirements.

    sqlite3, Pillow, Twisted and the Enigma2 base modules are fatal because
    the current artwork and Details/Backdrop UI graph imports them directly.
    Keep this list aligned with the package Depends field so a missing feed
    package produces a clear startup error instead of a later initialization
    failure.
    """
    checks = {
        "sqlite3": _module_available("sqlite3"),
        "pillow": _module_available("PIL.Image") or _module_available("PIL"),
        "twisted": all(_module_available(name) for name in ("twisted.internet", "twisted.web.client", "twisted.web.http_headers")),
        "enigma": _module_available("enigma"),
        "components": _module_available("Components"),
        "screens": _module_available("Screens"),
        "plugins": _module_available("Plugins.Plugin"),
    }
    names = _package_names()
    fatal = []
    if not checks["sqlite3"]:
        fatal.append("Python sqlite3 (package: %s)" % names["sqlite3"])
    if not checks["pillow"]:
        fatal.append("Pillow/PIL (package: %s)" % names["pillow"])
    if not checks["twisted"]:
        fatal.append("Twisted networking (package: %s)" % names["twisted"])
    if not checks["enigma"]:
        fatal.append("Enigma2 Python module (enigma)")
    if not checks["components"]:
        fatal.append("Enigma2 Components package")
    if not checks["screens"]:
        fatal.append("Enigma2 Screens package")
    if not checks["plugins"]:
        fatal.append("Enigma2 Plugins package")
    warnings = []
    tls = us_env.bridge_status().get("tls") or {}
    if tls.get("source") == "missing":
        warnings.append("No TLS root certificates found; HTTPS (TMDB, subtitles, HTTPS portals) will fail")
    if us_env.PY2:
        status = us_env.bridge_status()
        bridge = status.get("bridge") or {}
        if bridge.get("error"):
            warnings.append("Enigma2 text bridge: %s" % bridge.get("error"))
        elif int(bridge.get("locked") or 0) > 0:
            warnings.append("Enigma2 text bridge: %s SWIG methods could not be wrapped" % bridge.get("locked"))
        elif int(bridge.get("patched") or 0) < 20:
            warnings.append("Enigma2 text bridge patched only %s entry points" % bridge.get("patched"))
        fs = status.get("fs_encoding") or {}
        if str(fs.get("after") or "").lower().replace("-", "") != "utf8":
            warnings.append("File system encoding is %s (UTF-8 file names may fail)" % fs.get("after"))
    return {"checks": checks, "fatal": fatal, "warnings": warnings, "ok": not fatal}


def startup_preflight():
    py = python_compatibility()
    deps = dependency_report()
    fatal = list(deps["fatal"])
    warnings = list(deps["warnings"])
    if not bool(py["supported"]):
        fatal.insert(0, "%s (detected Python %s)" % (py["message"], py["version"]))
    elif py["status"] == "untested-newer":
        warnings.insert(0, "%s: Python %s" % (py["message"], py["version"]))
    return {
        "ok": not fatal,
        "python": py,
        "dependencies": deps,
        "fatal": fatal,
        "warnings": warnings,
    }


def format_preflight_error(report):
    fatal = list(report.get("fatal") or [])
    lines = ["Ultra Stalker cannot start on this receiver image.", ""]
    if fatal:
        lines.append("Missing or unsupported requirements:")
        lines.extend("- %s" % item for item in fatal)
    lines.extend(("", "Install/fix the listed requirement(s), then restart Enigma2."))
    return "\n".join(lines)


def runtime_capabilities():
    serviceapp_paths = (
        "/usr/lib/enigma2/python/Plugins/SystemPlugins/ServiceApp",
        "/usr/lib/enigma2/python/Plugins/Extensions/ServiceApp",
    )
    return {
        "python": platform.python_version(),
        "image": image_family(),
        "package_manager": us_env.PACKAGE_MANAGER,
        "enigma_module": _module_available("enigma"),
        "virtual_keyboard": _module_available("Screens.VirtualKeyBoard"),
        "audio_selection": _module_available("Screens.AudioSelection"),
        "subtitle_display": _module_available("Screens.SubtitleDisplay"),
        "serviceapp": any(os.path.exists(p) for p in serviceapp_paths),
        "gstplayer": os.path.exists("/usr/bin/gstplayer"),
        "exteplayer3": os.path.exists("/usr/bin/exteplayer3"),
    }


def require_supported_python():
    """Backward-compatible helper for callers outside plugin discovery."""
    result = python_compatibility()
    if not bool(result["supported"]):
        raise RuntimeError(str(result["message"]))
