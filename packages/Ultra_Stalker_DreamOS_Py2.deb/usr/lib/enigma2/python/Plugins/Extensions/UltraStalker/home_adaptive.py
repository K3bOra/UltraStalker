# -*- coding: utf-8 -*-
"""Home adaptive accent (R5.74).

The whole Home chrome (focus frame, the seven menu cards, the three Recent
panels and the selected Recent row) takes ONE accent colour from the current
hero: the title logo (brand colour, weighted x3) plus the backdrop.  The
original green glass assets are hue-shifted to that accent, so the look stays
identical and only the colour follows the film.

Built ONCE per (backdrop, logo) in a background thread and cached on disk;
later visits are a stat() + bind.  Nothing here ever runs on the GUI thread.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import int, open, max, min, OSError

import colorsys
hashlib = _us_env.hashlib
json = _us_env.json
os = _us_env.os
threading = _us_env.threading

from .log import optional_failure
from .persistent_cache import durable_view_path

_BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets_fhd", "fixed_master_r63")
PARTS = (
    ("focus", "home_menu_focus_254x206.png"),
    ("menu", "home_menu.png"),
    ("recent", "home_recent.png"),
    ("row_sel", "home_recent_row_selected.png"),
    ("row", "home_recent_row.png"),
    ("pbar", "home_recent_pbar_fill.png"),
)
VERSION = "home-accent-v6"
_LOCK = threading.Lock()


def _stamp(path):
    if not path:
        return "-"
    st = os.stat(path)
    return "%s|%d|%d" % (path, int(st.st_mtime), int(st.st_size))


def _key(source, logo):
    raw = "%s|%s|%s" % (_stamp(source), _stamp(logo), VERSION)
    return hashlib.sha1(raw.encode("utf-8", "ignore")).hexdigest()


def _meta_path(source, logo):
    try:
        k = _key(source, logo)
    except Exception:
        return None, None
    return k, durable_view_path("homeacc_%s.json" % k, source=source)


def _ok(path):
    try:
        return bool(path) and os.path.getsize(path) > 200
    except Exception:
        return False


def _usable(path):
    try:
        return bool(path) and os.path.isfile(path) and os.path.getsize(path) > 256
    except Exception:
        return False


def cached(source, logo=None):
    """GUI-safe: the finished result dict, or None when it is not built yet."""
    if not _usable(source):
        return None
    logo = logo if _usable(logo) else None
    _k, meta = _meta_path(source, logo)
    if not meta:
        return None
    try:
        with open(meta, "r") as h:
            row = json.load(h)
    except Exception:
        return None
    if not isinstance(row, dict):
        return None
    if row.get("none"):
        return {"none": True}
    for name, _f in PARTS:
        if not _ok(row.get(name)):
            return None
    return row


def _hue_votes(path, weight, votes, size):
    from PIL import Image
    img = Image.open(path)
    img.draft("RGB", (size * 2, size * 2))
    img = img.convert("RGBA")
    img.thumbnail((size, size))
    for r, g, b, a in img.getdata():
        if a < 140:
            continue
        h, s, v = colorsys.rgb_to_hsv(r / 255.0, g / 255.0, b / 255.0)
        if s < 0.16 or v < 0.14:
            continue
        w = s * v * weight
        slot = votes.setdefault(int(h * 24) % 24, [0.0, 0.0, 0.0, 0.0])
        slot[0] += w
        slot[1] += r * w
        slot[2] += g * w
        slot[3] += b * w


def pick_accent(source, logo=None):
    """Dominant saturated hue (logo x3 + backdrop); None for grey artwork."""
    votes = {}
    try:
        _hue_votes(source, 1.0, votes, 96)
    except Exception as exc:
        optional_failure("home.accent_backdrop", exc)
    if logo:
        try:
            _hue_votes(logo, 3.0, votes, 96)
        except Exception as exc:
            optional_failure("home.accent_logo", exc)
    if not votes:
        return None
    # merge each bin with its neighbours so a hue split across two bins wins
    best, best_w = None, 0.0
    for b in votes:
        w = sum(votes.get((b + d) % 24, (0,))[0] for d in (-1, 0, 1))
        if w > best_w:
            best, best_w = b, w
    if best_w < 3.0:
        return None
    acc = [0.0, 0.0, 0.0, 0.0]
    for d in (-1, 0, 1):
        s = votes.get((best + d) % 24)
        if s:
            for i in range(4):
                acc[i] += s[i]
    r, g, b = acc[1] / acc[0], acc[2] / acc[0], acc[3] / acc[0]
    h, s, v = colorsys.rgb_to_hsv(r / 255.0, g / 255.0, b / 255.0)
    s = min(0.86, max(0.50, s * 1.6))
    v = max(0.88, v)
    return h, s, v


def recolor(base_path, hue, sat):
    """Hue-shift one green glass asset; alpha and luminance stay untouched."""
    from PIL import Image
    img = Image.open(base_path).convert("RGBA")
    alpha = img.split()[3]
    hh, ss, vv = img.convert("RGB").convert("HSV").split()
    hh = Image.new("L", img.size, int(hue * 255) % 256)
    k = 0.10 if sat <= 0.01 else (0.6 + sat * 0.55)
    ss = ss.point(lambda x: min(255, int(x * k)))
    out = Image.merge("HSV", (hh, ss, vv)).convert("RGB")
    out.putalpha(alpha)
    return out


def _save(img, target):
    tmp = "%s.tmp.%d.%d" % (target, os.getpid(), threading.get_ident())
    try:
        from .persistent_cache import persistent_write_gate
        if not persistent_write_gate(target):
            return False
    except Exception:
        pass
    try:
        img.save(tmp, "PNG", optimize=True)
        os.replace(tmp, target)
        return True
    finally:
        try:
            if os.path.exists(tmp):
                os.unlink(tmp)
        except OSError:
            pass


def _write_meta(meta, row):
    tmp = "%s.tmp.%d" % (meta, threading.get_ident())
    try:
        with open(tmp, "w") as h:
            json.dump(row, h)
        os.replace(tmp, meta)
    except Exception as exc:
        optional_failure("home.accent_meta", exc)
        try:
            os.unlink(tmp)
        except OSError:
            pass


def build(source, logo=None):
    """Background only.  Returns the result dict ({"none":True} for grey art)."""
    hit = cached(source, logo)
    if hit:
        return hit
    if not _usable(source):
        return None
    logo = logo if _usable(logo) else None
    k, meta = _meta_path(source, logo)
    if not meta:
        return None
    with _LOCK:
        hit = cached(source, logo)
        if hit:
            return hit
        try:
            from .core.image_budget import image_work
            with image_work("home_accent"):
                picked = pick_accent(source, logo)
                if picked is None:
                    # grey / colourless artwork: Home keeps the fixed Palestine card set
                    _write_meta(meta, {"none": True})
                    return {"none": True}
                else:
                    h, s, v = picked
                    r, g, b = colorsys.hsv_to_rgb(h, min(0.55, s), 1.0)
                    row = {"color": "#%02x%02x%02x" % (int(r * 255), int(g * 255), int(b * 255))}
                if True:
                    for name, base in PARTS:
                        target = durable_view_path("homeacc_%s_%s.png" % (k, name), source=source)
                        if not _ok(target) and not _save(recolor(os.path.join(_BASE, base), h, s), target):
                            return None
                        row[name] = target
            _write_meta(meta, row)
            return cached(source, logo) or row
        except Exception as exc:
            optional_failure("home.accent_build", exc)
            return None
