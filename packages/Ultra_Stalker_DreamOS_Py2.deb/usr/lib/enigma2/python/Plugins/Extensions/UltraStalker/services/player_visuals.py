# -*- coding: utf-8 -*-
"""Player visual/artwork helpers.

Extracted from services.player to keep rendering/cache concerns separate from
the playback lifecycle. This module intentionally contains no Screen/player
state transitions.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .. import us_env as _us_env
from ..us_env import str, int, round, max, min, OSError

try:
    import colorsys
except Exception:
    from .. import compat_colorsys as colorsys

from ..core.image_budget import image_budgeted

hashlib = _us_env.hashlib
os = _us_env.os
re = _us_env.re
threading = _us_env.threading

try:
    from PIL import Image as _PILImage, ImageDraw as _ImageDraw, ImageFilter as _ImageFilter, ImageEnhance as _ImageEnhance
except Exception:
    _PILImage = None
    _ImageDraw = None
    _ImageFilter = None
    _ImageEnhance = None

from ..securefs import secure_private_dir
from ..persistent_cache import ROOT as PERSISTENT_CACHE_ROOT, GENERATED as PERSISTENT_GENERATED_DIR
from ..log import optional_failure
from ..core.executor import LazyThreadPoolExecutor
from ..ui_clean_glass import player_glass as _cg_player_glass, frame_ring as _cg_frame_ring, fill_mask as _cg_fill_mask, layer as _cg_layer, glass as _cg_glass

PLUGIN_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ASSET_DIR = os.path.join(PLUGIN_DIR, "assets_fhd")
PLAYER_ASSET_DIR = os.path.join(ASSET_DIR, "player")
PLAYER_FALLBACK_INFOBAR_DIR = os.path.join(PLAYER_ASSET_DIR, "infobar_premium")

_PROGRESS_FRAME_EXECUTOR = LazyThreadPoolExecutor(max_workers=1, thread_name_prefix="ultrastalker-progress")
_PROGRESS_FRAME_PENDING = set()
_PROGRESS_FRAME_LOCK = threading.RLock()

def _fallback_player_frames():
    """Bundled opaque Premium Player material.

    This is intentionally independent of poster/picon/HDD state.  It is the
    first-line player chrome so a late/missing adaptive source can never leave
    naked text and controls floating over video.
    """
    names=("main","poster","live_picon","track","keybar",
           "chip_quality","chip_video","chip_audio_codec",
           "chip_fps","chip_stream","chip_audio","chip_subtitles","chip_engine")
    out={}
    for name in names:
        path=os.path.join(PLAYER_FALLBACK_INFOBAR_DIR,"%s.png"%name)
        if os.path.isfile(path):
            out[name]=path
    out["accent"]="#6dcca1"
    out["accent_soft"]="#a8e3c8"
    out["accent_neon"]="#6dcca1"
    return out

@image_budgeted
def _adaptive_player_frames(source_path, accent_override=None, poster_halo_canvas=None, poster_art_size=None, poster_art_offset=None, cache_namespace=None):
    """Create player chrome with the exact floating-glass language used by Categories/Portal rows.

    Geometry stays identical to us226. Only the material changes: dark calm glass,
    restrained poster-derived tint, soft internal glow, polished inner rim and top sheen.
    """
    if _PILImage is None or _ImageDraw is None:
        return {}
    try:
        if not source_path or not os.path.isfile(source_path):
            return {}
        with _PILImage.open(source_path) as im:
            im = im.convert("RGB")
            im.thumbnail((96, 96))
            pixels = list(p for p in list(im.getdata()) if 28 < sum(p) / 3.0 < 230)
            if not pixels:
                return {}
            pixels.sort(key=lambda p: (max(p)-min(p)) + sum(p)/12.0, reverse=True)
            sample = pixels[:max(8, len(pixels)//8)]
            rgb = tuple(int(sum(px[i] for px in sample)/len(sample)) for i in range(3))
        rr, gg, bb = list(v/255.0 for v in rgb)
        h, l, sat = colorsys.rgb_to_hls(rr, gg, bb)
        sat = max(.38, min(.66, sat))
        l = max(.38, min(.54, l))
        rr, gg, bb = colorsys.hls_to_rgb(h, l, sat)
        accent = (int(rr*255), int(gg*255), int(bb*255))
        # Cinematic can lock the poster halo to the already-established page
        # adaptive colour. Player callers pass no override and keep existing behaviour.
        override=str(accent_override or "").strip().lstrip("#")
        if re.fullmatch(r"[0-9A-Fa-f]{6}",override):
            accent=tuple(int(override[i:i+2],16) for i in (0,2,4))
        # Secondary accent is a slightly softer/lighter cousin, same idea as category glass.
        accent2 = tuple(min(255, int(v*0.78 + 255*0.22)) for v in accent)
        base = (4, 12, 18)

        def mix(a, b, t):
            t = max(0.0, min(1.0, float(t)))
            return tuple(int(a[i]*(1.0-t) + b[i]*t) for i in range(3))

        cache = os.path.join(PERSISTENT_GENERATED_DIR,"player_glass241")
        secure_private_dir(cache)
        halo_canvas=tuple(poster_halo_canvas or (310,415))
        art_size=tuple(poster_art_size or (250,375))
        art_offset=tuple(poster_art_offset or (30,20))
        namespace=str(cache_namespace or "player")
        key = hashlib.sha1((source_path + str(os.path.getmtime(source_path)) + str(accent) + "|" + str(accent_override or "") + "|glass241-b95-exactchips-clean1-fps7|" + namespace + "|" + str(halo_canvas) + "|" + str(art_size) + "|" + str(art_offset)).encode("utf-8", "ignore")).hexdigest()[:16]
        out = {}

        specs = {
            # name: (size, radius, selected_like, fill_alpha, edge_alpha, glow_alpha)
            "main": ((1800,200), 26, True, 226, 238, 196),
            # Separate halo canvas. Defaults are unchanged for Player/Cinematic.
            # Details can request the same recipe at its native large-poster geometry.
            "poster_halo": (halo_canvas, 28, True, 0, 255, 255),
            "poster": ((270,395), 22, True, 0, 255, 255),
            "live_picon": ((240,152), 18, True, 118, 245, 188),
            "keybar": ((1600,58), 22, True, 232, 228, 178),
            "chip_quality": ((165,46), 15, False, 232, 226, 168),
            "chip_video": ((185,46), 15, False, 232, 226, 168),
            "chip_audio_codec": ((195,46), 15, False, 232, 226, 168),
            "chip_fps": ((150,46), 15, False, 232, 226, 168),
            "chip_stream": ((175,46), 15, False, 232, 226, 168),
            "chip_audio": ((170,46), 15, False, 232, 226, 168),
            "chip_subtitles": ((170,42), 15, False, 232, 226, 168),
            "chip_engine": ((287,46), 15, False, 232, 226, 168),
        }

        for name, (size, radius, selected, fill_alpha, edge_alpha, glow_alpha) in specs.items():
            if name != "poster_halo":
                # R5.424: all Player panels use the bundled premium material.
                # Preserve artwork halos and bypass old poster-tinted chrome caches.
                out[name] = os.path.join(PLAYER_FALLBACK_INFOBAR_DIR, "%s.png" % name)
                continue
            target = os.path.join(cache, "%s_%s.png" % (key, name))
            if not os.path.isfile(target):
                w, hh = size
                img = _PILImage.new("RGBA", size, (0,0,0,0))

                d = _ImageDraw.Draw(img)
                if name == "poster_halo":
                    # us242: renderer-safe poster neon. OpenBH on this box visibly
                    # drops/weakens soft semi-transparent Gaussian bloom. Use stepped,
                    # near-opaque adaptive energy bands baked into the SAME pixmap as
                    # the poster so the effect survives framebuffer composition.
                    ox,oy=int(art_offset[0]),int(art_offset[1])
                    aw,ah=int(art_size[0]),int(art_size[1])
                    poster_box = (ox, oy, ox+aw, oy+ah)
                    hot = mix(accent, (255,255,255), .62)
                    white_hot = mix(accent, (255,255,255), .92)
                    outer = mix(accent, (255,255,255), .28)

                    # Concentric anti-aliased energy bands (outside-in), one radius family.
                    for e_out, e_in, col, alpha in (
                        (15, 11, outer, 120),
                        (11, 8, accent, 170),
                        (8, 5, hot, 215),
                        (5, 3, hot, 245),
                        (3, -2, white_hot, 255),
                    ):
                        img = _PILImage.alpha_composite(img, _cg_frame_ring(size, poster_box, e_out, e_in, col, alpha))

                    # Bake the poster into the same pixmap with a smooth rounded window, so
                    # square artwork corners can never peek outside the rim.
                    try:
                        prepared = _prepare_player_poster_fill(source_path, art_size)
                        artwork_path = prepared if prepared and os.path.isfile(prepared) else source_path
                        with _PILImage.open(artwork_path) as art:
                            art = art.convert("RGBA")
                            if art.size != art_size:
                                res = getattr(getattr(_PILImage,"Resampling",_PILImage),"LANCZOS",1)
                                art = art.resize(art_size, res)
                            window = _cg_fill_mask((aw, ah), 16, 0, 3)
                            from PIL import ImageChops as _IC
                            art.putalpha(_IC.multiply(art.getchannel("A"), window))
                            img.alpha_composite(art, (ox, oy))
                        img = _PILImage.alpha_composite(img, _cg_frame_ring(size, poster_box, 1, -2, hot, 255))
                        img = _PILImage.alpha_composite(img, _cg_frame_ring(size, poster_box, 0, -1, white_hot, 255))
                        d = _ImageDraw.Draw(img)
                    except Exception as exc:
                        optional_failure("player.poster_composite", exc)
                elif name == "poster":
                    # The foreground frame is now deliberately clean.  All bloom is on
                    # poster_halo behind it, so nothing can be clipped by this 270x395 widget.
                    hot = mix(accent, (255,255,255), .72)
                    white_hot = mix(accent, (255,255,255), .94)
                    glass_corner = mix(base, accent, .13)
                    box = (10, 10, 260, 385)
                    for e_out, e_in, col, alpha in (
                        (1, -4, glass_corner, 250),      # bezel / mat hides square poster corners
                        (-3, -4, hot, 190),              # polished window rim
                        (2, 1, white_hot, 235),
                        (4, 2, hot, 255),
                        (7, 4, accent, 255),
                    ):
                        img = _PILImage.alpha_composite(img, _cg_frame_ring(size, box, e_out, e_in, col, alpha))
                    d = _ImageDraw.Draw(img)
                else:
                    img = _cg_player_glass(size, radius, accent, base, fill_alpha, edge_alpha, selected)
                    if name == "keybar":
                        kd = _ImageDraw.Draw(img)
                        sep = mix(accent, (255,255,255), .30)
                        # Subtle dividers create a real control dock rather than a long empty strip.
                        for xx in (235, 485, 755, 1045, 1345):
                            kd.line((xx,13,xx,hh-13), fill=sep + (72,), width=1)

                img.save(target, "PNG")
            out[name] = target

        # Neutral remaining track. The watched segment itself is rendered by a dedicated
        # neon pixmap so it can look like a laser/glow rather than a flat ProgressBar.
        track_target = os.path.join(cache, "%s_track.png" % key)
        if not os.path.isfile(track_target):
            w, hh = 1350, 8
            tmask = _cg_fill_mask((w,hh), 4, 0, 4)
            track = _cg_layer(tmask, (6,10,14), (12,18,24), 226, 226)
            from ..ui_clean_glass import ring_mask as _cg_ring_mask
            track = _PILImage.alpha_composite(track, _cg_layer(_cg_ring_mask((w,hh), 4, 0, 1, 4), mix(accent,(255,255,255),.28), mix(accent,(255,255,255),.10), 120, 90))
            track.save(track_target, "PNG")
        out["track"] = track_target
        out["accent"] = "#%02x%02x%02x" % accent
        out["accent_soft"] = "#%02x%02x%02x" % mix(accent, (255,255,255), .54)
        out["accent_neon"] = "#%02x%02x%02x" % mix(accent, (255,255,255), .32)
        return out
    except Exception as exc:
        optional_failure("player.adaptive_frames", exc)
        return {}

def _progress_neon_frame(accent_hex, value):
    """Render one cached laser-like watched-progress frame (0..100).

    The beam itself communicates progress; there is no detached dot/target. A compact
    white-hot flare at the leading edge is part of the beam, matching the supplied reference.
    """
    if _PILImage is None or _ImageDraw is None:
        return ""
    try:
        value=max(0,min(100,int(value)))
        hx=str(accent_hex or "#75d2ab").lstrip("#")
        if len(hx)!=6: hx="55b9ff"
        accent=tuple(int(hx[i:i+2],16) for i in (0,2,4))
        cache=os.path.join(PERSISTENT_GENERATED_DIR,"progress_neon239")
        secure_private_dir(cache)
        target=os.path.join(cache,"%s_%03d.png"%(hx,value))
        if os.path.isfile(target): return target
        w,h=1350,34
        img=_PILImage.new("RGBA",(w,h),(0,0,0,0))
        if value<=0:
            img.save(target,"PNG"); return target
        end=max(2,min(w-2,int(round((w-4)*value/100.0))))
        y=h//2
        # Broad atmospheric bloom.
        bloom=_PILImage.new("RGBA",(w,h),(0,0,0,0)); bd=_ImageDraw.Draw(bloom)
        bd.line((2,y,end,y),fill=accent+(205,),width=11)
        if _ImageFilter is not None: bloom=bloom.filter(_ImageFilter.GaussianBlur(radius=6))
        img=_PILImage.alpha_composite(img,bloom)
        # Tighter neon halo.
        halo=_PILImage.new("RGBA",(w,h),(0,0,0,0)); hd=_ImageDraw.Draw(halo)
        hd.line((2,y,end,y),fill=accent+(245,),width=7)
        if _ImageFilter is not None: halo=halo.filter(_ImageFilter.GaussianBlur(radius=2.8))
        img=_PILImage.alpha_composite(img,halo)
        d=_ImageDraw.Draw(img)
        hot=tuple(min(255,int(v*.48+255*.52)) for v in accent)
        core=tuple(min(255,int(v*.20+255*.80)) for v in accent)
        # Bright continuous core: the same premium laser language as the reference.
        d.line((2,y,end,y),fill=hot+(255,),width=4)
        d.line((2,y,end,y),fill=core+(255,),width=2)
        # Leading flare, not a separate point: a short comet bloom integrated into the beam.
        flare=_PILImage.new("RGBA",(w,h),(0,0,0,0)); fd=_ImageDraw.Draw(flare)
        fd.line((max(2,end-28),y,end+min(16,w-1-end),y),fill=core+(250,),width=5)
        fd.line((end,max(1,y-9),end,min(h-2,y+9)),fill=core+(210,),width=2)
        fd.ellipse((end-5,y-5,end+5,y+5),fill=(255,255,255,250))
        if _ImageFilter is not None: flare=flare.filter(_ImageFilter.GaussianBlur(radius=4.0))
        img=_PILImage.alpha_composite(img,flare)
        # Re-sharpen a tiny white-hot center within the flare.
        d=_ImageDraw.Draw(img); d.ellipse((end-2,y-2,end+2,y+2),fill=(255,255,255,255))
        img.save(target,"PNG")
        return target
    except Exception as exc:
        optional_failure("player.progress_neon",exc); return ""


def _schedule_progress_neon_frame(accent_hex,value):
    """Generate missing progress PNGs off Enigma2's GUI thread."""
    try:
        value=max(0,min(100,int(value)));hx=str(accent_hex or "#75d2ab").lstrip("#");key=(hx,value)
        cache=os.path.join(PERSISTENT_GENERATED_DIR,"progress_neon239");path=os.path.join(cache,"%s_%03d.png"%(hx,value))
        if os.path.isfile(path):return path
        with _PROGRESS_FRAME_LOCK:
            if key in _PROGRESS_FRAME_PENDING:return ""
            _PROGRESS_FRAME_PENDING.add(key)
        def work():
            try:return _progress_neon_frame("#"+hx,value)
            finally:
                with _PROGRESS_FRAME_LOCK:_PROGRESS_FRAME_PENDING.discard(key)
        _PROGRESS_FRAME_EXECUTOR.submit(work)
    except Exception as exc:optional_failure("player.progress_schedule",exc)
    return ""

def shutdown_player_workers(wait=False):
    try:_PROGRESS_FRAME_EXECUTOR.shutdown(wait=bool(wait),cancel_futures=True)
    except Exception as exc:optional_failure("player.progress_shutdown",exc)
def _asset(name):
    return os.path.join(ASSET_DIR, name)




NEXT_EPISODE_AUTOPLAY_SESSION = True









def _letter_logo(name, media_type):
    if media_type == "vod":
        return _asset("grid_placeholder_movie_921.png")
    if media_type in ("series", "episode"):
        return _asset("grid_placeholder_series_921.png")
    return _asset("us168_live_placeholder_220x132.png")



IMAGE_CACHE_DIR = os.path.join(PERSISTENT_GENERATED_DIR,"player_images")
try:
    secure_private_dir(IMAGE_CACHE_DIR)
except OSError:
    pass


def _image_value(item):
    if not isinstance(item, dict):
        return ""
    # VOD/Series player artwork must be the canonical external poster prepared
    # by the catalogue/details pipeline. Portal cover/screenshot fields are
    # deliberately ignored so the InfoBar can never resurrect low-quality art.
    media_type=str(item.get("_media_type") or item.get("media_type") or "").lower()
    keys=("_player_poster",) if media_type in ("vod","movie","series","episode") else ("_player_poster","logo","poster","poster_url","cover","cover_url","image","img")
    for key in keys:
        value=item.get(key)
        if value is not None and str(value).strip() and str(value).strip().lower() not in ("null","none"):
            return str(value).strip()
    return ""


def _cached_poster(item, name, media_type):
    is_live=str(media_type or "").lower() in ("itv","live")
    explicit_key="_player_picon" if is_live else "_player_poster"
    direct = str((item or {}).get(explicit_key) or (item or {}).get("_player_poster") or "").strip()
    if direct and os.path.isfile(direct):
        return direct
    value = _image_value(item)
    if value and os.path.isfile(value):
        return value
    # Prefer the absolute picon URL attached by the browser; its digest is the
    # same persistent HDD cache key used by the live grid.
    if is_live:
        picon_url=str((item or {}).get("_player_picon_url") or "").strip()
        if picon_url:value=picon_url
    if value.startswith(("http://", "https://")):
        digest = hashlib.sha1(value.encode("utf-8", "ignore")).hexdigest()
        roots=[IMAGE_CACHE_DIR]
        if is_live:
            roots.insert(0,os.path.join(PERSISTENT_CACHE_ROOT,"live_picons"))
        for root in roots:
            for ext in (".png", ".jpg", ".jpeg", ".webp"):
                candidate = os.path.join(root, digest + ext)
                if os.path.isfile(candidate) and os.path.getsize(candidate) > 100:
                    return candidate
    # Live must never show a generated initial/letter.  Until a real picon is
    # available use the neutral live asset; the card remains exactly 220x132.
    if is_live:
        return _asset("us168_live_placeholder_220x132.png")
    return _letter_logo(name, media_type)









@image_budgeted
def _prepare_player_poster_fill(source_path, size=(242,330)):
    """Reuse the master HDD poster directly; resizing stays in-memory at render time."""
    return source_path

@image_budgeted
def _prepare_live_picon(source_path, size=(220,132)):
    """Reuse the cached live picon directly; do not create a player-only picon file."""
    return source_path

