# -*- coding: utf-8 -*-
"""Hero visuals, settings materials and layout readiness.

Methods moved verbatim out of ``PortalListScreen`` (ui_screens_portallist.py); behaviour is unchanged.
This module is imported by ui_screens_portallist.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, round
from .ui_screens_portallist import (
    LOG,
    _,
    _portal_category_backdrop,
    cleanup_legacy_application_outputs,
    fixed_settings_rows,
    fixed_value_color,
    gFont,
    getDesktop,
    os,
    parseColor,
    time,
)


class PortalListMaterialsMixin(object):
    """Hero visuals, settings materials and layout readiness."""

    def _portal_hero_visuals(self):
        prepared = _portal_category_backdrop()
        ambient = ""
        return prepared, ambient

    @staticmethod
    def _portal_settings_icon(name):
        try:
            compact = asset("settings_icons_40/" + str(name or ""))
            if compact and os.path.isfile(compact):
                return compact
        except Exception as exc:
            optional_failure("ui.portal_settings_icon",exc)
        return asset("home_settings_line.png")

    def _apply_portal_settings_materials(self):
        _perf_all = time.monotonic()
        # Legacy Home/utility cleanup runs in selected-portal warmup.
        prepared, ambient = self._portal_hero_visuals()
        try:
            if ambient:
                self["ambient_bg"].instance.setPixmapFromFile(ambient); self["ambient_bg"].show()
            else:
                self["ambient_bg"].hide()
        except Exception as exc:
            optional_failure("ui.portal_settings_ambient", exc)

        # PERF28: On the target OpenBH renderer the skin-level page_bg is not
        # the visible Portal List backdrop.  hero_backdrop is the actual painted
        # layer.  PERF27 hid it and therefore removed the approved Palestine
        # background.  Restore the proven R26 visual path exactly; keep the
        # surrounding cache-first row work and timing instrumentation intact.
        _phase = time.monotonic()
        try:
            if prepared and os.path.isfile(prepared):
                self["hero_backdrop"].instance.setPixmapFromFile(prepared)
                self["hero_backdrop"].show()
            else:
                self["hero_backdrop"].hide()
        except Exception as exc:
            optional_failure("ui.portal_settings_backdrop", exc)
        LOG.info("PERF28 portals backdrop_restore elapsed_ms=%d", int((time.monotonic() - _phase) * 1000))

        _phase = time.monotonic()
        generated = False
        try:
            chrome = fixed_settings_rows() or {}
            normal = str(chrome.get("normal") or "")
            selected = str(chrome.get("selected") or "")
            if normal and os.path.isfile(normal):
                self._portal_row_asset = normal
            if selected and os.path.isfile(selected):
                self._portal_row_selected_asset = selected
            self._portal_value_color = int(chrome.get("value_color") or fixed_value_color(self._portal_value_color))
            _accent=parseColor("#%06x" % (int(self._portal_value_color)&0xFFFFFF))
            for _name,_size in (("check_progress",20),("portal_page",20)):
                try:
                    _inst=self[_name].instance
                    if _inst is not None:
                        _inst.setForegroundColor(parseColor("#f0ece2") if _name=="portal_page" else _accent)
                        _inst.setFont(_ultra_rfont("Regular",_size))
                except Exception:pass
            # The list was first painted during __init__; force a physical row
            # rebuild so no legacy blue fallback pixmap can survive that first paint.
            for _name in ("list","source_badges"):
                try:self[_name]._render_row_signatures=None
                except Exception:pass
        except Exception as exc:
            optional_failure("ui.portal_settings_material", exc)
        LOG.info("PERF27 portals row_chrome elapsed_ms=%d generated=%s", int((time.monotonic() - _phase) * 1000), "yes" if generated else "no")

        _phase = time.monotonic()
        for name in ("list", "source_badges"):
            try:
                if self[name].instance is not None:
                    self[name].instance.setSelectionEnable(0)
                    self[name].instance.setTransparent(1)
                    self[name].instance.setScrollbarMode(2)
            except Exception as exc:
                optional_failure("ui.portal_settings_list_native", exc)
        LOG.info("PERF27 portals native_list elapsed_ms=%d total_ms=%d", int((time.monotonic() - _phase) * 1000), int((time.monotonic() - _perf_all) * 1000))

    def _layout_ready(self):
        _perf_t0 = time.monotonic()
        self._image_layout_ready()
        _phase = time.monotonic()
        self._apply_portal_settings_materials()
        LOG.info("PERF25 portals layout_materials elapsed_ms=%d", int((time.monotonic() - _phase) * 1000))
        self._hide_check_notice()
        # Test69 Lean: profiles were already loaded in __init__. Repainting is
        # enough; avoid a second synchronous disk parse during first layout.
        _phase = time.monotonic()
        self.refresh()
        self._fit_portal_color_keys()
        LOG.info("PERF25 portals layout_refresh elapsed_ms=%d", int((time.monotonic() - _phase) * 1000))
        notices = consume_recovery_notices()
        if notices:
            self["status"].setText(_("Recovered malformed data safely • %s") % notices[-1])
        LOG.info("PERF25 portals layout_done elapsed_ms=%d mono_ms=%d", int((time.monotonic() - _perf_t0) * 1000), int(time.monotonic() * 1000))

from .wqhd_layout import responsive_font as _ultra_rfont, factors as _ultra_factors

def _ultra_osd_scale():
    return _ultra_factors()[1]
