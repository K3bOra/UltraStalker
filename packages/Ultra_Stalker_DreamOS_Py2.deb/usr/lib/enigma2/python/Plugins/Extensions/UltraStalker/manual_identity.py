"""Source-scoped user choices. Playback identity and global title aliases stay separate."""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str, int, open, OSError, us_clear
OrderedDict = _us_env.collections.OrderedDict
hashlib = _us_env.hashlib
json = _us_env.json
os = _us_env.os
re = _us_env.re
threading = _us_env.threading
time = _us_env.time
import uuid
from .verified_identity import media_kind, positive_id

_LOCK=threading.RLock()
_CACHE=OrderedDict()
_LIMIT=2048
# Per-key serialization keeps slow storage out of the global RAM-cache lock.
_IO_LOCKS=tuple(threading.RLock() for _ in range(64))
MAX_BACKUP_CHOICES=16384

def clear_memory():
    with _LOCK:us_clear(_CACHE)

def validate_backup_snapshot(value):
    if not isinstance(value,dict) or value.get('schema')!=1 or not isinstance(value.get('choices'),dict):
        raise ValueError('Invalid manual matching snapshot')
    if len(value['choices'])>MAX_BACKUP_CHOICES:raise ValueError('Too many manual matching choices')
    out={}
    for key,row in value['choices'].items():
        if not isinstance(key,str) or not re.fullmatch(r'[0-9a-f]{64}',key):raise ValueError('Invalid manual matching key')
        if not isinstance(row,dict) or row.get('schema')!=1 or row.get('owner')!=key:
            raise ValueError('Invalid manual matching owner')
        revision=row.get('revision')
        if not isinstance(revision,str) or not re.fullmatch(r'[0-9a-f]{32}',revision):raise ValueError('Invalid manual matching revision')
        if not isinstance(row.get('active'),bool):raise ValueError('Invalid manual matching state')
        clean={'schema':1,'owner':key,'revision':revision,'active':row['active'],'updated_at':int(row.get('updated_at') or 0)}
        if row['active']:
            ident=positive_id(row.get('tmdb_id'));kind=row.get('media_type')
            if not ident or kind not in ('movie','tv'):raise ValueError('Invalid manual matching identity')
            clean.update(tmdb_id=int(ident),media_type=kind,title=str(row.get('title') or '')[:300],year=str(row.get('year') or '')[:4])
        out[key]=clean
    return out

def backup_snapshot():
    from .storage import CONFIG_DIR,STATE_IO_LOCK
    folder=os.path.join(CONFIG_DIR,'manual_tmdb');rows={}
    with STATE_IO_LOCK:
        if os.path.islink(folder):raise ValueError('Unsafe manual matching directory')
        if os.path.isdir(folder):
            for name in sorted(os.listdir(folder)):
                if not re.fullmatch(r'[0-9a-f]{64}\.json',name):continue
                path=os.path.join(folder,name)
                if os.path.islink(path) or not os.path.isfile(path) or os.path.getsize(path)>65536:
                    raise ValueError('Unsafe manual matching file')
                with open(path,'r',encoding='utf-8') as handle:rows[name[:-5]]=json.load(handle)
                if len(rows)>MAX_BACKUP_CHOICES:raise ValueError('Too many manual matching choices')
        return {'schema':1,'choices':validate_backup_snapshot({'schema':1,'choices':rows})}

def _io_lock(key):
    return _IO_LOCKS[int(key[:8],16)%len(_IO_LOCKS)]

def _remember(key,row):
    # Caller owns _LOCK; storage reads/writes never do.
    _CACHE[key]=row;_CACHE.move_to_end(key)
    while len(_CACHE)>_LIMIT:_CACHE.popitem(last=False)

def original(item):
    item=item if isinstance(item,dict) else {}
    return dict(item.get('_manual_original') or item)

def source_key(profile,media_type,item):
    source=original(item);profile=profile or {}
    ident=None
    keys=('series_id','id','series_uid') if media_kind(media_type)=='tv' else ('movie_id','id','video_id','stream_id')
    for key in keys+('cmd','command','url'):
        if source.get(key) not in (None,''):
            value=str(source[key])
            if key in ('cmd','command','url'):ident=['stream',value]
            else:
                if source.get('_xtream'):
                    for prefix in ('xt-vod-','xt-series-'):
                        if value.startswith(prefix):value=value[len(prefix):];break
                ident=['provider-id',value]
            break
    if ident is None:
        ident=['title',source.get('_raw_name') or source.get('name') or source.get('title') or '',
               source.get('category_id') or source.get('category') or '']
    account=[profile.get(k) or '' for k in ('portal','mac','username','password','url','playlist_url')]
    raw=json.dumps([account,media_kind(media_type),ident],ensure_ascii=False,separators=(',',':'))
    return hashlib.sha256(raw.encode('utf-8')).hexdigest()

def _path(key):
    from .storage import CONFIG_DIR
    return os.path.join(CONFIG_DIR,'manual_tmdb',key+'.json')

def choice(profile,media_type,item):
    if str(media_type).lower() not in ('vod','movie','movies','series','tv'):return {}
    key=source_key(profile,media_type,item)
    with _LOCK:
        if key in _CACHE:
            _CACHE.move_to_end(key);return dict(_CACHE[key])
    # Recheck after acquiring the per-key lock: a concurrent writer may have
    # published a new revision while this cold reader was waiting.
    with _io_lock(key):
        with _LOCK:
            if key in _CACHE:
                _CACHE.move_to_end(key);return dict(_CACHE[key])
        row={}
        try:
            with open(_path(key),'r',encoding='utf-8') as f:row=json.load(f)
            if not isinstance(row,dict) or row.get('schema')!=1 or row.get('owner')!=key or not row.get('revision'):row={}
            if row.get('active') and (not positive_id(row.get('tmdb_id')) or row.get('media_type') not in ('movie','tv')):row={}
        except (OSError,ValueError):row={}
        with _LOCK:_remember(key,row)
        return dict(row)

def set_choice(profile,media_type,item,result=None):
    if str(media_type).lower() not in ('vod','movie','movies','series','tv'):raise ValueError('Unsupported content type')
    key=source_key(profile,media_type,item)
    row={'schema':1,'owner':key,'revision':uuid.uuid4().hex,'active':result is not None,'updated_at':int(time.time())}
    if result is not None:
        ident=positive_id(result.get('tmdb_id') or result.get('id'));kind=media_kind(result.get('media_type'))
        if not ident or kind not in ('movie','tv'):raise ValueError('Invalid TMDb selection')
        row.update(tmdb_id=int(ident),media_type=kind,title=str(result.get('title') or result.get('name') or '')[:300],
                   year=str(result.get('release_date') or result.get('first_air_date') or result.get('year') or '')[:4])
    path=_path(key)
    from .storage import STATE_IO_LOCK
    with STATE_IO_LOCK,_io_lock(key):
        os.makedirs(os.path.dirname(path),mode=0o700,exist_ok=True)
        temp=path+'.tmp.'+uuid.uuid4().hex
        try:
            fd=os.open(temp,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
            with os.fdopen(fd,'w',encoding='utf-8') as f:
                json.dump(row,f,ensure_ascii=False,separators=(',',':'));f.flush();os.fsync(f.fileno())
            os.replace(temp,path)
            try:
                directory=os.open(os.path.dirname(path),os.O_RDONLY)
                try:os.fsync(directory)
                finally:os.close(directory)
            except OSError:pass
            with _LOCK:_remember(key,row)
        finally:
            try:os.unlink(temp)
            except OSError:pass
    return dict(row)


def cache_token(profile,media_type,item):
    return str(choice(profile,media_type,item).get('revision') or '')

_CLEAR=('tmdb_id','tmdb','tmdbid','imdb_id','imdb','tvdb_id','tvdb','_locked_tmdb_id','_locked_tmdb_type',
 '_ultra_search_verified_tmdb_id','_local_name_first_identity','_local_media','_tmdb_rating',
 'identity_verified','identity_pointer_verified','identity_source','identity_confidence','identity_evidence',
 'matched','_details_authority_ready','item_overlay','imdb_data',
 'overview','overview_language','description','description_full','descr','plot','tagline',
 'genre','genres','cast','actors','crew','country','countries','production_companies','production',
 'networks','network','creators','last_air_date','in_production','budget','revenue',
 'country_code','origin_country','production_countries','production_country','original_language',
 '_origin_country','_origin_language','origin_countries','region','english_name','english_title','o_name',
 'original_title','original_name','year','release_year','release_date','releaseDate','first_air_date',
 'rating','rating_imdb','imdb_rating','imdb_score','tmdb_rating','vote_average','vote_count',
 'runtime','duration','time','length','director','directors','writer','writers','creator','created_by',
 'actor','certification','age_rating','number_of_seasons',
 'number_of_episodes','episodes_count','episode_count','seasons_count','season_count','_details_provider_metadata',
 'poster','poster_path','poster_url','poster_local','cover','cover_url','cover_big','movie_image','logo','logo_path','logo_url',
 'backdrop','backdrop_url','backdrop_path','backdrop_local','stream_icon','_ultra_search_snapshot')

def apply_choice(profile,media_type,item):
    src=original(item);row=choice(profile,media_type,src)
    if not row:
        src['_manual_identity_revision']=''
        return src
    out=dict(src)
    if row.get('active'):
        for key in list(out):
            if key in _CLEAR or key.startswith(('_cin_','_visible_provider_','_rescue_provider_',
                    '_ultra_poster','_ultra_palette','_player_poster','_backdrop_source','_adaptive_',
                    '_details_','_locked_tmdb','_manual_','_search_',
                    '_ultra_fast_','_ultra_detail_','_ultra_visible_')):out.pop(key,None)
        out.update(_locked_tmdb_id=row['tmdb_id'],_ultra_search_verified_tmdb_id=row['tmdb_id'],
                   _locked_tmdb_type=row['media_type'],_manual_tmdb_selection=dict(row))
        out['_manual_original']=src
    else:
        for key in list(out):
            if key.startswith('_manual_'):out.pop(key,None)
    out['_manual_identity_revision']=row['revision']
    return out

def allows_write(profile,media_type,item,data):
    row=choice(profile,media_type,item)
    if not row:return True
    if (item or {}).get('_manual_identity_revision')!=row['revision']:return False
    if not row.get('active'):return True
    return positive_id((data or {}).get('tmdb_id'))==str(row['tmdb_id']) and media_kind((data or {}).get('media_type'))==row['media_type']

def selected(item):
    row=(item or {}).get('_manual_tmdb_selection') or {}
    return row if row.get('active') and positive_id(row.get('tmdb_id')) and row.get('media_type') in ('movie','tv') else {}

def changed_since_paint(owner):
    return any(cache_token(owner.profile,owner.media_type,item)!=item.get('_manual_identity_revision','')
               for item in getattr(owner,'grid_items',[]) if isinstance(item,dict))
