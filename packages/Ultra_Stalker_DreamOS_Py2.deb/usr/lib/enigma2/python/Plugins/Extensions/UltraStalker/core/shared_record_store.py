"""Bounded shared records: accepted dirty writes are retained until published."""
from __future__ import absolute_import, division, print_function, unicode_literals
from .. import us_env as _us_env
from ..us_env import int, open, max, OSError, us_clear
__metaclass__ = type  # new-style classes on Python 2
import copy
json = _us_env.json
os = _us_env.os
re = _us_env.re
threading = _us_env.threading
time = _us_env.time
OrderedDict = _us_env.collections.OrderedDict
from ..persistent_cache import hdd_ready, hdd_read_ready, ensure_persistent_dirs, persistent_write_gate


class PendingWriteLimitError(BufferError):
    """New data was not accepted; existing unpublished records remain intact."""


class SharedRecordStore:
    def __init__(self, directory, limit=256, merge=None, pending_limit=4096,
                 pending_bytes=4*1024*1024, miss_ttl=3.0):
        self.directory=directory
        self.limit=max(1,int(limit))
        self.lock=threading.RLock()
        self.ram=OrderedDict();self.dirty=OrderedDict()
        self.worker=None;self.merge=merge;self.retry_seconds=5.0
        self.pending_limit=max(1,int(pending_limit))
        self.pending_bytes=max(1,int(pending_bytes))
        self._dirty_sizes={};self._dirty_bytes=0
        self._misses=OrderedDict();self.miss_ttl=max(0.,float(miss_ttl))
        self._read_ready=False

    def _path(self,key):
        if not re.fullmatch(r'(?:movie|tv)_[1-9]\d{0,11}',key):
            raise ValueError('Invalid shared metadata identity')
        return os.path.join(self.directory,key+'.json')

    def _remember(self,key,value):
        self._misses.pop(key,None)
        self.ram[key]=copy.deepcopy(value);self.ram.move_to_end(key)
        while len(self.ram)>self.limit:self.ram.popitem(last=False)

    def _miss(self,key):
        self._misses[key]=time.monotonic()+self.miss_ttl
        self._misses.move_to_end(key)
        while len(self._misses)>self.limit:self._misses.popitem(last=False)

    def get(self,key):
        with self.lock:
            self._path(key)
            if key in self.dirty:
                self._schedule()
                return copy.deepcopy(self.dirty[key])
            if key in self.ram:
                self.ram.move_to_end(key);return copy.deepcopy(self.ram[key])
            readable=bool(hdd_read_ready())
            # A miss while the mount is absent must never hide data after mount.
            if readable!=self._read_ready:
                us_clear(self._misses);self._read_ready=readable
            if not readable:return {}
            until=self._misses.get(key,0.)
            if time.monotonic()<until:return {}
            self._misses.pop(key,None)
            try:
                with open(self._path(key),'r',encoding='utf-8') as handle:value=json.load(handle)
                if not isinstance(value,dict):
                    self._miss(key);return {}
                self._remember(key,value);return copy.deepcopy(value)
            except (OSError,ValueError,TypeError):
                self._miss(key);return {}

    def _retain_dirty(self,key,value,size):
        self._dirty_bytes+=size-self._dirty_sizes.get(key,0)
        self._dirty_sizes[key]=size
        self.dirty[key]=value;self.dirty.move_to_end(key)

    def put(self,key,value):
        with self.lock:
            self._path(key)
            old=self.get(key)
            if old==value and key not in self.dirty:return False
            # RAM cache eviction and unpublished writes have separate budgets.
            # Never evict an already accepted write to admit a different record.
            incoming=copy.deepcopy(value)
            size=len(json.dumps(incoming,ensure_ascii=False,separators=(',',':')).encode('utf-8'))
            required=self._dirty_bytes-self._dirty_sizes.get(key,0)+size
            if ((key not in self.dirty and len(self.dirty)>=self.pending_limit)
                    or required>self.pending_bytes):
                self._schedule()
                raise PendingWriteLimitError('Shared metadata pending-write capacity; new update not accepted')
            self._remember(key,incoming)
            self._retain_dirty(key,incoming,size)
            saved=self._flush_one(key)
            if not saved:self._schedule()
            return saved

    def _flush_one(self,key):
        # The store lock serializes merge + snapshot + publication, including
        # retries. A delayed older writer cannot replace a newer value.
        if key not in self.dirty or not hdd_ready() or not ensure_persistent_dirs(self.directory):return False
        path=self._path(key);temp='%s.tmp.%d.%d'%(path,os.getpid(),threading.get_ident())
        try:
            if self.merge is not None:
                try:
                    with open(path,'r',encoding='utf-8') as handle:old=json.load(handle)
                    if isinstance(old,dict):
                        merged=self.merge(old,self.dirty[key])
                        size=len(json.dumps(merged,ensure_ascii=False,separators=(',',':')).encode('utf-8'))
                        self._retain_dirty(key,merged,size);self._remember(key,merged)
                except (OSError,ValueError,TypeError):pass
            if not persistent_write_gate(temp,path):return False
            with open(temp,'w',encoding='utf-8') as handle:
                json.dump(self.dirty[key],handle,ensure_ascii=False,separators=(',',':'))
                handle.flush();os.fsync(handle.fileno())
            os.chmod(temp,0o600)
            if not persistent_write_gate(temp,path):return False
            os.replace(temp,path)
            self.dirty.pop(key,None)
            self._dirty_bytes-=self._dirty_sizes.pop(key,0)
            self._misses.pop(key,None)
            return True
        except (OSError,ValueError,TypeError):return False
        finally:
            try:
                if os.path.isfile(temp) and persistent_write_gate(temp):os.unlink(temp)
            except OSError:pass

    def flush(self):
        with self.lock:
            for key in list(self.dirty):
                if not hdd_ready():break
                self._flush_one(key)
            return not self.dirty

    def _schedule(self):
        if not self.dirty or (self.worker is not None and self.worker.is_alive()):return
        def retry():
            attempt=0
            try:
                for attempt in range(12):
                    threading.Event().wait(self.retry_seconds)
                    if self.flush():break
            finally:
                with self.lock:
                    self.worker=None
                    if self.dirty and attempt<11:self._schedule()
        self.worker=threading.Thread(target=retry,name='UltraStalkerSharedMetadataRetry',daemon=True)
        self.worker.start()
