# -*- coding: utf-8 -*-
"""Unified episode labels for the Series rail and the Player info bar.

Every episode is shown as "Episode N", whatever the portal calls it.  A real
episode name (when the portal or TMDB has one) is shown on a second line, and
the runtime in minutes is shown at the right edge of the Series row.

Pure helpers first (no Enigma2 imports, easy to simulate), the TMDB season
lookup and the screen glue at the bottom.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str, int, open, round, max, min, us_casefold

import logging
hashlib = _us_env.hashlib
json = _us_env.json
re = _us_env.re
threading = _us_env.threading
time = _us_env.time

LOG = logging.getLogger("UltraStalker")

_NAME_KEYS = ("episode_name", "_episode_title", "episode_title", "name", "title")
_NUMBER_KEYS = ("episode_number", "episode", "number", "episode_num", "episode_id")
_RUNTIME_MIN_KEYS = ("runtime", "duration_min")
_RUNTIME_TMDB_KEYS = ("_ep_runtime",)
_RUNTIME_SEC_KEYS = ("duration_secs",)
_RUNTIME_AUTO_KEYS = ("duration", "length", "movie_duration")

_WORDS = (
    "episode", "episodio", "épisode", "episodio", "ep", "e", "folge", "bölüm", "bolum",
    "серия", "эпизод", "odcinek", "aflevering", "avsnitt", "capítulo", "capitulo", "cap",
    "الحلقة", "الحلقه", "حلقة", "حلقه",
)
_WORD_ALT = "|".join(sorted(set(re.escape(w) for w in _WORDS), key=len, reverse=True))
_RE_SXXEYY = re.compile(r"^\s*s\d{1,2}\s*[._ -]?\s*e\s*\d{1,4}(?!\d)", re.I | re.U)
_RE_NXMM = re.compile(r"^\s*\d{1,2}x\d{1,4}(?!\d)", re.I | re.U)
_RE_WORD_NUM = re.compile(r"^\s*(?:%s)\.?\s*0*\d{1,4}(?!\d)" % _WORD_ALT, re.I | re.U)
_RE_NUM_SEP = re.compile(r"^\s*0*\d{1,3}\s*[-–—:.)]\s+", re.U)
_RE_SEPARATORS = re.compile(r"^[\s\-–—:.|)\]_/]+", re.U)
_RE_ONLY_NUMBER = re.compile(r"^[\s\d.\-_:|/()\[\]]*$", re.U)
_RE_ONLY_WORD = re.compile(r"^\s*(?:%s)\.?\s*$" % _WORD_ALT, re.I | re.U)


def _tr(text):
    try:
        from . import _
        return _(text)
    except Exception:
        return text


def _flat(value, limit=120):
    if isinstance(value, (list, tuple)):
        value = value[0] if value else ""
    text = " ".join(str(value if value is not None else "").replace("\n", " ").replace("\r", " ").split()).strip()
    if text.lower() in ("none", "null", "n/a", "0"):
        return ""
    return text[:limit]


def episode_number(item, fallback=None):
    """Episode number as an int (> 0) or ``fallback``."""
    if isinstance(item, dict):
        for key in _NUMBER_KEYS:
            value = item.get(key)
            if value in (None, ""):
                continue
            match = re.search(r"\d+", str(value))
            if not match:
                continue
            try:
                number = int(match.group(0))
            except Exception:
                continue
            if 0 < number < 10000:
                return number
    return fallback


def clean_episode_name(raw, series_title=""):
    """Return the real episode name inside ``raw`` or "" when it is generic.

    "01", "Episode 7", "S01E07", "الحلقة 7" -> ""
    "S1E2 Hide + Seek", "Episode 2 - Hide + Seek", "2. Hide + Seek" -> "Hide + Seek"
    "12 Angry Men" stays as it is.
    """
    text = _flat(raw)
    if not text:
        return ""
    for _round in range(3):
        before = text
        for pattern in (_RE_SXXEYY, _RE_NXMM, _RE_WORD_NUM, _RE_NUM_SEP):
            match = pattern.match(text)
            if match:
                text = text[match.end():]
                text = _RE_SEPARATORS.sub("", text).strip()
                break
        if text == before:
            break
    text = text.strip()
    if not text or _RE_ONLY_NUMBER.match(text) or _RE_ONLY_WORD.match(text):
        return ""
    series = us_casefold(_flat(series_title))
    if series and us_casefold(text) == series:
        return ""
    return text[:80]


def episode_name(item):
    """Best real episode name for ``item`` ("" when there is none)."""
    if not isinstance(item, dict):
        return ""
    series_title = item.get("_series_title") or ""
    for key in _NAME_KEYS:
        name = clean_episode_name(item.get(key), series_title)
        if name:
            return name
    return clean_episode_name(item.get("_ep_tmdb_name"), series_title)


def episode_label(item, index=None):
    """The unified title: always "Episode N" when a number is known."""
    number = episode_number(item, (int(index) + 1) if index is not None else None)
    if number:
        return _tr("Episode %s") % number
    return _tr("Episode")


def _parse_clock(text):
    parts = text.split(":")
    if len(parts) not in (2, 3) or not all(p.strip().isdigit() for p in parts):
        return None
    nums = list(int(p) for p in parts)
    if len(nums) == 3:
        return nums[0] * 60 + nums[1] + (1 if nums[2] >= 30 else 0)
    return nums[0] + (1 if nums[1] >= 30 else 0)


def _to_minutes(value, unit):
    if isinstance(value, (list, tuple)):
        value = value[0] if value else None
    if value in (None, ""):
        return None
    text = str(value).strip().lower()
    if ":" in text:
        return _parse_clock(text)
    match = re.search(r"\d+(?:[.,]\d+)?", text)
    if not match:
        return None
    try:
        number = float(match.group(0).replace(",", "."))
    except Exception:
        return None
    if number <= 0:
        return None
    if unit == "sec":
        return number / 60.0
    if unit == "min":
        return number
    return number / 60.0 if number > 300 else number


def episode_runtime_minutes(item):
    """Runtime in whole minutes (1..600) or 0 when unknown."""
    if not isinstance(item, dict):
        return 0
    # Portal values first; the TMDB value (_ep_runtime) only fills the gap.
    groups = ((_RUNTIME_MIN_KEYS, "min"), (_RUNTIME_SEC_KEYS, "sec"), (_RUNTIME_AUTO_KEYS, "auto"), (_RUNTIME_TMDB_KEYS, "min"))
    for keys, unit in groups:
        for key in keys:
            minutes = _to_minutes(item.get(key), unit)
            if minutes is None:
                continue
            minutes = int(round(minutes))
            if 1 <= minutes <= 600:
                return minutes
    return 0


def runtime_text(item):
    minutes = episode_runtime_minutes(item)
    return (_tr("%d min") % minutes) if minutes else ""


# ---------------------------------------------------------------------------
# TMDB season lookup (names + runtimes for portals that only send "01", "02")
# ---------------------------------------------------------------------------

_META_LOCK = threading.Lock()
_META_CACHE = {}
_META_TTL_OK = 6 * 3600
_META_TTL_FAIL = 600


# ---------------------------------------------------------------------------
# Disk cache: names and runtimes are kept on the HDD after the first lookup so
# the next visit paints them with the first frame (no 20-30 s TMDB wait).
# ---------------------------------------------------------------------------
_DISK_FILE = "/etc/enigma2/ultrastalker/episode_meta.json"
_DISK_MAX = 300
_DISK_FRESH = 14 * 86400
_DISK_LOCK = threading.Lock()
_DISK_FLUSH_LOCK = threading.Lock()
_DISK_MEM = {"data": None}


def _disk_path():
    return _DISK_FILE


def _disk_load():
    with _DISK_LOCK:
        if _DISK_MEM["data"] is not None:
            return _DISK_MEM["data"]
        data = {}
        try:
            json = _us_env.json
            with open(_disk_path(), "r", encoding="utf-8") as handle:
                raw = json.load(handle)
            if isinstance(raw, dict):
                data = raw
        except Exception:
            data = {}
        _DISK_MEM["data"] = data
        return data


def _disk_flush():
    # Snapshot only AFTER taking the publication lock. A delayed writer must
    # publish the latest in-memory state, never its older pre-lock snapshot.
    # Writers release _DISK_LOCK before entering here; lock order is flush -> data.
    with _DISK_FLUSH_LOCK:
        data = _disk_load()
        with _DISK_LOCK:
            snapshot = dict(data)
        return _disk_flush_locked(snapshot)


def _disk_flush_locked(data):
    try:
        json = _us_env.json
        os = _us_env.os
        path = _disk_path()
        folder = os.path.dirname(path)
        if folder and not os.path.isdir(folder):
            os.makedirs(folder)
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as handle:
            json.dump(data, handle, ensure_ascii=False, separators=(",", ":"))
            handle.flush()
            try:
                os.fsync(handle.fileno())
            except Exception:
                pass
        os.replace(tmp, path)
        return True
    except Exception as exc:
        LOG.debug("episode meta disk save failed: %s", exc)
        return False


def _series_identity(series_item):
    if not isinstance(series_item, dict):
        return ""
    for key in ("series_id", "id", "series_uid"):
        value = series_item.get(key)
        if value not in (None, ""):
            return "s%s" % value
    title = series_item.get("original_name") or series_item.get("name") or series_item.get("title") or ""
    return "t%s" % str(title).strip().lower() if title else ""


def _source_scope(series_item, profile=None):
    """Provider ids are local to an account; never persist ambiguous aliases."""
    source = profile if isinstance(profile, dict) and profile else series_item
    if not isinstance(source, dict):
        return ""
    portal = str(source.get("portal") or source.get("url") or source.get("host") or "").strip().rstrip("/")
    if not portal:
        return ""
    identity = (portal, str(source.get("mac") or "").upper(),
                str(source.get("username") or source.get("user") or ""),
                str(source.get("source_type") or source.get("type") or ""))
    raw = json.dumps(identity, ensure_ascii=True, separators=(",", ":"))
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _disk_keys(series_item, season_number, language, profile=None):
    keys = []
    tmdb_id = _series_tmdb_id(series_item)
    if tmdb_id:
        keys.append("tmdb:%d:%d:%s" % (tmdb_id, int(season_number), language))
    ident = _series_identity(series_item)
    scope = _source_scope(series_item, profile)
    if ident and scope:
        # Ignore legacy unscoped provider ids. TMDb identities remain shareable.
        keys.append("provider-v2:%s:%s:%d:%s" % (scope, ident, int(season_number), language))
    return keys


def _current_language():
    try:
        from .storage import load_settings
        return str((load_settings() or {}).get("tmdb_language") or "ar-EG").strip() or "ar-EG"
    except Exception:
        return "ar-EG"


def disk_meta_get(series_item, season_number, language=None, profile=None):
    """(meta, age_seconds) from the HDD cache, or ({}, None)."""
    try:
        if season_number is None:
            return {}, None
        language = language or _current_language()
        data = _disk_load()
        for key in _disk_keys(series_item, season_number, language, profile):
            entry = data.get(key)
            if not isinstance(entry, dict) or not isinstance(entry.get("m"), dict):
                continue
            meta = {}
            for number, value in entry["m"].items():
                try:
                    meta[int(number)] = {"name": str(value[0] or ""), "runtime": int(value[1] or 0)}
                except Exception:
                    continue
            if meta:
                return meta, max(0, time.time() - float(entry.get("t") or 0))
        return {}, None
    except Exception as exc:
        LOG.debug("episode meta disk read failed: %s", exc)
        return {}, None


def disk_meta_put(series_item, season_number, meta, language=None, profile=None):
    try:
        if not meta or season_number is None:
            return False
        language = language or _current_language()
        keys = _disk_keys(series_item, season_number, language, profile)
        if not keys:
            return False
        packed = {}
        for number, value in meta.items():
            if value.get("name") or value.get("runtime"):
                packed[str(int(number))] = [value.get("name") or "", int(value.get("runtime") or 0)]
        if not packed:
            return False
        data = _disk_load()
        stamp = time.time()
        with _DISK_LOCK:
            for key in keys:
                data[key] = {"t": stamp, "m": packed}
            if len(data) > _DISK_MAX:
                def _stamp(name):
                    # A damaged entry (not a dict) sorts as the oldest, so it is
                    # evicted first instead of making every later save fail.
                    entry = data.get(name)
                    if not isinstance(entry, dict):
                        return 0.0
                    try:
                        return float(entry.get("t") or 0)
                    except Exception:
                        return 0.0
                for old in sorted(data, key=_stamp)[: len(data) - _DISK_MAX]:
                    data.pop(old, None)
        return _disk_flush()
    except Exception as exc:
        LOG.debug("episode meta disk put failed: %s", exc)
        return False



def _series_tmdb_id(series_item):
    if not isinstance(series_item, dict):
        return 0
    for key in ("_locked_tmdb_id", "_ultra_search_verified_tmdb_id", "tmdb_id", "tmdbid", "tmdb"):
        value = series_item.get(key)
        try:
            number = int(str(value).strip())
        except Exception:
            continue
        if number > 0:
            return number
    return 0


def _season_number_from_rows(rows):
    for row in rows or ():
        if isinstance(row, dict):
            for key in ("season", "season_number", "season_id"):
                value = row.get(key)
                if value in (None, ""):
                    continue
                match = re.search(r"\d+", str(value))
                if match:
                    try:
                        return int(match.group(0))
                    except Exception:
                        pass
    return None


def tmdb_season_meta(series_item, season_number, cancel_event=None, profile=None):
    """{episode_number: {"name": str, "runtime": int}} from TMDB, or {}."""
    try:
        from .storage import load_settings
        cfg = load_settings() or {}
        credential = str(cfg.get("tmdb_credential") or "").strip()
        if not credential or not cfg.get("tmdb_enabled", True) or season_number is None:
            return {}
        language = str(cfg.get("tmdb_language") or "ar-EG").strip() or "ar-EG"
        timeout = min(7, max(3, int(cfg.get("timeout", 10) or 10)))
        from .tmdb import TMDBClient
        client = TMDBClient(credential, language, timeout)
        tmdb_id = _series_tmdb_id(series_item)
        if not tmdb_id:
            found = client.enrich("series", dict(series_item or {}), "metadata") or {}
            if str(found.get("media_type") or "tv").lower() in ("tv", "series"):
                try:
                    tmdb_id = int(found.get("tmdb_id") or 0)
                except Exception:
                    tmdb_id = 0
        if not tmdb_id:
            return {}
        key = (tmdb_id, int(season_number), language)
        now = time.time()
        with _META_LOCK:
            hit = _META_CACHE.get(key)
            if hit and now - hit[0] < (_META_TTL_OK if hit[1] else _META_TTL_FAIL):
                return hit[1]
        if cancel_event is not None and cancel_event.is_set():
            return {}
        path = "/tv/%d/season/%d" % (tmdb_id, int(season_number))
        result = {}

        def absorb(payload):
            for row in (payload or {}).get("episodes") or []:
                if not isinstance(row, dict):
                    continue
                try:
                    number = int(row.get("episode_number") or 0)
                except Exception:
                    continue
                if number <= 0:
                    continue
                slot = result.setdefault(number, {"name": "", "runtime": 0})
                if not slot["name"]:
                    slot["name"] = clean_episode_name(row.get("name"))
                if not slot["runtime"]:
                    try:
                        slot["runtime"] = int(row.get("runtime") or 0)
                    except Exception:
                        slot["runtime"] = 0

        absorb(client._get(path, {"language": language}))
        needs_english = (not result) or any(not v["name"] or not v["runtime"] for v in result.values())
        if needs_english and language.lower() != "en-us" and not (cancel_event is not None and cancel_event.is_set()):
            try:
                absorb(client._get(path, {"language": "en-US"}))
            except Exception as exc:
                LOG.debug("episode meta english fallback failed: %s", exc)
        with _META_LOCK:
            _META_CACHE[key] = (time.time(), result)
        if result:
            try:
                disk_meta_put(dict(series_item or {}, tmdb_id=tmdb_id), int(season_number), result, language, profile=profile)
            except Exception as exc:
                LOG.debug("episode meta disk store failed: %s", exc)
        return result
    except Exception as exc:
        LOG.debug("episode meta lookup failed: %s", exc)
        return {}


# ---------------------------------------------------------------------------
# Series screen glue
# ---------------------------------------------------------------------------

def apply_cached_meta(screen, rows):
    """Copy already-fetched TMDB names/runtimes onto freshly built rows."""
    try:
        season = _season_number_from_rows(rows)
        data = (getattr(screen, "_ep_meta_store", None) or {}).get(season)
        if not data and season is not None:
            # First paint straight from the HDD cache (no network, no waiting).
            disk, age = disk_meta_get(getattr(screen, "series_item", None), season, profile=getattr(screen, "profile", None))
            if disk:
                screen.__dict__.setdefault("_ep_meta_store", {})[season] = disk
                if age is not None and age > _DISK_FRESH:
                    screen.__dict__.setdefault("_ep_meta_stale", set()).add(season)
                data = disk
        if not data:
            return False
        changed = False
        for row in rows or ():
            if not isinstance(row, dict):
                continue
            meta = data.get(episode_number(row))
            if not meta:
                continue
            if meta.get("name") and row.get("_ep_tmdb_name") != meta["name"]:
                row["_ep_tmdb_name"] = meta["name"]
                changed = True
            if meta.get("runtime") and row.get("_ep_runtime") != meta["runtime"]:
                row["_ep_runtime"] = meta["runtime"]
                changed = True
        return changed
    except Exception as exc:
        LOG.debug("episode meta apply failed: %s", exc)
        return False


def needs_meta(rows):
    """True when at least one row lacks a real name or a runtime."""
    for row in rows or ():
        if isinstance(row, dict) and (not episode_name(row) or not episode_runtime_minutes(row)):
            return True
    return False


def start_meta_fetch(screen, rows, on_ready):
    """Fetch the season from TMDB once per screen; never blocks the UI."""
    try:
        if getattr(screen, "_screen_closed", False) or not rows:
            return False
        season = _season_number_from_rows(rows)
        if season is None:
            return False
        store = screen.__dict__.setdefault("_ep_meta_store", {})
        stale = screen.__dict__.setdefault("_ep_meta_stale", set())
        refresh = season in stale
        if not refresh and not needs_meta(rows):
            return False
        if season in store and not refresh:
            return False
        stale.discard(season)
        store.setdefault(season, {})
        series_item = getattr(screen, "series_item", None)
        profile = dict(getattr(screen, "profile", None) or {})
        from .core.tasks import TASKS

        def work(handle):
            return tmdb_season_meta(series_item, season, handle.cancel_event, profile=profile)

        def ok(value):
            if getattr(screen, "_screen_closed", False):
                return
            if isinstance(value, dict) and value:
                changed = value != store.get(season)
                store[season] = value
                if changed:
                    on_ready(season)

        handle = TASKS.submit(work, screen._series_jobs, ok=ok, fail=lambda exc: None)
        if handle is None:
            store.pop(season, None)
            return False
        try:
            screen._series_task_handles.append(handle)
        except Exception:
            pass
        try:
            screen._async_set_poll_interval(120)
        except Exception:
            pass
        return True
    except Exception as exc:
        LOG.debug("episode meta start failed: %s", exc)
        return False
