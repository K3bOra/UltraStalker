# -*- coding: utf-8 -*-
"""Poster Grid 3 (R5.22): 5x2 large poster cards + a Spotlight glass panel.

Grid 1/V2 are untouched; this screen only subclasses PremiumPosterGridScreen and
changes geometry plus the right-hand panel for the focused title:
large title, genres, year/age/runtime(+episodes) badges, country/language,
IMDb/TMDb ratings, overview, four real TMDB cast portraits and the continue-watching progress.

GUI-thread rules (same as the other grids):
* arrow keys only change text / visibility (no HDD, no Pillow, no network);
* the full panel fill starts after focus settles (base 360 ms debounce) on one
  keyed metadata worker that replaces older focus jobs;
* every result carries a focus token, stale results are dropped.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str, int, round, max, min, us_func

os = _us_env.os
queue = _us_env.queue
re = _us_env.re
threading = _us_env.threading

from . import _
from .ui_grid_screens import PremiumPosterGridScreen, _poster_menu_overlay_skin
from .ui_skin_templates import POSTER_GRID3_SKIN as _RAW_SKIN
from .log import optional_failure
from .ui_parts.catalog import strip_arabic_tashkeel as _strip_arabic_tashkeel
from .ui_parts.catalog import clean_person_name as _clean_person_name
from .core.shared_executors import METADATA_EXECUTOR as _SPOT_EXECUTOR

from Components.Label import Label
from Components.Pixmap import Pixmap
from enigma import eTimer, ePoint, eSize

PANEL_X, PANEL_Y = 1350, 34
BADGE_Y = 244
BADGE_H = 34
PANEL_INNER_X, PANEL_INNER_W = 1382, 466
# Movies: Year / Age / Duration, centred.  Series: Year / Age / Seasons / Episodes,
# packed to the left edge of the panel.  Icon chips carry a small leading icon.
BADGE_ICON = {"spot_runtime": "spot_runtime_icon", "spot_eps": "spot_eps_icon"}
PROGRESS_W = 466
# Description auto-scroll. SMOOTH: the long text is moved up 1px every
# SMOOTH_STEP_MS inside a clipped viewport (~14 px/s, about one line every 2 s).
# Any failure, or this file, drops back to the paged one-line fallback below.
SMOOTH_SCROLL = True
SMOOTH_DISABLE_FILE = "/etc/enigma2/ultrastalker/disable_smooth_scroll"
SMOOTH_STEP_MS = 70
SMOOTH_START_HOLD = 5000
SMOOTH_END_HOLD = 6000
PAGED_FIRST_HOLD = 6000
PAGED_LINE_MS = 2000
PAGED_END_HOLD = 6000
CAST_SLOTS = 4
TITLE_LOGO_SIZE = (466, 180)


def _prepared_skin():
    xml = _RAW_SKIN
    try:
        from . import ui as _ui
        xml = _ui._bind_internal_skin_assets(xml)
        xml = _ui._prepare_runtime_skin(xml)
    except Exception as exc:
        optional_failure("grid3.skin_prepare", exc)
    return _poster_menu_overlay_skin(xml)


def _asset(name):
    try:
        from . import ui as _ui
        return _ui.asset(name)
    except Exception:
        return os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets_fhd", name)


def _short(text, limit):
    text = re.sub(r"\s+", " ", str(text or "")).strip()
    if len(text) <= limit:
        return text
    cut = text[:limit].rsplit(" ", 1)[0].rstrip(" ,.;:-")
    return (cut or text[:limit]) + "…"


def _names(value, limit=3):
    if isinstance(value, str):
        value = [x.strip() for x in re.split(r"[,،|/]", value) if x.strip()]
    out = []
    for v in (value or []):
        if isinstance(v, dict):
            v = v.get("name") or ""
        v = str(v or "").strip()
        if v and v not in out:
            out.append(v)
        if len(out) >= limit:
            break
    return out


def _runtime_text(row, media_type):
    if media_type == "series":
        try:
            seasons = int(row.get("number_of_seasons") or row.get("seasons_count") or 0)
        except Exception:
            seasons = 0
        if seasons <= 0:
            return ""
        return (_("%d season") % seasons) if seasons == 1 else (_("%d seasons") % seasons)
    value = row.get("runtime") or row.get("duration") or row.get("time") or ""
    m = re.search(r"\d+", str(value or ""))
    if not m:
        return ""
    minutes = int(m.group(0))
    if minutes <= 0 or minutes > 1000:
        return ""
    h, mm = divmod(minutes, 60)
    return ("%dh %02dm" % (h, mm)) if h else ("%dm" % mm)


def _score(value):
    m = re.search(r"\d+(?:\.\d+)?", str(value or ""))
    if not m:
        return 0.0
    try:
        v = float(m.group(0))
    except Exception:
        return 0.0
    return v if 0.0 < v <= 10.0 else 0.0


class PremiumPosterGrid3Screen(PremiumPosterGridScreen):
    skin = ""
    columns = 5
    page_size = 10
    image_size = (240, 362)
    placeholder = "grid_placeholder_movie_921.png"
    selection_asset = "poster_cursor_g3_256x440.png"
    card_chrome_geometry = (240, 424, 362)
    poster_hud_disabled = True
    card_positions = [(40 + c * 262 - 8, y - 8) for y in (34, 494) for c in range(5)]

    def __init__(self, session, profile, client, media_type, genre, category_title="", initial_search=""):
        if not PremiumPosterGrid3Screen.skin:
            PremiumPosterGrid3Screen.skin = _prepared_skin()
        us_func(PremiumPosterGridScreen.__init__)(self, session, profile, client, media_type, genre, category_title, initial_search)
        self.selection_asset = "poster_cursor_g3_256x440.png"
        self._poster_menu_init()
        for name in ("spot_title", "spot_year", "spot_age", "spot_runtime",
                     "spot_overview_head", "spot_cast_head", "spot_progress_label", "spot_progress_percent",
                     "spot_country_head", "spot_language_head",
                     "spot_imdb_value", "spot_tmdb_value", "spot_country", "spot_language", "spot_eps"):
            self[name] = Label("")
        self["spot_overview"] = Label("")
        for k in range(3):
            self["spot_gchip%d" % k] = Label("")
            self["spot_gchip_bg%d" % k] = Pixmap()
        for name in ("spot_title_logo", "spot_progress_track", "spot_progress_fill",
                     "spot_imdb_logo", "spot_tmdb_logo", "spot_runtime_icon",
                     "spot_country_icon", "spot_language_icon", "spot_eps_icon",
                     "spot_year_bg", "spot_age_bg", "spot_runtime_bg", "spot_eps_bg"):
            self[name] = Pixmap()
        for k in range(CAST_SLOTS):
            self["spot_cast%d" % k] = Pixmap()
            self["spot_cast_name%d" % k] = Label("")
            self["spot_cast_role%d" % k] = Label("")
        self._spot_jobs = queue.Queue()
        self._spot_token = 0
        self._spot_cancel = None
        self._spot_key = ""
        self._spot_suspended = False
        self._spot_future = None
        self._spot_meta_rows = {}
        self._spot_cast_rows = {}
        self._spot_title_logo_path = ""
        self._spot_logo_paths = {}
        self._spot_cast_paths = {}
        self._spot_bound_pixmaps = {}
        self._spot_badges_sig = None
        self._spot_gchips_sig = None
        try:
            self._spot_smooth_disabled = os.path.exists(SMOOTH_DISABLE_FILE)
        except Exception:
            self._spot_smooth_disabled = False
        self._spot_timer = eTimer()
        self._spot_timer_conn = None
        try:
            self._spot_timer_conn = self._spot_timer.timeout.connect(self._spot_drain)
        except Exception:
            self._spot_timer.callback.append(self._spot_drain)
        self._spot_scroll_timer = eTimer()
        self._spot_scroll_conn = None
        self._spot_overview_source = ""
        try:
            self._spot_scroll_conn = self._spot_scroll_timer.timeout.connect(self._spot_scroll_description)
        except Exception:
            self._spot_scroll_timer.callback.append(self._spot_scroll_description)
        self._spot_box = None
        self._spot_lab = None
        self._spot_smooth = False
        self._spot_smooth_broken = False
        self._spot_smooth_pos = 0
        self._spot_smooth_max = 0
        self._spot_smooth_phase = "hold_top"
        self._spot_smooth_timer = eTimer()
        self._spot_smooth_conn = None
        try:
            self._spot_smooth_conn = self._spot_smooth_timer.timeout.connect(self._spot_smooth_tick)
        except Exception:
            self._spot_smooth_timer.callback.append(self._spot_smooth_tick)
        try:
            self.onExecEnd.append(self._spot_pause_description)
            self.onExecBegin.append(self._spot_resume_description)
        except Exception:
            pass
        self.onLayoutFinish.append(self._spot_layout_ready)
        self.onClose.append(self._spot_stop)

    # ------------------------------------------------------------------ helpers
    def _spot_layout_ready(self):
        try:
            self["spot_overview_head"].setText(_("OVERVIEW"))
        except Exception:
            pass
        self._spot_clear()

    def _spot_pause_scroll(self):
        self._spot_scroll_timer.stop()
        self._spot_smooth_timer.stop()

    def _spot_resume_scroll(self):
        if self._spot_overview_source and not self._spot_suspended and not getattr(self, "_screen_closed", False):
            if self._spot_smooth:
                phase = self._spot_smooth_phase
                delay = SMOOTH_START_HOLD if phase == "hold_top" else (SMOOTH_END_HOLD if phase == "hold_end" else SMOOTH_STEP_MS)
                self._spot_smooth_timer.start(delay, True)
            else:
                self._spot_scroll_timer.start(PAGED_FIRST_HOLD, True)

    def _spot_pause_description(self):
        self._spot_pause_scroll()
        self._spot_suspended = True
        self._spot_token += 1
        if self._spot_cancel is not None:
            self._spot_cancel.set()
        future = getattr(self, "_spot_future", None)
        if future is not None:
            future.cancel()
        self._spot_timer.stop()

    def _spot_resume_description(self):
        was_suspended = self._spot_suspended
        self._spot_suspended = False
        if was_suspended and not getattr(self, "_screen_closed", False):
            self._spot_settle()
        self._spot_resume_scroll()

    # ---- smooth (pixel) description scroll -------------------------------
    def _spot_font_spec(self):
        m = re.search(r'<widget name="spot_overview"[^>]*?font="([^";]+);(\d+)"', PremiumPosterGrid3Screen.skin or "")
        return (m.group(1), int(m.group(2))) if m else ("Regular", 20)

    def _spot_smooth_ensure(self):
        """Create (once) a clipped viewport + tall label, the same structure
        ScrollLabel uses internally, but without its skin/size quirks."""
        if self._spot_box is not None and self._spot_lab is not None:
            return True
        from enigma import eWidget, eLabel, gFont, gRGB
        base = self["spot_overview"].instance
        parent = getattr(self, "instance", None)
        if base is None or parent is None:
            return False
        pos, size = base.position(), base.size()
        box = eWidget(parent)
        try:box.setTransparent(True)
        except Exception:pass
        box.move(ePoint(int(pos.x()), int(pos.y())))
        box.resize(eSize(int(size.width()), int(size.height())))
        lab = eLabel(box)
        name, px = self._spot_font_spec()
        lab.setFont(gFont(name, px))
        lab.setHAlign(eLabel.alignCenter)
        lab.setVAlign(eLabel.alignTop)
        lab.setForegroundColor(gRGB(0xe8e8ec))
        try:
            lab.setShadowColor(gRGB(0x000000))
            lab.setShadowOffset(ePoint(1, 1))
        except Exception:pass
        try:lab.setTransparent(True)
        except Exception:pass
        lab.move(ePoint(0, 0))
        lab.resize(eSize(int(size.width()), int(size.height())))
        try:box.setZPosition(6)
        except Exception:pass
        box.hide()
        self._spot_box, self._spot_lab = box, lab
        return True

    def _spot_smooth_off(self):
        self._spot_smooth = False
        self._spot_smooth_timer.stop()
        self._spot_smooth_pos = 0
        self._spot_smooth_phase = "hold_top"
        try:
            if self._spot_box is not None:
                self._spot_box.hide()
        except Exception:
            pass

    def _spot_smooth_try(self, text):
        """True when the text is taller than the box and the pixel scroller took over."""
        if not SMOOTH_SCROLL or self._spot_smooth_broken or not text:
            return False
        try:
            if getattr(self, "_spot_smooth_disabled", False):
                return False
            if not self._spot_smooth_ensure():
                return False
            view_w = int(self._spot_box.size().width())
            view_h = int(self._spot_box.size().height())
            lab = self._spot_lab
            lab.resize(eSize(view_w, 8000))
            lab.setText(text)
            total = int(lab.calculateSize().height())
            if total <= view_h:
                return False
            lab.resize(eSize(view_w, total + 8))
            lab.move(ePoint(0, 0))
            self._spot_smooth_pos = 0
            self._spot_smooth_max = total + 6 - view_h
            self._spot_smooth_phase = "hold_top"
            self._spot_box.show()
            lab.show()
            self._spot_smooth = True
            return True
        except Exception as exc:
            optional_failure("grid3.smooth_scroll", exc)
            self._spot_smooth_broken = True
            self._spot_smooth_off()
            return False

    def _spot_smooth_tick(self):
        if getattr(self, "_screen_closed", False) or not getattr(self, "execing", True) or not self._spot_smooth:
            return
        phase = self._spot_smooth_phase
        try:
            if phase == "hold_top":
                self._spot_smooth_phase = "run"
                delay = SMOOTH_STEP_MS
            elif phase == "run":
                _sx, sy = self._spot_scale()
                self._spot_smooth_pos = min(self._spot_smooth_max, self._spot_smooth_pos + max(1, int(round(sy))))
                self._spot_lab.move(ePoint(0, -int(self._spot_smooth_pos)))
                if self._spot_smooth_pos >= self._spot_smooth_max:
                    self._spot_smooth_phase = "hold_end"
                    delay = SMOOTH_END_HOLD
                else:
                    delay = SMOOTH_STEP_MS
            else:
                self._spot_smooth_pos = 0
                self._spot_lab.move(ePoint(0, 0))
                self._spot_smooth_phase = "hold_top"
                delay = SMOOTH_START_HOLD
        except Exception as exc:
            optional_failure("grid3.smooth_tick", exc)
            self._spot_smooth_broken = True
            self._spot_smooth_off()
            return
        self._spot_smooth_timer.start(delay, True)

    def _spot_description_lines(self, text):
        """Wrap with the receiver's own font metrics; retain all source text."""
        widget = self["spot_overview"]
        inst = getattr(widget, "instance", None)
        if inst is None:return [text]
        lines = []
        try:
            widget.setText("Ag")
            line_height = max(1, int(inst.calculateSize().height()))
            for paragraph in text.split("\n"):
                rest = paragraph
                if not rest:lines.append("");continue
                while rest:
                    lo, hi = 1, len(rest)
                    while lo < hi:
                        mid = (lo + hi + 1) // 2
                        widget.setText(rest[:mid])
                        if int(inst.calculateSize().height()) <= line_height:lo = mid
                        else:hi = mid - 1
                    cut = lo
                    if cut < len(rest):
                        boundary = rest.rfind(" ", 0, cut)
                        if boundary > 0:cut = boundary + 1
                    lines.append(rest[:cut])
                    rest = rest[cut:]
            return lines or [""]
        except Exception as exc:
            optional_failure("grid3.description_measure", exc)
            return [text]

    def _spot_description_window(self):
        lines = getattr(self, "_spot_overview_lines", [])
        start = getattr(self, "_spot_overview_line", 0)
        widget = self["spot_overview"]
        inst = getattr(widget, "instance", None)
        _sx, sy = self._spot_scale()
        # Fit the real resized viewport so lower rows never overflow it.
        limit = max(1, int(inst.size().height()) if inst is not None else int(202 * sy))
        end = min(start + 1, len(lines))
        while end < len(lines) and inst is not None:
            widget.setText("\n".join(lines[start:end + 1]))
            if int(inst.calculateSize().height()) > limit:break
            end += 1
        widget.setText("\n".join(lines[start:end]))
        return end >= len(lines)

    def _spot_description(self, text):
        # Display-only: Arabic tashkeel is dropped (it breaks Arabic shaping in
        # this box). Runs once per focus settle; non-Arabic text returns at once.
        text = _strip_arabic_tashkeel(str(text or "").strip())
        if text != self._spot_overview_source:
            self._spot_pause_scroll()
            self._spot_smooth_off()
            self._spot_overview_source = text
            if self._spot_smooth_try(text):
                self._spot_overview_lines = []
                self._spot_overview_line = 0
                self._spot_overview_at_end = False
                self._spot_text("spot_overview", "")
            else:
                self._spot_overview_lines = self._spot_description_lines(text)
                self._spot_overview_line = 0
                self._spot_overview_at_end = self._spot_description_window()
            self._spot_resume_scroll()
        self._spot_show("spot_overview", bool(text) and not self._spot_smooth)
        self._spot_show("spot_overview_head", bool(text))

    def _spot_scroll_description(self):
        if getattr(self, "_screen_closed", False) or not getattr(self, "execing", True):return
        lines = getattr(self, "_spot_overview_lines", [])
        if not lines:return
        if self._spot_overview_at_end:
            if not self._spot_overview_line:return
            self._spot_overview_line = 0
        else:self._spot_overview_line += 1
        self._spot_overview_at_end = self._spot_description_window()
        # Advance one wrapped line per tick, with a longer first/last dwell.
        self._spot_scroll_timer.start(PAGED_END_HOLD if self._spot_overview_at_end or self._spot_overview_line == 0 else PAGED_LINE_MS, True)

    def _spot_stop(self):
        self._spot_pause_description()
        try:
            if self._spot_pause_description in self.onExecEnd:
                self.onExecEnd.remove(self._spot_pause_description)
        except Exception:
            pass
        try:
            if self._spot_resume_description in self.onExecBegin:
                self.onExecBegin.remove(self._spot_resume_description)
        except Exception:
            pass
        try:
            if self._spot_smooth_conn is not None:
                self._spot_smooth_conn.disconnect()
            elif self._spot_smooth_tick in self._spot_smooth_timer.callback:
                self._spot_smooth_timer.callback.remove(self._spot_smooth_tick)
        except Exception:
            pass
        self._spot_smooth = False
        try:
            if self._spot_box is not None:
                self._spot_box.hide()
        except Exception:
            pass
        try:
            if self._spot_scroll_conn is not None:
                self._spot_scroll_conn.disconnect()
            elif self._spot_scroll_description in self._spot_scroll_timer.callback:
                self._spot_scroll_timer.callback.remove(self._spot_scroll_description)
        except Exception:
            pass
        try:
            if self._spot_cancel is not None:
                self._spot_cancel.set()
        except Exception:
            pass
        try:
            self._spot_timer.stop()
        except Exception:
            pass
        try:
            if self._spot_timer_conn is not None:
                self._spot_timer_conn.disconnect()
        except Exception:
            pass
        self._spot_timer_conn = None
        try:
            if self._spot_drain in self._spot_timer.callback:
                self._spot_timer.callback.remove(self._spot_drain)
        except Exception:
            pass

    def _spot_show(self, name, visible):
        try:
            if visible:
                self[name].show()
            else:
                self[name].hide()
        except Exception:
            pass

    def _spot_text(self, name, value):
        value = str(value or "")
        try:
            if str(self[name].getText() or "") != value:
                self[name].setText(value)
        except Exception:
            pass

    def _spot_pixmap(self, name, path):
        try:
            widget = self[name]
            if widget.instance is None:
                return False
            bound = getattr(self, "_spot_bound_pixmaps", None)
            if isinstance(bound, dict) and bound.get(name) == path and name != "spot_title_logo":
                widget.show()
                return True
            widget.instance.setPixmapFromFile(path)
            if isinstance(bound, dict):
                bound[name] = path
            widget.show()
            return True
        except Exception as exc:
            optional_failure("grid3.pixmap", exc)
            return False

    def _spot_scale(self):
        return float(getattr(self, "_grid_sx", 1.0) or 1.0), float(getattr(self, "_grid_sy", 1.0) or 1.0)

    def _spot_badges(self, values):
        """values: {name: text}. Pack the visible badges into one row.

        Movies keep the centred Year / Age / Duration trio. Series left-align
        Year / Age / Seasons / Episodes; the icon chips size to their text.
        """
        sx, sy = self._spot_scale()
        series = self.media_type == "series"
        order = (("spot_year", 76 if series else 80), ("spot_age", 62 if series else 66),
                 ("spot_runtime", 168), ("spot_eps", 168))
        sig = (series, sx, sy, tuple((n, str(values.get(n) or "")) for n, _w in order))
        if getattr(self, "_spot_badges_sig", None) == sig:
            return
        self._spot_badges_sig = sig
        entries = []
        for name, width in order:
            text = str(values.get(name) or "")
            visible = bool(text)
            self._spot_text(name, text)
            icon = BADGE_ICON.get(name)
            for part in (name, name + "_bg") + ((icon,) if icon else ()):
                self._spot_show(part, visible)
            if not visible:
                continue
            if series and icon:
                width = max(112, 40 + self._spot_text_px(name, text) + 14)
            entries.append([name, width, icon])
        if not entries:
            return
        gap = 8
        total = sum(e[1] for e in entries) + gap * (len(entries) - 1)
        if total > PANEL_INNER_W:
            gap = 6
            total = sum(e[1] for e in entries) + gap * (len(entries) - 1)
            flex = list(e for e in entries if e[2])
            if total > PANEL_INNER_W and flex:
                cut = -(-(total - PANEL_INNER_W) // len(flex))
                for e in flex:
                    e[1] = max(96, e[1] - cut)
        total = sum(e[1] for e in entries) + gap * (len(entries) - 1)
        x = PANEL_INNER_X if series else PANEL_INNER_X + (PANEL_INNER_W - total) // 2
        _badge_assets = {
            "spot_year": "grid3_badge_glass_70x30.png",
            "spot_age": "grid3_badge_glass_58x30.png",
            "spot_runtime": "grid3_badge_glass_128x30.png",
            "spot_eps": "grid3_badge_glass_128x30.png",
        }
        from .ui_icon_menu import _us_fit_png
        for name, width, icon in entries:
            try:
                bg = self[name + "_bg"].instance
                bw, bh = max(1, int(width * sx)), max(1, int(BADGE_H * sy))
                basset = _badge_assets.get(name)
                if basset:
                    fpath = _us_fit_png(_asset(basset), bw, bh, True)
                    if fpath and os.path.isfile(fpath):
                        bg.setPixmapFromFile(fpath)
                bg.move(ePoint(int(x * sx), int(BADGE_Y * sy)))
                bg.resize(eSize(bw, bh))
                lab = self[name].instance
                if icon:
                    lab.move(ePoint(int((x + 40) * sx), int(BADGE_Y * sy)))
                    lab.resize(eSize(int((width - 40) * sx), int(BADGE_H * sy)))
                    self[icon].instance.move(ePoint(int((x + 10) * sx), int((BADGE_Y + 5) * sy)))
                else:
                    lab.move(ePoint(int(x * sx), int(BADGE_Y * sy)))
                    lab.resize(eSize(int(width * sx), int(BADGE_H * sy)))
            except Exception:
                pass
            x += width + gap

    def _spot_text_px(self, name, text):
        """Real text width in native px (falls back to a conservative estimate)."""
        sx, _sy = self._spot_scale()
        try:
            inst = self[name].instance
            if inst is not None:
                inst.resize(eSize(int(520 * sx), int(30 * sx)))
                w = int(inst.calculateSize().width())
                if w > 0:
                    return int(round(w / max(0.1, sx)))
        except Exception:
            pass
        units = 0.0
        for ch in str(text):
            o = ord(ch)
            if o > 0x2ff:
                units += 0.62
            elif ch.isupper():
                units += 0.74
            elif ch == " ":
                units += 0.32
            else:
                units += 0.58
        return int(units * 17 * 1.1)

    def _spot_genre_chips(self, genres):
        """Center the full group of resident Premium genre pills."""
        sx, sy = self._spot_scale()
        entries = []
        texts = [str(t).strip()[:40] for t in genres[:3] if str(t).strip()]
        sig = (sx, sy, tuple(texts))
        if getattr(self, "_spot_gchips_sig", None) == sig:
            return
        self._spot_gchips_sig = sig
        cap = min(236, (466 - 8 * (len(texts) - 1)) // max(1, len(texts)))
        for k, text in enumerate(texts):
            self._spot_text("spot_gchip%d" % k, text)
            width = max(52, min(cap, self._spot_text_px("spot_gchip%d" % k, text) + 30))
            entries.append((text, max(52, (int(width) // 4) * 4)))
        total = sum(w for _t, w in entries) + max(0, len(entries) - 1) * 8
        x = 1382 + (466 - total) // 2
        for k in range(3):
            visible = k < len(entries)
            if visible:
                text, w = entries[k]
                try:
                    from .ui_icon_menu import _us_fit_png
                    bg = self["spot_gchip_bg%d" % k].instance
                    if bg is not None:bg.setPixmapFromFile(_us_fit_png(_asset("grid3_chip_%dx30.png" % w), max(1, int(w * sx)), max(1, int(30 * sy)), True))
                    for name in ("spot_gchip_bg%d" % k, "spot_gchip%d" % k):
                        inst = self[name].instance
                        inst.move(ePoint(int(x * sx), int(300 * sy)))
                        inst.resize(eSize(int(w * sx), int(30 * sy)))
                except Exception:pass
                x += w + 8
            else:self._spot_text("spot_gchip%d" % k, "")
            self._spot_show("spot_gchip%d" % k, visible)
            self._spot_show("spot_gchip_bg%d" % k, visible)

    def _spot_progress(self, item):
        state = {}
        try:
            state = (getattr(self, "_grid_item_state", {}) or {}).get(id(item), {}) or {}
        except Exception:
            state = {}
        label = ""
        frac = 0.0
        try:
            if state.get("completed"):
                label = _("Watched")
                frac = 1.0
            elif state.get("position") and state.get("duration"):
                frac = max(0.0, min(1.0, float(state["position"]) / float(state["duration"])))
                if frac > 0.0:
                    label = _("Continue watching")
                    se, ep = str(state.get("resume_season") or ""), str(state.get("resume_episode") or "")
                    if se.isdigit() and ep.isdigit():
                        label = _("Season %d • Episode %d") % (int(se), int(ep))
        except Exception:
            frac = 0.0
            label = ""
        self._spot_text("spot_progress_percent", "%d%%" % int(round(frac * 100)) if label else "")
        self._spot_show("spot_progress_percent", bool(label))
        self._spot_text("spot_progress_label", label)
        self._spot_show("spot_progress_label", bool(label))
        self._spot_show("spot_progress_track", bool(label))
        width = int(round(PROGRESS_W * frac))
        if label and width > 0:
            sx, sy = self._spot_scale()
            try:
                self["spot_progress_fill"].instance.resize(eSize(max(1, int(width * sx)), max(1, int(6 * sy))))
            except Exception:
                pass
            self._spot_show("spot_progress_fill", True)
        else:
            self._spot_show("spot_progress_fill", False)

    def _spot_cast_apply(self, cast):
        cast = list(cast or [])[:CAST_SLOTS]
        self._spot_text("spot_cast_head", _("CAST") if cast else "")
        self._spot_show("spot_cast_head", bool(cast))
        placeholder = _asset("grid3_cast_placeholder_96.png")
        for k in range(CAST_SLOTS):
            if k < len(cast):
                row = cast[k] or {}
                image = str(row.get("image") or "")
                path = image if (image and os.path.isfile(image)) else placeholder
                if self._spot_cast_paths.get(k) != path:
                    if self._spot_pixmap("spot_cast%d" % k, path):
                        self._spot_cast_paths[k] = path
                else:
                    self._spot_show("spot_cast%d" % k, True)
                self._spot_text("spot_cast_name%d" % k, _short(_clean_person_name(row.get("name")), 15))
                self._spot_text("spot_cast_role%d" % k, _short(_clean_person_name(row.get("role")), 17))
                self._spot_show("spot_cast_name%d" % k, True)
                self._spot_show("spot_cast_role%d" % k, True)
            else:
                for part in ("spot_cast%d", "spot_cast_name%d", "spot_cast_role%d"):
                    self._spot_show(part % k, False)

    def _spot_clear(self):
        for name in ("spot_title", "spot_overview"):
            self._spot_text(name, "")
        self._spot_description("")
        for name in ("spot_country_head", "spot_language_head", "spot_imdb_value", "spot_tmdb_value", "spot_country", "spot_language"):
            self._spot_text(name, "")
        for name in ("spot_imdb_logo", "spot_tmdb_logo", "spot_runtime_icon", "spot_eps_icon"):
            self._spot_show(name, False)
        self._spot_badges({})
        self._spot_genre_chips([])
        self._spot_cast_apply([])
        self._spot_show("spot_title_logo", False)
        self._spot_show("spot_title", True)
        self._spot_show("spot_overview_head", False)
        self._spot_title_logo_path = ""
        for name in ("spot_progress_label", "spot_progress_percent", "spot_progress_track", "spot_progress_fill"):
            self._spot_show(name, False)

    def _spot_current(self):
        try:
            if self.grid_items and 0 <= int(self.index) < len(self.grid_items):
                return self.grid_items[int(self.index)]
        except Exception:
            pass
        return None

    def _spot_fill_meta(self, item, row, overview=None):
        """Paint one record (RAM only). Missing values hide their widget."""
        from .ui_grid_v2_premium import merge_badge_metadata, seed_badge_metadata
        merge_badge_metadata(self, item, row)
        seed_badge_metadata(self, item)
        metadata = dict(row) if isinstance(row, dict) else {}
        row = dict(item, **metadata)
        title = (getattr(self, "_grid_display_titles", {}) or {}).get(self.index)
        if not title:
            try:
                title = self._display_item_title(item, "")
            except Exception:
                title = item.get("name") or ""
        if row.get("title") and not title:
            title = row.get("title")
        self._spot_text("spot_title", title)
        genres = _names(row.get("genres") or row.get("genres_str") or row.get("genre") or item.get("genres") or item.get("genres_str") or item.get("genre") or "", 3)
        self._spot_genre_chips(genres)
        m = re.search(r"(19|20)\d\d", str(row.get("year") or row.get("release_date") or row.get("first_air_date") or ""))
        year = int(m.group(0)) if m else 0
        if not year:
            try:year = int(self._folder_year_value(item) or 0)
            except Exception:year = 0
        try:
            from .age_rating import display_certification
            age = display_certification(row.get("certification") or row.get("age_rating") or item.get("certification") or item.get("age_rating"))
        except Exception:
            age = ""
        runtime_text = _runtime_text(row, self.media_type)
        eps_text = ""
        if self.media_type == "series":
            try:
                eps = int(row.get("number_of_episodes") or 0)
            except Exception:
                eps = 0
            if eps > 0:
                eps_text = (_("%d episode") % eps) if eps == 1 else (_("%d episodes") % eps)
        self._spot_badges({
            "spot_year": str(year) if year else "",
            "spot_age": age or "",
            "spot_runtime": runtime_text,
            "spot_eps": eps_text,
        })
        imdb = _score(row.get("rating_imdb") or row.get("imdb_rating") or item.get("rating_imdb"))
        tmdb = _score(row.get("_tmdb_rating") or row.get("vote_average") or row.get("rating"))
        for name, value, asset in (("imdb", imdb, "us65_logo_imdb_94x36.png"), ("tmdb", tmdb, "us62_icon_tmdb.png")):
            self._spot_text("spot_" + name + "_value", "%.1f" % value if value > 0 else "—")
            self._spot_show("spot_" + name + "_value", True)
            self._spot_show("spot_" + name + "_logo", True)
        if runtime_text:
            self._spot_pixmap("spot_runtime_icon", _asset("metadata_icons_premium/seasons_32.png" if self.media_type == "series" else "metadata_icons_premium/duration_32.png"))
        if eps_text:
            self._spot_pixmap("spot_eps_icon", _asset("metadata_icons_premium/episodes_28.png"))
        country = (metadata.get('countries') or metadata.get('production_countries') or metadata.get('origin_country') or metadata.get('country') or
                   row.get("production_countries") or row.get("countries") or row.get("origin_country") or row.get("country") or "")
        if isinstance(country, (list, tuple)):
            country = ", ".join(_names(country, 2))
        language = row.get("original_language") or row.get("language") or ""
        if not language:
            try:
                from .services.origin_language import work_language_label
                language = work_language_label(row, item) or ""
            except Exception:
                language = ""
        try:
            from .localization import current_language
            ui_lang = str(current_language() or "en").lower()
        except Exception:
            ui_lang = "en"
        is_ar_ui = ui_lang.startswith("ar")
        lang_key = str(language or "").strip().lower().split("-")[0].split("_")[0]
        lang_names_en = {
            "en": "English", "ar": "Arabic", "fr": "French", "de": "German", "es": "Spanish",
            "it": "Italian", "pt": "Portuguese", "ru": "Russian", "tr": "Turkish", "nl": "Dutch",
            "pl": "Polish", "uk": "Ukrainian", "ro": "Romanian", "cs": "Czech", "hu": "Hungarian",
            "el": "Greek", "bg": "Bulgarian", "sr": "Serbian", "hr": "Croatian", "sk": "Slovak",
            "sv": "Swedish", "da": "Danish", "fi": "Finnish", "no": "Norwegian", "nb": "Norwegian",
            "fa": "Persian", "ja": "Japanese", "ko": "Korean", "zh": "Chinese", "cn": "Chinese",
            "hi": "Hindi", "ta": "Tamil", "te": "Telugu", "ml": "Malayalam", "bn": "Bengali",
            "ur": "Urdu", "th": "Thai", "vi": "Vietnamese", "id": "Indonesian", "ms": "Malay",
            "tl": "Tagalog", "he": "Hebrew", "iw": "Hebrew",
        }
        lang_names_ar = {
            "en": "الإنجليزية", "ar": "العربية", "fr": "الفرنسية", "de": "الألمانية", "es": "الإسبانية",
            "it": "الإيطالية", "pt": "البرتغالية", "ru": "الروسية", "tr": "التركية", "nl": "الهولندية",
            "pl": "البولندية", "uk": "الأوكرانية", "ro": "الرومانية", "cs": "التشيكية", "hu": "المجرية",
            "el": "اليونانية", "bg": "البلغارية", "sr": "الصربية", "hr": "الكرواتية", "sk": "السلوفاكية",
            "sv": "السويدية", "da": "الدنماركية", "fi": "الفنلندية", "no": "النرويجية", "nb": "النرويجية",
            "fa": "الفارسية", "ja": "اليابانية", "ko": "الكورية", "zh": "الصينية", "cn": "الصينية",
            "hi": "الهندية", "ta": "التاميلية", "te": "التيلوغوية", "ml": "الماليالامية", "bn": "البنغالية",
            "ur": "الأردية", "th": "التايلاندية", "vi": "الفيتنامية", "id": "الإندونيسية", "ms": "الملايوية",
            "tl": "التاغالوغية", "he": "العبرية", "iw": "العبرية",
        }
        if lang_key:
            language = (lang_names_ar if is_ar_ui else lang_names_en).get(lang_key, _(lang_names_en.get(lang_key, str(language).strip())))
        country_names_en = {
            "US": "United States", "USA": "United States", "GB": "United Kingdom", "UK": "United Kingdom",
            "KR": "South Korea", "EG": "Egypt", "FR": "France", "DE": "Germany", "ES": "Spain",
            "IN": "India", "JP": "Japan", "CN": "China", "HK": "Hong Kong", "TW": "Taiwan",
            "TR": "Turkey", "CA": "Canada", "AU": "Australia", "IT": "Italy", "RU": "Russia",
            "BR": "Brazil", "MX": "Mexico", "AR": "Argentina", "CO": "Colombia", "SE": "Sweden",
            "NO": "Norway", "DK": "Denmark", "FI": "Finland", "NL": "Netherlands", "BE": "Belgium",
            "PL": "Poland", "TH": "Thailand", "ID": "Indonesia", "PH": "Philippines", "SA": "Saudi Arabia",
            "AE": "UAE", "LB": "Lebanon", "SY": "Syria", "KW": "Kuwait", "MA": "Morocco", "TN": "Tunisia",
        }
        country_names_ar = {
            "US": "الولايات المتحدة", "USA": "الولايات المتحدة", "GB": "المملكة المتحدة", "UK": "المملكة المتحدة",
            "KR": "كوريا الجنوبية", "EG": "مصر", "FR": "فرنسا", "DE": "ألمانيا", "ES": "إسبانيا",
            "IN": "الهند", "JP": "اليابان", "CN": "الصين", "HK": "هونغ كونغ", "TW": "تايوان",
            "TR": "تركيا", "CA": "كندا", "AU": "أستراليا", "IT": "إيطاليا", "RU": "روسيا",
            "BR": "البرازيل", "MX": "المكسيك", "AR": "الأرجنتين", "CO": "كولومبيا", "SE": "السويد",
            "NO": "النرويج", "DK": "الدنمارك", "FI": "فنلندا", "NL": "هولندا", "BE": "بلجيكا",
            "PL": "بولندا", "TH": "تايلاند", "ID": "إندونيسيا", "PH": "الفلبين", "SA": "السعودية",
            "AE": "الإمارات", "LB": "لبنان", "SY": "سوريا", "KW": "الكويت", "MA": "المغرب", "TN": "تونس",
        }
        cmap = country_names_ar if is_ar_ui else country_names_en
        cparts = []
        for raw_c in str(country or "").split(","):
            cs = raw_c.strip()
            if not cs or cs.upper() in ("IL", "ISRAEL") or cs == "إسرائيل":
                continue
            cparts.append(cmap.get(cs.upper(), cs))
        country = ", ".join(cparts)
        for name, heading, value in (("country", _("Country"), country), ("language", _("Language"), language)):
            self._spot_text("spot_" + name + "_head", heading if value not in (None, "", 0) else "")
            self._spot_text("spot_" + name, str(value) if value not in (None, "", 0) else "")
            self._spot_show("spot_" + name + "_icon", value not in (None, "", 0))
        text = overview
        if overview is None:
            try:
                from .details_authority import loaded_description_for_display
                text = loaded_description_for_display(item,row,getattr(self,'_grid_settings',None) or {})
            except Exception as exc:
                optional_failure('grid3.first_paint_overview',exc)
                text = ""
            if not text:
                cached_row = self._spot_meta_rows.get(self._spot_key) if self._spot_key else None
                text = str(row.get("_resolved_overview") or ((cached_row or {}).get("_resolved_overview") if isinstance(cached_row, dict) else "") or "")
        elif text and self._spot_key:
            try:
                self._spot_meta_rows.setdefault(self._spot_key, {})["_resolved_overview"] = str(text)
            except Exception:
                pass
        if text and self._spot_key and isinstance(self._spot_meta_rows.get(self._spot_key), dict):
            self._spot_meta_rows[self._spot_key].setdefault("_resolved_overview", str(text))
        self._spot_description(text)
        self._spot_progress(item)

    # ------------------------------------------------------------ navigation
    def _on_visible_badges_ready(self, item, pos):
        """The side panel receives the same early badge result as its poster."""
        if self._spot_suspended or pos != self.index:
            return
        row = dict(self._spot_meta_rows.get(self._spot_key) or {})
        for field in ("_tmdb_rating", "rating", "vote_average", "year", "release_date", "first_air_date", "certification", "age_rating", "_age_rating_checked"):
            if item.get(field) not in (None, ""):
                row[field] = item[field]
        if item.get("_age_rating_checked") and not (item.get("certification") or item.get("age_rating")):
            row.pop("certification", None)
            row.pop("age_rating", None)
        self._spot_fill_meta(item, row, None)

    def _update_header(self, item):
        us_func(PremiumPosterGridScreen._update_header)(self, item)
        if self.media_type not in ("vod", "series"):
            return
        # Invalidate the old title now; paint its panel only after focus settles.
        self._spot_token += 1
        self._spot_key = ""
        self._spot_title_logo_path = ""
        self._spot_text("spot_title", str((item or {}).get("name") or (item or {}).get("title") or ""))
        try:
            if self._spot_cancel is not None:self._spot_cancel.set()
        except Exception:pass
        self._spot_show("spot_title_logo", False)
        self._spot_show("spot_title", True)

    def _spot_update_header_settled(self, item):
        us_func(PremiumPosterGridScreen._update_header)(self, item)
        if self.media_type not in ("vod", "series") or not isinstance(item, dict):
            return
        try:
            key = self._page_visual_key(item) or str(id(item))
        except Exception:
            key = str(id(item))
        if key == self._spot_key:
            return
        self._spot_key = key
        self._spot_token += 1
        try:
            if self._spot_cancel is not None:
                self._spot_cancel.set()
        except Exception:
            pass
        # Clear old identity immediately; only this title's RAM cache may replace it.
        self._spot_title_logo_path = ""
        self._spot_show("spot_title_logo", False)
        self._spot_cast_apply(self._spot_cast_rows.get(key) or [])
        tkey = ""
        if isinstance(item, dict):
            tid = item.get("_locked_tmdb_id") or item.get("_ultra_search_verified_tmdb_id") or item.get("tmdb_id")
            if tid not in (None, ""):
                tkey = "tmdb:%s:%s" % ("tv" if self.media_type == "series" else "movie", str(tid).strip())
        cached = self._spot_logo_paths.get(key, "") or (self._spot_logo_paths.get(tkey, "") if tkey else "")
        if cached and os.path.isfile(cached):
            if self._spot_pixmap("spot_title_logo", cached):
                self._spot_title_logo_path = cached
        self._spot_fill_meta(item, self._spot_meta_rows.get(key) or {}, None)
        self._spot_show("spot_title", not bool(self._spot_title_logo_path))

    def _apply_debounced_grid_focus(self):
        us_func(PremiumPosterGridScreen._apply_debounced_grid_focus)(self)
        try:
            if self.grid_items:self._spot_update_header_settled(self.grid_items[self.index])
            self._spot_settle()
        except Exception as exc:
            optional_failure("grid3.spot_settle", exc)

    def _spot_settle(self):
        if getattr(self, "_screen_closed", False) or self._spot_suspended or self.media_type not in ("vod", "series"):
            return
        item = self._spot_current()
        if not isinstance(item, dict):
            return
        try:
            if self._spot_cancel is not None:self._spot_cancel.set()
        except Exception:pass
        # Every settle owns its own generation, including repeated settles of
        # the same focused title. An older done marker cannot stop this poller.
        self._spot_token += 1
        token = self._spot_token
        ev = threading.Event()
        self._spot_cancel = ev
        profile = self.profile
        media_type = self.media_type
        settings = dict(getattr(self, "_grid_settings", None) or {})
        client = self.client
        item_copy = dict(item)
        jobs = self._spot_jobs

        def post(kind, payload):
            if not ev.is_set():
                jobs.put((token, kind, payload))

        def worker():
            # Fix17: the title-logo lookup used to run AFTER the metadata request and
            # the overview, so the logo always appeared last. It now runs on its own
            # thread: at once when the TMDb identity is already known, otherwise as
            # soon as the metadata request has produced it. Cast and overview no
            # longer wait for it, and the worker still ends only after the logo is
            # posted, so the "done" marker stays last.
            logo_state = {"thread": None, "row": None, "path": ""}
            row = {}
            def trace(stage,overview=None,error=''):
                try:
                    from .metadata_trace import trace_metadata
                    trace_metadata(stage,profile,item_copy,row,settings,overview=overview,
                                   folder=getattr(self,'category_title',''),error=error)
                except Exception:pass
            try:
                if ev.is_set():
                    return
                from .details_authority import load_canonical
                row = load_canonical(profile, media_type, item_copy) or {}
                trace('initial_cache')
                # HDD-only, identity/language-validated lookup before potentially
                # slow metadata requests. No network or image conversion here.
                from .title_logo_ultra import ultra_title_logo_cached, ultra_title_logo_identity_id
                logo_path = ultra_title_logo_cached(media_type, item_copy, row,
                                                    canvas_size=TITLE_LOGO_SIZE)
                if logo_path:
                    post("title_logo", logo_path)

                def start_logo(source_row):
                    if logo_path or ev.is_set() or logo_state["thread"] is not None:
                        return
                    snapshot = dict(source_row or {})

                    def run():
                        try:
                            from .title_logo_ultra import resolve_ultra_title_logo
                            visible_title = snapshot.get("title") or snapshot.get("name") or item_copy.get("name") or ""
                            path, new_row = resolve_ultra_title_logo(
                                profile, media_type, item_copy, snapshot,
                                canvas_size=TITLE_LOGO_SIZE, visible_title=visible_title,
                                cancel_event=ev, settings=settings
                            )
                            logo_state["row"] = new_row
                            logo_state["path"] = path or ""
                            if not ev.is_set():
                                post("title_logo", path if (path and os.path.isfile(path)) else "")
                        except Exception as exc:
                            optional_failure("grid3.title_logo", exc)
                            if not ev.is_set():
                                post("title_logo", "")

                    thread = threading.Thread(target=run, name="ultrastalker-grid3-logo")
                    thread.daemon = True
                    logo_state["thread"] = thread
                    thread.start()

                post("meta", (row, None))
                try:
                    if ultra_title_logo_identity_id(item_copy, row) not in (None, ""):
                        start_logo(row)
                except Exception as exc:
                    optional_failure("grid3.title_logo_early", exc)
                try:
                    from .details_authority import metadata_language_ready, resolve_metadata_fast
                    if not ev.is_set():
                        row = resolve_metadata_fast(profile, media_type, item_copy, current=row, cancel_event=ev,
                                                    settings=settings, provider_client=client) or row
                except Exception as exc:
                    optional_failure("grid3.resolve_meta", exc)
                    trace('metadata_error',error=type(exc).__name__)
                trace('metadata_result')
                start_logo(row)
                overview = None
                try:
                    from .details_authority import details_overview
                    text, ready = details_overview(profile, media_type, item_copy, row)
                    if ready or text:
                        overview = text
                except Exception as exc:
                    optional_failure("grid3.overview_resolve", exc)
                    overview = None
                post("meta", (row, overview))

                tmdb_id = row.get("tmdb_id")
                missing_origin = not (row.get('countries') or row.get('production_countries') or row.get('origin_country') or row.get('country')) or not row.get('original_language')
                if (not tmdb_id or missing_origin) and logo_state["thread"] is not None:
                    # Fix24: the logo lane may discover identity/origin even when
                    # the first metadata lane returned a sparse/provider-only row.
                    # Join it back into text metadata and PAINT it, not only cast.
                    while logo_state["thread"].is_alive() and not ev.is_set():
                        logo_state["thread"].join(0.2)
                    if isinstance(logo_state["row"], dict) and not ev.is_set():
                        from .details_authority import adopt_verified_artwork_metadata
                        row = adopt_verified_artwork_metadata(profile,media_type,item_copy,row,logo_state['row'],
                            settings=settings,cancel_event=ev,provider_client=client) or row
                        text, ready = details_overview(profile,media_type,item_copy,row)
                        overview = text if (ready or text) else None
                        post('meta',(row,overview))
                        trace('artwork_join',overview)
                        tmdb_id = row.get('tmdb_id')
                trace('final',overview)
                if not tmdb_id or ev.is_set():
                    post("cast", [])
                    return
                from . import cast_portraits
                mt = row.get("media_type") or media_type
                quick = cast_portraits.cached_cast(settings, mt, tmdb_id)
                if quick:
                    post("cast", quick)
                    if all(c.get("image") for c in quick):
                        return
                post("cast", cast_portraits.resolve_cast(settings, mt, tmdb_id, cancel_event=ev))
            except Exception as exc:
                optional_failure("grid3.spot_worker", exc)
                trace('worker_error',error=type(exc).__name__)
            finally:
                thread = logo_state["thread"]
                try:
                    while thread is not None and thread.is_alive() and not ev.is_set():
                        thread.join(0.2)
                except Exception:
                    pass
                # Signal completion of this focus result.
                if not ev.is_set():jobs.put((token, "done", None))

        try:
            self._spot_future = _SPOT_EXECUTOR.submit(worker, priority=0, _task_key="grid3-spot:%x" % id(self), _replace_task_key=True)
            self._spot_idle_ticks = 0
            self._spot_timer.start(45, False)
        except Exception as exc:
            optional_failure("grid3.spot_submit", exc)

    def _spot_drain(self):
        if getattr(self, "_screen_closed", False):
            self._spot_stop()
            return
        if self._spot_suspended:
            return
        try:
            self._drain_visible_poster_results(4)
        except Exception:
            pass
        handled = 0
        done = False
        while handled < 6:
            try:
                token, kind, payload = self._spot_jobs.get_nowait()
            except queue.Empty:
                break
            handled += 1
            if token != self._spot_token:
                continue
            if kind == "done":
                done = True
                continue
            item = self._spot_current()
            if not isinstance(item, dict):
                continue
            try:
                if kind == "meta":
                    row, overview = payload
                    if row:
                        prev_row = self._spot_meta_rows.get(self._spot_key)
                        merged_row = dict(prev_row) if isinstance(prev_row, dict) else {}
                        merged_row.update(dict(row))
                        if overview not in (None, ""):
                            merged_row["_resolved_overview"] = str(overview)
                        self._spot_meta_rows[self._spot_key] = merged_row
                        while len(self._spot_meta_rows) > 64:
                            self._spot_meta_rows.pop(next(iter(self._spot_meta_rows)))
                        row = merged_row
                    self._spot_fill_meta(item, row, overview)
                    self._card_rating_layout(item, self.index)
                elif kind == "title_logo":
                    if payload:
                        committed = payload == self._spot_title_logo_path
                        if payload != self._spot_title_logo_path:
                            if self._spot_pixmap("spot_title_logo", payload):
                                self._spot_title_logo_path = payload
                                committed = True
                        else:
                            self._spot_show("spot_title_logo", True)
                        if committed:
                            self._spot_logo_paths[self._spot_key] = payload
                            cur_item = self._spot_current()
                            if isinstance(cur_item, dict):
                                tid = cur_item.get("_locked_tmdb_id") or cur_item.get("_ultra_search_verified_tmdb_id") or cur_item.get("tmdb_id")
                                if tid not in (None, ""):
                                    tkey = "tmdb:%s:%s" % ("tv" if self.media_type == "series" else "movie", str(tid).strip())
                                    self._spot_logo_paths[tkey] = payload
                            while len(self._spot_logo_paths) > 256:
                                self._spot_logo_paths.pop(next(iter(self._spot_logo_paths)))
                            self._spot_show("spot_title", False)
                    else:
                        self._spot_show("spot_title_logo", False)
                        self._spot_title_logo_path = ""
                        self._spot_show("spot_title", True)
                elif kind == "cast":
                    self._spot_cast_rows[self._spot_key] = list(payload or [])
                    while len(self._spot_cast_rows) > 64:
                        self._spot_cast_rows.pop(next(iter(self._spot_cast_rows)))
                    self._spot_cast_apply(payload)
            except Exception as exc:
                optional_failure("grid3.spot_apply", exc)
        self._spot_idle_ticks = 0 if handled else (getattr(self, "_spot_idle_ticks", 0) + 1)
        # Stop polling when the current focus job reported done (and the queue is
        # empty), or after ~20 s of silence as a safety net.
        if (done and self._spot_jobs.empty()) or self._spot_idle_ticks > 160:
            self._spot_idle_ticks = 0
            try:
                self._spot_timer.stop()
            except Exception:
                pass
