# -*- coding: utf-8 -*-
"""Localised text fitting and layout readiness.

Methods moved verbatim out of ``PortalHomeScreen`` (ui_screens_home.py); behaviour is unchanged.
This module is imported by ui_screens_home.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import int, round, max, min
from .ui_screens_home import (
    LOG,
    _mem34,
    _ui_diag,
    diagnostic_failure,
    ePoint,
    eSize,
    fit_label_to_box,
    gFont,
    optional_failure,
    splash_home_is_warm,
    time,
)


class HomeLayoutMixin(object):
    """Localised text fitting and layout readiness."""

    def _fit_home_localized_text(self):
        # R48: the seven fixed cards keep their exact geometry.  Only their
        # description text becomes receiver-measured and language independent.
        if getattr(self,"_sc_mode",False):return
        for idx in range(7):
            try:
                fit_label_to_box(self,"card_sub%d"%idx,max_size=16,min_size=9,padding=12,
                                 allow_two_lines=True,prefer_two_lines=False,height_padding=3)
            except Exception as exc:
                optional_failure("ui.home_card_localized_fit",exc)
        self._fit_home_account_row()

    def _fit_home_account_row(self):
        """Center connection and stacked expiry rows inside the Home status card.

        The status dot/word keep their combined measured center. Expiry uses
        two centered native labels, preserving the card's own x=218 axis.
        """
        try:
            sx=float(getattr(self,"_home_sx",1.0) or 1.0)
            sy=float(getattr(self,"_home_sy",1.0) or 1.0)
            left=int(round(78*sx))
            right=int(round(358*sx))
            center=int(round(218*sx))
            row_h=max(1,int(round(30*sy)))

            def _measure(name):
                try:
                    return max(1,int(self[name].instance.calculateSize().width()))
                except Exception:
                    return 1

            def _position_pair(first, second, y, spacing):
                a=self[first].instance
                b=self[second].instance
                if a is None or b is None:
                    return False
                gap=max(1,int(round(spacing*sx)))
                w1=_measure(first)
                w2=_measure(second)
                avail=right-left
                w1=min(w1,avail)
                w2=min(w2,max(1,avail-w1-gap))
                total=w1+gap+w2
                x=max(left,min(right-total, center-total//2))
                a.move(ePoint(x,int(round(y*sy))))
                a.resize(eSize(w1,row_h))
                b.move(ePoint(x+w1+gap,int(round(y*sy))))
                b.resize(eSize(w2,row_h))
                return True

            # The little green/red dot stays alongside the status text.
            _position_pair("portal_state","portal_connected",328,7)

            # B: the expiry caption and full date have separate centered rows.
            for name,y,height in (("portal_expiry_prefix",360,26),("portal_expiry",386,30)):
                inst=self[name].instance
                if inst is not None:
                    inst.move(ePoint(left,int(round(y*sy))))
                    inst.resize(eSize(right-left,int(round(height*sy))))
        except Exception as exc:
            optional_failure("ui.home_account_card_layout",exc)

    def _layout_ready(self):
        _perf_t0=time.monotonic()
        self._home_clock_tick()
        self._fit_home_localized_text()
        for _g in range(3):
            try:
                _lst=self["recent_list%d"%_g]
                _lst.row_width=305;_lst.set_layout(98,0,22,13,row_style="home_recent")
                try:_lst.l.setFont(7,_ultra_rfont("Regular",18))
                except Exception as exc:optional_failure("ui.home_recent_font7",exc)
                if _lst.instance is not None:
                    _lst.instance.setSelectionEnable(0);_lst.instance.setTransparent(1);_lst.instance.setScrollbarMode(2)
            except Exception as exc:optional_failure("ui.home_recent_list_layout",exc)
        try:_ui_diag("ui_ready",screen="home",elapsed_ms=int((time.monotonic()-self._ui_diag_open_mono)*1000.0))
        except Exception as exc: diagnostic_failure("ui.home.failsoft", exc)
        _phase=time.monotonic();self._image_layout_ready()
        if LOG is not None: LOG.info("PERF25 home layout_image elapsed_ms=%d",int((time.monotonic()-_phase)*1000))
        _phase=time.monotonic();self._load_menu_icons()
        if LOG is not None: LOG.info("PERF25 home layout_icons elapsed_ms=%d",int((time.monotonic()-_phase)*1000))
        _phase=time.monotonic();self._restore_home_focus()
        if LOG is not None: LOG.info("PERF25 home layout_focus elapsed_ms=%d",int((time.monotonic()-_phase)*1000))
        # Point 5: build the purely-local Recent snapshot before first paint.
        # It is only SQLite/HDD cache work, never network I/O.  The old deferred
        # pass made the lower Home cards appear a beat after the fixed upper
        # cards (and then repaint again during Hero settle), which looked like
        # flashing even though the content itself was static.
        _phase=time.monotonic()
        try:
            self._load_recent_cards(initial=True)
            self._recent_snapshot_ready=True
        except Exception as exc:
            optional_failure("ui.home_recent_first_paint",exc)
        if LOG is not None: LOG.info("POINT5 home layout_recent_resident elapsed_ms=%d",int((time.monotonic()-_phase)*1000))
        _phase=time.monotonic();self._load_account_state()
        if LOG is not None: LOG.info("PERF25 home layout_account_queue elapsed_ms=%d",int((time.monotonic()-_phase)*1000))
        # R268: selected-portal cold-start work now completes behind Splash.
        # When that warm state exists, bind the already-decoded Hero before the
        # first Home paint instead of showing Home and firing an 80ms settle.
        _phase=time.monotonic()
        _warm=False
        try:_warm=bool(splash_home_is_warm and splash_home_is_warm(self.profile))
        except Exception:_warm=False
        if _warm:
            try:self._startup_hero_apply()
            except Exception as exc:optional_failure("ui.home_warm_hero_first_paint",exc)
            if LOG is not None: LOG.info("R268 home layout_hero_warm elapsed_ms=%d",int((time.monotonic()-_phase)*1000))
        else:
            try:self._startup_hero_timer.stop();self._startup_hero_timer.start(80,True)
            except Exception:self._startup_hero_apply()
            if LOG is not None: LOG.info("PERF26 home layout_hero_deferred elapsed_ms=%d",int((time.monotonic()-_phase)*1000))
        if LOG is not None: LOG.info("PERF25 home layout_done elapsed_ms=%d mono_ms=%d",int((time.monotonic()-_perf_t0)*1000),int(time.monotonic()*1000))
        _mem34("home_layout_done")
from .wqhd_layout import responsive_font as _ultra_rfont, factors as _ultra_factors

def _ultra_osd_scale():
    return _ultra_factors()[1]
