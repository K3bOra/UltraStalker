# -*- coding: utf-8 -*-
"""Cache-first refresh restricted to the currently visible folder and page."""
from __future__ import absolute_import
import time
import weakref
import threading
try:
    from .us_env import str,int
except ImportError:
    pass
_TTL=900.0
_LOCK=threading.Lock()
_RUNNING=set()
def _valid_pages(pages,native):
    if not pages:return False
    any_items=False
    for number,payload in pages.items():
        if not isinstance(payload,dict) or not isinstance(payload.get("items"),list):return False
        try:
            size=int(payload.get("page_size") or 0)
            total=int(payload.get("total") or 0)
        except (TypeError,ValueError):return False
        if size!=int(native) or total<0:return False
        rows=payload["items"]
        if any(not isinstance(row,dict) for row in rows):return False
        if not rows and (int(number)-1)*size<total:return False
        any_items=any_items or bool(rows)
    return any_items

def note_fresh(client,media,genre):
    stamps=getattr(client,'_folder_fresh_at',None)
    if stamps is None:stamps={};client._folder_fresh_at=stamps
    stamps[(str(media),str(genre))]=time.time()
    if len(stamps)>128:stamps.pop(next(iter(stamps)))
def schedule(screen):
    if getattr(screen,'_screen_closed',False) or getattr(screen,'_view_active',False):return
    client=screen.client
    # Local libraries and raw M3U have no independently refreshable remote folders.
    if not hasattr(client,'_xtream') and not hasattr(client,'_cache_put_usable'):return
    if hasattr(client,'_xtream') and not client._xtream:return
    media,genre=str(screen.media_type),str(screen.genre)
    stamp=(getattr(client,'_folder_fresh_at',{}) or {}).get((media,genre),0)
    if hasattr(client,'_xtream'):
        try:
            import os
            cid=client._xtream_category_id(media,genre) or '*'
            stamp=max(stamp,os.path.getmtime(client._xtream_category_cache_path(media,cid)))
        except Exception:pass
    if time.time()-stamp<_TTL:return
    snapshot=(media,genre,int(screen.page),int(getattr(screen,'_content_epoch',0) or 0))
    if getattr(screen,'_folder_refresh_scheduled',None)==snapshot:return
    screen._folder_refresh_scheduled=snapshot
    ref=weakref.ref(screen)
    from twisted.internet import reactor
    def active(owner):
        return (owner is not None and not getattr(owner,'_screen_closed',False)
            and not getattr(owner,'_grid_images_suspended',False)
            and (str(owner.media_type),str(owner.genre),int(owner.page),int(getattr(owner,'_content_epoch',0) or 0))==snapshot)
    def start():
        owner=ref()
        if not active(owner):return
        key=(id(client),media,genre)
        with _LOCK:
            if key in _RUNNING:return
            _RUNNING.add(key)
        cancel=getattr(owner,'_page_prefetch_cancel',None)
        native=max(1,int(getattr(owner,'_portal_page_size',0) or owner.page_size))
        first=((snapshot[2]-1)*owner.page_size)//native+1
        last=((snapshot[2]*owner.page_size-1)//native)+1
        profile=dict(owner.profile or {})
        def work():
            isolated=None
            pages={}
            try:
                if cancel is not None and cancel.is_set():return
                from .ui import _new_isolated_source_client
                isolated=_new_isolated_source_client(profile,timeout=6)
                if hasattr(isolated,'_xtream'):
                    isolated._ensure(cancel)
                    isolated._load_xtream_category(media,genre,cancel_event=cancel,force=True)
                    for page in range(first,last+1):
                        if cancel is not None and cancel.is_set():return
                        pages[page]=isolated.ordered_page(media,genre,page,cancel_event=cancel)
                else:
                    for page in range(first,last+1):
                        if cancel is not None and cancel.is_set():return
                        pages[page]=isolated.ordered_page(media,genre,page,cancel_event=cancel,force=True)
                # Empty or malformed replies never erase the currently visible last-good page.
                if not _valid_pages(pages,native):return
                note_fresh(client,media,genre)
                def apply():
                    owner=ref()
                    if not active(owner) or getattr(owner,'_busy',False):return
                    if cancel is not None and cancel.is_set():return
                    owner._content_epoch=int(getattr(owner,"_content_epoch",0) or 0)+1
                    owner._grid_page_warm_token=int(getattr(owner,"_grid_page_warm_token",0) or 0)+1
                    owner._portal_page_cache.clear()
                    with owner._prepared_page_lock:owner._prepared_page_cache.clear()
                    for page,payload in pages.items():
                        owner._portal_page_cache[page]=[dict(x) for x in payload.get('items',[]) if isinstance(x,dict)]
                    sample=pages[first]
                    owner._portal_total=int(sample.get('total') or 0)
                    owner._portal_page_size=max(1,int(sample.get('page_size') or native))
                    index=int(getattr(owner,'index',0) or 0)
                    previous=list(getattr(owner,'grid_items',[]) or [])
                    def ident(row):return str(row.get('id') or row.get('stream_id') or row.get('series_id') or row.get('url') or row.get('cmd') or '') if isinstance(row,dict) else ''
                    selected=ident(previous[index]) if 0<=index<len(previous) else ''
                    merged=[]
                    for number in sorted(pages):merged.extend(pages[number].get('items') or [])
                    offset=(snapshot[2]-1)*int(owner.page_size)-(first-1)*native
                    for position,row in enumerate(merged[max(0,offset):max(0,offset)+int(owner.page_size)]):
                        if selected and ident(row)==selected:index=position;break
                    owner.load_page(snapshot[2],index)
                reactor.callFromThread(apply)
            except Exception:
                pass  # Keep last-good content and let manual refresh report failures.
            finally:
                if isolated is not None:
                    try:isolated.cancel_pending_requests()
                    except Exception:pass
                with _LOCK:_RUNNING.discard(key)
        try:
            from .ui import _CATEGORY_PREFETCH_EXECUTOR
            _CATEGORY_PREFETCH_EXECUTOR.submit(work)
        except Exception:
            with _LOCK:_RUNNING.discard(key)
    reactor.callLater(1.5,start)

def schedule_list(screen,media,genre,page,paint):
    client=screen.client
    if not hasattr(client,'_xtream') and not hasattr(client,'_cache_put_usable'):return
    if hasattr(client,'_xtream') and not client._xtream:return
    stamp=(getattr(client,'_folder_fresh_at',{}) or {}).get((str(media),str(genre)),0)
    if hasattr(client,'_xtream'):
        try:
            import os
            cid=client._xtream_category_id(media,genre) or '*'
            stamp=max(stamp,os.path.getmtime(client._xtream_category_cache_path(media,cid)))
        except Exception:pass
    if time.time()-stamp<_TTL:return
    snap=(str(media),str(genre),int(page))
    if getattr(screen,'_folder_list_refresh_scheduled',None)==snap:return
    screen._folder_list_refresh_scheduled=snap
    ref=weakref.ref(screen)
    cancel=threading.Event()
    screen.onClose.append(cancel.set)
    profile=dict(screen.profile or {})
    from twisted.internet import reactor
    def active():
        owner=ref()
        if owner is None or getattr(owner,'_screen_closed',False) or getattr(owner,'_browser_images_suspended',False) or getattr(owner,'level','')!='items':return False
        return (str(owner.media_type),str(owner.genre),int(owner.page))==snap
    def start():
        if not active():return
        key=(id(client),str(media),str(genre))
        with _LOCK:
            if key in _RUNNING:return
            _RUNNING.add(key)
        def work():
            isolated=None
            try:
                if cancel.is_set():return
                from .ui import _new_isolated_source_client
                isolated=_new_isolated_source_client(profile,timeout=6)
                if hasattr(isolated,'_xtream'):
                    isolated._ensure(cancel)
                    isolated._load_xtream_category(media,genre,cancel_event=cancel,force=True)
                    payload=isolated.ordered_page(media,genre,page,cancel_event=cancel)
                else:payload=isolated.ordered_page(media,genre,page,cancel_event=cancel,force=True)
                rows=payload.get('items') or []
                if not rows or cancel.is_set():return
                note_fresh(client,media,genre)
                def apply():
                    if not active() or cancel.is_set():return
                    owner=ref()
                    if getattr(owner,'_busy',False):return
                    try:index=owner['list'].getSelectedIndex()
                    except Exception:index=0
                    previous=list(getattr(owner,'content_items',[]) or [])
                    def ident(row):return str(row.get('id') or row.get('stream_id') or row.get('series_id') or row.get('url') or row.get('cmd') or '') if isinstance(row,dict) else ''
                    selected=ident(previous[index]) if 0<=index<len(previous) else ''
                    if selected:
                        for position,row in enumerate(rows):
                            if ident(row)==selected:index=position;break
                    paint(rows)
                    try:owner['list'].moveToIndex(min(index,len(rows)-1))
                    except Exception:pass
                reactor.callFromThread(apply)
            except Exception:pass
            finally:
                if isolated is not None:
                    try:isolated.cancel_pending_requests()
                    except Exception:pass
                with _LOCK:_RUNNING.discard(key)
        try:
            from .ui import _CATEGORY_PREFETCH_EXECUTOR
            _CATEGORY_PREFETCH_EXECUTOR.submit(work)
        except Exception:
            with _LOCK:_RUNNING.discard(key)
    reactor.callLater(1.5,start)
