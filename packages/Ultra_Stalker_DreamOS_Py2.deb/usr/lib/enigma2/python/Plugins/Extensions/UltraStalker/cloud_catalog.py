# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

import json
import os
import re
import ssl
import tempfile
import threading
import time
try:
    from urllib.error import HTTPError
    from urllib.parse import urlencode, urlsplit
    from urllib.request import build_opener, HTTPRedirectHandler, HTTPSHandler, Request
except ImportError:
    from urllib2 import build_opener, HTTPError, HTTPRedirectHandler, HTTPSHandler, Request
    from urllib import urlencode
    from urlparse import urlsplit

from . import _
from .storage import CONFIG_DIR
from .version import PLUGIN_VERSION

_ENDPOINT = "https://ultrastalker-catalog-v2.k3borazz0.workers.dev/v2/"
_PAGE_BYTES = 32768
_ID = re.compile(r"\A[a-f0-9]{32}\Z")
_TEXT = type(u"")
_DATE = re.compile(r"\A[0-9]{4}-[0-9]{2}-[0-9]{2}\Z")

SUMMARY_CACHE_TTL = 86400 * 7
_GENERIC_SERVER_LABEL_RE = re.compile(
    r"^(?:free\s+)?(?:portal|xtream|stalker|server|source|catalog|host|account|line)s?\s*#?\s*\d+$",
    re.IGNORECASE,
)
_EXPLICIT_SUFFIX_RE = re.compile(
    r"(?:\s*[-•|#:]\s*(?:account|acc|server|srv|line|user|#)?\s*\d+|\s+\(\d+\)|\s+#\d+|\s+0+\d+)$",
    re.IGNORECASE,
)
_ANY_TRAILING_NUM_RE = re.compile(
    r"(?:\s*[-•|#:_]?\s*(?:account|acc|server|srv|line|user|#)?\s*\d+|\s+\(\d+\))$",
    re.IGNORECASE,
)

_MEM_LOCK = threading.Lock()
_SERVER_FETCH_LOCKS = {}
_SUMMARY_MEM_CACHE = {"portal": {}, "xtream": {}}
_SUMMARY_LOADED = {"portal": False, "xtream": False}
_SUMMARY_DIRTY = {"portal": False, "xtream": False}
_ACCOUNTS_FIRST_PAGE_CACHE = {}


class CatalogError(Exception):
    pass


class _NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def _write(path, data):
    fd, temp = tempfile.mkstemp(prefix=".catalog-write-", dir=CONFIG_DIR)
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(data)
        os.rename(temp, path)
    finally:
        if os.path.exists(temp):
            os.unlink(temp)


def _get_server_lock(kind, server_id):
    key = (str(kind or "portal"), _TEXT(server_id or ""))
    with _MEM_LOCK:
        lock = _SERVER_FETCH_LOCKS.get(key)
        if lock is None:
            lock = threading.Lock()
            _SERVER_FETCH_LOCKS[key] = lock
        return lock


def _summary_cache_path(kind):
    return os.path.join(CONFIG_DIR, ".cloud-server-summary-" + str(kind) + ".json")


def _ensure_summary_loaded(kind):
    kind = str(kind or "portal")
    with _MEM_LOCK:
        if _SUMMARY_LOADED.get(kind):
            return dict(_SUMMARY_MEM_CACHE.get(kind) or {})
        _SUMMARY_LOADED[kind] = True
        path = _summary_cache_path(kind)
        loaded = {}
        try:
            if os.path.isfile(path):
                with open(path, "rb") as handle:
                    raw = json.loads(handle.read().decode("utf-8"))
                if isinstance(raw, dict):
                    for k, v in raw.items():
                        if isinstance(v, dict) and (v.get("name") or v.get("count")):
                            loaded[_TEXT(k)] = {
                                "name": _TEXT(v.get("name") or "").strip(),
                                "count": int(v.get("count") or 0),
                                "more": bool(v.get("more")),
                                "ts": int(v.get("ts") or 0),
                            }
        except Exception:
            loaded = {}
        _SUMMARY_MEM_CACHE[kind] = loaded
        return dict(loaded)


def get_cached_server_summaries(kind):
    return _ensure_summary_loaded(kind)


def flush_server_summaries(kind):
    kind = str(kind or "portal")
    with _MEM_LOCK:
        if not _SUMMARY_DIRTY.get(kind):
            return
        snapshot = dict(_SUMMARY_MEM_CACHE.get(kind) or {})
        _SUMMARY_DIRTY[kind] = False
    try:
        _write(_summary_cache_path(kind), json.dumps(snapshot).encode("utf-8"))
    except Exception:
        pass


def is_generic_server_label(label):
    text = _TEXT(label or "").strip()
    if not text:
        return True
    return bool(_GENERIC_SERVER_LABEL_RE.match(text))


def _extract_direct_server_name(item):
    if not isinstance(item, dict):
        return ""
    for key in ("server_name", "name", "title", "host", "domain", "label"):
        val = _TEXT(item.get(key) or "").strip()
        if not val or is_generic_server_label(val):
            continue
        if "://" in val:
            try:
                parsed = urlsplit(val)
                val = _TEXT(parsed.hostname or parsed.netloc or val).strip()
            except Exception:
                pass
        if val and not is_generic_server_label(val):
            return val
    return ""


def _extract_direct_server_count(item):
    if not isinstance(item, dict):
        return None
    for key in ("count", "accounts_count", "account_count", "total", "servers_count", "items_count"):
        val = item.get(key)
        if val is not None:
            try:
                n = int(val)
                if n >= 0:
                    return n
            except Exception:
                pass
    accounts = item.get("accounts") or item.get("items")
    if isinstance(accounts, list) and accounts:
        return len(accounts)
    return None


def _derive_server_name_from_accounts(items, fallback=""):
    labels = []
    for row in items or []:
        if not isinstance(row, dict):
            continue
        lbl = _TEXT(row.get("server_name") or row.get("name") or row.get("label") or "").strip()
        if lbl and not is_generic_server_label(lbl):
            labels.append(lbl)
    if not labels:
        return _TEXT(fallback or "").strip()
    first = labels[0]
    if len(labels) > 1:
        if first.lower() == labels[1].lower():
            cleaned_same = _EXPLICIT_SUFFIX_RE.sub("", first).strip()
            if cleaned_same and not is_generic_server_label(cleaned_same):
                return cleaned_same
            return first
        stripped = [_ANY_TRAILING_NUM_RE.sub("", s).strip() for s in labels[:min(len(labels), 5)]]
        if stripped[0] and not is_generic_server_label(stripped[0]):
            first_low = stripped[0].lower()
            if all(s.lower() == first_low for s in stripped):
                return stripped[0]
    cleaned = _EXPLICIT_SUFFIX_RE.sub("", first).strip()
    if cleaned and not is_generic_server_label(cleaned):
        return cleaned
    return first


def _get(path, select=False):
    request = Request(_ENDPOINT + path, data=b"{}" if select else None, headers={
        "Accept": "application/json",
        "User-Agent": "UltraStalker/%s (Enigma2)" % PLUGIN_VERSION,
    })
    opener = build_opener(_NoRedirect(), HTTPSHandler(context=ssl.create_default_context()))
    try:
        response = opener.open(request, timeout=6)
        try:
            raw = response.read(_PAGE_BYTES + 1)
        finally:
            response.close()
    except HTTPError as error:
        code = error.code
        error.close()
        raise CatalogError(str(code))
    if len(raw) > _PAGE_BYTES:
        raise CatalogError("invalid")
    return json.loads(raw.decode("utf-8"))


def _page(payload, kind=None, is_server_index=False):
    items = payload["items"]
    after = payload.get("next")
    if not isinstance(items, list) or len(items) > 50:
        raise CatalogError("invalid")
    summaries = _ensure_summary_loaded(kind) if (kind and is_server_index) else {}
    rows = []
    previous = ""
    for item in items:
        row_id, label = item["id"], item["label"]
        if not _ID.match(row_id) or row_id <= previous or not isinstance(label, _TEXT) or not label:
            raise CatalogError("invalid")
        row = {"id": row_id, "label": label[:80]}
        if item.get("expires_on"):
            row["expiry"] = _expiry_label(item["expires_on"])
        if is_server_index:
            direct_name = _extract_direct_server_name(item)
            direct_count = _extract_direct_server_count(item)
            cached = summaries.get(row_id) or {}
            resolved_name = direct_name or _TEXT(cached.get("name") or "").strip()
            resolved_count = int(cached.get("count") or 0)
            if resolved_name and not is_generic_server_label(resolved_name):
                row["server_name"] = resolved_name[:80]
                row["label"] = resolved_name[:80]
            if direct_count is not None:
                row["count"] = direct_count
                row["more"] = False
                row["indexed_summary"] = True
            elif resolved_count > 0:
                row["count"] = resolved_count
                row["more"] = bool(cached.get("more"))
        rows.append(row)
        previous = row_id
    if after is not None and (not rows or previous != after):
        raise CatalogError("invalid")
    out = {"items": rows, "next": after}
    total = payload.get("total") or payload.get("count")
    if total is not None:
        try:
            out["total"] = int(total)
        except Exception:
            pass
    return out


def _cache_path(kind):
    return os.path.join(CONFIG_DIR, ".cloud-catalog-hostnames-" + kind + ".json")


def cached_servers(kind):
    try:
        with open(_cache_path(kind), "rb") as handle:
            raw = handle.read(_PAGE_BYTES + 1)
        if len(raw) <= _PAGE_BYTES:
            return _page(json.loads(raw.decode("utf-8")), kind=kind, is_server_index=True)
    except (IOError, ValueError, KeyError, TypeError, CatalogError):
        pass
    return None


def _record_summary_from_accounts_page(kind, server_id, parsed_page, total_count=None):
    kind = str(kind or "portal")
    server_id = _TEXT(server_id or "").strip()
    if not server_id or not isinstance(parsed_page, dict):
        return None
    items = parsed_page.get("items") or []
    explicit_total = total_count if total_count is not None else parsed_page.get("total")
    has_more = bool(parsed_page.get("next")) and (explicit_total is None)
    count = int(explicit_total if explicit_total is not None else len(items))
    name = _derive_server_name_from_accounts(items, fallback="")
    if not name and count <= 0:
        return None
    _ensure_summary_loaded(kind)
    with _MEM_LOCK:
        prev = (_SUMMARY_MEM_CACHE.get(kind) or {}).get(server_id) or {}
        final_name = name if (name and not is_generic_server_label(name)) else _TEXT(prev.get("name") or "").strip()
        final_count = count if count > 0 else int(prev.get("count") or 0)
        entry = {
            "name": final_name[:80],
            "count": final_count,
            "more": bool(has_more),
            "ts": int(time.time()),
        }
        _SUMMARY_MEM_CACHE.setdefault(kind, {})[server_id] = entry
        _SUMMARY_DIRTY[kind] = True
    return entry


def page(kind, server=None, after=None):
    if server and not after:
        lock = _get_server_lock(kind, server)
        with lock:
            with _MEM_LOCK:
                cached_entry = _ACCOUNTS_FIRST_PAGE_CACHE.get((kind, server))
            if cached_entry and (time.time() - cached_entry[0] <= 900):
                return dict(cached_entry[1])
            path = kind + "/servers/" + server + "/accounts"
            raw_payload = _get(path)
            result = _page(raw_payload, kind=kind, is_server_index=False)
            with _MEM_LOCK:
                _ACCOUNTS_FIRST_PAGE_CACHE[(kind, server)] = (time.time(), dict(result))
            _record_summary_from_accounts_page(kind, server, result)
            flush_server_summaries(kind)
            return result
    path = kind + "/servers"
    if server:
        path += "/" + server + "/accounts"
    if after:
        path += "?after=" + after
    raw_payload = _get(path)
    result = _page(raw_payload, kind=kind, is_server_index=(not server))
    if after and result["items"] and result["items"][0]["id"] <= after:
        raise CatalogError("invalid")
    if not server and not after:
        try:
            _write(_cache_path(kind), json.dumps(raw_payload).encode("utf-8"))
        except OSError:
            pass
    return result


def resolve_server_summary(kind, server_id, fallback_label=""):
    server_id = _TEXT(server_id or "").strip()
    if not server_id:
        return {"id": server_id, "name": _TEXT(fallback_label or ""), "count": 0, "more": False}
    summaries = _ensure_summary_loaded(kind)
    cached = summaries.get(server_id)
    now = int(time.time())
    if cached and cached.get("name") and not is_generic_server_label(cached.get("name")) and int(cached.get("count") or 0) > 0:
        if now - int(cached.get("ts") or 0) < SUMMARY_CACHE_TTL:
            return {
                "id": server_id,
                "name": _TEXT(cached.get("name")),
                "count": int(cached.get("count") or 0),
                "more": bool(cached.get("more")),
            }
    first_page = page(kind, server=server_id, after=None)
    entry = _record_summary_from_accounts_page(kind, server_id, first_page) or {}
    return {
        "id": server_id,
        "name": _TEXT(entry.get("name") or fallback_label or ""),
        "count": int(entry.get("count") or len(first_page.get("items") or []) or 0),
        "more": bool(entry.get("more")),
    }


def _expiry_label(value):
    if not isinstance(value, _TEXT) or not _DATE.match(value):
        return ""
    year, month, day = value.split("-")
    return day + "/" + month + "/" + year


def profile(kind, server, account, label, card=False):
    payload = _get(kind + "/servers/" + server + "/accounts/" + account, select=True)
    data = payload["connection"]
    expiry = _expiry_label(payload.get("expires_on"))
    url = data["url"]
    parsed = urlsplit(url)
    if parsed.scheme not in ("http", "https") or not parsed.hostname or parsed.username is not None:
        raise CatalogError("invalid")
    if kind == "portal":
        mac = data["mac"]
        if not re.match(r"\A(?:[0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}\Z", mac):
            raise CatalogError("invalid")
        if card:
            return (_("MAC %s") % mac,)
        return {"name": label, "portal": url, "mac": mac, "source_type": "stalker", "expiry": expiry}
    if parsed.path not in ("", "/") or parsed.query or parsed.fragment:
        raise CatalogError("invalid")
    username, password = data["username"], data["password"]
    if not username or not password:
        raise CatalogError("invalid")
    if card:
        return (_("User %s") % username, _("Pass %s") % password)
    query = urlencode({"username": username.encode("utf-8"), "password": password.encode("utf-8"),
                       "type": "m3u_plus", "output": "ts"})
    return {"name": label, "portal": url.rstrip("/") + "/get.php?" + query, "source_type": "m3u", "expiry": expiry}
