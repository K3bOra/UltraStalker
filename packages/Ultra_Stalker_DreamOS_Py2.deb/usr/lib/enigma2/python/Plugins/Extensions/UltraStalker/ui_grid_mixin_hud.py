# -*- coding: utf-8 -*-
"""Header, poster live HUD and chrome.

Methods moved verbatim out of ``PremiumGridBase`` (ui_grid_base.py); behaviour is unchanged.
This module is imported by ui_grid_base.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, max, min
from .ui_grid_base import (
    _,
    durable_view_path,
    os,
)


class GridHudMixin(object):
    """Header, poster live HUD and chrome."""

    def _update_header(self,item):
        raw=item.get("name") or item.get("title") or _("Result")
        title=(getattr(self,"_grid_display_titles",{}) or {}).get(self.index)
        if title is None:title=self._display_item_title(item,"Item")
        self["title"].setText(_clean_display_text(title,44))
        if self.media_type=="itv":
            cid=str(item.get("id") or item.get("ch_id") or "");epg=self._epg_cache.get(cid,{})
            now=epg.get("now") or item.get("epg_title") or item.get("now") or _("EPG information will appear here")
            nxt=epg.get("next") or ""
            self["rating"].setText(_("NOW  %s")%_clean_display_text(now,90))
            self["meta1"].setText((_("NEXT")+"  "+_clean_display_text(nxt,90)) if nxt else "")
            badges=[]
            if item.get("allow_archive") or item.get("tv_archive_duration") or item.get("archive"):badges.append(_("Catch-up"))
            state=self._grid_item_state.get(id(item),{})
            if state.get("favorite"):badges.append(_("Favorite"))
            self["meta2"].setText("  •  ".join(badges))
            self._schedule_epg(item)
        else:
            # Movies/Series top rating/meta widgets are intentionally hidden in
            # the current HUD. Do not scan quality/metadata or resize glass here.
            # A remote-control arrow must only change the visible title text.
            return

    def _fit_poster_live_hud(self):
        if getattr(self,"poster_hud_disabled",False):return
        if self.media_type not in ("vod","series"):return
        try:
            from .ui_icon_menu import _us_fit_png
            sx=float(getDesktop(0).size().width())/1920.0;sy=float(getDesktop(0).size().height())/1080.0
            chrome=getattr(self,"_poster_hud_last",None) or {}
            ck_map={"poster_folder_bg":"counter","poster_title_bg":"channel_top","poster_counter_bg":"counter"}
            fit_cache=getattr(self,"_poster_hud_fit_cache",None)
            if fit_cache is None:fit_cache=self._poster_hud_fit_cache={}
            def fit(bg,label,value,cx,minw,maxw,y,h,fs,pad,minfs):
                value=str(value or "")
                # Better Arabic/Latin width estimate than raw character count.
                units=max(1.0,sum(1.45 if ord(ch)>0x2ff else (0.58 if ch in " ilI1|.,:'" else 1.0) for ch in value))
                usable=max(1.0,float(maxw-24))
                fitted_fs=int(fs)
                expected=units*fitted_fs*0.57
                if expected>usable:
                    fitted_fs=max(int(minfs),min(int(fs),int(usable/(units*0.57))))
                w=max(minw,min(maxw,int(units*fitted_fs*0.57+pad)));x=int(cx-w/2)
                pw=max(1,int(w*sx));ph=max(1,int(h*sy))
                src_path=chrome.get(ck_map.get(bg,""))
                if src_path and os.path.isfile(src_path):
                    key=(src_path,pw,ph)
                    if fit_cache.get(bg)!=key:
                        fpath=_us_fit_png(src_path,pw,ph,True)
                        if fpath and os.path.isfile(fpath):
                            self[bg].instance.setPixmapFromFile(fpath)
                            fit_cache[bg]=key
                self[bg].instance.move(ePoint(int(x*sx),int(y*sy)));self[bg].instance.resize(eSize(pw,ph))
                self[label].instance.move(ePoint(int((x+12)*sx),int((y+6)*sy)));self[label].instance.resize(eSize(int((w-24)*sx),int((h-12)*sy)))
                try:self[label].instance.setFont(_ultra_rfont("Regular",fitted_fs))
                except Exception as exc:optional_failure("ui.poster_hud_font_fit",exc)
            fit("poster_folder_bg","section",self["section"].getText(),670,250,650,38,54,18,58,12)
            fit("poster_title_bg","title",self["title"].getText(),1215,250,590,38,54,22,64,13)
            fit("poster_counter_bg","page_label",self["page_label"].getText(),1650,260,430,936,46,18,52,12)
        except Exception as exc:optional_failure("ui.poster_hud_fit",exc)

    def _apply_poster_hud_chrome(self, source, chrome):
        if getattr(self,"poster_hud_disabled",False):return
        if self.media_type not in ("vod","series") or not isinstance(chrome,dict):return
        # Counter uses the exact same floating glass family as the top folder card.
        for ck,wk in (("counter","poster_folder_bg"),("channel_top","poster_title_bg"),("clock","poster_clock_bg"),("counter","poster_counter_bg")):
            path=chrome.get(ck)
            if path and os.path.isfile(path):
                try:self[wk].instance.setPixmapFromFile(path);self[wk].show()
                except Exception as exc:optional_failure("ui.poster_hud_apply",exc)
        self._poster_hud_last=dict(chrome);self._poster_hud_source=str(source or "")
        self._poster_hud_fit_cache={}
        self._fit_poster_live_hud()

    def _drain_poster_live_hud(self):
        if self.media_type not in ("vod","series"):return
        while True:
            try:source,chrome=self._poster_hud_jobs.get_nowait()
            except queue.Empty:break
            except Exception:break
            self._poster_hud_pending.discard(source)
            # Only repaint for the currently selected poster. Old jobs may finish
            # after rapid navigation and must never yank the HUD colour backwards.
            pos=max(0,min(int(self.index or 0),len(self.grid_items)-1)) if self.grid_items else 0
            current=str((getattr(self,"_grid_palette_sources",{}) or {}).get(pos) or "")
            if source==current:self._apply_poster_hud_chrome(source,chrome)

    def _apply_poster_live_hud(self, item=None):
        if self.media_type not in ("vod","series"):return
        try:
            pos=max(0,min(int(self.index or 0),len(self.grid_items)-1)) if self.grid_items else 0
            source=str((getattr(self,"_grid_palette_sources",{}) or {}).get(pos) or "")
            if not source or not os.path.isfile(source):
                return
            self._fit_poster_live_hud()
            if source==getattr(self,"_poster_hud_source","") and getattr(self,"_poster_hud_last",None):
                # Same-source is not proof that the native Pixmap is still painted.
                # OpenBH may retain our Python cache marker after a hide/show or
                # child-screen transition while the adaptive glass surface itself
                # is gone. Rebind the already-cached chrome instead of returning.
                self._apply_poster_hud_chrome(source,self._poster_hud_last)
                return
            # Durable HUD: include the poster revision so an in-place artwork
            # upgrade can never keep an old colour across restarts.
            try:
                _hud_st=os.stat(source)
                _hud_rev="%s|%s|%s"%(source,int(getattr(_hud_st,"st_mtime_ns",int(_hud_st.st_mtime*1e9))),int(_hud_st.st_size))
            except Exception:
                _hud_rev=source
            key="poster_hud_"+hashlib.sha1(_hud_rev.encode("utf-8","ignore")).hexdigest()[:16]
            expected={
                "counter":durable_view_path("posterhud_clean_cg1_%s_counter.png"%key,source=source),
                "channel_top":durable_view_path("posterhud_clean_cg1_%s_channel_top.png"%key,source=source),
                "clock":durable_view_path("posterhud_clean_cg1_%s_clock.png"%key,source=source),
            }
            if all(_valid_cache_file(p,ttl=0) for p in expected.values()):
                self._apply_poster_hud_chrome(source,expected)
                return

            # restore the adaptive folder/title/clock/counter HUD without
            # putting Pillow back on the navigation path.  This method is already
            # called only after the 300 ms stable-focus debounce; a single-worker
            # adaptive lane builds one missing HUD family in the background, while
            # rapid LEFT/RIGHT browsing remains cache-only.
            if source in getattr(self,"_poster_hud_pending",set()):
                return
            self._poster_hud_pending.add(source)
            def worker(src=source,hkey=key):
                try:
                    chrome=_build_poster_adaptive_chrome_clean(src,hkey) or {}
                    if chrome:self._poster_hud_jobs.put((src,chrome))
                    else:self._poster_hud_jobs.put((src,{}))
                except Exception as exc:
                    optional_failure("ui.poster_hud_background_build",exc)
                    try:self._poster_hud_jobs.put((src,{}))
                    except Exception as queue_exc:optional_failure("ui.poster_hud_background_queue",queue_exc)
            try:_ADAPTIVE_EXECUTOR.submit(worker)
            except Exception as exc:
                self._poster_hud_pending.discard(source)
                optional_failure("ui.poster_hud_background_submit",exc)
        except Exception as exc:optional_failure("ui.poster_live_hud_cache_only",exc)
from .wqhd_layout import responsive_font as _ultra_rfont, factors as _ultra_factors

def _ultra_osd_scale():
    return _ultra_factors()[1]
