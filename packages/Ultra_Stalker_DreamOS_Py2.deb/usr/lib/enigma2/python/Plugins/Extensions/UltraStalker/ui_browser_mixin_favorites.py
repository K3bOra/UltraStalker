# -*- coding: utf-8 -*-
"""Favourites root, tabs and folders.

Methods moved verbatim out of ``PortalBrowserScreen`` (ui_screens_browser.py); behaviour is unchanged.
This module is imported by ui_screens_browser.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, max, min, us_clear, us_text_callback, native_text
from .ui_screens_browser import (
    _,
    _ROOT_COUNTS_CACHE,
    _mem34,
    os,
    show_notice,
    time,
)


class BrowserFavoritesMixin(object):
    """Favourites root, tabs and folders."""

    def _stop_favorite_art_jobs(self):
        self._favorite_art_generation += 1
        self._favorite_meta_token = int(getattr(self,"_favorite_meta_token",0) or 0)+1
        for future in list(getattr(self,"_favorite_art_futures",set()) or set()):
            try:future.cancel()
            except Exception:pass
        try:us_clear(self._favorite_art_futures)
        except Exception:pass
        try:us_clear(self._favorite_art_pending)
        except Exception:pass
        try:
            while True:self._favorite_art_jobs.get_nowait()
        except Exception:pass

    def _favorite_entry_key(self, media_type, item):
        item=item if isinstance(item,dict) else {}
        raw="|".join((str(media_type or ""),str(item.get("id") or item.get("movie_id") or item.get("series_id") or item.get("stream_id") or ""),str(item.get("name") or item.get("title") or ""),str(_image_url(item) or "")))
        return hashlib.sha1(raw.encode("utf-8","ignore")).hexdigest()[:24]

    def _favorite_clean_title(self, media_type, item, max_chars=80):
        """Favorites always use the same cleaned catalogue names as normal browsing.

        Search intentionally keeps provider/raw names so source provenance stays visible;
        Favorites are a personal library, so technical/provider noise is not useful there.
        """
        item=item if isinstance(item,dict) else {}
        mt=str(media_type or "vod").lower()
        raw=item.get("name") or item.get("title") or item.get("id") or (_("Channel") if mt=="itv" else _("Result"))
        if mt=="itv":
            cleaned=_clean_live_channel_name(raw,True)
        else:
            cleaned=premium_title(raw,True)
        return _clean_display_text(cleaned or raw,max_chars)

    def _root_counts(self):
        """Favorites / continue-watching counts for the root descriptions.

        Each count used to cost ~1000 SQLite rows + JSON decodes on the GUI thread
        and ran 2-3 times per open.  The pair is now cached per portal and only
        recomputed after a favorite or history change (or after 60 s).
        """
        try:
            from .storage import history_revision
            from .repositories.content import favorites_revision
            key=(str(self.profile.get("portal") or "").rstrip("/").lower(),str(self.profile.get("mac") or "").upper(),history_revision(),favorites_revision())
        except Exception:
            key=None
        cache=_ROOT_COUNTS_CACHE
        now=time.monotonic()
        if key is not None and cache.get("key")==key and now-float(cache.get("t",0))<60.0:
            return cache["value"]
        value=(len(self._favorites_for_portal()),len(load_continue_watching()))
        if key is not None:
            cache["key"]=key;cache["t"]=now;cache["value"]=value
        return value

    def _favorites_for_portal(self, media_type=None):
        """Favorites are owned by the exact portal profile, not server URL alone.

        R5.199: grouped once per (profile, favorites revision) and then served
        from memory, so opening Favorites / moving tabs does no DB or JSON work.
        """
        portal=str(self.profile.get("portal") or "").rstrip("/").lower()
        mac=str(self.profile.get("mac") or "").upper()
        wanted=str(media_type or "").lower()
        try:
            from .repositories.content import favorites_revision
            key=(portal,mac,favorites_revision())
        except Exception:key=None
        cache=getattr(self,"_fav_group_cache",None)
        if key is None or not cache or cache[0]!=key:
            groups={"":[]}
            for entry in (load_favorites() or []):
                if not isinstance(entry,dict) or not isinstance(entry.get("item"),dict):continue
                if str(entry.get("portal") or "").rstrip("/").lower()!=portal:continue
                # R135 safety: same endpoint with another MAC/M3U synthetic identity
                # is a different portal profile. Never expose or play its saved IDs.
                if str(entry.get("mac") or "").upper()!=mac:continue
                mt=str(entry.get("media_type") or "vod").lower()
                groups[""].append(entry);groups.setdefault(mt,[]).append(entry)
            cache=(key,groups)
            if key is not None:self._fav_group_cache=cache
        return list(cache[1].get(wanted,[]))

    def _apply_favorites_static_mode(self, show_list=False):
        """Favorites is fully static visually; only content artwork may load."""
        try:
            bg=asset("ultra_bg_clean_1920x1080.png")
            self._browser_geom("page_adaptive_bg",0,0,1920,1080)
            if self["page_adaptive_bg"].instance is not None and os.path.isfile(bg):
                if str(getattr(self,"_favorites_static_bg_loaded","") or "") != bg:
                    self["page_adaptive_bg"].instance.setPixmapFromFile(bg)
                    self._favorites_static_bg_loaded=bg
                self["page_adaptive_bg"].show()
        except Exception as exc:optional_failure("ui.favorites_static_bg",exc)
        for name in ("brand_header","title","counter","section","top_divider","preview","accent_frame","info_card1","info_card2","info_card3","info_icon1","info_icon2","info_icon3","info_title","info","status","red_bg","green_bg","yellow_bg","blue_bg","red","green","yellow","blue"):
            try:self[name].hide()
            except Exception:pass
        try:
            if show_list:self["list"].show()
            else:self["list"].hide()
        except Exception:pass

    @staticmethod
    def _favorite_is_folder_entry(entry):
        return bool(isinstance(entry,dict) and entry.get("_favorite_folder"))

    def _favorite_selected_entry(self):
        entries=list(getattr(self,"_favorite_card_entries",[]) or [])
        if not entries:return None
        idx=max(0,min(int(getattr(self,"_favorite_card_index",0) or 0),len(entries)-1))
        return entries[idx]

    def _hide_favorite_action_buttons(self):
        for name in ("fav_red_bg","fav_green_bg","fav_yellow_bg","fav_blue_bg","fav_red","fav_green","fav_yellow","fav_blue"):
            try:self[name].hide()
            except Exception:pass

    def _hide_favorite_ui(self):
        """Hide every Favorites widget (used at start-up and when leaving the page)."""
        names=["fv_title","fv_sub","fv_underline","fv_empty","fv_d_title","fv_pos","fv_d_meta","fv_d_desc"]
        for i in range(3):
            names+=["fv_tab_bg%d"%i,"fv_tab_icon%d"%i,"fv_tab_text%d"%i,"fv_tab_badge%d"%i,"fv_tab_cnt%d"%i]
        for n in names:
            try:self[n].hide()
            except Exception:pass
        try:self._hide_favorite_cards()
        except Exception:pass
        self._hide_favorite_action_buttons()
        self._favorite_tab_state={};self._favorite_slot_state={}

    def _favorite_set_color(self, name, color):
        """Change a Label colour on the receiver (needs a text refresh to repaint)."""
        try:
            lbl=self[name];inst=lbl.instance
            if inst is not None:
                inst.setForegroundColor(parseColor(color))
                lbl.setText(lbl.getText())
        except Exception:pass

    def _favorite_show_buttons(self,buttons):
        """Colour-key hints, right aligned bottom row (same dashes as Local)."""
        self._hide_favorite_action_buttons()
        buttons=list(buttons or [])[:4]
        if not buttons:return
        slot=204;right=1880
        x0=right-slot*len(buttons)
        for idx,(color,label) in enumerate(buttons):
            try:
                color=str(color);bg="fav_%s_bg"%color;text_name="fav_%s"%color
                x=x0+idx*slot;y=1033
                self._browser_geom(bg,x,y,56,42)
                if self[bg].instance is not None:self[bg].instance.setPixmapFromFile(asset("player_keyline_%s_dash_56x42.png"%color))
                self[bg].show()
                self._browser_geom(text_name,x+58,y,140,42)
                self[text_name].setText(str(label or ""));self[text_name].show()
            except Exception:pass

    def _render_favorite_action_buttons(self):
        if self.level=="favorites_root":
            self._favorite_show_buttons([("red",_("Back"))]);return
        if self.level!="favorites_cards":
            self._hide_favorite_action_buttons();return
        entries=list(getattr(self,"_favorite_card_entries",[]) or [])
        mt=str(getattr(self,"_favorites_bucket_type",None) or "vod").lower()
        in_folder=bool(getattr(self,"_favorite_folder_id",None))
        selected=self._favorite_selected_entry()
        is_folder=self._favorite_is_folder_entry(selected)
        if getattr(self,"_favorite_reorder_active",False):
            buttons=[("red",_("Cancel")),("yellow",_("Move"))]
        elif mt=="itv" and not in_folder and is_folder:
            buttons=[("red",_("Delete")),("blue",_("Edit"))]
        else:
            buttons=[("red",_("Back"))]
            if selected is not None and not is_folder:
                buttons.extend([("green",_("Unfavorite")),("yellow",_("Move"))])
            if mt=="itv" and not in_folder and not is_folder:
                buttons.append(("blue",_("Create Folder")))
            elif mt=="itv" and not in_folder and not entries:
                buttons.append(("blue",_("Create Folder")))
        self._favorite_show_buttons(buttons)

    def _favorite_tab_types(self):
        return ("itv","vod","series")

    def _favorite_active_mt(self):
        """Category whose rail is on screen: the open bucket, else the focused tab."""
        if getattr(self,"level","")=="favorites_cards" and getattr(self,"_favorites_bucket_type",None):
            return str(self._favorites_bucket_type).lower()
        return self._favorite_tab_types()[max(0,min(2,int(getattr(self,"_favorite_root_index",0) or 0)))]

    def _favorite_load_preview(self):
        """Tab focus keeps the focused category's rail on screen (no item focus)."""
        mt=self._favorite_tab_types()[max(0,min(2,int(getattr(self,"_favorite_root_index",0) or 0)))]
        try:self._favorite_card_entries=list(self._favorite_folder_entries(mt,None))
        except Exception as exc:
            optional_failure("ui.favorite_preview",exc);self._favorite_card_entries=[]
        self._favorite_card_index=0

    def _render_favorites_root(self):
        """Header + the three category tabs with their count badges."""
        entries=(
            ("itv",_("Live TV"),"home_live_line.png"),
            ("vod",_("Movies"),"home_movies_line.png"),
            ("series",_("Series"),"home_series_line.png"),
        )
        try:
            self["fv_title"].setText(_("FAVORITES"));self["fv_title"].show()
            self["fv_sub"].setText(_("Your saved channels, movies and series"));self["fv_sub"].show()
            if self["fv_underline"].instance is not None:
                if not getattr(self,"_favorite_underline_set",False):
                    self["fv_underline"].instance.setPixmapFromFile(asset("page_underline_120x4.png"));self._favorite_underline_set=True
            self["fv_underline"].show()
        except Exception:pass
        active=max(0,min(2,int(getattr(self,"_favorite_root_index",0) or 0)))
        tabs_focused=(self.level=="favorites_root")
        try:counts=tuple(len(self._favorites_for_portal(mt)) for mt,_l,_i in entries)
        except Exception:counts=tuple(getattr(self,"_favorite_counts",(0,0,0)))
        self._favorite_counts=counts
        for slot,(mt,label,icon_name) in enumerate(entries):
            selected=(slot==active)
            state=(selected,tabs_focused if selected else False,counts[slot])
            try:
                if self._favorite_tab_state.get(slot)!=state:
                    bgfile="fixed_master_r63/home_menu_focus.png" if selected else "fixed_master_r63/home_menu_%d.png"%max(0,min(2,slot))
                    if self["fv_tab_bg%d"%slot].instance is not None:self["fv_tab_bg%d"%slot].instance.setPixmapFromFile(asset(bgfile))
                    # R5.198: Local-style tile: the big neon icon sits centred in the card, the
                    # title under it and the count INSIDE the card (nothing touches the edges).
                    _big=icon_name.replace("_line.png","_line_big.png")
                    if self["fv_tab_icon%d"%slot].instance is not None:self["fv_tab_icon%d"%slot].instance.setPixmapFromFile(asset(_big))
                    self["fv_tab_text%d"%slot].setText(label)
                    self._favorite_set_color("fv_tab_text%d"%slot,"#00e676" if (selected and not tabs_focused) else "#ffffff")
                    self["fv_tab_cnt%d"%slot].setText(_("Items: %d")%counts[slot])
                    self._favorite_set_color("fv_tab_cnt%d"%slot,"#afc0cf")
                    self._favorite_tab_state[slot]=state
                _bx=360+360*slot
                self._browser_geom("fv_tab_icon%d"%slot,_bx+51,168,136,102)
                self._browser_geom("fv_tab_text%d"%slot,_bx+13,274,212,32)
                self._browser_geom("fv_tab_cnt%d"%slot,_bx+13,308,212,30)
                for n in ("fv_tab_bg%d","fv_tab_icon%d","fv_tab_text%d","fv_tab_cnt%d"):self[n%slot].show()
            except Exception:pass
        self._render_favorite_action_buttons()
        _mem34("favorites_root_rendered", rows=3)

    def _show_favorites_root(self):
        self._favorite_reorder_active=False;self._favorite_reorder_original=[];self._favorite_move_source_index=-1;self._hide_favorite_action_buttons()
        self._favorite_art_generation+=1;self._favorites_bucket_type=None;self._favorite_folder_id=None;self._favorite_folder_name="";self._favorite_card_entries=[];self._favorite_card_index=0
        self._favorite_root_index=max(0,min(2,int(getattr(self,"_favorite_root_index",0) or 0)))
        self.level="favorites_root";self.media_type=None;self.content_items=[];self.all_content_items=[]
        self._apply_favorites_static_mode(show_list=False);self._hide_favorite_cards();self._favorite_load_preview();self._render_favorites_root();self._render_favorite_cards()

    def _favorite_focus_tabs(self):
        """UP from the rail: focus the tab row (not while moving or inside a Live folder)."""
        if getattr(self,"_favorite_reorder_active",False) or getattr(self,"_favorite_folder_id",None):return
        self._favorite_root_index=self._favorite_tab_types().index(self._favorite_active_mt()) if self._favorite_active_mt() in self._favorite_tab_types() else 0
        self._show_favorites_root()

    def _favorite_enter_tab(self):
        """DOWN / OK on a tab: focus its content."""
        self._show_favorites_bucket(self._favorite_tab_types()[max(0,min(2,int(getattr(self,"_favorite_root_index",0) or 0)))])

    def _favorite_root_move(self, delta):
        self._favorite_root_index=(int(getattr(self,"_favorite_root_index",0) or 0)+int(delta))%3
        self._favorite_load_preview();self._render_favorites_root();self._render_favorite_cards()

    def _favorite_content_key(self, media_type, item):
        try:
            from .repositories.content import content_key
            return content_key(self.profile,str(media_type or "").lower(),item if isinstance(item,dict) else {})
        except Exception:
            return self._favorite_entry_key(media_type,item)

    def _favorite_folder_entries(self, media_type, active_folder_id=None):
        """Return virtual folder rows plus visible favorite rows for this bucket.

        Only Live favorites expose folders. A favorite belongs to at most one
        folder; deleting a folder only removes the assignment, never the favorite.
        """
        mt=str(media_type or "vod").lower();saved=list(self._favorites_for_portal(mt))
        if mt!="itv":return saved
        try:
            from .repositories.content import FAVORITE_FOLDERS
            membership=FAVORITE_FOLDERS.membership(self.profile,mt) or {}
            folders=FAVORITE_FOLDERS.list(self.profile,mt) or []
        except Exception as exc:
            optional_failure("ui.favorite_folder_load",exc);membership={};folders=[]
        keyed={}
        for entry in saved:
            item=(entry or {}).get("item") or {}
            if isinstance(item,dict):keyed[self._favorite_content_key(mt,item)]=entry
        if active_folder_id:
            try:
                from .repositories.content import FAVORITE_FOLDERS
                ordered_keys=FAVORITE_FOLDERS.keys(active_folder_id) or []
            except Exception:ordered_keys=[]
            rows=[keyed[k] for k in ordered_keys if k in keyed]
            return rows
        counts={str(f.get("folder_id") or ""):0 for f in folders}
        assigned=set()
        for key,meta in membership.items():
            folder_id=str((meta or {}).get("folder_id") or "")
            if key in keyed and folder_id in counts:
                counts[folder_id]+=1;assigned.add(key)
        virtual=[]
        for folder in folders:
            folder_id=str(folder.get("folder_id") or "")
            if not folder_id:continue
            virtual.append({
                "_favorite_folder":True,
                "folder_id":folder_id,
                "name":str(folder.get("name") or _("Folder")),
                "count":int(counts.get(folder_id,0)),
                "media_type":"itv",
            })
        unfiled=[]
        for entry in saved:
            item=(entry or {}).get("item") or {}
            key=self._favorite_content_key(mt,item) if isinstance(item,dict) else ""
            if key not in assigned:unfiled.append(entry)
        return virtual+unfiled

    def _favorite_refresh_bucket_entries(self, keep_index=None):
        mt=str(getattr(self,"_favorites_bucket_type",None) or "vod").lower()
        folder_id=getattr(self,"_favorite_folder_id",None) if mt=="itv" else None
        self._favorite_card_entries=list(self._favorite_folder_entries(mt,folder_id))
        if keep_index is None:keep_index=int(getattr(self,"_favorite_card_index",0) or 0)
        self._favorite_card_index=max(0,min(int(keep_index),max(0,len(self._favorite_card_entries)-1)))

    def _favorite_open_folder(self, entry):
        if not self._favorite_is_folder_entry(entry):return
        self._favorite_folder_id=str(entry.get("folder_id") or "")
        self._favorite_folder_name=str(entry.get("name") or _("Folder"))
        self._favorite_reorder_active=False;self._favorite_reorder_original=[];self._favorite_move_source_index=-1
        self._favorite_card_index=0;self._favorite_refresh_bucket_entries(0);self._render_favorites_root();self._render_favorite_cards()

    def _favorite_leave_folder(self):
        if not getattr(self,"_favorite_folder_id",None):return False
        self._favorite_folder_id=None;self._favorite_folder_name="";self._favorite_card_index=0
        self._favorite_refresh_bucket_entries(0);self._render_favorites_root();self._render_favorite_cards();return True

    def _favorite_create_folder(self):
        if str(getattr(self,"_favorites_bucket_type",None) or "").lower()!="itv" or getattr(self,"_favorite_folder_id",None):return
        try:
            from Screens.VirtualKeyBoard import VirtualKeyBoard as E2VirtualKeyBoard
        except Exception:
            E2VirtualKeyBoard=None
        if E2VirtualKeyBoard is not None:
            self.session.openWithCallback(us_text_callback(self._favorite_folder_created),E2VirtualKeyBoard,title=native_text(_("Folder name")),text=native_text(""))
        else:
            self.session.openWithCallback(us_text_callback(self._favorite_folder_created),InputBox,title=native_text(_("Folder name")),text=native_text(""),maxSize=50)

    def _favorite_folder_created(self, value):
        name=str(value or "").strip()
        if not name:return
        try:
            from .repositories.content import FAVORITE_FOLDERS
            folder_id=FAVORITE_FOLDERS.create(self.profile,"itv",name)
            if not folder_id:
                show_notice(self.session, _("A folder with this name already exists."), timeout=5, owner=self);return
        except Exception as exc:
            optional_failure("ui.favorite_folder_create",exc);return
        self._favorite_refresh_bucket_entries(0)
        for _idx,_entry in enumerate(list(getattr(self,"_favorite_card_entries",[]) or [])):
            if self._favorite_is_folder_entry(_entry) and str(_entry.get("folder_id") or "")==str(folder_id):
                self._favorite_card_index=_idx;break
        self._render_favorite_cards()

    def _favorite_edit_folder(self):
        entry=self._favorite_selected_entry()
        if not self._favorite_is_folder_entry(entry):return
        self._favorite_editing_folder_id=str(entry.get("folder_id") or "")
        current_name=str(entry.get("name") or "")
        try:
            from Screens.VirtualKeyBoard import VirtualKeyBoard as E2VirtualKeyBoard
        except Exception:
            E2VirtualKeyBoard=None
        if E2VirtualKeyBoard is not None:
            self.session.openWithCallback(us_text_callback(self._favorite_folder_renamed),E2VirtualKeyBoard,title=native_text(_("Folder name")),text=native_text(current_name))
        else:
            self.session.openWithCallback(us_text_callback(self._favorite_folder_renamed),InputBox,title=native_text(_("Folder name")),text=native_text(current_name),maxSize=50)

    def _favorite_folder_renamed(self, value):
        name=str(value or "").strip();folder_id=str(getattr(self,"_favorite_editing_folder_id","") or "")
        self._favorite_editing_folder_id=""
        if not name or not folder_id:return
        try:
            from .repositories.content import FAVORITE_FOLDERS
            ok=FAVORITE_FOLDERS.rename(self.profile,"itv",folder_id,name)
            if not ok:
                show_notice(self.session, _("A folder with this name already exists."), timeout=5, owner=self);return
        except Exception as exc:
            optional_failure("ui.favorite_folder_rename",exc);return
        self._favorite_refresh_bucket_entries();self._render_favorite_cards()

    def _favorite_delete_folder(self):
        entry=self._favorite_selected_entry()
        if not self._favorite_is_folder_entry(entry):return False
        folder_id=str(entry.get("folder_id") or "")
        if not folder_id:return False
        try:
            from .repositories.content import FAVORITE_FOLDERS
            FAVORITE_FOLDERS.delete(self.profile,"itv",folder_id)
        except Exception as exc:
            optional_failure("ui.favorite_folder_delete",exc);return False
        # Membership is deleted by SQLite cascade. Favorites themselves are untouched,
        # so every channel from the deleted folder immediately returns to the root.
        keep=max(0,int(getattr(self,"_favorite_card_index",0) or 0)-1)
        self._favorite_refresh_bucket_entries(keep);self._render_favorites_root();self._render_favorite_cards();return True

    def _favorite_live_icon(self,item):
        key=self._favorite_entry_key("itv",item)
        path=str((getattr(self,"_favorite_art_local",{}) or {}).get(key) or "")
        if not (path and os.path.isfile(path)):
            try:
                cached=_cached_live_picon_path(_image_url(item),self.profile,item) or ""
                if cached and os.path.isfile(cached):
                    from .ui_artwork_helpers import _live_row_fit_cached
                    path=_live_row_fit_cached(cached,PERSISTENT_GENERATED_DIR,(184,110)) or ""
                    # R5.205: the exact 184x110 derivative is built off the GUI thread by the
                    # artwork scheduler. Until it exists show the small bundled Live icon:
                    # the raw picon is not scaled by the widget, so it used to flash at its
                    # full size and then jump to the right size.
            except Exception:path=""
        return path if path and os.path.isfile(path) else asset("home_live_line.png")

    def _show_favorites_bucket(self, media_type):
        """Open a favorites bucket inline, without leaving the Favorites page."""
        mt=str(media_type or "vod").lower();self._favorites_bucket_type=mt;self.media_type=mt
        self._favorite_reorder_active=False;self._favorite_reorder_original=[];self._favorite_move_source_index=-1
        self._favorite_folder_id=None;self._favorite_folder_name=""
        self._favorite_art_generation+=1;us_clear(self._favorite_art_pending);self._favorite_card_index=0
        self._favorite_card_entries=list(self._favorite_folder_entries(mt,None))
        self.level="favorites_cards";self._apply_favorites_static_mode(show_list=False);self._render_favorites_root();self._render_favorite_cards()
