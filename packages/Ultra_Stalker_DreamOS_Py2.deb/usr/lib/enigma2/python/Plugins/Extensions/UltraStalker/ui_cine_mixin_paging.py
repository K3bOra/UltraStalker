# -*- coding: utf-8 -*-
"""Virtual page navigation and catalogue prefetch.

Methods moved verbatim out of ``PremiumGlobalCinematicScreen`` (ui_cinematic_global.py); behaviour is unchanged.
This module is imported by ui_cinematic_global.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import int, max, min, us_func
from .ui_cinematic_global import (
    PremiumGridBase,
    _CIN_PAGE_EXECUTOR,
    optional_failure,
    time,
)


class CinePagingMixin(object):
    """Virtual page navigation and catalogue prefetch."""

    def _cin_nav_total_pages(self):
        total=int(self._active_total() or 0)
        return max(1,(total+self.page_size-1)//self.page_size) if total else max(1,int(self.page or 1))

    def _cin_prefetch_catalogue_pages(self):
        """R112: warm only neighbouring catalogue pages off the GUI thread.

        This is catalogue/RAM preparation only. It exists so crossing the end of
        the 12-row rail does not leave the highlight waiting on provider I/O and
        then replay a burst of remote presses afterwards.
        """
        if getattr(self,"_cin_page_warm_running",False):return
        total=int(self._active_total() or 0)
        if total<=self.page_size:return
        total_pages=max(1,(total+self.page_size-1)//self.page_size)
        current=max(1,min(int(self.page or 1),total_pages))
        targets=[]
        for p in (current+1,current-1):
            if 1<=p<=total_pages and p!=current and p not in targets:
                targets.append(p)
        if not targets:return
        self._cin_page_warm_running=True
        def worker():
            try:
                for target in targets:
                    if getattr(self,"_screen_closed",False):break
                    with self._prepared_page_lock:
                        if target in self._prepared_page_cache:continue
                    try:
                        payload=self._finish_prepared_page(self._prepare_grid_page(target,None))
                        if payload:self._cache_prepared_page(target,payload)
                    except Exception as exc:optional_failure("cinematic.catalogue_page_warm",exc)
            finally:self._cin_page_warm_running=False
        try:getattr(self,"_cin_page_executor",_CIN_PAGE_EXECUTOR).submit(worker)
        except Exception as exc:self._cin_page_warm_running=False;optional_failure("cinematic.catalogue_page_warm_submit",exc)

    def _apply_prepared_page(self,target,payload,restore_index=None):
        pending=int(getattr(self,"_cin_page_nav_target",0) or 0)
        # Key-repeat may keep moving inside the ONE pending page while provider
        # I/O is in flight.  Apply the newest pending row, never the stale row
        # captured when load_page() first started.
        if pending and int(target or 0)==pending:
            restore_index=max(0,int(getattr(self,"_cin_page_nav_row",0) or 0))
        if pending>0 and int(target or 0)!=pending:
            # A newer key burst already chose another destination. Preserve this
            # completed catalogue payload in RAM, but never flash it on screen.
            try:self._cache_prepared_page(int(target),payload)
            except Exception as exc:optional_failure("cinematic.stale_page_cache",exc)
            return False
        ok=us_func(PremiumGridBase._apply_prepared_page)(self,target,payload,restore_index)
        if not ok and pending and int(target or 0)==pending and int(getattr(self,"_cin_page_nav_target",0) or 0)==pending:
            # The destination could not be painted (empty page / shrunk catalogue).
            # Release the arrow lock, otherwise every later key is ignored.
            self._cin_page_nav_target=0;self._cin_page_nav_row=0
        if ok:
            if int(getattr(self,"_cin_page_nav_target",0) or 0)==int(target or 0):
                self._cin_page_nav_target=0;self._cin_page_nav_row=0
            try:self._cin_prefetch_catalogue_pages()
            except Exception as exc:optional_failure("cinematic.catalogue_page_warm_start",exc)
        return ok

    def _cin_virtual_page(self):
        target=int(getattr(self,"_cin_page_nav_target",0) or 0)
        return target if target>0 else max(1,int(self.page or 1))

    def _cin_schedule_page_target(self,target,row,delay_ms=110):
        """Queue one virtual page destination without disturbing last-good visuals.

        The painted page remains authoritative until the final catalogue payload is
        ready. Every key press updates the virtual destination; one short one-shot
        timer collapses provider work, not key events.
        """
        last=self._cin_nav_total_pages()
        target=max(1,min(int(last),int(target or 1)))
        if target==int(self.page or 1) and self.grid_items and not int(getattr(self,"_cin_page_nav_target",0) or 0):
            # R5.173: the whole folder fits on the painted page (e.g. 5 titles):
            # DOWN on the last item / UP on the first wraps inside the page instead
            # of scheduling a reload of the page we are already on (which did nothing).
            self.index=max(0,min(int(row or 0),len(self.grid_items)-1))
            self._update_selection()
            return
        self._cin_page_nav_target=target
        self._cin_page_nav_row=max(0,int(row or 0))
        self._cin_page_nav_generation=int(getattr(self,"_cin_page_nav_generation",0) or 0)+1
        try:
            self._cin_page_nav_timer.stop();self._cin_page_nav_timer.start(max(1,int(delay_ms)),True)
        except Exception:
            self._cin_commit_page_nav()

    def _cin_queue_page_delta(self,delta,row,wrap=False,delay_ms=110):
        if not self.grid_items:return
        last=self._cin_nav_total_pages();base=self._cin_virtual_page();step=int(delta or 0)
        target=base+step
        if wrap:
            if target<1:target=last
            elif target>last:target=1
        else:
            target=max(1,min(last,target))
        if target==base:
            # Preserve the legacy edge grammar when there is nowhere to page.
            if not int(getattr(self,"_cin_page_nav_target",0) or 0):
                if step<0:self.index=0;self._update_selection()
                elif step>0:self.index=max(0,len(self.grid_items)-1);self._update_selection()
            return
        self._cin_schedule_page_target(target,row,delay_ms)

    def _cin_commit_page_nav(self):
        target=int(getattr(self,"_cin_page_nav_target",0) or 0)
        if target<=0:return
        row=max(0,int(getattr(self,"_cin_page_nav_row",0) or 0))
        if target==int(self.page or 1):
            self._cin_page_nav_target=0;self._cin_page_nav_row=0
            return
        # load_page already generation-guards/cancels older provider reads. Keep
        # our virtual target alive until _apply_prepared_page confirms that this
        # exact destination actually painted.
        self.load_page(target,row)
        # Search pages paint immediately from RAM. A normal catalogue page stays
        # pending until _apply_prepared_page confirms it. If the destination is
        # already on screen, the arrow lock must be released or every later key
        # is ignored and the only way out is leaving Search.
        if int(getattr(self,"page",0) or 0)==int(target):
            self._cin_page_nav_target=0;self._cin_page_nav_row=0
        # A fully painted previous Cinematic page is a valid hold surface. Page I/O
        # is background work and must not replace it with a six-second Loading text.
        try:
            if getattr(self,"grid_items",None):self["status"].setText("")
        except Exception:pass

    def _cin_mark_navigation_activity(self):
        """R112: make an arrow press an immediate GUI-priority event.

        No metadata/artwork result may be delivered while the remote is moving.
        The settled-title timers are re-armed by _update_selection() once the
        visible focus actually changes.
        """
        self._cin_last_nav_at=time.monotonic()
        try:self._cin_poll.stop();self._cin_poll_interval=0
        except Exception:pass
        for _timer_name in ("_cin_fast_info_timer","_cin_nav_backdrop_timer","_cin_nav_adaptive_timer","_grid_focus_timer"):
            try:getattr(self,_timer_name).stop()
            except Exception:pass

    def _cin_wrap_up(self):
        # Continuous item navigation crosses one page boundary at a time, but
        # the whole current folder is circular: global item #1 UP -> final item.
        if not self.grid_items:return
        self._cin_mark_navigation_activity()
        if int(getattr(self,"_cin_page_nav_target",0) or 0):
            # R112: never bank/replay row presses while a page payload is still
            # arriving. A warm neighbour normally paints immediately; on a cold
            # portal we hold the edge row rather than teleport after queued keys.
            return
        total=max(0,int(self._active_total() or 0))
        page_size=max(1,int(self.page_size or 1))
        current_global=(max(1,int(self.page or 1))-1)*page_size+max(0,int(self.index or 0))
        if total>0 and current_global<=0:
            last_page=max(1,(total+page_size-1)//page_size)
            last_row=max(0,(total-1)%page_size)
            self._cin_schedule_page_target(last_page,last_row,1)
            return
        if self.index>0:
            self.index-=1;self._update_selection();return
        self._cin_queue_page_delta(-1,page_size-1,wrap=True,delay_ms=1)

    def _cin_wrap_down(self):
        # Same one-page-at-a-time law in the opposite direction.  At the actual
        # final folder item, DOWN wraps straight to global item #1.
        if not self.grid_items:return
        self._cin_mark_navigation_activity()
        if int(getattr(self,"_cin_page_nav_target",0) or 0):
            # R112: do not accumulate latent DOWN presses behind provider I/O.
            return
        total=max(0,int(self._active_total() or 0))
        page_size=max(1,int(self.page_size or 1))
        current_global=(max(1,int(self.page or 1))-1)*page_size+max(0,int(self.index or 0))
        if total>0 and current_global>=total-1:
            self._cin_schedule_page_target(1,0,1)
            return
        if self.index<len(self.grid_items)-1:
            self.index+=1;self._update_selection();return
        self._cin_queue_page_delta(1,0,wrap=True,delay_ms=1)

    def _cin_page_left(self):
        # LEFT/RIGHT are explicit page keys. R112 accepts one page transition at
        # a time; remote repeats are never stored for later replay.
        if not self.grid_items:return
        self._cin_mark_navigation_activity()
        if int(getattr(self,"_cin_page_nav_target",0) or 0):return
        self._cin_queue_page_delta(-1,max(0,int(self.index or 0)),wrap=False,delay_ms=1)

    def _cin_page_right(self):
        if not self.grid_items:return
        self._cin_mark_navigation_activity()
        if int(getattr(self,"_cin_page_nav_target",0) or 0):return
        self._cin_queue_page_delta(1,max(0,int(self.index or 0)),wrap=False,delay_ms=1)
