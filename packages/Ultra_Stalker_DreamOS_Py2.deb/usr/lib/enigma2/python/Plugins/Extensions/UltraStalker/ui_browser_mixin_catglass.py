# -*- coding: utf-8 -*-
"""Category glass layout, previews, mood/chrome sources and backdrops.

Methods moved verbatim out of ``PortalBrowserScreen`` (ui_screens_browser.py); behaviour is unchanged.
This module is imported by ui_screens_browser.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str, int, open, round, max, min, us_clear, us_casefold
from .ui_screens_browser import (
    _,
    _CAT_GLASS_KEYS,
    _CAT_GLASS_WIDGETS,
    os,
    time,
    weakref,
)


_CAT_FOOTER_PARTS=("cat_footer","cat_footer_fade_left","cat_footer_middle","cat_footer_fade_right","cat_footer_right")

class BrowserCategoryGlassMixin(object):
    """Category glass layout, previews, mood/chrome sources and backdrops."""

    def _category_title_ctx(self, cfg):
        """Per-settings-object derived data (sets, casefolded keywords, signature).

        Rebuilt only when a different ``cfg`` object is passed, so a render pass
        over hundreds of rows builds it once.
        """
        ctx = getattr(self, "_cat_title_ctx", None)
        if ctx is not None and ctx[0] is cfg:
            return ctx
        media = self.media_type
        pins = cfg.get("pinned_categories", {}).get(media, [])
        prot = cfg.get("protected_categories", {}).get(media, [])
        words = tuple(us_casefold(str(w)) for w in (cfg.get("adult_keywords", []) or []))
        locked = bool(cfg.get("parental_lock")) and cfg.get("parental_mode", "pin") == "pin"
        pinned = set(pins)
        protected = set(prot)
        sig = (media, tuple(sorted(str(x) for x in pinned)), tuple(sorted(str(x) for x in protected)), words, locked)
        ctx = (cfg, sig, pinned, protected, words, locked)
        self._cat_title_ctx = ctx
        return ctx

    def _category_display_title(self, entry, cfg=None):
        cfg = cfg or load_settings()
        e = entry if isinstance(entry, dict) else {}
        gid = str(e.get("id") or e.get("genre_id") or e.get("name") or e.get("title") or "")
        raw = e.get("title") or e.get("name") or e.get("category_name") or e.get("genre_name") or e.get("id") or _("Categories")
        _cfg, sig, pinned, protected, words, locked = self._category_title_ctx(cfg)
        sens_src = str(e.get("name") or e.get("title") or "")
        try:
            key = (sig, gid, raw if isinstance(raw, (str, int, float)) else str(raw), sens_src)
            cache = getattr(self, "_cat_title_cache", None)
            if cache is None:
                cache = self._cat_title_cache = {}
            hit = cache.get(key)
            if hit is not None:
                return hit
        except Exception:
            key = None
            cache = None
        title = _clean_display_text(raw, 100) or _("Categories")
        if gid in pinned:
            title = "\u2605  " + title
        low = us_casefold(sens_src)
        sensitive = gid in protected or any(w in low for w in words)
        if locked and sensitive:
            title = "[PIN]  " + title
        # Selection state is rendered in a dedicated right-side check column.
        # Never mix the check mark into provider/category text; this keeps Arabic
        # and Latin category names visually consistent and unambiguous.
        if cache is not None and key is not None:
            if len(cache) > 4000:
                us_clear(cache)
            cache[key] = title
        return title

    def _category_measure_width(self, text, font_size):
        try:
            fn = globals().get("_settings_text_width_px")
            if fn is not None:
                return max(1, int(fn(str(text or ""), int(font_size))))
        except Exception as exc:
            optional_failure("ui.category_text_measure", exc)
        return max(1, int(len(str(text or "")) * max(1, int(font_size)) * 0.58))

    def _prepare_category_global_geometry(self, entries, cfg=None):
        """Choose one stable row width for the entire category list.

        The width is based on the longest decorated title across every category,
        not just the 14 currently visible rows.  All pages therefore keep the
        exact same rail geometry while UP/DOWN paging.

        For Movies Categories we must guarantee that *both* states remain fully
        readable: the compact white title when the row is not selected, and the
        larger green title when the row is selected.  Pick one global width and
        one font pair that keep the longest title visible in both states.
        """
        cfg = cfg or load_settings()
        titles = [self._category_display_title(e, cfg) for e in (entries or [])]
        if not titles:
            titles = ["Category"]
        # Native text measurement is comparatively expensive on Enigma2.  Rank
        # cheaply in Python first, then probe only the titles most likely to be
        # widest.  This keeps portals with hundreds of categories from measuring
        # every label at every candidate font size.
        def _rough_width(value):
            total=0.0
            for ch in str(value or ""):
                code=ord(ch)
                if 0x0600<=code<=0x06ff:total+=1.35
                elif ch.isupper():total+=1.18
                elif ch.isdigit():total+=1.00
                elif ch.isspace():total+=0.55
                else:total+=1.0
            return total
        if len(titles)>48:
            titles=sorted(titles,key=_rough_width,reverse=True)[:48]
        media = str(getattr(self, "media_type", "") or "").lower()
        is_movies = media in ("itv", "vod", "series")
        max_width = 1320 if is_movies else 860
        if is_movies:
            # (normal_font_index, normal_px, selected_font_index, selected_px)
            # Keep Movies Categories calmer and denser: slightly smaller white
            # titles, and a selected green title that is emphasized without
            # ballooning into the line below.
            font_steps = (
                (0, 22, 11, 26),
                (3, 20, 11, 26),
                (4, 18, 3, 20),
                (5, 16, 4, 18),
                (6, 14, 5, 16),
            )
        else:
            font_steps = (
                (0, 22, 0, 22),
                (3, 19, 3, 19),
                (4, 17, 4, 17),
            )
        chosen_font, chosen_sel_font, chosen_width = (0 if is_movies else 0), (11 if is_movies else 0), 426
        for font_index, font_size, selected_font_index, selected_font_size in font_steps:
            longest_normal = max(list(self._category_measure_width(t, font_size) for t in titles) or [260])
            longest_selected = max(list(self._category_measure_width(t, selected_font_size) for t in titles) or [260])
            # Leave permanent breathing room for the folder icon plus trailing
            # padding so no title disappears at either size.
            needed = max(426, longest_normal + 102, longest_selected + 136)
            chosen_font, chosen_sel_font, chosen_width = font_index, selected_font_index, min(max_width, needed)
            if needed <= max_width:
                break
        chosen_width = int(chosen_width)
        if chosen_width % 2:
            chosen_width += 1
        self._category_row_card_w = max(426, min(max_width, chosen_width))
        self._category_title_font = chosen_font
        self._category_selected_title_font = chosen_sel_font
        return self._category_row_card_w

    def _set_category_clean_visibility(self, active):
        # Categories intentionally keep only the brand, exact Home backdrop and
        # floating rows.  A neutral full-screen underlay covers the Browser's
        # baked divider while the hero is being restored, so neither the old
        # top line nor any right-side Browser furniture can flash through.
        try:
            (self["category_clean_bg"].show() if active else self["category_clean_bg"].hide())
        except Exception as exc:
            optional_failure("ui.category_clean_underlay", exc)
        if active:
            # Category pages are intentionally brand-free.  Do not rely on hide()
            # alone: some Enigma2 images repaint the skin-time pixmap after layout.
            # Clear the native pixmap and move the widget off-screen as well.
            try:
                if self["brand_header"].instance is not None:
                    self["brand_header"].instance.setPixmap(None)
                self["brand_header"].hide()
                self._browser_geom("brand_header",2000,0,1,1)
            except Exception as exc:optional_failure("ui.category_brand_hard_hide",exc)
            # Hard-disable the legacy right-side preview, including any root-page
            # decode that was queued just before cached Categories became ready.
            try:self._image_suspend()
            except Exception as exc:optional_failure("ui.category_preview_suspend", exc)
            try:
                if self["preview"].instance is not None:
                    self["preview"].instance.setPixmap(None)
                self["preview"].hide()
            except Exception as exc:optional_failure("ui.category_preview_clear", exc)
        if not active:
            try:
                self._browser_geom("brand_header",48,12,300,96)
                _brand=asset("brand_header_full.png")
                if self["brand_header"].instance is not None and os.path.isfile(_brand):
                    self["brand_header"].instance.setPixmapFromFile(_brand)
            except Exception as exc:optional_failure("ui.category_brand_restore",exc)
        names=("brand_header","title","section","counter","top_divider","preview","accent_frame",
               "info_card1","info_card2","info_card3","info_icon1","info_icon2","info_icon3",
               "info_title","info","status","red_bg","green_bg","yellow_bg","blue_bg",
               "red","green","yellow","blue")
        if active and self._category_glass_wanted():
            # glass page owns the colour-key hints; they are hidden until its layout runs
            names=tuple(n for n in names if n not in _CAT_GLASS_KEYS)
            if not getattr(self,"_cat_glass_on",False):
                for name in _CAT_GLASS_KEYS:
                    try:self[name].hide()
                    except Exception:pass
        for name in names:
            try:
                (self[name].hide() if active else self[name].show())
            except Exception as exc:
                optional_failure("ui.category_clean_visibility", exc)

    def _apply_category_portal_geometry(self):
        """Apply the clean full-height Categories rail.

        The Categories-only brand is hidden and the exact approved 66px row
        grammar is preserved.  Sixteen complete rows fit between 12px top/bottom
        margins, so density increases without shrinking cards or their spacing.
        """
        if self._category_glass_wanted():
            return self._category_glass_layout()
        _cat_max = 1320 if str(getattr(self, "media_type", "") or "").lower() in ("itv", "vod", "series") else 860
        card_w=max(426,min(_cat_max,int(getattr(self,"_category_row_card_w",426) or 426)))
        list_w=card_w+8
        self._browser_geom("list",14,12,list_w,1056)
        try:
            self["list"].row_width=list_w
            if self["list"].instance is not None:
                try:self["list"].instance.setSelectionEnable(0)
                except Exception as exc:optional_failure("ui.silent_guard",exc)
                try:self["list"].instance.setTransparent(1)
                except Exception as exc:optional_failure("ui.silent_guard",exc)
                try:self["list"].instance.setScrollbarMode(2)
                except Exception as exc:optional_failure("ui.silent_guard",exc)
        except Exception as exc:optional_failure("ui.category_settings_list",exc)
        self._set_category_clean_visibility(True)

    # ------------------------------------------------------------------
    # R5.66 Movies / Series category page.  Header + one 14-row glass rail
    # (native MultiContent, windowed by IconMenuList) + a preview panel whose
    # posters come ONLY from caches that already exist (see ui_category_glass).
    # ------------------------------------------------------------------
    def _category_glass_wanted(self):
        return (getattr(self,"level",None) in ("genres","genres_loading")
                and str(getattr(self,"media_type","") or "").lower() in ("vod","series","itv"))

    def _category_glass_details(self, entry, selected, checked):
        from .ui_category_glass import entry_count
        n=entry_count(entry)
        return {"selected":bool(selected),"checked":bool(checked),"count":""}

    def _cat_set_text(self, name, text):
        text=str(text or "")
        if self._cat_glass_txt.get(name)==text:return
        self._cat_glass_txt[name]=text
        try:self[name].setText(text)
        except Exception as exc:optional_failure("ui.category_glass_text",exc)

    def _cat_set_pixmap(self, name, filename):
        """Load one static glass pixmap once per residency."""
        try:
            if name in self._cat_glass_pix:return True
            inst=self[name].instance
            if inst is None:return False
            path=asset(filename)
            if not os.path.isfile(path):return False
            inst.setPixmapFromFile(path)
            self._cat_glass_pix.add(name)
            return True
        except Exception as exc:
            optional_failure("ui.category_glass_pixmap",exc)
            return False

    def _category_glass_hide_widgets(self):
        self._category_footer_signature=None
        for name in _CAT_GLASS_WIDGETS:
            try:self[name].hide()
            except Exception:pass

    def _category_glass_hide(self):
        """Leave the glass page: stop preview work and hide its widgets."""
        was=getattr(self,"_cat_glass_on",False)
        self._cat_glass_on=False
        self._category_footer_active=False
        self._category_footer_signature=None
        for name in _CAT_FOOTER_PARTS:
            try:self[name].hide()
            except Exception:pass
        try:
            self._cat_pv_token+=1
            self._cat_pv_timer.stop()
        except Exception:pass
        if was or getattr(self,"_cat_glass_txt",None):
            self._category_glass_hide_widgets()
            self._cat_glass_txt={};self._cat_focus_pos=None;self._cat_scroll_sig=None;self._cat_pv_state="";self._cat_pv_key=""

    def _category_glass_header(self):
        media=str(getattr(self,"media_type","") or "").lower()
        n=len(self.content_items or []) if self.level=="genres" else 0
        self._cat_set_text("cat_hdr_title","")
        self._cat_set_text("cat_hdr_sub",(_("Categories: %d")%n) if self.level=="genres" else _("Loading categories..."))

    def _category_glass_layout(self):
        """Idempotent page geometry; runs on every _apply_category_portal_geometry()."""
        self._cat_glass_on=True
        self._browser_geom("list",66,68,800,990)
        try:
            self["list"].row_width=800
            inst=self["list"].instance
            if inst is not None:
                for fn_name,arg in (("setSelectionEnable",0),("setTransparent",1),("setScrollbarMode",2)):
                    try:getattr(inst,fn_name)(arg)
                    except Exception as exc:optional_failure("ui.silent_guard",exc)
        except Exception as exc:optional_failure("ui.category_glass_list",exc)
        self._set_category_clean_visibility(True)
        self._category_glass_header()
        self._cat_set_pixmap("cat_hdr_line","cat_flag_120x4.png")
        self._cat_set_pixmap("cat_scrim","cat_scrim_1000x1080.png")
        for name in ("cat_scrim","cat_hdr_sub","cat_hdr_line"):
            try:self[name].show()
            except Exception:pass
        self._category_glass_keys()

    def _category_glass_keys(self):
        """Four colour keys packed at the bottom-right corner."""
        self._category_footer_active=True
        media=str(getattr(self,"media_type","") or "").lower()
        blue_text=_("Cache Picons") if media=="itv" else _("Export")
        labels=(
            ("red", _("Search"), 108),
            ("green", _("Manage"), 118),
            ("yellow", _("Hide"), 84),
            ("blue", blue_text, 176 if media=="itv" else 118),
        )
        desktop=getDesktop(0).size()
        signature=(desktop.width(), desktop.height(), labels,
                   tuple(id(self[c].instance) for c in ("red","green","yellow","blue")+_CAT_FOOTER_PARTS))
        if (signature==getattr(self,"_category_footer_signature",None)
                and all(self[c].getText()==text for c,text,_w in labels)
                and all(getattr(self[c],"visible",True) for c in ("red","green","yellow","blue","cat_footer"))):
            return
        measured=[]
        for color, text, fallback_w in labels:
            self._browser_geom(color, 2000, 0, fallback_w, 42)
            self[color].setText(text)
            inst=self[color].instance
            width=fallback_w
            if inst is not None:
                try:
                    from enigma import gFont
                    sy=float(getDesktop(0).size().height()) / 1080.0
                    sx=float(getDesktop(0).size().width()) / 1920.0
                    inst.setFont(gFont("Regular", int(round(20*sy))))
                    width=min(fallback_w, max(1, int(round((inst.calculateSize().width() + (6 if _us_env.IS_DREAMOS else 0))/sx))))
                except Exception as exc:
                    optional_failure("ui.category_caption_measure", exc)
            measured.append((color, text, width))
        labels=tuple(measured)
        colors={"red":"#ffffff","green":"#ffffff","yellow":"#ffffff","blue":"#ffffff"}
        right=1868
        gap=22
        x=right
        slots={}
        for color, _text, text_w in reversed(labels):
            x-=text_w
            slots[color]=(x-58, x, text_w)
            x-=58+gap
        for color, text, text_w in labels:
            dash_x, text_x, width=slots[color]
            self._browser_geom(color+"_bg", dash_x, 1026, 56, 42)
            self._browser_geom(color, text_x, 1026, width, 42)
            try:
                self[color].setText(text)
                inst=self[color].instance
                if inst is not None:
                    inst.setForegroundColor(parseColor(colors[color]))
                    from enigma import gFont
                    inst.setFont(gFont("Regular", int(round(20 * float(getDesktop(0).size().height()) / 1080.0))))
                self[color+"_bg"].show()
                self[color].show()
            except Exception as exc:
                optional_failure("ui.category_color_keys", exc)

        try:
            from .ui_icon_menu import _us_fit_png
            left=min(slot[0] for slot in slots.values())-8
            width=1880-left
            rest=max(0,width-48);fade=min(700,rest//2);mid=rest-2*fade
            slots=(("cat_footer","left",left,24),
                   ("cat_footer_fade_left","fade_left",left+24,fade),
                   ("cat_footer_middle","middle",left+24+fade,mid),
                   ("cat_footer_fade_right","fade_right",left+24+fade+mid,fade),
                   ("cat_footer_right","right",1880-24,24))
            sx=float(desktop.width())/1920.0
            sy=float(desktop.height())/1080.0
            bar_h=max(1,int(round(64*sy)))
            bar_y=int(round(1015*sy))
            cat_wh=getattr(self,"_cat_footer_wh",None)
            if cat_wh is None:
                cat_wh=self._cat_footer_wh={}
            for name,part,x,w in slots:
                inst=self[name].instance
                if inst is not None:
                    if w<=0:
                        self[name].hide();continue
                    px0=int(round(x*sx))
                    px1=int(round((x+w)*sx))
                    pw=max(1,px1-px0)
                    wh=(pw,bar_h)
                    if name not in self._cat_glass_pix or cat_wh.get(name)!=wh:
                        fit_path=_us_fit_png(asset("premium_footer_caps_r5424/"+part+".png"),pw,bar_h,False)
                        if fit_path and os.path.isfile(fit_path):
                            inst.setPixmapFromFile(fit_path)
                            self._cat_glass_pix.add(name)
                            cat_wh[name]=wh
                    inst.move(ePoint(px0,bar_y))
                    inst.resize(eSize(pw,bar_h))
                    self[name].show()
            for part in ("left", "fade_left", "middle", "fade_right", "right"):
                self["compact_footer_" + part].hide()
            if all(self[c].instance is not None for c in ("red","green","yellow","blue")+_CAT_FOOTER_PARTS):
                self._category_footer_signature=signature
        except Exception as exc:
            optional_failure("ui.category_footer_native", exc)

    def _category_glass_selection(self, idx):
        """Focus overlay, scroll thumb and preview text for the focused row."""
        lst=self["list"]
        top=int(lst.win_top());total=int(lst.win_total())
        slot=max(0,min(16,int(idx)-top))
        pos=(54,68+58*slot)
        if self._cat_focus_pos!=pos or "cat_focus" not in self._cat_glass_pix:
            if "cat_focus" not in self._cat_glass_pix:
                try:
                    from .ui_icon_menu import _us_fit_png
                    desktop=getDesktop(0).size()
                    fw=max(1,int(round(800*float(desktop.width())/1920.0)))
                    fh=max(1,int(round(56*float(desktop.height())/1080.0)))
                    fpath=_us_fit_png(asset("cat_focus_824x56.png"),fw,fh,True)
                    if fpath and os.path.isfile(fpath) and self["cat_focus"].instance is not None:
                        self["cat_focus"].instance.setPixmapFromFile(fpath)
                        self._cat_glass_pix.add("cat_focus")
                except Exception as exc:
                    optional_failure("ui.category_focus_fit",exc)
                    self._cat_set_pixmap("cat_focus","cat_focus_824x56.png")
            if "cat_focus" in self._cat_glass_pix:
                self._browser_geom("cat_focus",pos[0],pos[1],800,56)
                self._cat_focus_pos=pos
                try:self["cat_focus"].show()
                except Exception:pass
        sig=(top,total)
        if sig!=self._cat_scroll_sig:
            self._cat_scroll_sig=sig
            try:
                self["cat_scroll_track"].hide();self["cat_scroll_thumb"].hide()
            except Exception as exc:optional_failure("ui.category_glass_scroll",exc)
        self._category_glass_header()
        self._cat_pv_select(idx)

    # ----- preview panel --------------------------------------------------
    def _cat_pv_entry(self, idx):
        items=self.content_items or []
        if 0<=idx<len(items) and isinstance(items[idx],dict):return items[idx]
        return None

    def _cat_warm_select(self, idx):
        """R5.199: resting on a category warms its first page in the background
        (RAM/SQLite page cache only, nothing is painted), so OK opens instantly."""
        try:self._cat_warm_timer.stop()
        except Exception:pass
        if getattr(self,"_screen_closed",False) or self.level!="genres":return
        if str(self.media_type or "").lower() not in ("vod","series","itv"):return
        self._cat_warm_timer.start(650,True)

    def _cat_warm_fire(self):
        if getattr(self,"_screen_closed",False) or self.level!="genres" or self._cat_warm_busy:return
        try:entry=self._cat_pv_entry(self["list"].getSelectedIndex())
        except Exception:return
        if not isinstance(entry,dict):return
        media=str(self.media_type or "").lower()
        gid=str(entry.get("id") or entry.get("genre_id") or entry.get("category_id") or entry.get("name") or entry.get("title") or "*")
        if gid in ("*","","None"):return
        key=(media,gid)
        if key in self._cat_warm_done:return
        self._cat_warm_done.add(key)
        self._cat_warm_busy=True
        ref=weakref.ref(self);client=self.client
        def work():
            try:
                scr=ref()
                if scr is None or getattr(scr,"_screen_closed",False) or scr.level!="genres":
                    return
                scr=None
                client.ordered_page(media,gid,1)
            except Exception as exc:
                optional_failure("ui.category_warm",exc)
            finally:
                s2=ref()
                if s2 is not None:s2._cat_warm_busy=False
        try:
            from .core.shared_executors import METADATA_EXECUTOR
            METADATA_EXECUTOR.submit(work)
        except Exception as exc:
            self._cat_warm_busy=False;optional_failure("ui.category_warm_submit",exc)

    def _cat_pv_select(self, idx):
        self._cat_warm_select(idx)
        return  # R5.118: no preview panel / poster work on the clean category page

    def _cat_pv_show_empty(self):
        if self._cat_pv_state=="empty":return
        self._cat_pv_state="empty"
        for name in ("cat_pv_fan","cat_pv_chipbg0","cat_pv_chipbg1","cat_pv_chipbg2","cat_pv_chip0","cat_pv_chip1","cat_pv_chip2","cat_pv_upd"):
            try:self[name].hide()
            except Exception:pass
        self._cat_glass_txt["cat_pv_upd"]=""
        try:
            self["cat_pv_ph"].show()
        except Exception:pass

    def _cat_pv_forget_current(self):
        """After a category was opened its first page is cached: re-resolve its preview."""
        if not self._category_glass_wanted():return
        key=getattr(self,"_cat_pv_key","")
        if key:self._cat_pv_ram.pop(key,None)

    def _cat_pv_dwell(self):
        """Dwell elapsed: resolve the focused category from caches on a worker."""
        if getattr(self,"_screen_closed",False) or not self._cat_glass_on or self.level!="genres":return
        if not self._selection_settings().get("category_preview_posters",True):return
        try:idx=self["list"].getSelectedIndex()
        except Exception:return
        entry=self._cat_pv_entry(idx)
        if entry is None:return
        from .ui_category_glass import build_preview, preview_key, category_id
        media=str(self.media_type or "").lower()
        key=preview_key(self.profile,media,category_id(entry))
        hit=self._cat_pv_ram.get(key)
        if hit is not None and (hit[1].get("cached") or time.monotonic()-hit[0]<15.0):return
        token=self._cat_pv_token
        ref=weakref.ref(self);out=self._cat_pv_queue
        client=self.client;profile=dict(self.profile or {});entry_copy=dict(entry)
        def current():
            scr=ref()
            return scr is not None and scr._cat_pv_token==token and not getattr(scr,"_screen_closed",False)
        def work():
            try:
                res=build_preview(client,profile,media,entry_copy,current) if current() else None
                out.put((token,key,res))
            except Exception as exc:
                optional_failure("ui.category_pv_worker",exc)
                out.put((token,key,None))
        try:
            from .core.shared_executors import METADATA_EXECUTOR
            METADATA_EXECUTOR.submit(work)
        except Exception as exc:
            optional_failure("ui.category_pv_submit",exc);return
        self._cat_pv_pending+=1
        try:self._cat_pv_drain_timer.start(120,True)
        except Exception as exc:optional_failure("ui.category_pv_drain_start",exc)

    def _cat_pv_drain(self):
        while True:
            try:token,key,res=self._cat_pv_queue.get_nowait()
            except queue.Empty:break
            except Exception:break
            self._cat_pv_pending=max(0,self._cat_pv_pending-1)
            if not isinstance(res,dict):continue
            self._cat_pv_ram[key]=(time.monotonic(),res)
            self._cat_pv_ram.move_to_end(key)
            while len(self._cat_pv_ram)>64:self._cat_pv_ram.popitem(last=False)
            # stale answer (focus moved on): keep it cached, never paint it
            if token!=self._cat_pv_token or key!=self._cat_pv_key or not self._cat_glass_on or self.level!="genres":continue
            try:self._cat_pv_apply(self._cat_pv_entry(self["list"].getSelectedIndex()),res)
            except Exception as exc:optional_failure("ui.category_pv_apply",exc)
        if self._cat_pv_pending>0 and not getattr(self,"_screen_closed",False):
            try:self._cat_pv_drain_timer.start(120,True)
            except Exception:pass

    def _cat_pv_age_text(self, saved):
        try:age=max(0,int(time.time()-float(saved)))
        except Exception:return ""
        if float(saved or 0)<=0:return ""
        if age<90:return _("updated just now")
        if age<3600:return _("updated %d min ago")%(age//60)
        if age<86400:return _("updated %d h ago")%(age//3600)
        days=age//86400
        return _("updated today") if days<=0 else _("updated %d days ago")%days

    def _cat_pv_apply(self, entry, res):
        from .ui_category_glass import entry_count
        if not isinstance(res,dict):return
        n=entry_count(entry) if entry is not None else None
        if n is None:n=res.get("total")
        self._cat_set_text("cat_pv_count",(_("%s titles")%"{:,}".format(int(n))) if n else "")
        chips=list((res.get("chips") or {}).items())[:3]
        for i in range(3):
            try:
                if i<len(chips):
                    self._cat_set_pixmap("cat_pv_chipbg%d"%i,"cat_chip_140x36.png")
                    self._cat_set_text("cat_pv_chip%d"%i,"%s  %s"%(chips[i][0],"{:,}".format(int(chips[i][1]))))
                    self["cat_pv_chipbg%d"%i].show();self["cat_pv_chip%d"%i].show()
                else:
                    self["cat_pv_chipbg%d"%i].hide();self["cat_pv_chip%d"%i].hide()
            except Exception as exc:optional_failure("ui.category_pv_chip",exc)
        upd=self._cat_pv_age_text(res.get("saved")) if res.get("cached") else ""
        self._cat_set_text("cat_pv_upd",upd)
        try:
            (self["cat_pv_upd"].show() if upd else self["cat_pv_upd"].hide())
        except Exception:pass
        fan=str(res.get("fan") or "")
        shown=False
        if fan and os.path.isfile(fan):
            try:
                inst=self["cat_pv_fan"].instance
                if inst is not None:
                    if self._cat_pv_fan_path!=fan:
                        inst.setPixmapFromFile(fan);self._cat_pv_fan_path=fan
                    self["cat_pv_fan"].show();self["cat_pv_ph"].hide()
                    shown=True
            except Exception as exc:optional_failure("ui.category_pv_fan_bind",exc)
        if shown:
            self._cat_pv_state="fan"
        else:
            try:
                self["cat_pv_fan"].hide();self["cat_pv_ph"].show()
            except Exception:pass
            self._cat_pv_state="stats"

    def _cat_pv_close(self):
        try:
            self._cat_pv_token+=1
            self._cat_pv_timer.stop();self._cat_pv_drain_timer.stop();self._cat_warm_timer.stop()
        except Exception as exc:optional_failure("ui.category_pv_close",exc)
        for _cname in ("_cat_pv_timer_conn","_cat_pv_drain_conn","_cat_warm_conn"):
            try:
                _conn=getattr(self,_cname,None)
                if _conn is not None:_conn.disconnect()
                setattr(self,_cname,None)
            except Exception:pass
        for _tname,_cb in (("_cat_pv_timer",self._cat_pv_dwell),("_cat_pv_drain_timer",self._cat_pv_drain),("_cat_warm_timer",self._cat_warm_fire)):
            try:
                _tm=getattr(self,_tname,None)
                if _tm is not None and _cb in _tm.callback:_tm.callback.remove(_cb)
            except Exception:pass
        try:
            while True:self._cat_pv_queue.get_nowait()
        except Exception:pass

    def _restore_browser_geometry(self):
        """Restore the normal Browser geometry when leaving Categories."""
        self._category_glass_hide()
        self._movies_category_visual_ready = False
        self._set_category_clean_visibility(False)
        try:
            if self["page_adaptive_bg"].instance is not None:
                self["page_adaptive_bg"].instance.setPixmap(None)
            self["page_adaptive_bg"].hide()
            self._category_static_bg_loaded = ""
        except Exception as exc:
            optional_failure("ui.silent_guard",exc)
        self._browser_geom("list", 78, 190, 754, 720)
        self._browser_geom("preview", 1110, 205, 530, 382)
        self._browser_geom("accent_frame", 1090, 194, 570, 405)
        self._browser_geom("info_card1", 1070, 620, 610, 70)
        self._browser_geom("info_card2", 1070, 708, 610, 70)
        self._browser_geom("info_card3", 1070, 796, 610, 70)
        self._browser_geom("info_icon1", 1090, 634, 42, 42)
        self._browser_geom("info_icon2", 1090, 722, 42, 42)
        self._browser_geom("info_icon3", 1090, 810, 42, 42)
        self._browser_geom("info_title", 1145, 620, 515, 70)
        self._browser_geom("info", 1145, 708, 515, 70)
        self._browser_geom("status", 1145, 796, 515, 70)
        try:
            if self["list"].instance is not None:
                try:self["list"].instance.setSelectionEnable(1)
                except Exception as exc:optional_failure("ui.silent_guard",exc)
                try:self["list"].instance.setScrollbarMode(2)
                except Exception:
                    try:self["list"].instance.setScrollbarMode(2)
                    except Exception as exc:optional_failure("ui.silent_guard",exc)
        except Exception as exc:optional_failure("ui.silent_guard",exc)
        try:
            from .wqhd_layout import wh as _wqhd_wh
            self._image_size=(530,382)
            pw, ph = _wqhd_wh(530, 382)
            self._picload.setPara((pw, ph, 1, 1, False, 1, "#000000"))
        except Exception as exc:optional_failure("ui.silent_guard",exc)

    def _category_mood_source(self):
        """Return the cached source belonging to the exact current Home hero.

        Categories prefer the hero's raw local backdrop so Test15 can retain the
        artwork farther down the screen than Home's intentionally short prepared
        top-hero.  No network lookup is allowed here.
        """
        media = str(getattr(self, "media_type", "") or "").lower()
        if media in ("itv", "vod", "series"):
            return None
        hero = {}
        try:
            with open(HOME_HERO_FILE, "r", encoding="utf-8") as h:
                state = json.load(h)
            hero = state.get("hero") if isinstance(state, dict) and isinstance(state.get("hero"), dict) else {}
        except Exception:
            hero = {}
        # Categories need more vertical artwork than Home's prepared TOP hero,
        # whose alpha intentionally reaches zero around y=610.  Prefer the exact
        # raw cached backdrop belonging to that same hero, then build our own
        # receiver-safe long derivative from it.
        for key in ("display_backdrop_local", "backdrop_local"):
            candidate = str(hero.get(key) or "") if isinstance(hero, dict) else ""
            try:
                if candidate and os.path.isfile(candidate) and os.path.getsize(candidate) > 4096:
                    return candidate
            except Exception as exc:
                optional_failure("ui.category_raw_hero", exc)

        direct = str(getattr(self, "_home_adaptive_source", "") or "")
        try:
            if direct and os.path.isfile(direct) and os.path.getsize(direct) > 4096:
                return direct
        except Exception as exc:
            optional_failure("ui.silent_guard",exc)

        prepared = str(hero.get("prepared") or "") if isinstance(hero, dict) else ""
        try:
            if prepared and os.path.isfile(prepared) and os.path.getsize(prepared) > 4096:
                return prepared
        except Exception as exc:
            optional_failure("ui.category_prepared_fallback", exc)

        section_source = {
            "itv": "us80_section_live_530x382.png",
        }.get(media, "ultra_bg_clean_1920x1080.png")
        fallback = asset(section_source)
        return fallback if fallback and os.path.isfile(fallback) else None

    def _category_chrome_source(self):
        """Return a dynamic source only for category pages that still use it.

        Live, Movies and Series are permanently static and never read Home Hero state.
        """
        media = str(getattr(self, "media_type", "") or "").lower()
        if media in ("itv", "vod", "series"):
            return None
        hero = {}
        try:
            with open(HOME_HERO_FILE, "r", encoding="utf-8") as h:
                state = json.load(h)
            hero = state.get("hero") if isinstance(state, dict) and isinstance(state.get("hero"), dict) else {}
        except Exception:
            hero = {}
        for candidate in (str(hero.get("prepared") or ""), str(getattr(self, "_home_adaptive_source", "") or "")):
            try:
                if candidate and os.path.isfile(candidate) and os.path.getsize(candidate) > 4096:
                    return candidate
            except Exception as exc:
                optional_failure("ui.category_chrome_source", exc)
        return self._category_mood_source()

    def _load_category_backdrop(self):
        """Show the clean, lower-reaching Categories hero without building rows."""
        if not self._category_dynamic_visuals_enabled():
            # Approved static path for Live, Movies and Series. No Home Hero lookup,
            # derivative build, palette extraction, TMDb work or worker.
            self._apply_static_category_background()
            return self._category_static_bg_loaded or None
        try:
            src = self._category_mood_source()
            if not src:
                return None
            try:
                stamp = str(int(os.path.getmtime(src)))
            except Exception:
                stamp = "0"
            key = hashlib.sha1((src + "|" + stamp + "|category-long-hero-v1").encode("utf-8", "ignore")).hexdigest()[:16]
            backdrop = _build_category_extended_backdrop(src, key)
            if not backdrop or not os.path.isfile(backdrop):
                backdrop = src
            self._browser_geom("page_adaptive_bg", 0, 0, 1920, 1080)
            if self["page_adaptive_bg"].instance is not None and os.path.isfile(backdrop):
                self["page_adaptive_bg"].instance.setPixmapFromFile(backdrop)
                self["page_adaptive_bg"].show()
            self._set_category_clean_visibility(True)
            return backdrop
        except Exception as exc:
            optional_failure("ui.category_long_backdrop", exc)
            return None

    def _load_category_chrome(self):
        if not self._category_dynamic_visuals_enabled():
            # Static receiver-local rows only. No Home Hero palette lookup and no
            # _build_category_adaptive_chrome() call for Live/Movies/Series Categories.
            self._category_chrome = self._movies_static_category_chrome()
            return self._category_chrome
        try:
            src = self._category_chrome_source()
            if not src:
                self._category_chrome = {}
                return {}
            try:
                stamp = str(int(os.path.getmtime(src)))
            except Exception:
                stamp = "0"
            card_w=max(426,min(860,int(getattr(self,"_category_row_card_w",426) or 426)))
            key = hashlib.sha1((src + "|" + stamp + "|category-settings-v2|" + str(card_w)).encode("utf-8", "ignore")).hexdigest()[:16]
            self._category_chrome = _build_category_adaptive_chrome(
                src, key, getattr(self,"media_type","") or "", card_w
            )

            # The rows and the visible long hero derive from the same cached Home
            # source; Categories simply retain the picture farther down the screen.
            self._load_category_backdrop()
            return self._category_chrome
        except Exception as exc:
            optional_failure("ui.category_chrome_load", exc)
            self._category_chrome = {}
            return {}
