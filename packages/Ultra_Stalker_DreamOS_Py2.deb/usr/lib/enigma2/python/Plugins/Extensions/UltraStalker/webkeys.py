# -*- coding: utf-8 -*-
"""Authenticated Web settings for receiver-owned metadata/subtitle credentials.

Responses contain status only. Candidate credentials travel only to their fixed
provider over verified HTTPS, and are persisted only after that provider accepts
an authenticated request. Existing settings remain intact on validation failure.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str, OSError, TimeoutError
json = _us_env.json
re = _us_env.re
socket = _us_env.socket
ssl = _us_env.ssl
threading = _us_env.threading
urllib = _us_env.urllib
urllib = _us_env.urllib
urllib = _us_env.urllib

_SERVICES = {"tmdb": "TMDB_API_KEY", "subdl": "SUBDL_API_KEY", "subsource": "SUBSOURCE_API_KEY"}
_LIMIT = threading.BoundedSemaphore(2)
_SAVE_LOCK = threading.RLock()
_MAX_RESPONSE = 256 * 1024

class KeySettingsError(ValueError):
    def __init__(self, code):
        self.code = code
        super(KeySettingsError, self).__init__(code)

class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None

def normalize_key(service, value):
    if not isinstance(service,str) or service not in _SERVICES:raise KeySettingsError("unknown_service")
    if not isinstance(value,str) or len(value)>8192:raise KeySettingsError("invalid_value")
    # Clipboard direction marks are not part of any of these credentials.
    value=re.sub(r"[\u200b\u200e\u200f\ufeff\u202a-\u202e\u2066-\u2069]","",value).strip()
    names={"tmdb":("TMDB_API_KEY","TMDB_READ_TOKEN","TMDB_API_TOKEN"),"subdl":("SUBDL_API_KEY",),"subsource":("SUBSOURCE_API_KEY",)}
    assignment=re.match(r"^([A-Z][A-Z0-9_]*(?:API_KEY|READ_TOKEN|API_TOKEN))\s*=\s*(.*)$",value,re.S|re.I)
    if assignment:
        if assignment.group(1).upper() not in names[service]:raise KeySettingsError("wrong_service")
        value=assignment.group(2).strip()
    if len(value)>=2 and value[0]==value[-1] and value[0] in "\"'":value=value[1:-1].strip()
    if service=="tmdb":value=re.sub(r"^Bearer\s+","",value,flags=re.I).strip()
    if not value:raise KeySettingsError("empty_key")
    if "://" in value or value.lower().startswith("www."):raise KeySettingsError("key_not_url")
    if len(value)>4096 or not re.fullmatch(r"[A-Za-z0-9._~+/=\-]+",value):raise KeySettingsError("invalid_characters")
    if service=="tmdb" and not (re.fullmatch(r"[A-Fa-f0-9]{32}",value) or len(value)>64):
        raise KeySettingsError("tmdb_format")
    return value

def service_key_status():
    from .storage import load_settings
    settings=load_settings()
    fields={"tmdb":("tmdb_credential","tmdb_credential_source"),"subdl":("subdl_api_key","subdl_api_key_source"),"subsource":("subsource_api_key","subsource_api_key_source")}
    result={}
    for service,(key,source) in fields.items():
        active=bool(str(settings.get(key) or "").strip())
        kind="default" if settings.get(source)=="builtin" else ("custom" if active else "none")
        result[service]={"configured":active,"source":kind}
    return {"ok":True,"services":result}

def _probe_request(service, value):
    headers={"Accept":"application/json","User-Agent":"UltraStalker/WebKeys"}
    if service=="tmdb":
        url="https://api.themoviedb.org/3/configuration"
        if re.fullmatch(r"[A-Fa-f0-9]{32}",value):url+="?"+urllib.parse.urlencode({"api_key":value})
        else:headers["Authorization"]="Bearer "+value
    elif service=="subdl":
        url="https://api.subdl.com/api/v1/subtitles?"+urllib.parse.urlencode({"api_key":value,"film_name":"Inception","type":"movie","languages":"EN","subs_per_page":1})
    else:
        url="https://api.subsource.net/api/v1/movies/search?"+urllib.parse.urlencode({"searchType":"text","q":"Inception"})
        headers["X-API-Key"]=value
    return urllib.request.Request(url,headers=headers)

def verify_key(service,value):
    if not _LIMIT.acquire(blocking=False):raise KeySettingsError("busy")
    try:
        opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),_NoRedirect())
        try:
            with opener.open(_probe_request(service,value),timeout=8) as response:
                body=response.read(_MAX_RESPONSE+1)
                if len(body)>_MAX_RESPONSE:raise KeySettingsError("unconfirmed_response")
                try:data=json.loads(body.decode("utf-8"))
                except (UnicodeError,ValueError):raise KeySettingsError("unconfirmed_response")
        except urllib.error.HTTPError as exc:
            status=exc.code;exc.close()
            raise KeySettingsError({401:"invalid_key",403:"access_denied",402:"plan_required",429:"rate_limit"}.get(status,"service_unavailable"))
        except (socket.timeout,TimeoutError):raise KeySettingsError("timeout")
        except (urllib.error.URLError,ssl.SSLError,OSError):raise KeySettingsError("connection_failed")
        if not isinstance(data,dict):raise KeySettingsError("unconfirmed_response")
        accepted=(isinstance(data.get("images"),dict) if service=="tmdb" else data.get("status") is True if service=="subdl" else data.get("success") is True)
        if not accepted:
            # Classify only; never reflect provider bodies or secret-bearing URLs.
            message=str(data.get("error") or data.get("message") or "").lower()
            if any(x in message for x in ("invalid api","invalid key","unauthorized","api key is invalid","invalid_api_key")):raise KeySettingsError("invalid_key")
            if "limit" in message or "quota" in message:raise KeySettingsError("rate_limit")
            if "subscription" in message or "premium" in message or "payment" in message:raise KeySettingsError("plan_required")
            raise KeySettingsError("unconfirmed_response")
    finally:_LIMIT.release()

def update_service_key(payload):
    if not isinstance(payload,dict) or set(payload)-{"service","action","value"}:raise KeySettingsError("invalid_request")
    service=payload.get("service");action=payload.get("action")
    if not isinstance(service,str) or service not in _SERVICES:raise KeySettingsError("unknown_service")
    if action not in ("test","save","reset"):raise KeySettingsError("invalid_request")
    value=""
    if action!="reset":
        value=normalize_key(service,payload.get("value"))
        verify_key(service,value)
    if action=="test":return {"ok":True,"verified":True,"saved":False,"service":service}
    try:
        with _SAVE_LOCK:
            from .storage import save_tmdb_credential,update_api_keys,strip_builtin_value
            same_as_default=False
            if service=="tmdb":save_tmdb_credential(value)
            else:
                stored=strip_builtin_value(_SERVICES[service],value)
                # A key identical to the bundled one is never written (it would only copy the
                # default into api_keys.conf), so the page must say so instead of looking ignored.
                same_as_default=bool(value) and not stored
                update_api_keys({_SERVICES[service]:stored})
        result=service_key_status()
    except Exception:raise KeySettingsError("save_failed")
    result.update({"verified":action=="save","saved":True,"service":service,"reset":action=="reset","same_as_default":same_as_default})
    return result
