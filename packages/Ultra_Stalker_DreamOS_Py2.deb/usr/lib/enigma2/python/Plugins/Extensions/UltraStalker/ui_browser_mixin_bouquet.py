# -*- coding: utf-8 -*-
"""Live bouquet channel selection and target bouquet choice.

Methods moved verbatim out of ``PortalBrowserScreen`` (ui_screens_browser.py); behaviour is unchanged.
This module is imported by ui_screens_browser.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, max
from .ui_screens_browser import (
    _,
    os,
    show_notice,
)


class BrowserBouquetMixin(object):
    """Live bouquet channel selection and target bouquet choice."""

    @staticmethod
    def _bouquet_channel_key(item):
        row=item if isinstance(item,dict) else {}
        raw="%s|%s|%s"%(str(row.get("id") or row.get("ch_id") or ""),str(row.get("cmd") or row.get("command") or row.get("url") or ""),str(row.get("name") or row.get("title") or ""))
        return hashlib.sha1(raw.encode("utf-8","ignore")).hexdigest()[:20]

    def _prepare_live_bouquet_row(self,item,allow_fetch=False):
        row=dict(item or {}) if isinstance(item,dict) else {}
        raw_name=row.get("name") or row.get("title") or row.get("id") or _("Channel")
        row["_receiver_name"]=_clean_live_channel_name(raw_name)
        epg_ids=[]
        for key in ("ch_id","channel_id","id","stream_id","epg_id","tvg_id","xmltv_id"):
            value=row.get(key)
            if value in (None,""):continue
            value=str(value).strip()
            if value and value not in epg_ids:epg_ids.append(value)
        if epg_ids:row["_receiver_epg_candidates"]=epg_ids
        try:
            candidates=[]
            for key in ("stream_icon","picon","logo","logo_url","image","img","pic","cover","cover_url","hd","_visible_provider_art_url"):
                value=row.get(key)
                if isinstance(value,str):
                    value=value.strip()
                    if value and value.lower() not in ("null","none") and value not in candidates:candidates.append(value)
            fallback=_image_url(row)
            if fallback and fallback not in candidates:candidates.append(fallback)
            best="";best_area=-1
            for source in candidates[:5]:
                local=_cached_live_picon_path(source,self.profile,row) or ""
                if (not local or not os.path.isfile(local)) and allow_fetch:
                    try:local=_download_live_portal_temp_picon(source,self.profile,self.client,item=row,timeout=4.5) or ""
                    except Exception:local=""
                    if not local:local=_download_public_live_picon(source,self.profile,item=row,timeout=4.5) or ""
                if not local or not os.path.isfile(local):continue
                area=0;large=False
                try:
                    from PIL import Image as _ExportPILImage
                    with _ExportPILImage.open(local) as im:
                        w,h=im.size;area=max(1,int(w))*max(1,int(h));large=(int(w)>=220 and int(h)>=132)
                except Exception:pass
                if area>best_area:best=local;best_area=area
                if large:break
            if best and os.path.isfile(best):
                fitted=_fit_live_picon_canvas(best,PERSISTENT_GENERATED_DIR,(220,132)) or best
                row["_receiver_picon_local"]=fitted if fitted and os.path.isfile(fitted) else best
                row["_receiver_picon_source_local"]=best
        except Exception as exc:optional_failure("ui.bouquet_selected_picon",exc)
        return row

    def _start_bouquet_channel_selection(self):
        if self.level!="items" or self.media_type!="itv":return
        self._bouquet_select_mode=True;self._bouquet_selected_rows={}
        self._render_content_rows(keep_index=self["list"].getSelectedIndex())
        self["status"].setText(_("Channel selection • OK select/unselect • MENU add to Bouquet"))

    def _toggle_bouquet_channel_selection(self):
        if not getattr(self,"_bouquet_select_mode",False) or self.level!="items" or self.media_type!="itv":return
        idx=self["list"].getSelectedIndex()
        if not (0<=idx<len(self.content_items)):return
        item=self.content_items[idx]
        if not isinstance(item,dict):return
        key=self._bouquet_channel_key(item)
        if key in self._bouquet_selected_rows:self._bouquet_selected_rows.pop(key,None)
        else:self._bouquet_selected_rows[key]=dict(item)
        self._render_content_rows(keep_index=idx)
        if idx+1<len(self.content_items):
            try:self["list"].moveToIndex(idx+1)
            except Exception:pass
        self["status"].setText(_("Selected channels: %d • MENU to add")%len(self._bouquet_selected_rows))

    def _select_all_visible_bouquet_channels(self):
        if not getattr(self,"_bouquet_select_mode",False):return
        for item in self.content_items:
            if isinstance(item,dict):self._bouquet_selected_rows[self._bouquet_channel_key(item)]=dict(item)
        self._render_content_rows(keep_index=self["list"].getSelectedIndex())
        self["status"].setText(_("Selected channels: %d • MENU to add")%len(self._bouquet_selected_rows))

    def _clear_bouquet_channel_selection(self):
        if not getattr(self,"_bouquet_select_mode",False):return
        self._bouquet_selected_rows={};self._render_content_rows(keep_index=self["list"].getSelectedIndex())
        self["status"].setText(_("Selection cleared • OK selects channels"))

    def _cancel_bouquet_channel_selection(self):
        self._bouquet_select_mode=False;self._bouquet_selected_rows={}
        if self.level=="items" and self.media_type=="itv":self._render_content_rows(keep_index=self["list"].getSelectedIndex())
        self["status"].setText(_("Ready"))

    def add_current_channel_to_bouquet(self):
        if self._busy or self.level!="items" or self.media_type!="itv":return
        idx=self["list"].getSelectedIndex()
        if not (0<=idx<len(self.content_items)):return
        item=self.content_items[idx]
        if not isinstance(item,dict):return
        self._choose_target_bouquet([dict(item)],False)

    def add_selected_channels_to_bouquet(self):
        if not getattr(self,"_bouquet_select_mode",False):return
        rows=list((getattr(self,"_bouquet_selected_rows",{}) or {}).values())
        if not rows:
            self["status"].setText(_("Select at least one channel first"));return
        self._choose_target_bouquet(rows,True)

    def _choose_target_bouquet(self,rows,multi):
        try:bouquets=list_tv_bouquets() or []
        except Exception as exc:
            self["status"].setText(_("Could not read TV bouquets: %s")%exc);return
        if not bouquets:
            show_notice(self.session, _("No TV bouquets were found on the receiver."), timeout=7, owner=self);return
        choices=[(str(row.get("name") or row.get("filename")),str(row.get("filename"))) for row in bouquets]
        self._pending_bouquet_rows=[dict(x) for x in rows if isinstance(x,dict)]
        self._pending_bouquet_multi=bool(multi)
        self.session.openWithCallback(self._target_bouquet_chosen,ChoiceBox,title=_("Choose target Bouquet"),list=choices)

    def _target_bouquet_chosen(self,choice):
        if not choice:return
        filename=str(choice[1] if isinstance(choice,(tuple,list)) and len(choice)>1 else "")
        label=str(choice[0] if isinstance(choice,(tuple,list)) and choice else filename)
        # Row preparation (picon lookup/fit with Pillow) runs in the worker below;
        # doing it here as well blocked the GUI thread for every selected channel.
        rows=[dict(x) for x in list(getattr(self,"_pending_bouquet_rows",[]) or []) if isinstance(x,dict)]
        if not filename or not rows:return
        keep_index=self["list"].getSelectedIndex();multi=bool(getattr(self,"_pending_bouquet_multi",False));cfg=load_settings()
        self["status"].setText((_("Adding to %s")%label)+" • "+(_("Channels: %d")%len(rows)))
        def work(handle):
            if handle.cancelled():return {}
            prepared=[]
            for row in rows:
                if handle.cancelled():return {}
                prepared.append(self._prepare_live_bouquet_row(row,True))
            return append_receiver_items_to_bouquet(self.profile,prepared,"itv",filename,cfg.get("service_type",4097))
        def ok(result):
            reload_bouquets()
            try:
                from .core.bouquets import _queue_receiver_epg_seed
                _queue_receiver_epg_seed((result or {}).get("epg_seed") or [])
            except Exception as exc:optional_failure("ui.browser_bouquet_epg_seed",exc)
            added=int((result or {}).get("added") or 0)
            if multi:
                self._bouquet_select_mode=False;self._bouquet_selected_rows={};self._render_content_rows(keep_index=keep_index)
            self["status"].setText(_("Bouquet updated • New channels: %d")%added)
            show_notice(self.session, _("Added to Bouquet: %s\n\nNew channels: %d")%(label,added), timeout=7, owner=self)
        def failed(exc):
            self["status"].setText(_("Bouquet update failed: %s")%exc)
        self._run_async(work,ok,failed)
