# -*- coding: utf-8 -*-
"""UI hook teardown, hide/show release and resume, detached prefetch futures, job draining.

Methods moved verbatim out of ``PremiumGridBase`` (ui_grid_base.py); behaviour is unchanged.
This module is imported by ui_grid_base.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, max, us_func
from .ui_grid_base import AsyncScreenMixin, _mem34, _ui_diag, diagnostic_failure, display_certification, os, time

class GridLifecycleMixin(object):
    """UI hook teardown, hide/show release and resume, detached prefetch futures, job draining."""

    def _stop_grid_ui_hooks(self):
        for queue_name in ('_quality_prefetch_jobs', '_art_prefetch_jobs', '_epg_jobs', '_folder_artwork_progress', '_poster_hud_jobs', '_grid_mood_jobs'):
            result_queue = getattr(self, queue_name, None)
            if result_queue is None:
                continue
            try:
                while True:
                    result_queue.get_nowait()
            except queue.Empty:
                pass
            except Exception as exc:
                optional_failure('ui.grid_queue_cleanup', exc)
        self._epg_pending = None
        for hook_name, callback in (('onLayoutFinish', self._grid_layout_ready), ('onLayoutFinish', self._refresh_search_sort_controls), ('onHide', self._grid_hidden_release), ('onShown', self._grid_shown_resume)):
            try:
                hooks = getattr(self, hook_name, None)
                if hooks is not None and callback in hooks:
                    hooks.remove(callback)
            except Exception as exc:
                optional_failure('ui.grid_hook_cleanup', exc)

    def _ui_diag_grid_close(self):
        try:
            _ui_diag('ui_close', screen='grid', media_type=getattr(self, 'media_type', ''), page=getattr(self, 'page', 0), lifetime_ms=int(max(0.0, (time.monotonic() - float(getattr(self, '_ui_diag_open_mono', time.monotonic()))) * 1000.0)))
        except Exception as exc:
            diagnostic_failure('ui.grid.failsoft.161', exc)

    def _grid_layout_ready(self):
        try:
            _ui_diag('ui_layout', screen='grid', media_type=self.media_type, elapsed_ms=int((time.monotonic() - self._ui_diag_open_mono) * 1000.0))
        except Exception as exc:
            diagnostic_failure('ui.grid.failsoft.165', exc)
        self._grid_art_layout_ready()
        try:
            initial_selector = asset(self.selection_asset)
            self['selection'].instance.setPixmapFromFile(initial_selector)
            self['selection'].show()
            self._grid_selection_visual_path = initial_selector
            if self.media_type in ('vod', 'series'):
                self['selection_adaptive'].hide()
                self._grid_selection_adaptive_visual_path = ''
        except Exception as exc:
            optional_failure('ui', exc)
        if not getattr(self, 'disable_grid_clock', False):
            self._update_grid_clock()
        _mem34('grid_layout_ready', mode=self.__class__.__name__, media=str(self.media_type or ''))
        term = str(getattr(self, '_open_search_term', '') or '')
        if term:
            self._open_search_term = ''
            self._section_search_started = True
            self._folder_search_entered(term)
            return
        self.load_page(self._restore_page, self._restore_index)

    def _grid_hidden_release(self):
        if getattr(self, '_screen_closed', False) or getattr(self, '_grid_closed', False):
            return
        self._grid_images_suspended = True
        try:
            self._grid_cancel_queued_downloads()
        except Exception as exc:
            optional_failure('ui.grid_hide_cancel', exc)
        try:
            self._grid_focus_timer.stop()
        except Exception as exc:
            diagnostic_failure('ui.grid.failsoft.186', exc)
        try:
            self._detail_prefetch_timer.stop()
        except Exception as exc:
            diagnostic_failure('ui.grid.failsoft.188', exc)
        try:
            self._grid_idle_warm_timer.stop()
        except Exception as exc:
            diagnostic_failure('ui.grid.failsoft.190', exc)
        try:
            if hasattr(self, '_stop_visible_rating_retry_timer'):
                self._stop_visible_rating_retry_timer()
        except Exception:
            pass
        try:
            cancel = getattr(self, '_page_prefetch_cancel', None)
            if cancel is not None:
                cancel.set()
        except Exception as exc:
            diagnostic_failure('ui.grid.failsoft.194', exc)
        self._cancel_detached_page_prefetch_futures()
        for future in list(getattr(self, '_page_prefetch_futures', []) or []):
            try:
                future.cancel()
            except Exception as exc:
                diagnostic_failure('ui.grid.failsoft.197', exc)
        self._page_prefetch_futures = []

    def _grid_shown_resume(self):
        if not getattr(self, '_grid_images_suspended', False):
            return
        if getattr(self, '_screen_closed', False) or getattr(self, '_grid_closed', False):
            return
        if self.media_type in ('vod', 'series'):
            from .manual_identity import changed_since_paint
            if changed_since_paint(self):
                from .ui_manual_match import refresh_grid
                self._grid_images_suspended = False
                refresh_grid(self, True)
                return
        self._grid_images_suspended = False
        try:
            self._schedule_page_maintenance()
        except Exception as exc:
            optional_failure('ui.page_maintenance_resume', exc)
        try:
            self._grid_art_layout_ready()
        except Exception as exc:
            optional_failure('ui.grid_resume_layout', exc)
        if not getattr(self, 'grid_items', None):
            return
        try:
            self._update_selection()
        except Exception as exc:
            optional_failure('ui.grid_resume_selection', exc)
        try:
            if self.media_type in ('vod', 'series'):
                self._grid_apply_current_selector()
                cancel = getattr(self, '_page_prefetch_cancel', None)
                if cancel is None or cancel.is_set():
                    self._page_prefetch_cancel = threading.Event()
                try:
                    self._start_progressive_poster_prefetch()
                except Exception:
                    pass
                try:
                    self._schedule_visible_rating_sweeps()
                except Exception:
                    pass
            elif self.media_type == 'itv' and hasattr(self, '_force_live_visual_rebind'):
                self._force_live_visual_rebind()
        except Exception as exc:
            optional_failure('ui.grid_resume_rebind', exc)

    def _cancel_detached_page_prefetch_futures(self):
        """Cancel futures submitted by the detached HDD discovery worker."""
        q = getattr(self, '_page_prefetch_future_jobs', None)
        if q is None:
            return
        while True:
            try:
                _generation, _key, future = q.get_nowait()
            except queue.Empty:
                break
            except Exception:
                break
            try:
                future.cancel()
            except Exception:
                pass

    def _adopt_detached_page_prefetch_futures(self, limit=16):
        q = getattr(self, '_page_prefetch_future_jobs', None)
        if q is None:
            return
        current = int(getattr(self, '_page_prefetch_generation', 0) or 0)
        for _ in range(max(1, int(limit or 1))):
            try:
                generation, key, future = q.get_nowait()
            except queue.Empty:
                break
            except Exception:
                break
            if generation != current or getattr(self, '_screen_closed', False):
                try:
                    future.cancel()
                except Exception:
                    pass
                continue
            if future.done():
                try:
                    future.result()
                except Exception:
                    try:
                        with self._page_prefetch_lock:
                            self._page_prefetch_seen.discard(key)
                    except Exception:
                        pass
                continue
            self._page_prefetch_futures.append(future)

    def _drain_visible_poster_results(self, limit=1):
        if getattr(self, '_screen_closed', False) or getattr(self, '_grid_images_suspended', False):
            return
        self._adopt_detached_page_prefetch_futures()
        applied = 0
        meta_applied = 0
        max_posters = max(4, int(limit or 4))
        retry_positions = []
        for _job_no in range(64):
            if applied >= max_posters or meta_applied >= 32:
                break
            try:
                _ajob = self._art_prefetch_jobs.get_nowait()
                if len(_ajob) >= 4:
                    agen, akey, apath, ameta = (_ajob[0], _ajob[1], _ajob[2], _ajob[3])
                else:
                    agen, akey, apath = _ajob
                    ameta = None
            except queue.Empty:
                break
            except (TypeError, ValueError, IndexError):
                continue
            if agen != int(getattr(self, '_page_prefetch_generation', 0) or 0):
                continue
            matched_positions = []
            for pos, item in enumerate(self.grid_items[:self.page_size]):
                ikey = ''
                try:
                    ikey = self._page_visual_key(item)
                except Exception:
                    ikey = ''
                if not ikey:
                    try:
                        from .persistent_cache import content_cache_key
                        ikey = content_cache_key(self.profile, self.media_type, item)
                    except Exception:
                        ikey = ''
                if ikey and ikey == akey:
                    known = item.get('_locked_tmdb_id') or item.get('_ultra_search_verified_tmdb_id')
                    incoming = ameta.get('tmdb_id') if isinstance(ameta, dict) else None
                    if known and incoming and (str(known) != str(incoming)):
                        continue
                    matched_positions.append(pos)
            matched_pos = matched_positions[0] if matched_positions else None
            if apath == '__RETRY__':
                try:
                    with self._page_prefetch_lock:
                        self._page_prefetch_seen.discard(akey)
                        count = int(self._page_art_retry_count.get(akey, 0) or 0)
                        if count < 1 and matched_pos is not None:
                            self._page_art_retry_count[akey] = count + 1
                            retry_positions.append(matched_pos)
                except Exception as exc:
                    optional_failure('ui.art_retry_state', exc)
                continue
            if matched_positions and isinstance(ameta, dict):
                for _mpos in matched_positions:
                    try:
                        target_item = self.grid_items[_mpos]
                        if ameta.get('tmdb_id') and (ameta.get('identity_verified') or ameta.get('identity_pointer_verified') or ameta.get('matched')):
                            target_item['_locked_tmdb_id'] = ameta.get('tmdb_id')
                            target_item['_ultra_search_verified_tmdb_id'] = ameta.get('tmdb_id')
                            target_item['_locked_tmdb_type'] = ameta.get('media_type') or ('tv' if self.media_type == 'series' else 'movie')
                            self._grid_item_state.setdefault(id(target_item), {})['tmdb_id'] = ameta.get('tmdb_id')
                        for key in ('number_of_seasons', 'seasons_count', 'season_count'):
                            if ameta.get(key) is not None:
                                target_item[key] = ameta[key]
                        try:
                            if self._folder_year_value(target_item) <= 0:
                                _tmdb_year = self._folder_year_value(ameta)
                                if _tmdb_year > 0:
                                    target_item['year'] = _tmdb_year
                        except Exception as exc:
                            optional_failure('ui.grid_tmdb_year_apply', exc)
                        try:
                            _tmdb_score = float(ameta.get('rating') or ameta.get('vote_average') or 0)
                        except Exception:
                            _tmdb_score = 0.0
                        if 0.0 < _tmdb_score <= 10.0:
                            target_item['_tmdb_rating'] = _tmdb_score
                            try:
                                _rk = self._page_visual_key(target_item)
                                if _rk:
                                    self._visible_tmdb_rating_cache[_rk] = _tmdb_score
                            except Exception:
                                pass
                        _raw_age = str(ameta.get('certification') or ameta.get('age_rating') or '').strip()
                        _raw_age_display = display_certification(_raw_age)
                        _age_checked = bool(_raw_age_display or (not _raw_age and ameta.get('_age_rating_checked')))
                        if _age_checked:
                            target_item['_age_rating_checked'] = True
                            if _raw_age:
                                target_item['certification'] = _raw_age
                                target_item['age_rating'] = _raw_age
                            else:
                                target_item.pop('certification', None)
                                target_item.pop('age_rating', None)
                            self._age_cache_put(target_item, _raw_age, True)
                        elif _raw_age:
                            target_item['certification'] = _raw_age
                            target_item['age_rating'] = _raw_age
                            target_item.pop('_age_rating_checked', None)
                        try:
                            _bd_local = str(ameta.get('backdrop_local') or '')
                            if _bd_local and os.path.isfile(_bd_local) and (os.path.getsize(_bd_local) > 1024):
                                target_item['_backdrop_source_local'] = _bd_local
                                self._page_visual_put(target_item, backdrop=_bd_local)
                        except Exception as exc:
                            optional_failure('ui.grid_backdrop_ram_publish', exc)
                        try:
                            from .ui_grid_v2_premium import merge_badge_metadata
                            merge_badge_metadata(self, target_item, ameta)
                        except Exception:
                            pass
                        try:
                            self._card_rating_layout(target_item, _mpos, self._card_meta(target_item, _mpos))
                        except Exception as exc:
                            optional_failure('ui.grid_tmdb_meta_apply_layout', exc)
                        meta_applied += 1
                        hook = getattr(self, '_on_visible_badges_ready', None)
                        if callable(hook):
                            hook(target_item, _mpos)
                    except Exception as exc:
                        optional_failure('ui.grid_tmdb_meta_apply', exc)
            if not apath or not os.path.isfile(str(apath)):
                continue
            for matched_pos in matched_positions:
                try:
                    target_item = self.grid_items[matched_pos]
                    palette_source = str((ameta or {}).get('palette_source') or '') if isinstance(ameta, dict) else ''
                    if palette_source and os.path.isfile(palette_source):
                        self._grid_palette_sources[matched_pos] = palette_source
                    if not hasattr(self, '_grid_canonical_poster_slots'):
                        self._grid_canonical_poster_slots = {}
                    shared = ''
                    try:
                        shared = self._shared_tmdb_poster(target_item)
                    except Exception:
                        shared = ''
                    if shared:
                        apath = shared
                    existing_slot_path = str((getattr(self, '_grid_slot_paths', {}) or {}).get(matched_pos) or '')
                    already_real = bool(existing_slot_path and os.path.isfile(existing_slot_path) and (not ('placeholder' in os.path.basename(existing_slot_path).lower() or os.path.basename(existing_slot_path).lower().startswith(('poster_movie', 'poster_series')))))
                    self._grid_canonical_poster_slots[matched_pos] = str(apath)
                    self._grid_queue_decode(self._grid_generation, matched_pos, str(apath))
                    self._remember_grid_visual(matched_pos, display=str(apath), poster=palette_source or str(apath), palette=palette_source or str(apath), provider_locked=bool(isinstance(ameta, dict) and ameta.get('provider_locked')))
                    try:
                        self._card_rating_layout(target_item, matched_pos, self._card_meta(target_item, matched_pos))
                    except Exception:
                        pass
                    if not already_real:
                        applied += 1
                except Exception as exc:
                    optional_failure('ui.art_prefetch_apply', exc)
        for retry_pos in retry_positions[:1]:
            try:
                self._prefetch_visible_page_details(priority_index=retry_pos, max_items=1)
            except Exception as exc:
                optional_failure('ui.art_retry_submit', exc)
        return applied

    def _drain_jobs(self):
        if not self._screen_closed and (getattr(self, '_folder_artwork_cache_running', False) or (getattr(self, '_folder_artwork_progress', None) is not None and not self._folder_artwork_progress.empty())):
            try:
                self._drain_folder_artwork_progress()
            except Exception as exc:
                optional_failure('ui.blue_progress_fast_drain', exc)
        us_func(AsyncScreenMixin._drain_jobs)(self)
        if time.monotonic() < float(getattr(self, '_nav_burst_until', 0.0) or 0.0):
            return
        if not self._screen_closed and self.media_type in ('vod', 'series'):
            try:
                self._drain_visible_poster_results(12)
                self._grid_drain_art_jobs(limit=12)
            except Exception as exc:
                optional_failure('ui.poster_micro_drain', exc)
        if not self._screen_closed:
            self._grid_drain_art_jobs()
            self._grid_drain_adaptive_selector()
            self._grid_drain_page_mood()
            self._drain_grid_epg()
            self._drain_folder_artwork_progress()
            self._drain_poster_live_hud()
            while True:
                try:
                    qgen, qkey, qvalue = self._quality_prefetch_jobs.get_nowait()
                except queue.Empty:
                    break
                if qgen != int(getattr(self, '_page_prefetch_generation', 0) or 0):
                    continue
                for pos, item in enumerate(self.grid_items[:self.page_size]):
                    try:
                        from .persistent_cache import content_cache_key
                        ikey = content_cache_key(self.profile, self.media_type, item)
                    except Exception:
                        ikey = ''
                    if ikey == qkey:
                        self._grid_item_state.setdefault(id(item), {})['quality'] = qvalue
                        try:
                            self['item_meta%d' % pos].setText(self._card_meta(item, pos))
                        except Exception as exc:
                            optional_failure('ui.silent_guard', exc)
                        if pos == self.index:
                            self._update_header(item)
                        break
            self._drain_visible_poster_results(8)
            pending = getattr(self, '_pending_page_request', None)
            if pending and (not self._busy):
                self._pending_page_request = None
                self.load_page(pending[0], pending[1])

    def _remember_grid_state(self):
        self._restore_page = max(1, int(self.page or 1))
        self._restore_index = max(0, int(self.index or 0))
        if not getattr(self, '_view_active', False):
            try:
                _state = dict(_GRID_NAV_STATE.get(self._session_nav_key, {}) or {})
                _state.update({'page': self._restore_page, 'index': self._restore_index})
                _GRID_NAV_STATE[self._session_nav_key] = _state
            except Exception as exc:
                optional_failure('ui.grid_state', exc)
        return (self._restore_page, self._restore_index)
