# -*- coding: utf-8 -*-
"""
Ultra Stalker - runtime environment layer.

The plugin is one source tree that runs on:

  * Python 3 images (OE-Alliance, DreamOS OE2.6+)
  * Python 2.7 images (DreamOS OE2.5)

Every difference between the two interpreters is kept in this file.  Other
modules import the neutral names defined here (``str``, ``open``, ``os``,
``urllib``, ``queue`` ...) instead of the version specific ones.

On Python 3 every exported name is the plain builtin or standard library
object, so importing it changes nothing.  On Python 2.7 the names are thin
adapters that give the Python 3 behaviour the plugin was written against:
text is ``unicode`` everywhere inside the plugin and is converted to UTF-8
bytes only where it crosses into the C++ Enigma2 core.
"""
from __future__ import absolute_import, division, print_function

import binascii as _binascii
import errno as _errno
import io as _io
import itertools as _itertools
import math as _math
import os as _os
import socket as _socket
import sys as _sys
import threading as _threading
import time as _time

PY2 = _sys.version_info[0] == 2
PY3 = not PY2
PYVER = tuple(_sys.version_info[:2])


# ==========================================================================
# Image detection
# ==========================================================================
def _read_small(path):
    try:
        with _io.open(path, "rb") as handle:
            return handle.read(512).decode("utf-8", "replace").lower()
    except Exception:
        return ""


def _detect_dreamos():
    """DreamOS images are dpkg/apt based.  Some of them (Gemini, Merlin ...)
    also ship opkg, so opkg alone does not mean OE-Alliance."""
    try:
        if not _os.path.exists("/var/lib/dpkg/status"):
            return False
        if _os.path.exists("/usr/bin/apt-get"):
            return True
        issue = _read_small("/etc/issue") + _read_small("/etc/issue.net")
        return "opendreambox" in issue or "dreambox" in issue
    except Exception:
        return False


IS_DREAMOS = _detect_dreamos()
IS_OEA = not IS_DREAMOS
PACKAGE_MANAGER = "dpkg" if IS_DREAMOS else "opkg"


class _NS(object):
    """Attribute namespace standing in for a package (``urllib``, ``http``)."""

    def __init__(self, **items):
        self.__dict__.update(items)


class _ModuleProxy(object):
    """Module stand-in: local overrides first, everything else from ``base``."""

    def __init__(self, base, **overrides):
        object.__setattr__(self, "_us_base", base)
        self.__dict__.update(overrides)

    def __getattr__(self, name):
        return getattr(self._us_base, name)

    def __setattr__(self, name, value):
        # e.g. tests or code that sets socket.setdefaulttimeout style globals
        setattr(self._us_base, name, value)

    def __repr__(self):
        return "<us_env proxy for %r>" % (self._us_base,)


def _any_needs(values, predicate):
    for value in values:
        if predicate(value):
            return True
    return False


# ==========================================================================
# Regex helper for narrow (UCS-2) Python 2 builds
# ==========================================================================
_uchr = getattr(__import__("builtins" if PY3 else "__builtin__"), "unichr", chr)


def _is_high(ch):
    return u"\ud800" <= ch <= u"\udbff"


def _is_low(ch):
    return u"\udc00" <= ch <= u"\udfff"


def _surrogate_alternatives(lo, hi):
    def pair(cp):
        cp -= 0x10000
        return 0xD800 + (cp >> 10), 0xDC00 + (cp & 0x3FF)

    hl, ll = pair(lo)
    hh, lh = pair(hi)
    if hl == hh:
        return [_uchr(hl) + u"[" + _uchr(ll) + u"-" + _uchr(lh) + u"]"]
    alts = [_uchr(hl) + u"[" + _uchr(ll) + u"-\udfff]"]
    if hh - hl > 1:
        alts.append(u"[" + _uchr(hl + 1) + u"-" + _uchr(hh - 1) + u"][\udc00-\udfff]")
    alts.append(_uchr(hh) + u"[\udc00-" + _uchr(lh) + u"]")
    return alts


def _convert_char_class(p, start):
    """Rewrite one [...] class holding supplementary-plane characters (stored
    as surrogate pairs on UCS-2 builds) into an equivalent alternation."""
    i = start + 1
    negated = False
    if i < len(p) and p[i] == u"^":
        negated = True
        i += 1
    items = []
    first = True
    while i < len(p):
        c = p[i]
        if c == u"]" and not first:
            break
        first = False
        if c == u"\\" and i + 1 < len(p):
            items.append(("raw", p[i:i + 2]))
            i += 2
            continue
        if _is_high(c) and i + 1 < len(p) and _is_low(p[i + 1]):
            cp = 0x10000 + ((ord(c) - 0xD800) << 10) + (ord(p[i + 1]) - 0xDC00)
            items.append(("cp", cp))
            i += 2
            continue
        if c == u"-":
            items.append(("dash", c))
        else:
            items.append(("ch", c))
        i += 1
    if i >= len(p):
        return len(p), p[start:]
    end = i + 1
    bmp = []
    astral = []
    k = 0
    while k < len(items):
        kind, val = items[k]
        if (k + 2 < len(items) and items[k + 1][0] == "dash" and kind in ("ch", "cp")
                and items[k + 2][0] in ("ch", "cp")):
            hkind, hval = items[k + 2]
            lo = ord(val) if kind == "ch" else val
            hi = ord(hval) if hkind == "ch" else hval
            if hi > 0xFFFF:
                if lo <= 0xFFFF:
                    bmp.append(_uchr(lo) + u"-\uffff")
                    lo = 0x10000
                astral.append((lo, hi))
            else:
                bmp.append(val + u"-" + hval)
            k += 3
            continue
        if kind == "cp":
            astral.append((val, val))
        else:
            bmp.append(val)
        k += 1
    if not astral:
        return end, p[start:end]
    if negated:
        # approximation: keep the BMP part of a negated class
        return end, u"[^" + (u"".join(bmp) or u"\\x00") + u"]"
    parts = []
    if bmp:
        parts.append(u"[" + u"".join(bmp) + u"]")
    for lo, hi in astral:
        parts.extend(_surrogate_alternatives(lo, hi))
    return end, u"(?:" + u"|".join(parts) + u")"


def astral_classes_to_surrogates(pattern):
    """Make character classes with emoji ranges compile on UCS-2 Python 2
    (otherwise: "bad character range")."""
    if not any(_is_high(c) for c in pattern):
        return pattern
    out = []
    i = 0
    n = len(pattern)
    while i < n:
        c = pattern[i]
        if c == u"\\":
            out.append(pattern[i:i + 2])
            i += 2
            continue
        if c == u"[":
            i, converted = _convert_char_class(pattern, i)
            out.append(converted)
            continue
        out.append(c)
        i += 1
    return u"".join(out)


# ==========================================================================
# Python 3
# ==========================================================================
if PY3:
    import base64
    import builtins as _bi
    import collections
    import concurrent.futures as concurrent_futures
    import hashlib
    import hmac
    import inspect
    import socket
    import ssl
    try:
        import sqlite3
    except ImportError:  # pragma: no cover - reported by the preflight
        sqlite3 = None
    import html
    import http.client as http_client
    import http.cookiejar as http_cookiejar
    import http.cookies as http_cookies
    import http.server as http_server
    import ipaddress
    import json
    import queue
    import re
    import secrets
    import shutil
    import threading
    import time
    import traceback
    import urllib.error as urllib_error
    import urllib.parse as urllib_parse
    import urllib.request as urllib_request

    os = _os

    str = _bi.str
    bytes = _bi.bytes
    int = _bi.int
    open = _bi.open
    round = _bi.round
    zip = _bi.zip
    map = _bi.map
    filter = _bi.filter
    chr = _bi.chr
    max = _bi.max
    min = _bi.min
    list = _bi.list
    object = _bi.object
    range = _bi.range
    OSError = _bi.OSError
    IOError = _bi.OSError
    TimeoutError = _bi.TimeoutError
    FileNotFoundError = _bi.FileNotFoundError
    FileExistsError = _bi.FileExistsError
    PermissionError = _bi.PermissionError
    ConnectionError = _bi.ConnectionError
    ConnectionRefusedError = _bi.ConnectionRefusedError
    ConnectionResetError = _bi.ConnectionResetError
    BrokenPipeError = _bi.BrokenPipeError
    InterruptedError = _bi.InterruptedError
    ProcessLookupError = _bi.ProcessLookupError
    RecursionError = _bi.RecursionError

    text_type = _bi.str
    binary_type = _bi.bytes
    string_types = (_bi.str,)
    native_str = _bi.str

    def casefold(value):
        return value.casefold()

    def int_from_bytes(data, byteorder, signed=False):
        return _bi.int.from_bytes(data, byteorder, signed=signed)

    def int_to_bytes(value, length, byteorder, signed=False):
        return value.to_bytes(length, byteorder, signed=signed)

    def bytes_hex(data):
        return data.hex()

    def native_text(value):
        """Text in the form the Enigma2 core / stock screens expect."""
        if isinstance(value, _bi.bytes):
            return value.decode("utf-8", "replace")
        return value

    def install_enigma_bridge():
        return True


# ==========================================================================
# Python 2.7
# ==========================================================================
else:  # pragma: no cover - exercised only on Python 2 receivers
    import __builtin__ as _bi
    import BaseHTTPServer as _bhs
    import Cookie as http_cookies
    import HTMLParser as _htmlparser
    import Queue as queue
    import SocketServer as _socketserver
    import cookielib as http_cookiejar
    import hmac as _hmac
    import httplib as _httplib
    import json as _json
    import mimetools as _mimetools
    import random as _random
    import re as _re
    import shutil as _shutil
    import thread as _thread
    import traceback as _traceback
    import types as _types
    import urllib as _urllib
    import urllib2 as _urllib2
    import urlparse as _urlparse

    _unicode = _bi.unicode
    _bstr = _bi.str
    _long = _bi.long

    text_type = _unicode
    binary_type = _bstr
    string_types = (_bi.basestring,)
    native_str = _bstr

    # ----------------------------------------------------------------------
    # text helpers
    # ----------------------------------------------------------------------
    def _to_text(value, encoding="utf-8", errors="replace"):
        if isinstance(value, _unicode):
            return value
        if isinstance(value, _bstr):
            return value.decode(encoding, errors)
        if isinstance(value, (bytearray, memoryview)):
            return _bstr(value).decode(encoding, errors) if isinstance(value, bytearray) else value.tobytes().decode(encoding, errors)
        try:
            return _unicode(value)
        except UnicodeError:
            try:
                return _bstr(value).decode("utf-8", "replace")
            except Exception:
                return repr(value).decode("ascii", "replace")

    def _to_bytes(value, encoding="utf-8", errors="strict"):
        if isinstance(value, _unicode):
            return value.encode(encoding, errors)
        return value

    def native_text(value):
        """UTF-8 bytes: the text form stock Python 2 Enigma2 screens expect."""
        if isinstance(value, _unicode):
            return value.encode("utf-8")
        return value

    # ----------------------------------------------------------------------
    # file system encoding
    # ----------------------------------------------------------------------
    _FS_STATE = {"before": None, "after": None, "ref": None}

    def _ensure_utf8_filesystem_encoding():
        """Enigma2 starts Python 2 in the C locale, so unicode paths are
        encoded as ASCII and Arabic file names fail.  Receivers store names
        as UTF-8; point Python 2's (process global) file system codec at it."""
        current = _sys.getfilesystemencoding()
        _FS_STATE["before"] = current
        if current and current.lower().replace("-", "").replace("_", "") in ("utf8",):
            _FS_STATE["after"] = current
            return
        try:
            import ctypes
            value = ctypes.c_char_p(b"utf-8")
            target = ctypes.c_char_p.in_dll(ctypes.pythonapi, "Py_FileSystemDefaultEncoding")
            target.value = value.value
            _FS_STATE["ref"] = (value, target)  # keep the buffer alive
        except Exception:
            pass
        _FS_STATE["after"] = _sys.getfilesystemencoding()

    try:
        _ensure_utf8_filesystem_encoding()
    except Exception:
        pass

    # ----------------------------------------------------------------------
    # builtins: str / bytes / int
    # ----------------------------------------------------------------------
    class _TextMeta(type):
        def __instancecheck__(cls, obj):
            if cls is _TEXT:
                return isinstance(obj, _unicode)
            return type.__instancecheck__(cls, obj)

        def __subclasscheck__(cls, sub):
            if cls is _TEXT:
                return issubclass(sub, _unicode)
            return type.__subclasscheck__(cls, sub)

    def _text_new(cls, obj=u"", encoding=None, errors=None):
        if encoding is not None or errors is not None:
            if isinstance(obj, _unicode):
                raise TypeError("decoding str is not supported")
            if isinstance(obj, memoryview):
                obj = obj.tobytes()
            value = _bstr(obj).decode(encoding or "utf-8", errors or "strict")
        else:
            value = _to_text(obj)
        if cls is _TEXT:
            return value
        return _unicode.__new__(cls, value)

    def _text_maketrans(x, y=None, z=None):
        table = {}
        if y is None:
            for key, val in x.items():
                if isinstance(key, _bi.basestring):
                    key = ord(key)
                table[key] = val
            return table
        for a, b in _bi.zip(x, y):
            table[ord(a)] = ord(b)
        for c in (z or u""):
            table[ord(c)] = None
        return table

    _TEXT = _TextMeta("str", (_unicode,), {
        "__new__": _text_new,
        "__module__": __name__,
        "maketrans": staticmethod(_text_maketrans),
    })

    class _BytesMeta(type):
        def __instancecheck__(cls, obj):
            if cls is _BYTES:
                return isinstance(obj, _bstr)
            return type.__instancecheck__(cls, obj)

        def __subclasscheck__(cls, sub):
            if cls is _BYTES:
                return issubclass(sub, _bstr)
            return type.__subclasscheck__(cls, sub)

    def _bytes_new(cls, obj=b"", encoding=None, errors="strict"):
        if isinstance(obj, _unicode):
            if encoding is None:
                raise TypeError("string argument without an encoding")
            return obj.encode(encoding, errors)
        if isinstance(obj, (_bi.int, _long)) and not isinstance(obj, bool):
            if obj < 0:
                raise ValueError("negative count")
            return b"\x00" * obj
        if isinstance(obj, _bstr):
            return obj
        if isinstance(obj, bytearray):
            return _bstr(obj)
        if isinstance(obj, memoryview):
            return obj.tobytes()
        if isinstance(obj, _bi.buffer):
            return _bstr(obj)
        return _bstr(bytearray(obj))

    def _bytes_fromhex(text):
        text = u"".join(_to_text(text).split())
        return _binascii.unhexlify(text.encode("ascii"))

    _BYTES = _BytesMeta("bytes", (_bstr,), {
        "__new__": _bytes_new,
        "__module__": __name__,
        "fromhex": staticmethod(_bytes_fromhex),
    })

    class _IntMeta(type):
        def __instancecheck__(cls, obj):
            if cls is _INT:
                return isinstance(obj, (_bi.int, _long))
            return type.__instancecheck__(cls, obj)

        def __subclasscheck__(cls, sub):
            if cls is _INT:
                return issubclass(sub, (_bi.int, _long))
            return type.__subclasscheck__(cls, sub)

    def _int_new(cls, *args, **kwargs):
        if args and isinstance(args[0], _bstr) and len(args) == 1 and not kwargs:
            value = _bi.int(args[0].strip())
        else:
            value = _bi.int(*args, **kwargs)
        if cls is _INT:
            return value
        return _bi.int.__new__(cls, value)

    def int_from_bytes(data, byteorder, signed=False):
        raw = bytearray(_bytes_new(_BYTES, data) if not isinstance(data, (_bstr, bytearray)) else data)
        if byteorder == "little":
            raw.reverse()
        elif byteorder != "big":
            raise ValueError("byteorder must be either 'little' or 'big'")
        value = _long(_binascii.hexlify(_bstr(raw)), 16) if raw else 0
        if signed and raw and raw[0] & 0x80:
            value -= 1 << (8 * len(raw))
        return _bi.int(value)

    def int_to_bytes(value, length, byteorder, signed=False):
        if value < 0:
            if not signed:
                raise OverflowError("can't convert negative int to unsigned")
            value += 1 << (8 * length)
        if value < 0 or value >= (1 << (8 * length)):
            raise OverflowError("int too big to convert")
        text = "%x" % value
        text = ("0" * (2 * length - len(text))) + text
        raw = bytearray(_binascii.unhexlify(text)) if length else bytearray()
        if byteorder == "little":
            raw.reverse()
        elif byteorder != "big":
            raise ValueError("byteorder must be either 'little' or 'big'")
        return _bstr(raw)

    def _int_from_bytes_cm(cls, data, byteorder, signed=False):
        return int_from_bytes(data, byteorder, signed)

    _INT = _IntMeta("int", (_bi.int,), {
        "__new__": _int_new,
        "__module__": __name__,
        "from_bytes": classmethod(_int_from_bytes_cm),
    })

    str = _TEXT
    bytes = _BYTES
    int = _INT
    list = _bi.list
    object = _bi.object
    range = getattr(_bi, 'xrange', _bi.range)

    def bytes_hex(data):
        if isinstance(data, memoryview):
            data = data.tobytes()
        return _binascii.hexlify(_bstr(data)).decode("ascii")

    def casefold(value):
        return value.lower()

    # ----------------------------------------------------------------------
    # builtins: open / round / iterators / chr / max / min
    # ----------------------------------------------------------------------
    def open(file, mode="r", buffering=-1, encoding=None, errors=None, newline=None, closefd=True):
        if "b" not in mode and encoding is None:
            encoding = "utf-8"
        return _io.open(file, mode, buffering, encoding, errors, newline, closefd)

    def round(number, ndigits=None):
        if ndigits is not None:
            return _bi.round(number, ndigits)
        floor = _math.floor(number)
        diff = number - floor
        if diff > 0.5:
            result = floor + 1
        elif diff < 0.5:
            result = floor
        else:
            result = floor if floor % 2 == 0 else floor + 1
        return _bi.int(result)

    zip = _itertools.izip
    map = _itertools.imap
    filter = _itertools.ifilter
    chr = _bi.unichr

    _MISSING = object()

    def _minmax(builtin, args, kwargs):
        default = kwargs.pop("default", _MISSING)
        if default is _MISSING:
            return builtin(*args, **kwargs)
        if len(args) != 1:
            raise TypeError("default is only allowed with a single iterable argument")
        items = list(args[0])
        if not items:
            return default
        return builtin(items, **kwargs)

    def max(*args, **kwargs):
        return _minmax(_bi.max, args, kwargs)

    def min(*args, **kwargs):
        return _minmax(_bi.min, args, kwargs)

    # ----------------------------------------------------------------------
    # exceptions
    # ----------------------------------------------------------------------
    # IOError and OSError are separate on Python 2; EnvironmentError is the
    # common base, which is what "except OSError" means on Python 3.
    OSError = _bi.EnvironmentError
    IOError = _bi.EnvironmentError

    class _ErrnoMeta(type):
        """Exception class that matches EnvironmentError by errno, the way
        the Python 3 OSError subclasses do."""

        def __instancecheck__(cls, obj):
            if isinstance(obj, cls._us_extra):
                return True
            return isinstance(obj, _bi.EnvironmentError) and getattr(obj, "errno", None) in cls._us_errnos

        def __subclasscheck__(cls, sub):
            # "except FileNotFoundError" only sees the class, so it has to
            # accept the whole EnvironmentError family; handlers that care
            # re-check the errno through isinstance().
            try:
                if issubclass(sub, cls._us_extra):
                    return True
            except TypeError:
                return False
            return type.__subclasscheck__(cls, sub) or (cls._us_catch_env and issubclass(sub, _bi.EnvironmentError))

    def _errno_exc(name, errnos, extra=(), catch_env=True):
        return _ErrnoMeta(name, (_bi.EnvironmentError,), {
            "_us_errnos": frozenset(e for e in errnos if e is not None),
            "_us_extra": tuple(extra) or (_ErrnoPlaceholder,),
            "_us_catch_env": catch_env,
            "__module__": __name__,
        })

    class _ErrnoPlaceholder(Exception):
        pass

    TimeoutError = _socket.timeout
    FileNotFoundError = _errno_exc("FileNotFoundError", (_errno.ENOENT,))
    FileExistsError = _errno_exc("FileExistsError", (_errno.EEXIST,))
    PermissionError = _errno_exc("PermissionError", (_errno.EACCES, _errno.EPERM))
    ConnectionRefusedError = _errno_exc("ConnectionRefusedError", (_errno.ECONNREFUSED,))
    ConnectionResetError = _errno_exc("ConnectionResetError", (_errno.ECONNRESET,))
    BrokenPipeError = _errno_exc("BrokenPipeError", (_errno.EPIPE, getattr(_errno, "ESHUTDOWN", None)))
    ConnectionError = _errno_exc("ConnectionError", (
        _errno.ECONNREFUSED, _errno.ECONNRESET, _errno.ECONNABORTED, _errno.EPIPE,
        getattr(_errno, "ESHUTDOWN", None)))
    ProcessLookupError = _errno_exc("ProcessLookupError", (_errno.ESRCH,))

    class InterruptedError(_bi.EnvironmentError):
        """Python 3 builtin; the plugin raises it for cancelled work."""

    RecursionError = RuntimeError

    # ----------------------------------------------------------------------
    # os / os.path
    # ----------------------------------------------------------------------
    def _makedirs(name, mode=0o777, exist_ok=False):
        try:
            _os.makedirs(name, mode)
        except _bi.EnvironmentError as exc:
            if not (exist_ok and exc.errno == _errno.EEXIST and _os.path.isdir(name)):
                raise

    class _DirEntry(object):
        __slots__ = ("name", "path", "_lstat", "_stat")

        def __init__(self, directory, name):
            self.name = name
            self.path = _os.path.join(directory, name)
            self._lstat = None
            self._stat = None

        def _get_lstat(self):
            if self._lstat is None:
                self._lstat = _os.lstat(self.path)
            return self._lstat

        def stat(self, follow_symlinks=True):
            if not follow_symlinks:
                return self._get_lstat()
            if self._stat is None:
                self._stat = _os.stat(self.path)
            return self._stat

        def is_symlink(self):
            try:
                import stat as _st
                return _st.S_ISLNK(self._get_lstat().st_mode)
            except _bi.EnvironmentError:
                return False

        def is_dir(self, follow_symlinks=True):
            try:
                import stat as _st
                return _st.S_ISDIR(self.stat(follow_symlinks).st_mode)
            except _bi.EnvironmentError:
                return False

        def is_file(self, follow_symlinks=True):
            try:
                import stat as _st
                return _st.S_ISREG(self.stat(follow_symlinks).st_mode)
            except _bi.EnvironmentError:
                return False

        def inode(self):
            return self._get_lstat().st_ino

        def __repr__(self):
            return "<DirEntry %r>" % (self.name,)

    class _ScandirIterator(object):
        def __init__(self, path):
            self._path = path
            self._names = iter(_os.listdir(path))

        def __iter__(self):
            return self

        def next(self):
            return _DirEntry(self._path, next(self._names))

        __next__ = next

        def close(self):
            self._names = iter(())

        def __enter__(self):
            return self

        def __exit__(self, *exc):
            self.close()
            return False

    def _scandir(path=u"."):
        return _ScandirIterator(path)

    def _commonpath(paths):
        paths = list(paths)
        if not paths:
            raise ValueError("commonpath() arg is an empty sequence")
        absolute = set(p.startswith("/") for p in paths)
        if len(absolute) > 1:
            raise ValueError("Can't mix absolute and relative paths")
        split = [[c for c in p.split("/") if c and c != "."] for p in paths]
        prefix = []
        for parts in _bi.zip(*split):
            if all(part == parts[0] for part in parts):
                prefix.append(parts[0])
            else:
                break
        joined = "/".join(prefix)
        return ("/" + joined) if absolute.pop() else joined

    def _cpu_count():
        try:
            import multiprocessing
            return multiprocessing.cpu_count()
        except Exception:
            return None

    def _fsencode(name):
        return _to_bytes(name, _sys.getfilesystemencoding() or "utf-8")

    def _fsdecode(name):
        return _to_text(name, _sys.getfilesystemencoding() or "utf-8")

    def _text_path_result(func):
        def call(path, *args):
            result = func(path, *args)
            if isinstance(path, _unicode) and isinstance(result, _bstr):
                result = result.decode(_sys.getfilesystemencoding() or "utf-8", "replace")
            return result
        call.__name__ = func.__name__
        return call

    _os_path = _ModuleProxy(
        _os.path,
        commonpath=_commonpath,
        realpath=_text_path_result(_os.path.realpath),
        abspath=_text_path_result(_os.path.abspath),
    )

    os = _ModuleProxy(
        _os,
        path=_os_path,
        makedirs=_makedirs,
        replace=_os.rename,  # rename() replaces atomically on POSIX
        getcwd=_os.getcwdu,
        getcwdb=_os.getcwd,
        scandir=_scandir,
        cpu_count=_cpu_count,
        fsencode=_fsencode,
        fsdecode=_fsdecode,
        fdopen=lambda fd, mode="r", buffering=-1, encoding=None, errors=None, newline=None, closefd=True: open(fd, mode, buffering, encoding, errors, newline, closefd),
    )

    # ----------------------------------------------------------------------
    # time
    # ----------------------------------------------------------------------
    def _make_monotonic():
        try:
            import ctypes

            class _Timespec(ctypes.Structure):
                _fields_ = [("tv_sec", ctypes.c_long), ("tv_nsec", ctypes.c_long)]

            for libname in (None, "librt.so.1", "libc.so.6"):
                try:
                    lib = ctypes.CDLL(libname, use_errno=True)
                    fn = lib.clock_gettime
                except Exception:
                    continue
                fn.argtypes = [ctypes.c_int, ctypes.POINTER(_Timespec)]
                probe = _Timespec()
                if fn(1, ctypes.byref(probe)) != 0:  # CLOCK_MONOTONIC
                    continue

                def _monotonic(_fn=fn, _T=_Timespec, _byref=ctypes.byref):
                    ts = _T()
                    _fn(1, _byref(ts))
                    return ts.tv_sec + ts.tv_nsec * 1e-9

                return _monotonic
        except Exception:
            pass
        state = {"last": 0.0}
        lock = _threading.Lock()

        def _fallback():
            with lock:
                now = _time.time()
                if now < state["last"]:
                    now = state["last"]
                state["last"] = now
                return now

        return _fallback

    _monotonic = _make_monotonic()

    def _strftime(fmt, t=None):
        raw_fmt = _to_bytes(fmt, "utf-8", "replace")
        res = _time.strftime(raw_fmt) if t is None else _time.strftime(raw_fmt, t)
        return _to_text(res, "utf-8", "replace")

    def _strptime(string, fmt="%a %b %d %H:%M:%S %Y"):
        return _time.strptime(_to_bytes(string, "utf-8", "replace"), _to_bytes(fmt, "utf-8", "replace"))

    time = _ModuleProxy(
        _time,
        monotonic=_monotonic,
        perf_counter=_monotonic,
        process_time=_time.clock,
        time_ns=lambda: _bi.int(_time.time() * 1000000000),
        monotonic_ns=lambda: _bi.int(_monotonic() * 1000000000),
        strftime=_strftime,
        strptime=_strptime,
    )

    # ----------------------------------------------------------------------
    # shutil
    # ----------------------------------------------------------------------
    class _DiskUsage(tuple):
        __slots__ = ()

        def __new__(cls, total, used, free):
            return tuple.__new__(cls, (total, used, free))

        total = property(lambda self: self[0])
        used = property(lambda self: self[1])
        free = property(lambda self: self[2])

    def _disk_usage(path):
        st = _os.statvfs(path)
        free = st.f_bavail * st.f_frsize
        total = st.f_blocks * st.f_frsize
        used = (st.f_blocks - st.f_bfree) * st.f_frsize
        return _DiskUsage(total, used, free)

    def _which(cmd, mode=_os.F_OK | _os.X_OK, path=None):
        if _os.path.dirname(cmd):
            return cmd if (_os.path.exists(cmd) and _os.access(cmd, mode) and not _os.path.isdir(cmd)) else None
        path = path or _os.environ.get("PATH", _os.defpath)
        for directory in path.split(_os.pathsep):
            candidate = _os.path.join(directory, cmd)
            if _os.path.exists(candidate) and _os.access(candidate, mode) and not _os.path.isdir(candidate):
                return candidate
        return None

    shutil = _ModuleProxy(_shutil, disk_usage=_disk_usage, which=_which)

    # ----------------------------------------------------------------------
    # threading
    # ----------------------------------------------------------------------
    class _Thread(_threading.Thread):
        def __init__(self, group=None, target=None, name=None, args=(), kwargs=None, verbose=None, daemon=None):
            _threading.Thread.__init__(self, group=group, target=target, name=name, args=args, kwargs=kwargs or {})
            if daemon is not None:
                self.daemon = daemon

        def run(self):
            try:
                _threading.Thread.run(self)
            except BaseException:
                _report_thread_failure("uncaught in thread %s" % self.name, _sys.exc_info())
                raise

    def _timed_acquire(raw_acquire, blocking=True, timeout=-1):
        """acquire(blocking, timeout) on Python 2 primitives."""
        if not blocking or timeout is None or timeout < 0:
            return raw_acquire(bool(blocking))
        deadline = _time.time() + timeout
        delay = 0.0005
        while True:
            if raw_acquire(False):
                return True
            remaining = deadline - _time.time()
            if remaining <= 0:
                return False
            delay = min(delay * 2, remaining, 0.05)
            _time.sleep(delay)

    _SEM_EXTRA = {}
    if hasattr(_threading, "_Semaphore"):
        class _Semaphore(_threading._Semaphore):
            def acquire(self, blocking=True, timeout=None):
                return _timed_acquire(lambda b: _threading._Semaphore.acquire(self, b), blocking,
                                      -1 if timeout is None else timeout)
            __enter__ = acquire

        class _BoundedSemaphore(_Semaphore):
            def __init__(self, value=1):
                _Semaphore.__init__(self, value)
                self._initial_value = value

            def release(self):
                if self._Semaphore__value >= self._initial_value:
                    raise ValueError("Semaphore released too many times")
                return _Semaphore.release(self)

        _SEM_EXTRA = dict(Semaphore=_Semaphore, BoundedSemaphore=_BoundedSemaphore)

    threading = _ModuleProxy(
        _threading,
        Thread=_Thread,
        get_ident=_thread.get_ident,
        main_thread=lambda: next((t for t in _threading.enumerate() if isinstance(t, _threading._MainThread)), None),
        **_SEM_EXTRA
    )

    # ----------------------------------------------------------------------
    # json: always text in, text out
    # ----------------------------------------------------------------------
    def _json_dumps(obj, *args, **kwargs):
        value = _json.dumps(obj, *args, **kwargs)
        if isinstance(value, _bstr):
            value = value.decode("utf-8")
        return value

    def _json_dump(obj, fp, *args, **kwargs):
        text = _json_dumps(obj, *args, **kwargs)
        mode = getattr(fp, "mode", "") or ""
        if "b" in mode:
            fp.write(text.encode("utf-8"))
        else:
            try:
                fp.write(text)
            except TypeError:
                fp.write(text.encode("utf-8"))

    json = _ModuleProxy(_json, dumps=_json_dumps, dump=_json_dump, JSONDecodeError=ValueError)

    # ----------------------------------------------------------------------
    # re: Python 3 matches Unicode by default
    # ----------------------------------------------------------------------
    _RE_ASCII = 1 << 20  # sentinel bit, stripped before reaching sre

    def _re_flags(flags):
        flags = flags or 0
        if flags & _RE_ASCII:
            return flags & ~_RE_ASCII
        return flags | _re.UNICODE

    _NARROW_UNICODE = _sys.maxunicode < 0x10000

    try:
        _re._MAXCACHE = 4096
    except Exception:
        pass
    try:
        _sys.setcheckinterval(250)
    except Exception:
        pass

    _RAW_RE_PATTERN = type(_re.compile(""))
    _RE_MATCH = type(_re.match("", ""))
    _ORIG_STDLIB_RE_COMPILE = getattr(_re, "_compile", None)
    _RE_COMPILE_CACHE = {}
    _RE_FULLMATCH_CACHE = {}

    def _pattern_fullmatch(regex, string, pos=0, endpos=None):
        raw = getattr(regex, "_us_raw", regex)
        fkey = (raw.pattern, raw.flags)
        wrapped = _RE_FULLMATCH_CACHE.get(fkey)
        if wrapped is None:
            pat = raw.pattern if isinstance(raw.pattern, _unicode) else raw.pattern.decode("latin-1")
            wrapped = _re.compile(u"(?:%s)\\Z" % pat, raw.flags)
            if len(_RE_FULLMATCH_CACHE) > 2048:
                _RE_FULLMATCH_CACHE.clear()
            _RE_FULLMATCH_CACHE[fkey] = wrapped
        if endpos is None:
            return wrapped.match(string, pos)
        return wrapped.match(string, pos, endpos)

    class _RegexPatternProxy(object):
        __slots__ = ("_us_raw", "_us_fullmatch")
        def __init__(self, raw):
            object.__setattr__(self, "_us_raw", raw)
            object.__setattr__(self, "_us_fullmatch", None)
        def fullmatch(self, string, pos=0, endpos=None):
            fm = object.__getattribute__(self, "_us_fullmatch")
            if fm is None:
                raw = object.__getattribute__(self, "_us_raw")
                pat = raw.pattern if isinstance(raw.pattern, _unicode) else raw.pattern.decode("latin-1")
                fm = _re.compile(u"(?:%s)\\Z" % pat, raw.flags)
                object.__setattr__(self, "_us_fullmatch", fm)
            if endpos is None:
                return fm.match(string, pos)
            return fm.match(string, pos, endpos)
        def __getattr__(self, name):
            return getattr(object.__getattribute__(self, "_us_raw"), name)
        def __repr__(self):
            return repr(object.__getattribute__(self, "_us_raw"))
        def __eq__(self, other):
            return object.__getattribute__(self, "_us_raw") == getattr(other, "_us_raw", other)
        def __ne__(self, other):
            return not self.__eq__(other)
        def __hash__(self):
            return hash(object.__getattribute__(self, "_us_raw"))

    class _PatternMeta(type):
        def __instancecheck__(cls, obj):
            return isinstance(obj, (_RAW_RE_PATTERN, _RegexPatternProxy))

    _RE_PATTERN = _PatternMeta(native_str("Pattern"), (object,), {})

    if callable(_ORIG_STDLIB_RE_COMPILE) and not getattr(_ORIG_STDLIB_RE_COMPILE, "_us_unwrapped", False):
        def _stdlib_re_compile_wrapper(pattern, flags=0):
            if isinstance(pattern, _RegexPatternProxy):
                pattern = object.__getattribute__(pattern, "_us_raw")
            return _ORIG_STDLIB_RE_COMPILE(pattern, flags)
        _stdlib_re_compile_wrapper._us_unwrapped = True
        try:
            _re._compile = _stdlib_re_compile_wrapper
        except Exception:
            pass

    def _re_compile(pattern, flags=0):
        if isinstance(pattern, _RegexPatternProxy):
            return pattern
        if isinstance(pattern, _RAW_RE_PATTERN):
            return _RegexPatternProxy(pattern)
        eff_flags = _re_flags(flags)
        ckey = (pattern, eff_flags, type(pattern))
        cached = _RE_COMPILE_CACHE.get(ckey)
        if cached is not None:
            return cached
        comp_pat = pattern
        if _NARROW_UNICODE and isinstance(comp_pat, _unicode):
            comp_pat = astral_classes_to_surrogates(comp_pat)
        proxy = _RegexPatternProxy(_re.compile(comp_pat, eff_flags))
        if len(_RE_COMPILE_CACHE) > 4096:
            _RE_COMPILE_CACHE.clear()
        _RE_COMPILE_CACHE[ckey] = proxy
        return proxy

    def _re_fullmatch(pattern, string, flags=0):
        regex = _re_compile(pattern, flags)
        return _pattern_fullmatch(regex, string)

    def _re_call(name):
        func = getattr(_re, name)

        def call(pattern, *args, **kwargs):
            flags = kwargs.pop("flags", None)
            if flags is None and name in ("match", "search", "findall", "finditer") and len(args) >= 2:
                args = list(args)
                flags = args.pop(1)
            elif flags is None and name == "split" and len(args) >= 3:
                args = list(args)
                flags = args.pop(2)
            elif flags is None and name in ("sub", "subn") and len(args) >= 4:
                args = list(args)
                flags = args.pop(3)
            regex = _re_compile(pattern, flags or 0)
            return getattr(regex, name)(*args, **kwargs)

        call.__name__ = name
        return call

    re = _ModuleProxy(
        _re,
        compile=_re_compile,
        match=_re_call("match"),
        search=_re_call("search"),
        findall=_re_call("findall"),
        finditer=_re_call("finditer"),
        split=_re_call("split"),
        sub=_re_call("sub"),
        subn=_re_call("subn"),
        fullmatch=_re_fullmatch,
        ASCII=_RE_ASCII,
        A=_RE_ASCII,
        Pattern=_RE_PATTERN,
        Match=_RE_MATCH,
    )

    # ----------------------------------------------------------------------
    # traceback: text, not bytes
    # ----------------------------------------------------------------------
    def _tb_text(func):
        def call(*args, **kwargs):
            value = func(*args, **kwargs)
            if isinstance(value, list):
                return [_to_text(line) for line in value]
            return _to_text(value)

        call.__name__ = func.__name__
        return call

    traceback = _ModuleProxy(
        _traceback,
        format_exc=_tb_text(_traceback.format_exc),
        format_exception=_tb_text(_traceback.format_exception),
        format_exception_only=_tb_text(_traceback.format_exception_only),
        format_stack=_tb_text(_traceback.format_stack),
        format_tb=_tb_text(_traceback.format_tb),
        format_list=_tb_text(_traceback.format_list),
    )

    # ----------------------------------------------------------------------
    # urllib.parse
    # ----------------------------------------------------------------------
    def _quote(value, safe="/", encoding=None, errors=None):
        return _urllib.quote(_to_bytes(value, encoding or "utf-8", errors or "strict"), _to_bytes(safe)).decode("ascii")

    def _quote_plus(value, safe="", encoding=None, errors=None):
        return _urllib.quote_plus(_to_bytes(value, encoding or "utf-8", errors or "strict"), _to_bytes(safe)).decode("ascii")

    def _unquote(value, encoding="utf-8", errors="replace"):
        return _urllib.unquote(_to_bytes(value)).decode(encoding, errors)

    def _unquote_plus(value, encoding="utf-8", errors="replace"):
        return _urllib.unquote_plus(_to_bytes(value)).decode(encoding, errors)

    def _urlencode(query, doseq=False, safe="", encoding=None, errors=None, quote_via=None):
        if hasattr(query, "items"):
            query = list(query.items())

        def enc(item):
            if isinstance(item, _unicode):
                return item.encode(encoding or "utf-8", errors or "strict")
            if isinstance(item, _bstr):
                return item
            return _unicode(item).encode("utf-8")

        pairs = []
        for key, val in query:
            if doseq and isinstance(val, (list, tuple)):
                val = [enc(x) for x in val]
            else:
                val = enc(val)
            pairs.append((enc(key), val))
        text = _urllib.urlencode(pairs, doseq)
        if quote_via is _quote:
            text = text.replace("+", "%20")
        return text.decode("ascii")

    def _parse_qsl(qs, keep_blank_values=False, strict_parsing=False, encoding="utf-8", errors="replace", max_num_fields=None, separator="&"):
        return [
            (_to_text(k, encoding, errors), _to_text(v, encoding, errors))
            for k, v in _urlparse.parse_qsl(_to_bytes(qs), keep_blank_values, strict_parsing)
        ]

    def _parse_qs(qs, keep_blank_values=False, strict_parsing=False, encoding="utf-8", errors="replace", max_num_fields=None, separator="&"):
        result = {}
        for key, val in _parse_qsl(qs, keep_blank_values, strict_parsing, encoding, errors):
            result.setdefault(key, []).append(val)
        return result

    _SCHEME_CHARS = frozenset(u"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+-.")

    def _urlsplit(url, scheme="", allow_fragments=True):
        """urlsplit() following the Python 3 rules: a scheme must start with a
        letter, and "host:8080" is split the same way on both interpreters."""
        text_input = isinstance(url, _unicode)
        empty = u"" if text_input else b""
        if text_input and isinstance(scheme, _bstr):
            scheme = scheme.decode("ascii")
        url = url.lstrip(u" \t\n\r\x0b\x0c" if text_input else b" \t\n\r\x0b\x0c")
        for bad in ((u"\t", u"\r", u"\n") if text_input else (b"\t", b"\r", b"\n")):
            url = url.replace(bad, empty)
        netloc = query = fragment = empty
        i = url.find(u":" if text_input else b":")
        if i > 0 and url[0:1].isalpha() and ord(url[0:1]) < 128:
            head = url[:i]
            if all((c if text_input else c.decode("ascii", "replace")) in _SCHEME_CHARS for c in head):
                scheme, url = head.lower(), url[i + 1:]
        if url[:2] == (u"//" if text_input else b"//"):
            netloc, url = _urlparse._splitnetloc(url, 2)
            if ((u"[" in netloc and u"]" not in netloc) or (u"]" in netloc and u"[" not in netloc)):
                raise ValueError("Invalid IPv6 URL")
        if allow_fragments and (u"#" if text_input else b"#") in url:
            url, fragment = url.split(u"#" if text_input else b"#", 1)
        if (u"?" if text_input else b"?") in url:
            url, query = url.split(u"?" if text_input else b"?", 1)
        if text_input and isinstance(scheme, _bstr):
            scheme = scheme.decode("ascii")
        return _urlparse.SplitResult(scheme or empty, netloc, url, query, fragment)

    def _urlparse_fn(url, scheme="", allow_fragments=True):
        split = _urlsplit(url, scheme, allow_fragments)
        path, params = split.path, split[2][:0]
        if split.scheme in _urlparse.uses_params and u";" in path:
            if u"/" in path:
                cut = path.find(u";", path.rfind(u"/"))
                if cut >= 0:
                    path, params = path[:cut], path[cut + 1:]
            else:
                path, params = path.split(u";", 1)
        return _urlparse.ParseResult(split.scheme, split.netloc, path, params, split.query, split.fragment)

    urllib_parse = _ModuleProxy(
        _urlparse,
        urlsplit=_urlsplit,
        urlparse=_urlparse_fn,
        quote=_quote,
        quote_plus=_quote_plus,
        unquote=_unquote,
        unquote_plus=_unquote_plus,
        urlencode=_urlencode,
        parse_qs=_parse_qs,
        parse_qsl=_parse_qsl,
    )

    # ----------------------------------------------------------------------
    # urllib.request / urllib.error
    # ----------------------------------------------------------------------
    if not hasattr(_urllib2.Request, "full_url"):
        # urllib2's own redirect handler builds stock Request objects; the
        # plugin's redirect handlers read req.full_url from them.
        _urllib2.Request.full_url = property(lambda self: self.get_full_url())

    class _Request(_urllib2.Request):
        """urllib2.Request with Python 3 extras (method=, full_url)."""

        def __init__(self, url, data=None, headers=None, origin_req_host=None, unverifiable=False, method=None):
            _urllib2.Request.__init__(self, _to_bytes(url), data, {}, origin_req_host, unverifiable)
            for key, val in (headers or {}).items():
                self.add_header(_to_bytes(key), _to_bytes(val))
            self._us_method = method

        def get_method(self):
            if self._us_method:
                return _to_bytes(self._us_method)
            return _urllib2.Request.get_method(self)

        @property
        def full_url(self):
            return self.get_full_url()

        def add_header(self, key, val):
            _urllib2.Request.add_header(self, _to_bytes(key), _to_bytes(val))

        def add_unredirected_header(self, key, val):
            _urllib2.Request.add_unredirected_header(self, _to_bytes(key), _to_bytes(val))

    def _urlopen(url, data=None, timeout=_socket._GLOBAL_DEFAULT_TIMEOUT, cafile=None, capath=None, cadefault=False, context=None):
        if isinstance(url, _unicode):
            url = url.encode("utf-8")
        if context is not None:
            return _urllib2.urlopen(url, data, timeout, context=context)
        return _urllib2.urlopen(url, data, timeout)

    def _newstyle(cls):
        """Python 2 stdlib classes (urllib2 handlers, httplib connections,
        BaseHTTPServer handlers) are classic classes; super() needs new-style."""
        if isinstance(cls, type):
            return cls
        return type(cls.__name__, (cls, object), {"__module__": cls.__module__, "__doc__": cls.__doc__})

    urllib_request = _ModuleProxy(
        _urllib2,
        Request=_Request,
        urlopen=_urlopen,
        BaseHandler=_newstyle(_urllib2.BaseHandler),
        HTTPRedirectHandler=_newstyle(_urllib2.HTTPRedirectHandler),
        HTTPHandler=_newstyle(_urllib2.HTTPHandler),
        HTTPSHandler=_newstyle(_urllib2.HTTPSHandler),
        ProxyHandler=_newstyle(_urllib2.ProxyHandler),
        HTTPCookieProcessor=_newstyle(_urllib2.HTTPCookieProcessor),
        HTTPErrorProcessor=_newstyle(_urllib2.HTTPErrorProcessor),
        HTTPDefaultErrorHandler=_newstyle(_urllib2.HTTPDefaultErrorHandler),
    )
    urllib_error = _ModuleProxy(_urllib2)

    # ----------------------------------------------------------------------
    # http.client / http.server
    # ----------------------------------------------------------------------
    def _message_get_all(self, name, failobj=None):
        values = self.getheaders(name)
        return values if values else failobj

    if not hasattr(_mimetools.Message, "get_all"):
        _mimetools.Message.get_all = _message_get_all
    if not hasattr(_httplib.HTTPMessage, "get_all"):
        _httplib.HTTPMessage.get_all = _message_get_all
    if not hasattr(_httplib.HTTPResponse, "headers"):
        _httplib.HTTPResponse.headers = property(lambda self: self.msg)
    if not hasattr(_urllib.addinfourl, "status"):
        _urllib.addinfourl.status = property(lambda self: self.code)

    def _cm_enter(self):
        return self

    def _cm_exit(self, *exc):
        try:
            self.close()
        except Exception:
            pass
        return False

    def _http_readinto(self, b):
        data = self.read(len(b))
        n = len(data)
        b[:n] = data
        return n

    for _cls in (_urllib.addinfourl, _urllib.addbase, _httplib.HTTPResponse):
        if not hasattr(_cls, "readinto"):
            try:
                _cls.readinto = _http_readinto
            except Exception:
                pass

    for _cls in (_urllib.addinfourl, _urllib.addbase, _httplib.HTTPResponse, _httplib.HTTPConnection):
        if not hasattr(_cls, "__enter__"):
            try:
                _cls.__enter__ = _cm_enter
                _cls.__exit__ = _cm_exit
            except Exception:
                pass

    class _BytesRequestLine(object):
        """httplib joins the request line, headers and body with ``+``; one
        unicode piece turns the whole message into unicode and a binary body
        then fails to decode.  Keep every piece a byte string."""

        def putrequest(self, method, url, *args, **kwargs):
            return super(_BytesRequestLine, self).putrequest(_to_bytes(method), _to_bytes(url), *args, **kwargs)

        def putheader(self, header, *values):
            values = [_to_bytes(v) if isinstance(v, _unicode) else v for v in values]
            return super(_BytesRequestLine, self).putheader(_to_bytes(header), *values)

        def request(self, method, url, body=None, headers=None, **kwargs):
            if isinstance(body, _unicode):
                body = body.encode("iso-8859-1")  # what Python 3 does for str bodies
            return super(_BytesRequestLine, self).request(method, url, body, headers or {}, **kwargs)

    _HTTPConnection = type("HTTPConnection", (_BytesRequestLine, _httplib.HTTPConnection, object), {"__module__": "httplib"})
    _HTTPSConnection = type("HTTPSConnection", (_BytesRequestLine, _httplib.HTTPSConnection, object), {"__module__": "httplib"})

    http_client = _ModuleProxy(
        _httplib,
        HTTPConnection=_HTTPConnection,
        HTTPSConnection=_HTTPSConnection,
    )

    class _ThreadingHTTPServer(_socketserver.ThreadingMixIn, _bhs.HTTPServer, object):
        daemon_threads = True

    _NewStyleBaseHTTPRequestHandler = _newstyle(_bhs.BaseHTTPRequestHandler)

    class _BaseHTTPRequestHandler(_NewStyleBaseHTTPRequestHandler):
        def send_header(self, keyword, value):
            if isinstance(keyword, _unicode):
                keyword = keyword.encode("iso-8859-1", "replace")
            if isinstance(value, _unicode):
                try:
                    value = value.encode("iso-8859-1")
                except UnicodeError:
                    value = value.encode("utf-8", "replace")
            return _NewStyleBaseHTTPRequestHandler.send_header(self, keyword, value)

    http_server = _ModuleProxy(
        _bhs,
        ThreadingHTTPServer=_ThreadingHTTPServer,
        HTTPServer=_newstyle(_bhs.HTTPServer),
        BaseHTTPRequestHandler=_BaseHTTPRequestHandler,
    )

    # ----------------------------------------------------------------------
    # html
    # ----------------------------------------------------------------------
    def _html_escape(value, quote=True):
        value = value.replace(u"&", u"&amp;").replace(u"<", u"&lt;").replace(u">", u"&gt;")
        if quote:
            value = value.replace(u'"', u"&quot;").replace(u"'", u"&#x27;")
        return value

    def _html_unescape(value):
        return _htmlparser.HTMLParser().unescape(_to_text(value))

    html = _NS(escape=_html_escape, unescape=_html_unescape)

    # ----------------------------------------------------------------------
    # secrets
    # ----------------------------------------------------------------------
    _SYSRAND = _random.SystemRandom()

    def _token_urlsafe(nbytes=32):
        import base64
        return base64.urlsafe_b64encode(_os.urandom(nbytes)).rstrip(b"=").decode("ascii")

    secrets = _NS(
        compare_digest=lambda a, b: _compare_digest(a, b),
        token_bytes=lambda nbytes=32: _os.urandom(nbytes),
        token_hex=lambda nbytes=32: _binascii.hexlify(_os.urandom(nbytes)).decode("ascii"),
        token_urlsafe=_token_urlsafe,
        randbelow=lambda limit: _SYSRAND.randrange(limit),
        randbits=lambda k: _SYSRAND.getrandbits(k),
        choice=lambda seq: _SYSRAND.choice(seq),
    )

    # ----------------------------------------------------------------------
    # ipaddress (classification subset used by the plugin)
    # ----------------------------------------------------------------------
    _V4 = _socket.AF_INET
    _V6 = _socket.AF_INET6

    def _cidr(text, family):
        addr, _sep, bits = text.partition("/")
        packed = _socket.inet_pton(family, addr)
        value = _long(_binascii.hexlify(packed), 16)
        width = 32 if family == _V4 else 128
        bits = _bi.int(bits) if bits else width
        mask = ((1 << width) - 1) ^ ((1 << (width - bits)) - 1)
        return (value & mask, mask)

    def _in_nets(value, nets):
        for net, mask in nets:
            if value & mask == net:
                return True
        return False

    _NETS = {
        "v4_loopback": [_cidr("127.0.0.0/8", _V4)],
        "v4_link_local": [_cidr("169.254.0.0/16", _V4)],
        "v4_multicast": [_cidr("224.0.0.0/4", _V4)],
        "v4_reserved": [_cidr("240.0.0.0/4", _V4)],
        "v4_shared": [_cidr("100.64.0.0/10", _V4)],
        "v4_private": [_cidr(n, _V4) for n in (
            "0.0.0.0/8", "10.0.0.0/8", "127.0.0.0/8", "169.254.0.0/16", "172.16.0.0/12",
            "192.0.0.0/29", "192.0.0.170/31", "192.0.2.0/24", "192.168.0.0/16",
            "198.18.0.0/15", "198.51.100.0/24", "203.0.113.0/24", "240.0.0.0/4",
            "255.255.255.255/32")],
        "v6_link_local": [_cidr("fe80::/10", _V6)],
        "v6_multicast": [_cidr("ff00::/8", _V6)],
        "v6_mapped": [_cidr("::ffff:0:0/96", _V6)],
        "v6_reserved": [_cidr(n, _V6) for n in (
            "::/8", "100::/8", "200::/7", "400::/6", "800::/5", "1000::/4", "4000::/3",
            "6000::/3", "8000::/3", "a000::/3", "c000::/3", "e000::/4", "f000::/5",
            "f800::/6", "fe00::/9")],
        "v6_private": [_cidr(n, _V6) for n in (
            "::1/128", "::/128", "::ffff:0:0/96", "64:ff9b:1::/48", "100::/64", "2001::/23",
            "2001:db8::/32", "2002::/16", "fc00::/7", "fe80::/10")],
        "v6_private_exc": [_cidr(n, _V6) for n in (
            "2001:1::1/128", "2001:1::2/128", "2001:3::/32", "2001:4:112::/48",
            "2001:20::/28", "2001:30::/28")],
    }

    class _IPAddress(object):
        def __init__(self, family, packed):
            self.version = 4 if family == _V4 else 6
            self._family = family
            self.packed = packed
            self._value = _long(_binascii.hexlify(packed), 16)

        @property
        def ipv4_mapped(self):
            if self.version == 6 and _in_nets(self._value, _NETS["v6_mapped"]):
                return _IPAddress(_V4, _binascii.unhexlify("%08x" % (self._value & 0xFFFFFFFF)))
            return None

        def _is(self, v4_key, v6_test):
            mapped = self.ipv4_mapped
            if mapped is not None:
                return mapped._is(v4_key, v6_test)
            if self.version == 4:
                return _in_nets(self._value, _NETS[v4_key])
            return v6_test(self._value)

        @property
        def is_unspecified(self):
            return self._value == 0

        @property
        def is_loopback(self):
            return self._is("v4_loopback", lambda v: v == 1)

        @property
        def is_link_local(self):
            return self._is("v4_link_local", lambda v: _in_nets(v, _NETS["v6_link_local"]))

        @property
        def is_multicast(self):
            return self._is("v4_multicast", lambda v: _in_nets(v, _NETS["v6_multicast"]))

        @property
        def is_reserved(self):
            return self._is("v4_reserved", lambda v: _in_nets(v, _NETS["v6_reserved"]))

        @property
        def is_private(self):
            return self._is("v4_private", lambda v: _in_nets(v, _NETS["v6_private"]) and not _in_nets(v, _NETS["v6_private_exc"]))

        @property
        def is_global(self):
            mapped = self.ipv4_mapped
            if mapped is not None:
                return mapped.is_global
            if self.version == 4:
                return not _in_nets(self._value, _NETS["v4_shared"]) and not self.is_private
            return not self.is_private

        def __str__(self):
            return _socket.inet_ntop(self._family, self.packed)

        def __unicode__(self):
            return _unicode(self.__str__())

        def __repr__(self):
            return "IPv%dAddress(%r)" % (self.version, self.__str__())

        def __eq__(self, other):
            return isinstance(other, _IPAddress) and self._family == other._family and self._value == other._value

        def __ne__(self, other):
            return not self.__eq__(other)

        def __hash__(self):
            return hash((self._family, self._value))

    def _ip_address(value):
        text = value
        if isinstance(text, _unicode):
            try:
                text = text.encode("ascii")
            except UnicodeError:
                raise ValueError("%r does not appear to be an IPv4 or IPv6 address" % (value,))
        if isinstance(text, (_bi.int, _long)):
            width = 8 if text <= 0xFFFFFFFF else 32
            family = _V4 if width == 8 else _V6
            return _IPAddress(family, _binascii.unhexlify(("%0" + _bstr(width) + "x") % text))
        if not isinstance(text, _bstr):
            raise ValueError("%r does not appear to be an IPv4 or IPv6 address" % (value,))
        for family in (_V4, _V6):
            try:
                return _IPAddress(family, _socket.inet_pton(family, text))
            except (_socket.error, ValueError, TypeError):
                continue
        raise ValueError("%r does not appear to be an IPv4 or IPv6 address" % (value,))

    ipaddress = _NS(ip_address=_ip_address)

    # ----------------------------------------------------------------------
    # concurrent.futures (thread pool subset)
    # ----------------------------------------------------------------------
    class CancelledError(Exception):
        pass

    _FUTURE_TIMEOUT = TimeoutError

    class Future(object):
        def __init__(self):
            self._cond = _threading.Condition()
            self._state = "PENDING"
            self._result = None
            self._exception = None
            self._callbacks = []

        def _fire(self):
            callbacks, self._callbacks = self._callbacks, []
            for fn in callbacks:
                try:
                    fn(self)
                except Exception:
                    pass

        def cancel(self):
            with self._cond:
                if self._state in ("RUNNING", "FINISHED"):
                    return False
                if self._state == "CANCELLED":
                    return True
                self._state = "CANCELLED"
                self._cond.notify_all()
            self._fire()
            return True

        def cancelled(self):
            return self._state == "CANCELLED"

        def running(self):
            return self._state == "RUNNING"

        def done(self):
            return self._state in ("CANCELLED", "FINISHED")

        def _wait(self, timeout):
            with self._cond:
                if self.done():
                    return
                if timeout is None:
                    while not self.done():
                        self._cond.wait(3600)
                else:
                    end = _monotonic() + timeout
                    while not self.done():
                        left = end - _monotonic()
                        if left <= 0:
                            break
                        self._cond.wait(left)
                if not self.done():
                    raise _FUTURE_TIMEOUT()

        def result(self, timeout=None):
            self._wait(timeout)
            if self._state == "CANCELLED":
                raise CancelledError()
            if self._exception is not None:
                raise self._exception
            return self._result

        def exception(self, timeout=None):
            self._wait(timeout)
            if self._state == "CANCELLED":
                raise CancelledError()
            return self._exception

        def add_done_callback(self, fn):
            with self._cond:
                if not self.done():
                    self._callbacks.append(fn)
                    return
            try:
                fn(self)
            except Exception:
                pass

        def set_running_or_notify_cancel(self):
            with self._cond:
                if self._state == "CANCELLED":
                    return False
                self._state = "RUNNING"
                return True

        def set_result(self, result):
            with self._cond:
                self._result = result
                self._state = "FINISHED"
                self._cond.notify_all()
            self._fire()

        def set_exception(self, exception):
            with self._cond:
                self._exception = exception
                self._state = "FINISHED"
                self._cond.notify_all()
            self._fire()

    class ThreadPoolExecutor(object):
        def __init__(self, max_workers=None, thread_name_prefix="", initializer=None, initargs=()):
            if max_workers is None:
                max_workers = (_cpu_count() or 1) + 4
            if max_workers <= 0:
                raise ValueError("max_workers must be greater than 0")
            self._max_workers = max_workers
            self._prefix = thread_name_prefix or ("ThreadPoolExecutor-%d" % id(self))
            self._initializer = initializer
            self._initargs = initargs
            self._work = queue.Queue()
            self._threads = []
            self._idle = 0
            self._lock = _threading.Lock()
            self._closed = False

        def _worker(self):
            if self._initializer is not None:
                try:
                    self._initializer(*self._initargs)
                except Exception:
                    return
            while True:
                with self._lock:
                    self._idle += 1
                item = self._work.get()
                with self._lock:
                    self._idle -= 1
                if item is None:
                    self._work.put(None)  # wake the next worker too
                    return
                future, fn, args, kwargs = item
                if not future.set_running_or_notify_cancel():
                    continue
                try:
                    value = fn(*args, **kwargs)
                except BaseException as exc:
                    _report_thread_failure("thread-pool job %s" % getattr(fn, "__name__", "?"), _sys.exc_info())
                    future.set_exception(exc)
                else:
                    future.set_result(value)
                del item, future, fn, args, kwargs

        def submit(self, fn, *args, **kwargs):
            with self._lock:
                if self._closed:
                    raise RuntimeError("cannot schedule new futures after shutdown")
                future = Future()
                self._work.put((future, fn, args, kwargs))
                self._threads = [t for t in self._threads if t.is_alive()]
                if self._idle == 0 and len(self._threads) < self._max_workers:
                    thread = _threading.Thread(target=self._worker, name="%s_%d" % (self._prefix, len(self._threads)))
                    thread.daemon = True
                    thread.start()
                    self._threads.append(thread)
            return future

        def map(self, fn, *iterables, **kwargs):
            timeout = kwargs.get("timeout")
            futures = [self.submit(fn, *args) for args in _bi.zip(*iterables)]

            def results():
                try:
                    end = None if timeout is None else _monotonic() + timeout
                    for future in futures:
                        if end is None:
                            yield future.result()
                        else:
                            yield future.result(max(0.0, end - _monotonic()))
                finally:
                    for future in futures:
                        future.cancel()

            return results()

        def shutdown(self, wait=True, cancel_futures=False):
            with self._lock:
                self._closed = True
                threads = list(self._threads)
            if cancel_futures:
                while True:
                    try:
                        item = self._work.get_nowait()
                    except queue.Empty:
                        break
                    if item is not None:
                        item[0].cancel()
            self._work.put(None)
            if wait:
                for thread in threads:
                    thread.join()

        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc, tb):
            self.shutdown(wait=True)
            return False

    def as_completed(fs, timeout=None):
        fs = list(fs)
        done_queue = queue.Queue()
        pending = set()
        for future in fs:
            if future not in pending:
                pending.add(future)
                future.add_done_callback(done_queue.put)
        end = None if timeout is None else _monotonic() + timeout
        remaining = len(pending)
        while remaining:
            try:
                if end is None:
                    future = done_queue.get(True, 3600)
                else:
                    future = done_queue.get(True, max(0.0, end - _monotonic()))
            except queue.Empty:
                if end is None:
                    continue
                raise _FUTURE_TIMEOUT("%d (of %d) futures unfinished" % (remaining, len(pending)))
            remaining -= 1
            yield future

    FIRST_COMPLETED = "FIRST_COMPLETED"
    FIRST_EXCEPTION = "FIRST_EXCEPTION"
    ALL_COMPLETED = "ALL_COMPLETED"

    def _futures_wait(fs, timeout=None, return_when=ALL_COMPLETED):
        fs = set(fs)
        end = None if timeout is None else _monotonic() + timeout
        while True:
            done = set(f for f in fs if f.done())
            if return_when == FIRST_COMPLETED and done:
                break
            if return_when == FIRST_EXCEPTION and any(not f.cancelled() and f._exception is not None for f in done):
                break
            if len(done) == len(fs):
                break
            if end is not None and _monotonic() >= end:
                break
            _time.sleep(0.01)
        return (done, fs - done)

    concurrent_futures = _NS(
        Future=Future,
        ThreadPoolExecutor=ThreadPoolExecutor,
        as_completed=as_completed,
        wait=_futures_wait,
        CancelledError=CancelledError,
        TimeoutError=_FUTURE_TIMEOUT,
        FIRST_COMPLETED=FIRST_COMPLETED,
        FIRST_EXCEPTION=FIRST_EXCEPTION,
        ALL_COMPLETED=ALL_COMPLETED,
    )

    # ----------------------------------------------------------------------
    # collections: OrderedDict.move_to_end, text-safe namedtuple
    # ----------------------------------------------------------------------
    import collections as _collections

    class _OrderedDict(_collections.OrderedDict):
        def move_to_end(self, key, last=True):
            # Relink in place like Python 3; never calls a subclass's
            # __setitem__ (which may itself call move_to_end).
            try:
                link = self._OrderedDict__map[key]
                root = self._OrderedDict__root
            except AttributeError:
                link = None
            if link is not None:
                link_prev, link_next = link[0], link[1]
                link_prev[1] = link_next
                link_next[0] = link_prev
                if last:
                    tail = root[0]
                    link[0] = tail
                    link[1] = root
                    tail[1] = root[0] = link
                else:
                    head = root[1]
                    link[0] = root
                    link[1] = head
                    root[1] = head[0] = link
                return
            base = _collections.OrderedDict
            value = base.pop(self, key)
            if last:
                base.__setitem__(self, key, value)
                return
            rest = list(base.items(self))
            base.clear(self)
            base.__setitem__(self, key, value)
            for k, v in rest:
                base.__setitem__(self, k, v)

    def _namedtuple(typename, field_names, *args, **kwargs):
        if isinstance(field_names, _bi.basestring):
            field_names = field_names.replace(u",", u" ").split()
        kwargs.pop("module", None)
        kwargs.pop("defaults", None)
        native = lambda x: x.encode("utf-8") if isinstance(x, _unicode) else x
        return _collections.namedtuple(native(typename), [native(f) for f in field_names], *args, **kwargs)

    collections = _ModuleProxy(_collections, OrderedDict=_OrderedDict, namedtuple=_namedtuple)

    # ----------------------------------------------------------------------
    # logging: new-style Formatter / RotatingFileHandler so super() works
    # ----------------------------------------------------------------------
    try:
        import logging as _logging
        import logging.handlers as _logging_handlers
        for _lmod, _lname in ((_logging, "Formatter"), (_logging, "Handler"), (_logging, "StreamHandler"), (_logging, "FileHandler"), (_logging_handlers, "BaseRotatingHandler"), (_logging_handlers, "RotatingFileHandler")):
            _lcls = getattr(_lmod, _lname, None)
            if _lcls is not None and not isinstance(_lcls, type):
                try:
                    setattr(_lmod, _lname, _newstyle(_lcls))
                except Exception:
                    pass
    except Exception:
        pass

    # ----------------------------------------------------------------------
    # ssl: Python 3 exception names + unicode server_hostname on Python 2
    # ----------------------------------------------------------------------
    try:
        import ssl as _ssl
        if hasattr(_ssl, "SSLContext"):
            _orig_wrap_socket = getattr(_ssl.SSLContext, "wrap_socket", None)
            if _orig_wrap_socket is not None and not getattr(_orig_wrap_socket, "_us_patched", False):
                def _wrap_socket(self, sock, *args, **kwargs):
                    sh = kwargs.get("server_hostname")
                    if isinstance(sh, _unicode):
                        try:
                            kwargs["server_hostname"] = sh.encode("idna")
                        except UnicodeError:
                            kwargs["server_hostname"] = sh.encode("utf-8", "replace")
                    return _orig_wrap_socket(self, sock, *args, **kwargs)
                _wrap_socket._us_patched = True
                try:
                    _ssl.SSLContext.wrap_socket = _wrap_socket
                except Exception:
                    pass
        ssl = _ModuleProxy(
            _ssl,
            SSLCertVerificationError=getattr(_ssl, "SSLCertVerificationError", _ssl.SSLError),
            CertificateError=getattr(_ssl, "CertificateError", _ssl.SSLError),
        )
    except ImportError:
        ssl = None

    # ----------------------------------------------------------------------
    # sqlite3: Row that accepts text column names (and slices)
    # ----------------------------------------------------------------------
    # With unicode_literals every row["column"] lookup passes unicode, and the
    # Python 2 sqlite3.Row only takes byte strings or ints ("Index must be int
    # or string") - which broke every database read: cache, favourites,
    # history, portal state.
    try:
        import sqlite3 as _sqlite3

        class _SqliteRow(_sqlite3.Row):
            __slots__ = ()

            def __getitem__(self, key):
                if isinstance(key, _unicode):
                    key = key.encode("utf-8")
                elif isinstance(key, slice):
                    return tuple(self)[key]
                return _sqlite3.Row.__getitem__(self, key)

        sqlite3 = _ModuleProxy(_sqlite3, Row=_SqliteRow)
    except ImportError:  # pragma: no cover - reported by the preflight
        sqlite3 = None

    # ----------------------------------------------------------------------
    # socket: getaddrinfo() keyword arguments (Python 2 takes positional only)
    # ----------------------------------------------------------------------
    def _getaddrinfo(host, port, family=0, type=0, proto=0, flags=0):
        if isinstance(host, _unicode):
            try:
                host = host.encode("idna")
            except UnicodeError:
                host = host.encode("utf-8")
        if isinstance(port, _unicode):
            port = port.encode("ascii")
        return _socket.getaddrinfo(host, port, family, type, proto, flags)

    socket = _ModuleProxy(_socket, getaddrinfo=_getaddrinfo)

    # ----------------------------------------------------------------------
    # hashlib / hmac: text hexdigest, native algorithm names, mixed compare
    # ----------------------------------------------------------------------
    import hashlib as _hashlib_mod
    import hmac as _hmac_mod

    class _Hash(object):
        __slots__ = ("_h",)

        def __init__(self, h):
            self._h = h

        def update(self, data):
            if isinstance(data, _unicode):
                raise TypeError("Unicode-objects must be encoded before hashing")
            self._h.update(data)

        def digest(self):
            return self._h.digest()

        def hexdigest(self):
            return self._h.hexdigest().decode("ascii")

        def copy(self):
            return _Hash(self._h.copy())

        @property
        def digest_size(self):
            return self._h.digest_size

        @property
        def block_size(self):
            return self._h.block_size

        @property
        def name(self):
            return self._h.name

    def _hash_ctor(name):
        ctor = getattr(_hashlib_mod, name)

        def make(data=b"", **_ignored):
            if isinstance(data, _unicode):
                raise TypeError("Unicode-objects must be encoded before hashing")
            return _Hash(ctor(data))

        make.__name__ = name  # already a native str here
        return make

    def _hash_new(name, data=b"", **_ignored):
        if isinstance(data, _unicode):
            raise TypeError("Unicode-objects must be encoded before hashing")
        return _Hash(_hashlib_mod.new(_to_bytes(name), data))

    def _pbkdf2_hmac(hash_name, password, salt, iterations, dklen=None):
        return _hashlib_mod.pbkdf2_hmac(_to_bytes(hash_name), password, salt, iterations, dklen)

    def _compare_digest(a, b):
        # Python 2 refuses str/unicode mixes; hex digests and PIN hashes are
        # ASCII, so compare them in one representation.
        if isinstance(a, _unicode) != isinstance(b, _unicode):
            a = _to_bytes(a, "utf-8") if isinstance(a, _unicode) else a
            b = _to_bytes(b, "utf-8") if isinstance(b, _unicode) else b
        return _hmac_mod.compare_digest(a, b)

    def _hmac_new(key, msg=None, digestmod=None):
        if isinstance(digestmod, (_bi.basestring,)):
            digestmod = _hash_ctor(_to_bytes(digestmod))
        return _HMAC(key, msg, digestmod)

    class _HMAC(_hmac_mod.HMAC, object):
        def hexdigest(self):
            value = _hmac_mod.HMAC.hexdigest(self)
            return value.decode("ascii") if isinstance(value, _bstr) else value

    hashlib = _ModuleProxy(
        _hashlib_mod,
        md5=_hash_ctor("md5"), sha1=_hash_ctor("sha1"), sha224=_hash_ctor("sha224"),
        sha256=_hash_ctor("sha256"), sha384=_hash_ctor("sha384"), sha512=_hash_ctor("sha512"),
        new=_hash_new, pbkdf2_hmac=_pbkdf2_hmac,
    )
    hmac = _ModuleProxy(_hmac_mod, new=_hmac_new, HMAC=_HMAC, compare_digest=_compare_digest)

    # ----------------------------------------------------------------------
    # base64: Base85 (RFC 1924 alphabet, same as Python 3 b85encode)
    # ----------------------------------------------------------------------
    import base64 as _base64
    import inspect as _inspect

    _B85_ALPHABET = (b"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
                     b"abcdefghijklmnopqrstuvwxyz!#$%&()*+-;<=>?@^_`{|}~")
    _B85_DECODE = dict((c, i) for i, c in enumerate(bytearray(_B85_ALPHABET)))

    def _b85encode(data, pad=False):
        raw = bytearray(_to_bytes(data))
        padding = (-len(raw)) % 4
        raw += bytearray(padding)
        out = bytearray()
        alphabet = bytearray(_B85_ALPHABET)
        for i in range(0, len(raw), 4):
            word = (raw[i] << 24) | (raw[i + 1] << 16) | (raw[i + 2] << 8) | raw[i + 3]
            chunk = bytearray(5)
            for j in range(4, -1, -1):
                word, rem = divmod(word, 85)
                chunk[j] = alphabet[rem]
            out += chunk
        if padding and not pad:
            out = out[:-padding]
        return _bstr(out)

    def _b85decode(data):
        raw = bytearray(_to_bytes(data, "ascii"))
        padding = (-len(raw)) % 5
        raw += bytearray(b"~" * padding)
        out = bytearray()
        for i in range(0, len(raw), 5):
            word = 0
            for c in raw[i:i + 5]:
                try:
                    word = word * 85 + _B85_DECODE[c]
                except KeyError:
                    raise ValueError("bad base85 character at position %d" % i)
            if word > 0xFFFFFFFF:
                raise ValueError("base85 overflow in hunk starting at byte %d" % i)
            out += bytearray(((word >> 24) & 0xFF, (word >> 16) & 0xFF, (word >> 8) & 0xFF, word & 0xFF))
        if padding:
            out = out[:-padding]
        return _bstr(out)

    base64 = _ModuleProxy(_base64, b85encode=_b85encode, b85decode=_b85decode)

    # ----------------------------------------------------------------------
    # inspect.signature (subset: .parameters and .bind())
    # ----------------------------------------------------------------------
    class _Parameter(object):
        POSITIONAL_OR_KEYWORD = "POSITIONAL_OR_KEYWORD"
        VAR_POSITIONAL = "VAR_POSITIONAL"
        VAR_KEYWORD = "VAR_KEYWORD"
        empty = object()

        def __init__(self, name, kind, default):
            self.name = name
            self.kind = kind
            self.default = default

    class _Signature(object):
        def __init__(self, args, varargs, varkw, defaults):
            from collections import OrderedDict
            self._args = list(args)
            self._varargs = varargs
            self._varkw = varkw
            defaults = tuple(defaults or ())
            self._required = len(self._args) - len(defaults)
            params = OrderedDict()
            for index, name in enumerate(self._args):
                default = defaults[index - self._required] if index >= self._required else _Parameter.empty
                params[name] = _Parameter(name, _Parameter.POSITIONAL_OR_KEYWORD, default)
            if varargs:
                params[varargs] = _Parameter(varargs, _Parameter.VAR_POSITIONAL, _Parameter.empty)
            if varkw:
                params[varkw] = _Parameter(varkw, _Parameter.VAR_KEYWORD, _Parameter.empty)
            self.parameters = params

        def bind(self, *args, **kwargs):
            if len(args) > len(self._args) and not self._varargs:
                raise TypeError("too many positional arguments")
            bound = set(self._args[:len(args)])
            for key in kwargs:
                if key in bound:
                    raise TypeError("multiple values for argument %r" % key)
                if key not in self._args and not self._varkw:
                    raise TypeError("got an unexpected keyword argument %r" % key)
                bound.add(key)
            for name in self._args[:self._required]:
                if name not in bound:
                    raise TypeError("missing a required argument: %r" % name)
            return True

    def _signature(func):
        target = func
        drop_first = False
        if isinstance(target, (_types.FunctionType, _types.LambdaType)):
            pass
        elif isinstance(target, _types.MethodType):
            drop_first = target.__self__ is not None
            target = target.__func__
        elif isinstance(target, (type, _types.ClassType)):
            init = getattr(target, "__init__", None)
            if not isinstance(init, (_types.MethodType, _types.FunctionType)):
                return _Signature((), None, None, ())
            target = getattr(init, "__func__", init)
            drop_first = True
        elif hasattr(target, "__call__") and isinstance(getattr(target, "__call__"), _types.MethodType):
            target = target.__call__.__func__
            drop_first = True
        elif isinstance(target, _functools_partial):
            inner = _signature(target.func)
            args = inner._args[len(target.args):]
            keywords = target.keywords or {}
            args = [a for a in args if a not in keywords]
            return _Signature(args, inner._varargs, inner._varkw, ())
        try:
            spec = _inspect.getargspec(target)
        except TypeError:
            raise ValueError("no signature found for %r" % (func,))
        args = list(spec.args)
        if drop_first and args:
            args = args[1:]
        return _Signature(args, spec.varargs, spec.keywords, spec.defaults)

    import functools as _functools
    _functools_partial = _functools.partial

    inspect = _ModuleProxy(_inspect, signature=_signature, Parameter=_Parameter, Signature=_Signature)

    # ----------------------------------------------------------------------
    # Enigma2 bridge: UTF-8 bytes at the C++ boundary
    # ----------------------------------------------------------------------
    _BRIDGE_STATE = {"installed": False, "patched": 0, "error": None}

    def _needs_encoding(value, depth=0):
        if isinstance(value, _unicode):
            return True
        if depth < 3 and type(value) in (list, tuple):
            for item in value:
                if _needs_encoding(item, depth + 1):
                    return True
        return False

    _LONE_SURROGATE = None
    if _sys.maxunicode < 0x10000:
        _LONE_SURROGATE = _re.compile(
            u"[\ud800-\udbff](?![\udc00-\udfff])|(?<![\ud800-\udbff])[\udc00-\udfff]")

    def _enigma_text(value):
        # Text cut in the middle of an emoji leaves half a surrogate pair on
        # UCS-2 builds; Enigma2 would draw it as garbage.
        if _LONE_SURROGATE is not None and u"\ud800" <= max(value or u"\x00") :
            value = _LONE_SURROGATE.sub(u"", value)
        return value.encode("utf-8")

    def _encode_value(value, depth=0):
        if isinstance(value, _unicode):
            return _enigma_text(value)
        if depth < 3:
            kind = type(value)
            if kind is list:
                return [_encode_value(item, depth + 1) for item in value]
            if kind is tuple:
                return tuple(_encode_value(item, depth + 1) for item in value)
        return value

    def _encode_args(args):
        for arg in args:
            if _needs_encoding(arg):
                return tuple(_encode_value(arg) for arg in args), True
        return args, False

    def _wrap_result_encoder(fn):
        def build(*args, **kwargs):
            return _encode_value(fn(*args, **kwargs))

        build._us_wrapped = fn
        return build

    _CALLBACK_METHODS = frozenset(("setBuildFunc", "setSelectableFunc"))

    def _is_template_item(item):
        return type(item) is tuple and item and isinstance(item[0], (_bi.int, _long))

    def _encode_list_entry(entry):
        """One listbox row.  Multi-content rows are ``[data, (TYPE, ...), ...]``;
        the data slot goes back to Python through getCurrentSelection(), so it
        is left as it is and only the drawing templates are encoded.  String
        content rows are ``(text, data)``; only the text is encoded."""
        if isinstance(entry, _unicode):
            return _enigma_text(entry)
        kind = type(entry)
        if kind not in (list, tuple) or not entry:
            return entry
        if len(entry) > 1 and any(_is_template_item(x) for x in entry[1:]):
            tail = [_encode_value(x, 1) for x in entry[1:]]
            return kind([entry[0]] + tail)
        head = _encode_value(entry[0], 2)
        if head is entry[0]:
            return entry
        return kind([head] + list(entry[1:]))

    def _encode_rows(rows):
        if not _needs_encoding(rows):
            return rows
        return [_encode_list_entry(row) for row in rows]

    # Listbox contents keep a reference to the Python list given to setList();
    # screens then edit that same list (rows[i] = new_row) and call
    # invalidateEntry(i) / invalidate() to redraw.  So rows are encoded *inside*
    # the caller's list, never into a copy, and re-encoded on invalidation.
    _CONTENT_ROWS = {}
    _CONTENT_ORDER = []
    _CONTENT_LIMIT = 256

    def _encode_rows_inplace(rows):
        for index in range(len(rows)):
            row = rows[index]
            if _needs_encoding(row, 1):
                rows[index] = _encode_list_entry(row)
        return rows

    def _remember_rows(content, rows):
        key = id(content)
        if key not in _CONTENT_ROWS:
            _CONTENT_ORDER.append(key)
            if len(_CONTENT_ORDER) > _CONTENT_LIMIT:
                _CONTENT_ROWS.pop(_CONTENT_ORDER.pop(0), None)
        _CONTENT_ROWS[key] = rows

    def _rows_of(content):
        return _CONTENT_ROWS.get(id(content))

    def _wrap_callable(func, name):
        if getattr(func, "_us_bridge", False):
            return func

        if name == "setList":
            # method: args = (content, rows, ...)
            def bridge(*args, **kwargs):
                if len(args) >= 2 and type(args[1]) is list:
                    _encode_rows_inplace(args[1])
                    _remember_rows(args[0], args[1])
                    args = args[:2] + tuple(_encode_value(a) for a in args[2:])
                else:
                    args, _changed = _encode_args(args)
                return func(*args, **kwargs)
        elif name == "invalidateEntry":
            def bridge(*args, **kwargs):
                rows = _rows_of(args[0]) if args else None
                if rows is not None and len(args) >= 2:
                    try:
                        index = _bi.int(args[1])
                        if 0 <= index < len(rows) and _needs_encoding(rows[index], 1):
                            rows[index] = _encode_list_entry(rows[index])
                    except Exception:
                        pass
                return func(*args, **kwargs)
        elif name == "invalidate":
            def bridge(*args, **kwargs):
                rows = _rows_of(args[0]) if args else None
                if rows is not None:
                    _encode_rows_inplace(rows)
                return func(*args, **kwargs)
        elif name in _CALLBACK_METHODS:
            def bridge(*args, **kwargs):
                args = tuple(_wrap_result_encoder(a) if callable(a) and not isinstance(a, type) else a for a in args)
                args, _changed = _encode_args(args)
                return func(*args, **kwargs)
        else:
            def bridge(*args, **kwargs):
                args, changed = _encode_args(args)
                if kwargs:
                    for key, val in list(kwargs.items()):
                        if _needs_encoding(val):
                            kwargs[key] = _encode_value(val)
                return func(*args, **kwargs)

        try:
            bridge.__name__ = getattr(func, "__name__", name)
            bridge.__doc__ = getattr(func, "__doc__", None)
        except Exception:
            pass
        bridge._us_bridge = True
        bridge._us_original = func
        return bridge

    def _rebind_everywhere(replacements):
        """Replace references that other modules already imported by name
        (``from enigma import loadPNG``)."""
        if not replacements:
            return
        for module in list(_sys.modules.values()):
            space = getattr(module, "__dict__", None)
            if not isinstance(space, dict):
                continue
            for key, value in list(space.items()):
                try:
                    new = replacements.get(id(value))
                except Exception:
                    new = None
                if new is not None and new[0] is value:
                    try:
                        space[key] = new[1]
                    except Exception:
                        pass

    def install_enigma_bridge():
        """Make the SWIG wrapped Enigma2 API accept ``unicode`` text.

        Python 2 SWIG bindings take ``std::string`` only from byte strings.
        The wrappers encode unicode arguments (also inside list/tuple
        entries passed to listbox contents) to UTF-8 and leave everything
        else untouched, so other plugins keep working exactly as before.
        """
        if _BRIDGE_STATE["installed"]:
            return True
        try:
            import enigma
        except Exception as exc:
            _BRIDGE_STATE["error"] = "enigma import: %s" % (exc,)
            return False
        patched = 0
        replacements = {}
        try:
            for name, obj in list(vars(enigma).items()):
                if name.startswith("_"):
                    continue
                if isinstance(obj, (type, _types.ClassType)):
                    if getattr(obj, "__module__", None) not in ("enigma", None):
                        continue
                    for attr, member in list(vars(obj).items()):
                        if attr.startswith("__") and attr != "__init__":
                            continue
                        # SWIG proxies come in several shapes: plain functions,
                        # "fastproxy" unbound instancemethods (-O builds, as on
                        # DreamOS) and builtin method objects.  Wrap every plain
                        # callable; leave static/class methods, properties and
                        # nested classes alone.
                        if isinstance(member, (staticmethod, classmethod, property, type, _types.ClassType)):
                            continue
                        if not callable(member):
                            continue
                        try:
                            setattr(obj, attr, _wrap_callable(member, attr))
                            patched += 1
                        except Exception:
                            _BRIDGE_STATE["locked"] = _BRIDGE_STATE.get("locked", 0) + 1
                elif isinstance(obj, (_types.FunctionType, _types.BuiltinFunctionType)):
                    wrapped = _wrap_callable(obj, name)
                    setattr(enigma, name, wrapped)
                    replacements[id(obj)] = (obj, wrapped)
                    patched += 1
        except Exception as exc:
            _BRIDGE_STATE["error"] = "enigma patch: %s" % (exc,)
        # XML parsers used for screen skins
        for modname in ("xml.etree.cElementTree", "xml.etree.ElementTree"):
            try:
                module = __import__(modname, fromlist=[_bstr("fromstring")])
            except Exception:
                continue
            for attr in ("fromstring", "XML"):
                original = getattr(module, attr, None)
                if original is None or getattr(original, "_us_bridge", False):
                    continue

                def xml_bridge(text, *args, **kwargs):
                    if isinstance(text, _unicode):
                        text = text.encode("utf-8")
                    return xml_bridge._us_original(text, *args, **kwargs)

                xml_bridge._us_original = original
                xml_bridge._us_bridge = True
                xml_bridge.__name__ = attr
                try:
                    setattr(module, attr, xml_bridge)
                    replacements[id(original)] = (original, xml_bridge)
                except Exception:
                    pass
        _rebind_everywhere(replacements)
        _BRIDGE_STATE["installed"] = True
        _BRIDGE_STATE["patched"] = patched
        return patched > 0

    try:
        install_enigma_bridge()
    except Exception as _exc:
        _BRIDGE_STATE["error"] = "%s" % (_exc,)


# ==========================================================================
# Helpers shared by both interpreters
# ==========================================================================
def us_clear(obj):
    """``obj.clear()`` that also works for Python 2 lists."""
    if type(obj) is list:
        del obj[:]
        return None
    return obj.clear()


def us_copy(obj):
    """``obj.copy()`` that also works for Python 2 lists."""
    if type(obj) is list:
        return obj[:]
    return obj.copy()


us_casefold = casefold


def us_bytes_fromhex(value):
    """``bytes.fromhex`` on both interpreters."""
    import binascii
    value = "".join(str(value).split())
    return bytes(binascii.unhexlify(value.encode("ascii")))


def us_acquire(lock, timeout):
    """``lock.acquire(timeout=...)`` (Python 3 only) with a polling fallback."""
    try:
        return lock.acquire(True, timeout)
    except TypeError:
        pass
    import time as _t
    end = _t.time() + float(timeout)
    while True:
        if lock.acquire(False):
            return True
        if _t.time() >= end:
            return False
        _t.sleep(0.005)


def us_et_fromstring(xml):
    import xml.etree.ElementTree as _ET
    if isinstance(xml, text_type):
        xml = xml.encode("utf-8")
    return _ET.fromstring(xml)


def us_et_tostring(root):
    import xml.etree.ElementTree as _ET
    out = _ET.tostring(root, encoding="utf-8")
    if isinstance(out, binary_type):
        out = out.decode("utf-8")
    if out.startswith("<?xml"):
        out = out.split("?>", 1)[1].lstrip()
    return out
us_bytes_hex = bytes_hex
us_int_from_bytes = int_from_bytes
us_int_to_bytes = int_to_bytes


def to_text(value, encoding="utf-8", errors="replace"):
    if isinstance(value, binary_type):
        return value.decode(encoding, errors)
    if isinstance(value, text_type):
        return value
    return str(value)


def to_bytes(value, encoding="utf-8", errors="strict"):
    if isinstance(value, text_type):
        return value.encode(encoding, errors)
    return value


_THREAD_FAILURE_HOOK = [None]


def set_thread_failure_hook(hook):
    """hook(where, exc_info) is called for exceptions that escape a plugin
    thread or thread-pool job on Python 2 (Python 3 uses threading.excepthook)."""
    _THREAD_FAILURE_HOOK[0] = hook


def _report_thread_failure(where, exc_info):
    hook = _THREAD_FAILURE_HOOK[0]
    if hook is None:
        return
    try:
        hook(where, exc_info)
    except Exception:
        pass


def us_func(method):
    """Base.method(self, ...) with any object as self.  Python 2 unbound
    methods only accept instances of Base; return the plain function then.
    Bound methods (classmethods) are returned unchanged."""
    if not PY3 and getattr(method, "__self__", 0) is None:
        return getattr(method, "__func__", method)
    return method


def us_isprintable(text):
    """``str.isprintable()`` for both interpreters."""
    if PY3:
        return text.isprintable()
    import unicodedata
    for ch in to_text(text):
        if ch == u" ":
            continue
        if unicodedata.category(ch) in ("Cc", "Cf", "Cs", "Co", "Cn", "Zl", "Zp", "Zs"):
            return False
    return True


def us_text_callback(callback):
    """Wrap a stock-screen callback so text results arrive as text.

    Python 2 Enigma2 screens (VirtualKeyBoard, InputBox ...) hand back UTF-8
    byte strings; the plugin works with text everywhere."""
    if PY3:
        return callback

    def wrapped(*args, **kwargs):
        args = tuple(to_text(a) if isinstance(a, binary_type) else a for a in args)
        return callback(*args, **kwargs)

    return wrapped


# --------------------------------------------------------------------------
# TLS trust store
# --------------------------------------------------------------------------
# Python verifies HTTPS against the roots OpenSSL finds at its compiled-in
# default paths.  DreamOS images often have no bundle there (or keep it at a
# path their OpenSSL does not look at), so every HTTPS request - TMDB,
# subtitles, HTTPS portals - fails certificate verification.  Point OpenSSL
# at a real bundle through SSL_CERT_FILE: the system one when it exists
# somewhere else, otherwise the Mozilla roots shipped in certs/cacert.pem.
_TRUST_STATE = {"source": None, "file": None}
_CA_CANDIDATES = (
    "/etc/ssl/certs/ca-certificates.crt",
    "/etc/pki/tls/certs/ca-bundle.crt",
    "/etc/ssl/ca-bundle.pem",
    "/etc/ssl/cert.pem",
    "/usr/lib/ssl/cert.pem",
    "/usr/local/share/certs/ca-root-nss.crt",
)


def _file_has_certs(path):
    try:
        if not path or not _os.path.isfile(path) or _os.path.getsize(path) < 1024:
            return False
        with _io.open(path, "rb") as handle:
            return b"BEGIN CERTIFICATE" in handle.read(65536)
    except Exception:
        return False


def _dir_has_certs(path):
    try:
        if not path or not _os.path.isdir(path):
            return False
        for name in _os.listdir(path):
            if name[-2:] in (".0", ".1") or name.endswith((".pem", ".crt")):
                return True
    except Exception:
        pass
    return False


def ensure_trust_store():
    if _TRUST_STATE["source"] is not None:
        return _TRUST_STATE
    env_file = _os.environ.get("SSL_CERT_FILE")
    if _file_has_certs(env_file):
        _TRUST_STATE.update(source="environment", file=env_file)
        return _TRUST_STATE
    try:
        import ssl as _ssl_mod
        paths = _ssl_mod.get_default_verify_paths()
        if _file_has_certs(paths.openssl_cafile) or _dir_has_certs(paths.openssl_capath):
            _TRUST_STATE.update(source="system", file=paths.openssl_cafile or paths.openssl_capath)
            return _TRUST_STATE
    except Exception:
        pass
    for candidate in _CA_CANDIDATES:
        if _file_has_certs(candidate):
            _os.environ["SSL_CERT_FILE"] = candidate
            _TRUST_STATE.update(source="system-relocated", file=candidate)
            return _TRUST_STATE
    bundled = _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), "certs", "cacert.pem")
    if _file_has_certs(bundled):
        _os.environ["SSL_CERT_FILE"] = bundled
        _TRUST_STATE.update(source="bundled", file=bundled)
    else:
        _TRUST_STATE.update(source="missing", file=None)
    return _TRUST_STATE


try:
    ensure_trust_store()
except Exception:
    pass


def bridge_status():
    if PY3:
        return {"python": "%d.%d" % PYVER, "bridge": "not needed", "tls": dict(_TRUST_STATE)}
    return {"python": "%d.%d" % PYVER, "bridge": dict(_BRIDGE_STATE),
            "fs_encoding": {"before": _FS_STATE["before"], "after": _FS_STATE["after"]},
            "tls": dict(_TRUST_STATE)}


# Package-style namespaces (both interpreters)
urllib = _NS(request=urllib_request, parse=urllib_parse, error=urllib_error)
http = _NS(client=http_client, server=http_server, cookiejar=http_cookiejar, cookies=http_cookies)
concurrent = _NS(futures=concurrent_futures)


# Older Pillow on receivers: add only the missing APIs the plugin uses.
try:
    try:
        from . import pil_compat as _pil_compat
    except (ImportError, ValueError):
        import pil_compat as _pil_compat
    PIL_STATE = _pil_compat.install()
except Exception as _exc:
    PIL_STATE = {"error": "%s" % (_exc,)}


# functools.lru_cache (Python 3.2+); a small bounded memo on Python 2.
try:
    from functools import lru_cache
except ImportError:  # pragma: no cover - Python 2 receivers
    def lru_cache(maxsize=128, typed=False):
        if callable(maxsize):
            return lru_cache()(maxsize)

        def _wrap(fn):
            store = {}
            lock = _threading.Lock()

            def call(*args, **kwargs):
                key = (args, tuple(sorted(kwargs.items()))) if kwargs else args
                try:
                    return store[key]
                except KeyError:
                    pass
                except TypeError:
                    return fn(*args, **kwargs)
                value = fn(*args, **kwargs)
                with lock:
                    if maxsize is not None and len(store) >= maxsize:
                        store.clear()
                    store[key] = value
                return value

            def cache_clear():
                with lock:
                    store.clear()

            call.cache_clear = cache_clear
            call.__wrapped__ = fn
            try:
                call.__name__ = fn.__name__
                call.__doc__ = fn.__doc__
            except Exception:
                pass
            return call
        return _wrap


_ISO_RE = None


def us_iso_timestamp(text):
    """Epoch seconds of an ISO-8601 time that carries an offset (or Z); None
    for a naive time.  ValueError when the text is not ISO-8601.
    datetime.fromisoformat()/timestamp() exist on Python 3 only."""
    global _ISO_RE
    import datetime as _dt
    text = str(text or "").strip()
    if PY3 and hasattr(_dt.datetime, "fromisoformat"):
        parsed = _dt.datetime.fromisoformat(text.replace("Z", "+00:00"))
        return parsed.timestamp() if parsed.tzinfo is not None else None
    import calendar
    import re as _re_mod
    if _ISO_RE is None:
        _ISO_RE = _re_mod.compile(r"^(\d{4})-(\d{2})-(\d{2})(?:[T ](\d{2}):(\d{2})(?::(\d{2})(?:\.(\d{1,6}))?)?)?\s*(Z|z|[+-]\d{2}:?\d{2})?$")
    match = _ISO_RE.match(text)
    if not match:
        raise ValueError("not an ISO-8601 time: %r" % (text,))
    y, mo, d, hh, mi, ss, frac, zone = match.groups()
    stamp = calendar.timegm((int(y), int(mo), int(d), int(hh or 0), int(mi or 0), int(ss or 0), 0, 0, 0))
    if frac:
        stamp += float("0." + frac)
    if not zone:
        return None
    if zone not in ("Z", "z"):
        z = zone.replace(":", "")
        offset = int(z[1:3]) * 3600 + int(z[3:5]) * 60
        stamp -= offset if z[0] == "+" else -offset
    return stamp
