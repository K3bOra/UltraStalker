# -*- coding: utf-8 -*-
"""Detail action layout, sharp chrome assets, quality values and visual refresh.

Methods moved verbatim out of ``ContentDetailsScreen`` (ui_screens_details.py); behaviour is unchanged.
This module is imported by ui_screens_details.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, round, max, min, OSError
from .ui_screens_details import (
    _,
    durable_view_path,
    hashlib,
    os,
    re,
    reactor,
    threading,
    weakref,
)


from . import details_look as _look


class DetailsChromeMixin(object):
    """Detail action layout, sharp chrome assets, quality values and visual refresh."""

    def _layout_detail_actions(self):
        # R5.140: the footer geometry is fixed in the skin (copied from Cinematic).
        return

    def _apply_poster_laser_outline(self, chrome):
        # release: Details poster remains intentionally frameless. Some provider
        # posters arrive undersized; a fixed outline exposes the empty widget
        # rectangle and looks wrong. Keep compatibility widgets hidden.
        for name in ("poster_laser_top","poster_laser_bottom","poster_laser_left","poster_laser_right"):
            try:self[name].hide()
            except Exception:pass

    def _sharp_detail_chrome_cache_path(self, source, key, target_size):
        """Compute the exact nine-slice cache path without decoding the PNG."""
        try:
            source=str(source or "")
            if not source or not os.path.isfile(source):return ""
            tw,th=[int(x) for x in target_size]
            stamp="%s|%s|%s|%s|%s"%(source,os.path.getmtime(source),key,tw,th)
            return durable_view_path(hashlib.sha1(stamp.encode("utf-8","ignore")).hexdigest()[:24]+".png","details_sharp_v6514",source=source)
        except Exception:
            return ""

    def _queue_sharp_detail_chrome_asset(self, widget, source, key, target_size):
        """Build an exact-size glass asset off the Enigma2 GUI thread.

        The source is painted immediately.  If an exact nine-slice copy is needed,
        it is generated in the bounded async pool and swapped in later.  This keeps
        Details/Series opening independent from Pillow PNG resize/optimize time.
        """
        source=str(source or "")
        if not source or not os.path.isfile(source) or getattr(self,"_screen_closed",False):return
        identity=(str(widget),source,str(key),tuple(int(x) for x in target_size))
        requested=getattr(self,"_sharp_detail_requested",None)
        if requested is None:requested={};self._sharp_detail_requested=requested
        requested[widget]=identity
        if identity in getattr(self,"_sharp_detail_exact_sources",set()) or identity in getattr(self,"_sharp_detail_pending",set()):return
        cached=self._sharp_detail_chrome_cache_path(source,key,target_size)
        if cached and _valid_cache_file(cached):
            try:
                if self[widget].instance is not None:self[widget].instance.setPixmapFromFile(cached)
            except Exception as exc:optional_failure("ui.details_sharp_cached_apply",exc)
            return
        self._sharp_detail_pending.add(identity)
        cancel_event=getattr(self,"_details_cancel_event",None)
        screen_ref=weakref.ref(self)
        def work():
            if cancel_event is not None and cancel_event.is_set():return ""
            return self._sharp_detail_chrome_asset(source,key,target_size)
        def done(future):
            error=None;path=""
            try:path=str(future.result() or "")
            except Exception as exc:error=exc
            def apply():
                screen=screen_ref()
                if screen is None:return
                screen._sharp_detail_pending.discard(identity)
                if getattr(screen,"_sharp_detail_requested",{}).get(widget)!=identity:return
                if error is not None:
                    optional_failure("ui.details_sharp_async",error);return
                if getattr(screen,"_screen_closed",False):return
                if cancel_event is not None and cancel_event.is_set():return
                if path==source:screen._sharp_detail_exact_sources.add(identity)
                if path and os.path.isfile(path):
                    try:
                        if screen[widget].instance is not None:screen[widget].instance.setPixmapFromFile(path)
                    except Exception as exc:optional_failure("ui.details_sharp_async_apply",exc)
            try:reactor.callFromThread(apply)
            except Exception:
                pass  # UI writes must stay on the reactor thread.
        try:
            task_id=hashlib.sha1((source+"|"+str(key)+"|"+str(tuple(target_size))+"|"+str(id(self))).encode("utf-8","ignore")).hexdigest()[:20]
            future=_DETAIL_PREFETCH_EXECUTOR.submit(work,priority=1,_task_key="details-sharp:%s"%task_id)
            self._track_details_future(future)
            future.add_done_callback(done)
            try:self._async_set_poll_interval(120)
            except Exception:pass
        except Exception as exc:
            self._sharp_detail_pending.discard(identity)
            optional_failure("ui.details_sharp_async_submit",exc)

    def _sharp_detail_chrome_asset(self, source, key, target_size):
        """Return an exact-size nine-slice copy so Enigma2 never blurs rounded glass corners."""
        try:
            source=str(source or "")
            if not source or not os.path.isfile(source):return source
            tw,th=[int(x) for x in target_size]
            from PIL import Image as _SharpImg
            with _SharpImg.open(source) as _probe:
                sw,sh=_probe.size
            if (sw,sh)==(tw,th):return source
            out=self._sharp_detail_chrome_cache_path(source,key,(tw,th))
            if not out:return source
            os.makedirs(os.path.dirname(out),mode=0o700,exist_ok=True)
            if _valid_cache_file(out):return out
            with _SharpImg.open(source) as im:
                im=im.convert("RGBA");sw,sh=im.size
                # Preserve the source corners and edge glow; stretch only the centers.
                cx=max(10,min(38,sw//5,tw//5));cy=max(8,min(22,sh//4,th//4))
                left=right=cx;top=bottom=cy
                canvas=_SharpImg.new("RGBA",(tw,th),(0,0,0,0))
                sx=(0,left,sw-right,sw);sy=(0,top,sh-bottom,sh)
                dx=(0,left,tw-right,tw);dy=(0,top,th-bottom,th)
                for yi in range(3):
                    for xi in range(3):
                        tile=im.crop((sx[xi],sy[yi],sx[xi+1],sy[yi+1]))
                        size=(dx[xi+1]-dx[xi],dy[yi+1]-dy[yi])
                        res=getattr(getattr(_SharpImg,"Resampling",_SharpImg),"LANCZOS",getattr(_SharpImg,"LANCZOS",1))
                        if tile.size!=size:tile=tile.resize(size,res)
                        canvas.paste(tile,(dx[xi],dy[yi]))
                _tmp="%s.tmp.%d.%d"%(out,os.getpid(),threading.get_ident())
                try:
                    canvas.save(_tmp,"PNG",optimize=True)
                    os.replace(_tmp,out)
                finally:
                    if os.path.exists(_tmp):
                        try:os.unlink(_tmp)
                        except OSError:pass
            return out
        except Exception as exc:
            optional_failure("ui.details_sharp_chrome",exc)
            return source

    def _apply_detail_chrome(self, chrome):
        chrome=None  # Always use fixed glass for Details/Seasons/Episodes boxes; only dynamic_bg behind poster is adaptive
        # release: cast strip is generated natively at 1318x50 by the SAME
        # dynamic-glass recipe as genre_detail. Never stretch the 680px genre
        # bitmap across the cast row; that was the source of broken end-caps.
        try:
            chrome=dict(chrome or {}) if isinstance(chrome,dict) else {}
            # GUI-thread firewall: never invoke the Pillow chrome builder here.
            # The screen paints neutral/cached glass immediately and
            # _schedule_poster_visuals() builds any missing adaptive assets on the
            # bounded background executor, then reapplies them in-place.
            if chrome:
                self._details_visual_state["chrome"]=dict(chrome)
        except Exception as exc:optional_failure("ui.silent_guard",exc)
        for old_widget in ("accent_frame","poster_card_bg","poster_border_overlay"):
            try:
                comp=self[old_widget]
                if getattr(comp,"instance",None) is not None:
                    try:comp.instance.setPixmap(None)
                    except Exception:pass
                comp.hide()
            except Exception:
                pass
        mapping={
            "panel_bg":("panel_detail","us66_neutral_panel.png"),
            "overview_bg":("overview_detail","us89_overview_card.png"),
            "cast_card_bg":("cast_detail","us66_neutral_pill_genre.png"),
            "poster_footer_bg":("poster_footer_detail","us66_neutral_poster_footer.png"),
            "imdb_pill_bg":("quality","fixed_green_details/quality.png"),
            "tmdb_pill_bg":("quality","fixed_green_details/quality.png"),
            "quality_pill_bg":("quality","fixed_green_details/quality.png"),
            "year_pill_bg":("year","fixed_green_details/year.png"),
            "runtime_pill_bg":("runtime","fixed_green_details/quality.png"),
            "country_pill_bg":("country","us66_neutral_pill_country.png"),
            "genre_pill_bg":("genre_detail","us66_neutral_pill_genre.png"),
        }
        # R5.14: the cold state is the fixed-green clean glass (same material as
        # Cinematic's first paint), never the old navy neutral boxes.
        try:
            from .ui_fixed_glass import fixed_details_chrome as _fixed_green_details
            _fixed_green=_fixed_green_details() or {}
        except Exception as exc:
            optional_failure("ui.fixed_green_details",exc);_fixed_green={}
        for widget,(key,fallback) in mapping.items():
            try:
                try:
                    component=self[widget]
                except Exception:
                    continue
                # R5.449: Seasons/Episodes have the EXACT same panel, overview,
                # cast and pill geometries as Details. Never substitute the
                # smaller legacy chrome; use the inherited cached asset directly.
                path=(chrome or {}).get(key) if isinstance(chrome,dict) else None
                if not path or not os.path.isfile(path):path=_fixed_green.get(key) or (asset(fallback) if fallback else None)
                _exact={"panel_detail":(1410,360),"overview_detail":(1318,170),"cast_detail":(1318,50),"genre_detail":(680,50),"poster_footer_detail":(360,86),"quality":(150,50),"year":(130,50),"runtime":(150,50),"country":(160,50)}.get(key)
                inst=component.instance
                if inst is not None and path and os.path.isfile(path):
                    try:inst.setPixmap(None)
                    except Exception:pass
                    inst.setPixmapFromFile(path);self[widget].show()
                    if _exact:
                        target=(int(inst.size().width()),int(inst.size().height()))
                        self._queue_sharp_detail_chrome_asset(widget,path,key,target)
            except Exception as exc:optional_failure("ui.detail_chrome_apply",exc)
        self._apply_poster_laser_outline(chrome)
        for widget in ("rating_ring","rating_source","imdb_text","poster_match_text","status"):
            try:self[widget].hide()
            except Exception as exc:optional_failure("ui.detail_rating_hide",exc)
        for widget in ("tmdb_pill_bg","imdb_pill_bg"):
            try:self[widget].hide()
            except Exception:pass
        for widget in ("poster_footer_bg","rating_score","poster_imdb_logo","poster_imdb_value"):
            try:self[widget].show()
            except Exception as exc:optional_failure("ui.detail_rating_show",exc)

    def _detail_quality_value(self):
        item=self.item if isinstance(self.item,dict) else {}
        values=[]
        def walk(v,depth=0):
            if depth>4:return
            if isinstance(v,dict):
                for k,x in v.items():
                    if str(k).lower() in ("password","token","cookie"):continue
                    walk(x,depth+1)
            elif isinstance(v,(list,tuple)):
                for x in v[:40]:walk(x,depth+1)
            elif v is not None:
                values.append(str(v))
        walk(item)
        joined=" ".join(values).upper()
        # Explicit catalogue text wins immediately: title, description and all
        # portal metadata. This is intentionally checked before runtime cache.
        if re.search(r"\b(?:4K|UHD|2160P?|3840\s*[Xx×]\s*2160)\b",joined):return "4K"
        if re.search(r"\b(?:FULL[ ._-]?HD|FHD|1080P?|1920\s*[Xx×]\s*1080)\b",joined):return "FHD"
        if re.search(r"\b(?:HD|720P?|1280\s*[Xx×]\s*720)\b",joined):return "HD"
        if re.search(r"\b(?:SD|576P?|480P?|720\s*[Xx×]\s*(?:576|480))\b",joined):return "SD"
        h=str(item.get("height") or item.get("video_height") or item.get("resolution_height") or item.get("stream_height") or "").strip()
        w=str(item.get("width") or item.get("video_width") or item.get("resolution_width") or item.get("stream_width") or "").strip()
        try:
            hv=int(float(re.sub(r"[^0-9.]","",h) or 0)); wv=int(float(re.sub(r"[^0-9.]","",w) or 0))
            if hv>=2000 or wv>=3500:return "4K"
            if hv>=1000 or wv>=1800:return "FHD"
            if hv>=700 or wv>=1200:return "HD"
            if hv>=400 or wv>=640:return "SD"
        except Exception as exc:optional_failure("ui.silent_guard",exc)
        try:
            cached=load_content_quality(self.profile,self.media_type,getattr(self,"_portal_item",item))
            if cached:return cached
        except Exception as exc:optional_failure("ui.quality_cache_read",exc)
        return ""

    def _refresh_detail_visuals(self):
        # R5.464: certification owns the former quality slot. No AUTO/badge overlay.
        for name in ("quality_logo", "quality_text"):
            try:self[name].hide()
            except Exception:pass
        runtime_asset = "metadata_icons_premium/duration_32.png" if self.media_type == "vod" else "metadata_icons_premium/seasons_32.png"
        self._set_widget_pixmap("runtime_icon", runtime_asset)

        country_raw = getattr(self,"_country_raw","") or self.item.get("country_code") or self.item.get("country") or self["country_text"].getText() or ""
        country_value = self._normalized_country(country_raw)
        try:self["country_text"].setText(country_value)
        except Exception as exc:optional_failure("ui",exc)
        self._fit_country_font()
        self._set_widget_pixmap("country_flag", self._country_flag_asset(country_raw))
        try:
            self._fit_compact_text("quality_text",max_size=21,min_size=11,padding=12)
            self._fit_compact_text("year_text",max_size=22,min_size=12,padding=8)
            self._fit_compact_text("runtime_text",max_size=24,min_size=18,padding=4)
            self._fit_compact_text("genre_text",max_size=26,min_size=17,padding=16)
        except Exception as exc:optional_failure("ui.detail_visual_font_refresh",exc)

        imdb_raw = self["imdb_text"].getText() or self.item.get("rating_imdb") or self.item.get("imdb_rating") or ""
        imdb_value = self._extract_numeric_rating(imdb_raw)
        if not imdb_value:
            imdb_value = "N/A" if str(imdb_raw).strip().upper().find("N/A") >= 0 else "--"
        try:self["poster_imdb_value"].setText(str(imdb_value)[:4])
        except Exception as exc:optional_failure("ui",exc)
        self._set_widget_pixmap("poster_imdb_logo", "us65_logo_imdb_94x36.png")

        match_text = _("TMDb • portal metadata")
        if isinstance(getattr(self, "_tmdb_data", None), dict) and self._tmdb_data.get("matched"):
            if str(self._tmdb_data.get("identity_source") or "")=="portal_payload":
                match_text=_("Portal metadata • HDD")
            else:
                confidence=int(round(float(self._tmdb_data.get("confidence") or 0)*100))
                match_text = (_("TMDB • %d%% match") % confidence) if confidence else _("TMDb linked")
        elif self["rating_source"].getText():
            match_text = self["rating_source"].getText()
        try:self["poster_match_text"].setText(match_text[:34])
        except Exception as exc:optional_failure("ui",exc)
