# -*- coding: utf-8 -*-
"""History action, EPG viewer and playback settings.

Methods moved verbatim out of ``PortalBrowserScreen`` (ui_screens_browser.py); behaviour is unchanged.
This module is imported by ui_screens_browser.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str, int, us_text_callback, native_text
from .ui_screens_browser import (
    _,
    os,
    show_notice,
    time,
)


class BrowserToolsMixin(object):
    """History action, EPG viewer and playback settings."""

    def _history_action(self,action):
        idx=self["list"].getSelectedIndex()
        if not (0<=idx<len(self.content_items)):return
        item=self.content_items[idx];media_type=item.get("_saved_media_type") or self.media_type or "vod"
        clean=dict(item);clean.pop("_saved_media_type",None);clean.pop("_history_position",None);clean.pop("_history_duration",None);clean.pop("_history_completed",None)
        try:
            if action=="remove_history":remove_from_history(self.profile,media_type,clean);message=_("Removed from Continue Watching")
            else:mark_watched(self.profile,media_type,clean,action=="mark_watched");message=_("Marked watched") if action=="mark_watched" else _("Marked unwatched")
            self._show_saved_entries(load_continue_watching(),"Continue Watching");self["status"].setText(message)
        except Exception as exc:self["status"].setText(_("History update failed: %s")%exc)

    def _clear_history_confirmed(self,answer):
        if not answer:return
        try:clear_history(self.profile);self._show_saved_entries([],"Continue Watching");self["status"].setText(_("Continue Watching cleared"))
        except Exception as exc:self["status"].setText(_("Clear failed: %s")%exc)

    def show_selected_epg(self):
        if self.level != "items" or self.media_type != "itv":
            self["status"].setText(_("EPG is available for live channels"))
            return
        idx = self["list"].getSelectedIndex()
        if not (0 <= idx < len(self.content_items)):
            return
        item = self.content_items[idx]
        channel_id = item.get("id") or item.get("ch_id")
        if not channel_id:
            self["status"].setText(_("Channel has no EPG identifier"))
            return
        self._epg_record_channel = dict(item)
        self["status"].setText(_("Loading EPG..."))
        now = int(time.time())
        hours = int(load_settings().get("epg_hours", 4) or 4)
        def ok(rows):
            choices=[]
            for row in rows[:40]:
                if not isinstance(row, dict):
                    continue
                title=_clean_display_text(row.get("name") or row.get("title") or row.get("descr") or "Programme", 100)
                begin,end=event_times(row)
                if begin:
                    stamp=time.strftime("%H:%M",time.localtime(begin))
                    if end:
                        stamp += "–" + time.strftime("%H:%M",time.localtime(end))
                else:
                    stamp=_clean_display_text(row.get("time") or row.get("start") or "",24)
                choices.append(((stamp+"  "+title).strip(), row))
            if not choices:
                show_notice(self.session, _("No EPG data returned"), timeout=8, owner=self)
                self["status"].setText(_("Ready"))
                return
            self.session.openWithCallback(self._epg_program_selected,ChoiceBox,title=_("EPG • choose a programme"),list=choices)
            self["status"].setText(_("Choose a programme"))
        self._run_async(
            lambda: self.client.full_epg(channel_id, now - 3600, now + (hours * 3600), max_pages=120),
            ok, lambda e: self["status"].setText(_("EPG failed: %s") % e)
        )

    def _epg_program_selected(self, choice):
        if not choice or not isinstance(choice[1], dict):
            self["status"].setText(_("Ready"))
            return
        self._selected_epg_program = dict(choice[1])
        self.session.openWithCallback(
            self._epg_program_action, ChoiceBox, title=str(choice[0])[:120],
            list=[(_("Record this programme"), "record"), (_("Programme details"), "details")],
        )

    def _epg_program_action(self, choice):
        if not choice:
            return
        program=getattr(self,"_selected_epg_program",{}) or {}
        channel=getattr(self,"_epg_record_channel",{}) or {}
        if choice[1] == "details":
            title=str(program.get("name") or program.get("title") or program.get("descr") or "Programme")
            description=str(program.get("description") or program.get("descr") or program.get("plot") or _("No programme description"))
            self.session.open(MessageBox,title+"\n\n"+description,MessageBox.TYPE_INFO,timeout=15)
            return
        if choice[1] != "record":
            return
        self["status"].setText(_("Preparing recording timer..."))
        cfg=load_settings()
        def work():
            return prepare_portal_recording(self.profile,channel,program,cfg.get("service_type",4097))
        def installed(prepared):
            try:
                timer=install_recording_timer(self.session,prepared)
                begin=int(getattr(timer,"begin",prepared.get("begin",0)) or 0)
                self["status"].setText(_("Recording timer added • %s") % (time.strftime("%H:%M",time.localtime(begin)) if begin else _("scheduled")))
            except Exception as exc:
                self["status"].setText(_("Timer failed: %s") % exc)
        self._run_async(work,installed,lambda e:self["status"].setText(_("Timer failed: %s")%e))

    def open_playback_settings(self):
        cfg=load_settings()
        def work(handle):
            files=0;size=0
            if not hdd_read_ready(force=True):return files,0.0
            try:
                with os.scandir(IMAGE_CACHE_DIR) as entries:
                    for entry in entries:
                        if handle.cancelled():break
                        try:
                            if entry.is_file(follow_symlinks=False):
                                size+=entry.stat(follow_symlinks=False).st_size;files+=1
                        except OSError:continue
            except OSError as exc:optional_failure("ui.cache_stats",exc)
            return files,size/(1024.0*1024.0)
        def done(stats):self._open_playback_settings_with_stats(cfg,stats)
        if self._run_async(work,done,lambda exc:done((0,0.0))):
            self["status"].setText(_("Loading settings…"))

    def _open_playback_settings_with_stats(self,cfg,stats):
        cache_files,cache_mb=stats
        choices = [
            (_("Playback engine  •  %s") % cfg.get("service_type", 4097), "service"),
            (_("Portal timeout  •  %ss") % cfg.get("timeout", 10), "timeout"),
            (_("EPG window  •  %sh") % cfg.get("epg_hours", 4), "epg"),
            (_("Poster loading  •  %s") % (_("ON") if cfg.get("load_images", True) else _("OFF")), "images"),
            (_("Clear image cache  •  %d files / %.1f MB") % (cache_files, cache_mb), "clear_cache"),
            (_("Visible home sections"), "sections"),
            (_("Parental lock  •  %s") % (_("ON") if cfg.get("parental_lock", False) else _("OFF")), "parental"),
            (_("Change parental PIN"), "pin"),
            (_("Manage hidden categories"), "hidden"),
            (_("Interface  •  Nova FHD / 1920×1080"), "interface"),
            (_("Clean technical prefixes  •  %s") % (_("ON") if cfg.get("clean_titles",True) else _("OFF")), "clean_titles"),
            (_("Quality badges  •  %s") % (_("ON") if cfg.get("show_quality_badges",True) else _("OFF")), "quality_badges"),
            (_("Player Engine Lock  •  ON"), "engine_lock_info"),
        ]
        self.session.openWithCallback(self._premium_setting_selected, ChoiceBox, title=_("Portal settings"), list=choices)


    def _premium_setting_selected(self, choice):
        if not choice:
            return
        action = choice[1]
        if action == "service":
            current = load_settings().get("service_type", 4097)
            from . import us_env as _us_env
            if _us_env.IS_DREAMOS:
                choices = [("DreamOS Stream Player (8193)", 8193), ("DreamOS GStreamer (4097)", 4097), ("DreamOS DVB / Live TS (1)", 1)]
                if _us_env.os.path.exists("/usr/bin/gstplayer"): choices.append(("GstPlayer (5001)", 5001))
                if _us_env.os.path.exists("/usr/bin/exteplayer3"): choices.append(("ExtePlayer3 (5002)", 5002))
            else:
                choices = [("DVB / native (1)", 1), ("IPTV / GStreamer (4097)", 4097), ("GstPlayer (5001)", 5001), ("ExtePlayer3 (5002)", 5002), ("ServiceApp / DreamOS (8193)", 8193)]
            self.session.openWithCallback(self._service_type_selected, ChoiceBox, title=_("Playback service type (current: %s)") % current, list=choices)
        elif action == "timeout":
            choices = list((_("%d seconds") % x, x) for x in (5, 8, 10, 15, 20, 30))
            self.session.openWithCallback(lambda c: self._save_numeric_setting("timeout", c), ChoiceBox, title=_("Portal timeout"), list=choices)
        elif action == "epg":
            choices = list((_("%d hours") % x, x) for x in (2, 4, 6, 8, 12, 24))
            self.session.openWithCallback(lambda c: self._save_numeric_setting("epg_hours", c), ChoiceBox, title=_("EPG window"), list=choices)
        elif action in ("clean_titles", "quality_badges", "remember_location"):
            key = {"quality_badges":"show_quality_badges"}.get(action, action)
            enabled = not bool(load_settings().get(key, True)); save_settings({key: enabled})
            self["status"].setText(_("Setting updated"))
            self.refresh_current()
        elif action == "engine_lock_info":
            show_notice(self.session, _("Playback engine is locked to the value selected under Playback engine. Automatic Smart Engine switching is disabled."), timeout=7, owner=self)
        elif action == "images":
            enabled = not bool(load_settings().get("load_images", True))
            save_settings({"load_images": enabled})
            self._image_load_images=bool(enabled);self._selection_cfg_mono=0.0
            self["status"].setText(_("Poster loading enabled") if enabled else _("Poster loading disabled"))
        elif action == "clear_cache":
            # R5.63: thousands of unlinks must not freeze the GUI thread.
            def _clear_cache_worker():
                try: cleanup_image_cache(max_files=0, max_bytes=0)
                except Exception as exc: optional_failure("cache-clear", exc)
                try: prune_persistent_cache(0)
                except Exception as exc: optional_failure("cache-prune", exc)
            try:
                _ct = _us_env.threading
                _ct.Thread(target=_clear_cache_worker, name="ultrastalker-clear-cache", daemon=True).start()
            except Exception:
                _clear_cache_worker()
            self["status"].setText(_("Artwork + metadata cache cleaned"))
        elif action == "sections":
            self.open_section_settings()
        elif action == "parental":
            self._set_parental_lock(not bool(load_settings().get("parental_lock",False)))
        elif action == "pin":
            self.session.openWithCallback(us_text_callback(self._save_parental_pin), InputBox, title=native_text(_("New parental PIN (4-8 digits)")), text=native_text(""), maxSize=8, type=Input.PIN)
        elif action == "hidden":
            self.show_hidden_categories()
        elif action == "interface":
            show_notice(self.session, _("Nova FHD is the only interface in this build. All plugin screens use the same 1920×1080 design system."), timeout=8, owner=self)

    def _save_numeric_setting(self, key, choice):
        if choice:
            save_settings({key: int(choice[1])})
            self["status"].setText(_("Setting saved"))

    def _channel_mode_selected(self, choice):
        if choice:
            save_settings({"channel_list_mode": choice[1]}); self["status"].setText(_("Channel layout saved: %s") % choice[0])
            self.refresh_current()

    def _service_type_selected(self, choice):
        if choice:
            save_settings({"service_type": int(choice[1])})
            self["status"].setText(_("Playback service type saved: %s") % choice[1])
