# -*- coding: utf-8 -*-
"""Single heavy-image budget for receiver stability.

All Pillow-heavy generation paths share one semaphore so TMDB hydration,
Home, Grid, Details and Player cannot decode/generate large images in parallel.
Network concurrency remains controlled separately by the global hydration queue.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .. import us_env as _us_env
from ..us_env import int, max, native_str
threading = _us_env.threading
from contextlib import contextmanager

_IMAGE_WORK_SEMAPHORE = threading.BoundedSemaphore(1)
_IMAGE_WORK_LOCAL = threading.local()
_MAIN_THREAD = threading.main_thread()

@contextmanager
def image_work(label=""):
    # Re-entrant for the same worker thread: a high-level image builder may call
    # a lower-level normalized/derived builder while it already owns the budget.
    depth=int(getattr(_IMAGE_WORK_LOCAL,"depth",0) or 0)
    acquired=False
    if depth<=0:
        if threading.current_thread() is _MAIN_THREAD:
            # The Enigma2 GUI thread must never sit behind a long background
            # Pillow job (that froze Cinematic after a cache rebuild).  Wait
            # never wait: take the lane if free, otherwise run the small GUI-side job anyway.
            acquired=_IMAGE_WORK_SEMAPHORE.acquire(False)
        else:
            _IMAGE_WORK_SEMAPHORE.acquire();acquired=True
    _IMAGE_WORK_LOCAL.depth=depth+1
    try:
        yield
    finally:
        _IMAGE_WORK_LOCAL.depth=max(0,int(getattr(_IMAGE_WORK_LOCAL,"depth",1) or 1)-1)
        if acquired:_IMAGE_WORK_SEMAPHORE.release()

def image_budgeted(func):
    def wrapped(*args, **kwargs):
        with image_work(getattr(func, "__name__", "image")):
            return func(*args, **kwargs)
    wrapped.__name__ = native_str(getattr(func, "__name__", "image_budgeted"))
    wrapped.__doc__ = getattr(func, "__doc__", None)
    return wrapped
