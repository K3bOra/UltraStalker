# -*- coding: utf-8 -*-
"""Selection, bulk move/delete/disable, reorder mode and paging.

Methods moved verbatim out of ``PortalListScreen`` (ui_screens_portallist.py); behaviour is unchanged.
This module is imported by ui_screens_portallist.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, max, min, us_clear, us_text_callback, native_text
from .ui_screens_portallist import (
    InputBox,
    MessageBox,
    PT_COLS,
    VirtualKeyBoard,
    _,
)


class PortalListSelectMixin(object):
    """Selection, bulk move/delete/disable, reorder mode and paging."""

    def _toggle_portal_selection_and_advance(self):
        idx = self._index()
        if idx is None or not self.profiles:
            return
        if idx in self._portal_selected:
            self._portal_selected.remove(idx)
        else:
            self._portal_selected.add(idx)
        # Update only the current row first, then advance automatically exactly
        # like Category selection.  The list itself owns page transitions.
        try:
            self["list"].update_icon_row(idx, self._portal_row_tuple(idx, idx))
        except Exception:
            self._render_portal_rows(idx)
        if idx + 1 < len(self.profiles):
            try:self["list"].moveToIndex(idx + 1)
            except Exception as exc:optional_failure("ui.portal_select_advance", exc)
        self._selection_changed()

    def _selected_portal_targets(self):
        if self._portal_select_mode:
            return [self.profiles[i] for i in sorted(self._portal_selected) if 0 <= i < len(self.profiles)]
        idx = self._index()
        return [self.profiles[idx]] if idx is not None and 0 <= idx < len(self.profiles) else []

    def _request_delete_selected_portals(self):
        targets = self._selected_portal_targets()
        if not targets:
            self["status"].setText(_("No portal selected"))
            return
        self._direct_delete_targets = list(targets)
        prompt = (_("Delete %d selected portals") % len(targets)) + "\n\n" + _("Permanently delete selected portal from saved profiles, imports, cached sessions and plugin-owned data?")
        self.session.openWithCallback(self._direct_delete_confirmed, MessageBox, prompt, MessageBox.TYPE_YESNO)

    def _direct_delete_confirmed(self, answer):
        if not answer:
            return
        targets = list(getattr(self, "_direct_delete_targets", []) or [])
        deleted = 0
        failed = 0
        for profile in targets:
            try:
                result = permanently_delete_profile(profile, session=self.session, purge_related=True) or {}
                if result.get("deleted", True): deleted += 1
                else: failed += 1
            except Exception as exc:
                failed += 1
                optional_failure("ui.portal_direct_bulk_delete", exc)
        self._portal_select_mode = False
        us_clear(self._portal_selected)
        self._sync_profiles_from_disk()
        if not self.profiles:
            self._tab_focus = True
        self.refresh()
        self["status"].setText(_("Deleted %d portals") % deleted if not failed else _("Deleted %d portals • %d failed") % (deleted, failed))

    def _request_disable_portals(self):
        targets = self._selected_portal_targets()
        if not targets:
            self["status"].setText(_("No portal selected"))
            return
        self._direct_disable_targets = list(targets)
        prompt = _("Disable %d selected portals?") % len(targets)
        self.session.openWithCallback(self._direct_disable_confirmed, MessageBox, prompt, MessageBox.TYPE_YESNO)

    def _direct_disable_confirmed(self, answer):
        if not answer:
            return
        targets = list(getattr(self, "_direct_disable_targets", []) or [])
        try:
            disable_profiles(targets)
            count = len(targets)
            self._portal_select_mode = False
            us_clear(self._portal_selected)
            self._sync_profiles_from_disk()
            if not self.profiles:
                self._tab_focus = True
            self.refresh()
            self["status"].setText(_("%d disabled") % count)
        except Exception as exc:
            self["status"].setText(_("Disabling failed portals failed: %s") % exc)

    @staticmethod
    def _bulk_profile_key(profile):
        p = profile if isinstance(profile, dict) else {}
        return (
            str(p.get("portal") or "").rstrip("/").lower(),
            str(p.get("mac") or "").strip().upper(),
            str(p.get("source_type") or "stalker").strip().lower(),
        )

    def _begin_bulk_move(self, targets):
        if self._busy or not self.profiles:
            return
        wanted = {self._bulk_profile_key(p) for p in (targets or []) if isinstance(p, dict)}
        # Resolve against the parent's CURRENT order. This prevents stale manager
        # snapshots from moving the wrong row after an external profile edit.
        block = list(p for p in self.profiles if self._bulk_profile_key(p) in wanted)
        if not block:
            self["status"].setText(_("No selected portals are available to move"))
            return
        self._reorder_mode = False
        self._bulk_move_profiles = list(block)
        self._bulk_move_mode = True
        self["green"].setText(_("Place Here"))
        self["blue"].setText(_("Disable"))
        self._fit_portal_color_keys()
        # Start on the first selected source, exactly where the user left off,
        # then let normal UP/DOWN/LEFT/RIGHT page navigation choose the slot.
        first_key = self._bulk_profile_key(block[0])
        first_idx = 0
        for pos, profile in enumerate(self.profiles):
            if self._bulk_profile_key(profile) == first_key:
                first_idx = pos
                break
        try:
            self["list"].moveToIndex(first_idx)
            self._selection_changed()
        except Exception as exc:
            optional_failure("ui.portal_bulk_move_anchor", exc)
        self["status"].setText(_("Move %d selected • ARROWS choose destination • GREEN Place Here • BACK Cancel") % len(block))

    def _cancel_bulk_move(self):
        count = len(self._bulk_move_profiles)
        self._bulk_move_mode = False
        self._bulk_move_profiles = []
        self["green"].setText(_("Move"))
        self["blue"].setText(_("Disable"))
        self._fit_portal_color_keys()
        self["status"].setText(_("Move cancelled") if count else _("Portal order unchanged"))

    def _place_bulk_move(self):
        if not self._bulk_move_mode or not self._bulk_move_profiles or not self.profiles:
            return
        destination = self._index()
        if destination is None:
            destination = 0
        destination = max(0, min(int(destination), len(self.profiles) - 1))
        selected_keys = {self._bulk_profile_key(p) for p in self._bulk_move_profiles}
        block = list(p for p in self.profiles if self._bulk_profile_key(p) in selected_keys)
        remaining = list(p for p in self.profiles if self._bulk_profile_key(p) not in selected_keys)
        if not block:
            self._cancel_bulk_move()
            self["status"].setText(_("Selected portals are no longer available"))
            return
        # Destination is a POSITION, not an anchor row. Thus stopping on visible
        # row 1 means the moved block starts at #1, row 10 means it starts at #10.
        insert_at = max(0, min(destination, len(remaining)))
        reordered = remaining[:insert_at] + block + remaining[insert_at:]
        previous = list(self.profiles)
        try:
            self._save_active_category_profiles(reordered)
        except Exception as exc:
            self.profiles = previous
            self.refresh()
            self["status"].setText(_("Move save failed: %s") % exc)
            return
        moved = len(block)
        self._bulk_move_mode = False
        self._bulk_move_profiles = []
        self["green"].setText(_("Move"))
        self["blue"].setText(_("Disable"))
        self._fit_portal_color_keys()
        target = max(0, min(insert_at, max(0, len(self.profiles) - 1)))
        self._render_portal_rows(target)
        try:self["list"].moveToIndex(target)
        except Exception as exc:optional_failure("ui.portal_bulk_move_focus", exc)
        self._selection_changed()
        self["status"].setText(_("Moved %d portals • block starts at position %d") % (moved, target + 1))

    def rename_selected_portal(self):
        idx = self._index()
        if idx is None or self._busy:
            return
        self._editing_profile = self.profiles[idx]
        current_name = str(self._editing_profile.get("name") or (_("Portal Server %d") % (idx + 1)))
        if VirtualKeyBoard is not None:
            try:
                self.session.openWithCallback(us_text_callback(self._portal_renamed), VirtualKeyBoard, title=native_text(_("Portal name")), text=native_text(current_name))
                return
            except Exception as exc:
                optional_failure("ui.portal_rename_keyboard", exc)
        self.session.openWithCallback(
            us_text_callback(self._portal_renamed), InputBox, title=native_text(_("Portal name")), text=native_text(current_name), maxSize=80
        )

    def _set_reorder_mode(self, enabled):
        enabled = bool(enabled and self.profiles and not self._busy and not self._bulk_move_mode)
        if enabled and not self._reorder_mode:
            self._reorder_original_profiles = list(self.profiles)
        self._reorder_mode = enabled
        self["green"].setText(_("Move"))
        self["blue"].setText(_("Disable"))
        self._fit_portal_color_keys()
        if self._reorder_mode:
            # Repaint immediately so the moving portal name turns red the very
            # moment GREEN/Move is pressed, before the first arrow key.
            try:
                _move_idx=self._index()
                self._render_portal_rows(0 if _move_idx is None else _move_idx)
            except Exception as exc:
                optional_failure("ui.portal_reorder_visual_start", exc)
            self["status"].setText(_("Move portal  •  ARROWS choose position  •  OK Save  •  BACK Cancel"))
        else:
            self["status"].setText(_("Portal order saved"))

    def _finish_reorder(self, commit=True):
        if not self._reorder_mode:
            return
        original = list(getattr(self, "_reorder_original_profiles", []) or [])
        current_idx = self._index()
        if commit:
            try:
                self._save_active_category_profiles(self.profiles)
                self["status"].setText(_("Portal order saved"))
            except Exception as exc:
                if original:
                    self.profiles = original
                self["status"].setText(_("Order save failed: %s") % exc)
        else:
            if original:
                self.profiles = original
            self["status"].setText(_("Move cancelled"))
        self._reorder_mode = False
        self._reorder_original_profiles = []
        self["green"].setText(_("Move"))
        self["blue"].setText(_("Disable"))
        self._fit_portal_color_keys()
        if self.profiles:
            target = max(0, min(int(current_idx or 0), len(self.profiles)-1))
            self._render_portal_rows(target)
            try:self["list"].moveToIndex(target)
            except Exception as exc:optional_failure("ui.portal_reorder_focus", exc)
            self._selection_changed()

    def toggle_reorder_mode(self):
        if self._busy or not self.profiles:
            return
        if self._reorder_mode:
            self._finish_reorder(commit=True)
        else:
            self._set_reorder_mode(True)

    # R5.69 grid navigation: LEFT/RIGHT move one tile, UP/DOWN one row (3).
    def _pt_goto(self, target):
        if not self.profiles:
            return
        target = max(0, min(len(self.profiles) - 1, int(target)))
        try:
            self["list"].moveToIndex(target)
        except Exception as exc:
            optional_failure("ui.portal_grid_nav", exc)
        self._selection_changed()

    def _pt_step(self, delta):
        if self._reorder_mode:
            self._move_selected_portal(delta)
            return
        if not self.profiles:
            return
        n = len(self.profiles)
        idx = self._index()
        if idx is None:
            idx = 0
        target = idx + int(delta)
        if abs(int(delta)) == 1:
            target = max(0, min(n - 1, target))
        elif target < 0:
            col = idx % PT_COLS
            last_row = (n - 1) // PT_COLS
            target = min(n - 1, last_row * PT_COLS + col)
        elif target > n - 1:
            target = (n - 1) if (idx // PT_COLS) < ((n - 1) // PT_COLS) else (idx % PT_COLS)
        self._pt_goto(target)

    def _portal_up(self):
        if getattr(self, "_tab_focus", False):
            return
        self._pt_step(-PT_COLS)

    def _portal_down(self):
        if getattr(self, "_tab_focus", False):
            return
        self._pt_step(PT_COLS)

    def _portal_prev_page(self):
        if getattr(self, "_tab_focus", False) and not (self._reorder_mode or self._bulk_move_mode or self._portal_select_mode):
            self._switch_category_step(-1)
            return
        self._pt_step(-1)

    def _portal_next_page(self):
        if getattr(self, "_tab_focus", False) and not (self._reorder_mode or self._bulk_move_mode or self._portal_select_mode):
            self._switch_category_step(1)
            return
        self._pt_step(1)

    def _move_selected_portal(self, delta):
        idx = self._index()
        if idx is None or not self.profiles:
            return
        target = max(0, min(len(self.profiles)-1, idx + int(delta)))
        if target == idx:
            self["status"].setText(_("Already at the top") if delta < 0 else _("Already at the bottom"))
            return
        moving = self.profiles.pop(idx)
        self.profiles.insert(target, moving)
        self._render_portal_rows(target)
        try:self["list"].moveToIndex(target)
        except Exception as exc:optional_failure("ui.portal_reorder_move", exc)
        self._selection_changed()
        self["status"].setText(_("Move portal  •  Position %d of %d  •  OK Save  •  BACK Cancel") % (target+1, len(self.profiles)))
