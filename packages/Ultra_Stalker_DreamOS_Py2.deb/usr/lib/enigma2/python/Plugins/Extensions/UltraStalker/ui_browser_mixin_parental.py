# -*- coding: utf-8 -*-
"""Parental locks, category pinning/hiding and account info.

Methods moved verbatim out of ``PortalBrowserScreen`` (ui_screens_browser.py); behaviour is unchanged.
This module is imported by ui_screens_browser.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, us_casefold, us_text_callback, native_text
from .ui_screens_browser import (
    _,
    _authorize_parental_change,
    _live_screen_class,
    _poster_grid3_screen,
    _profile_hidden_ids,
    _profile_hidden_update,
    _visibility_category_id,
    show_notice,
)


class BrowserParentalMixin(object):
    """Parental locks, category pinning/hiding and account info."""

    def open_global_search(self):
        self.session.open(PortalGlobalSearchScreen,self.profile,self.client)

    def toggle_current_category_pinned(self):
        if self.level!="genres" or not self.media_type:
            self["status"].setText(_("Open a category list first"));return
        idx=self["list"].getSelectedIndex()
        if not (0<=idx<len(self.content_items)):return
        item=self.content_items[idx]; gid=str(item.get("id") or item.get("genre_id") or item.get("name") or item.get("title") or "")
        cfg=load_settings(); pins=cfg.get("pinned_categories",{}); values=list(pins.get(self.media_type,[]))
        if gid in values: values.remove(gid); state=_("unpinned")
        else: values.append(gid); state=_("pinned")
        pins[self.media_type]=values; save_settings({"pinned_categories":pins}); self["status"].setText(_("Category %s")%state); self.load_genres(self.media_type)

    def toggle_current_category_protected(self):
        if self.level!="genres" or not self.media_type:self["status"].setText(_("Open a category list first"));return
        idx=self["list"].getSelectedIndex()
        if not (0<=idx<len(self.content_items)):return
        item=self.content_items[idx]
        gid=str(item.get("id") or item.get("genre_id") or item.get("name") or item.get("title") or "")
        cfg=load_settings()
        enabled=gid not in cfg.get("protected_categories",{}).get(self.media_type,[])
        self._set_category_protected(self.media_type,gid,enabled)

    def _set_category_protected(self,media_type,gid,enabled,_pin_authorized=False):
        if not enabled and not _pin_authorized:
            _authorize_parental_change(self,lambda:self._set_category_protected(media_type,gid,enabled,True),InputBox)
            return
        cfg=load_settings();protected=dict(cfg.get("protected_categories",{}))
        values=list(protected.get(media_type,[]))
        if enabled and gid not in values:values.append(gid)
        elif not enabled and gid in values:values.remove(gid)
        protected[media_type]=values;save_settings({"protected_categories":protected})
        self["status"].setText(_("Category %s")%(_("protected") if enabled else _("unprotected")))
        self.load_genres(media_type)

    def _open_media_with_parental(self, media_type):
        # Category-level protection replaces the old all-or-nothing VOD lock.
        # A cancelled Live preview/page request must never poison the next
        # Movies/Series/Live navigation action.
        try:self.client.reset_failure_backoff()
        except Exception as exc:optional_failure("ui.silent_guard",exc)
        self.load_genres(media_type)

    def _category_sensitive(self, media_type, item):
        cfg=load_settings();gid=str(item.get("id") or item.get("genre_id") or item.get("name") or item.get("title") or "")
        if gid in set(cfg.get("protected_categories",{}).get(media_type,[])):return True
        text=us_casefold(str(item.get("name") or item.get("title") or ""))
        return any(word in text for word in cfg.get("adult_keywords",[]))

    def _open_genre_with_parental(self, item, index=0):
        cfg=load_settings()
        if cfg.get("parental_lock") and cfg.get("parental_mode","pin")=="pin" and self._category_sensitive(self.media_type,item) and not parental_is_unlocked():
            self._pending_genre=(dict(item),int(index),self.media_type)
            self.session.openWithCallback(us_text_callback(self._parental_category_pin_done),InputBox,title=native_text(_("Parental PIN")),text=native_text(""),maxSize=8,type=Input.PIN);return
        self._open_genre_direct(item,index,self.media_type)

    def _open_genre_direct(self,g,index,media_type):
        genre_id=str(g.get("id") or g.get("genre_id") or g.get("category_id") or g.get("name") or g.get("title") or "*")
        category_title=_clean_display_text(g.get("title") or g.get("name") or g.get("category_name") or g.get("genre_name") or _("Result"),100) or _("Result")
        if media_type=="itv":
            screen = _live_screen_class(PremiumLiveGridScreen)
            live_categories=list(dict(x) for x in (getattr(self,"content_items",[]) or []) if isinstance(x,dict)) if getattr(self,"level","")=="genres" else []
            # Preserve the Browser's parental contract inside the in-player
            # category drawer. A PIN-protected category is not exposed there
            # until the existing parental session has already been unlocked.
            try:
                _pcfg=load_settings()
                if _pcfg.get("parental_lock") and _pcfg.get("parental_mode","pin")=="pin" and not parental_is_unlocked():
                    live_categories=list(x for x in live_categories if not self._category_sensitive("itv",x))
            except Exception as exc:
                optional_failure("ui.live_player_category_parental_filter",exc)
            self.session.openWithCallback(self._grid_returned,screen,self.profile,self.client,media_type,genre_id,category_title,live_categories)
            return
        else:
            cfg=load_settings();view_key="movies_view_mode" if media_type=="vod" else "series_view_mode"
            view_mode=str(cfg.get(view_key) or "cinematic").lower()
            screen=PremiumGlobalCinematicScreen if view_mode=="cinematic" else (PremiumBackdropGrid2Screen if view_mode=="backdrop2" else (PremiumBackdropGridScreen if view_mode=="backdrop" else (PremiumPosterGridScreen if view_mode=="poster_legacy" else (_poster_grid3_screen() if view_mode=="poster3" else PremiumPosterGridV2Screen))))
        self.session.openWithCallback(self._grid_returned,screen,self.profile,self.client,media_type,genre_id,category_title)

    def _parental_category_pin_done(self,value):
        if value is None:
            return
        cfg=load_settings();ok,message=parental_verify_pin(value,cfg)
        if ok:
            pending=getattr(self,"_pending_genre",None)
            if pending:self._open_genre_direct(pending[0],pending[1],pending[2])
            self._pending_genre=None
        else:
            self.session.open(MessageBox,message or _("Incorrect parental PIN"),MessageBox.TYPE_ERROR,timeout=6)

    def _set_parental_lock(self,enabled,_pin_authorized=False):
        if not _pin_authorized:
            _authorize_parental_change(self,lambda:self._set_parental_lock(enabled,True),InputBox)
            return
        cfg=load_settings()
        if enabled and parental_pin_is_default(cfg):
            self.session.openWithCallback(us_text_callback(self._save_parental_pin_and_enable),InputBox,
                title=native_text(_("Set parental PIN to enable lock (4-8 digits)")),text=native_text(""),maxSize=8,type=Input.PIN)
            return
        save_settings({"parental_lock":bool(enabled)})
        parental_lock_now()
        self["status"].setText(_("Parental lock enabled") if enabled else _("Parental lock disabled"))
        self.refresh_current()

    def _save_parental_pin(self, value,_pin_authorized=False):
        value=str(value or "")
        if value.isdigit() and 4 <= len(value) <= 8:
            if not _pin_authorized:
                _authorize_parental_change(self,lambda:self._save_parental_pin(value,True),InputBox)
                return
            save_settings(parental_hash_pin(value))
            parental_lock_now()
            self["status"].setText(_("Parental PIN saved securely"))
            self.refresh_current()
        elif value:
            show_notice(self.session,_("PIN must contain 4-8 digits"),timeout=5,title=_("Parental PIN"), owner=self)

    def _save_parental_pin_and_enable(self, value,_pin_authorized=False):
        value=str(value or "")
        if not value:
            self["status"].setText(_("Parental lock remains disabled"))
            self.refresh_current()
            return
        if not (value.isdigit() and 4 <= len(value) <= 8):
            show_notice(self.session,_("PIN must contain 4-8 digits. Parental Lock was not enabled."),timeout=5,title=_("Parental PIN"), owner=self)
            self.refresh_current()
            return
        if not _pin_authorized:
            _authorize_parental_change(self,lambda:self._save_parental_pin_and_enable(value,True),InputBox)
            return
        payload=parental_hash_pin(value)
        payload["parental_lock"]=True
        save_settings(payload)
        parental_lock_now()
        self["status"].setText(_("Parental PIN saved • Parental lock enabled"))
        self.refresh_current()

    def open_section_settings(self):
        cfg=load_settings(); rows=[]
        for label,key in ((_("Live TV"),"show_live"),(_("Movies"),"show_movies"),(_("Series"),"show_series"),(_("Catch-up TV"),"show_catchup")):
            rows.append(("%s  •  %s"%(label,_("ON") if cfg.get(key,True) else _("OFF")),key))
        self.session.openWithCallback(self._toggle_section,ChoiceBox,title=_("Visible home sections"),list=rows)

    def _toggle_section(self, choice):
        if choice:
            key=choice[1]; save_settings({key:not bool(load_settings().get(key,True))}); self._show_root(); self["status"].setText(_("Section visibility updated"))

    def _save_hidden_category_ids(self, values):
        cfg=load_settings();payload=_profile_hidden_update(cfg,self.profile,self.media_type,set(values or []));save_settings(payload);self._selection_cfg_mono=0.0

    def _start_category_selection(self,reset=True):
        if self.level!="genres" or self.media_type not in ("itv","vod","series"):
            self["status"].setText(_("Open a category list first"));return
        if not self.content_items:
            self["status"].setText(_("No visible categories to select • MENU can restore hidden categories"));return
        self._category_select_mode=True
        if reset:self._category_selected_ids=set()
        self._render_genre_rows()
        self["status"].setText(_("Selection mode • OK selects and moves down • MENU applies"))

    def _toggle_category_selection(self):
        if not self._category_select_mode or self.level!="genres":return
        idx=self["list"].getSelectedIndex()
        if not (0<=idx<len(self.content_items)):return
        gid=_visibility_category_id(self.content_items[idx])
        if not gid:return
        if gid in self._category_selected_ids:self._category_selected_ids.remove(gid)
        else:self._category_selected_ids.add(gid)
        self._render_genre_rows()
        if idx+1<len(self.content_items):
            try:self["list"].moveToIndex(idx+1)
            except Exception as exc:optional_failure("ui.category_select_next",exc)
        self._force_category_list_redraw()
        self["status"].setText(_("Selected categories: %d • MENU to apply")%len(self._category_selected_ids))

    def _select_all_visible_categories(self):
        if not self._category_select_mode:return
        self._category_selected_ids=set(_visibility_category_id(e) for e in self.content_items if _visibility_category_id(e));self._render_genre_rows();self._force_category_list_redraw()
        self["status"].setText(_("Selected categories: %d • MENU to apply")%len(self._category_selected_ids))

    def _clear_category_selection(self):
        if not self._category_select_mode:return
        self._category_selected_ids=set();self._render_genre_rows();self._force_category_list_redraw();self["status"].setText(_("Selection cleared • OK selects and moves down"))

    def _cancel_category_selection(self):
        self._category_select_mode=False;self._category_selected_ids=set()
        if self.level=="genres":self._render_genre_rows();self["status"].setText(_("Ready"))

    def _hide_selected_categories(self):
        if not self._category_select_mode:return
        selected=set(self._category_selected_ids or set())
        if not selected:self["status"].setText(_("Select at least one category first"));return
        current=_profile_hidden_ids(load_settings(),self.profile,self.media_type);current.update(selected);self._save_hidden_category_ids(current)
        self._category_select_mode=False;self._category_selected_ids=set();self.load_genres(self.media_type)

    def _keep_selected_categories_only(self):
        if not self._category_select_mode:return
        selected=set(self._category_selected_ids or set())
        if not selected:self["status"].setText(_("Select at least one category first"));return
        known=set(_visibility_category_id(e) for e in (self._category_known_items or self.content_items) if _visibility_category_id(e))
        # Save only IDs known right now. Any folder the provider adds later has a
        # new ID, is absent from this hidden set and therefore appears immediately.
        hidden=set(gid for gid in known if gid not in selected);self._save_hidden_category_ids(hidden)
        self._category_select_mode=False;self._category_selected_ids=set();self.load_genres(self.media_type)

    def _show_all_categories(self):
        if self.media_type not in ("itv","vod","series"):return
        self._save_hidden_category_ids(set());self._category_select_mode=False;self._category_selected_ids=set();self.load_genres(self.media_type)

    def toggle_current_category_hidden(self):
        if self.level not in ("genres","items") or not self.media_type:self["status"].setText(_("Open a category first"));return
        category=str(self.genre or "")
        if self.level=="genres":
            idx=self["list"].getSelectedIndex()
            if 0<=idx<len(self.content_items):category=_visibility_category_id(self.content_items[idx])
        if not category or category=="*":self["status"].setText(_("This category cannot be hidden"));return
        values=_profile_hidden_ids(load_settings(),self.profile,self.media_type)
        if category in values:values.remove(category);state=_("visible")
        else:values.add(category);state=_("hidden")
        self._save_hidden_category_ids(values);self["status"].setText(_("Category %s")%state)
        if self.level=="genres":self.load_genres(self.media_type)

    def show_hidden_categories(self):
        cfg=load_settings();lines=[]
        for typ in ("itv","vod","series"):
            values=sorted(_profile_hidden_ids(cfg,self.profile,typ));lines.append("%s: %s"%(self._mode_name(typ),", ".join(values) or _("None")))
        self.session.open(MessageBox,_("Hidden categories")+"\n\n"+"\n".join(lines)+"\n\n"+_("Use MENU → Manage Categories to change visibility."),MessageBox.TYPE_INFO,timeout=15)

    def show_account_info(self):
        self["status"].setText(_("Loading account information..."))
        def ok(info):
            if not isinstance(info,dict): info={"Information":info}
            preferred=("login","phone","fname","lsname","tariff_plan","account_balance","expire_billing_date","end_date","status")
            lines=[]
            for key in preferred:
                if info.get(key) not in (None,""): lines.append("%s: %s"%(key.replace("_"," ").title(),info.get(key)))
            health=self.client.health_snapshot(); lines.extend([_("Portal Health: %s")%health.get("health","unknown"),_("Average Latency: %s ms")%health.get("latency_ms",0)])
            if not lines:
                for key,value in list(info.items())[:18]:
                    if value not in (None,"",[],{}): lines.append("%s: %s"%(str(key).replace("_"," ").title(),value))
            _message=_("Account Information")+"\n\n"+("\n".join(lines) if lines else _("No account data returned"))
            # R144: Home INFO is a modal account popup only.  The Browser is an
            # internal carrier for the async request and must disappear with the
            # popup instead of exposing the retired legacy root menu underneath.
            if self.initial_action == "account" and getattr(self,"_home_entry",False):
                self.session.openWithCallback(lambda *args:self.close(),MessageBox,_message,MessageBox.TYPE_INFO,timeout=20)
            else:
                self.session.open(MessageBox,_message,MessageBox.TYPE_INFO,timeout=20)
            self["status"].setText(_("Ready"))
        self._run_async(self.client.account_info,ok,lambda e:self["status"].setText(_("Account info failed: %s")%e))
