# -*- coding: utf-8 -*-
"""Result labels, focus and rendering.

Methods moved verbatim out of ``PortalGlobalSearchScreen`` (ui_screens_search.py); behaviour is unchanged.
This module is imported by ui_screens_search.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, max
from .ui_screens_search import (
    _,
    _image_url,
)


class SearchRenderMixin(object):
    """Result labels, focus and rendering."""

    @staticmethod
    def _set_label_if_changed(widget, value):
        text = str(value or "")
        try:
            if widget.getText() == text:
                return False
        except Exception:
            pass
        widget.setText(text)
        return True

    def _set_search_status(self, value, color="#b0bec8"):
        self._set_label_if_changed(self["search_status"], value)
        try:
            inst = self["search_status"].instance
            if inst is not None:
                inst.setForegroundColor(parseColor(str(color)))
        except Exception as exc:
            optional_failure("ui.search_status_color", exc)

    def _set_result_focus(self, slot, selected):
        """R5.206: the title stays plain white; the selected poster gets the unified
        poster cursor (exact poster size, one bundled PNG, set once per slot)."""
        try:
            slot=int(slot)
            sel=self["result_sel%d" % slot]
            if sel.instance is None:return
            if selected:
                if slot not in self._search_cursor_set:
                    from .ui_edge_cursor import poster_cursor_asset
                    path=poster_cursor_asset("poster_cursor_search_206x310.png")
                    if path:
                        sel.instance.setPixmapFromFile(path);self._search_cursor_set.add(slot)
                sel.show()
            else:
                sel.hide()
        except Exception as exc:
            optional_failure("ui.search_focus_cursor",exc)

    def _result_meta_text(self, item):
        copies, sources = self._group_stats(item)
        typ=str((item or {}).get("_search_media_type") or "vod").lower()
        label=_("SERIES") if typ=="series" else _("MOVIE")
        line="%s  •  %s • %s" % (label, (_("%d results") % copies), (_("%d sources") % sources))
        if sources==1:
            source_name=""
            for row in self._group_copies(item):
                source_name=str((row or {}).get("_search_portal_name") or ((row or {}).get("_search_profile") or {}).get("name") or "").strip()
                if source_name:
                    break
            if source_name:
                if len(source_name)>30:
                    source_name=source_name[:29].rstrip()+"…"
                line += "\n" + source_name
        return line

    def _result_meta_color(self, item):
        # Portal-only grouped results keep the established red metadata line.
        # If any copy in the federated group belongs to Xtream/M3U, make that
        # line white so the source family is visible without changing the text.
        copies=self._group_copies(item)
        for row in copies:
            source_type=str((row or {}).get("_search_source_type") or "").strip().lower()
            if source_type in ("xtream","m3u"):
                return "#FFFFFF"
            profile=(row or {}).get("_search_profile") or {}
            if str((profile or {}).get("source_type") or "").strip().lower()=="m3u":
                return "#FFFFFF"
        return "#FF5A5F"

    def _render(self):
        query_text = (_("Search: %s") % self.query) if self.query else _("Search")
        self._set_label_if_changed(self["search_query"], query_text)
        if getattr(self, "_search_gateway", False):
            self._sd_pending_item = None
            self._search_hide_details()
            self._render_search_gateway()
            return
        self._hide_search_gateway()
        view_rows = self._view_results()
        page = self.index // self.PAGE_SIZE if view_rows else 0
        start = page * self.PAGE_SIZE
        rows = view_rows[start : start + self.PAGE_SIZE]
        pages = max(1, (len(view_rows) + self.PAGE_SIZE - 1) // self.PAGE_SIZE)
        titles = len(view_rows)
        page_text = ((_("Page %d / %d  •  %d result(s)") % (page + 1, pages, titles)) if view_rows else "")
        self._set_label_if_changed(self["page_label"], page_text)

        # A page change invalidates queued poster downloads; partial results that
        # merely append to the current page do not. The old renderer bumped one
        # global generation whenever the page signature changed, repeatedly
        # cancelling and rescheduling posters already in flight.
        if getattr(self, "_render_art_start", None) != start:
            self._advance_poster_generation()
            self._render_art_start = start
        generation = self._poster_generation

        slot_signatures = list(getattr(self, "_render_slot_signatures", [None] * self.PAGE_SIZE))
        art_identities = list(getattr(self, "_render_art_identities", [None] * self.PAGE_SIZE))
        if len(slot_signatures) != self.PAGE_SIZE:slot_signatures = [None] * self.PAGE_SIZE
        if len(art_identities) != self.PAGE_SIZE:art_identities = [None] * self.PAGE_SIZE

        current_signature=[]
        for slot in range(self.PAGE_SIZE):
            art = self["result_art%d" % slot]
            title = self["result_title%d" % slot]
            meta = self["result_meta%d" % slot]
            if slot >= len(rows):
                current_signature.append("")
                if slot_signatures[slot] is not None or art_identities[slot] is not None:
                    try:
                        if art.instance is not None:
                            art.instance.setPixmap(None)
                    except Exception:
                        pass
                    art.hide()
                    self._set_label_if_changed(title, "")
                    self._set_label_if_changed(meta, "")
                    slot_signatures[slot] = None
                    art_identities[slot] = None
                self._set_result_focus(slot,False)
                continue

            item = rows[slot]
            ident = self._poster_identity(item)
            current_signature.append(ident)
            # Search always shows the exact provider name, independent from the
            # global Clean Names preference.  This is how users can distinguish
            # multiple 4K/FHD/language/server variants of the same cleaned title.
            raw = ((item.get("_search_group_title") if item.get("_search_group") else None) or item.get("_raw_name") or item.get("name") or item.get("title") or _("Result"))
            title_text = str(raw).strip()[:52]
            meta_text = self._result_meta_text(item)
            meta_color = self._result_meta_color(item)
            # Include the artwork source/copy count in the signature. Native
            # search often returns a sparse first copy, then a later portal adds
            # the usable poster URL. Requeue that card when its source improves.
            try:art_source=str(_image_url(item) or "")
            except Exception:art_source=""
            slot_signature = (ident, title_text, meta_text, meta_color, art_source, len(self._group_copies(item)))
            if slot_signatures[slot] != slot_signature:
                self._set_label_if_changed(title, title_text)
                self._set_label_if_changed(meta, meta_text)
                try:
                    if meta.instance is not None:
                        meta.instance.setForegroundColor(parseColor(meta_color))
                except Exception as exc:
                    optional_failure("ui.search_result_meta_color",exc)
                # If a later partial result promoted real artwork onto the same
                # logical title, allow one fresh poster attempt without changing
                # Search result speed/order.
                previous=slot_signatures[slot]
                source_changed=bool(previous and previous[4:] != slot_signature[4:])
                slot_signatures[slot] = slot_signature
                if source_changed and art_identities[slot] == ident:
                    art_identities[slot] = None

            if art_identities[slot] != ident:
                try:
                    if art.instance is not None:
                        art.instance.setPixmap(None)
                    art.hide()
                except Exception:
                    pass
                art_identities[slot] = ident
                self._schedule_poster(generation, slot, item)

        self._render_signature = tuple(current_signature)

        # The only selection visual is the selected title itself turning green.
        # It exists before the poster arrives, so there is always exactly one
        # visible focus cue and no per-card frame/green line to generate.
        selected_slot = self.index - start if start <= self.index < start + len(rows) else None
        old_slot = getattr(self, "_render_selected_slot", None)
        if old_slot != selected_slot:
            if old_slot is not None and 0 <= old_slot < self.PAGE_SIZE:
                self._set_result_focus(old_slot,False)
            if selected_slot is not None and 0 <= selected_slot < self.PAGE_SIZE:
                self._set_result_focus(selected_slot,True)
            self._render_selected_slot = selected_slot
        elif selected_slot is not None:
            self._set_result_focus(selected_slot,True)
        self._render_slot_signatures = slot_signatures
        self._render_art_identities = art_identities
        try:
            if selected_slot is not None and 0 <= selected_slot < len(rows):
                _sel = rows[selected_slot]
                try:_sid = self._poster_identity(_sel)
                except Exception:_sid = id(_sel)
                if _sid in self._sd_cache:
                    self._sd_pending_item = None
                    try:self._sd_timer.stop()
                    except Exception:pass
                    self._apply_search_details(_sel, True)
                else:
                    # Cheap in-memory details now; disk snapshot lookup only
                    # after focus has rested for ~150 ms.
                    self._apply_search_details(_sel, False)
                    self._sd_pending_item = _sel
                    try:self._sd_timer.start(150, True)
                    except Exception:self._sd_pending_item = None;self._apply_search_details(_sel, True)
            else:
                self._sd_pending_item = None
                try:self._sd_timer.stop()
                except Exception:pass
                self._search_hide_details()
        except Exception as exc:
            optional_failure("ui.search_details", exc)
