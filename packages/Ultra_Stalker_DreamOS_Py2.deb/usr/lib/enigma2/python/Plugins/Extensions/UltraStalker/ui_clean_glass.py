"""Shared clean-glass renderer for every adaptive chrome PNG (PIL only, no numpy).

All shapes are drawn with 3x supersampling and ONE concentric radius family, so rims, glow,
hairlines and fills never stair-step or pinch at the corners.  Callers keep their own geometry,
translucency and palette; only the drawing technique is shared:

    glow (soft, blurred ring) -> body (vertical tint gradient) -> bottom shade -> one smooth top
    sheen -> inner hairline (top-lit) -> outer rim (top-lit gradient)
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import int, round, max, min, us_copy
try:
    from PIL import Image as _Img, ImageDraw as _Draw, ImageChops as _Chops, ImageFilter as _Filt
except Exception:  # pragma: no cover - Pillow is a hard dependency elsewhere
    _Img = _Draw = _Chops = _Filt = None

WHITE = (255, 255, 255)


# ---------------------------------------------------------------------------
# R5.129: Portal-tile nine-slice, used ONLY by the fixed (non-adaptive) surfaces
# (ui_fixed_glass).  Adaptive surfaces keep the glass() recipe above untouched.
_os = _us_env.os
_PT_CACHE = {}


def _pt_src(selected):
    key = bool(selected)
    im = _PT_CACHE.get(key)
    if im is None:
        name = "pt_tile_sel_380x148.png" if key else "pt_tile_380x148.png"
        base = _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), "assets_fhd", name)
        im = _Img.open(base).convert("RGBA")
        _PT_CACHE[key] = im
    return im


def portal_tile(size, selected=False, backing=0, frame=False, corner=None):
    """Portal-tile nine-slice at ``size``.  ``backing`` (0-255) adds a dark opaque
    base for surfaces that sit over video; ``frame`` keeps only the border ring."""
    width, height = max(2, int(size[0])), max(2, int(size[1]))
    src = _pt_src(selected)
    # Keep the complete source corner, even on short year/age/quality pills.
    # Cropping a smaller source corner cuts its arc and leaves a join/notch.
    sw, sh = src.size
    c = min(36, sw // 2, sh // 2)
    d = min(22, (width - 1) // 2, (height - 1) // 2)
    if corner is not None:
        d = min(d, max(1, int(corner)))
    dx = dy = d
    o = _Img.new("RGBA", (width, height))
    xs = [(0, c, 0, dx), (c, sw - c, dx, width - dx), (sw - c, sw, width - dx, width)]
    ys = [(0, c, 0, dy), (c, sh - c, dy, height - dy), (sh - c, sh, height - dy, height)]
    for sx0, sx1, dx0, dx1 in xs:
        for sy0, sy1, dy0, dy1 in ys:
            if dx1 > dx0 and dy1 > dy0:
                o.paste(src.crop((sx0, sy0, sx1, sy1)).resize((dx1 - dx0, dy1 - dy0), _Img.BILINEAR), (dx0, dy0))
    if backing and not frame:
        base = _Img.new("RGBA", (width, height), (8, 10, 12, 0))
        base.putalpha(_Img.new("L", (width, height), 0))
        a = o.split()[3]
        body = us_copy(o)
        # opaque base only where the tile has body
        back = _Img.new("RGBA", (width, height), (8, 10, 12, int(backing)))
        back.putalpha(a.point(lambda v: int(backing) if v > 8 else 0))
        o = _Img.alpha_composite(back, body)
    if frame:
        m = _Img.new("L", (width, height), 0)
        d = _Draw.Draw(m)
        bw = 3
        r = max(4, min(20, width // 3, height // 3))
        d.rounded_rectangle((0, 0, width - 1, height - 1), radius=r, fill=255)
        d.rounded_rectangle((bw, bw, width - 1 - bw, height - 1 - bw), radius=max(1, r - bw), fill=0)
        a = _Chops.multiply(o.split()[3], m)
        o.putalpha(a)
    return o


def _mix(a, b, t):
    t = max(0.0, min(1.0, float(t)))
    return tuple(int(a[i] * (1.0 - t) + b[i] * t) for i in range(3))


def _box():
    return getattr(getattr(_Img, "Resampling", _Img), "BOX", 4)


def _rr_full(W, H, box, R, ss):
    m = _Img.new("L", (W * ss, H * ss), 0)
    X0, Y0, X1, Y1 = box
    if X1 > X0 and Y1 > Y0:
        _Draw.Draw(m).rounded_rectangle((X0, Y0, X1, Y1), radius=max(1, int(R)), fill=255)
    return m.resize((W, H), _box())


def _rr(W, H, box, R, ss):
    """Anti-aliased rounded-rect mask at final size.

    Pixel-identical to drawing the shape at ``ss``x and BOX-downscaling, but only the
    four corner tiles are supersampled; straight edges are stretched from one exact
    column/row.  This keeps big panels cheap on receiver CPUs.
    """
    W, H = int(W), int(H)
    X0, Y0, X1, Y1 = [int(v) for v in box]
    R = max(1, int(R))
    if X1 <= X0 or Y1 <= Y0:
        return _Img.new("L", (W, H), 0)
    K = -(-R // ss) + 3
    ox, oy = X0 // ss - 1, Y0 // ss - 1
    rx, ry = X1 // ss + 2 - K, Y1 // ss + 2 - K
    mx, my = rx - (ox + K), ry - (oy + K)
    if mx < 0 or my < 0:
        return _rr_full(W, H, (X0, Y0, X1, Y1), R, ss)
    S = 2 * K + 1
    sm = _Img.new("L", (S * ss, S * ss), 0)
    _Draw.Draw(sm).rounded_rectangle((X0 - ox * ss, Y0 - oy * ss, X1 - (rx - K - 1) * ss, Y1 - (ry - K - 1) * ss), radius=R, fill=255)
    sm = sm.resize((S, S), _box())
    out = _Img.new("L", (W, H), 0)
    near = getattr(getattr(_Img, "Resampling", _Img), "NEAREST", 0)
    xs = ((0, K, ox, K), (K, K + 1, ox + K, mx), (K + 1, S, rx, K))
    ys = ((0, K, oy, K), (K, K + 1, oy + K, my), (K + 1, S, ry, K))
    for (sx0, sx1, dx, dw) in xs:
        if dw <= 0:
            continue
        for (sy0, sy1, dy, dh) in ys:
            if dh <= 0:
                continue
            tile = sm.crop((sx0, sy0, sx1, sy1))
            if tile.size != (dw, dh):
                tile = tile.resize((dw, dh), near)
            out.paste(tile, (dx, dy))
    return out


def _inset_box(size, radius, inset, ss):
    w, h = int(size[0]), int(size[1])
    i = int(round(inset * ss))
    if not (w * ss - 1 - i > i and h * ss - 1 - i > i):
        return None, 0
    return (i, i, w * ss - 1 - i, h * ss - 1 - i), int(max(1.0, radius - inset) * ss)


def fill_mask(size, radius, inset=0.0, ss=3):
    box, R = _inset_box(size, radius, inset, ss)
    if box is None:
        return _Img.new("L", (int(size[0]), int(size[1])), 0)
    return _rr(size[0], size[1], box, R, ss)


def ring_mask(size, radius, inset_out, inset_in, ss=3):
    return _Chops.subtract(fill_mask(size, radius, inset_out, ss), fill_mask(size, radius, inset_in, ss))


def _ramp(size, top, bottom):
    """Vertical L ramp built from one column (cheap: no full-size bicubic resize)."""
    w, h = int(size[0]), int(size[1])
    col = _Img.new("L", (1, h))
    d = float(max(1, h - 1))
    col.putdata([int(top + (bottom - top) * y / d) for y in range(h)])
    return col.resize((w, h), getattr(getattr(_Img, "Resampling", _Img), "NEAREST", 0))


def _vgrad(size, top, bottom):
    return _ramp(size, top, bottom)


def layer(mask, c_top, c_bottom=None, a_top=255, a_bottom=None):
    """RGBA layer shaped by ``mask`` with a vertical colour and alpha gradient."""
    c_bottom = c_top if c_bottom is None else c_bottom
    a_bottom = a_top if a_bottom is None else a_bottom
    size = mask.size
    if tuple(c_top) == tuple(c_bottom):
        col = _Img.new("RGB", size, tuple(c_top))
    else:
        g = _ramp(size, 0, 255)
        col = _Img.composite(_Img.new("RGB", size, tuple(c_bottom)), _Img.new("RGB", size, tuple(c_top)), g)
    alpha = mask if a_top == a_bottom == 255 else _Chops.multiply(mask, _vgrad(size, a_top, a_bottom))
    if a_top == a_bottom and a_top != 255:
        alpha = mask.point(lambda v: int(v * a_top / 255.0))
    out = col.convert("RGBA")
    out.putalpha(alpha)
    return out


# ---------------------------------------------------------------------------
# Palestine chrome (R5.81): ONE fixed look for every frame in the plugin.
# Any green rim / tint in a chrome PNG is re-hued along a diagonal flag ramp:
# green (top-left) -> soft neutral -> red (bottom-right).  Luminance, alpha and
# non-green pixels (white text/icons, greys, posters) are left untouched.
# ---------------------------------------------------------------------------
_FLAG_STOPS = ((0.0, (60, 200, 140)), (0.36, (60, 200, 140)), (0.58, (150, 172, 160)), (0.84, (222, 52, 62)), (1.0, (222, 52, 62)))


def _flag_rgb(t):
    for i in range(len(_FLAG_STOPS) - 1):
        t0, c0 = _FLAG_STOPS[i]
        t1, c1 = _FLAG_STOPS[i + 1]
        if t <= t1:
            return _mix(c0, c1, (t - t0) / float(max(1e-6, t1 - t0)))
    return _FLAG_STOPS[-1][1]


def _flag_ramp(size):
    n = 48
    g = _Img.new("RGB", (n, n))
    px = []
    for y in range(n):
        for x in range(n):
            px.append(_flag_rgb(0.5 * x / (n - 1.0) + 0.5 * y / (n - 1.0)))
    g.putdata(px)
    return g.resize((int(size[0]), int(size[1])), getattr(getattr(_Img, "Resampling", _Img), "BILINEAR", 2))


def flagify(img, min_side=12):
    """Return ``img`` (RGBA) with its green chrome re-hued to the Palestine ramp."""
    try:
        if _Img is None or img is None:
            return img
        w, h = img.size
        if min(w, h) < min_side:
            return img
        rgba = img.convert("RGBA")
        alpha = rgba.split()[3]
        rgb = rgba.convert("RGB")
        hh, ss, vv = rgb.convert("HSV").split()
        gh, gs, _gv = _flag_ramp((w, h)).convert("HSV").split()
        hue_ok = hh.point(lambda x: 255 if 48 <= x <= 140 else 0)
        sat_ok = ss.point(lambda x: max(0, min(255, (x - 25) * 6)))
        mask = _Chops.multiply(hue_ok, sat_ok)
        new_s = _Chops.multiply(ss, gs).point(lambda x: min(255, int(x * 1.25)))
        new = _Img.merge("HSV", (gh, new_s, vv)).convert("RGB")
        out = _Img.composite(new, rgb, mask).convert("RGBA")
        out.putalpha(alpha)
        return out
    except Exception:
        return img


def glass(size, radius, accent, fill=(4, 10, 16), fill_alpha=96, fill_inset=0.0, fill_radius=None,
          rim_alpha=200, rim_w=1.0, rim_inset=1.0, lit=0.22, rim_mix=None,
          hair_alpha=40, hair_inset=6.0, hair_color=None,
          sheen_alpha=16, sheen_frac=0.46, shade_alpha=0,
          glow_alpha=0, glow_w=3.0, glow_inset=4.0, glow_blur=6.0, glow_color=None,
          tint_top=0.07, depth_alpha=0, depth_blur=5.0, depth_dy=3.0, depth_inset=4.0,
          inner_fill=None, ss=3):
    """Render one adaptive glass surface and return an RGBA image."""
    w, h = int(size[0]), int(size[1])
    out = _Img.new("RGBA", (w, h), (0, 0, 0, 0))
    acc = tuple(int(v) for v in accent)
    # contained floating depth shadow (never leaves the canvas)
    if depth_alpha > 0:
        # blur only the 8-bit mask (4x less work than blurring an RGBA layer)
        dm = fill_mask(size, radius, depth_inset, ss)
        da = _Img.new("L", (w, h), 0)
        da.paste(dm, (0, int(round(depth_dy))))
        if _Filt is not None and depth_blur > 0:
            da = da.filter(_Filt.GaussianBlur(radius=depth_blur))
        out = _Img.alpha_composite(out, layer(da, (0, 0, 0), None, int(depth_alpha)))
    # soft glow, kept inside the canvas
    if glow_alpha > 0:
        gm = ring_mask(size, radius, glow_inset, glow_inset + glow_w, ss)
        if _Filt is not None and glow_blur > 0:
            gm = gm.filter(_Filt.GaussianBlur(radius=glow_blur))
        out = _Img.alpha_composite(out, layer(gm, tuple(glow_color or acc), None, int(glow_alpha)))
    # body
    if fill_alpha > 0:
        frad = radius if fill_radius is None else fill_radius
        top = _mix(fill, acc, tint_top)
        body = layer(fill_mask(size, frad, fill_inset, ss), top, tuple(fill), int(fill_alpha), int(fill_alpha))
        out = _Img.alpha_composite(out, body)
        if shade_alpha > 0:
            out = _Img.alpha_composite(out, layer(fill_mask(size, frad, fill_inset + 1.0, ss), (0, 0, 0), (0, 0, 0), 0, int(shade_alpha)))
    # optional second inner skin ("glass inside the frame")
    if inner_fill:
        icol, ialpha, iinset = inner_fill
        # replace (not stack): the inner skin sets its own translucency, as the original did
        inner_solid = _Img.new("RGBA", (w, h), tuple(icol) + (int(ialpha),))
        out = _Img.composite(inner_solid, out, fill_mask(size, max(8, radius - iinset), iinset, ss))
    # one smooth top sheen
    if sheen_alpha > 0:
        sh = max(10, int(h * sheen_frac))
        grad = _Img.new("L", (w, h), 0)
        grad.paste(_vgrad((w, sh), int(sheen_alpha), 0), (0, 0))
        sm = _Chops.multiply(fill_mask(size, radius, max(2.0, fill_inset + 2.0), ss), grad)
        sl = _Img.new("RGBA", (w, h), _mix(acc, WHITE, 0.55) + (0,))
        sl.putalpha(sm)
        out = _Img.alpha_composite(out, sl)
    # inner hairline (top-lit)
    if hair_alpha > 0:
        hc = tuple(hair_color or _mix(acc, WHITE, 0.50))
        out = _Img.alpha_composite(out, layer(ring_mask(size, radius, hair_inset, hair_inset + 1.0, ss), hc, _mix(acc, WHITE, 0.25), int(hair_alpha), int(hair_alpha * 0.25)))
    # outer rim
    if rim_alpha > 0 and rim_w > 0:
        top_c = _mix(acc, WHITE, lit) if rim_mix is None else rim_mix
        out = _Img.alpha_composite(out, layer(ring_mask(size, radius, rim_inset, rim_inset + rim_w, ss), top_c, _mix(acc, (4, 10, 16), 0.15), int(rim_alpha), max(0, int(rim_alpha) - 20)))
    return out


def _ell(size, inset, ss):
    w, h = int(size[0]), int(size[1])
    i = int(round(inset * ss))
    m = _Img.new("L", (w * ss, h * ss), 0)
    _Draw.Draw(m).ellipse((i, i, w * ss - 1 - i, h * ss - 1 - i), fill=255)
    return m


def disc(size, accent, fill=(4, 12, 18), fill_alpha=238, rim_alpha=205, rim_w=4.0, rim_inset=5.0,
         hair_alpha=65, hair_inset=12.0, lit=0.30, ss=3):
    """Anti-aliased round badge (rating ring)."""
    w, h = int(size[0]), int(size[1])
    acc = tuple(int(v) for v in accent)
    box = _box()
    out = _Img.new("RGBA", (w, h), (0, 0, 0, 0))
    body = _ell(size, rim_inset, ss).resize((w, h), box)
    out = _Img.alpha_composite(out, layer(body, tuple(fill), None, int(fill_alpha)))
    if hair_alpha > 0:
        hm = _Chops.subtract(_ell(size, hair_inset, ss), _ell(size, hair_inset + 1.0, ss)).resize((w, h), box)
        out = _Img.alpha_composite(out, layer(hm, _mix(acc, WHITE, 0.40), None, int(hair_alpha)))
    rm = _Chops.subtract(_ell(size, rim_inset, ss), _ell(size, rim_inset + rim_w, ss)).resize((w, h), box)
    out = _Img.alpha_composite(out, layer(rm, _mix(acc, WHITE, lit), acc, int(rim_alpha), max(0, int(rim_alpha) - 20)))
    return out


def _expand_mask(size, edges, e, radius0, ss, square_top=False):
    l, t, r, b = edges
    box = (int((l - e) * ss), int((t - e) * ss), int((r + e) * ss) - 1, int((b + e) * ss) - 1)
    R = int(max(2.0, radius0 + e) * ss)
    m = _rr(size[0], size[1], box, R, ss)
    if square_top:
        # square top corners: the frame closes exactly around a square poster top
        x0, y0, x1 = int(l - e), int(t - e), int(r + e)
        band = int(-(-R // ss)) + 1
        if x1 > x0:
            _Draw.Draw(m).rectangle((max(0, x0), max(0, y0), x1 - 1, y0 + band), fill=255)
    return m


def frame_ring(size, edges, e_out, e_in, color, alpha, radius0=16, ss=3, square_top=False):
    """Concentric anti-aliased ring around a poster box (expand in px, negative = inset)."""
    m = _expand_mask(size, edges, e_out, radius0, ss, square_top)
    if e_in is not None:
        m = _Chops.subtract(m, _expand_mask(size, edges, e_in, radius0, ss, square_top))
    return layer(m, tuple(color), None, int(alpha))


def player_glass(size, radius, accent, base, fill_alpha, edge_alpha, strong, ss=3):
    """Player/Cinematic chrome material (main panel, key bar, chips, picon card)."""
    w, h = int(size[0]), int(size[1])
    mix = _mix
    out = _Img.new("RGBA", (w, h), (0, 0, 0, 0))
    out = _Img.alpha_composite(out, layer(fill_mask(size, radius, 0, ss), mix(base, accent, .19 if strong else .16), mix(base, accent, .09), fill_alpha, max(0, int(fill_alpha * .94))))
    out = _Img.alpha_composite(out, layer(fill_mask(size, radius, 1.5, ss), (0, 0, 0), (0, 0, 0), 0, 46 if strong else 34))
    sheen_h = max(10, int(h * .46))
    grad = _Img.new("L", (w, h), 0)
    grad.paste(_vgrad((w, sheen_h), 30 if strong else 22, 0), (0, 0))
    sl = _Img.new("RGBA", (w, h), mix(accent, WHITE, .55) + (0,))
    sl.putalpha(_Chops.multiply(fill_mask(size, radius, 3, ss), grad))
    out = _Img.alpha_composite(out, sl)
    out = _Img.alpha_composite(out, layer(ring_mask(size, radius, 3.2 if strong else 2.6, 4.2 if strong else 3.4, ss), mix(accent, WHITE, .62), mix(accent, WHITE, .30), 120 if strong else 96, 18))
    ew = 2.0 if strong else 1.5
    out = _Img.alpha_composite(out, layer(ring_mask(size, radius, 0, ew, ss), mix(accent, WHITE, .30), mix(accent, base, .18), edge_alpha, max(0, edge_alpha - 18)))
    return out
