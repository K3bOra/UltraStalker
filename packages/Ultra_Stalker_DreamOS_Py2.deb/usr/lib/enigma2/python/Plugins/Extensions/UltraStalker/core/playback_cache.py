"""Bounded retained byte cache. Native HTTP Range remains the seek authority."""
from __future__ import absolute_import, division, print_function, unicode_literals
from .. import us_env as _us_env
from ..us_env import int, open, max, min, us_clear
__metaclass__ = type  # new-style classes on Python 2
os = _us_env.os
threading = _us_env.threading


class RangeCache:
    def __init__(self, path, limit):
        self.lock = threading.RLock()
        self.limit = max(65536, int(limit))
        self.requested_limit = self.limit
        self.cursor = 0
        self.spans = []  # logical start/end, physical start
        self.file = open(path, 'w+b', buffering=0)

    def resize(self, limit):
        # Called from GUI controls: apply physical resize only on the IO worker.
        with self.lock:
            self.requested_limit = max(65536, int(limit))

    def _apply_limit(self):
        if self.limit != self.requested_limit:
            if self.requested_limit < self.limit:
                us_clear(self.spans); self.cursor = 0
                self.file.truncate(self.requested_limit)
            self.limit = self.requested_limit

    def put(self, offset, data):
        with self.lock:
            self._apply_limit()
            while data:
                size = min(len(data), self.limit-self.cursor)
                lo, hi = self.cursor, self.cursor+size
                kept = []
                for start, end, physical in self.spans:
                    stop = physical+end-start
                    if stop <= lo or physical >= hi:
                        kept.append((start,end,physical)); continue
                    if physical < lo:
                        kept.append((start,start+lo-physical,physical))
                    if stop > hi:
                        kept.append((start+hi-physical,end,hi))
                self.file.seek(lo); self.file.write(data[:size])
                span = (offset, offset+size, lo)
                if kept and kept[-1][1] == offset and kept[-1][2]+kept[-1][1]-kept[-1][0] == lo:
                    start,end,physical = kept.pop(); span = (start,offset+size,physical)
                kept.append(span); self.spans = kept
                self.cursor = hi % self.limit
                offset += size; data = data[size:]

    def read(self, offset, amount):
        with self.lock:
            self._apply_limit()
            for start, end, physical in reversed(self.spans):
                if start <= offset < end:
                    self.file.seek(physical+offset-start)
                    return self.file.read(min(amount,end-offset))
        return b''

    def coverage(self, offset):
        # Metadata only: safe for a one-second HUD tick; no disk reads.
        with self.lock:
            if self.requested_limit < self.limit: return None
            end = offset
            while True:
                next_end = max((stop for start,stop,_ in self.spans if start <= end < stop),default=end)
                if next_end == end: return (offset,end) if end>offset else None
                end = next_end

    def close(self):
        with self.lock: self.file.close()
