# -*- coding: utf-8 -*-
"""R5.342: brief status text IN the current screen, never a black overlay.

Use an existing status/page-count label whenever available.  Restore its
previous value after the timeout, unless the screen itself changed the value.
On uncommon screens without such a label, use a transparent native child
label attached to the existing window (never create an Enigma2 dialog).
No ActionMap, no session.open, no modal navigation changes.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str, int, max, min
re = _us_env.re
import weakref

from enigma import eTimer


from .label_align import halign as _lbl_h, valign as _lbl_v

def notice_line(value, limit=75):
    """Shorten common export notifications without dropping the item count."""
    raw = str(value or "").strip()
    flat = re.sub(r"\s+", " ", raw).strip()
    if not flat:
        return ""
    count = re.search(r"\b(Channels|Movies|Series|Episodes|Items)\s*:\s*(\d+)", raw, re.I)
    name = ""
    lines = [s.strip() for s in raw.splitlines() if s.strip()]
    if len(lines) > 1:
        name = lines[1]
    # The first sentence is boilerplate; expose the useful title and result.
    if count and ("exported" in flat.lower() or "receiver bouquet" in flat.lower()):
        word = count.group(1).lower()
        qty = count.group(2)
        label = ("Sent to Receiver" if "sent to" in flat.lower() else "Exported")
        flat = u"%s  •  %s  •  %s %s" % (label, name, qty, word)
    elif flat.startswith("Added to Bouquet:"):
        flat = flat.replace("Added to Bouquet:", "Bouquet updated •", 1)
    if len(flat) > limit:
        flat = flat[:limit - 1].rstrip() + u"…"
    return flat


def _label_for(owner):
    """Select a legitimate UI line, not a full-screen/large popup."""
    if getattr(owner, "_cat_glass_on", False) and getattr(owner, "level", "") == "genres":
        # Category notices have their OWN line just above the right footer.
        # Do not temporarily replace Categories: N or alter its underline.
        names = ("cat_inline_notice",)
    else:
        # Cinematic grids already use status above the description; settings
        # and other pages have matching inline status positions.
        names = ("status", "page_label", "counter", "page_sub", "subtitle")
    for name in names:
        try:
            widget = owner[name]
            if callable(getattr(widget, "setText", None)) and callable(getattr(widget, "getText", None)):
                if getattr(widget, "instance", None) is not None:
                    return name, widget
        except Exception:
            pass
    return None, None


def _timer_connect(timer, callback):
    try:
        return timer.timeout.connect(callback)
    except (AttributeError, TypeError):
        timer.callback.append(callback)
        return None


class _InlineNotice(object):
    def __init__(self, owner):
        self.owner_ref = weakref.ref(owner)
        self.timer = eTimer()
        self.connection = _timer_connect(self.timer, self.expire)
        self.widget = None
        self.widget_key = None
        self.original = ""
        self.message = ""
        self.window_child = None
        self.dead = False
        try:
            owner.onClose.append(self.close)
        except Exception:
            pass

    def close(self):
        if self.dead:
            return
        self.expire()
        self.dead = True
        try:
            self.timer.stop()
        except Exception:
            pass
        try:
            if self.connection is not None:
                self.connection.disconnect()
            elif self.expire in self.timer.callback:
                self.timer.callback.remove(self.expire)
        except Exception:
            pass
        owner = self.owner_ref()
        if owner is not None and getattr(owner, "_ultrastalker_inline_notice", None) is self:
            owner._ultrastalker_inline_notice = None
        # A native child belongs to its parent window and will die with it.
        self.window_child = None

    def expire(self):
        try:
            self.timer.stop()
        except Exception:
            pass
        if self.window_child is not None:
            try:
                self.window_child.hide()
            except Exception:
                pass
        if self.widget is not None:
            try:
                if str(self.widget.getText() or "") == self.message:
                    self.widget.setText(self.original)
                if self.widget_key == "cat_inline_notice":
                    self.widget.hide()
            except Exception:
                pass
        self.widget = None
        self.widget_key = None
        self.original = ""
        self.message = ""

    def _native_child(self, owner):
        """Draw plain text as a child of the existing screen, never a dialog."""
        if self.window_child is not None:
            return self.window_child
        try:
            from enigma import eLabel, ePoint, eSize, gFont
            from skin import parseColor
            parent = getattr(owner, "instance", None)
            if parent is None:
                return None
            label = eLabel(parent)
            category = (getattr(owner, "_cat_glass_on", False)
                        and getattr(owner, "level", "") == "genres")
            from .wqhd_layout import xy as _wqhd_xy, wh as _wqhd_wh
            if category:
                label.move(ePoint(*_wqhd_xy(1000, 967)))
                label.resize(eSize(*_wqhd_wh(872, 36)))
                label.setFont(_ultra_rfont("Regular", 22))
                try:
                    from enigma import RT_HALIGN_RIGHT
                    label.setHAlign(_lbl_h("right"))
                except Exception:
                    pass
            else:
                label.move(ePoint(*_wqhd_xy(72, 35)))
                label.resize(eSize(*_wqhd_wh(1030, 36)))
                label.setFont(_ultra_rfont("Regular", 23))
            label.setForegroundColor(parseColor("#E7F1F0"))
            label.setTransparent(1)
            self.window_child = label
            return label
        except Exception:
            return None

    def show(self, text, timeout_ms):
        if self.dead:
            return False
        owner = self.owner_ref()
        if owner is None:
            return False
        name, widget = _label_for(owner)
        # Preserve the text that preceded the *first* notice if messages
        # arrive repeatedly before expiry.
        if name != self.widget_key or widget is not self.widget:
            self.expire()
        if widget is not None:
            # Navigation or a periodic status update may have replaced our
            # message. In that case the NEW page value is the one to restore.
            if self.widget is widget:
                try:
                    actual = str(widget.getText() or "")
                    if actual != self.message:
                        self.original = actual
                except Exception:
                    pass
            if self.widget is None:
                try:
                    self.original = str(widget.getText() or "")
                except Exception:
                    self.original = ""
                # The Cinematic screen already prints a long-lived success
                # status. It should fade away, not come back after this toast.
                if re.match(r"\s*(sent to receiver|sent to the receiver|exported|bouquet updated)\b", self.original, re.I):
                    self.original = ""
            self.widget = widget
            self.widget_key = name
            self.message = notice_line(text, 74 if name == "cat_inline_notice" else 84)
            try:
                widget.setText(self.message)
                if name == "cat_inline_notice":
                    widget.show()
            except Exception:
                self.expire()
                return False
        else:
            self.expire()
            child = self._native_child(owner)
            if child is None:
                return False
            self.message = notice_line(text, 84)
            try:
                child.setText(self.message)
                child.show()
            except Exception:
                self.expire()
                return False
        try:
            self.timer.start(max(1200, min(12000, int(timeout_ms))), True)
        except Exception:
            self.expire()
            return False
        return True


def show_notice(session, text, timeout=4, title=None, owner=None):
    """Non-modal, no background: briefly borrow a status/count line."""
    if title and str(title).strip().lower() not in ("information", "info", "success"):
        text = u"%s • %s" % (str(title).strip(), str(text or ""))
    if not str(text or "").strip():
        return False
    if owner is None:
        owner = getattr(session, "current_dialog", None)
    if owner is None:
        return False
    try:
        state = getattr(owner, "_ultrastalker_inline_notice", None)
        if state is None or state.dead:
            state = _InlineNotice(owner)
            owner._ultrastalker_inline_notice = state
        return state.show(text, int(max(1.2, min(12.0, float(timeout or 4))) * 1000))
    except Exception:
        return False
from .wqhd_layout import responsive_font as _ultra_rfont, factors as _ultra_factors

def _ultra_osd_scale():
    return _ultra_factors()[1]
