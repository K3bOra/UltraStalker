"""Provider XMLTV input, shared disk index and exact channel matching.

Streaming XML parsing keeps large guides outside receiver RAM. A successful
refresh replaces the private SQLite index atomically; a failed refresh keeps
the last working guide. No provider URL or credentials are stored in the DB.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str, int, max, min, OSError, InterruptedError, us_clear, us_casefold, us_acquire
__metaclass__ = type  # new-style classes on Python 2
import calendar
import errno
import gzip
hashlib = _us_env.hashlib
os = _us_env.os
re = _us_env.re
sqlite3 = _us_env.sqlite3
shutil = _us_env.shutil
import stat
import tempfile
threading = _us_env.threading
time = _us_env.time
urllib = _us_env.urllib
urllib = _us_env.urllib
import xml.etree.ElementTree as ET
OrderedDict = _us_env.collections.OrderedDict
from contextlib import closing
lru_cache = _us_env.lru_cache

from .netsec import provider_urlopen, validate_http_url
from .securefs import secure_private_dir

_LOCKS=tuple(threading.Lock() for _ in range(8))
_RETRIES=OrderedDict()
_RETRY_LOCK=threading.Lock()
_TTL=2*3600
_RAW_LIMIT=32*1024*1024
_XML_LIMIT=128*1024*1024
_DB_LIMIT=64*1024*1024


def timestamp(value):
    text=str(value or '').strip()
    if len(text)>64:return 0
    return _timestamp(text)


@lru_cache(maxsize=8192)
def _timestamp(text):
    """Bounded date parsing shared by channels with overlapping programme times."""
    m=re.fullmatch(r'(\d{8,14})(?:\s*(Z|UTC|GMT|[+-]\d{2}:?\d{2}))?',text,re.I)
    if m:
        digits=m.group(1)
        if len(digits) not in (8,10,12,14):return 0
        digits=digits.ljust(14,'0')
        try:stamp=calendar.timegm(time.strptime(digits,'%Y%m%d%H%M%S'))
        except (ValueError,OverflowError):return 0
        zone=m.group(2) or ''
        if zone.startswith(('+','-')):
            zone=zone.replace(':','');hh=int(zone[1:3]);mm=int(zone[3:5])
            if hh>23 or mm>59:return 0
            stamp-=(1 if zone[0]=='+' else -1)*(hh*3600+mm*60)
        return stamp
    try:
        aware=_us_env.us_iso_timestamp(text)
        if aware is not None:return int(aware)
    except (ValueError,TypeError,OverflowError):pass
    return 0


def name_key(value):
    text=us_casefold(str(value or '')).strip()
    text=re.sub(r'\b(?:uhd|fhd|hd|sd|4k|hevc|h265|h264)\b',' ',text)
    return ' '.join(re.sub(r'[\[\]{}()|:_./\\-]+',' ',text).split())


def header_urls(line,base):
    from .m3u_adapter import _attr_map
    attrs=_attr_map(str(line or '').lstrip('\ufeff'))
    out=[]
    for key in ('url-tvg','x-tvg-url','tvg-url','epg-url'):
        raw=str(attrs.get(key) or '')
        for value in re.split(r'[,\s]+(?=https?://)',raw):
            url=urllib.parse.urljoin(base,value.strip())
            if not value.strip():continue
            try:validate_http_url(url)
            except ValueError:continue
            if url not in out:out.append(url)
    return out[:4]


def source_urls(client):
    out=list(getattr(client,'_xmltv_urls',[]) or [])[:4]
    xt=getattr(client,'_xtream',None) or {}
    if xt.get('base') and xt.get('username') is not None and xt.get('password') is not None:
        url=str(xt['base']).rstrip('/')+'/xmltv.php?'+urllib.parse.urlencode({
            'username':xt['username'],'password':xt['password']})
        if url not in out:out.append(url)
    return out[:4]


def _discover_header_attempt(client,event=None,browser=False):
    """Migrate an old playlist cache with a bounded header read, not a reload."""
    if _cancelled(event):return None
    response=None
    try:
        headers=client._request_headers(browser=browser)
        headers.update({'Accept-Encoding':'identity','Range':'bytes=0-65535'})
        request=urllib.request.Request(client._normalized_url(),headers=headers)
        response=provider_urlopen(request,timeout=8)
        track=getattr(client,'_track_response',None)
        if callable(track):track(response)
        data=b''
        while len(data)<65536:
            if _cancelled(event):return None
            block=response.read(min(4096,65536-len(data)))
            if not block:break
            data+=block
            if b'\n' in data:break
        line=data.decode('utf-8-sig','replace').splitlines()[0] if data else ''
        if not line.startswith('#EXTM3U'):return None
        return header_urls(line,client._normalized_url())
    except Exception:return None
    finally:
        if response is not None:
            untrack=getattr(client,'_untrack_response',None)
            if callable(untrack):untrack(response)
            response.close()


def discover_header(client,event=None):
    for browser in (False,True):
        if _cancelled(event):return None
        urls=_discover_header_attempt(client,event,browser)
        if urls is not None:return urls
    return None


def cache_dir():
    from .persistent_cache import ROOT, hdd_read_ready, persistent_write_gate
    root=os.path.join(ROOT,'m3u','xmltv')
    if not hdd_read_ready() or not persistent_write_gate(root):
        root='/tmp/ultrastalker-xmltv'
    secure_private_dir(root,0o700)
    return root


class GuideCapacityError(ValueError):
    """A capacity limit cannot be repaired by retrying the same large download."""


def _index_limits(path):
    """Large guides live on the configured HDD; RAM/tmp keeps small limits."""
    result={'raw':_RAW_LIMIT,'xml':_XML_LIMIT,'db':_DB_LIMIT,'events':200000,'horizon':3*86400}
    try:
        from .persistent_cache import ROOT, hdd_read_ready, persistent_write_gate
        root=os.path.abspath(os.path.join(ROOT,'m3u','xmltv'))
        persistent=(os.path.commonpath((os.path.abspath(path),root))==root
                    and hdd_read_ready() and persistent_write_gate(root))
        free=shutil.disk_usage(os.path.dirname(path)).free
        if persistent and free>=192*1024*1024:
            result.update(raw=min(512*1024*1024,free//6),xml=2*1024*1024*1024,
                          db=min(512*1024*1024,free//3),events=2000000,horizon=30*3600)
        else:
            result['raw']=min(result['raw'],max(0,free//6))
            result['db']=min(result['db'],max(0,free//3))
    except (OSError,ValueError):pass
    return result


def _require_index_storage(path):
    """Never continue a large HDD write on receiver flash after a lost mount."""
    from .persistent_cache import ROOT, hdd_read_ready, persistent_write_gate
    root=os.path.abspath(os.path.join(ROOT,'m3u','xmltv'))
    if os.path.commonpath((os.path.abspath(path),root))==root:
        if not hdd_read_ready() or not persistent_write_gate(root):
            raise GuideCapacityError('XMLTV HDD unavailable')


def _cancelled(event):
    return bool(event is not None and event.is_set())


def _safe_file(path):
    try:return stat.S_ISREG(os.lstat(path).st_mode) and not os.path.islink(path)
    except OSError:return False


class _LimitedReader:
    def __init__(self,handle,event,limit=None):
        self.handle=handle;self.event=event;self.limit=_XML_LIMIT if limit is None else limit;self.size=0;self.tail=b''
    def read(self,n=-1):
        if _cancelled(self.event):raise InterruptedError('EPG cancelled')
        data=self.handle.read(min(n,65536) if n>=0 else 65536)
        self.size+=len(data)
        if self.size>self.limit:raise GuideCapacityError('XMLTV uncompressed size limit')
        combined=self.tail+data
        if b'<!ENTITY' in combined.upper():raise ValueError('XMLTV entity declarations are unsupported')
        self.tail=combined[-16:]
        return data


def build_index(handle,destination,event=None,now=None,limits=None):
    now=int(time.time() if now is None else now)
    limits=dict(_index_limits(destination) if limits is None else limits)
    _require_index_storage(destination)
    db=sqlite3.connect(destination)
    os.chmod(destination,0o600)
    try:
        # Two MiB page cache, no full-guide RAM copies or end-of-build sort.
        # The disposable index is published only after a successful commit.
        db.execute('PRAGMA journal_mode=OFF')
        db.execute('PRAGMA synchronous=OFF')
        db.execute('PRAGMA cache_size=-2048')
        db.execute('PRAGMA temp_store=FILE')
        page_size=db.execute('PRAGMA page_size').fetchone()[0]
        db.execute('PRAGMA max_page_count=%d'%max(1,limits['db']//page_size))
        db.execute('CREATE TABLE events (cid TEXT, start INTEGER, stop INTEGER, title TEXT, descr TEXT)')
        db.execute('CREATE TABLE aliases (kind TEXT, key TEXT, cid TEXT, PRIMARY KEY(kind,key,cid))')
        db.execute('CREATE INDEX event_channel_time ON events(cid,start)')
        parser=ET.iterparse(_LimitedReader(handle,event,limits['xml']),events=('start','end'))
        root=None;count=0;pending=[];known_ids=set();nodes=0
        def remember_id(cid):
            if cid in known_ids:return
            db.execute('INSERT OR IGNORE INTO aliases VALUES (?,?,?)',('id',us_casefold(cid),cid))
            if len(known_ids)>=8192:us_clear(known_ids)
            known_ids.add(cid)
        def flush():
            if pending:
                db.executemany('INSERT INTO events VALUES (?,?,?,?,?)',pending)
                us_clear(pending)
        for action,node in parser:
            tag=node.tag.rsplit('}',1)[-1]
            if root is None:
                root=node
                if tag!='tv':raise ValueError('Response is not XMLTV')
            if action!='end':continue
            if tag=='channel':
                cid=str(node.get('id') or '')
                if len(cid)>256:cid=''
                if cid:
                    remember_id(cid)
                    for child in node:
                        if child.tag.rsplit('}',1)[-1]=='display-name':
                            key=name_key(''.join(child.itertext()))[:256]
                            if key:db.execute('INSERT OR IGNORE INTO aliases VALUES (?,?,?)',('name',key,cid))
                us_clear(node);us_clear(root);nodes+=1
            elif tag=='programme':
                cid=str(node.get('channel') or '')
                if len(cid)>256:cid=''
                start=timestamp(node.get('start'));stop=timestamp(node.get('stop'))
                if cid and now-2*86400<=start<=now+limits['horizon'] and (not stop or stop>=now-6*3600):
                    title='';descr=''
                    for child in node:
                        key=child.tag.rsplit('}',1)[-1]
                        if key=='title' and not title:title=''.join(child.itertext()).strip()[:512]
                        elif key=='desc' and not descr:descr=''.join(child.itertext()).strip()[:4096]
                    if title:
                        count+=1
                        if count>limits['events']:raise GuideCapacityError('XMLTV programme limit')
                        pending.append((cid,start,stop,title,descr))
                        remember_id(cid)
                        if len(pending)>=256:flush()
                us_clear(node);us_clear(root);nodes+=1
            if nodes and nodes%256==0 and tag in ('channel','programme'):
                if _cancelled(event):raise InterruptedError('EPG cancelled')
                # Give input/render threads a turn while processing large feeds.
                time.sleep(0)
        if root is None:raise ValueError('Empty XMLTV response')
        if not count:raise ValueError('XMLTV has no usable programmes')
        flush()
        if _cancelled(event):raise InterruptedError('EPG cancelled')
        db.commit()
    except sqlite3.OperationalError as exc:
        if 'full' in str(exc).lower():raise GuideCapacityError('XMLTV index capacity')
        raise
    finally:db.close()


def _refresh_attempt(client,url,path,event,browser=False):
    from .provider_requests import account_gate,same_provider,ProviderCancelled,ProviderBusyError,retry_delay
    lease=None
    try:
        if same_provider(client,url):
            lease=account_gate(client).acquire(event,priority=3,preemptible=True,timeout=25)
            event=_CancelEvents(event,lease.preempt)
        return _refresh_attempt_owned(client,url,path,event,browser,lease)
    except ProviderCancelled as exc:raise InterruptedError('EPG cancelled')
    except urllib.error.HTTPError as exc:
        if int(exc.code) in (429,469):
            delay=retry_delay(exc.headers);exc.close()
            if lease is not None:lease.gate.defer(delay,exc.code)
            raise ProviderBusyError(exc.code,delay)
        raise
    except OSError as exc:
        if _cancelled(event):raise InterruptedError('EPG cancelled')
        raise
    finally:
        if lease is not None:lease.release()


def _refresh_attempt_owned(client,url,path,event,browser=False,lease=None):
    if _cancelled(event):raise InterruptedError('EPG cancelled')
    headers=client._request_headers(browser=browser)
    headers.update({'Accept':'application/xml,text/xml,*/*','Accept-Encoding':'gzip'})
    request=urllib.request.Request(url,headers=headers)
    response=None;temporary='';limits=_index_limits(path)
    _require_index_storage(path)
    try:
        response=provider_urlopen(request,timeout=10)
        if lease is not None:lease.bind(response)
        track=getattr(client,'_track_response',None)
        if callable(track):track(response)
        _require_index_storage(path)
        with tempfile.TemporaryFile(dir=os.path.dirname(path)) as raw:
            total=0
            while True:
                if _cancelled(event):raise InterruptedError('EPG cancelled')
                block=getattr(response,'read1',response.read)(65536)
                if not block:break
                total+=len(block)
                if total>limits['raw']:raise GuideCapacityError('XMLTV download size limit')
                raw.write(block)
            if _cancelled(event):raise InterruptedError('EPG cancelled')
            untrack=getattr(client,'_untrack_response',None)
            if callable(untrack):untrack(response)
            response.close();response=None
            if lease is not None:lease.release()
            raw.seek(0);magic=raw.read(2);raw.seek(0)
            reader=gzip.GzipFile(fileobj=raw) if magic==b'\x1f\x8b' else raw
            _require_index_storage(path)
            fd,temporary=tempfile.mkstemp(prefix='.xmltv-',suffix='.tmp',dir=os.path.dirname(path));os.close(fd)
            build_index(reader,temporary,event,limits=limits)
            if _cancelled(event):raise InterruptedError('EPG cancelled')
            _require_index_storage(path)
            os.replace(temporary,path);temporary=''
    except OSError as exc:
        if exc.errno in (errno.ENOSPC,getattr(errno,'EDQUOT',errno.ENOSPC)):
            raise GuideCapacityError('XMLTV storage capacity')
        raise
    finally:
        if response is not None:
            untrack=getattr(client,'_untrack_response',None)
            if callable(untrack):untrack(response)
            response.close()
        if temporary:
            try:os.unlink(temporary)
            except OSError:pass


def _refresh(client,url,path,event):
    """Retry a provider's rejected/default connection once with browser headers."""
    for browser in (False,True):
        if _cancelled(event):raise InterruptedError('EPG cancelled')
        try:
            _refresh_attempt(client,url,path,event,browser)
            return
        except (InterruptedError,GuideCapacityError):raise
        except Exception as exc:
            from .provider_requests import ProviderBusyError
            if isinstance(exc,ProviderBusyError):raise
            if _cancelled(event):raise InterruptedError('EPG cancelled')
            if browser:raise


def query_index(path,ids,name,hours=10,now=None):
    if not _safe_file(path):return []
    now=int(time.time() if now is None else now)
    uri='file:'+urllib.parse.quote(path,safe='/')+'?mode=ro'
    try:_ro_db=sqlite3.connect(uri,uri=True)
    except TypeError:_ro_db=sqlite3.connect(path)  # Python 2: no URI filenames
    with closing(_ro_db) as db:
        cid=''
        for wanted in ids:
            if db.execute('SELECT 1 FROM events WHERE cid=? LIMIT 1',(wanted,)).fetchone():cid=wanted;break
            matches=db.execute('SELECT cid FROM aliases WHERE kind=? AND key=? LIMIT 2',('id',us_casefold(wanted))).fetchall()
            if len(matches)==1:cid=matches[0][0];break
        if not cid and not ids and name:
            matches=db.execute('SELECT cid FROM aliases WHERE kind=? AND key=? LIMIT 2',('name',name_key(name))).fetchall()
            if len(matches)==1:cid=matches[0][0]
        if not cid:return []
        # Apply the bounded result limit to current/future events, not to six
        # hours of retained history. Only the latest past start can have an
        # unknown end; earlier unknown-end events ended at a later start.
        latest=db.execute('SELECT MAX(start) FROM events WHERE cid=? AND start<=?',(cid,now)).fetchone()[0]
        data=db.execute('SELECT start,stop,title,descr FROM events WHERE cid=? AND start<=? '
                        'AND (start>? OR stop>? OR ((stop IS NULL OR stop=0) AND start=?)) '
                        'ORDER BY start LIMIT 513',
                        (cid,now+max(1,min(72,int(hours or 10)))*3600,now,now,latest)).fetchall()
    out=[]
    for pos,(start,stop,title,descr) in enumerate(data):
        if not stop and pos+1<len(data):stop=data[pos+1][0]
        if stop and stop<=now:continue
        out.append({'title':title,'name':title,'description':descr,'descr':descr,
                    'start_timestamp':start,'stop_timestamp':stop,'duration':max(0,stop-start) if stop else 0})
        if len(out)>=512:break
    return out


class _CancelEvents:
    def __init__(self,*events):self.events=tuple(event for event in events if event is not None)
    def is_set(self):return any(event.is_set() for event in self.events)


def client_event(client,event=None):
    return _CancelEvents(getattr(client,'_epg_stop',None),event)


def prepare_header(client,event=None):
    """Discover an older playlist's guide once, including concurrent UI requests."""
    if not getattr(client,'_xmltv_header_pending',False):return
    lock=client._xmltv_header_lock
    while not us_acquire(lock, 0.1):
        if _cancelled(event):raise InterruptedError('EPG cancelled')
    try:
        if _cancelled(event):raise InterruptedError('EPG cancelled')
        if not client._xmltv_header_pending:return
        if time.monotonic()<float(getattr(client,'_xmltv_header_retry_at',0)):return
        urls=discover_header(client,event)
        if _cancelled(event):raise InterruptedError('EPG cancelled')
        if urls is not None:
            client._xmltv_urls=urls;client._xmltv_header_pending=False
        else:client._xmltv_header_retry_at=time.monotonic()+120
    finally:lock.release()


def _source_path(url):
    validate_http_url(url)
    key=hashlib.sha256(url.encode('utf-8')).hexdigest()
    return key,os.path.join(cache_dir(),key+'.sqlite3')


def _prepare_source(client,url,key,path,event):
    lock=_LOCKS[int(key[:8],16)%len(_LOCKS)]
    while not us_acquire(lock, 0.1):
        if _cancelled(event):raise InterruptedError('EPG cancelled')
    try:
        if _cancelled(event):raise InterruptedError('EPG cancelled')
        fresh=_safe_file(path) and time.time()-os.path.getmtime(path)<_TTL
        with _RETRY_LOCK:retry=_RETRIES.get(key,0)
        if not fresh and time.monotonic()>=retry:
            try:
                _refresh(client,url,path,event)
                with _RETRY_LOCK:_RETRIES.pop(key,None)
            except InterruptedError:raise
            except Exception:
                with _RETRY_LOCK:
                    _RETRIES[key]=time.monotonic()+120;_RETRIES.move_to_end(key)
                    while len(_RETRIES)>128:_RETRIES.popitem(last=False)
    finally:lock.release()


def prepare_sources(client,cancel_event=None):
    """Download/index whole feeds once, without fetching a provider channel list."""
    event=client_event(client,cancel_event)
    available=False
    try:
        prepare_header(client,event)
        for url in source_urls(client):
            if _cancelled(event):return
            try:
                key,path=_source_path(url)
                _prepare_source(client,url,key,path,event)
                available = _safe_file(path) or available
            except InterruptedError:return
            except Exception:continue
    except InterruptedError:return
    finally:
        if available and not _cancelled(event):
            client._epg_ready_revision = int(getattr(client,'_epg_ready_revision',0) or 0)+1


def start_prepare(client):
    """One bounded background pass on Live use; no idle refresh loop or GUI I/O."""
    if not source_urls(client) and not getattr(client,'_xmltv_header_pending',False):return
    with client._epg_prepare_lock:
        if client._epg_stop.is_set():return
        worker=client._epg_prepare_thread
        if worker is not None and worker.is_alive():return
        if time.monotonic()<client._epg_prepare_at:return
        client._epg_prepare_at=time.monotonic()+120
        worker=threading.Thread(target=prepare_sources,args=(client,client._epg_stop),name='UltraStalker-XMLTV',daemon=True)
        client._epg_prepare_thread=worker
        worker.start()


def guide_rows(client,ids,name,hours=10,cancel_event=None,cache_only=False):
    event=client_event(client,cancel_event)
    try:
        if not cache_only:prepare_header(client,event)
        for url in source_urls(client):
            if _cancelled(event):return []
            try:
                key,path=_source_path(url)
                # SQLite readers use the last complete index while a replacement
                # is built. Never wait for the network merely to read cached EPG.
                if not cache_only:_prepare_source(client,url,key,path,event)
                if _cancelled(event):return []
                rows=query_index(path,ids,name,hours)
                if rows:return rows
            except InterruptedError:return []
            except Exception:
                # URL/credentials and XML text must never reach routine logs.
                continue
    except InterruptedError:return []
    return []
