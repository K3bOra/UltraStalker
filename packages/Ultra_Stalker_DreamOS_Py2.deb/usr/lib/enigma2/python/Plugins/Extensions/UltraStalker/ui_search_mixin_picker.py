# -*- coding: utf-8 -*-
"""Movement, source picker, details return and selection.

Methods moved verbatim out of ``PortalGlobalSearchScreen`` (ui_screens_search.py); behaviour is unchanged.
This module is imported by ui_screens_search.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, max, min
from .ui_screens_search import (
    OrderedDict,
    _,
    _SOURCE_ROWS,
    os,
)


class SearchPickerMixin(object):
    """Movement, source picker, details return and selection."""

    def move_left(self):
        rows = self._view_results()
        if not rows:
            return
        self.index = (self.index - 1) % len(rows)
        self._render()

    def move_right(self):
        rows = self._view_results()
        if not rows:
            return
        self.index = (self.index + 1) % len(rows)
        self._render()

    def page_left(self):
        rows = self._view_results()
        if not rows:
            return
        self.index = max(0, self.index - self.PAGE_SIZE)
        self._render()

    def page_right(self):
        rows = self._view_results()
        if not rows:
            return
        self.index = min(len(rows) - 1, self.index + self.PAGE_SIZE)
        self._render()

    def _result_context(self, item):
        profile = item.get("_search_profile") if isinstance(item, dict) else None
        if not isinstance(profile, dict):
            profile = self.profile
        owned = self._profile_key(profile) != self._profile_key(self.profile)
        client = self.client if not owned else _client_from_profile(
            profile, timeout=min(8, int(load_settings().get("timeout", 10) or 10))
        )
        return profile, client, owned

    @staticmethod
    def _quality_label(item, position=0):
        row = item if isinstance(item, dict) else {}
        raw = " ".join(str(row.get(k) or "") for k in ("quality", "resolution", "video_quality", "name", "title"))
        upper = raw.upper()
        parts = []
        if any(x in upper for x in ("8K", "4320")): parts.append("8K")
        elif any(x in upper for x in ("4K", "2160", "3840", "UHD")): parts.append("4K UHD")
        elif any(x in upper for x in ("1080", "FHD")): parts.append("1080P FHD")
        elif any(x in upper for x in ("720", " HD")): parts.append("720P HD")
        elif "SD" in upper: parts.append("SD")
        if "DOLBY VISION" in upper or " DV " in (" " + upper + " "): parts.append("Dolby Vision")
        elif "HDR" in upper: parts.append("HDR")
        if any(x in upper for x in ("HEVC", "H265", "H.265", "X265")): parts.append("HEVC")
        return " • ".join(parts) if parts else (_("Result")+" %d" % (int(position) + 1))

    @staticmethod
    def _copy_category_label(item):
        row = item if isinstance(item, dict) else {}
        value = row.get("category_name") or row.get("genre_name") or row.get("category_title") or row.get("category")
        if isinstance(value, (str, int, float)):
            text = str(value).strip()
            if text and not text.isdigit():
                return text[:46]
        return ""

    def _server_buckets(self, group):
        buckets = OrderedDict()
        for row in self._group_copies(group):
            profile = row.get("_search_profile") or {}
            key = self._source_key(profile)
            bucket = buckets.get(key)
            if bucket is None:
                bucket = {
                    "name": str(row.get("_search_portal_name") or profile.get("name") or profile.get("portal") or _("Portal server")),
                    "copies": [],
                }
                buckets[key] = bucket
            bucket["copies"].append(row)
        return list(buckets.values())

    def _source_picker_bind(self):
        # Original Search geometry with the exact Settings green border material.
        # All surfaces are bundled: no image generation during navigation.
        base = os.path.join(os.path.dirname(__file__), "assets_fhd")
        for name, image in (("source_panel", "search_source_panel_412x602.png"),
                            ("source_tile", "set_tile_64.png"),
                            ("source_icon", "set_ic_portal_40.png")):
            try:
                inst = self[name].instance
                if inst is not None: inst.setPixmapFromFile(os.path.join(base, image))
            except Exception as exc: optional_failure("ui.search_source_panel_asset", exc)
        try:
            inst = self["source_list"].instance
            if inst is not None: inst.setSelectionEnable(0)
        except Exception: pass

    def _source_picker_hide(self):
        self._source_picker_active = False
        for name in ("source_panel", "source_tile", "source_icon", "source_title",
                     "source_list", "source_hint"):
            try: self[name].hide()
            except Exception: pass

    def _source_picker_render(self):
        entries = self._source_picker_entries
        n = len(entries)
        idx = max(0, min(self._source_picker_index, n - 1)) if n else 0
        self._source_picker_index = idx
        # Exact Categories-style fixed window: the list *only* contains the
        # visible page, so scrolling never leaves a clipped or ghost selection.
        top = (idx // _SOURCE_ROWS) * _SOURCE_ROWS if n else 0
        self._source_picker_top = top
        rows = []
        for slot, (name, count, data) in enumerate(entries[top:top + _SOURCE_ROWS]):
            rows.append((str(name), "", data, {
                "selected": top + slot == idx,
                "value": str(count) if count else "",
            }))
        self["source_list"].set_icon_rows(rows)
        if rows:
            self["source_list"].moveToIndex(idx - top)
        self["source_hint"].setText(
            "%d/%d • OK %s • %s" % (idx + 1, n, _("Select"), _("Back")))

    def _source_picker_show(self, title, entries, stage="servers"):
        self._source_picker_stage = stage
        self._source_picker_entries = list(entries)
        self._source_picker_index = 0
        self._source_picker_top = 0
        self._source_picker_active = True
        self["source_title"].setText(str(title or _("Portals"))[:42])
        self._source_picker_render()
        for name in ("source_panel", "source_tile", "source_icon", "source_title",
                     "source_list", "source_hint"):
            try: self[name].show()
            except Exception: pass

    def _source_picker_step(self, delta):
        n = len(self._source_picker_entries)
        if not n:
            return
        idx = max(0, min(int(self._source_picker_index), n - 1))
        step = int(delta)
        if abs(step) == 1:
            # Up / Down: cycle through the complete source list, including
            # across page boundaries. Last + Down => first, First + Up => last.
            target = (idx + step) % n
        elif step:
            # Left / Right move one visible eight-row page while keeping the
            # current row where possible. At the last page, Right selects its
            # last source; at the first page, Left selects the first source.
            page = idx // _SOURCE_ROWS
            slot = idx % _SOURCE_ROWS
            last_page = (n - 1) // _SOURCE_ROWS
            if step > 0:
                target = min(n - 1, (page + 1) * _SOURCE_ROWS + slot) if page < last_page else n - 1
            else:
                target = (page - 1) * _SOURCE_ROWS + slot if page > 0 else 0
        else:
            return
        if idx != target:
            self._source_picker_index = target
            self._source_picker_render()

    def _source_picker_back(self):
        if self._source_picker_stage == "copies":
            self._source_picker_show_servers()
        else:
            self._source_picker_hide()

    def _source_picker_accept(self):
        entries = self._source_picker_entries
        idx = self._source_picker_index
        if not (0 <= idx < len(entries)): return
        payload = entries[idx][2]
        if self._source_picker_stage == "servers":
            copies = list((payload or {}).get("copies") or [])
            if len(copies) == 1:
                self._source_picker_hide()
                self._open_result_details(copies[0])
            elif copies:
                self._source_picker_bucket = payload
                self._source_picker_show_copies(payload)
        else:
            self._source_picker_hide()
            self._open_result_details(payload)

    def _source_picker_show_servers(self):
        buckets = self._source_picker_buckets
        entries = []
        for bucket in buckets:
            copies = len(bucket.get("copies") or [])
            entries.append((bucket.get("name") or _("Portal server"),
                            "%d %s" % (copies, _("result") if copies == 1 else _("results")), bucket))
        self._source_picker_show("%s (%d)" % (_("Portals"), len(entries)), entries)

    def _source_picker_show_copies(self, bucket):
        entries = []
        for pos, item in enumerate(bucket.get("copies") or []):
            quality = self._quality_label(item, pos)
            category = self._copy_category_label(item)
            entries.append((quality, category, item))
        self._source_picker_show(str(bucket.get("name") or _("Portal server")), entries, stage="copies")

    def _open_group_servers(self, group):
        buckets = self._server_buckets(group)
        if not buckets: return
        self._source_picker_buckets = buckets
        self._source_picker_show_servers()

    def _open_result_details(self, item):
        """Open Search details using the same proven contract as Favorites.

        Search is only responsible for choosing the source-owned item/context.
        It must not resolve visual peers, read HDD visual bundles, score cached
        seeds or perform any TMDb work before Enigma2 opens Details.  Once the
        screen is open, ContentDetailsScreen follows its normal cache/provider
        completion path exactly as it does for a saved Favorite.
        """
        typ = item.get("_search_media_type") or "vod"
        profile, client, owned = self._result_context(item)
        clean = self._clean_search_copy(item)
        # Favorites parity: source context + item -> Details immediately.
        # Playback ownership (profile/id/cmd/url) remains the selected Search
        # copy; only the temporary owned client is retained until return.
        self._details_owned_client = client if owned else None
        try:
            self.session.openWithCallback(
                self._details_returned, ContentDetailsScreen, profile, client, typ, clean
            )
        except Exception:
            # The Details screen never opened, so nothing will call _details_returned:
            # release the temporary source-owned client here instead of leaking it.
            self._details_returned()
            raise

    def _details_returned(self, _result=None):
        client = getattr(self, "_details_owned_client", None)
        self._details_owned_client = None
        if client is not None:
            try: client.close()
            except Exception: pass
        self._render()

    def select(self):
        rows = self._view_results()
        if not rows or not (0 <= self.index < len(rows)):
            return
        if self._busy:
            try:
                self._cancel_active_async()
            except Exception:
                pass
        item = rows[self.index]
        copies = self._group_copies(item)
        if len(copies) <= 1:
            self._open_result_details(copies[0] if copies else item)
            return
        self._open_group_servers(item)
