# -*- coding: utf-8 -*-
"""Live TV - logo wall (R5.137).

A 6 x 4 wall of channel cards (logo, name, quality chip, favourite star and a
thin NOW progress bar when the provider has guide data for that channel) over a
fully dark page, so the eye goes to the channels.  OK opens the channel full
screen straight away (no preview window).

Built on PremiumLiveGridScreen, so favourites, bouquet MENU, picons, paging and
the full-screen hand-off keep their proven behaviour.  EPG for the visible page is
fetched by one sequential background job (selected card first) and shares the
module-level cache of the 3-column screen, including "this channel has no EPG",
so nothing is drawn (and nothing is asked again) for channels without a guide.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str, int, round, max, min, us_func
from .wqhd_layout import responsive_font as _ultra_rfont, factors as _ultra_factors

def _ultra_osd_scale():
    return _ultra_factors()[1]

os = _us_env.os
queue = _us_env.queue
re = _us_env.re
threading = _us_env.threading
time = _us_env.time

from . import _
from .ui_grid_screens import PremiumLiveGridScreen
from .ui_live_columns import (
    _cache_get, _cache_put, _events_from_rows, _now_state, _EPG_EXECUTOR,
    _TTL_EVENTS, _TTL_NONE, tiered_epg_many, _refresh_ready_epg,
)
from .log import optional_failure
from .ultra import quality_badges, epg_summary

from Components.Label import Label
from Components.Pixmap import Pixmap
from enigma import eTimer, ePoint, eSize, eLabel, gFont

COLS = 6
ROWS = 4
PAGE = COLS * ROWS
CARD_W, CARD_H = 266, 186
X0, Y0 = 102, 180
DX, DY = 290, 210
ART_W, ART_H = 150, 84
BAR_W = 226
_PKG = "/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/"


def _build_skin():
    off = 'position="2000,0" size="1,1"'
    out = ['<screen name="PremiumLiveWallScreen" position="center,center" size="1920,1080" backgroundColor="#04060a" flags="wfNoBorder">']
    out.append(' <widget name="page_adaptive_bg" position="0,0" size="1920,1080" alphatest="off" scale="1" zPosition="0"/>')
    # R5.375: seamless full-width EPG shade; no border or visible lower edge.
    out.append(' <ePixmap position="0,0" size="1920,%d" pixmap="%swall_epg_seamless_shade_1920x180.png" alphatest="blend" zPosition="1"/>' % (Y0, _PKG))
    for n in ("title", "brand", "meta2", "rating", "meta1", "epg_hint", "tech1", "tech2", "tech3", "tech4",
              "channel_name", "preview_status"):
        out.append(' <widget name="%s" %s font="Regular;1" transparent="1" zPosition="1"/>' % (n, off))
    for n in ("tech_bg1", "tech_bg2", "tech_bg3", "tech_bg4", "page_label_bg", "preview_frame", "live_info_bg"):
        out.append(' <widget name="%s" %s alphatest="blend" transparent="1" zPosition="1"/>' % (n, off))
    out.append(' <widget name="now_progress" %s borderWidth="0" zPosition="1"/>' % off)
    # R5.364: keep inherited widgets alive but completely off-screen; the
    # top-left header is reserved exclusively for the focused channel's EPG.
    out.append(' <widget name="wall_title" %s font="Regular;1" transparent="1" zPosition="1"/>' % off)
    out.append(' <widget name="wall_cat" %s font="Regular;1" transparent="1" zPosition="1"/>' % off)
    out.append(' <widget name="wall_acc" %s transparent="1" alphatest="blend" zPosition="1"/>' % off)
    # R5.350: counter in the user-marked empty footer area, before the existing
    # red Back icon.  The four action icons and labels BELOW stay untouched.
    out.append(' <widget name="page_label" position="515,1024" size="420,42" font="Regular;24" halign="center" valign="center" foregroundColor="#aab5bd" transparent="1" zPosition="17" noWrap="1"/>')
    # R5.364: fixed left-aligned NOW/NEXT in the free upper-left header.
    # No adaptive x measurement and no LIVE TV/category overlap.
    out.append(' <widget name="wall_epg_now" position="66,24" size="1818,46" font="Regular;32" halign="left" valign="center" foregroundColor="#4bdb92" transparent="1" zPosition="7" noWrap="1"/>')
    out.append(' <widget name="wall_epg_next" position="66,75" size="1818,36" font="Regular;24" halign="left" valign="center" foregroundColor="#b6c3cb" transparent="1" zPosition="7" noWrap="1"/>')
    out.append(' <widget name="status" position="66,1030" size="800,34" font="Regular;20" halign="left" valign="center" foregroundColor="#aab5bd" transparent="1" zPosition="7" noWrap="1"/>')
    out.append(' <widget name="selection" position="%d,%d" size="%d,%d" pixmap="%swall_card_sel_266x186.png" alphatest="blend" transparent="1" zPosition="3"/>' % (X0, Y0, CARD_W, CARD_H, _PKG))
    for pos in range(PAGE):
        r, c = divmod(pos, COLS)
        x, y = X0 + c * DX, Y0 + r * DY
        out.append(' <ePixmap position="%d,%d" size="%d,%d" pixmap="%swall_card_266x186.png" alphatest="blend" zPosition="2"/>' % (x, y, CARD_W, CARD_H, _PKG))
        out.append(' <widget name="art%d" position="%d,%d" size="%d,%d" alphatest="blend" scale="1" backgroundColor="transparent" transparent="1" zPosition="5"/>' % (pos, x + (CARD_W - ART_W) // 2, y + 14, ART_W, ART_H))
        out.append(' <widget name="item_title%d" position="%d,%d" size="%d,34" font="Regular;22" halign="center" valign="center" foregroundColor="#ffffff" transparent="1" zPosition="6" shadowColor="#000000" shadowOffset="1,1" noWrap="1"/>' % (pos, x + 10, y + 108, CARD_W - 20))
        out.append(' <widget name="item_meta%d" %s font="Regular;1" transparent="1" zPosition="1"/>' % (pos, off))
        out.append(' <widget name="wall_qbg%d" position="%d,%d" size="56,24" pixmap="%swall_chip_56x24.png" alphatest="blend" transparent="1" zPosition="5"/>' % (pos, x + CARD_W - 64, y + 8, _PKG))
        out.append(' <widget name="wall_q%d" position="%d,%d" size="56,24" font="Regular;15" halign="center" valign="center" foregroundColor="#e8eef2" transparent="1" zPosition="6"/>' % (pos, x + CARD_W - 64, y + 8))
        out.append(' <widget name="wall_fav%d" position="%d,%d" size="20,20" pixmap="%swall_star_20.png" alphatest="blend" transparent="1" zPosition="6"/>' % (pos, x + 12, y + 10, _PKG))
        out.append(' <widget name="wall_pt%d" position="%d,%d" size="%d,6" pixmap="%swall_track_226x6.png" alphatest="blend" scale="1" transparent="1" zPosition="5"/>' % (pos, x + 20, y + 156, BAR_W, _PKG))
        out.append(' <widget name="wall_pf%d" position="%d,%d" size="%d,6" pixmap="%swall_fill_226x6.png" alphatest="blend" scale="1" transparent="1" zPosition="6"/>' % (pos, x + 20, y + 156, BAR_W, _PKG))
    for name, x, label_w, key in (("red", 960, 170, "red"), ("green", 1190, 170, "green"), ("yellow", 1420, 170, "yellow"), ("blue", 1650, 170, "blue")):
        out.append(' <widget name="%s" position="%d,1024" size="%d,42" font="Regular;20" halign="left" valign="center" foregroundColor="#ffffff" transparent="1" zPosition="17" noWrap="1" shadowColor="#000000" shadowOffset="1,1"/>' % (name, x + 58, label_w))
        out.append(' <ePixmap position="%d,1024" size="56,42" pixmap="%splayer_keyline_%s_dash_56x42.png" alphatest="blend" zPosition="16"/>' % (x, _PKG, key))
    out.append(' <widget name="live_menu_scrim" position="0,0" size="1920,1080" alphatest="blend" scale="1" transparent="1" zPosition="40"/>')
    out.append(' <widget name="live_menu_list" position="415,268" size="1090,552" scrollbarMode="showNever" transparent="1" zPosition="41"/>')
    out.append('</screen>')
    from .ui_shared_footer import shared_footer_skin
    return shared_footer_skin("\n".join(out))


def _ui():
    from . import ui as _u
    return _u


def _prepared_skin():
    xml = _build_skin()
    try:
        u = _ui()
        xml = u._bind_internal_skin_assets(xml)
        xml = u._prepare_runtime_skin(xml)
    except Exception as exc:
        optional_failure("wall.skin_prepare", exc)
    return xml


def _asset(name):
    try:
        return _ui().asset(name)
    except Exception:
        return os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets_fhd", name)


class PremiumLiveWallScreen(PremiumLiveGridScreen):
    EPG_MARKS = False  # the wall shows a progress bar per card instead
    skin = ""
    columns = COLS
    page_size = PAGE
    image_size = (ART_W, ART_H)
    card_positions = [(X0 + (p % COLS) * DX, Y0 + (p // COLS) * DY) for p in range(PAGE)]
    selection_asset = "wall_card_sel_266x186.png"

    def __init__(self, session, profile, client, media_type, genre, category_title="", live_categories=None, initial_search=""):
        if not PremiumLiveWallScreen.skin:
            PremiumLiveWallScreen.skin = _prepared_skin()
        us_func(PremiumLiveGridScreen.__init__)(self, session, profile, client, media_type, genre, category_title, live_categories, initial_search)
        self["wall_title"] = Label(_("LIVE TV"))
        self["wall_cat"] = Label("")
        self["wall_epg_now"] = Label("")
        self["wall_epg_next"] = Label("")
        self._wl_epg_labels_ready = True
        self["wall_acc"] = Pixmap()
        for p in range(PAGE):
            self["wall_q%d" % p] = Label("")
            self["wall_qbg%d" % p] = Pixmap()
            self["wall_fav%d" % p] = Pixmap()
            self["wall_pt%d" % p] = Pixmap()
            self["wall_pf%d" % p] = Pixmap()
        self._wl_gen = 0
        self._wl_jobs = queue.Queue()
        self._wl_cancel = None
        self._wl_fetch_future = None
        self._wl_fetch_future_gen = -1
        self._wl_fav_sig = None
        self._wl_bar_shown = {}
        self._wl_fetch_timer = eTimer()
        self._wl_fetch_conn = None
        try:
            self._wl_fetch_conn = self._wl_fetch_timer.timeout.connect(self._wl_start_fetch)
        except Exception:
            self._wl_fetch_timer.callback.append(self._wl_start_fetch)
        self._wl_drain_timer = eTimer()
        self._wl_drain_conn = None
        try:
            self._wl_drain_conn = self._wl_drain_timer.timeout.connect(self._wl_drain)
        except Exception:
            self._wl_drain_timer.callback.append(self._wl_drain)
        self._wl_tick_timer = eTimer()
        self._wl_tick_conn = None
        try:
            self._wl_tick_conn = self._wl_tick_timer.timeout.connect(self._wl_tick)
        except Exception:
            self._wl_tick_timer.callback.append(self._wl_tick)
        self["red"].setText(_("Back"))
        self["green"].setText(_("Favorite"))
        self["yellow"].setText(_("Previous page"))
        self["blue"].setText(_("Next page"))
        self.onLayoutFinish.append(self._wl_layout_ready)
        self.onClose.append(self._wl_stop)

    # ---------------------------------------------------------------- basics
    def _wl_show(self, name, visible):
        try:
            if visible:
                self[name].show()
            else:
                self[name].hide()
        except Exception:
            pass

    def _wl_text(self, name, value):
        value = str(value or "")
        try:
            if str(self[name].getText() or "") != value:
                self[name].setText(value)
        except Exception:
            pass

    def _wl_sxy(self):
        return float(getattr(self, "_grid_sx", 1.0) or 1.0), float(getattr(self, "_grid_sy", 1.0) or 1.0)

    def _portal_id(self):
        p = self.profile or {}
        return "%s|%s" % (str(p.get("portal") or p.get("url") or "").rstrip("/").lower(), str(p.get("mac") or p.get("username") or ""))

    @staticmethod
    def _cid(item):
        return str((item or {}).get("id") or (item or {}).get("ch_id") or (item or {}).get("stream_id") or "")

    def _wl_layout_ready(self):
        for p in range(PAGE):
            for n in ("wall_q%d", "wall_qbg%d", "wall_fav%d", "wall_pt%d", "wall_pf%d"):
                self._wl_show(n % p, False)
        self._wl_paint_header()
        self._wl_update_focus_epg()
        try:
            self._wl_tick_timer.start(2000, False)
            self._wl_schedule_fetch()
        except Exception:
            pass

    def _wl_stop(self):
        try:
            if self._wl_cancel is not None:
                self._wl_cancel.set()
        except Exception:
            pass
        for t in ("_wl_fetch_timer", "_wl_drain_timer", "_wl_tick_timer"):
            try:
                getattr(self, t).stop()
            except Exception:
                pass
        for c in ("_wl_fetch_conn", "_wl_drain_conn", "_wl_tick_conn"):
            try:
                conn = getattr(self, c, None)
                if conn is not None:
                    conn.disconnect()
                setattr(self, c, None)
            except Exception:
                pass
        for t, cb in (
            ("_wl_fetch_timer", self._wl_start_fetch),
            ("_wl_drain_timer", self._wl_drain),
            ("_wl_tick_timer", self._wl_tick),
        ):
            try:
                tm = getattr(self, t, None)
                if tm is not None and cb in tm.callback:
                    tm.callback.remove(cb)
            except Exception:
                pass

    # ----------------------------------------------------- inherited chrome
    def _apply_live_static_chrome(self):
        try:
            self._apply_live_chrome({
                "page": _asset("ultra_bg_clean_1920x1080.png"),
                "selected": _asset("wall_card_sel_266x186.png"),
            })
            self._live_static_chrome_bound = True
        except Exception as exc:
            optional_failure("wall.static_chrome", exc)

    def _apply_live_action_footer_geometry(self):
        self._apply_shared_footer_geometry()

    def _refresh_live_epg(self):
        # Wall owns its minute tick and page refresh; no second fetch lane.
        return

    def _schedule_epg(self, item):
        # The wall paints its own per-card EPG; no duplicate per-focus request.
        return

    # ---------------------------------------------------------- navigation
    def _wl_go(self, target):
        self._live_nav_go_absolute(target)

    def move_left(self):
        if not self.grid_items or not self._nav_allowed():
            return
        total = self._live_nav_total()
        if total > 0:
            self._wl_go((self._live_nav_absolute() - 1) % total)

    def move_right(self):
        if not self.grid_items or not self._nav_allowed():
            return
        total = self._live_nav_total()
        if total > 0:
            self._wl_go((self._live_nav_absolute() + 1) % total)

    def move_up(self):
        if not self.grid_items or not self._nav_allowed():
            return
        total = self._live_nav_total()
        if total <= 0:
            return
        cur = self._live_nav_absolute()
        target = cur - COLS
        if target < 0:
            col = cur % COLS
            last_row_start = ((total - 1) // COLS) * COLS
            target = last_row_start + col
            if target >= total:
                target = total - 1 if last_row_start == 0 else max(0, last_row_start - COLS + col)
        self._wl_go(target)

    def move_down(self):
        if not self.grid_items or not self._nav_allowed():
            return
        total = self._live_nav_total()
        if total <= 0:
            return
        cur = self._live_nav_absolute()
        target = cur + COLS
        if target >= total:
            if (cur // COLS) < ((total - 1) // COLS):
                target = total - 1          # shorter last row: land on its final card
            else:
                target = cur % COLS         # wrap to the first row of the first page
                if target >= total:
                    target = 0
        self._wl_go(target)

    def next_page(self):
        self._live_page_shift(1)

    def previous_page(self):
        self._live_page_shift(-1)

    def open_selected(self):
        if self._busy or not self.grid_items:
            return
        if getattr(self, "_bouquet_select_mode", False):
            return us_func(PremiumLiveGridScreen.open_selected)(self)
        item = self.grid_items[self.index]
        if not isinstance(item, dict):
            return
        try:
            self._last_fullscreen_key = str(self._preview_key(item) or "")
        except Exception:
            pass
        self._open_direct_fullscreen(item)

    # ------------------------------------------------------------- picons
    def _grid_set_local(self, slot, path):
        """Wall logos: exact 150x84 derivative of the original picon (never blocky)."""
        source = str(path or "")
        render_path = source
        size = (ART_W, ART_H)
        try:
            from . import ui_grid_screens as _gs
            from .ui_artwork_helpers import _live_row_fit_cached
            is_placeholder = (not source or os.path.basename(source) == os.path.basename(_asset(self.placeholder)))
            is_fitted = bool(source and os.path.basename(os.path.dirname(source)) == "live_row_picon_fit")
            if not is_placeholder and not is_fitted and source:
                ready = _gs._live_fit_ready(source, size)
                if ready:
                    render_path = ready
                    is_fitted = True
                elif source not in _gs._LIVE_FIT_FAILED:
                    render_path = _asset(self.placeholder)
            result = us_func(_gs.PremiumGridBase._grid_set_local)(self, slot, render_path)
            if is_placeholder or is_fitted or not os.path.isfile(source):
                return result
            generation = int(getattr(self, "_grid_generation", 0) or 0)
            token = (generation, int(slot), source, "wall")
            pending = getattr(self, "_live_row_fit_pending", None)
            if pending is None:
                self._live_row_fit_pending = set()
                pending = self._live_row_fit_pending
            if token in pending or getattr(self, "_screen_closed", False) or getattr(self, "_grid_closed", False):
                return result
            pending.add(token)

            def worker(gen=generation, pos=int(slot), src=source, key=token):
                try:
                    if getattr(self, "_screen_closed", False) or getattr(self, "_grid_closed", False):
                        return
                    fitted = _gs._fit_live_row_picon_canvas(src, _gs.PERSISTENT_GENERATED_DIR, size) or src
                    if fitted == src:
                        _gs._LIVE_FIT_FAILED.add(src)
                        self._grid_download_jobs.put((gen, pos, str(src), "live_fit"))
                    if (fitted != src and os.path.isfile(str(fitted))
                            and gen == int(getattr(self, "_grid_generation", 0) or 0)
                            and not getattr(self, "_screen_closed", False)
                            and not getattr(self, "_grid_closed", False)):
                        self._grid_download_jobs.put((gen, pos, str(fitted), "live_fit"))
                except Exception as exc:
                    optional_failure("wall.fit_async", exc)
                finally:
                    try:
                        pending.discard(key)
                    except Exception:
                        pass
            try:
                _gs._LIVE_ROW_FIT_EXECUTOR.submit(worker)
            except Exception as exc:
                pending.discard(token)
                optional_failure("wall.fit_submit", exc)
            return result
        except Exception as exc:
            optional_failure("wall.set_local", exc)
            return us_func(_gs.PremiumGridBase._grid_set_local)(self, slot, render_path)

    # --------------------------------------------------------------- paint
    @staticmethod
    def _quality_tag(item):
        raw = str((item or {}).get("name") or (item or {}).get("title") or "")
        try:
            q = str(quality_badges(raw) or "")
        except Exception:
            q = ""
        q = q.replace("•", " ").split()
        if not q:
            return ""
        tag = q[0].upper()
        return tag if len(tag) <= 4 else ""

    def _wl_is_fav(self, item):
        try:
            return bool(((getattr(self, "_grid_item_state", {}) or {}).get(id(item), {}) or {}).get("favorite"))
        except Exception:
            return False

    def _wl_paint_header(self):
        self._wl_text("wall_cat", str(self.category_title or ""))

    def _render_grid(self):
        result = us_func(PremiumLiveGridScreen._render_grid)(self)
        try:
            self._wl_gen += 1
            try:
                if self._wl_cancel is not None:
                    self._wl_cancel.set()
            except Exception:
                pass
            self._wl_cancel = None
            self._wl_bar_shown = {}
            self._wl_fav_sig = None
            self._wl_paint_header()
            self._wl_update_focus_epg()
            for pos in range(PAGE):
                self._wl_paint_card(pos)
            self._wl_schedule_fetch()
        except Exception as exc:
            optional_failure("wall.render", exc)
        return result

    def _refresh_favorite_button(self, item=None, state=None):
        us_func(PremiumLiveGridScreen._refresh_favorite_button)(self, item, state)
        try:
            items = list(self.grid_items or [])
            sig = tuple(self._wl_is_fav(it) for it in items)
            if sig == self._wl_fav_sig:
                return
            self._wl_fav_sig = sig
            for pos in range(PAGE):
                self._wl_show("wall_fav%d" % pos, pos < len(items) and sig[pos])
        except Exception as exc:
            optional_failure("wall.fav", exc)

    def _wl_paint_card(self, pos):
        items = self.grid_items or []
        if pos >= len(items):
            for n in ("wall_q%d", "wall_qbg%d", "wall_fav%d", "wall_pt%d", "wall_pf%d"):
                self._wl_show(n % pos, False)
            return
        item = items[pos]
        q = ""
        self._wl_text("wall_q%d" % pos, q)
        self._wl_show("wall_q%d" % pos, bool(q))
        self._wl_show("wall_qbg%d" % pos, bool(q))
        self._wl_show("wall_fav%d" % pos, self._wl_is_fav(item))
        self._wl_paint_bar(pos, item)

    def _wl_bar_state(self, item):
        """(has_bar, percent) - a bar exists only when the channel has a current programme."""
        cid = self._cid(item)
        if not cid:
            return False, 0
        hit, data = _cache_get((self._portal_id(), cid))
        if not hit or not data:
            return False, 0
        if data.get("events"):
            cur, pct = _now_state(data)
            if cur >= 0:
                return True, pct
            return False, 0
        summ = data.get("summary") or {}
        if summ.get("now"):
            try:
                return True, max(0, min(100, int(summ.get("percent") or 0)))
            except Exception:
                return True, 0
        return False, 0

    def _wl_paint_bar(self, pos, item):
        has, pct = self._wl_bar_state(item)
        key = (has, pct if not has else int(pct))
        if self._wl_bar_shown.get(pos) == key:
            return
        self._wl_bar_shown[pos] = key
        if not has:
            self._wl_show("wall_pt%d" % pos, False)
            self._wl_show("wall_pf%d" % pos, False)
            return
        width = int(round(BAR_W * pct / 100.0))
        if pct > 0:
            width = max(8, width)
        self._wl_show("wall_pt%d" % pos, True)
        if width > 0:
            try:
                sx, sy = self._wl_sxy()
                inst = self["wall_pf%d" % pos].instance
                try:
                    inst.setScale(1)
                except Exception:
                    pass
                inst.resize(eSize(max(1, int(width * sx)), max(1, int(6 * sy))))
            except Exception:
                pass
        self._wl_show("wall_pf%d" % pos, width > 0)

    def _wl_tick(self):
        if (getattr(self, "_screen_closed", False)
                or getattr(self, "_grid_images_suspended", False)):
            return
        try:
            _refresh_ready_epg(self)
            for pos, item in enumerate((self.grid_items or [])[:PAGE]):
                self._wl_paint_bar(pos, item)
            self._wl_update_focus_epg()
            # Cache expiry needs network refresh, not only a repaint. One
            # bounded background job at a time for this page generation.
            future = getattr(self, "_wl_fetch_future", None)
            running = (future is not None and not future.done()
                       and self._wl_fetch_future_gen == self._wl_gen)
            portal = self._portal_id()
            if not running and any(self._cid(item) and
                    not _cache_get((portal, self._cid(item)))[0]
                    for item in (self.grid_items or [])[:PAGE]):
                self._wl_schedule_fetch()
        except Exception as exc:
            optional_failure("wall.tick", exc)

    def _update_page_counter(self):
        us_func(PremiumLiveGridScreen._update_page_counter)(self)
        self._wl_update_focus_epg()

    # NOW/NEXT read ONLY the existing wall EPG cache, with no extra traffic.
    @staticmethod
    def _wl_epg_clock(stamp):
        try:
            return time.strftime("%H:%M", time.localtime(int(stamp))) if stamp else ""
        except Exception:
            return ""

    @classmethod
    def _wl_epg_line(cls, caption, start, title):
        title = str(title or "").replace("\r", " ").replace("\n", " ").strip()
        if not title:
            return ""
        clock = cls._wl_epg_clock(start)
        return "%s  %s  •  %s" % (caption, clock, title) if clock else "%s  •  %s" % (caption, title)

    def _wl_focus_epg_text(self):
        items = self.grid_items or []
        index = int(self.index or 0)
        if index < 0 or index >= len(items):
            return "", ""
        cid = self._cid(items[index])
        if not cid:
            return "", ""
        hit, data = _cache_get((self._portal_id(), cid))
        if not hit or not data:
            return "", ""
        now = int(time.time())
        events = data.get("events") or []
        if events:
            pos, _pct = _now_state(data, now)
            current = events[pos] if pos >= 0 else None
            future = next((row for row in events if row[0] > now and row is not current), None)
            return (
                self._wl_epg_line(_("NOW"), current[0], current[2]) if current else "",
                self._wl_epg_line(_("NEXT"), future[0], future[2]) if future else "",
            )
        summary = data.get("summary") or {}
        return (
            self._wl_epg_line(_("NOW"), 0, summary.get("now")),
            self._wl_epg_line(_("NEXT"), 0, summary.get("next")),
        )

    @staticmethod
    def _wl_text_width(value, font_size, safety=True):
        """Measure rendered EPG text using Enigma2's own Regular font.

        The raw (un-padded) measurement anchors NOW's final glyph at the
        requested right edge.  A separate safety width protects glyph shaping,
        especially for mixed Arabic/Latin titles.
        """
        if not value:
            return 0
        try:
            from .wqhd_layout import _get_shared_probe
            probe = _get_shared_probe()
            if probe is not None:
                probe.setFont(_ultra_rfont("Regular", int(font_size)))
                probe.setText(str(value))
                width = int(probe.calculateSize().width())
            else:
                width = 0
            if width > 0:
                if not safety:
                    return width
                mixed = any(0x0600 <= ord(c) <= 0x06ff for c in str(value))
                return int(width * (1.15 if mixed else 1.07)) + 12
        except Exception:
            pass
        units = 0.0
        for c in str(value):
            if 0x0600 <= ord(c) <= 0x06ff:
                units += 0.90
            elif c.isupper():
                units += 0.78
            elif c.islower():
                units += 0.62
            elif c.isdigit():
                units += 0.63
            elif c.isspace():
                units += 0.40
            else:
                units += 0.60
        approximate = int(units * int(font_size))
        return int(approximate * 1.13) + 16 if safety else approximate

    @classmethod
    def _wl_epg_geometry(cls, current, following):
        """A fixed top-left viewport; no horizontal movement across channels."""
        return 66, 1818

    def _wl_position_focus_epg(self, current, following):
        if not (current or following):
            return
        try:
            x, width = self._wl_epg_geometry(current, following)
            sx, sy = self._wl_sxy()
            for name, y, height, font in (
                    ("wall_epg_now", 24, 46, 32),
                    ("wall_epg_next", 75, 36, 24)):
                instance = self[name].instance
                if instance is None:
                    continue
                instance.move(ePoint(int(round(x * sx)), int(round(y * sy))))
                instance.resize(eSize(max(1, int(round(width * sx))),
                                      max(1, int(round(height * sy)))))
                instance.setFont(_ultra_rfont("Regular", max(10, int(font))))
        except Exception as exc:
            optional_failure("wall.epg_adaptive_layout", exc)

    def _wl_update_focus_epg(self):
        if not getattr(self, "_wl_epg_labels_ready", False):
            return
        try:
            current, following = self._wl_focus_epg_text()
            # Keep caption, clock and programme together: no separate column
            # can introduce a gap or push NEXT's shorter text to the edge.
            self._wl_text("wall_epg_now", current)
            self._wl_text("wall_epg_next", following)
            self._wl_position_focus_epg(current, following)
        except Exception as exc:
            optional_failure("wall.focus_epg", exc)

    # ------------------------------------------------------------- EPG lane
    def _wl_schedule_fetch(self):
        try:
            self._wl_fetch_timer.stop()
            self._wl_fetch_timer.start(450, True)
        except Exception:
            self._wl_start_fetch()

    def _wl_start_fetch(self):
        if (getattr(self, "_screen_closed", False)
                or getattr(self, "_grid_images_suspended", False) or not self.grid_items):
            return
        gen = self._wl_gen
        if gen != getattr(self, '_wl_retry_gen', None):
            self._wl_retry_gen = gen
            self._wl_retry_after = {}
        future = getattr(self, "_wl_fetch_future", None)
        if (future is not None and not future.done()
                and self._wl_fetch_future_gen == gen):
            return
        try:
            if self._wl_cancel is not None:
                self._wl_cancel.set()
        except Exception:
            pass
        ev = threading.Event()
        self._wl_cancel = ev
        portal = self._portal_id()
        items = list(self.grid_items or [])[:PAGE]
        idx = int(self.index or 0)
        order = sorted(range(len(items)), key=lambda p: (abs(p - idx), p))
        misses = []
        for pos in order:
            cid = self._cid(items[pos])
            if (cid and time.monotonic() >= getattr(self, '_wl_retry_after', {}).get(cid, 0)
                    and not _cache_get((portal, cid))[0]):
                misses.append((pos, cid))
        if not misses:
            return
        client = self.client
        jobs = self._wl_jobs
        many = getattr(client, "epg_many", None)

        def on_each(cid, rows):
            if ev.is_set() or rows is None:
                return
            self._wl_store(portal, cid, rows)
            for pos, wanted in misses:
                if wanted == cid:
                    jobs.put((gen, pos))

        def worker():
            try:
                if not callable(many):
                    for pos, cid in misses:
                        if ev.is_set():
                            return
                        try:
                            rows = client.epg(cid, 10, cancel_event=ev) or []
                        except Exception:
                            continue
                        on_each(cid, rows)
                    return
                # Same alternative-id tiers the 3-column screen and the receiver
                # export use, so the wall shows as many guides as they do.
                tiered_epg_many(client, {cid: items[pos] for pos, cid in misses}, 10, ev, on_each)
            finally:
                jobs.put((gen, -1))

        try:
            self._wl_fetch_future = _EPG_EXECUTOR.submit(
                worker, _task_key="wall-epg:%x" % id(self), _replace_task_key=True)
            self._wl_fetch_future_gen = gen
            self._wl_drain_timer.start(250, False)
        except Exception as exc:
            optional_failure("wall.epg_submit", exc)

    def _wl_store(self, portal, cid, rows):
        key = (portal, cid)
        events = _events_from_rows(rows or [])
        summary = {}
        try:
            summary = epg_summary(rows or []) or {}
        except Exception:
            summary = {}
        if events or summary.get("now"):
            _cache_put(key, {"events": events[:24], "summary": summary}, _TTL_EVENTS)
        else:
            _cache_put(key, None, 45)

    def _wl_drain(self):
        if getattr(self, "_screen_closed", False):
            self._wl_stop()
            return
        done = False
        changed = set()
        while True:
            try:
                gen, pos = self._wl_jobs.get_nowait()
            except queue.Empty:
                break
            if gen != self._wl_gen:
                continue
            if pos < 0:
                done = True
                continue
            changed.add(pos)
        items = self.grid_items or []
        for pos in changed:
            if 0 <= pos < len(items):
                self._wl_paint_bar(pos, items[pos])
        if changed:
            self._wl_update_focus_epg()
        if not done:
            # A page change drops the previous fetch's "done" marker (stale
            # generation).  If nothing is running any more the heartbeat would
            # otherwise poll every 250 ms for the rest of the screen's life.
            try:
                future = getattr(self, "_wl_fetch_future", None)
                done = (future is None or future.done()) and self._wl_jobs.empty()
            except Exception:
                pass
        if done:
            retries = getattr(self, '_wl_retry_after', {})
            now = time.monotonic()
            for item in items:
                cid = self._cid(item)
                if cid and not _cache_get((self._portal_id(), cid))[0]:
                    retries[cid] = now + 15
            self._wl_retry_after = retries
            try:
                self._wl_drain_timer.stop()
            except Exception:
                pass
