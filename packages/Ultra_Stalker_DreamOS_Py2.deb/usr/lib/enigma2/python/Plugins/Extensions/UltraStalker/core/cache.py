# -*- coding: utf-8 -*-
from __future__ import absolute_import, division, print_function, unicode_literals
from .. import us_env as _us_env
from ..us_env import str, int, max, min, us_clear
__metaclass__ = type  # new-style classes on Python 2
hashlib = _us_env.hashlib
json = _us_env.json
threading = _us_env.threading
time = _us_env.time
OrderedDict = _us_env.collections.OrderedDict
from ..repositories.database import DB


class CachePolicy:
    TTL = {"get_genres": 21600, "get_ordered_list": 1800, "get_short_epg": 600, "get_epg_info": 600, "account_info": 900, "capabilities": 86400}

    @classmethod
    def ttl(cls, action, default=120):
        return int(cls.TTL.get(str(action or ""), default))


class CacheManager:
    PURGE_INTERVAL = 600.0

    def __init__(self, max_items=128, max_bytes=8 * 1024 * 1024):
        self.max_items = max_items
        self.max_bytes = max(0, int(max_bytes or 0))
        self._memory = OrderedDict()
        self._sizes = {}
        self._bytes = 0
        self._lock = threading.RLock()
        # DB.initialize() already purges once; the first throttled purge is due
        # one interval after import.
        self._last_purge = time.monotonic()
        self._purging = False

    @staticmethod
    def _approx_size(value):
        try:
            return len(json.dumps(value, ensure_ascii=False, separators=(',', ':')).encode('utf-8'))
        except (TypeError, ValueError):
            return 0

    def _store_locked(self, key, expires, value, size):
        if self.max_bytes and size > self.max_bytes:
            self._drop_locked(key)
            return
        self._bytes -= self._sizes.pop(key, 0)
        self._memory[key] = (expires, value)
        self._memory.move_to_end(key)
        self._sizes[key] = size
        self._bytes += size
        while len(self._memory) > self.max_items or (
                self.max_bytes and self._bytes > self.max_bytes):
            old, _row = self._memory.popitem(last=False)
            self._bytes -= self._sizes.pop(old, 0)

    def _drop_locked(self, key):
        self._memory.pop(key, None)
        self._bytes -= self._sizes.pop(key, 0)

    def _maybe_purge(self):
        """Throttled (10 min) removal of expired SQLite rows on a daemon thread."""
        now = time.monotonic()
        with self._lock:
            if self._purging or now - self._last_purge < self.PURGE_INTERVAL:
                return
            self._purging = True
            self._last_purge = now

        def run():
            try:
                DB.initialize()
                with DB._write_lock:
                    with DB.connect() as db:
                        db.execute('DELETE FROM cache WHERE expires_at < ?', (int(time.time()),))
            except Exception:
                pass
            finally:
                with self._lock:
                    self._purging = False
        try:
            threading.Thread(target=run, name="us-cache-purge", daemon=True).start()
        except Exception:
            with self._lock:
                self._purging = False

    def key(self, portal, mac, params):
        raw = json.dumps([str(portal).rstrip('/').lower(), str(mac).upper(), sorted((str(k), str(v)) for k, v in params.items())], separators=(',', ':'), ensure_ascii=True)
        return hashlib.sha256(raw.encode('utf-8')).hexdigest()

    def get(self, key):
        now = time.time()
        with self._lock:
            row = self._memory.get(key)
            if row:
                expires, value = row
                if expires >= now:
                    self._memory.move_to_end(key)
                    return value
                self._drop_locked(key)
        entry = DB.cache_get_entry(key)
        if entry is not None:
            value, remaining_ttl = entry
            # Never extend a persistent row beyond its original DB expiration.
            memory_ttl = max(1, min(90, int(remaining_ttl or 1)))
            size = self._approx_size(value) if self.max_bytes else 0
            with self._lock:
                self._store_locked(key, now + memory_ttl, value, size)
            return value
        return None

    def put(self, key, value, ttl):
        ttl = max(1, int(ttl))
        expires = time.time() + ttl
        size = self._approx_size(value) if self.max_bytes else 0
        with self._lock:
            self._store_locked(key, expires, value, size)
        DB.cache_put(key, value, ttl)
        self._maybe_purge()

    def clear_memory(self):
        with self._lock:
            us_clear(self._memory)
            us_clear(self._sizes)
            self._bytes = 0

    def clear(self):
        self.clear_memory()
        DB.clear_cache()


CACHE = CacheManager()
