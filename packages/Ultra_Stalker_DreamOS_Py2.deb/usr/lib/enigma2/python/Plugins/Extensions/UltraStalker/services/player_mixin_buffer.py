# -*- coding: utf-8 -*-
"""Playback buffer menu, proxy control and buffer status pill.

Methods moved verbatim out of ``UltraStalkerPlayer`` (player_native.py); behaviour is unchanged.
This module is imported by player_native.py once its module-level helpers exist, so the
names below are taken from that module (partially initialised at this point) on purpose.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from ..us_env import str, int, round, max, min, us_func
from .player_native import (
    LASER_H,
    LASER_W,
    UltraInfobarVisibility,
    _,
    _asset,
    _cached_poster,
    eSize,
    eTimer,
    load_settings,
    optional_failure,
    os,
    parseColor,
    save_settings,
    time,
)


class PlayerBufferMixin(object):
    """Playback buffer menu, proxy control and buffer status pill."""

    def _buffer_menu_lock(self):
        if getattr(self,"_buffer_menu_locked",False):
            return
        self._buffer_menu_locked=True
        self._subtitle_take_key_ownership()
        try:us_func(UltraInfobarVisibility.lockShow)(self)
        except Exception as exc:optional_failure("player.buffer_menu_lock",exc)

    def _buffer_menu_unlock(self):
        if not getattr(self,"_buffer_menu_locked",False):
            return
        self._buffer_menu_locked=False
        try:us_func(UltraInfobarVisibility.unlockShow)(self)
        except Exception as exc:optional_failure("player.buffer_menu_unlock",exc)
        self._subtitle_release_key_ownership()

    def _open_playback_buffer_menu(self):
        """RED: the same inline glass list as subtitles, bound to Playback Buffer."""
        try:
            if getattr(self,"_subtitle_inline_overlay",None) is not None and self._subtitle_inline_overlay.active:
                self._subtitle_inline_finish()
        except Exception:pass
        try:
            if getattr(self,"_server_search_inline_overlay",None) is not None and self._server_search_inline_overlay.active:
                self._server_search_overlay_close()
        except Exception:pass
        steps=(0,8,16,32,64,128,256,512)
        try:current=int(load_settings().get("playback_buffer_mb") or 0)
        except Exception:current=0
        if current not in steps:current=0
        choices=[(_("Off"),0)]+[(_("%d MB")%n,n) for n in steps if n]
        frames=dict(getattr(self,"_player_chrome_frames",{}) or {})
        source=str(getattr(self,"_player_chrome_source","") or "")
        if not (source and os.path.isfile(source)):
            try:source=str(_cached_poster(self.item,self.name,self.media_type) or "")
            except Exception:source=""
        if not (source and os.path.isfile(source)):
            candidate=str(frames.get("main") or "")
            if candidate and os.path.isfile(candidate):source=candidate
        self._buffer_menu_lock()
        return self._buffer_inline_overlay.show(
            choices,selection=steps.index(current),center_x=960,anchor_bottom=780,
            on_accept=self._playback_buffer_selected,on_close=self._buffer_menu_unlock,
            min_card_w=220,max_card_w=420,padding=48,
            visual_style="player_premium",row_h=70,max_visible=8,
            adaptive_source=source,adaptive_accent=frames.get("accent"),
            adaptive_accent_soft=frames.get("accent_soft"),
        )

    def _playback_buffer_selected(self,choice=None):
        self._buffer_menu_unlock()
        if not choice:return
        try:mb=int(choice[1] if isinstance(choice,(tuple,list)) and len(choice)>1 else 0)
        except Exception:mb=0
        if mb not in (0,8,16,32,64,128,256,512):mb=0
        try:save_settings({"playback_buffer_mb":mb})
        except Exception as exc:optional_failure("player.buffer_setting_save",exc)
        self._apply_playback_buffer_now(mb)
        try:
            label=_("Off") if mb<=0 else "%d MB"%mb
            self["connection"].setText(_("Buffer")+"  •  "+label)
            us_func(UltraInfobarVisibility.doShow)(self)
        except Exception:pass

    def _apply_playback_buffer_now(self, mb):
        job = getattr(self, "_buffer_job", None)
        if job is not None and int(mb or 0) <= 0:
            direct=str(getattr(self,"_buffer_direct_url","") or "")
            if direct:
                self._arm_recovery_resume()
                from ..core.playback_buffer import stop_buffer
                self._buffer_gave_up=True
                self._buffer_job=None
                stop_buffer(job)
                timer=getattr(self,"_buffer_timer",None)
                if timer is not None: timer.stop()
                self._suppress_service_events()
                self._buffer_bypass=True
                self.playStream(getattr(self,"_buffer_service",self.servicetype),direct)
                return
        if job is not None:
            try:
                from ..core.playback_buffer import resize_buffer
                if resize_buffer(job, mb): return
            except Exception as exc: optional_failure("player.buffer_resize", exc)
        if int(mb or 0) <= 0: return
        url = str(getattr(self, "_buffer_direct_url", "") or self.streamurl or "")
        if not url.startswith("http") or url.startswith("http://127.0.0.1") or ".m3u8" in url.lower(): return
        self._arm_recovery_resume()
        self._suppress_service_events()
        self._arm_playback_buffer(self.servicetype, url, mb)

    def _buffer_storage_key(self):
        return str(getattr(self, "_subtitle_session_key", "") or getattr(self, "_buffer_direct_url", "") or "")

    def _arm_playback_buffer(self, servicetype, streamurl, megabytes):
        self._buffer_gave_up = False
        self._buffer_pending = None
        self._buffer_direct_url = streamurl
        self._buffer_service = servicetype
        target = streamurl
        try:
            from ..core.playback_buffer import start_buffer, stop_buffer
            stop_buffer(getattr(self, "_buffer_job", None))
            self._buffer_job = None
            if int(megabytes or 0) > 0:
                portal = str((self.item or {}).get("_portal") or "")
                job = start_buffer(streamurl, megabytes, key=self._buffer_storage_key(),
                    trusted_private_origins=(portal,) if portal else ())
                self._buffer_job = job
                target = job.local_url
        except Exception as exc:
            optional_failure("player.buffer_start", exc)
            self._buffer_job = None
            self._buffer_gave_up = True
        self._buffer_bypass = True
        self.playStream(servicetype, target)
        self._schedule_buffer_after_start()

    def _schedule_buffer_after_start(self):
        if getattr(self, "_buffer_job", None) is None or self.restored or getattr(self, "_closing_playback", False):
            return
        timer = getattr(self, "_buffer_timer", None)
        if timer is None:
            timer = self._buffer_timer = eTimer()
            try: self._buffer_timer_conn = timer.timeout.connect(self._poll_playback_buffer)
            except Exception: timer.callback.append(self._poll_playback_buffer)
        try: timer.stop(); timer.start(500, True)
        except Exception as exc: optional_failure("player.buffer_monitor", exc)

    def _start_pending_buffer(self):
        # The decoder opens the buffered URL itself. No parallel downloader.
        return

    def _poll_playback_buffer(self):
        job = getattr(self, "_buffer_job", None)
        if job is None or self.restored or getattr(self, "_closing_playback", False): return
        if getattr(job, "failed", "") or getattr(job, "direct_only", False):
            self._fallback_from_buffer()
            return
        self._schedule_buffer_after_start()

    def _fallback_from_buffer(self):
        if getattr(self, "_buffer_gave_up", False): return False
        direct = str(getattr(self, "_buffer_direct_url", "") or "")
        job = getattr(self, "_buffer_job", None)
        if job is None or not direct or not str(getattr(self, "streamurl", "") or "").startswith("http://127.0.0.1"): return False
        # EOF at the end of a film is not a broken buffer. Never replay it.
        if not (getattr(job, "failed", "") or getattr(job, "direct_only", False)): return False
        self._buffer_gave_up = True
        self._arm_recovery_resume()
        try:
            from ..core.playback_buffer import stop_buffer
            stop_buffer(job)
        except Exception as exc:optional_failure("player.fallback_from_buffer.stop",exc)
        self._buffer_job = None
        self._suppress_service_events()
        self._buffer_bypass = True
        self.playStream(getattr(self, "_buffer_service", self.servicetype), direct)
        return True

    def _buffer_fill_ratio(self, play_ratio):
        job=getattr(self,"_buffer_job",None)
        play_ratio=max(0.0,min(1.0,float(play_ratio or 0.0)))
        if job is None or getattr(self,"_closing_playback",False) or not getattr(job,"prefetch_enabled",True) or getattr(job,"direct_only",False) or getattr(job,"failed",""):
            self._buffer_display_last=None
            return None
        total=int(getattr(job,"content_length",0) or 0)
        if total<=0:
            self._buffer_display_last=None
            return None
        with job._write_lock:
            end=max(0,int(getattr(job,"window_end",0) or 0))
        # Time based: the line shows the SECONDS buffered ahead (the same number as the Buffer
        # text). To real scale 47 s of a 105 min film is under 1% of the line (hidden under the
        # dot), so the length is stretched: 5 minutes ahead = 12% of the line, at most 25%.
        try:
            ahead=getattr(self,"_buffer_ahead_seconds",None)
            cushion=min(0.25,max(0.0,float(ahead))/300.0*0.12) if ahead is not None else 0.0
        except Exception:
            cushion=0.0
        # R19: the cache end (end/total) is NOT used any more. After a seek or an index probe
        # the decoder's range can sit at the far end of the file and drew a line across the
        # whole bar while the text said 15 s. The line now follows the text exactly.
        fill=min(1.0,play_ratio+cushion)
        now=time.monotonic()
        previous=getattr(self,"_buffer_display_last",None)
        drop_since=None
        if previous and previous[0] is job:
            last_play,last_fill,drop_since=previous[1:]
            # A real backward seek may legitimately expose a different cached
            # window. Native zero PTS can instead be the seek handoff sentinel.
            backward=play_ratio>0 and play_ratio<last_play-.002
            if backward:
                drop_since=None
            elif fill<last_fill:
                if drop_since is None:drop_since=now
                if now-drop_since<3.0:fill=last_fill
            else:
                drop_since=None
        display_play=play_ratio
        if previous and previous[0] is job and play_ratio==0 and drop_since is not None and now-drop_since<3.0:
            display_play=previous[1]
        self._buffer_display_last=(job,display_play,fill,drop_since)
        return fill

    def _buffer_note_position(self, position, duration):
        job=getattr(self,"_buffer_job",None)
        if job is None or getattr(self,"_closing_playback",False):
            return
        try:
            duration=int(duration or 0)
            position=max(0,int(position or 0))
            if duration>0:
                try:job.play_ratio=max(0.0,min(1.0,float(position)/float(duration)))
                except Exception:pass
            total=int(getattr(job,"content_length",0) or 0)
            if duration<=0 or total<=0 or position<=0:
                return
            byte=int(total*(float(position)/float(duration)))
            prev=int(getattr(self,"_buffer_noted_pts",0) or 0)
            aligned=bool(getattr(self,"_buffer_aligned",False))
            self._buffer_noted_pts=position
            self._buffer_aligned=True
            # One real skip, or the first note when Continue already sits deep
            # in the file, restarts the download there. Every-second restarts
            # are what made the buffer crawl.
            seek=(prev>0 and abs(position-prev)>(20*90000)) or (not aligned and position>(20*90000))
            from ..core.playback_buffer import note_playhead
            note_playhead(job, byte, seek=seek)
        except Exception as exc:
            optional_failure("player.buffer_playhead",exc)

    def _apply_buffer_glass(self, play_ratio):
        """White bar. On this image this pixmap is the solid one, so it is the movie."""
        try:
            widget=self["buffer_glass"]
            inst=widget.instance
            if inst is None or getattr(self,"_closing_playback",False):
                widget.hide();return
            play_ratio=max(0.0,min(1.0,float(play_ratio or 0.0)))
            end=int(round(_wqhd_wh(LASER_W,LASER_H)[0]*play_ratio))
            if end<=3:
                widget.hide();return
            path=_asset(("player_progress_white_1800x11.png" if _wqhd_wh(LASER_W,LASER_H)[0]==1800 else "player_progress_white_1350x8.png"))
            if path!=self._buffer_glass_path:
                inst.setPixmapFromFile(path);self._buffer_glass_path=path;self._buffer_glass_end=-1
            if not self._buffer_glass_path:
                widget.hide();return
            if end!=self._buffer_glass_end:
                self._buffer_glass_end=end
                inst.resize(eSize(max(1,end),_wqhd_wh(LASER_W,LASER_H)[1]))
            widget.show()
        except Exception as exc:
            optional_failure("player.buffer_glass",exc)

    def _buffer_status_clear(self):
        try:
            self["buffer_status"].setText("")
            self["buffer_status"].hide()
            self["buffer_pill"].hide()
        except Exception as exc:
            optional_failure("player.buffer_status_clear", exc)

    @staticmethod
    def _format_buffer_seconds(seconds):
        seconds = max(0, int(seconds))
        if seconds < 60:
            return "%d s" % seconds
        if seconds < 3600:
            return "%dm %02ds" % (seconds // 60, seconds % 60)
        return "%dh %02dm" % (seconds // 3600, (seconds % 3600) // 60)

    def _buffer_status_paint(self, text, color):
        try:
            if str(self["buffer_status"].getText() or "") != text:
                self["buffer_status"].setText(text)
            if color != self._buffer_status_color:
                inst = self["buffer_status"].instance
                if inst is not None:
                    inst.setForegroundColor(parseColor(color))
                    self._buffer_status_color = color
            if self._lb_active():
                self._lb_fit_status("buffer_status")
            else:
                self["buffer_pill"].show()
            self["buffer_status"].show()
        except Exception as exc:
            optional_failure("player.buffer_status_paint", exc)

    def _update_buffer_status(self, duration=0):
        """Buffer pill in the timeline row: seconds of video buffered ahead
        (bitrate-aware) plus MB, coloured by how safe the cushion is."""
        job = getattr(self, "_buffer_job", None)
        if job is None or getattr(job, "direct_only", False) or getattr(job, "failed", "") or getattr(self, "_closing_playback", False):
            self._buffer_ahead_seconds = None
            self._buffer_status_clear()
            return
        try:
            if getattr(job, "reconnecting", False):
                attempt = max(1, int(getattr(job, "reconnect_attempt", 1) or 1))
                self._buffer_status_paint("%s  %d/4" % (_("Reconnecting"), attempt), self._BUFFER_WARN)
                return
            size = max(0, int(getattr(job, "size", 0) or 0))
            filled = size / 1048576.0
            target = max(0, int(getattr(job, "requested_limit", 0) or getattr(job, "limit", 0) or 0)) / 1048576.0
            total = int(getattr(job, "content_length", 0) or 0)
            seconds = None
            span = int(duration or 0) / 90000.0
            if total > 0 and span > 30.0:
                rate = total / span
                if rate > 0:
                    seconds = size / rate
            # The window must belong to the playhead: a probe at the end of the file (index) or a
            # range that has not caught up with a seek is not "buffered ahead" of what is shown.
            if seconds is not None and total > 0:
                try:
                    with job._write_lock:
                        cursor = int(getattr(job, "window_start", 0) or 0)
                    if abs(cursor / float(total) - float(getattr(job, "play_ratio", 0.0) or 0.0)) > 0.08:
                        seconds = 0.0
                        size = 0
                        filled = 0.0
                except Exception:
                    pass
            self._buffer_ahead_seconds = seconds
            head = _("Buffer")
            if seconds is None:
                text = "%s  %.1f / %.0f MB" % (head, filled, target)
                color = self._BUFFER_GOOD
            else:
                text = "%s  %s  \u2022  %.0f / %.0f MB" % (head, self._format_buffer_seconds(seconds), filled, target)
                if int(getattr(job, "bytes_served", 0) or 0) < 262144:
                    color = self._BUFFER_IDLE
                elif seconds >= 20:
                    color = self._BUFFER_GOOD
                elif seconds >= 8:
                    color = self._BUFFER_WARN
                else:
                    color = self._BUFFER_BAD
            self._buffer_status_paint(text, color)
        except Exception as exc:
            optional_failure("player.buffer_counter", exc)

from ..wqhd_layout import wh as _wqhd_wh
