# -*- coding: utf-8 -*-
"""Saved entries, skeleton, keyboard search and section search.

Methods moved verbatim out of ``PortalBrowserScreen`` (ui_screens_browser.py); behaviour is unchanged.
This module is imported by ui_screens_browser.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, min, us_text_callback, native_text
from .ui_screens_browser import (
    LOG,
    _,
    _live_screen_class,
    _poster_grid3_screen,
    call_compatible,
    time,
)


class BrowserSearchMixin(object):
    """Saved entries, skeleton, keyboard search and section search."""

    def _show_saved_entries(self, entries, title):
        _perf29_saved_t0=time.monotonic()
        if str(title).lower()=="favorites":
            self._show_favorites_root();LOG.info("PERF29 browser favorites_ready elapsed_ms=%d entries=%d",int((time.monotonic()-_perf29_saved_t0)*1000),len(entries or []));return
        self._set_list_density("itv" if (self.media_type == "itv") else "compact")
        portal = str(self.profile.get("portal") or "").rstrip("/").lower()
        mac = str(self.profile.get("mac") or "").upper()
        matching = [x for x in entries if str(x.get("portal") or "").rstrip("/").lower() == portal and str(x.get("mac") or "").upper() == mac and isinstance(x.get("item"), dict)]
        if str(title).lower()=="favorites":
            self._favorite_card_entries=list(matching);self._favorite_card_index=0;self.level="favorites_cards"
            try:self["list"].hide()
            except Exception:pass
            for n in ("preview","accent_frame","info_card1","info_card2","info_card3","info_icon1","info_icon2","info_icon3","info_title","info"):
                try:self[n].hide()
                except Exception:pass
            self["section"].setText(_("Favorites"));self["status"].setText(_("LEFT / RIGHT browse  •  OK open / play"))
            self._render_favorite_cards();return
        self._hide_favorite_cards()
        self.content_items = []
        for entry in matching:
            saved_item = dict(entry["item"])
            saved_item["_saved_media_type"] = entry.get("media_type") or "vod"
            saved_item["_history_position"] = int(entry.get("_position") or 0)
            saved_item["_history_duration"] = int(entry.get("_duration") or 0)
            saved_item["_history_completed"] = bool(entry.get("_completed"))
            self.content_items.append(saved_item)
        self.all_content_items = list(self.content_items)
        self.media_type = matching[0].get("media_type") if matching else "vod"
        self.level = "items"
        rows = []
        for entry in matching:
            item = entry["item"]
            media_type = entry.get("media_type") or "vod"
            title_text = self._favorite_clean_title(media_type,item,120) if str(title).lower()=="favorites" else _clean_display_text(item.get("name") or item.get("title") or item.get("id") or _("Result"), 120)
            icon = "settings_icons_40/channel_list.png" if media_type == "itv" else ("settings_icons_40/artwork.png" if media_type == "vod" else "settings_icons_40/next_episode.png")
            position=int(entry.get("_position") or 0);duration=int(entry.get("_duration") or 0);completed=bool(entry.get("_completed"))
            meta=self._mode_name(media_type)
            if completed: meta += "  •  " + _("WATCHED")
            elif position and duration: meta += "  •  %d%%" % min(99,int(position*100.0/duration))
            elif position: meta += "  •  " + _("RESUME")
            rows.append((title_text, asset(icon), item, meta))
        if not rows:
            rows = [(_("No saved content"), asset("us89_folder_yellow_42.png"), None, {"meta":title,"row_asset":_neutral_utility_glass().get("utility_row"),"row_selected_asset":_neutral_utility_glass().get("utility_selected")})]
        self["list"].set_icon_rows(rows)
        self["section"].setText(title)
        self["counter"].setText(_("Items: %d") % len(matching))
        self["status"].setText(_("MENU: tools  •  OK: open / play"))
        self._selection_changed()

    def _show_skeleton(self, label="Loading premium content"):
        """Keep browser loading visually clean.

        us199: never render fake category/content rows, the Enigma2 default
        red selection bar or a temporary scrollbar while portal data is still
        arriving.  The premium page stays calm, then the real rows appear in
        one reveal when the request completes.
        """
        self["counter"].setText(_("Loading"))
        try:self["list"].hide()
        except Exception as exc:optional_failure("ui.silent_guard",exc)
        for name in ("accent_frame","preview","info_card1","info_card2","info_card3","info_icon1","info_icon2","info_icon3","info_title","info"):
            try:self[name].hide()
            except Exception as exc:optional_failure("ui.silent_guard",exc)

    def _reveal_browser_content(self):
        """Reveal real Browser content after portal rows are ready.

        Categories are intentionally special: only their floating rail is
        revealed.  Re-showing the generic preview/info widgets here was the
        reason the large section icon survived on the right in Test12.
        """
        if self.level == "genres":
            try:self["list"].show()
            except Exception as exc:optional_failure("ui.silent_guard",exc)
            self._set_category_clean_visibility(True)
            if self._category_glass_wanted():
                try:self._category_glass_header()
                except Exception as exc:optional_failure("ui.category_glass_header",exc)
            try:self["page_adaptive_bg"].show()
            except Exception as exc:optional_failure("ui.silent_guard",exc)
            return
        if str(self.level).startswith("catchup"):
            for name in ("list","info_title","info","status"):
                try:self[name].show()
                except Exception as exc:optional_failure("ui.silent_guard",exc)
            try:self["preview"].hide()
            except Exception:pass
            return
        for name in ("list","preview","info_title","info"):
            try:self[name].show()
            except Exception as exc:optional_failure("ui.silent_guard",exc)

    def _open_enigma_search_keyboard(self, callback, title):
        """Same receiver keyboard as Global Search, including MENU recent history."""
        try:
            from Screens.VirtualKeyBoard import VirtualKeyBoard
        except Exception:
            VirtualKeyBoard = None
        try:
            from Screens.ChoiceBox import ChoiceBox
        except Exception:
            ChoiceBox = None
        recent = [str(x).strip() for x in (_load_recent_searches() or []) if str(x or "").strip()]
        if recent:
            title = title + "  •  " + _("MENU: recent")
        if VirtualKeyBoard is None:
            self.session.openWithCallback(us_text_callback(callback), InputBox, title=native_text(title), text=native_text(""), maxSize=60)
            return
        keyboard = self.session.openWithCallback(us_text_callback(callback), VirtualKeyBoard, title=native_text(title), text=native_text(""))
        if ChoiceBox is None or ActionMap is None:
            return
        try:
            amap = ActionMap(["MenuActions", "UltraStalkerMenuActions"], {"menu": lambda: self._recent_search_from_keyboard(keyboard, ChoiceBox)}, -1000)
            keyboard["ultrastalker_recent_search_actions"] = amap
            try: amap.execBegin()
            except Exception: pass
            def cleanup():
                try: amap.execEnd()
                except Exception: pass
                try:
                    if getattr(keyboard, "widgets", {}).get("ultrastalker_recent_search_actions") is amap:
                        keyboard.widgets.pop("ultrastalker_recent_search_actions", None)
                except Exception: pass
            try: keyboard.onClose.append(cleanup)
            except Exception: pass
        except Exception as exc:
            optional_failure("ui.browser_search_keyboard", exc)

    def _recent_search_from_keyboard(self, keyboard, choice_box):
        recent = [str(x).strip() for x in (_load_recent_searches() or []) if str(x or "").strip()]
        if not recent:
            return
        def picked(choice):
            if not choice:
                return
            term = choice[1] if isinstance(choice, (tuple, list)) and len(choice) > 1 else choice[0]
            term = str(term or "").strip()
            if not term:
                return
            try: keyboard.close(term)
            except Exception as exc: optional_failure("ui.browser_search_recent_close", exc)
        owner = getattr(keyboard, "session", None) or self.session
        owner.openWithCallback(picked, choice_box, title=_("Recent searches"), list=list((term, term) for term in recent[:100]))

    def open_search(self):
        if self.level == "genres" and self.media_type in ("itv", "vod", "series"):
            title = {"vod": _("Search movies"), "series": _("Search series"), "itv": _("Search channels")}.get(self.media_type, _("Search"))
            self._open_enigma_search_keyboard(self._open_section_search_results, title)
            return
        if self.level != "items" or not self.content_items:
            self["status"].setText(_("Search is available inside content lists"))
            return
        self._open_enigma_search_keyboard(self._search_done, _("Search content"))

    def _search_done(self, term):
        self._set_list_density("itv" if (self.media_type == "itv") else "compact")
        term = str(term or "").strip()
        if not term: return
        _save_recent_search(term)
        q = _search_key(term)
        rows=[]
        icon="settings_icons_40/channel_list.png" if self.media_type=="itv" else ("settings_icons_40/artwork.png" if self.media_type=="vod" else "settings_icons_40/next_episode.png")
        source = getattr(self, "all_content_items", self.content_items)
        indexed = getattr(self, "_content_search_index", None)
        if not indexed or len(indexed) != len(source):
            indexed = list((_search_key(e.get("name") or e.get("title") or ""), e) for e in source)
            self._content_search_index = indexed
        self._filtered_items=list(e for key, e in indexed if q in key)
        self.content_items = list(self._filtered_items)
        for e in self._filtered_items:
            title=str(e.get("name") or e.get("title") or e.get("id") or _("Result"))
            sec=str(e.get("year") or e.get("number") or e.get("genre") or "")
            rows.append((title,asset(icon),e,sec))
        if not rows: rows=[(_("No search results"),asset(icon),None,term)]
        self["list"].set_icon_rows(rows)
        self["counter"].setText(_("Results: %d") % len(self._filtered_items))
        self["section"].setText(_("%s  /  Search: %s") % (self._mode_name(self.media_type), term[:30]))
        self["status"].setText(_("MENU: new search  •  BLUE: restore list"))

    def _section_view_screen(self, media):
        if media == "itv":
            return _live_screen_class(PremiumLiveGridScreen)
        cfg = load_settings()
        view_key = "movies_view_mode" if media == "vod" else "series_view_mode"
        view_mode = str(cfg.get(view_key) or "cinematic").lower()
        if view_mode == "cinematic":
            return PremiumGlobalCinematicScreen
        if view_mode == "backdrop2":
            return PremiumBackdropGrid2Screen
        if view_mode == "backdrop":
            return PremiumBackdropGridScreen
        if view_mode == "poster_legacy":
            return PremiumPosterGridScreen
        if view_mode == "poster3":
            return _poster_grid3_screen()
        return PremiumPosterGridV2Screen

    def _open_section_search_results(self, term):
        """Red search: this section only, then open it in the user's view."""
        term = str(term or "").strip()
        media = str(self.media_type or "")
        if not term or media not in ("vod", "series", "itv"):
            return
        try:
            _save_recent_search(term)
        except Exception:
            pass
        screen = self._section_view_screen(media)
        title = self._mode_name(media)
        if media == "itv":
            cats = [dict(x) for x in (self.content_items or []) if isinstance(x, dict)]
            self.session.openWithCallback(self._grid_returned, screen, self.profile, self.client, media, "*", title, cats, term)
            return
        self.session.openWithCallback(self._grid_returned, screen, self.profile, self.client, media, "*", title, term)

    def _search_all_folders(self, term):
        term = str(term or "").strip()
        if not term:
            return
        _save_recent_search(term)
        media = self.media_type
        self["status"].setText(_("Searching all folders..."))
        def work(handle):
            return call_compatible(
                self.client.ordered_all,
                (((media, "*"), {"max_items": 20000, "cancel_event": handle.cancel_event}),
                 ((media, "*", 1, None, 20000, handle.cancel_event), {})),
            ) or []
        def ok(rows):
            valid = [row for row in (rows or []) if isinstance(row, dict)]
            self.level = "items"
            self.genre = "*"
            self.content_items = valid
            self.all_content_items = list(valid)
            self._content_search_index = None
            self._search_done(term)
        def failed(exc):
            self["status"].setText(_("Search failed: %s") % exc)
        self._run_async(work, ok, failed)
