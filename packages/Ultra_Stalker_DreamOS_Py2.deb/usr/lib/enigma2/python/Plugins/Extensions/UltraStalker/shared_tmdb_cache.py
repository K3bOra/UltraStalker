# -*- coding: utf-8 -*-
"""Cross-screen TMDb requests and Full-HD backdrop masters on the HDD."""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str, int, open, round, max, min, OSError, IOError, us_clear
import copy
hashlib = _us_env.hashlib
json = _us_env.json
os = _us_env.os
re = _us_env.re
shutil = _us_env.shutil
threading = _us_env.threading
time = _us_env.time
urllib = _us_env.urllib
import weakref
OrderedDict = _us_env.collections.OrderedDict
from .persistent_cache import BACKDROPS, INDEX, hdd_ready, hdd_read_ready, ensure_persistent_dirs, persistent_write_gate
from .netsec import build_safe_https_media_opener
from .core.image_budget import image_budgeted
try:
    from .pil_compat import supports_webp as _supports_webp
except Exception:
    _supports_webp = lambda: False
_GUARD = threading.RLock()
_LOCKS = weakref.WeakValueDictionary()
_RAM = OrderedDict()
_LOCAL = threading.local()
REQUEST_TTL = 24 * 3600.0
SEARCH_TTL = 6 * 3600.0
NEGATIVE_TTL = 15 * 60.0
ERROR_TTL = 5.0
_ERRORS = {}

def _lock(key):
    with _GUARD:
        value = _LOCKS.get(key)
        if value is None:
            value = threading.RLock()
            _LOCKS[key] = value
        return value

def failure_count():
    return int(getattr(_LOCAL, 'failures', 0))

def _key(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), default=str).encode('utf-8')).hexdigest()

def _read(key):
    with _GUARD:
        row = _RAM.get(key)
        if row is not None:
            _RAM.move_to_end(key)
    if row is None and hdd_read_ready():
        try:
            with open(os.path.join(INDEX, 'tmdb_requests', key + '.json'), 'r', encoding='utf-8') as f:
                row = json.load(f)
        except (OSError, ValueError):
            return None
    if not isinstance(row, dict) or row.get('schema') != 1:
        return None
    try:
        if float(row.get('expires') or 0) <= time.time():
            return None
    except (TypeError, ValueError):
        return None
    with _GUARD:
        _RAM[key] = row
        _RAM.move_to_end(key)
        while len(_RAM) > 128:
            _RAM.popitem(last=False)
    return copy.deepcopy(row.get('value'))

def _write(key, value, ttl):
    row = {'schema': 1, 'expires': time.time() + ttl, 'value': copy.deepcopy(value)}
    with _GUARD:
        _RAM[key] = row
        _RAM.move_to_end(key)
        while len(_RAM) > 128:
            _RAM.popitem(last=False)
    root = os.path.join(INDEX, 'tmdb_requests')
    if not hdd_ready() or not ensure_persistent_dirs(root):
        return
    path = os.path.join(root, key + '.json')
    temp = path + '.tmp.%d.%d' % (os.getpid(), threading.get_ident())
    try:
        if not persistent_write_gate(temp):
            return
        with open(temp, 'w', encoding='utf-8') as f:
            json.dump(row, f, ensure_ascii=False, separators=(',', ':'))
            f.flush()
        os.chmod(temp, 384)
        if persistent_write_gate(path):
            os.replace(temp, path)
    except (OSError, ValueError):
        pass
    finally:
        try:
            if os.path.exists(temp) and persistent_write_gate(temp):
                os.unlink(temp)
        except OSError:
            pass

def request_json(credential, path, params, loader):
    """Exact endpoint+parameters+credential sharing; locale stays in the key.

    Errors are never persisted as identity misses. A short RAM cooldown lets
    concurrent failing callers reuse the error, then permits a fresh attempt.
    """
    key = _key(['request-v1', hashlib.sha256(str(credential).encode('utf-8')).hexdigest(), path, params or {}])
    with _lock(key):
        value = _read(key)
        if value is not None:
            return value
        with _GUARD:
            err = _ERRORS.get(key)
        if err and time.monotonic() - err[0] < ERROR_TTL:
            _LOCAL.failures = failure_count() + 1
            raise err[1]
        try:
            value = loader()
        except Exception as exc:
            _LOCAL.failures = failure_count() + 1
            with _GUARD:
                if len(_ERRORS) > 128:
                    us_clear(_ERRORS)
                _ERRORS[key] = (time.monotonic(), exc)
            raise
        with _GUARD:
            _ERRORS.pop(key, None)
        ttl = SEARCH_TTL if path.startswith('/search/') else REQUEST_TTL
        if isinstance(value, dict) and 'results' in value and (not value.get('results')):
            ttl = NEGATIVE_TTL
        if isinstance(value, dict) and path.startswith('/find/'):
            result_keys = list((k for k in value if k.endswith('_results')))
            if result_keys and (not any((value.get(k) for k in result_keys))):
                ttl = NEGATIVE_TTL
        if isinstance(value, dict) and path.endswith('/images'):
            if not any((value.get(k) for k in ('posters', 'backdrops', 'logos'))) and (not value.get('results')):
                ttl = NEGATIVE_TTL
        _write(key, value, ttl)
        return copy.deepcopy(value)

def identity_once(credential, language, media_type, item, hot, loader):
    fields = ('name', 'title', '_raw_name', '_provider_name', '_local_identity_title', '_local_name_first_identity', '_local_media', 'source_type', '_source_type', 'year', 'release_year', 'release_date', 'first_air_date', 'releaseDate', 'tmdb_id', 'movie_id', 'series_id', 'imdb_id', 'imdb', 'description', 'descr', 'overview', 'plot', 'country', 'countries', 'country_code', 'origin_country', 'original_language', 'original_title', 'original_name', '_tmdb_aliases', '_search_aliases', '_title_aliases', '_tmdb_id', '_locked_tmdb_id', '_locked_tmdb_type', 'english_name', 'english_title', 'o_name', '_ultra_search_verified_tmdb_id', 'number_of_episodes', 'number_of_seasons', '_local_episode_count', '_local_max_season', '_local_season_count', 'tmdb', '_origin_country', '_origin_language', 'production_countries', 'origin_countries', 'region', 'production_country', '_blue_detached_exact')
    evidence = {k: item[k] for k in fields if k in item}
    key = _key(['identity-miss-v2', hashlib.sha256(str(credential).encode('utf-8')).hexdigest(), language, media_type, evidence, hot or {}])
    with _lock(key):
        cached = _read(key)
        if cached is not None:
            return tuple(cached)
        failed = failure_count()
        result = loader()
        if not result[1] and failure_count() == failed:
            _write(key, list(result), NEGATIVE_TTL)
        return result

def original_url(url):
    p = urllib.parse.urlsplit(str(url or ''))
    if p.scheme not in ('http', 'https') or (p.hostname or '').lower() != 'image.tmdb.org':
        return ''
    if p.port not in (None, 80, 443) or p.username or p.password:
        return ''
    path = re.sub('^/t/p/(?:original|w\\d+|h\\d+)/', '/t/p/original/', p.path)
    if not path.startswith('/t/p/original/') or not path[len('/t/p/original/'):]:
        return ''
    return 'https://image.tmdb.org' + path

def backdrop_path(url):
    url = original_url(url)
    return os.path.join(BACKDROPS, hashlib.sha1(url.encode('utf-8')).hexdigest()[:32] + '.jpg') if url else ''

def _valid(path):
    try:
        size = os.path.getsize(path) if path and os.path.isfile(path) else 0
        if size <= 1024:
            return False
        with open(path, 'rb') as f:
            head = f.read(3)
            f.seek(max(0, size - 4096))
            tail = f.read()
        return head == b'\xff\xd8\xff' and b'\xff\xd9' in tail
    except OSError:
        return False

def cached_backdrop(url):
    path = backdrop_path(url)
    return path if hdd_read_ready() and _valid(path) else ''

@image_budgeted
def _fullhd(raw, target):
    from PIL import Image
    with Image.open(raw) as image:
        w, h = image.size
        if w < 320 or h < 180 or w < h or (w * h > 64 * 1024 * 1024):
            raise IOError('Invalid landscape dimensions')
        try:
            image.draft('RGB', (1920, 1080))
        except Exception:
            pass
        image = image.convert('RGB')
        w, h = image.size
        scale = min(1.0, 1920.0 / float(w), 1080.0 / float(h))
        if scale < 0.999:
            res = getattr(getattr(Image, 'Resampling', Image), 'LANCZOS', 1)
            image = image.resize((max(1, int(round(w * scale))), max(1, int(round(h * scale)))), res)
        image.save(target, 'JPEG', quality=60, subsampling=2, optimize=False, progressive=False)
    if not _valid(target):
        raise IOError('Invalid Full-HD master')

def fetch_backdrop(url, timeout=10):
    """Stream one original once, store one shared Full-HD master atomically.

    This is worker-only. All consumers wait on the same image key; cancelling
    one screen cannot cancel another screen's download or destroy the master.
    """
    url = original_url(url)
    target = backdrop_path(url)
    if not target:
        return ''
    hit = cached_backdrop(url)
    if hit:
        return hit
    with _lock(target):
        hit = cached_backdrop(url)
        if hit:
            return hit
        with _GUARD:
            err = _ERRORS.get(target)
        if err and time.monotonic() - err[0] < ERROR_TTL:
            raise IOError(err[1])
        if not hdd_ready() or not ensure_persistent_dirs(os.path.dirname(target)):
            return ''
        raw = target + '.raw.%d.%d' % (os.getpid(), threading.get_ident())
        temp = raw + '.jpg'
        try:
            if not persistent_write_gate(raw):
                return ''
            accept_hdr = 'image/jpeg,image/png,image/webp' if _supports_webp() else 'image/jpeg,image/png'
            req = urllib.request.Request(url, headers={'User-Agent': 'UltraStalker/9.2.2', 'Accept': accept_hdr})
            opener = build_safe_https_media_opener(allowed_hosts=('image.tmdb.org',))
            total = 0
            with opener.open(req, timeout=max(4, min(20, float(timeout)))) as response:
                if int(getattr(response, 'status', 200) or 200) != 200:
                    raise IOError('Backdrop HTTP failure')
                declared = int(response.headers.get('Content-Length') or 0)
                if declared > 24 * 1024 * 1024:
                    raise IOError('Backdrop exceeds limit')
                with open(raw, 'wb') as f:
                    while True:
                        chunk = response.read(65536)
                        if not chunk:
                            break
                        total += len(chunk)
                        if total > 24 * 1024 * 1024:
                            raise IOError('Backdrop exceeds limit')
                        f.write(chunk)
                    f.flush()
            if total <= 1024 or (declared and declared != total):
                raise IOError('Incomplete backdrop')
            if not persistent_write_gate(temp):
                return ''
            try:
                _fullhd(raw, temp)
            except Exception as _fh_exc:
                if not _valid(raw):
                    raise _fh_exc
                _us_env.shutil.copyfile(raw, temp)
            if not persistent_write_gate(target):
                return ''
            os.replace(temp, target)
            with _GUARD:
                _ERRORS.pop(target, None)
            return target
        except Exception as exc:
            with _GUARD:
                if len(_ERRORS) > 128:
                    us_clear(_ERRORS)
                _ERRORS[target] = (time.monotonic(), str(exc))
            raise
        finally:
            for path in (raw, temp):
                try:
                    if os.path.exists(path) and persistent_write_gate(path):
                        os.unlink(path)
                except OSError:
                    pass

def materialize_backdrop(url, target, timeout=10, replace_existing=False):
    """Canonical per-title paths reuse the shared bytes, with no second fetch."""
    if not replace_existing and hdd_read_ready() and _valid(target):
        return target
    source = fetch_backdrop(url, timeout)
    if not source:
        return None
    if os.path.abspath(source) == os.path.abspath(target):
        return source
    with _lock(target):
        if not replace_existing and _valid(target):
            return target
        if not hdd_ready() or not ensure_persistent_dirs(os.path.dirname(target)):
            return None
        temp = target + '.shared.%d.%d' % (os.getpid(), threading.get_ident())
        try:
            if not persistent_write_gate(temp):
                return None
            try:
                os.link(source, temp)
            except OSError:
                shutil.copyfile(source, temp)
            if not persistent_write_gate(target):
                return None
            os.replace(temp, target)
            return target
        finally:
            try:
                if os.path.exists(temp) and persistent_write_gate(temp):
                    os.unlink(temp)
            except OSError:
                pass
