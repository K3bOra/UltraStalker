"""Dynamic chrome builders extracted from ui.py with dependency injection.

The public builder functions retain their original bodies; only the UI-owned
cache primitives are configured after ui.py defines them.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str, int, round, max, min

os = _us_env.os
hashlib = _us_env.hashlib
threading = _us_env.threading

try:
    from PIL import Image as _PILImage, ImageFilter as _PILImageFilter, ImageDraw
except Exception:
    _PILImage = None
    _PILImageFilter = None
    ImageDraw = None

from .adaptive_mode import adaptive_enabled, fixed_source, fixed_chrome, is_static_source
from .log import optional_failure
from .persistent_cache import durable_view_path
from .ui_dynamic_palette import _dynamic_palette
from .ui_helpers import _lift_dynamic_accent, _mix_rgb
from .ui_clean_glass import glass as _cg_glass, disc as _cg_disc
from .core.image_budget import image_budgeted

THUMB_CACHE_DIR = ""
CATEGORY_ADAPTIVE_TMP_DIR = ""
DETAILS_ADAPTIVE_CACHE_DIR = ""
_persistent_write_ok = None
_persistent_write_require = None
_valid_cache_file = None

def configure_dynamic_chrome(thumb_cache_dir, persistent_write_ok, persistent_write_require, valid_cache_file, category_adaptive_tmp_dir="", details_adaptive_cache_dir=""):
    global THUMB_CACHE_DIR, CATEGORY_ADAPTIVE_TMP_DIR, DETAILS_ADAPTIVE_CACHE_DIR, _persistent_write_ok, _persistent_write_require, _valid_cache_file
    THUMB_CACHE_DIR = thumb_cache_dir
    CATEGORY_ADAPTIVE_TMP_DIR = category_adaptive_tmp_dir
    DETAILS_ADAPTIVE_CACHE_DIR = details_adaptive_cache_dir or thumb_cache_dir
    _persistent_write_ok = persistent_write_ok
    _persistent_write_require = persistent_write_require
    _valid_cache_file = valid_cache_file


def canonical_dynamic_details_key(source_path):
    """Return the shared cache identity for Details-style adaptive chrome.

    Screen names must never participate in this key. The same source artwork
    revision therefore produces one reusable 24-file chrome bundle whether it
    is requested by Details, Cinematic focus or Backdrop Grid.
    """
    try:
        from .core.generated_cache import canonical_dynamic_details_key as _canonical
        return _canonical(source_path)
    except Exception:
        return ""

def canonical_dynamic_rows_key(source_path, selected_rim_only=False, cinematic_premium=False):
    try:
        from .core.generated_cache import canonical_dynamic_rows_key as _canonical
        return _canonical(source_path, selected_rim_only=selected_rim_only, cinematic_premium=cinematic_premium)
    except Exception:
        return ""


def _build_dynamic_details_gradient(source_path,target_path,size=(1920,1080)):
    if not _persistent_write_ok(THUMB_CACHE_DIR): return None
    """Create a cached dark colour field matched to the current artwork.

    The gradient intentionally contains no recognisable image content. It is
    safe on Enigma2 renderers because it is a normal opaque JPEG, not a live
    alpha/blur effect. The builder works on 1-pixel strips then scales them, so
    palette generation is cheap even on slower receivers.
    """
    if _PILImage is None or not source_path or not os.path.isfile(source_path):return None
    if _valid_cache_file(target_path):return target_path
    temp=target_path+".tmp.%d.%d"%(os.getpid(),threading.get_ident())
    try:
        primary,secondary=_dynamic_palette(source_path,poster=True);tw,th=int(size[0]),int(size[1]);base=(2,7,12)
        strip=[]
        for x in range(tw):
            nx=x/float(max(1,tw-1))
            # primary -> secondary -> near-black. Colour is strongest in the
            # poster/left area and is almost gone by the hero's far edge.
            if nx<=0.20:
                t=nx/0.20;left=primary;right=secondary
            elif nx<=0.48:
                t=(nx-0.20)/0.28;left=secondary;right=base
            else:
                t=min(1.0,(nx-0.48)/0.52);left=base;right=(1,4,8)
            ease=t*t*(3.0-2.0*t)
            strip.append(tuple(int(left[i]*(1.0-ease)+right[i]*ease) for i in range(3)))
        row=_PILImage.new("RGB",(tw,1));row.putdata(strip);img=row.resize((tw,th))
        # Darken progressively toward the bottom while retaining a subtle tint.
        vmask=_PILImage.new("L",(1,th));vmask.putdata([int(22+74*((y/float(max(1,th-1)))**1.35)) for y in range(th)])
        vmask=vmask.resize((tw,th));black=_PILImage.new("RGB",(tw,th),(1,4,8));img=_PILImage.composite(black,img,vmask)
        if _PILImageFilter is not None:img=img.filter(_PILImageFilter.GaussianBlur(radius=4))
        _persistent_write_require(temp);img.save(temp,"JPEG",quality=88,optimize=False,progressive=False)
        _persistent_write_require(target_path);os.replace(temp,target_path)
        return target_path if _valid_cache_file(target_path) else None
    except Exception as exc:
        optional_failure("ui.dynamic_gradient",exc)
        try:
            if os.path.exists(temp) and _persistent_write_ok(temp):os.unlink(temp)
        except Exception as exc:optional_failure("ui.silent_guard",exc)
        return None


def _build_dynamic_poster_accent(source_path,target_path,size=(360,640)):
    if not _persistent_write_ok(THUMB_CACHE_DIR): return None
    if _PILImage is None or ImageDraw is None or not source_path or not os.path.isfile(source_path):return None
    if _valid_cache_file(target_path):return target_path
    temp=target_path+".tmp.%d.%d"%(os.getpid(),threading.get_ident())
    try:
        primary,_secondary=_dynamic_palette(source_path,poster=True);accent=_lift_dynamic_accent(primary,0.48,0.46);w,h=int(size[0]),int(size[1])
        r,g,b=accent
        # Clean anti-aliased rim + hairline (same lifted palette as the details chrome).
        out=_cg_glass((w,h),20,accent,fill_alpha=0,sheen_alpha=0,rim_alpha=225,rim_w=3.0,rim_inset=1.0,
                      hair_alpha=92,hair_inset=6.0,hair_color=(min(255,r+30),min(255,g+30),min(255,b+30)))
        _persistent_write_require(temp);out.save(temp,"PNG")
        _persistent_write_require(target_path);os.replace(temp,target_path)
        return target_path if _valid_cache_file(target_path) else None
    except Exception as exc:
        optional_failure("ui.dynamic_accent",exc)
        try:
            if os.path.exists(temp) and _persistent_write_ok(temp):os.unlink(temp)
        except Exception as exc:optional_failure("ui.silent_guard",exc)
        return None




CINEMATIC_CHROME_KEYS = ("panel_detail","overview_detail","cast_detail","quality","year","runtime","country","genre_detail")


@fixed_chrome
def _cached_dynamic_details_chrome(source_path, cache_key, only=CINEMATIC_CHROME_KEYS):
    """GUI-safe: return already-built Details surfaces (no palette, no Pillow)."""
    try:
        cache_root = DETAILS_ADAPTIVE_CACHE_DIR or THUMB_CACHE_DIR
        if not cache_key or not cache_root or _valid_cache_file is None:
            return {}
        out = {}
        for name in only:
            if name == "panel_detail":
                target = os.path.join(cache_root, "dyn270panel_cg1_%s_%s.png" % (str(cache_key), name))
            elif name == "overview_detail":
                target = os.path.join(cache_root, "dyn270overview_cg1_%s_%s.png" % (str(cache_key), name))
            elif name == "overview":
                target = os.path.join(cache_root, "dyn166overview_cg1_%s_%s.png" % (str(cache_key), name))
            else:
                target = os.path.join(cache_root, ("dyn146series_cinematic_cg1_%s_%s.png" if name in ("series_row", "series_row_selected") else "dyn125details_cg1_%s_%s.png") % (str(cache_key), name))
            if not _valid_cache_file(target):
                return {}
            out[name] = target
        return out
    except Exception:
        return {}


@fixed_chrome
def _build_dynamic_details_chrome(source_path, cache_key, only=None):
    cache_root = DETAILS_ADAPTIVE_CACHE_DIR or THUMB_CACHE_DIR
    if not _persistent_write_ok(cache_root): return {}
    """Generate subdued UI chrome whose edges follow the current artwork palette.

    Only borders, corner glints and very light glass tints follow the artwork.
    The body remains dark/neutral so text readability is stable across movies.
    """
    if _PILImage is None or ImageDraw is None or not source_path or not os.path.isfile(source_path):
        return {}
    try:
        primary,secondary=_dynamic_palette(source_path)
        accent=_lift_dynamic_accent(primary,0.48,0.46)
        accent2=_lift_dynamic_accent(secondary,0.42,0.38)
        base=(3,12,20)
        specs={
            "panel":((1388,410),30,True),
            "panel_detail":((1410,360),30,True),
            "overview":((1283,142),22,True),
            "overview_detail":((1318,170),22,True),
            "cast_card":((585,106),18,True),
            "director_card":((285,106),18,True),
            "writer_card":((418,106),18,True),
            "cast_card_ep":((555,106),18,True),
            "director_card_ep":((260,106),18,True),
            "writer_card_ep":((430,106),18,True),
            "poster_footer":((320,86),18,False),
            "poster_footer_detail":((360,86),18,False),
            "quality":((150,50),22,False),
            "year":((130,50),22,False),
            "runtime":((150,50),22,False),
            "country":((160,50),22,False),
            "genre":((815,40),19,False),
            "genre_detail":((680,50),22,False),
            "cast_detail":((1318,50),22,False),
            "rating_pill":((130,42),18,False),
            "episodes_panel":((430,782),20,True),
        }
        if only:
            # R5.14: Cinematic needs only its 8 visible surfaces; build those
            # first so the title adaptive appears ~3x sooner.
            specs={k:v for k,v in specs.items() if k in only}
        result={}
        try: os.makedirs(cache_root,mode=0o700,exist_ok=True)
        except Exception: return {}
        for name,(size,radius,is_panel) in specs.items():
            if name == "panel_detail":
                target=os.path.join(cache_root,"dyn270panel_cg1_%s_%s.png"%(str(cache_key),name))
            elif name == "overview_detail":
                target=os.path.join(cache_root,"dyn270overview_cg1_%s_%s.png"%(str(cache_key),name))
            elif name == "overview":
                target=os.path.join(cache_root,"dyn166overview_cg1_%s_%s.png"%(str(cache_key),name))
            else:
                target=os.path.join(cache_root,("dyn146series_cinematic_cg1_%s_%s.png" if name in ("series_row","series_row_selected") else "dyn125details_cg1_%s_%s.png")%(str(cache_key),name))
            if _valid_cache_file(target):
                result[name]=target;continue
            temp=target+".tmp.%d.%d"%(os.getpid(),threading.get_ident())
            w,h=size
            if name == "series_row_selected":
                glow_a,glow_w,glow_blur,glow_in=235,5.0,6,5.0
            elif name == "series_row":
                glow_a,glow_w,glow_blur,glow_in=96,3.0,5,6.0
            else:
                glow_a,glow_w,glow_blur,glow_in=(92 if is_panel else 78),3.0,(7 if is_panel else 5),6.0
            fill=_mix_rgb(base,accent,0.10 if is_panel else 0.14)
            if name in ("panel", "panel_detail"):
                fill_alpha=62; border_alpha=174; border_width=1
            elif name in ("overview", "overview_detail"):
                fill_alpha=82; border_alpha=188; border_width=1
            elif name in ("cast_card", "director_card", "writer_card", "cast_card_ep", "director_card_ep", "writer_card_ep"):
                fill_alpha=88; border_alpha=184; border_width=1
            elif name in ("quality", "year", "runtime", "country", "genre", "genre_detail", "cast_detail", "poster_footer", "poster_footer_detail"):
                fill_alpha=98; border_alpha=196; border_width=1
            else:
                fill_alpha=112; border_alpha=(190 if is_panel else 202); border_width=1
            if name == "series_row":
                fill=_mix_rgb((3,10,15),accent,0.040)
                fill_alpha=68; border_alpha=104; border_width=1
            elif name == "series_row_selected":
                fill=_mix_rgb((3,10,15),accent,0.055)
                fill_alpha=82; border_alpha=255; border_width=3
            is_overview = name in ("overview", "overview_detail")
            inner=_mix_rgb(accent,(255,255,255),0.40)
            if name in ("series_row","series_row_selected"):
                hair_a,hair_in,hair_c=(150 if name=="series_row_selected" else 26),5.0,(255,255,255)
            else:
                hair_a,hair_in,hair_c=22,7.0,inner
            sheen_a=(17 if name in ("panel","panel_detail") else (15 if is_panel else 13))
            out=_cg_glass(size,radius,accent,fill=fill,fill_alpha=fill_alpha,
                          fill_inset=2.0,fill_radius=None,
                          rim_alpha=border_alpha,rim_w=float(border_width),rim_inset=2.0,
                          hair_alpha=hair_a,hair_inset=hair_in,hair_color=hair_c,
                          sheen_alpha=int(sheen_a*1.7),
                          glow_alpha=glow_a,glow_w=glow_w,glow_inset=glow_in,glow_blur=glow_blur)
            _persistent_write_require(temp);out.save(temp,"PNG",compress_level=1)
            _persistent_write_require(target);os.replace(temp,target);result[name]=target
        result["accent_color"]="#%02x%02x%02x"%(int(accent[0]),int(accent[1]),int(accent[2]))
        if only and "rating_ring" not in only:
            return result
        ring_target=os.path.join(cache_root,"dyn220laser_cg1_%s_rating_ring.png"%str(cache_key))
        if not _valid_cache_file(ring_target):
            temp=ring_target+".tmp.%d.%d"%(os.getpid(),threading.get_ident())
            ring=_cg_disc((108,108),accent,fill=_mix_rgb(base,accent,0.07),fill_alpha=238,rim_alpha=205,rim_w=4.0,rim_inset=5.0,hair_alpha=65,hair_inset=12.0)
            _persistent_write_require(temp);ring.save(temp,"PNG");_persistent_write_require(ring_target);os.replace(temp,ring_target)
        result["rating_ring"]=ring_target
        return result
    except Exception as exc:
        optional_failure("ui.dynamic_details_chrome",exc)
        return {}


@fixed_chrome
def _build_aux_adaptive_chrome(source_path, cache_key):
    if not _persistent_write_ok(THUMB_CACHE_DIR): return {}
    """Build adaptive glass assets for Information overlays.

    The material intentionally mirrors the approved floating episode rows: dark
    glass body, restrained artwork tint, polished top sheen and a contained
    adaptive edge. Geometry is fixed; only the palette changes.
    """
    if _PILImage is None or ImageDraw is None:
        return {}
    try:
        if source_path and os.path.isfile(str(source_path)):
            primary, secondary = _dynamic_palette(str(source_path))
        else:
            primary, secondary = (58,116,140), (30,68,92)
        accent = _lift_dynamic_accent(primary,0.50,0.46)
        accent2 = _lift_dynamic_accent(secondary,0.42,0.36)
        specs = {
            "info_panel": ((1320,820),30,"panel"),
            "info_inner": ((1220,520),24,"inner"),
            "info_overview": ((1220,300),24,"inner"),
            "info_cast": ((560,150),22,"inner"),
            "info_director": ((280,150),22,"inner"),
            "info_writer": ((340,150),22,"inner"),
        }
        result={}
        for name,(size,radius,kind) in specs.items():
            target=os.path.join(THUMB_CACHE_DIR,"dyn174aux_cg1_%s_%s.png"%(str(cache_key),name))
            if _valid_cache_file(target):
                result[name]=target; continue
            temp=target+".tmp.%d.%d"%(os.getpid(),threading.get_ident())
            w,h=size
            ga=118 if kind=="selected" else (58 if kind in ("panel","inner") else 44)
            gw=4.0 if kind=="selected" else 2.0
            base=(4,10,16)
            mix=0.085 if kind=="panel" else (0.105 if kind=="inner" else (0.12 if kind=="row" else 0.20))
            fill=_mix_rgb(base,accent,mix)
            alpha=238 if kind in ("panel","inner") else 244
            border=236 if kind=="selected" else (150 if kind=="row" else 190)
            bw=2.0 if kind=="selected" else 1.0
            inner=_mix_rgb(accent2,(255,255,255),0.34)
            out=_cg_glass(size,radius,accent,fill=fill,fill_alpha=alpha,fill_inset=2.0,rim_alpha=border,rim_w=bw,rim_inset=2.0,
                          hair_alpha=(86 if kind=="selected" else 50),hair_inset=7.0,hair_color=inner,
                          sheen_alpha=int((24 if kind in ("row","selected") else 14)*1.7),
                          glow_alpha=ga,glow_w=gw,glow_inset=5.0,glow_blur=(7 if kind in ("panel","selected") else 4))
            _persistent_write_require(temp);out.save(temp,"PNG",optimize=False); _persistent_write_require(target);os.replace(temp,target)
            result[name]=target
        return result
    except Exception as exc:
        optional_failure("ui.aux_adaptive_chrome",exc); return {}


def _build_home_adaptive_focus(source_path, cache_key):
    if not _persistent_write_ok(THUMB_CACHE_DIR): return {}
    """Premium glass focus for Home cards, derived from the current hero palette.

    The focus never paints an Enigma2-style slab or an external rectangle.  It
    reinforces the same layered glass material used by the floating episode rows:
    a quiet adaptive inner wash, a polished inner highlight and a controlled edge.
    """
    if _PILImage is None or ImageDraw is None or not source_path or not os.path.isfile(source_path): return {}
    try:
        primary,secondary=_dynamic_palette(source_path)
        accent=_lift_dynamic_accent(primary,0.72,0.82)
        accent2=_lift_dynamic_accent(secondary,0.62,0.72)
        specs={"menu":((238,190),20),"recent":((565,330),24)};result={}
        for name,(size,radius) in specs.items():
            target=os.path.join(THUMB_CACHE_DIR,"dyn228home_cg1_%s_%sfocus.png"%(str(cache_key),name))
            if _valid_cache_file(target):result[name]=target;continue
            temp=target+".tmp.%d.%d"%(os.getpid(),threading.get_ident());w,h=size
            inner=_mix_rgb(accent2,(255,255,255),0.36)
            focus_fill=_mix_rgb((6,13,18),accent,0.19 if name=="menu" else 0.145)
            out=_cg_glass(size,radius,accent,fill=focus_fill,fill_alpha=78,fill_inset=3.0,rim_alpha=245,rim_w=3.0,rim_inset=2.0,
                          hair_alpha=92,hair_inset=7.0,hair_color=inner,sheen_alpha=36,
                          glow_alpha=190,glow_w=4.0,glow_inset=4.0,glow_blur=4)
            _persistent_write_require(temp);out.save(temp,"PNG",optimize=False);_persistent_write_require(target);os.replace(temp,target);result[name]=target
        return result
    except Exception as exc:optional_failure("ui.home_adaptive_focus",exc);return {}


@fixed_chrome
def _cached_dynamic_settings_episode_rows(source_path, cache_key, selected_rim_only=False, cinematic_premium=False):
    """Return already-built Settings/Series row assets without opening artwork.

    This helper is intentionally GUI-safe: it only computes deterministic cache
    paths and validates the two tiny PNGs.  Palette extraction/Pillow work remains
    in the background builder below.
    """
    if not source_path or not os.path.isfile(source_path) or not THUMB_CACHE_DIR or _valid_cache_file is None:
        return {}
    result = {}
    try:
        for selected in (False, True):
            name = "selected" if selected else "normal"
            target = durable_view_path(
                "dyn_settings_episode_cg1_%s_%s%s%s.png" % (
                    str(cache_key), name,
                    "_rim" if (selected and selected_rim_only) else "",
                    "_premium" if cinematic_premium else "",
                ),
                source=source_path,
            )
            if _valid_cache_file(target):
                result[name] = target
        return result if result.get("normal") and result.get("selected") else {}
    except Exception:
        return {}

@fixed_chrome
def _build_dynamic_settings_episode_rows(source_path, cache_key, selected_rim_only=False, cinematic_premium=False):
    """Build only the two 426x72 adaptive glass rows used by Settings.

    Geometry/material deliberately mirrors the approved Series episode floating
    rows, but avoids generating the full Details chrome bundle when Settings is
    opened from Home.  This keeps first-open work tiny on receiver hardware.
    """
    if not _persistent_write_ok(THUMB_CACHE_DIR):
        return {}
    if _PILImage is None or ImageDraw is None or not source_path or not os.path.isfile(source_path):
        return {}
    try:
        primary, secondary = _dynamic_palette(source_path)
        accent = _lift_dynamic_accent(primary, 0.48, 0.46)
        accent2 = _lift_dynamic_accent(secondary, 0.42, 0.38)
        result = {}
        for selected in (False, True):
            name = "selected" if selected else "normal"
            target = durable_view_path("dyn_settings_episode_cg1_%s_%s%s%s.png" % (str(cache_key), name, "_rim" if (selected and selected_rim_only) else "", "_premium" if cinematic_premium else ""), source=source_path)
            if _valid_cache_file(target):
                result[name] = target
                continue
            temp = target + ".tmp.%d.%d" % (os.getpid(), threading.get_ident())
            w, h, radius = 426, 72, 22
            glow_alpha = (250 if selected else 54) if cinematic_premium else 78
            glow_width = 5.0 if (cinematic_premium and selected) else (2.0 if cinematic_premium else 3.0)
            if selected:
                if selected_rim_only:
                    fill = _mix_rgb((3, 10, 15), accent, 0.055 if cinematic_premium else 0.10)
                    fill_alpha = 82 if cinematic_premium else 108
                    border_alpha = 255 if cinematic_premium else 238
                    border_width = 3.0 if cinematic_premium else 2.0
                else:
                    fill = _mix_rgb((4, 13, 18), accent, 0.18)
                    fill_alpha, border_alpha, border_width = 126, 232, 2.0
            else:
                fill = _mix_rgb((3, 10, 15), accent, 0.040 if cinematic_premium else 0.10)
                fill_alpha = 68 if cinematic_premium else 108
                border_alpha = 104 if cinematic_premium else 130
                border_width = 1.0
            inner = _mix_rgb(accent2, (255, 255, 255), 0.46 if cinematic_premium else 0.40)
            if cinematic_premium:
                hair_a, hair_c, hair_in = (150 if selected else 26), (255,255,255), 5.0
                sheen_a = 42 if selected else 10
            else:
                hair_a, hair_c, hair_in = 0, inner, 7.0
                sheen_a = 13
            out = _cg_glass((w, h), radius, accent, fill=fill, fill_alpha=fill_alpha, fill_inset=2.0,
                            rim_alpha=border_alpha, rim_w=border_width, rim_inset=2.0,
                            hair_alpha=hair_a, hair_inset=hair_in, hair_color=hair_c,
                            sheen_alpha=int(sheen_a*1.7),
                            glow_alpha=glow_alpha, glow_w=glow_width, glow_inset=6.0, glow_blur=(6 if cinematic_premium else 5))
            _persistent_write_require(temp)
            out.save(temp, "PNG", compress_level=1)
            _persistent_write_require(target)
            os.replace(temp, target)
            if _valid_cache_file(target):
                result[name] = target
        result["value_color"] = accent
        return result
    except Exception as exc:
        optional_failure("ui.settings_episode_rows", exc)
        return {}

@image_budgeted
def _build_category_extended_backdrop(source_path, cache_key):
    """Build a receiver-safe Categories hero that reaches lower than Home.

    Home intentionally fades its prepared hero out around the menu zone.  That is
    perfect for Home, but leaves Categories with a large black right half.  Build
    a dedicated 1920x1080 derivative from the *raw cached Home backdrop* and keep
    it fully visible longer before a soft fade into the page background.

    Disk-only and cache-keyed: no provider/network work is ever triggered here.
    """
    try:
        os.makedirs(CATEGORY_ADAPTIVE_TMP_DIR, mode=0o700, exist_ok=True)
    except Exception as exc:
        optional_failure("ui.category_backdrop_dir", exc)
        return None
    if _PILImage is None or not source_path or not os.path.isfile(source_path):
        return None
    target = os.path.join(CATEGORY_ADAPTIVE_TMP_DIR, "cat_hero_long_%s.png" % str(cache_key))
    if _valid_cache_file(target):
        return target
    temp = target + ".tmp.%d.%d" % (os.getpid(), threading.get_ident())
    try:
        tw, th = 1920, 1080
        res = getattr(getattr(_PILImage, "Resampling", _PILImage), "LANCZOS", 1)
        with _PILImage.open(source_path) as image:
            image = image.convert("RGB")
            if image.width < 16 or image.height < 16:
                return None
            # True cover crop.  This turns any raw TMDB/local backdrop into the
            # same receiver-sized canvas before Enigma2 ever sees it.
            scale = max(float(tw) / max(1, image.width), float(th) / max(1, image.height))
            nw = max(tw, int(round(image.width * scale)))
            nh = max(th, int(round(image.height * scale)))
            image = image.resize((nw, nh), res)
            left = max(0, (nw - tw) // 2)
            top = max(0, (nh - th) // 2)
            image = image.crop((left, top, left + tw, top + th))

            # Keep the movie art crisp but slightly restrained behind glass rows.
            grade = _PILImage.new("RGBA", (tw, th), (2, 7, 12, 30))
            rgba = _PILImage.alpha_composite(image.convert("RGBA"), grade)

            # Test15: Home fades at ~610px.  Categories hold the picture much
            # lower, then dissolve gently so the bottom remains clean rather than
            # becoming a hard full-screen wallpaper.
            fade_start = 500.0
            fade_end = 880.0
            alpha_vals = []
            for y in range(th):
                if y <= fade_start:
                    a = 255
                elif y >= fade_end:
                    a = 0
                else:
                    t = (y - fade_start) / (fade_end - fade_start)
                    smooth = t * t * (3.0 - 2.0 * t)
                    a = int(255 * (1.0 - smooth))
                alpha_vals.append(max(0, min(255, a)))
            alpha = _PILImage.new("L", (1, th))
            alpha.putdata(alpha_vals)
            alpha = alpha.resize((tw, th))
            if _PILImageFilter is not None:
                try:
                    alpha = alpha.filter(_PILImageFilter.GaussianBlur(radius=10))
                except Exception as exc:
                    optional_failure("ui.category_backdrop_alpha", exc)
            rgba.putalpha(alpha)
            _persistent_write_require(temp)
            rgba.save(temp, "PNG", optimize=False)
        _persistent_write_require(target)
        os.replace(temp, target)
        return target if _valid_cache_file(target) else None
    except Exception as exc:
        optional_failure("ui.category_extended_backdrop", exc)
        try:
            if os.path.exists(temp) and _persistent_write_ok(temp):
                os.unlink(temp)
        except Exception as cleanup_exc:
            optional_failure("ui.category_extended_backdrop_cleanup", cleanup_exc)
        return None

@fixed_chrome
def _build_category_adaptive_chrome(source_path, cache_key, media_type="", row_width=674, accent_override=None, accent2_override=None):
    """Build Settings-style adaptive glass rows for Categories.

    Categories use the exact Home hero as the visible backdrop.  This helper only
    builds the two floating row materials.  ``row_width`` is calculated once from
    the longest category title in the *entire* category list, so paging never makes
    the rail breathe wider/narrower between groups of 14.
    """
    try:
        os.makedirs(CATEGORY_ADAPTIVE_TMP_DIR, mode=0o700, exist_ok=True)
    except Exception as exc:
        optional_failure("ui.category_adaptive_tmp", exc)
        return {}
    if _PILImage is None or ImageDraw is None or not source_path or not os.path.isfile(source_path):
        return {}
    try:
        row_width=max(426,min(860,int(row_width or 674)))
        primary, secondary = _dynamic_palette(source_path)
        # Match the approved Settings episode-row material, compressed only in
        # height so fourteen rows fit cleanly. Keep the Settings 22px corner
        # language instead of the shallower Test12 category radius.
        # Player overlays may supply the Player's already-authoritative adaptive
        # accent. Geometry/material remain byte-for-byte this builder; only the
        # colour authority changes, so Player menus never borrow Home/Settings.
        accent = _lift_dynamic_accent(primary, 0.48, 0.46)
        accent2 = _lift_dynamic_accent(secondary, 0.42, 0.38)
        def _rgb_override(value, fallback):
            try:
                if isinstance(value,(tuple,list)) and len(value)>=3:
                    return tuple(max(0,min(255,int(value[i]))) for i in range(3))
                text=str(value or "").strip().lstrip("#")
                if len(text)==8: text=text[-6:]
                if len(text)==6:
                    return (int(text[0:2],16),int(text[2:4],16),int(text[4:6],16))
            except Exception:
                pass
            return fallback
        if accent_override is not None:
            accent=_rgb_override(accent_override,accent)
        if accent2_override is not None:
            accent2=_rgb_override(accent2_override,accent2)
        out_paths = {}
        for selected in (False, True):
            name = "row_selected" if selected else "row"
            target = os.path.join(
                CATEGORY_ADAPTIVE_TMP_DIR,
                "cat_settings_contrast_v3_cg1_%s_%s_%d.png" % (str(cache_key), name, row_width)
            )
            if _valid_cache_file(target):
                out_paths[name] = target
                continue
            tmp = target + ".tmp.%d.%d" % (os.getpid(), threading.get_ident())
            w,h,r = row_width,62,22
            glow_alpha = 160 if selected else 92
            glow_width = 4.0 if selected else 3.0
            if selected:
                fill = _mix_rgb((3,11,17), accent, 0.24)
                fill_alpha,border_alpha,border_width = 160,255,2.0
            else:
                fill = _mix_rgb((3,10,16), accent, 0.08)
                fill_alpha,border_alpha,border_width = 140,154,1.0
            inner = _mix_rgb(accent2,(255,255,255),0.40)
            img = _cg_glass((w,h), r, accent, fill=fill, fill_alpha=fill_alpha, fill_inset=2.0,
                            rim_alpha=border_alpha, rim_w=border_width, rim_inset=2.0,
                            hair_alpha=0, sheen_alpha=int((27 if selected else 14)*1.7),
                            glow_alpha=glow_alpha, glow_w=glow_width, glow_inset=5.0, glow_blur=(6 if selected else 5))
            img.save(tmp,"PNG",optimize=False); os.replace(tmp,target)
            out_paths[name]=target
        out_paths["value_color"] = accent
        return out_paths
    except Exception as exc:
        optional_failure("ui.category_adaptive_chrome", exc)
        return {}


def _build_poster_adaptive_chrome_clean(source_path, cache_key=None):
    """Movies/Series HUD: Live-style adaptive glass without any inner lines."""
    if not _persistent_write_ok(THUMB_CACHE_DIR): return {}
    if _PILImage is None or ImageDraw is None or not source_path or not os.path.isfile(source_path):
        return {}
    try:
        try:stamp=str(int(os.path.getmtime(source_path)))
        except Exception:stamp="0"
        key=cache_key or hashlib.sha1((source_path+"|"+stamp+"|posterhud_clean_v1").encode("utf-8","ignore")).hexdigest()[:18]
        primary,secondary=_dynamic_palette(source_path)
        accent=_lift_dynamic_accent(primary,0.62,0.76)
        accent2=_lift_dynamic_accent(secondary,0.44,0.58)
        specs={
            "counter":(575,54,18,152),
            "channel_top":(500,52,17,164),
            "clock":(260,82,20,156),
        }
        result={}
        for name,(w,h,r,alpha) in specs.items():
            target=durable_view_path("posterhud_clean_cg1_%s_%s.png"%(key,name),source=source_path)
            if _valid_cache_file(target,ttl=0):
                result[name]=target;continue
            tmp=target+".tmp.%d.%d"%(os.getpid(),threading.get_ident())
            fill=_mix_rgb((4,12,18),accent,0.14 if name!="channel_top" else 0.18)
            outer=_mix_rgb(accent,(255,255,255),0.18)
            img=_cg_glass((w,h),r,accent,fill=fill,fill_alpha=alpha,fill_inset=2.0,rim_alpha=228,rim_w=2.0,rim_inset=2.0,
                          rim_mix=outer,hair_alpha=0,sheen_alpha=0,depth_alpha=96,depth_blur=5,depth_dy=2.0,depth_inset=5.0)
            _persistent_write_require(tmp);img.save(tmp,"PNG",optimize=False)
            _persistent_write_require(target);os.replace(tmp,target)
            result[name]=target
        return result
    except Exception as exc:
        optional_failure("ui.poster_clean_adaptive_chrome",exc)
        return {}


def _build_live_adaptive_chrome_211(source_path, cache_key=None):
    if not _persistent_write_ok(THUMB_CACHE_DIR): return {}
    """Live-only adaptive glass. Fast and cached; never touches Home/TMDB artwork."""
    if _PILImage is None or ImageDraw is None or not source_path or not os.path.isfile(source_path):
        return {}
    try:
        try: stamp=str(int(os.path.getmtime(source_path)))
        except Exception: stamp="0"
        key=cache_key or hashlib.sha1((source_path+"|"+stamp+"|livehud3d_v3").encode("utf-8","ignore")).hexdigest()[:18]
        primary,secondary=_dynamic_palette(source_path)
        accent=_lift_dynamic_accent(primary,0.62,0.76)
        accent2=_lift_dynamic_accent(secondary,0.44,0.58)
        base=(3,10,17); result={}

        # Cheap page mood: draw tiny, upscale. No 2M-pixel Python loop on every channel.
        target=os.path.join(THUMB_CACHE_DIR,"live211_%s_page.png"%key)
        if not _valid_cache_file(target):
            tmp=target+".tmp.%d.%d"%(os.getpid(),threading.get_ident())
            tiny=_PILImage.new("RGB",(96,54),base); d=ImageDraw.Draw(tiny)
            wash=_mix_rgb(base,accent,0.24)
            d.ellipse((38,-8,112,66),fill=wash)
            d.rectangle((0,0,96,54),fill=base+(0,) if False else base)
            # overlay a subtle right-side accent gradient with compositing
            ov=_PILImage.new("RGBA",(96,54),(0,0,0,0)); od=ImageDraw.Draw(ov)
            for x in range(34,96):
                t=(x-34)/62.0; a=int(46*t)
                od.rectangle((x,0,x,54),fill=accent+(a,))
            tiny=_PILImage.alpha_composite(tiny.convert("RGBA"),ov).convert("RGB")
            img=tiny.resize((1920,1080),_PILImage.Resampling.BILINEAR if hasattr(_PILImage,'Resampling') else _PILImage.BILINEAR)
            if _PILImageFilter is not None: img=img.filter(_PILImageFilter.GaussianBlur(radius=18))
            _persistent_write_require(tmp);img.save(tmp,"PNG",optimize=False); _persistent_write_require(target);os.replace(tmp,target)
        result["page"]=target

        specs={
            "selected":(748,58,20,True,112),
            "preview":(940,548,28,False,0),
            "info":(940,244,26,False,112),
            "tech":(205,46,18,False,96),
            "row":(748,58,18,False,54),
            # The compact Live HUD now keeps only the page/channel counter.
            "counter":(575,54,18,False,152),
        }
        for name,(w,h,r,selected,alpha) in specs.items():
            target=os.path.join(THUMB_CACHE_DIR,"live211_cg1_%s_%s.png"%(key,name))
            if _valid_cache_file(target): result[name]=target; continue
            tmp=target+".tmp.%d.%d"%(os.getpid(),threading.get_ident())
            if name=="preview":
                outer=_mix_rgb(accent,(255,255,255),0.18)
                img=_cg_glass((w,h),r,accent,fill_alpha=0,sheen_alpha=0,rim_alpha=105,rim_w=2.0,rim_inset=2.0,rim_mix=outer,
                              hair_alpha=38,hair_inset=8.0,hair_color=accent2)
            elif name=="counter":
                fill=_mix_rgb((4,12,18),accent,0.14)
                inner=_mix_rgb(accent2,(255,255,255),0.34)
                img=_cg_glass((w,h),r,accent,fill=fill,fill_alpha=alpha,fill_inset=2.0,rim_alpha=228,rim_w=2.0,rim_inset=2.0,
                              hair_alpha=82,hair_inset=7.0,hair_color=inner,sheen_alpha=int(22*1.7),
                              depth_alpha=96,depth_blur=5,depth_dy=2.0,depth_inset=5.0)
            else:
                fill=_mix_rgb(base,accent,0.13 if selected else 0.055)
                inner=_mix_rgb(accent2,(255,255,255),0.30)
                img=_cg_glass((w,h),r,accent,fill=fill,fill_alpha=alpha,fill_inset=2.0,
                              rim_alpha=(220 if selected else 70),rim_w=(2.0 if selected else 1.0),rim_inset=2.0,
                              hair_alpha=(76 if selected else 28),hair_inset=7.0,hair_color=inner,
                              sheen_alpha=(int(18*1.7) if selected else 0))
            _persistent_write_require(tmp);img.save(tmp,"PNG",optimize=False); _persistent_write_require(target);os.replace(tmp,target); result[name]=target
        result["accent"]=accent
        return result
    except Exception as exc:
        optional_failure("ui.live211_adaptive",exc); return {}


def _build_home_mood_assets(source_path, cache_key):
    if not _persistent_write_ok(THUMB_CACHE_DIR): return {}
    """Build episode-card quality glass for the ten Home cards.

    The hero artwork stays dominant.  Menu and Continue/Recent cards remain nearly
    black, but use layered translucent glass, an extremely restrained adaptive tint,
    a soft internal sheen and polished edges.  The palette is felt rather than seen.
    """
    if _PILImage is None or ImageDraw is None or not source_path or not os.path.isfile(source_path):return {}
    try:
        primary,secondary=_dynamic_palette(source_path)
        p=_lift_dynamic_accent(primary,0.54,0.64); q=_lift_dynamic_accent(secondary,0.48,0.56)
        out={}; tw,th=1920,1080
        # Keep a dark transparent-ready ambient base for receiver compositing.  The
        # backdrop remains the visual hero; this layer only prevents harsh black gaps.
        target=os.path.join(THUMB_CACHE_DIR,"dyn228home_%s_ambient.png"%cache_key)
        if not _valid_cache_file(target):
            temp=target+".tmp.%d.%d"%(os.getpid(),threading.get_ident())
            base=_PILImage.new("RGBA",(tw,th),(3,8,13,255))
            wash=_PILImage.new("RGBA",(tw,th),(0,0,0,0));d=ImageDraw.Draw(wash)
            d.ellipse((-520,-340,1300,900),fill=p+(13,));d.ellipse((980,-240,2350,780),fill=q+(9,));d.ellipse((260,650,1720,1420),fill=p+(5,))
            if _PILImageFilter is not None:wash=wash.filter(_PILImageFilter.GaussianBlur(radius=180))
            im=_PILImage.alpha_composite(base,wash);_persistent_write_require(temp);im.save(temp,"PNG",optimize=False);_persistent_write_require(target);os.replace(temp,target)
        out["ambient"]=target

        for name,size,tint in (("menu",(238,190),0.070),("recent",(565,330),0.050)):
            target=os.path.join(THUMB_CACHE_DIR,"dyn280home_cg1_%s_%sglass.png"%(cache_key,name))
            if not _valid_cache_file(target):
                temp=target+".tmp.%d.%d"%(os.getpid(),threading.get_ident());w,h=size
                radius=20 if name=="menu" else 24
                basec=_mix_rgb((3,8,12),p,tint)
                innerc=_mix_rgb((8,15,20),q,0.060 if name=="menu" else 0.042)
                outim=_cg_glass(size,radius,p,fill=basec,fill_alpha=242,fill_inset=2.0,rim_alpha=142,rim_w=2.0,rim_inset=2.0,
                                hair_alpha=68,hair_inset=7.0,hair_color=_mix_rgb(p,(255,255,255),0.30),
                                inner_fill=(innerc,82,7),sheen_alpha=int((30 if name=="menu" else 22)*1.7),
                                shade_alpha=34,depth_alpha=110,depth_blur=6,depth_dy=2.0,depth_inset=5.0)
                _persistent_write_require(temp);outim.save(temp,"PNG",optimize=False);_persistent_write_require(target);os.replace(temp,target)
            out[name]=target
        return out
    except Exception as exc:optional_failure("ui.home_mood_assets",exc);return {}
