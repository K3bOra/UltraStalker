# -*- coding: utf-8 -*-
"""Utility glass mode, catch-up rail, catch-up channels/programs and playback.

Methods moved verbatim out of ``PortalBrowserScreen`` (ui_screens_browser.py); behaviour is unchanged.
This module is imported by ui_screens_browser.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, round, max, min
from .ui_screens_browser import (
    LOG,
    _,
    _lstrf,
    os,
    time,
)


class BrowserCatchupMixin(object):
    """Utility glass mode, catch-up rail, catch-up channels/programs and playback."""

    def _utility_mode_active(self):
        return self.level in ("catchup_channels","catchup_channels_loading","catchup_programs","catchup_programs_loading","favorites")

    def _apply_utility_glass_mode(self):
        """Static compact glass identity for Catch-up and Favorites."""
        try:
            self._browser_geom("list",62,650,1796,300)
            self["list"].row_width=1796
            self["list"].set_layout(58,40,23,16,"utility_glass")

            # Same authored right column as Settings.
            for name,x,y,w,h in (
                ("preview",1260,132,360,260),
                ("accent_frame",0,0,1,1),
                ("info_card1",1110,438,660,78),
                ("info_card2",1110,532,660,78),
                ("info_card3",1110,626,660,78),
                ("info_icon1",1134,453,48,48),
                ("info_icon2",1134,547,48,48),
                ("info_icon3",1134,641,48,48),
                ("info_title",1200,438,540,78),
                ("info",1200,532,540,78),
                ("status",1200,626,540,78),
            ):
                try:self._browser_geom(name,x,y,w,h)
                except Exception as exc:optional_failure("ui.silent_guard",exc)
            for divider_name in ("divider","separator","midline","vline","vertical_line"):
                try:self[divider_name].hide()
                except Exception as exc:optional_failure("ui.silent_guard",exc)
            if self["list"].instance is not None:
                try:self["list"].instance.setSelectionEnable(0)
                except Exception as exc:optional_failure("ui.silent_guard",exc)
                try:self["list"].instance.setTransparent(1)
                except Exception as exc:optional_failure("ui.silent_guard",exc)
                try:self["list"].instance.setScrollbarMode(2)
                except Exception as exc:optional_failure("ui.silent_guard",exc)
                try:self["list"].instance.setScrollbarMode(2)
                except Exception as exc:optional_failure("ui.silent_guard",exc)
        except Exception as exc:optional_failure("ui.utility_browser_geom",exc)
        try:
            # Catch-up/Favorites use the same bundled static background as
            # Live/Movies/Series Categories. No Home Hero lookup, long-backdrop
            # derivative build or palette work is needed just to paint the page.
            _static_bg = asset("ultra_bg_clean_1920x1080.png")
            self._browser_geom("page_adaptive_bg",0,0,1920,1080)
            if self["page_adaptive_bg"].instance is not None and os.path.isfile(_static_bg):
                if str(getattr(self,"_utility_static_bg_loaded","") or "") != _static_bg:
                    self["page_adaptive_bg"].instance.setPixmap(None)
                    self["page_adaptive_bg"].instance.setPixmapFromFile(_static_bg)
                    self._utility_static_bg_loaded = _static_bg
                self["page_adaptive_bg"].show()
                self._category_static_bg_loaded = _static_bg
            for n in ("preview","accent_frame","info_card1","info_card2","info_card3","info_icon1","info_icon2","info_icon3","info_title","info"):
                try:self[n].hide()
                except Exception:pass
        except Exception as exc:optional_failure("ui.utility_static_bg",exc)
        try:
            if self["accent_frame"].instance is not None:
                self["accent_frame"].instance.setPixmap(None)
            self["accent_frame"].hide()
            self._browser_geom("accent_frame",2000,0,1,1)
        except Exception as exc:optional_failure("ui.silent_guard",exc)
        try:
            from .wqhd_layout import wh as _wqhd_wh
            self._image_size=(360,260)
            pw, ph = _wqhd_wh(360, 260)
            self._picload.setPara((pw, ph, 1, 1, False, 1, "#000000"))
        except Exception as exc:optional_failure("ui.silent_guard",exc)
        chrome=_neutral_utility_glass()
        self._category_chrome=dict(chrome)
        card=chrome.get("side") or chrome.get("info")
        if card and os.path.isfile(card):
            for n in ("info_card1","info_card2","info_card3"):
                try:self[n].instance.setPixmapFromFile(card);self[n].show()
                except Exception as exc:optional_failure("ui.silent_guard",exc)

    # ------------------------------------------------------------------
    # Catch-up pages: same floating-rail grammar as the Categories pages.
    # Old behaviour mixed the Live channel row style (fake "NOW / No EPG"
    # line), no visible focus and three empty glass cards on the right.
    # ------------------------------------------------------------------
    def _apply_catchup_rail_mode(self, programmes=False):
        card_w = 900 if programmes else 760
        self._catchup_card_w = card_w
        try:
            list_w = card_w + 8
            self._browser_geom("list", 14, 12, list_w, 1056)
            self["list"].row_width = list_w
            self["list"].set_layout(60, 36, 24, 15, "category_floating")
            inst = self["list"].instance
            if inst is not None:
                for fn_name, arg in (("setSelectionEnable", 0), ("setTransparent", 1), ("setScrollbarMode", 2)):
                    try: getattr(inst, fn_name)(arg)
                    except Exception as exc: optional_failure("ui.silent_guard", exc)
        except Exception as exc:
            optional_failure("ui.catchup_rail_geom", exc)
        try:
            bg = asset("ultra_bg_clean_1920x1080.png")
            self._browser_geom("page_adaptive_bg", 0, 0, 1920, 1080)
            if self["page_adaptive_bg"].instance is not None and os.path.isfile(bg):
                if str(getattr(self, "_utility_static_bg_loaded", "") or "") != bg:
                    self["page_adaptive_bg"].instance.setPixmap(None)
                    self["page_adaptive_bg"].instance.setPixmapFromFile(bg)
                    self._utility_static_bg_loaded = bg
                self["page_adaptive_bg"].show()
                self._category_static_bg_loaded = bg
        except Exception as exc:
            optional_failure("ui.catchup_static_bg", exc)
        # Nothing but the rail and one small info block over the dark artwork.
        for name in ("preview", "accent_frame", "info_card1", "info_card2", "info_card3",
                     "info_icon1", "info_icon2", "info_icon3", "top_divider", "brand_header",
                     "title", "section", "counter", "divider", "separator", "midline", "vline", "vertical_line"):
            try: self[name].hide()
            except Exception: pass
        try:
            if self["accent_frame"].instance is not None:
                self["accent_frame"].instance.setPixmap(None)
            self._browser_geom("accent_frame", 2000, 0, 1, 1)
        except Exception as exc:
            optional_failure("ui.silent_guard", exc)
        for name, x, y, w, h in (("info_title", 1110, 858, 660, 56), ("info", 1110, 916, 660, 40),
                                 ("status", 1110, 962, 660, 64)):
            try: self._browser_geom(name, x, y, w, h)
            except Exception as exc: optional_failure("ui.silent_guard", exc)

    def _catchup_row_title(self, entry, programmes=False):
        entry = entry if isinstance(entry, dict) else {}
        if not programmes:
            return _clean_display_text(entry.get("name") or entry.get("title") or _("Channel"), 120) or _("Channel")
        name = _clean_display_text(entry.get("name") or entry.get("title") or entry.get("descr") or _("Programme"), 120)
        try: ts = int(entry.get("start_timestamp") or 0)
        except Exception: ts = 0
        label = ""
        if ts > 1000000000:
            when = time.localtime(ts); now = time.localtime()
            same_day = (when.tm_year, when.tm_yday) == (now.tm_year, now.tm_yday)
            label = time.strftime("%H:%M" if same_day else "%d/%m  %H:%M", when)
        else:
            label = _clean_display_text(entry.get("time") or entry.get("start") or "", 24)
        return ("%s    %s" % (label, name)).strip() if label else name

    def _catchup_details(self, selected):
        return {"selected": bool(selected), "card_w": int(getattr(self, "_catchup_card_w", 760) or 760),
                "title_font": 0, "selected_title_font": 10}

    def _catchup_rows(self, entries, selected=0, programmes=False):
        icon = asset("us89_folder_yellow_42.png")
        return [(self._catchup_row_title(e, programmes), icon, e, self._catchup_details(i == selected))
                for i, e in enumerate(entries)]

    def _catchup_show_channels(self, valid, selected=0):
        """Paint the catch-up channel rail (also used when returning from programmes)."""
        self._apply_catchup_rail_mode(False)
        selected = max(0, min(int(selected or 0), max(0, len(valid) - 1)))
        self._catchup_last_idx = selected
        if valid:
            rows = self._catchup_rows(valid, selected, False)
        else:
            rows = [(_("No catch-up channels"), asset("us89_folder_yellow_42.png"), None, self._catchup_details(True))]
        self["list"].set_icon_rows(rows)
        try: self["list"].moveToIndex(selected)
        except Exception as exc: optional_failure("ui.silent_guard", exc)
        if not valid:
            self["info_title"].setText(_("Catch-up TV"))
            self["info"].setText(_("This account has no channels with archive"))
            self["status"].setText(_("Ask your provider whether catch-up is enabled"))
        self._reveal_browser_content()

    def _catchup_selection_changed(self, idx):
        entries = list(self.content_items or [])
        if not entries:
            return
        programmes = (self.level == "catchup_programs")
        idx = max(0, min(int(idx), len(entries) - 1))
        icon = asset("us89_folder_yellow_42.png")
        old = int(getattr(self, "_catchup_last_idx", idx) or 0)
        for j in set((old, idx)):
            if 0 <= j < len(entries):
                self["list"].update_icon_row(j, (self._catchup_row_title(entries[j], programmes), icon, entries[j], self._catchup_details(j == idx)))
        self._catchup_last_idx = idx
        e = entries[idx] if isinstance(entries[idx], dict) else {}
        if programmes:
            self["info_title"].setText(_clean_display_text(e.get("name") or e.get("title") or _("Programme"), 60))
            parts = []
            try:
                ts = int(e.get("start_timestamp") or 0)
                if ts > 1000000000:
                    parts.append(_lstrf("%a %d/%m  %H:%M", time.localtime(ts)))
            except Exception: pass
            try:
                mins = int(round(float(e.get("duration") or 0) / 60.0))
                if mins > 0: parts.append(_("%d min") % mins)
            except Exception: pass
            self["info"].setText("  •  ".join(parts) or _("Archived programme"))
            self["status"].setText(_("OK plays this programme  •  BACK returns to channels"))
        else:
            self["info_title"].setText(_clean_display_text(e.get("name") or e.get("title") or _("Channel"), 60))
            try: days = int(float(e.get("tv_archive_duration") or 0))
            except Exception: days = 0
            self["info"].setText((_("Archive: %d days") % days) if days > 0 else _("Archive available"))
            self["status"].setText(_("OK opens archived programmes  •  BACK returns"))
        try: self["preview"].hide()
        except Exception: pass

    def load_catchup_channels(self):
        if self._busy:return
        _perf29_catch_t0=time.monotonic();LOG.info("PERF29 catchup begin")
        self.level="catchup_channels_loading";self._apply_catchup_rail_mode(False)
        self["status"].setText(_("Loading catch-up channels...  •  BACK cancels")); self._show_skeleton(_("Loading catch-up"))
        try:self["status"].show()
        except Exception:pass
        def ok(rows):
            valid=[x for x in rows if isinstance(x,dict)]; self.level="catchup_channels"; self.media_type="itv"; self.content_items=valid; self.all_content_items=list(valid); self._catchup_channels_cache=list(valid)
            self._catchup_show_channels(valid)
            self["status"].setText(_("Ready") if valid else _("No catch-up channels"))
            if valid:self._selection_changed()
            LOG.info("PERF29 catchup first_paint channels=%d elapsed_ms=%d",len(valid),int((time.monotonic()-_perf29_catch_t0)*1000))
        def fail(e):
            self.level="catchup_channels";self.content_items=[]
            self._catchup_show_channels([])
            self["status"].setText(_("Catch-up failed: %s")%e)
        self._run_async(lambda handle:self.client.catchup_channels("*",1,max_pages=20,cancel_event=handle.cancel_event),ok,fail)

    def load_catchup_programs(self, channel):
        if self._busy:return
        self.level="catchup_programs_loading";self._apply_catchup_rail_mode(True)
        self.catchup_channel=channel
        cids=[]
        for key in ("id","ch_id","channel_id","stream_id"):
            value=channel.get(key)
            if value not in (None,"") and str(value) not in list(str(x) for x in cids):cids.append(value)
        if not cids: self["status"].setText(_("Channel has no archive identifier")); return
        self["status"].setText(_("Loading archive programmes...  •  BACK cancels"))
        try:self["status"].show()
        except Exception:pass
        def ok(rows):
            valid=[x for x in rows if isinstance(x,dict)]; self.level="catchup_programs"; self.content_items=valid
            self._catchup_last_idx=0
            if valid:
                rows=self._catchup_rows(valid,0,True)
            else:
                rows=[(_("No archived programmes"),asset("us89_folder_yellow_42.png"),None,self._catchup_details(True))]
            self["list"].set_icon_rows(rows)
            try:self["list"].moveToIndex(0)
            except Exception as exc:optional_failure("ui.silent_guard",exc)
            self._reveal_browser_content()
            self["status"].setText(_("Ready") if valid else _("No archive data"))
            if valid:self._selection_changed()
            else:
                self["info_title"].setText(_clean_display_text(channel.get("name") or _("Channel"),60))
                self["info"].setText(_("No archived programmes for this channel"))
                self["status"].setText(_("Try another channel  •  BACK returns"))
        hours=load_settings().get("catchup_hours",72)
        def fail(e):
            cache=list(getattr(self,"_catchup_channels_cache",None) or [])
            self.level="catchup_channels";self.content_items=cache;self.all_content_items=list(cache)
            self._catchup_show_channels(cache,getattr(self,"_catchup_channel_index",0))
            # Keep technical socket/EPG exceptions in the log only.  The old
            # raw "Archive EPG failed: [Errno ...]" line polluted the details
            # pane every time a provider reset the archive request.
            LOG.info("Catch-up archive EPG unavailable: %s",e)
            self["status"].setText("")
        def work(handle):
            last=[]
            for cid in cids:
                if handle.cancel_event.is_set():break
                try:
                    rows=self.client.catchup_programs(cid,hours,cancel_event=handle.cancel_event) or []
                except Exception as exc:
                    LOG.info("Catch-up identifier %s failed: %s",cid,exc);rows=[]
                if rows:return rows
                last=rows
            return last
        self._run_async(work,ok,fail)

    def play_catchup_program(self, program):
        if not self.catchup_channel: return
        self["status"].setText(_("Creating catch-up stream..."))
        def ok(url):
            name=str(program.get("name") or program.get("title") or _("Catch-up programme"))
            if not isinstance(url, str) or not url.strip():
                self["status"].setText(_("Portal returned an invalid catch-up link")); return
            self["status"].setText(_("Opening Ultra Stalker player..."))
            def closed(result=None):
                engine = result.get("engine") if isinstance(result, dict) else load_settings().get("service_type", 4097)
                self["status"].setText(_("Player closed  •  engine %s") % engine)
            engine=_configured_playback_engine()
            payload=_player_payload(program, self.profile, {"_catchup_channel": dict(self.catchup_channel)}, "catchup")
            payload["_player_client_ref"]=self.client
            self.session.openWithCallback(closed, UltraStalkerPlayer, url.strip(), name, "catchup", engine, payload)
        self._run_async(lambda handle:self.client.create_catchup_link(self.catchup_channel,program,cancel_event=handle.cancel_event),ok,lambda e:self["status"].setText(_("Catch-up play failed: %s")%e))
