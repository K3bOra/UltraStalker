# -*- coding: utf-8 -*-
"""Hero and account state, and job draining.

Methods moved verbatim out of ``PortalHomeScreen`` (ui_screens_home.py); behaviour is unchanged.
This module is imported by ui_screens_home.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, open, max, min, us_func
from .ui_screens_home import (
    AsyncScreenMixin,
    HOME_HERO_FILE,
    HOME_HERO_SCHEMA,
    _,
    _cleanup_legacy_home_hero_storage,
    asset,
    home_boot_pixmap,
    json,
    load_profiles,
    optional_failure,
    os,
    queue,
    save_profiles,
    splash_home_account_info,
    splash_home_is_warm,
    splash_home_warm_state,
)


class HomeHeroMixin(object):
    """Hero and account state, and job draining."""

    def _read_hero_state(self):
        try:
            if not HOME_HERO_FILE or not os.path.isfile(HOME_HERO_FILE):return {}
            with open(HOME_HERO_FILE,"r",encoding="utf-8") as fh:data=json.load(fh)
            return data if isinstance(data,dict) else {}
        except Exception:
            return {}

    def _read_hero_cache(self):
        data=self._read_hero_state()
        if int(data.get("schema") or 0)!=HOME_HERO_SCHEMA:return None
        hero=data.get("hero") if isinstance(data.get("hero"),dict) else None
        if not hero:return None
        prepared=str(hero.get("prepared") or "")
        try:
            if prepared and os.path.isfile(prepared) and os.path.getsize(prepared)>1024:return hero
        except Exception:pass
        return None

    def _apply_home_hero(self,hero):
        if not isinstance(hero,dict):return
        self._hero_data=hero;overview=str(hero.get("overview") or _("No programme description"))
        try:self["status"].setText(_("%s • DOWN recent • YELLOW new hero • OK open • BACK portals")%_(self.CARDS[self.index][0]))
        except Exception as exc:optional_failure("ui.silent_guard",exc)
        # Hero updates artwork only; the status card is a static skin surface.
        for _name in ("hero_kicker","hero_title","hero_subtitle","hero_rating"):
            try:self[_name].setText("");self[_name].hide()
            except Exception as exc:optional_failure("ui.home_hero_copy_hide",exc)
        path=hero.get("prepared");raw=hero.get("backdrop_local");display_raw=hero.get("display_backdrop_local")
        try:
            # R171 Home fix: fixed green ambient/cards/focus are immutable skin
            # pixmaps.  Hero changes may replace only the upper Hero artwork.
            if path and os.path.isfile(path) and os.path.getsize(path) > 1024:
                try:
                    pix=home_boot_pixmap(path) if callable(home_boot_pixmap) else None
                    if pix is not None:self["hero_backdrop"].instance.setPixmap(pix)
                    else:self["hero_backdrop"].instance.setPixmapFromFile(path)
                    self["hero_backdrop"].show()
                    self._image_displayed_path = path
                except Exception:
                    self._decode_picture(path)
            elif display_raw and os.path.isfile(display_raw) and os.path.getsize(display_raw) > 1024:
                self._decode_picture(display_raw)
            elif raw and os.path.isfile(raw) and os.path.getsize(raw) > 1024:
                self._decode_picture(raw)
            else:
                self._apply_default_home_hero_backdrop()
        except Exception as exc:optional_failure("ui.home_hero_art_apply",exc)

    def _apply_default_home_hero_backdrop(self):
        try:
            fallback = asset("ultra_bg_flag_1920x1080.png") if callable(asset) else ""
            if fallback and os.path.isfile(fallback) and self["hero_backdrop"].instance is not None:
                if getattr(self, "_image_displayed_path", None) != fallback:
                    pix = home_boot_pixmap(fallback) if callable(home_boot_pixmap) else None
                    if pix is not None:
                        self["hero_backdrop"].instance.setPixmap(pix)
                    else:
                        self["hero_backdrop"].instance.setPixmapFromFile(fallback)
                    self._image_displayed_path = fallback
                self["hero_backdrop"].show()
                return True
        except Exception as exc:
            optional_failure("ui.home_hero_default_backdrop", exc)
        return False

    def _load_home_hero(self,force=False,background_fill=False):
        # Explicit single-slot authority only.  No TMDb featured Hero, no local
        # Hero pool, no auto-download, no rotation and no background fill.
        try:
            if _cleanup_legacy_home_hero_storage is not None:
                _cleanup_legacy_home_hero_storage()
        except Exception as exc:optional_failure("ui.hero_legacy_cleanup_home",exc)
        hero=self._read_hero_cache()
        if hero:
            hero=self._ensure_home_visual_materials(dict(hero))
            self._hero_data=hero
            self._apply_home_hero(hero)
            self._rebind_home_materials(hero)
            return
        # When no custom Hero is set by the user, show the shared Settings /
        # Portal List background (ultra_bg_flag_1920x1080.png) as default Hero
        # so Home never looks plain black until the user picks their own Hero.
        self._apply_default_home_hero_backdrop()
        # Fixed green Home chrome belongs to HOME_SKIN and stays visible even
        # when no explicit Hero is pinned.
        try:self["hero_title"].setText("");self["hero_title"].hide()
        except Exception:pass

    def _load_account_state(self):
        # Account/network work was already completed by the selected-portal
        # Splash. A failed portal still opens Home, but it must paint OFFLINE and
        # must not immediately launch another account request behind the user's back.
        try:
            warm_state=splash_home_warm_state(self.profile) if callable(splash_home_warm_state) else {}
        except Exception:
            warm_state={}
        if isinstance(warm_state,dict) and str(warm_state.get("connection_state") or "").lower()=="offline":
            self._set_home_offline_line()
            return
        try:
            warm_info=splash_home_account_info(self.profile) if callable(splash_home_account_info) else {}
        except Exception:
            warm_info={}
        if isinstance(warm_info,dict) and warm_info:
            self._apply_home_account_info(warm_info,persist=False)
            return
        try:
            if splash_home_is_warm and splash_home_is_warm(self.profile):
                self._set_home_account_line(self.profile.get("expiry") or "")
                return
        except Exception:
            pass
        def work():return self.client.account_info()
        def ok(info):
            self._apply_home_account_info(info,persist=True)
        self._run_async(work,ok,lambda e:None)

    def _apply_home_account_info(self,info,persist=True):
        if not isinstance(info,dict):return
        expiry=info.get("phone") or info.get("end_date") or info.get("expire_billing_date") or ""
        state=info.get("status") or info.get("account_status") or "CONNECTED"
        self._set_home_account_line(expiry)
        try:
            self.profile["expiry"]=str(expiry or "")
            self.profile["account_state"]=str(state or "")
            if expiry:self.profile["state"]="%s / %s"%(str(state),str(expiry))
            if not persist:return
            profiles=load_profiles()
            target_portal=str(self.profile.get("portal") or "").rstrip("/").lower()
            target_mac=str(self.profile.get("mac") or "").upper()
            replaced=False
            for row in profiles:
                if (str(row.get("portal") or "").rstrip("/").lower()==target_portal and
                    str(row.get("mac") or "").upper()==target_mac):
                    row.update({"expiry":self.profile.get("expiry","") ,
                                "account_state":self.profile.get("account_state",""),
                                "state":self.profile.get("state","")})
                    replaced=True;break
            if not replaced:profiles.append(dict(self.profile))
            save_profiles(profiles)
        except Exception as exc:optional_failure("ui.home_account_persist",exc)

    def _drain_jobs(self):
        us_func(AsyncScreenMixin._drain_jobs)(self)
        if self._screen_closed:return
        self._drain_image_jobs()
        while True:
            try:job=self._home_jobs.get_nowait()
            except queue.Empty:break
            if not job:continue
            if job[0]=="hero":
                # Ignore stale automatic Hero completions that were queued before
                # an explicit Details -> Set as Home Hero action completed.
                # Re-apply the authoritative pinned state instead.
                try:
                    state=self._read_hero_state() or {}
                    if bool(state.get("manual_pin")):
                        pinned=self._read_hero_cache()
                        if pinned:
                            self._apply_home_hero(pinned)
                            continue
                except Exception as exc:optional_failure("ui.home_manual_pin_queue_guard",exc)
                self._apply_home_hero(job[1])
            elif job[0]=="recent_live_fit":
                _kind,generation,index,path=job
                try:
                    if int(generation)!=int(getattr(self,"_recent_generation",0) or 0):continue
                    index=max(0,min(8,int(index)))
                    if self._recent_group(index)!=0:continue
                    if not (path and os.path.isfile(str(path))):continue
                    self._recent_art_paths[index]=str(path)
                    preferred=self.recent_index if self.focus_row=="recent" and self._recent_group(self.recent_index)==0 else 0
                    self._bind_recent_group_art(0,preferred)
                except Exception as exc:optional_failure("ui.home_recent_live_fit_apply",exc)
            elif job[0]=="recent_progress_laser":
                _kind,generation,index,path=job
                try:
                    if int(generation)!=int(getattr(self,"_recent_generation",0) or 0):continue
                    index=max(0,min(8,int(index)))
                    if self._recent_group(index)==0:continue
                    if not (path and os.path.isfile(str(path))):continue
                    self._recent_progress_paths[index]=str(path)
                    selected=(self.focus_row=="recent" and int(self.recent_index)==index)
                    group=self._recent_group(index);row=self._recent_row(index)
                    self["recent_list%d"%group].update_icon_row(row,self._recent_list_entry(index,selected))
                except Exception as exc:optional_failure("ui.home_recent_laser_apply",exc)
