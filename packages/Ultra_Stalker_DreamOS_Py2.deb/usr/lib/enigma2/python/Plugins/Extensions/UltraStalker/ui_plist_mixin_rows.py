# -*- coding: utf-8 -*-
"""Portal row/status text, badges, genre rows and selection change.

Methods moved verbatim out of ``PortalListScreen`` (ui_screens_portallist.py); behaviour is unchanged.
This module is imported by ui_screens_portallist.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str, int, max, min
from .ui_screens_portallist import (
    _,
    _portal_connection_badge,
    re,
)


class PortalListRowsMixin(object):
    """Portal row/status text, badges, genre rows and selection change."""

    @staticmethod
    def _portal_display_parts(profile):
        p = profile if isinstance(profile, dict) else {}
        health = str(p.get("health") or "unknown").lower()
        raw_state = str(p.get("state") or "Not checked").strip()
        explicit = str(p.get("account_state") or "").strip()
        if str(p.get("source_type") or "").lower()=="m3u":
            if health in ("online","excellent"):status="M3U • ONLINE"
            elif health=="slow":status="M3U • SLOW"
            elif health=="offline":status="M3U • OFFLINE"
            else:status="M3U • READY"
        elif explicit:
            status = explicit
        elif health in ("online", "excellent"):
            status = "ONLINE"
        elif health == "slow":
            status = "SLOW"
        elif health == "offline":
            status = "OFFLINE"
        else:
            status = "NOT CHECKED"
        expiry = str(p.get("expiry") or "").strip()
        if not expiry and "/" in raw_state:
            parts = [x.strip() for x in raw_state.split("/") if x.strip()]
            for part in parts[1:]:
                if "INSECURE HTTP" not in part.upper():
                    expiry = part
                    break
        if not expiry:
            expiry = _("No expiry date")
        return _(status)[:18] if status in ("M3U • ONLINE","M3U • SLOW","M3U • OFFLINE","M3U • READY","ONLINE","SLOW","OFFLINE","NOT CHECKED","DISABLED","EXPIRED","BLOCKED","ACTIVE","UNKNOWN") else status[:18], expiry[:38]

    @staticmethod
    def _portal_card_expiry(expiry):
        text = " ".join(str(expiry or "").split())
        if not text:
            return _("No expiry")
        text = re.sub(r",?\s*\d{1,2}:\d{2}\s*(?:am|pm)$", "", text, flags=re.I).strip(" ,")
        return text[:24]

    @staticmethod
    def _portal_status_text(profile):
        p = profile if isinstance(profile, dict) else {}
        health = str(p.get("health") or "unknown").strip().lower()
        explicit = str(p.get("account_state") or "").strip().upper()
        is_m3u = str(p.get("source_type") or "").lower() == "m3u"
        if health in ("online", "excellent"):
            return "ONLINE"
        if health == "slow":
            return "SLOW"
        if health == "offline":
            return "OFFLINE"
        if explicit in ("ONLINE", "CONNECTED", "ACTIVE", "ENABLED"):
            return "ONLINE"
        if explicit in ("OFFLINE", "DISABLED", "EXPIRED", "BLOCKED"):
            return explicit[:12]
        if is_m3u:
            return "READY"
        return (explicit or "NOT CHECKED")[:12]

    def _portal_status_color(self, profile):
        status = self._portal_status_text(profile)
        if status == "ONLINE":
            # Deliberately vivid neon green so a working source is obvious at a
            # glance even against blue/cyan adaptive portal chrome.
            return 0x39FF88
        if status == "SLOW":
            return 0xFFD166
        if status in ("OFFLINE", "DISABLED", "EXPIRED", "BLOCKED"):
            return 0xFF6677
        return self._portal_value_color

    def _portal_row_tuple(self, index, selected_idx):
        p = self.profiles[index]
        is_m3u = str(p.get("source_type") or "").lower() == "m3u"
        # R69: source_type=m3u stays visually M3U exactly as the Portal footer
        # reports it. Do not reinterpret credential/API URLs as XTREME here.
        name = p.get("name") or ((_("M3U Playlist %d") % (index + 1)) if is_m3u else (_("Portal Server %d") % (index + 1)))
        identity = "M3U" if is_m3u else str(p.get("mac") or "").strip()
        picked = bool(getattr(self, "_portal_select_mode", False) and index in getattr(self, "_portal_selected", set()))
        if picked:
            name = "✓  " + str(name)
            identity = ((_("SELECTED") + " • ") + identity)[:34]
        meta = {
            "selected": bool(index == selected_idx),
            "source_number": int(index) + 1,
            "status_text": _(self._portal_status_text(p)),
            "status_color": self._portal_status_color(p),
            "identity_text": identity,
            # R69: ONLINE remains green and untouched. MAC stays right-aligned
            # in the identity lane; short M3U is centered inside that same lane
            # so it does not look glued to the card edge.
            "identity_color": 0xFF3045,
            "portal_mac_compact": bool(not is_m3u),
            "portal_identity_right": True,
            "portal_identity_source": bool(is_m3u),
            "server_text": "",
            "server_color": 0xEEF6FB,
            "row_asset": self._portal_row_asset,
            "row_selected_asset": self._portal_row_selected_asset,
            "value_color": self._portal_value_color,
            # When single-portal Move mode is active, the row being physically
            # dragged stays unmistakable even though the glass focus frame moves
            # with it. Keep every normal portal name white; only the moving name
            # turns strong red.
            "title_color": (0xFF3045 if bool(getattr(self, "_reorder_mode", False) and index == selected_idx) else 0xFFFFFF),
            "utility_accent_strong": True,
        }
        connection_badge = _portal_connection_badge(p)
        if connection_badge:
            meta["connection_badge_asset"] = connection_badge[0]
            meta["connection_badge_text"] = connection_badge[1]
            meta["connection_badge_dot"] = connection_badge[2]
        icon = self._portal_settings_icon("multi_search.png" if picked else ("channel_list.png" if is_m3u else "web_access.png"))
        return (name, icon, index, meta)

    def _render_source_badges(self, selected_idx=None):
        if selected_idx is None:
            selected_idx = self._index()
        current = self.profiles[selected_idx] if selected_idx is not None and 0 <= selected_idx < len(self.profiles) else {}
        current_m3u = str(current.get("source_type") or "").lower() == "m3u"
        portal_count = sum(1 for p in self.profiles if str((p or {}).get("source_type") or "").lower() != "m3u")
        m3u_count = len(self.profiles) - portal_count
        specs = (
            (_("PORTAL"), "portal", "web_access.png", portal_count, not current_m3u),
            ("M3U", "m3u", "channel_list.png", m3u_count, current_m3u),
        )
        rows = []
        for title, row_key, icon_name, count, active in specs:
            meta = {
                "selected": bool(active and bool(self.profiles)),
                "value": _("%d sources") % int(count),
                "row_asset": self._portal_row_asset,
                "row_selected_asset": self._portal_row_selected_asset,
                "value_color": self._portal_value_color,
                "utility_accent_strong": True,
            }
            rows.append((title, self._portal_settings_icon(icon_name), row_key, meta))

        # release TEST item #5: third right-side card reuses the exact same
        # floating glass row as PORTAL/M3U. It shows the selected source URL
        # plus expiry. Xtream credentials are intentionally not painted on screen.
        source_url = str(current.get("portal") or "").strip() if current else ""
        if source_url and current_m3u:
            try:
                urlsplit = _us_env.urllib_parse.urlsplit
                parsed = urlsplit(source_url)
                if parsed.scheme and parsed.netloc:
                    source_url = "%s://%s" % (parsed.scheme, parsed.netloc)
            except Exception as exc:
                optional_failure("ui.portal_source_address", exc)
        _status, source_expiry = self._portal_display_parts(current) if current else ("", "")
        expiry_text = str(source_expiry or "-").strip() or "-"
        address_title = source_url or _("No source selected")
        address_meta = {
            "selected": False,
            "value": _("Expiry: %s") % expiry_text,
            "row_asset": self._portal_row_asset,
            "row_selected_asset": self._portal_row_selected_asset,
            "value_color": self._portal_value_color,
            "adaptive_title": True,
            "utility_accent_strong": True,
        }
        rows.append((address_title, self._portal_settings_icon("channel_list.png" if current_m3u else "web_access.png"), "source_info", address_meta))
        try:
            self["source_badges"].set_icon_rows(rows)
        except Exception as exc:
            optional_failure("ui.portal_source_badges", exc)
        try:
            self._pt_paint(selected_idx, portal_count, m3u_count)
        except Exception as exc:
            optional_failure("ui.portal_tiles", exc)

    def _render_portal_rows(self, selected_idx=None):
        if selected_idx is None:
            selected_idx = self._index()
        if selected_idx is None:
            selected_idx = 0
        if self.profiles:
            selected_idx = max(0, min(int(selected_idx), len(self.profiles) - 1))
            rows = [self._portal_row_tuple(i, selected_idx) for i in range(len(self.profiles))]
        else:
            meta = {
                "selected": True, "value": _("Add a Portal or M3U source"),
                "row_asset": self._portal_row_asset, "row_selected_asset": self._portal_row_selected_asset,
                "value_color": self._portal_value_color,
                "utility_accent_strong": True,
            }
            rows = [(_("No profiles found"), self._portal_settings_icon("web_access.png"), None, meta)]
        self._portal_rebuilding = True
        try:
            self["list"].set_icon_rows(rows)
            if self.profiles:
                self["list"].moveToIndex(selected_idx)
        finally:
            self._portal_rebuilding = False
        self._portal_visual_index = selected_idx
        self._render_source_badges(selected_idx if self.profiles else None)

    def _selection_changed(self):
        if getattr(self, "_portal_rebuilding", False):
            return
        idx = self._index()
        if idx is None:
            self["portal_page"].setText(_("No Portal / M3U sources"))
            self["status"].setText(_("MENU Portal Manager  •  Add a Portal or M3U source to begin"))
            self["footer_connection"].setText("")
            self._render_source_badges(None)
            return

        old = getattr(self, "_portal_visual_index", idx)
        if idx != old:
            self._portal_visual_index = idx
            for j in set((old, idx)):
                if 0 <= j < len(self.profiles):
                    try:
                        self["list"].update_icon_row(j, self._portal_row_tuple(j, idx))
                    except Exception as exc:
                        optional_failure("ui.portal_settings_row_update", exc)

        total = len(self.profiles)
        try:
            nav_page_size = max(1, int(self["list"]._visible_page_rows()))
        except Exception:
            nav_page_size = 10
        pages = max(1, (total + nav_page_size - 1) // nav_page_size)
        page = (idx // nav_page_size) + 1
        p = self.profiles[idx]
        is_m3u = str(p.get("source_type") or "").lower() == "m3u"
        name = p.get("name") or ((_("M3U Playlist %d") % (idx + 1)) if is_m3u else (_("Portal Server %d") % (idx + 1)))
        status, _expiry = self._portal_display_parts(p)
        page_text = _("Page %d / %d  •  Source %d / %d") % (page, pages, idx + 1, total)
        if getattr(self, "_portal_select_mode", False):
            page_text += "  •  " + (_("%d portals • Multi-select") % len(getattr(self, "_portal_selected", set())))
        self["portal_page"].setText(page_text)
        self._portal_page_text = page_text
        # R5.44: the saved Portal screen no longer paints the selected portal
        # name or the permanent "Portal Connected" label.  The footer is reserved
        # for the compact page/source counter on the left and the action keys on
        # the right.  Keep the legacy Label objects alive for code compatibility,
        # but never feed them permanent UI text.
        self["status"].setText("")
        self["footer_connection"].setText("")
        self._portal_footer_name = ""
        self._portal_footer_connection = ""
        if getattr(self, "_bulk_move_mode", False):
            self._set_check_progress(_("Move %d selected • ARROWS choose destination • GREEN Place Here • BACK Cancel") % len(self._bulk_move_profiles))
        self._position_footer_group()
        self._render_source_badges(idx)
