# -*- coding: utf-8 -*-
"""Static media information in the receiver's selected-service event fields.

This is presentation metadata, not a Live schedule or a playback bookmark.
Cache-only preparation is safe at startup. Export workers may hydrate missing
text through the existing Details Authority; never fetch artwork here.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .. import us_env as _us_env
from ..us_env import str, int, max, min, us_casefold
hashlib = _us_env.hashlib
html = _us_env.html
re = _us_env.re
time = _us_env.time


def text(value, limit=4000):
    if not isinstance(value, (str, int, float)): return ""
    value = re.sub(r"<[^>]*>", " ", str(value))
    value = html.unescape(value)
    value = re.sub(r"[\x00-\x1f\x7f]+", " ", value)
    value = " ".join(value.split()).strip()
    return "" if value.lower() in ("none", "null", "n/a", "0") else value.encode("utf-8")[:limit].decode("utf-8", "ignore")


def _first(sources, keys):
    for source in sources:
        for key in keys:
            if source.get(key) not in (None, "", [], {}): return source[key]
    return ""


def fields(item, snapshot=None, media_type="vod", season_count=0):
    item = item if isinstance(item, dict) else {}
    snapshot = snapshot if isinstance(snapshot, dict) else {}
    info = item.get("info") if isinstance(item.get("info"), dict) else {}
    overlay = snapshot.get("item_overlay") if isinstance(snapshot.get("item_overlay"), dict) else {}
    sources = (snapshot, overlay, info, item)
    raw_genres = _first(sources, ("genres", "genre", "genre_name"))
    if isinstance(raw_genres, str): raw_genres = re.split(r"[,;/|]+", raw_genres)
    if not isinstance(raw_genres, (list, tuple)): raw_genres = []
    genres = []
    for value in raw_genres:
        value = text(value.get("name") if isinstance(value, dict) else value, 70)
        if value and not value.isdigit() and us_casefold(value) not in [us_casefold(x) for x in genres]: genres.append(value)
    year = ""
    raw_date = _first(sources, ("release_date", "releasedate", "year", "movie_year", "first_air_date"))
    match = re.search(r"(?<!\d)(?:19|20)\d{2}(?!\d)", str(raw_date or ""))
    if not match:
        match = re.search(r"[\[(]((?:19|20)\d{2})[\])]", str(item.get("_raw_name") or item.get("name") or item.get("title") or ""))
    if match: year = match.group(1) if match.lastindex else match.group(0)
    raw_count = _first(sources, ("number_of_seasons", "seasons_count", "season_count", "total_seasons"))
    try: count = max(0, min(500, int(raw_count or season_count or 0)))
    except (ValueError, TypeError): count = max(0, min(500, int(season_count or 0)))
    description = ""
    for source in sources:
        for key in ("_details_visible_overview", "_details_provider_overview", "overview", "description_full", "plot", "description", "descr", "story", "storyline"):
            description = text(source.get(key))
            if description:break
        if description:break
    parts = list(genres[:3])
    if media_type in ("episode", "series", "tv"):
        if count: parts.append("%d %s" % (count, "season" if count == 1 else "seasons"))
        elif not parts: parts.append("Series")
    else:
        if year: parts.append(year)
        elif not parts: parts.append("Movie")
    summary = " • ".join(parts)
    if not description:
        description = summary
    return {"summary": summary, "description": description,
            "genres": genres[:3], "year": year, "season_count": count}


def prepare(profile, item, media_type="vod", season_count=0, hydrate=False, provider_client=None):
    item = item if isinstance(item, dict) else {}
    snapshot = {}
    try:
        from ..persistent_cache import load_shared_detail_snapshot
        snapshot = load_shared_detail_snapshot(profile or {}, "series" if media_type in ("episode", "series", "tv") else "vod", item) or {}
    except Exception:
        pass
    # Catalogue rows are usually thin. Details snapshots and canonical TMDb
    # records are separate stores; missing one must not discard the other.
    if not snapshot.get("overview") or not snapshot.get("genres"):
        try:
            from ..artwork_v2 import load_manifest, identity_cache_compatible
            canonical = load_manifest(profile or {}, "series" if media_type in ("episode", "series", "tv") else "vod", item) or {}
            if canonical and identity_cache_compatible(item, canonical):
                snapshot = dict(canonical, **{k:v for k,v in snapshot.items() if v not in (None,"",[],{})})
        except Exception:
            pass
    result = fields(item, snapshot, media_type, season_count)
    if hydrate and (not result["description"] or not result["summary"]):
        try:
            from ..details_authority import resolve_metadata_fast
            resolved = resolve_metadata_fast(profile or {}, "series" if media_type in ("episode","series","tv") else "vod", dict(item), current=snapshot, provider_client=provider_client) or {}
            fresh = fields(item, resolved, media_type, season_count)
            # Keep the approved cached text if a network lookup is incomplete.
            result.update({k:v for k,v in fresh.items() if not result.get(k) and v not in (None,"",[],{})})
        except Exception:
            pass
    result["summary"] = fields(result, {}, media_type, season_count)["summary"]
    # One source per series, not a copy on every episode. It lets GUI restart
    # refresh information from the same cached identity without title searches.
    keys = ("id","movie_id","series_id","stream_id","_xtream","_xtream_kind","_raw_name","_provider_name","name","title","original_name","original_title","tmdb_id","tmdbid","_locked_tmdb_id","_locked_tmdb_type","_ultra_search_verified_tmdb_id","identity_verified","identity_pointer_verified","imdb_id","year","release_date","first_air_date","genres","genre","overview","plot","description","descr","country_code","origin_country","original_language","number_of_seasons","seasons_count","season_count")
    source = {k:item[k] for k in keys if item.get(k) not in (None,"",[],{})}
    if isinstance(item.get("info"),dict):source["info"]={k:item["info"][k] for k in keys if item["info"].get(k) not in (None,"",[],{})}
    result["_source_item"] = source
    result["_media_type"] = media_type
    return result


def seed(pairs, now=None):
    now = int(time.time() if now is None else now)
    start = (now // 86400) * 86400
    out = []
    # How long the description / genre / year stay visible without a refresh.
    # Fewer days for very large exports to keep the receiver's EPG memory small.
    total = len(pairs or [])
    days = 30 if total <= 1500 else (14 if total <= 4000 else 7)
    for ref, row in pairs or []:
        kind = str(row.get("_receiver_media_type") or "").lower()
        if kind not in ("vod", "movie", "episode", "series"): continue
        metadata = row.get("_receiver_metadata") or {}
        if not isinstance(metadata, dict): continue
        name = text(row.get("_receiver_name") or row.get("name") or row.get("title"), 240)
        summary = text(metadata.get("summary"), 240) or ("Series" if kind in ("series", "episode") else "Movie")
        description = text(metadata.get("description")) or summary or name
        event_title = summary or name
        eid = int(hashlib.sha1((str(ref)+"|media-info").encode("utf-8")).hexdigest()[:4],16) or 1
        # Some native EPG caches require a later event to find the current one:
        # lower_bound(now) == end otherwise returns no event, even while it runs.
        # Keep the following days too, including across midnight before the
        # daily refresh. Distinct nonzero IDs prevent the future rows replacing
        # today's row. This is data compatibility, independent of image branding.
        events = [(start + day * 86400, 86400, event_title, summary,
                   description, ((eid - 1 + day) % 65535) + 1)
                  for day in range(days)]
        out.append({"service_ref":str(ref),"service_name":name,"events":events})
    return out
