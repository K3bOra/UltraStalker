# -*- coding: utf-8 -*-
"""Portal list screen extracted from ui.py without changing class behavior."""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str, int, round, max, min, us_clear, us_func

from .ui_compact_footer import compact_footer_skin, install_compact_footer
from .ui_shared_footer import lower_existing_footer
from . import _
from .ui_floating_notice import show_notice
hashlib = _us_env.hashlib
json = _us_env.json
os = _us_env.os
queue = _us_env.queue
re = _us_env.re
time = _us_env.time
urllib = _us_env.urllib
urllib = _us_env.urllib
ThreadPoolExecutor = _us_env.concurrent_futures.ThreadPoolExecutor; as_completed = _us_env.concurrent_futures.as_completed

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.InputBox import InputBox
try:
    from Screens.VirtualKeyBoard import VirtualKeyBoard
except Exception:
    VirtualKeyBoard = None
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap
from enigma import eTimer, getDesktop, ePoint, eSize, eLabel, gFont
from skin import parseColor

from .ui_async import AsyncScreenMixin
from .ui_settings_glass import SettingsGlassList
from .ui_image_loader import ImageLoaderMixin
from .ui_transition import TransitionMixin
from .ui_helpers import fit_color_key_labels
from .ui_fixed_adaptive import fixed_settings_rows, fixed_value_color, fixed_settings_chrome, cleanup_legacy_application_outputs
# R112: settings popup factories are injected by ui.py.  Keeping this screen
# independent prevents the 150KB settings implementation from loading merely
# to paint the portal list.
SettingsGlassChoiceScreen = None
SettingsGlassNoticeScreen = None
SettingsGlassInputScreen = None
from .log import diagnostic_failure, get_logger
from .localization import localized_strftime as _lstrf

LOG = get_logger()

MAIN_SKIN = ""
_plugin_original_service_getter = lambda: None
_plugin_service_captured_getter = lambda: False


def _portal_category_backdrop():
    """Return the shared bundled background used by portal surfaces."""
    fallback = asset("ultra_bg_flag_1920x1080.png")
    return fallback if fallback and os.path.isfile(fallback) else ""


# Provider-reported connection telemetry only. Never synthesize or default a
# count: the badge appears only when the server itself returned BOTH values.
def _provider_connection_int(value):
    if isinstance(value, bool) or value is None:
        return None
    try:
        text = str(value).strip()
        if not text or not re.match(r"^\d+$", text):
            return None
        number = int(text)
    except Exception:
        return None
    return number if 0 <= number <= 999 else None

def _provider_payload_dicts(payload):
    """Yield provider dictionaries recursively without interpreting free text."""
    stack = [payload]
    seen = set()
    while stack:
        current = stack.pop()
        ident = id(current)
        if ident in seen:
            continue
        seen.add(ident)
        if isinstance(current, dict):
            yield current
            for value in current.values():
                if isinstance(value, (dict, list, tuple)):
                    stack.append(value)
        elif isinstance(current, (list, tuple)):
            for value in current:
                if isinstance(value, (dict, list, tuple)):
                    stack.append(value)

def _extract_provider_connections(payloads):
    """Return a real (active,max) pair only from one explicit provider object.

    We intentionally do not combine an active value from one response/object with
    a limit from another.  That would look clever but could manufacture a false
    pair.  If the provider does not return both values together, no badge is shown.
    """
    # Known provider field pairs. Xtream's user_info pair is first and therefore
    # wins when present. The remaining pairs are accepted only when BOTH numeric
    # values live in the same provider dictionary.
    exact_pairs = (
        ("active_cons", "max_connections"),
        ("active_connections", "max_connections"),
        ("current_connections", "max_connections"),
        ("current_cons", "max_cons"),
        ("used_connections", "allowed_connections"),
        ("connections_active", "connections_limit"),
        ("online_connections", "max_online_connections"),
        ("active_streams", "max_streams"),
    )
    for source_name, payload in payloads or ():
        for node in _provider_payload_dicts(payload):
            for active_key, max_key in exact_pairs:
                if active_key not in node or max_key not in node:
                    continue
                active = _provider_connection_int(node.get(active_key))
                maximum = _provider_connection_int(node.get(max_key))
                if active is None or maximum is None or maximum <= 0:
                    continue
                return {
                    "active": active,
                    "max": maximum,
                    "source": str(source_name or "provider_exact"),
                    "active_key": active_key,
                    "max_key": max_key,
                }
    return None

def _probe_provider_connections(client, account_info=None, cancel_event=None):
    """Perform a patient, fresh provider check for real connection counts.

    Xtream player_api is authoritative.  Stalker/MAG panels vary, so when the
    main account object has no pair we also ask fresh account + profile variants.
    No request runs while simply moving the selection; this is called ONLY by
    Check / Check All and its result is persisted in the profile.
    """
    if cancel_event is not None and cancel_event.is_set():
        return None
    payloads = []

    # Xtream/M3U adapter. account_info() triggers a real player_api probe when
    # needed; Check All also calls probe() first.  Use that fresh response first.
    if hasattr(client, "_xtream_probe"):
        if isinstance(account_info, dict):
            payloads.append(("provider_exact", account_info))
        found = _extract_provider_connections(payloads)
        if found:
            return found
        if not getattr(client, "_xtream", None):
            return None
        try:
            client._xtream_probe(cancel_event=cancel_event)
            account = getattr(client, "_xtream_account", None)
            if account:
                payloads.append(("provider_exact", account))
        except Exception as exc:
            optional_failure("ui.portal_connections_xtream", exc)
        return _extract_provider_connections(payloads)

    # Stalker/MAG: do not stop at a cached/fast account response.  Ask the
    # provider again without cache, then inspect get_profile variants too.
    if hasattr(client, "_get") and hasattr(client, "_unwrap"):
        try:
            if not getattr(client, "token", ""):
                client.authorize(cancel_event=cancel_event)
        except Exception as exc:
            optional_failure("ui.portal_connections_authorize", exc)
            return None
        for type_name in ("account_info", "account"):
            if cancel_event is not None and cancel_event.is_set():
                return None
            try:
                fresh = client._get({
                    "type": type_name, "action": "get_main_info", "JsHttpRequest": "1-xml"
                }, use_cache=False, cancel_event=cancel_event)
                if isinstance(fresh, (dict, list, tuple)):
                    payloads.append(("provider_exact", fresh))
                    found = _extract_provider_connections(payloads)
                    if found:
                        return found
            except Exception as exc:
                optional_failure("ui.portal_connections_account", exc)
        profile_params = []
        try:
            profile_params.append(client._full_profile_params(getattr(client, "resolved_device_profile", None)))
        except Exception as exc:
            optional_failure("ui.portal_connections_full_profile_params", exc)
        try:
            profile_params.append(client._basic_profile_params())
        except Exception as exc:
            optional_failure("ui.portal_connections_basic_profile_params", exc)
        for params in profile_params:
            if cancel_event is not None and cancel_event.is_set():
                return None
            try:
                fresh = client._get(params, use_cache=False, retry_auth=False, cancel_event=cancel_event)
                if isinstance(fresh, (dict, list, tuple)):
                    payloads.append(("provider_exact", fresh))
                    found = _extract_provider_connections(payloads)
                    if found:
                        return found
            except Exception as exc:
                optional_failure("ui.portal_connections_profile", exc)
        # Keep the original account payload as a final exact fallback only after
        # the fresh provider probes have had a real chance to answer.
        if isinstance(account_info, dict):
            payloads.append(("provider_exact", account_info))
        found = _extract_provider_connections(payloads)
        if not found:
            keys = sorted({str(key) for _source, payload in payloads
                           for node in _provider_payload_dicts(payload) for key in node
                           if re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]{0,63}", str(key))})
            LOG.info("PORTAL_CONNECTION_FIELDS no explicit active/limit pair; fields=%s", ",".join(keys[:120]))
        return found
    return None

def _run_bounded_probes(items, probe, cancelled, on_result, on_timeout, slots=4, limit=60.0, tick=0.5):
    """Run ``probe(item)`` for every item with at most ``slots`` probes alive.

    The time limit is per probe, measured from the moment it actually started.
    A probe that exceeds ``limit`` seconds is reported through ``on_timeout`` and
    stops occupying a slot (its thread is abandoned and ends with its own socket
    timeout). Queued items are therefore never marked as timed out merely because
    the first few sources were dead, and a few dead sources cannot starve the rest.
    ``on_result(item, result, error)`` receives either the result or the exception.
    """
    _wait = _us_env.concurrent_futures.wait; _FIRST = _us_env.concurrent_futures.FIRST_COMPLETED
    todo = list(items)
    active = {}
    pool = ThreadPoolExecutor(max_workers=max(1, len(todo)), thread_name_prefix="us-portal-check")
    try:
        while (todo or active) and not cancelled():
            while todo and len(active) < max(1, int(slots)):
                item = todo.pop(0)
                active[pool.submit(probe, item)] = (item, time.monotonic())
            finished, _pending = _wait(set(active), timeout=tick, return_when=_FIRST)
            for future in finished:
                item, _started = active.pop(future)
                try:
                    result = future.result()
                except Exception as exc:
                    on_result(item, None, exc)
                else:
                    on_result(item, result, None)
            now = time.monotonic()
            for future, (item, started) in list(active.items()):
                if now - started > limit:
                    future.cancel()
                    del active[future]
                    on_timeout(item)
    finally:
        try:
            pool.shutdown(wait=False, cancel_futures=True)
        except TypeError:
            pool.shutdown(wait=False)


def _clear_profile_connections(profile):
    if not isinstance(profile, dict):
        return
    profile.pop("active_connections", None)
    profile.pop("max_connections", None)
    profile.pop("connections_source", None)


def _portal_connection_badge(profile):
    p = profile if isinstance(profile, dict) else {}
    if str(p.get("connections_source") or "") != "provider_exact":
        return None
    active = _provider_connection_int(p.get("active_connections"))
    maximum = _provider_connection_int(p.get("max_connections"))
    if active is None or maximum is None or maximum <= 0:
        return None
    # Compact resident badge: used/limit, with room for legitimate 3-digit counts.
    text = "%d/%d" % (active, maximum)
    dot = "pt_dot_amber.png" if active >= maximum else "pt_dot_green.png"
    return asset("poster_grid2_premium/badge_70x26.png"), text, asset(dot)

def _portal_settings_text_width_px(text, font_size=24):
    """Exact copy of the Plugin Settings text measurement rule."""
    try:
        from .wqhd_layout import measure_text_width
        return measure_text_width(str(text or ""), int(font_size), responsive=False)
    except Exception as exc:
        optional_failure("ui.portal_settings_text_measure",exc)
        return max(0,int(len(str(text or ""))*font_size*0.56))


def configure_portal_list(**deps):
    globals().update(deps)
    for _mixin_module in _MIXIN_MODULES:
        _mixin_module.__dict__.update(deps)
    # Portal selection now deliberately shares the approved Settings Test8
    # visual shell instead of the legacy portal-specific full-page skin.
    try:
        scaler=deps.get("font_scale_skin")
        _portal_skin = lower_existing_footer(PORTAL_SELECTION_SETTINGS_SKIN)
        PortalListScreen.skin = scaler(_portal_skin) if callable(scaler) else _portal_skin
        PortalManagerPremiumScreen.skin = scaler(PORTAL_MANAGER_PREMIUM_SKIN) if callable(scaler) else PORTAL_MANAGER_PREMIUM_SKIN
        FreeLibraryShellScreen.skin = scaler(compact_footer_skin(FREE_LIBRARY_SHELL_SKIN)) if callable(scaler) else compact_footer_skin(FREE_LIBRARY_SHELL_SKIN)
    except Exception as exc:
        optional_failure("ui.portal_skin_config",exc)


PORTAL_MANAGER_PREMIUM_SKIN = '<screen name="PortalManagerPremiumScreen" position="center,center" size="1920,1080" backgroundColor="#02070b" flags="wfNoBorder">\n <widget name="ambient_bg" position="0,0" size="1920,1080" alphatest="blend" scale="1" transparent="1" zPosition="1"/>\n <widget name="hero_backdrop" position="0,0" size="1920,1080" alphatest="blend" scale="1" transparent="1" zPosition="2"/>\n <widget name="list" position="48,50" size="440,1000" foregroundColor="#ffffff" foregroundColorSelected="#ffffff" selectionPixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/portal_selection_clear.png" scrollbarMode="showNever" transparent="1" zPosition="7"/>\n <widget name="context_title" position="1160,618" size="650,40" font="Regular;29" foregroundColor="#ffffff" transparent="1" zPosition="11" shadowColor="#000000" shadowOffset="1,1"/>\n <widget name="context_subtitle" position="1160,658" size="650,28" font="Regular;17" foregroundColor="#91b7ca" transparent="1" zPosition="11" shadowColor="#000000" shadowOffset="1,1"/>\n <widget name="context_list" position="1160,700" size="650,220" foregroundColor="#ffffff" foregroundColorSelected="#ffffff" selectionPixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/portal_selection_clear.png" scrollbarMode="showNever" transparent="1" zPosition="12"/>\n <widget name="status" position="540,1028" size="1320,34" font="Regular;18" halign="right" valign="center" foregroundColor="#b7d9eb" shadowColor="#000000" shadowOffset="1,1" transparent="1" zPosition="9"/>\n <widget name="context_panel" position="1190,628" size="560,260" alphatest="blend" transparent="1" zPosition="10"/>\n <widget name="context_message" position="1226,696" size="488,174" font="Regular;20" foregroundColor="#f4f8fb" transparent="1" zPosition="11" noWrap="0"/>\n</screen>'

# R5.217: Free Portal / Free Xtream summary sits lower and remains visually
# anchored above the blue Preview end of the footer.  The title and its two
# summary lines share one centred block so the hierarchy reads as one unit.
FREE_LIBRARY_SHELL_SKIN = '<screen name="FreeLibraryShellScreen" position="center,center" size="1920,1080" backgroundColor="#02070b" flags="wfNoBorder">\n <widget name="ambient_bg" position="0,0" size="1920,1080" alphatest="blend" scale="1" transparent="1" zPosition="1" />\n <widget name="hero_backdrop" position="0,0" size="1920,1080" alphatest="blend" scale="1" transparent="1" zPosition="2" />\n <widget name="list" position="48,50" size="440,1000" foregroundColor="#ffffff" foregroundColorSelected="#ffffff" selectionPixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/portal_selection_clear.png" scrollbarMode="showNever" transparent="1" zPosition="7" />\n <widget name="context_title" position="1498,852" size="384,42" font="Regular;32" halign="center" valign="center" foregroundColor="#ffffff" transparent="1" zPosition="11" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="context_subtitle" position="1498,898" size="384,84" font="Regular;20" halign="center" valign="top" foregroundColor="#6da487" transparent="1" zPosition="11" shadowColor="#000000" shadowOffset="1,1" noWrap="0" />\n <widget name="context_list" position="1160,700" size="650,220" foregroundColor="#ffffff" foregroundColorSelected="#ffffff" selectionPixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/portal_selection_clear.png" scrollbarMode="showNever" transparent="1" zPosition="12" />\n <widget name="status" position="540,998" size="625,30" font="Regular;17" halign="right" valign="center" foregroundColor="#b7d9eb" shadowColor="#000000" shadowOffset="1,1" transparent="1" zPosition="9" noWrap="1" />\n <widget position="1196,1011" size="56,42" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/player_keyline_red_dash_56x42.png" alphatest="blend" scale="1" zPosition="9" name="free_red_dash" transparent="1" />\n <widget name="red" position="1254,1011" size="134,42" font="Regular;20" halign="left" valign="center" foregroundColor="#ffffff" transparent="1" zPosition="10" noWrap="1" shadowColor="#000000" shadowOffset="1,1" />\n <widget position="1356,1011" size="56,42" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/player_keyline_green_dash_56x42.png" alphatest="blend" scale="1" zPosition="9" name="free_green_dash" transparent="1" />\n <widget name="green" position="1414,1011" size="134,42" font="Regular;20" halign="left" valign="center" foregroundColor="#ffffff" transparent="1" zPosition="10" noWrap="1" shadowColor="#000000" shadowOffset="1,1" />\n <widget position="1516,1011" size="56,42" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/player_keyline_yellow_dash_56x42.png" alphatest="blend" scale="1" zPosition="9" name="free_yellow_dash" transparent="1" />\n <widget name="yellow" position="1574,1011" size="134,42" font="Regular;20" halign="left" valign="center" foregroundColor="#ffffff" transparent="1" zPosition="10" noWrap="1" shadowColor="#000000" shadowOffset="1,1" />\n <widget position="1676,1011" size="56,42" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/player_keyline_blue_dash_56x42.png" alphatest="blend" scale="1" zPosition="9" name="free_blue_dash" transparent="1" />\n <widget name="blue" position="1734,1011" size="134,42" font="Regular;20" halign="left" valign="center" foregroundColor="#ffffff" transparent="1" zPosition="10" noWrap="1" shadowColor="#000000" shadowOffset="1,1" />\n<widget name="free_summary_card" position="2000,0" size="420,132" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/free_summary_seamless_420x132.png" alphatest="blend" scale="1" transparent="1" zPosition="9" /></screen>'

PORTAL_SELECTION_SETTINGS_SKIN = '<screen name="PortalListScreen" position="center,center" size="1920,1080" backgroundColor="#02070b" flags="wfNoBorder">\n <widget name="ambient_bg" position="0,0" size="1920,1080" alphatest="blend" scale="1" transparent="1" zPosition="1" />\n <widget name="hero_backdrop" position="0,0" size="1920,1080" alphatest="blend" scale="1" transparent="1" zPosition="2" />\n <ePixmap position="0,0" size="1400,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/pt_veil_1400x1080.png" alphatest="blend" zPosition="3" />\n <widget name="list" position="2000,20" size="620,1040" foregroundColor="#ffffff" foregroundColorSelected="#ffffff" selectionPixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/portal_selection_clear.png" scrollbarMode="showNever" transparent="1" zPosition="1" />\n <widget name="source_badges" position="2000,792" size="430,240" foregroundColor="#ffffff" foregroundColorSelected="#ffffff" selectionPixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/portal_selection_clear.png" scrollbarMode="showNever" transparent="1" zPosition="1" />\n <widget name="pt_title" position="60,92" size="270,50" font="Regular;32" halign="left" valign="center" foregroundColor="#ffffff" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_tab0" position="330,100" size="180,38" font="Regular;22" halign="left" valign="center" foregroundColor="#ffffff" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_tab1" position="540,100" size="180,38" font="Regular;22" halign="left" valign="center" foregroundColor="#a0a0a8" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_tab_line" position="330,142" size="120,3" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/pt_tab_line_120x3.png" alphatest="blend" transparent="1" zPosition="6" />\n <ePixmap position="56,195" size="380,148" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/pt_tile_380x148.png" alphatest="blend" zPosition="4" />\n <widget name="pt_num0" position="78,211" size="76,54" font="Regular;38" halign="left" valign="center" foregroundColor="#76767e" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_name0" position="156,213" size="262,34" font="Regular;22" halign="left" valign="center" foregroundColor="#cdcdd4" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_id0" position="156,249" size="262,24" font="Regular;16" halign="left" valign="center" foregroundColor="#a0a0a8" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_dot0" position="84,296" size="10,10" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/pt_dot_green.png" alphatest="blend" transparent="1" zPosition="8" />\n <widget name="pt_status0" position="102,287" size="170,28" font="Regular;16" halign="left" valign="center" foregroundColor="#a0a0a8" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_days0" position="252,287" size="160,28" font="Regular;16" halign="right" valign="center" foregroundColor="#6edca0" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_track0" position="82,321" size="328,3" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/pt_track_328x3.png" alphatest="blend" transparent="1" zPosition="7" />\n <widget name="pt_fill0" position="82,321" size="328,3" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/pt_fill_green_328x3.png" alphatest="blend" transparent="1" zPosition="8" />\n <ePixmap position="456,195" size="380,148" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/pt_tile_380x148.png" alphatest="blend" zPosition="4" />\n <widget name="pt_num1" position="478,211" size="76,54" font="Regular;38" halign="left" valign="center" foregroundColor="#76767e" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_name1" position="556,213" size="262,34" font="Regular;22" halign="left" valign="center" foregroundColor="#cdcdd4" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_id1" position="556,249" size="262,24" font="Regular;16" halign="left" valign="center" foregroundColor="#a0a0a8" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_dot1" position="484,296" size="10,10" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/pt_dot_green.png" alphatest="blend" transparent="1" zPosition="8" />\n <widget name="pt_status1" position="502,287" size="170,28" font="Regular;16" halign="left" valign="center" foregroundColor="#a0a0a8" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_days1" position="652,287" size="160,28" font="Regular;16" halign="right" valign="center" foregroundColor="#6edca0" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_track1" position="482,321" size="328,3" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/pt_track_328x3.png" alphatest="blend" transparent="1" zPosition="7" />\n <widget name="pt_fill1" position="482,321" size="328,3" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/pt_fill_green_328x3.png" alphatest="blend" transparent="1" zPosition="8" />\n <ePixmap position="856,195" size="380,148" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/pt_tile_380x148.png" alphatest="blend" zPosition="4" />\n <widget name="pt_num2" position="878,211" size="76,54" font="Regular;38" halign="left" valign="center" foregroundColor="#76767e" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_name2" position="956,213" size="262,34" font="Regular;22" halign="left" valign="center" foregroundColor="#cdcdd4" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_id2" position="956,249" size="262,24" font="Regular;16" halign="left" valign="center" foregroundColor="#a0a0a8" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_dot2" position="884,296" size="10,10" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/pt_dot_green.png" alphatest="blend" transparent="1" zPosition="8" />\n <widget name="pt_status2" position="902,287" size="170,28" font="Regular;16" halign="left" valign="center" foregroundColor="#a0a0a8" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_days2" position="1052,287" size="160,28" font="Regular;16" halign="right" valign="center" foregroundColor="#6edca0" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_track2" position="882,321" size="328,3" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/pt_track_328x3.png" alphatest="blend" transparent="1" zPosition="7" />\n <widget name="pt_fill2" position="882,321" size="328,3" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/pt_fill_green_328x3.png" alphatest="blend" transparent="1" zPosition="8" />\n <ePixmap position="56,358" size="380,148" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/pt_tile_380x148.png" alphatest="blend" zPosition="4" />\n <widget name="pt_num3" position="78,374" size="76,54" font="Regular;38" halign="left" valign="center" foregroundColor="#76767e" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_name3" position="156,376" size="262,34" font="Regular;22" halign="left" valign="center" foregroundColor="#cdcdd4" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_id3" position="156,412" size="262,24" font="Regular;16" halign="left" valign="center" foregroundColor="#a0a0a8" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_dot3" position="84,459" size="10,10" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/pt_dot_green.png" alphatest="blend" transparent="1" zPosition="8" />\n <widget name="pt_status3" position="102,450" size="170,28" font="Regular;16" halign="left" valign="center" foregroundColor="#a0a0a8" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_days3" position="252,450" size="160,28" font="Regular;16" halign="right" valign="center" foregroundColor="#6edca0" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_track3" position="82,484" size="328,3" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/pt_track_328x3.png" alphatest="blend" transparent="1" zPosition="7" />\n <widget name="pt_fill3" position="82,484" size="328,3" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/pt_fill_green_328x3.png" alphatest="blend" transparent="1" zPosition="8" />\n <ePixmap position="456,358" size="380,148" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/pt_tile_380x148.png" alphatest="blend" zPosition="4" />\n <widget name="pt_num4" position="478,374" size="76,54" font="Regular;38" halign="left" valign="center" foregroundColor="#76767e" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_name4" position="556,376" size="262,34" font="Regular;22" halign="left" valign="center" foregroundColor="#cdcdd4" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_id4" position="556,412" size="262,24" font="Regular;16" halign="left" valign="center" foregroundColor="#a0a0a8" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_dot4" position="484,459" size="10,10" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/pt_dot_green.png" alphatest="blend" transparent="1" zPosition="8" />\n <widget name="pt_status4" position="502,450" size="170,28" font="Regular;16" halign="left" valign="center" foregroundColor="#a0a0a8" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_days4" position="652,450" size="160,28" font="Regular;16" halign="right" valign="center" foregroundColor="#6edca0" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_track4" position="482,484" size="328,3" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/pt_track_328x3.png" alphatest="blend" transparent="1" zPosition="7" />\n <widget name="pt_fill4" position="482,484" size="328,3" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/pt_fill_green_328x3.png" alphatest="blend" transparent="1" zPosition="8" />\n <ePixmap position="856,358" size="380,148" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/pt_tile_380x148.png" alphatest="blend" zPosition="4" />\n <widget name="pt_num5" position="878,374" size="76,54" font="Regular;38" halign="left" valign="center" foregroundColor="#76767e" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_name5" position="956,376" size="262,34" font="Regular;22" halign="left" valign="center" foregroundColor="#cdcdd4" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_id5" position="956,412" size="262,24" font="Regular;16" halign="left" valign="center" foregroundColor="#a0a0a8" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_dot5" position="884,459" size="10,10" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/pt_dot_green.png" alphatest="blend" transparent="1" zPosition="8" />\n <widget name="pt_status5" position="902,450" size="170,28" font="Regular;16" halign="left" valign="center" foregroundColor="#a0a0a8" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_days5" position="1052,450" size="160,28" font="Regular;16" halign="right" valign="center" foregroundColor="#6edca0" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_track5" position="882,484" size="328,3" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/pt_track_328x3.png" alphatest="blend" transparent="1" zPosition="7" />\n <widget name="pt_fill5" position="882,484" size="328,3" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/pt_fill_green_328x3.png" alphatest="blend" transparent="1" zPosition="8" />\n <ePixmap position="56,521" size="380,148" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/pt_tile_380x148.png" alphatest="blend" zPosition="4" />\n <widget name="pt_num6" position="78,537" size="76,54" font="Regular;38" halign="left" valign="center" foregroundColor="#76767e" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_name6" position="156,539" size="262,34" font="Regular;22" halign="left" valign="center" foregroundColor="#cdcdd4" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_id6" position="156,575" size="262,24" font="Regular;16" halign="left" valign="center" foregroundColor="#a0a0a8" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_dot6" position="84,622" size="10,10" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/pt_dot_green.png" alphatest="blend" transparent="1" zPosition="8" />\n <widget name="pt_status6" position="102,613" size="170,28" font="Regular;16" halign="left" valign="center" foregroundColor="#a0a0a8" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_days6" position="252,613" size="160,28" font="Regular;16" halign="right" valign="center" foregroundColor="#6edca0" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_track6" position="82,647" size="328,3" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/pt_track_328x3.png" alphatest="blend" transparent="1" zPosition="7" />\n <widget name="pt_fill6" position="82,647" size="328,3" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/pt_fill_green_328x3.png" alphatest="blend" transparent="1" zPosition="8" />\n <ePixmap position="456,521" size="380,148" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/pt_tile_380x148.png" alphatest="blend" zPosition="4" />\n <widget name="pt_num7" position="478,537" size="76,54" font="Regular;38" halign="left" valign="center" foregroundColor="#76767e" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_name7" position="556,539" size="262,34" font="Regular;22" halign="left" valign="center" foregroundColor="#cdcdd4" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_id7" position="556,575" size="262,24" font="Regular;16" halign="left" valign="center" foregroundColor="#a0a0a8" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_dot7" position="484,622" size="10,10" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/pt_dot_green.png" alphatest="blend" transparent="1" zPosition="8" />\n <widget name="pt_status7" position="502,613" size="170,28" font="Regular;16" halign="left" valign="center" foregroundColor="#a0a0a8" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_days7" position="652,613" size="160,28" font="Regular;16" halign="right" valign="center" foregroundColor="#6edca0" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_track7" position="482,647" size="328,3" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/pt_track_328x3.png" alphatest="blend" transparent="1" zPosition="7" />\n <widget name="pt_fill7" position="482,647" size="328,3" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/pt_fill_green_328x3.png" alphatest="blend" transparent="1" zPosition="8" />\n <ePixmap position="856,521" size="380,148" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/pt_tile_380x148.png" alphatest="blend" zPosition="4" />\n <widget name="pt_num8" position="878,537" size="76,54" font="Regular;38" halign="left" valign="center" foregroundColor="#76767e" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_name8" position="956,539" size="262,34" font="Regular;22" halign="left" valign="center" foregroundColor="#cdcdd4" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_id8" position="956,575" size="262,24" font="Regular;16" halign="left" valign="center" foregroundColor="#a0a0a8" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_dot8" position="884,622" size="10,10" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/pt_dot_green.png" alphatest="blend" transparent="1" zPosition="8" />\n <widget name="pt_status8" position="902,613" size="170,28" font="Regular;16" halign="left" valign="center" foregroundColor="#a0a0a8" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_days8" position="1052,613" size="160,28" font="Regular;16" halign="right" valign="center" foregroundColor="#6edca0" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_track8" position="882,647" size="328,3" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/pt_track_328x3.png" alphatest="blend" transparent="1" zPosition="7" />\n <widget name="pt_fill8" position="882,647" size="328,3" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/pt_fill_green_328x3.png" alphatest="blend" transparent="1" zPosition="8" />\n <ePixmap position="56,684" size="380,148" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/pt_tile_380x148.png" alphatest="blend" zPosition="4" />\n <widget name="pt_num9" position="78,700" size="76,54" font="Regular;38" halign="left" valign="center" foregroundColor="#76767e" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_name9" position="156,702" size="262,34" font="Regular;22" halign="left" valign="center" foregroundColor="#cdcdd4" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_id9" position="156,738" size="262,24" font="Regular;16" halign="left" valign="center" foregroundColor="#a0a0a8" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_dot9" position="84,785" size="10,10" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/pt_dot_green.png" alphatest="blend" transparent="1" zPosition="8" />\n <widget name="pt_status9" position="102,776" size="170,28" font="Regular;16" halign="left" valign="center" foregroundColor="#a0a0a8" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_days9" position="252,776" size="160,28" font="Regular;16" halign="right" valign="center" foregroundColor="#6edca0" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_track9" position="82,810" size="328,3" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/pt_track_328x3.png" alphatest="blend" transparent="1" zPosition="7" />\n <widget name="pt_fill9" position="82,810" size="328,3" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/pt_fill_green_328x3.png" alphatest="blend" transparent="1" zPosition="8" />\n <ePixmap position="456,684" size="380,148" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/pt_tile_380x148.png" alphatest="blend" zPosition="4" />\n <widget name="pt_num10" position="478,700" size="76,54" font="Regular;38" halign="left" valign="center" foregroundColor="#76767e" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_name10" position="556,702" size="262,34" font="Regular;22" halign="left" valign="center" foregroundColor="#cdcdd4" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_id10" position="556,738" size="262,24" font="Regular;16" halign="left" valign="center" foregroundColor="#a0a0a8" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_dot10" position="484,785" size="10,10" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/pt_dot_green.png" alphatest="blend" transparent="1" zPosition="8" />\n <widget name="pt_status10" position="502,776" size="170,28" font="Regular;16" halign="left" valign="center" foregroundColor="#a0a0a8" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_days10" position="652,776" size="160,28" font="Regular;16" halign="right" valign="center" foregroundColor="#6edca0" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_track10" position="482,810" size="328,3" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/pt_track_328x3.png" alphatest="blend" transparent="1" zPosition="7" />\n <widget name="pt_fill10" position="482,810" size="328,3" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/pt_fill_green_328x3.png" alphatest="blend" transparent="1" zPosition="8" />\n <ePixmap position="856,684" size="380,148" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/pt_tile_380x148.png" alphatest="blend" zPosition="4" />\n <widget name="pt_num11" position="878,700" size="76,54" font="Regular;38" halign="left" valign="center" foregroundColor="#76767e" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_name11" position="956,702" size="262,34" font="Regular;22" halign="left" valign="center" foregroundColor="#cdcdd4" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_id11" position="956,738" size="262,24" font="Regular;16" halign="left" valign="center" foregroundColor="#a0a0a8" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_dot11" position="884,785" size="10,10" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/pt_dot_green.png" alphatest="blend" transparent="1" zPosition="8" />\n <widget name="pt_status11" position="902,776" size="170,28" font="Regular;16" halign="left" valign="center" foregroundColor="#a0a0a8" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_days11" position="1052,776" size="160,28" font="Regular;16" halign="right" valign="center" foregroundColor="#6edca0" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_track11" position="882,810" size="328,3" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/pt_track_328x3.png" alphatest="blend" transparent="1" zPosition="7" />\n <widget name="pt_fill11" position="882,810" size="328,3" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/pt_fill_green_328x3.png" alphatest="blend" transparent="1" zPosition="8" />\n <ePixmap position="56,847" size="380,148" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/pt_tile_380x148.png" alphatest="blend" zPosition="4" />\n <widget name="pt_num12" position="78,863" size="76,54" font="Regular;38" halign="left" valign="center" foregroundColor="#76767e" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_name12" position="156,865" size="262,34" font="Regular;22" halign="left" valign="center" foregroundColor="#cdcdd4" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_id12" position="156,901" size="262,24" font="Regular;16" halign="left" valign="center" foregroundColor="#a0a0a8" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_dot12" position="84,948" size="10,10" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/pt_dot_green.png" alphatest="blend" transparent="1" zPosition="8" />\n <widget name="pt_status12" position="102,939" size="170,28" font="Regular;16" halign="left" valign="center" foregroundColor="#a0a0a8" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_days12" position="252,939" size="160,28" font="Regular;16" halign="right" valign="center" foregroundColor="#6edca0" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_track12" position="82,973" size="328,3" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/pt_track_328x3.png" alphatest="blend" transparent="1" zPosition="7" />\n <widget name="pt_fill12" position="82,973" size="328,3" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/pt_fill_green_328x3.png" alphatest="blend" transparent="1" zPosition="8" />\n <ePixmap position="456,847" size="380,148" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/pt_tile_380x148.png" alphatest="blend" zPosition="4" />\n <widget name="pt_num13" position="478,863" size="76,54" font="Regular;38" halign="left" valign="center" foregroundColor="#76767e" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_name13" position="556,865" size="262,34" font="Regular;22" halign="left" valign="center" foregroundColor="#cdcdd4" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_id13" position="556,901" size="262,24" font="Regular;16" halign="left" valign="center" foregroundColor="#a0a0a8" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_dot13" position="484,948" size="10,10" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/pt_dot_green.png" alphatest="blend" transparent="1" zPosition="8" />\n <widget name="pt_status13" position="502,939" size="170,28" font="Regular;16" halign="left" valign="center" foregroundColor="#a0a0a8" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_days13" position="652,939" size="160,28" font="Regular;16" halign="right" valign="center" foregroundColor="#6edca0" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_track13" position="482,973" size="328,3" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/pt_track_328x3.png" alphatest="blend" transparent="1" zPosition="7" />\n <widget name="pt_fill13" position="482,973" size="328,3" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/pt_fill_green_328x3.png" alphatest="blend" transparent="1" zPosition="8" />\n <ePixmap position="856,847" size="380,148" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/pt_tile_380x148.png" alphatest="blend" zPosition="4" />\n <widget name="pt_num14" position="878,863" size="76,54" font="Regular;38" halign="left" valign="center" foregroundColor="#76767e" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_name14" position="956,865" size="262,34" font="Regular;22" halign="left" valign="center" foregroundColor="#cdcdd4" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_id14" position="956,901" size="262,24" font="Regular;16" halign="left" valign="center" foregroundColor="#a0a0a8" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_dot14" position="884,948" size="10,10" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/pt_dot_green.png" alphatest="blend" transparent="1" zPosition="8" />\n <widget name="pt_status14" position="902,939" size="170,28" font="Regular;16" halign="left" valign="center" foregroundColor="#a0a0a8" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_days14" position="1052,939" size="160,28" font="Regular;16" halign="right" valign="center" foregroundColor="#6edca0" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_track14" position="882,973" size="328,3" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/pt_track_328x3.png" alphatest="blend" transparent="1" zPosition="7" />\n <widget name="pt_fill14" position="882,973" size="328,3" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/pt_fill_green_328x3.png" alphatest="blend" transparent="1" zPosition="8" />\n <widget name="pt_sel" position="56,195" size="380,148" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/pt_tile_sel_380x148.png" alphatest="blend" transparent="1" zPosition="5" />\n <ePixmap position="1316,646" size="560,350" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/pt_card_560x350.png" alphatest="blend" zPosition="4" />\n <widget name="pt_card_name" position="1346,666" size="300,44" font="Regular;28" halign="left" valign="center" foregroundColor="#ffffff" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_card_dot" position="1348,723" size="10,10" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/pt_dot_green.png" alphatest="blend" transparent="1" zPosition="8" />\n <widget name="pt_card_status" position="1366,712" size="480,30" font="Regular;18" halign="left" valign="center" foregroundColor="#a0a0a8" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_card_lab0" position="1346,758" size="190,32" font="Regular;19" halign="left" valign="center" foregroundColor="#a0a0a8" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_card_val0" position="1536,758" size="310,32" font="Regular;19" halign="right" valign="center" foregroundColor="#ffffff" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_card_lab1" position="1346,800" size="190,32" font="Regular;19" halign="left" valign="center" foregroundColor="#a0a0a8" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_card_val1" position="1536,800" size="310,32" font="Regular;19" halign="right" valign="center" foregroundColor="#ffffff" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_card_lab2" position="1346,842" size="190,32" font="Regular;19" halign="left" valign="center" foregroundColor="#a0a0a8" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_card_val2" position="1536,842" size="310,32" font="Regular;19" halign="right" valign="center" foregroundColor="#ffffff" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_card_exp" position="1346,896" size="330,32" font="Regular;19" halign="left" valign="center" foregroundColor="#a0a0a8" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_card_days" position="1676,896" size="170,32" font="Regular;19" halign="right" valign="center" foregroundColor="#e6be64" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="pt_card_track" position="1346,940" size="500,4" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/pt_track_500x4.png" alphatest="blend" transparent="1" zPosition="7" />\n <widget name="pt_card_fill" position="1346,940" size="500,4" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/pt_fill_green_500x4.png" alphatest="blend" transparent="1" zPosition="8" />\n <widget name="check_progress" position="1410,1012" size="436,40" font="Regular;20" halign="right" valign="center" foregroundColor="#a0d0b8" transparent="1" zPosition="26" shadowColor="#000000" shadowOffset="1,1" noWrap="1" />\n <widget name="status" position="0,0" size="1,1" font="Regular;1" foregroundColor="#d8e7ef" transparent="1" zPosition="1" />\n <widget name="footer_connection" position="0,0" size="1,1" font="Regular;1" foregroundColor="#39ff88" transparent="1" zPosition="1" />\n<widget name="check_notice_panel" position="1010,790" size="390,190" alphatest="blend" scale="1" transparent="1" zPosition="20" />\n <widget name="check_notice_title" position="1030,807" size="350,36" font="Regular;25" halign="center" valign="center" foregroundColor="#ffffff" transparent="1" zPosition="21" shadowColor="#000000" shadowOffset="1,1" />\n <widget name="check_notice_message" position="1030,850" size="350,60" font="Regular;19" halign="center" valign="center" foregroundColor="#f4f8fb" transparent="1" zPosition="21" noWrap="0" shadowColor="#000000" shadowOffset="1,1" />\n <widget name="check_notice_dash" position="1112,923" size="56,42" alphatest="blend" scale="1" transparent="1" zPosition="22" />\n <widget name="check_notice_ok" position="1170,923" size="126,42" font="Regular;20" halign="left" valign="center" foregroundColor="#ffffff" transparent="1" zPosition="23" noWrap="1" shadowColor="#000000" shadowOffset="1,1" />\n<ePixmap position="40,1000" size="1840,64" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/grid_bottom_bar_1840x64.png" alphatest="blend" zPosition="24" /><widget name="portal_page" position="66,1012" size="520,40" font="Regular;20" halign="left" valign="center" foregroundColor="#f0ece2" transparent="1" zPosition="26" noWrap="1" shadowColor="#000000" shadowOffset="1,1" /><widget name="red" position="644,1011" size="170,42" font="Regular;20" halign="left" valign="center" foregroundColor="#ffffff" transparent="1" zPosition="26" noWrap="1" shadowColor="#000000" shadowOffset="1,1" /><widget name="green" position="870,1011" size="170,42" font="Regular;20" halign="left" valign="center" foregroundColor="#ffffff" transparent="1" zPosition="26" noWrap="1" shadowColor="#000000" shadowOffset="1,1" /><widget name="yellow" position="1096,1011" size="170,42" font="Regular;20" halign="left" valign="center" foregroundColor="#ffffff" transparent="1" zPosition="26" noWrap="1" shadowColor="#000000" shadowOffset="1,1" /><widget name="blue" position="1322,1011" size="170,42" font="Regular;20" halign="left" valign="center" foregroundColor="#ffffff" transparent="1" zPosition="26" noWrap="1" shadowColor="#000000" shadowOffset="1,1" /><ePixmap position="586,1011" size="56,42" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/player_keyline_red_dash_56x42.png" alphatest="blend" zPosition="25" /><ePixmap position="812,1011" size="56,42" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/player_keyline_green_dash_56x42.png" alphatest="blend" zPosition="25" /><ePixmap position="1038,1011" size="56,42" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/player_keyline_yellow_dash_56x42.png" alphatest="blend" zPosition="25" /><ePixmap position="1264,1011" size="56,42" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/player_keyline_blue_dash_56x42.png" alphatest="blend" zPosition="25" /><widget name="pt_card_connections_dot" position="1730,684" size="10,10" alphatest="blend" transparent="1" zPosition="8" /><widget name="pt_card_connections" position="1686,666" size="160,44" font="Regular;20" halign="right" valign="center" foregroundColor="#ffffff" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1" noWrap="1" /></screen>'


# Split: related method groups live in ui_pmgr_mixin_*.py modules. They are imported here, after every module-level helper above exists,
# and listed BEFORE the other bases so they override them exactly like the methods that used to sit in this class body.
from .ui_pmgr_mixin_layout import PortalManagerLayoutMixin
from .ui_pmgr_mixin_actions import PortalManagerActionsMixin
from .ui_pmgr_mixin_keys import PortalManagerKeysMixin
import sys as _split_sys
_MIXIN_MODULES = tuple(_split_sys.modules[_m.__module__] for _m in (PortalManagerLayoutMixin, PortalManagerActionsMixin, PortalManagerKeysMixin,))


class PortalManagerPremiumScreen(
    PortalManagerLayoutMixin,
    PortalManagerActionsMixin,
    PortalManagerKeysMixin,
    Screen,
    AsyncScreenMixin,
):
    """Premium Portal Manager using the approved Settings row grammar.

    The manager exposes only non-duplicated portal utilities.  Destructive
    delete/disable actions remain on the main Portal List color keys, while the
    manager's multi-select flow is dedicated to moving portals.
    """
    skin = PORTAL_MANAGER_PREMIUM_SKIN
    ROW_W = 440   # R5.167: Settings group-rail geometry
    ROW_H = 100

    _ACTIONS = (
        # R5.211: the two free libraries are first-class Portal Manager entries.
        # Keep them first and adjacent so their positions never depend on the
        # selected portal type or on optional actions being filtered out.
        ("Free Portal", "free_portal", "Open the Free Portal library", "settings_icons_40/web_access.png"),
        ("Free Xtream", "free_xtream", "Open the Free Xtream library", "settings_icons_40/channel_list.png"),
        ("Backup & Restore", "backup_restore", "Backup or restore all portals, settings and user state", "settings_icons_40/backup.png"),
        ("Re-enable disabled portal", "enable_disabled", "Restore a disabled portal", "settings_icons_40/recovery.png"),
        ("Rename portal", "rename", "Rename the selected portal", "settings_icons_40/advanced.png"),
        ("Edit URL / MAC", "edit", "Edit portal address or MAC", "settings_icons_40/web_access.png"),
        ("MAG device profile", "device_profile", "Choose the MAG device profile", "settings_icons_40/playback.png"),
        ("Export Live bouquet + EPG", "export_bouquet", "Create Live bouquet and EPG source", "settings_icons_40/epg.png"),
        ("Remove exported bouquet + EPG", "unexport_bouquet", "Remove the exported Live integration", "settings_icons_40/clean.png"),
        ("Duplicate with another MAC", "duplicate", "Clone this portal with another MAC", "settings_icons_40/backup.png"),
        ("Move portals", "move_portals", "Select one or more portals, then press MENU to move them", "settings_icons_40/auto_switch.png"),
        ("Clear portal data", "purge_data", "Clear plugin-owned data but keep portal", "settings_icons_40/cache.png"),
    )

    def __init__(self, session, parent, initial_action=None):
        us_func(Screen.__init__)(self, session)
        self.parent = parent
        self._async_init()
        self.onClose.append(self._stop_async)
        self._backup_busy=False
        self._mode = "actions"
        self._visual_index = -1
        self._rebuilding = False
        self._row_asset = asset("fixed_master_r63/utility_row.png")
        self._row_selected_asset = asset("fixed_master_r63/utility_row_selected.png")
        self._value_color = int("74d8ff", 16)
        try:
            _fixed=fixed_settings_rows() or {}
            _n=str(_fixed.get("normal") or "");_s=str(_fixed.get("selected") or "")
            if _n and os.path.isfile(_n):self._row_asset=_n
            if _s and os.path.isfile(_s):self._row_selected_asset=_s
            self._value_color=int(_fixed.get("value_color") or fixed_value_color(self._value_color))
        except Exception as exc:optional_failure("ui.portal_manager_fixed_init",exc)
        self._multi_profiles = []
        self._multi_selected = set()
        self._visible_actions = []
        self._last_summary = ""
        self["ambient_bg"] = Pixmap()
        self["hero_backdrop"] = Pixmap()
        self["list"] = SettingsGlassList([], width=self.ROW_W, item_height=self.ROW_H)
        self["status"] = Label("")
        self["context_panel"] = Pixmap()
        self["context_message"] = Label("")
        self["context_title"] = Label("")
        self["context_subtitle"] = Label("")
        self["context_list"] = IconMenuList([], width=650, item_height=80, icon_size=0, primary_font=22, secondary_font=16, row_style="settings_dialog")
        self._context_active = False
        self._context_mode = "choice"
        self._context_callback = None
        self._context_choices = []
        self._context_last_idx = 0
        self._context_row_asset = None
        self._context_selected_asset = None
        self["list"].onSelectionChanged.append(self._selection_changed)
        actions = {
            "cancel": self._cancel, "ok": self._ok, "menu": self._menu,
            "up": lambda: self._move("up"), "down": lambda: self._move("down"),
            "left": lambda: self._move("left"), "right": lambda: self._move("right"),
            "red": self._red, "green": self._green, "yellow": self._yellow,
            "1": lambda: self._number(1), "2": lambda: self._number(2), "3": lambda: self._number(3),
            "4": lambda: self._number(4), "5": lambda: self._number(5), "6": lambda: self._number(6),
            "7": lambda: self._number(7), "8": lambda: self._number(8), "9": lambda: self._number(9),
            "0": lambda: self._number(0),
        }
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "MenuActions","UltraStalkerMenuActions", "NumberActions", "DirectionActions"], actions, -1)
        self.onLayoutFinish.append(self._layout_ready)
        if initial_action=="backup_restore":self.onLayoutFinish.append(self._backup_menu)
        self.onClose.append(self._cleanup)
        self._context_hide_widgets()
        self._render_actions(0)

    def _ok(self):
        if self._context_active:
            self._context_accept();return
        if self._backup_busy:return
        idx = self._safe_index()
        if self._mode == "actions":
            entries = list(self._visible_actions)
            if not (0 <= idx < len(entries)):
                return
            title, action, _desc, _icon = entries[idx]
            profile=self._selected_portal()
            if action == "backup_restore":
                self._backup_menu()
                return
            if action == "enable_disabled":
                disabled=list(load_disabled_profiles())
                if not disabled:
                    show_notice(self.session,_('No disabled portals.'),timeout=5,title=_('Re-enable portal'), owner=self);return
                rows=[(((row.get("name") or row.get("portal") or "Portal")+"  •  "+str(row.get("mac") or "")),row) for row in disabled]
                self._context_open_choice(self._enable_disabled_selected,_('Re-enable portal'),rows,0,_('Choose a disabled portal to enable'))
                return
            if action == "device_profile":
                if not profile:return
                self.parent._editing_profile=profile
                current=str(profile.get("device_profile") or "auto").lower();choices=[(_("Auto"),"auto"),("MAG250","mag250"),("MAG254","mag254"),("MAG256","mag256")];selection=next((i for i,x in enumerate(choices) if x[1]==current),0)
                self._context_open_choice(self._device_profile_selected,_('MAG device profile'),choices,selection,_('Choose the device profile for this portal'))
                return
            if action == "rename":
                if not profile:return
                self.parent._editing_profile=profile
                self.session.openWithCallback(self._rename_finished,SettingsGlassInputScreen,title=_('Portal name'),text=str(profile.get('name') or _('Portal Server')),maxSize=80)
                return
            if action == "edit":
                if not profile:return
                self.parent._editing_profile=profile
                self.session.openWithCallback(self._edit_url_finished,SettingsGlassInputScreen,title=_('Portal / M3U URL'),text=str(profile.get('portal') or 'https://'),maxSize=250)
                return
            if action == "duplicate":
                if not profile:return
                self.parent._duplicating_profile=profile
                self.session.openWithCallback(self._duplicate_finished,SettingsGlassInputScreen,title=_('MAC for duplicate'),text='00:1A:79:',maxSize=17)
                return
            if action == "purge_data":
                if not profile:return
                self.parent._purge_profile=profile
                self._context_open_choice(self._purge_selected,_('Clear portal data'),[(_('Yes'),True),(_('No'),False)],1,_('Clear plugin-owned data for this portal?  Favorites, History, Resume, exported bouquet/EPG and related timers are removed; the portal profile is kept.'),show_text=True)
                return
            if action == "move_portals":
                # One clean entry point: choose Move portals, select the targets,
                # then MENU starts placement directly. No second Move row.
                anchor = min(self._multi_selected) if self._multi_selected else 0
                self._render_multi(anchor); return
            if action == "free_portal":
                self.session.open(FreeLibraryShellScreen, "portal"); return
            if action == "free_xtream":
                self.session.open(FreeLibraryShellScreen, "xtream"); return
            self.close((title, action))
            return
        if self._mode == "multi":
            if not (0 <= idx < len(self._multi_profiles)):
                return
            if idx in self._multi_selected: self._multi_selected.remove(idx)
            else: self._multi_selected.add(idx)
            self._render_multi_row(idx)
            # Multi-select should stay fast: after OK toggles the current portal,
            # move focus straight to the next portal so several targets can be
            # marked with consecutive OK presses.  Keep focus on the last row.
            if idx + 1 < len(self._multi_profiles):
                try:
                    self["list"].moveToIndex(idx + 1)
                except Exception as exc:
                    optional_failure("ui.portal_manager_multi_select_advance", exc)
            self._update_status()
            return


class FreeLibraryShellScreen(Screen):
    """Free Portal / Free Xtream using V7 catalog behavior on the new UI.

    R5.212 preserves the proven V7 data path: passive bundled catalogs, the
    dedicated fast Xtream parser + mtime/size RAM cache, no network validation
    on open/import, and catalog parsing only after applySkin() has completed.
    Only the presentation layer is new: R5.211 Settings cards/background and
    the current bottom-right dash action footer.
    """
    skin = compact_footer_skin(FREE_LIBRARY_SHELL_SKIN)
    ROW_W = PortalManagerPremiumScreen.ROW_W
    ROW_H = PortalManagerPremiumScreen.ROW_H
    PAGE_SIZE = 10

    def __init__(self, session, library_kind="portal"):
        us_func(Screen.__init__)(self, session)
        self.library_kind = "xtream" if str(library_kind or "").lower() == "xtream" else "portal"
        self._visual_index = -1
        self._rebuilding = False
        self._page = 0
        self._library_items = []
        self._library_selected = set()
        self._library_loaded = False
        self._preview_index = None
        self._preview_profile = None
        self._notice = ""
        self._row_asset = asset("fixed_master_r63/utility_row.png")
        self._row_selected_asset = asset("fixed_master_r63/utility_row_selected.png")
        self._value_color = int("74d8ff", 16)
        try:
            chrome = fixed_settings_rows() or {}
            normal = str(chrome.get("normal") or "")
            selected = str(chrome.get("selected") or "")
            if normal and os.path.isfile(normal): self._row_asset = normal
            if selected and os.path.isfile(selected): self._row_selected_asset = selected
            self._value_color = int(chrome.get("value_color") or fixed_value_color(self._value_color))
        except Exception as exc:
            optional_failure("ui.free_library_fixed_init", exc)

        self._compact_footer_anchor = (1912, 1079)
        self._compact_footer_changed = self._free_summary_layout
        self["free_summary_card"] = Pixmap()
        for color in ("red", "green", "yellow", "blue"):
            self["free_" + color + "_dash"] = Pixmap()
        self["ambient_bg"] = Pixmap()
        self["hero_backdrop"] = Pixmap()
        self["list"] = SettingsGlassList([], width=self.ROW_W, item_height=self.ROW_H)
        self["status"] = Label("")
        self["context_title"] = Label("")
        self["context_subtitle"] = Label("")
        self["context_list"] = IconMenuList([], width=650, item_height=80, icon_size=0,
                                            primary_font=22, secondary_font=16,
                                            row_style="settings_dialog")
        self["red"] = Label(_("Clear"))
        self["green"] = Label(_("Import"))
        self["yellow"] = Label(_("Select All"))
        self["blue"] = Label(_("Preview"))
        self["list"].onSelectionChanged.append(self._selection_changed)
        self["actions"] = ActionMap(
            ["OkCancelActions", "DirectionActions", "ColorActions"],
            {
                "cancel": self.close,
                "ok": self._toggle_selected,
                "red": self._clear_selected,
                "green": self._import_selected,
                "yellow": self._select_all,
                "blue": self._preview,
                "up": lambda: self._move("up"),
                "down": lambda: self._move("down"),
                "left": lambda: self._move("left"),
                "right": lambda: self._move("right"),
            }, -1)
        self.onLayoutFinish.append(self._layout_ready)
        install_compact_footer(self)
        self.onShown.append(self._shown)
        self.onClose.append(self._cleanup)
        # Keep applySkin cheap, exactly like the proven V7 behavior.  The real
        # catalog is not parsed until onShown() after the GUI exists.
        self._render(0)

    def _cleanup(self):
        try:
            callbacks = self["list"].onSelectionChanged
            if self._selection_changed in callbacks:
                callbacks.remove(self._selection_changed)
        except Exception as exc:
            optional_failure("ui.free_library_cleanup", exc)

    def _title(self):
        return _("Free Xtream") if self.library_kind == "xtream" else _("Free Portal")

    def _layout_ready(self):
        try: cleanup_legacy_application_outputs()
        except Exception as exc: optional_failure("ui.free_library_cleanup_legacy", exc)
        prepared = _portal_category_backdrop()
        try:
            self["ambient_bg"].hide()
            if prepared and os.path.isfile(prepared):
                self["hero_backdrop"].instance.setPixmapFromFile(prepared)
                self["hero_backdrop"].show()
            else:
                self["hero_backdrop"].hide()
        except Exception as exc:
            optional_failure("ui.free_library_backdrop", exc)
        try:
            chrome = fixed_settings_rows() or {}
            normal = str(chrome.get("normal") or "")
            selected = str(chrome.get("selected") or "")
            if normal and os.path.isfile(normal): self._row_asset = normal
            if selected and os.path.isfile(selected): self._row_selected_asset = selected
            self._value_color = int(chrome.get("value_color") or fixed_value_color(self._value_color))
        except Exception as exc:
            optional_failure("ui.free_library_material", exc)
        try:
            if self["list"].instance is not None:
                self["list"].instance.setSelectionEnable(0)
                self["list"].instance.setTransparent(1)
                self["list"].instance.setScrollbarMode(2)
        except Exception as exc:
            optional_failure("ui.free_library_list_native", exc)
        try:
            self["context_list"].hide()
            self["context_title"].show()
            self["context_subtitle"].show()
        except Exception as exc:
            optional_failure("ui.free_library_context", exc)
        self._free_footer_layout()
        self._render(self._safe_index())

    def _shown(self):
        if self._library_loaded:
            return
        try:
            # Exact V7 runtime path: passive local parse only, no network work.
            self._library_items = list(load_server_library(self.library_kind))
            self._library_loaded = True
            self._page = 0
            self._visual_index = -1
            self._notice = ""
            self._render(0)
        except Exception as exc:
            self._library_loaded = True
            self._library_items = []
            optional_failure("ui.free_library_open", exc)
            self._notice = _("Open failed: %s") % exc
            self._render(0)

    def _safe_index(self):
        try: return int(self["list"].getSelectedIndex() or 0)
        except Exception: return 0

    def _settings_icon(self):
        name = "channel_list.png" if self.library_kind == "xtream" else "web_access.png"
        try:
            compact = asset("settings_icons_40/" + name)
            if compact and os.path.isfile(compact): return compact
        except Exception as exc:
            optional_failure("ui.free_library_icon", exc)
        return asset("home_settings_line.png")

    def _page_count(self):
        total = len(self._library_items)
        return ((total + self.PAGE_SIZE - 1) // self.PAGE_SIZE) if total else 0

    def _page_entries(self):
        pages = self._page_count()
        if pages <= 0:
            self._page = 0
            return []
        self._page = max(0, min(int(self._page or 0), pages - 1))
        start = self._page * self.PAGE_SIZE
        end = min(len(self._library_items), start + self.PAGE_SIZE)
        return [(i, self._library_items[i]) for i in range(start, end)]

    def _profile_title(self, profile, absolute):
        name = str((profile or {}).get("name") or "").strip()
        if name:
            return name[:80]
        raw = str((profile or {}).get("portal") or "")
        try:
            parsed = urllib.parse.urlsplit(raw)
            host = parsed.hostname or parsed.netloc
            if host:
                return str(host)[:80]
        except Exception:
            pass
        return ((_("Xtream Server %d") if self.library_kind == "xtream" else _("Portal Server %d")) % (absolute + 1))

    def _entry_rows(self):
        visible = self._page_entries()
        if not visible:
            label = _("Loading library") if not self._library_loaded else _("No results")
            value = _("Please wait") if not self._library_loaded else _("Ready")
            return [(None, {}, label, value)]
        rows = []
        for absolute, profile in visible:
            state = _("SELECTED") if absolute in self._library_selected else _("AVAILABLE")
            rows.append((absolute, profile, self._profile_title(profile, absolute), state))
        return rows

    def _row(self, local_index, selected_local, entries):
        absolute, profile, title, value = entries[local_index]
        chosen = absolute is not None and absolute in self._library_selected
        meta = {
            "level": "groups", "kind": "group", "selected": bool(local_index == selected_local),
            "value": str(value or ""), "count": str(value or ""),
            "row_asset": self._row_asset,
            "row_selected_asset": self._row_selected_asset,
            # Selected Free-library rows use an unmistakable bright green state
            # label. AVAILABLE keeps the normal adaptive value colour.
            # Free-library identity/status colours are explicit here so the
            # Settings glass renderer does not dim unfocused selected rows.
            # Names stay pure white; SELECTED is vivid green; AVAILABLE stays quiet.
            "title_color": 0xFFFFFF,
            "value_color": (0x39FF88 if chosen else 0x8E9AA3),
            "free_library_state": True,
            # Absolute source numbering, not page-local numbering.  SettingsGlassList
            # owns fit-safe 2/3/4-digit rendering so 1000+ is never clipped.
            "source_number": ((absolute + 1) if absolute is not None else None),
            "utility_accent_strong": True,
        }
        return (str(title), self._settings_icon(), profile if absolute is not None else None, meta)

    def _render(self, selected_local=0):
        entries = self._entry_rows()
        selected_local = max(0, min(int(selected_local or 0), max(0, len(entries) - 1)))
        rows = [self._row(i, selected_local, entries) for i in range(len(entries))]
        self._rebuilding = True
        try:
            self["list"].set_icon_rows(rows)
            if rows: self["list"].moveToIndex(selected_local)
        finally:
            self._rebuilding = False
        self._visual_index = selected_local
        self._update_chrome()

    def _current_absolute(self):
        if not self._library_items:
            return None
        local = self._safe_index()
        absolute = self._page * self.PAGE_SIZE + local
        if 0 <= absolute < len(self._library_items):
            return absolute
        return max(0, len(self._library_items) - 1)

    def _selection_changed(self):
        if self._rebuilding: return
        idx = self._safe_index()
        if idx == self._visual_index:
            self._update_chrome(); return
        old = self._visual_index
        self._visual_index = idx
        entries = self._entry_rows()
        for j in set((old, idx)):
            if 0 <= j < len(entries):
                try: self["list"].update_icon_row(j, self._row(j, idx, entries))
                except Exception as exc: optional_failure("ui.free_library_row_update", exc)
        self._notice = ""
        self._update_chrome()

    def _move_to_absolute(self, target):
        total = len(self._library_items)
        if total <= 0:
            return
        target = max(0, min(int(target), total - 1))
        page = target // self.PAGE_SIZE
        local = target % self.PAGE_SIZE
        if page != self._page:
            self._page = page
            self._render(local)
        else:
            try: self["list"].moveToIndex(local)
            except Exception as exc: optional_failure("ui.free_library_move", exc)
            self._selection_changed()

    def _move(self, direction):
        total = len(self._library_items)
        if total <= 0:
            return
        current = self._current_absolute()
        if current is None: current = 0
        if direction == "up":
            self._move_to_absolute((current - 1) % total)
            return
        if direction == "down":
            self._move_to_absolute((current + 1) % total)
            return
        row = current % self.PAGE_SIZE
        pages = max(1, self._page_count())
        current_page = current // self.PAGE_SIZE
        if direction == "left":
            if current_page <= 0:
                target = 0
            else:
                target = min(total - 1, (current_page - 1) * self.PAGE_SIZE + row)
            self._move_to_absolute(target)
            return
        if direction == "right":
            if current_page >= pages - 1:
                target = total - 1
            else:
                target = min(total - 1, (current_page + 1) * self.PAGE_SIZE + row)
            self._move_to_absolute(target)

    def _toggle_selected(self):
        idx = self._current_absolute()
        if idx is None:
            return
        if idx in self._library_selected:
            self._library_selected.remove(idx)
        else:
            self._library_selected.add(idx)
        self._notice = ""
        # Preserve the V7 fast multi-select ergonomics: OK toggles and advances.
        if idx + 1 < len(self._library_items):
            self._move_to_absolute(idx + 1)
        else:
            self._render(self._safe_index())

    def _clear_selected(self):
        if not self._library_selected:
            return
        us_clear(self._library_selected)
        self._notice = _("Selection cleared")
        self._render(self._safe_index())

    def _select_all(self):
        self._library_selected = set(range(len(self._library_items)))
        self._notice = _("All sources selected")
        self._render(self._safe_index())

    def _import_selected(self):
        if not self._library_selected:
            self._notice = _("Nothing selected")
            self._update_chrome()
            return
        chosen = [self._library_items[i] for i in sorted(self._library_selected) if 0 <= i < len(self._library_items)]
        try:
            result = import_server_library_profiles(chosen) or {}
        except Exception as exc:
            optional_failure("ui.free_library_import", exc)
            self._notice = _("Import failed")
            self._update_chrome()
            return
        added = int(result.get("added", 0) or 0)
        dup = int(result.get("duplicates", 0) or 0)
        us_clear(self._library_selected)
        self._notice = _("%d added • %d already existed") % (added, dup)
        self._render(self._safe_index())

    def _open_preview_profile(self, profile):
        if not isinstance(profile, dict):
            return
        preview = dict(profile)
        preview["source"] = "library_preview"
        preview["_library_preview"] = True
        try:
            _validate_profile_client(preview)
        except Exception as exc:
            self._notice = _("Preview unavailable: %s") % exc
            self._update_chrome()
            return
        try:
            from .ui_screens_splash import HomeWarmupSplashScreen
            self.session.openWithCallback(self._preview_closed, HomeWarmupSplashScreen, preview, PortalHomeScreen)
        except Exception as exc:
            optional_failure("ui.free_library_preview_open", exc)
            self._notice = _("Preview failed: %s") % exc
            self._update_chrome()

    def _preview_http_confirmed(self, accepted):
        profile = self._preview_profile
        if not accepted or not isinstance(profile, dict):
            self._preview_profile = None
            return
        preview = dict(profile)
        preview["explicit_http_accepted"] = True
        self._preview_profile = None
        self._open_preview_profile(preview)

    def _preview(self):
        idx = self._current_absolute()
        if idx is None or not (0 <= idx < len(self._library_items)):
            return
        self._preview_index = idx
        profile = dict(self._library_items[idx])
        self._preview_profile = profile
        try:
            if requires_http_consent(profile.get("portal")) and not bool(profile.get("explicit_http_accepted", False)):
                self.session.openWithCallback(
                    self._preview_http_confirmed, MessageBox,
                    http_warning_for(profile.get("portal")), MessageBox.TYPE_YESNO)
                return
        except Exception as exc:
            optional_failure("ui.free_library_preview_consent", exc)
        self._preview_profile = None
        self._open_preview_profile(profile)

    def _preview_closed(self, result=None):
        try:
            idx = self._preview_index
            self._preview_index = None
            if self._library_items:
                if idx is None: idx = self._current_absolute() or 0
                self._move_to_absolute(max(0, min(int(idx), len(self._library_items) - 1)))
            else:
                self._render(0)
        except Exception as exc:
            optional_failure("ui.free_library_preview_return", exc)

    def _free_footer_layout(self):
        """Pack actual caption widths against the bottom-right screen edge."""
        try:
            desktop = getDesktop(0).size()
            sx, sy = desktop.width() / 1920.0, desktop.height() / 1080.0
            labels = tuple(self[c].instance for c in ("red", "green", "yellow", "blue"))
            dashes = tuple(self["free_"+c+"_dash"].instance for c in ("red", "green", "yellow", "blue"))
            if any(inst is None for inst in labels+dashes):
                return
            signature = (desktop.width(), desktop.height(), tuple(id(inst) for inst in labels+dashes),
                         tuple(self[c].getText() for c in ("red", "green", "yellow", "blue")))
            if signature == getattr(self, "_free_footer_signature", None):
                refresh = getattr(self, "_compact_footer_refresh", None)
                if callable(refresh): refresh()
                return
            x = int(round(1900 * sx))
            y = int(round(1026 * sy))
            for color in reversed(("red", "green", "yellow", "blue")):
                label = self[color].instance
                dash = self["free_" + color + "_dash"].instance
                if label is None or dash is None:
                    return
                label.setFont(gFont("Regular", int(round(20 * sy))))
                width = min(int(round(180 * sx)), max(int(round(54 * sx)), label.calculateSize().width()))
                x -= width
                label.move(ePoint(x, y)); label.resize(eSize(width, int(round(42 * sy))))
                dash.move(ePoint(x - int(round(58 * sx)), y))
                dash.resize(eSize(int(round(56 * sx)), int(round(42 * sy))))
                x -= int(round(80 * sx))
            self._free_footer_signature = signature
            refresh = getattr(self, "_compact_footer_refresh", None)
            if callable(refresh):
                refresh()
        except Exception as exc:
            optional_failure("ui.free_footer_layout", exc)

    def _free_summary_layout(self, bounds):
        """The seamless summary is centered over the actual action bar."""
        try:
            left, top, right, _height = bounds
            desktop = getDesktop(0).size()
            sx, sy = desktop.width() / 1920.0, desktop.height() / 1080.0
            title, subtitle = self["context_title"].instance, self["context_subtitle"].instance
            card = self["free_summary_card"].instance
            if title is None or subtitle is None or card is None:
                return
            signature = (bounds, desktop.width(), desktop.height(), id(card), id(title), id(subtitle),
                         self["context_title"].getText(), self["context_subtitle"].getText())
            if signature == getattr(self, "_free_summary_signature", None):
                return
            width = min(int(round(420 * sx)), max(int(round(300 * sx)), title.calculateSize().width(), subtitle.calculateSize().width()) + int(round(36 * sx)))
            card_h = max(1, int(round(170 * sy)))
            x = int(round((left + right - width) / 2.0))
            y = top - int(round(182 * sy))
            try:
                from .ui_icon_menu import _us_fit_png
                fpath = _us_fit_png(_asset_path("free_summary_seamless_420x132.png"), width, card_h, True)
                if fpath and os.path.isfile(fpath):
                    card.setPixmapFromFile(fpath)
            except Exception as exc:
                optional_failure("ui.free_summary_card_fit", exc)
            card.move(ePoint(x, y)); card.resize(eSize(width, card_h))
            self["free_summary_card"].show()
            for inst, dy, h in ((title, 14, 42), (subtitle, 60, 84)):
                inst.move(ePoint(x + int(round(18 * sx)), y + int(round(dy * sy))))
                inst.resize(eSize(width - int(round(36 * sx)), int(round(h * sy))))
            self._free_summary_signature = signature
        except Exception as exc:
            optional_failure("ui.free_summary_layout", exc)

    def _update_chrome(self):
        title = self._title()
        total = len(self._library_items)
        pages = self._page_count()
        current_page = (self._page + 1) if pages else 0
        absolute = self._current_absolute()
        source_no = (absolute + 1) if absolute is not None else 0
        selected = len(self._library_selected)
        try:
            self["context_title"].setText(title)
            self["context_subtitle"].setText(
                (_("%d sources") % total) + "  •  " + (_("%d selected") % selected) + "\n" +
                (_("page %d/%d") % (current_page, pages)) +
                ("\n" + (_("source %d/%d") % (source_no, total)) if total else "")
            )
        except Exception as exc:
            optional_failure("ui.free_library_summary", exc)
        self._free_footer_layout()
        try:
            self["status"].setText(str(self._notice or ""))
        except Exception:
            pass


PT_TILES = 15


def _asset_path(name):
    try:
        return asset(name)
    except Exception:
        return os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets_fhd", name)

PT_COLS = 3
_PT_MONTHS = {m: i + 1 for i, m in enumerate(("jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"))}


def _pt_expiry_date(text):
    """Best-effort parse of the portal expiry string -> datetime.date or None."""
    import datetime
    raw = " ".join(str(text or "").split())
    if not raw:
        return None
    low = raw.lower()
    if any(w in low for w in ("unlimited", "no expiry", "never", "lifetime")):
        return None
    m = re.search(r"(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})", raw)
    try:
        if re.fullmatch(r"\d{9,11}", raw):
            # Xtream/Stalker panels sometimes report the expiry as a unix timestamp.
            stamp = int(raw)
            return datetime.date.fromtimestamp(stamp) if stamp > 0 else None
        if m:
            return datetime.date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
        m = re.search(r"(\d{1,2})[-/.](\d{1,2})[-/.](\d{4})", raw)
        if m:
            return datetime.date(int(m.group(3)), int(m.group(2)), int(m.group(1)))
        m = re.search(r"([A-Za-z]{3,})\.?\s+(\d{1,2}),?\s+(\d{4})", raw)
        if m and m.group(1)[:3].lower() in _PT_MONTHS:
            return datetime.date(int(m.group(3)), _PT_MONTHS[m.group(1)[:3].lower()], int(m.group(2)))
        m = re.search(r"(\d{1,2})\s+([A-Za-z]{3,})\.?,?\s+(\d{4})", raw)
        if m and m.group(2)[:3].lower() in _PT_MONTHS:
            return datetime.date(int(m.group(3)), _PT_MONTHS[m.group(2)[:3].lower()], int(m.group(1)))
    except Exception:
        return None
    return None


def _pt_days_left(text):
    import datetime
    d = _pt_expiry_date(text)
    if d is None:
        return None
    return (d - datetime.date.today()).days


def _pt_tone(days):
    if days is None:
        return "grey"
    if days > 60:
        return "green"
    if days > 14:
        return "amber"
    return "red"


_PT_TONE_HEX = {"green": "#6edca0", "amber": "#e6be64", "red": "#eb6e6e", "grey": "#a0a0a8"}
_PT_STATUS_TONE = {"ONLINE": "green", "SLOW": "amber", "OFFLINE": "red", "DISABLED": "red", "EXPIRED": "red", "BLOCKED": "red"}


# Split: related method groups live in ui_plist_mixin_*.py modules. They are imported here, after every module-level helper above exists,
# and listed BEFORE the other bases so they override them exactly like the methods that used to sit in this class body.
from .ui_plist_mixin_progress import PortalListProgressMixin
from .ui_plist_mixin_select import PortalListSelectMixin
from .ui_plist_mixin_tools import PortalListToolsMixin
from .ui_plist_mixin_edit import PortalListEditMixin
from .ui_plist_mixin_materials import PortalListMaterialsMixin
from .ui_plist_mixin_rows import PortalListRowsMixin
from .ui_plist_mixin_paint import PortalListPaintMixin
from .ui_plist_mixin_sources import PortalListSourcesMixin
from .ui_plist_mixin_check import PortalListCheckMixin
import sys as _split_sys
_MIXIN_MODULES = _MIXIN_MODULES + tuple(_split_sys.modules[_m.__module__] for _m in (PortalListProgressMixin, PortalListSelectMixin, PortalListToolsMixin, PortalListEditMixin, PortalListMaterialsMixin, PortalListRowsMixin, PortalListPaintMixin, PortalListSourcesMixin, PortalListCheckMixin,))


class PortalListScreen(
    PortalListProgressMixin,
    PortalListSelectMixin,
    PortalListToolsMixin,
    PortalListEditMixin,
    PortalListMaterialsMixin,
    PortalListRowsMixin,
    PortalListPaintMixin,
    PortalListSourcesMixin,
    PortalListCheckMixin,
    Screen,
    AsyncScreenMixin,
    ImageLoaderMixin,
    TransitionMixin,
):
    skin = PORTAL_SELECTION_SETTINGS_SKIN
    PORTAL_ROW_W = 620
    PORTAL_ROW_H = 80

    def __init__(self, session):
        _perf_t0 = time.monotonic()
        LOG.info("PERF25 portals init_enter mono_ms=%d", int(_perf_t0 * 1000))
        us_func(Screen.__init__)(self, session)
        self._async_init()
        self.onClose.append(self._stop_async)
        self.onClose.append(self._image_stop)
        _phase = time.monotonic()
        self.profiles = load_profiles()
        LOG.info("PERF25 portals profiles_loaded elapsed_ms=%d count=%d", int((time.monotonic() - _phase) * 1000), len(self.profiles or []))
        # A brand-new plugin session must start content grids from page 1.
        # Test69 Lean: navigation reset is session-RAM scoped by begin_plugin_launch().
        # Do NOT rewrite + fsync one state JSON per portal every time the plugin opens.
        # Persistent favorites/resume/home state remain untouched and Grid navigation
        # cannot leak across launches because its key includes current_plugin_launch().
        self._portal_old_service = _plugin_original_service_getter() if _plugin_service_captured_getter() else None
        try:self.session.nav.stopService()
        except Exception as exc:optional_failure("ui",exc)
        self.onClose.append(self._restore_background_service)
        initial_warning = _("Ready")
        self["status"] = Label(initial_warning)
        self["page_bg"] = Pixmap()
        self["ambient_bg"] = Pixmap()
        self["hero_backdrop"] = Pixmap()
        self["list"] = IconMenuList([], width=self.PORTAL_ROW_W, item_height=self.PORTAL_ROW_H, icon_size=40, primary_font=21, secondary_font=15, row_style="settings_episode")
        self["source_badges"] = IconMenuList([], width=430, item_height=self.PORTAL_ROW_H, icon_size=40, primary_font=21, secondary_font=15, row_style="settings_episode")
        self["portal_page"] = Label("")
        self["check_progress"] = Label("")
        self._portal_page_text = ""
        self._portal_footer_name = ""
        self._portal_footer_connection = ""
        self._portal_check_progress_text = ""
        self._portal_row_asset = asset("fixed_master_r63/utility_row.png")
        self._portal_row_selected_asset = asset("fixed_master_r63/utility_row_selected.png")
        self._portal_value_color = int("74d8ff", 16)
        # R64: bind the frozen application chrome before the first portal paint.
        try:
            _fixed=fixed_settings_rows() or {}
            _n=str(_fixed.get("normal") or "");_s=str(_fixed.get("selected") or "")
            if _n and os.path.isfile(_n):self._portal_row_asset=_n
            if _s and os.path.isfile(_s):self._portal_row_selected_asset=_s
            self._portal_value_color=int(_fixed.get("value_color") or fixed_value_color(self._portal_value_color))
        except Exception as exc:optional_failure("ui.portal_fixed_init",exc)
        self._portal_page_size = PT_TILES
        self._portal_page = 1
        self._portal_visual_index = 0
        self._portal_rebuilding = False
        self["red"] = Label(_("Delete portal"))
        self["green"] = Label(_("Move"))
        self["yellow"] = Label(_("Check All"))
        self["blue"] = Label(_("Disable"))
        self["footer_connection"] = Label("")
        self["check_notice_panel"] = Pixmap()
        self["check_notice_title"] = Label("")
        self["check_notice_message"] = Label("")
        self["check_notice_dash"] = Pixmap()
        self["check_notice_ok"] = Label(_("OK"))
        # R5.69 premium tile grid (3 x 5).  The legacy list above stays the
        # selection/data source of truth (off screen); tiles only mirror it.
        self["pt_title"] = Label(_("Select Portal"))
        self["pt_tab0"] = Label("")
        self["pt_tab1"] = Label("")
        self["pt_tab_line"] = Pixmap()
        self["pt_sel"] = Pixmap()
        for _k in range(PT_TILES):
            for _n in ("pt_num%d", "pt_name%d", "pt_id%d", "pt_status%d", "pt_days%d"):
                self[_n % _k] = Label("")
            for _n in ("pt_dot%d", "pt_track%d", "pt_fill%d"):
                self[_n % _k] = Pixmap()
        for _n in ("pt_card_name", "pt_card_status", "pt_card_exp", "pt_card_days", "pt_card_connections"):
            self[_n] = Label("")
        for _k in range(3):
            self["pt_card_lab%d" % _k] = Label("")
            self["pt_card_val%d" % _k] = Label("")
        for _n in ("pt_card_dot", "pt_card_track", "pt_card_fill", "pt_card_connections_dot"):
            self[_n] = Pixmap()
        self._pt_state = {}
        self._check_notice_visible = False
        for _notice_name in ("check_notice_panel", "check_notice_title", "check_notice_message", "check_notice_dash", "check_notice_ok"):
            try:self[_notice_name].hide()
            except Exception:pass
        # R181: onboarding is a disposable child screen. PortalList carries zero
        # onboarding Pixmaps/Labels while normal navigation is running.
        self._portal_select_mode = False
        self._portal_selected = set()
        self._onboarding_prompted_this_screen = False
        self._reorder_mode = False
        self._reorder_original_profiles = []
        # Bulk placement mode is entered from Portal Manager -> Select portals
        # -> MENU -> Move.  Network/account state is untouched; only the local
        # saved profile order changes when GREEN confirms the destination.
        self._bulk_move_mode = False
        self._bulk_move_profiles = []
        self._portal_progress_jobs = queue.Queue()
        self._portal_progress_timer = eTimer()
        self._portal_progress_conn = None
        try:
            self._portal_progress_conn = self._portal_progress_timer.timeout.connect(self._drain_portal_progress)
        except Exception:
            self._portal_progress_timer.callback.append(self._drain_portal_progress)
        self._portal_progress_active=False
        self.onClose.append(self._stop_portal_progress)
        self.onClose.append(self._stop_portal_ui_hooks)
        self._image_init("preview", (310, 245), {"portal": ""}, None)
        self.onLayoutFinish.append(self._layout_ready)
        try:self.onShown.append(self._portal_list_shown)
        except Exception as exc:optional_failure("ui",exc)
        self["list"].onSelectionChanged.append(self._selection_changed)
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "MenuActions","UltraStalkerMenuActions", "NumberActions", "InfoActions", "DirectionActions"], {
            "cancel": self._portal_cancel, "green": self._portal_green, "red": self._portal_red,
            "yellow": self._portal_yellow, "blue": self._portal_blue, "ok": self._portal_ok,
            "up": self._portal_up, "down": self._portal_down, "left": self._portal_prev_page, "right": self._portal_next_page,
            "menu": self._portal_menu, "info": self._portal_info,
        }, -1)
        self.refresh()
        LOG.info("PERF25 portals init_done elapsed_ms=%d", int((time.monotonic() - _perf_t0) * 1000))


        # R181 point 3: first-run setup is now an inline Settings-row list on Home.
        # PortalList must never open the old child popup.


    def _export_live_integration(self, profile):
        if self._busy:
            return
        self["status"].setText(_("Exporting full Live bouquet..."))
        cfg=load_settings()
        def work(handle):
            client=_client_from_profile(profile,cfg.get("timeout",10))
            try:
                channels=client.ordered_all("itv","*",1,max_pages=cfg.get("search_max_pages",250),max_items=25000,cancel_event=handle.cancel_event)
                if handle.cancelled(): return {}
                _stamp_cached_live_export_picons(profile, channels)
                return export_live_integration(profile,channels,cfg.get("service_type",4097))
            finally:
                client.close()
        def ok(result):
            server=start_proxy_server();reload_bouquets()
            try:
                from .core.bouquets import _queue_receiver_epg_seed
                _queue_receiver_epg_seed((result or {}).get("epg_seed") or [])
            except Exception as exc:
                optional_failure("ui.portal_live_epg_seed", exc)
            if server is None:
                self["status"].setText(_("Bouquet export failed: dynamic proxy is not running"))
                self.session.open(SettingsGlassNoticeScreen,_("Live Export"),_("The files were written but the dynamic bouquet proxy could not start. Remove/re-export the bouquet after resolving the port conflict."),False)
                return
            count=int((result or {}).get("channels") or 0)
            self["status"].setText(_("Bouquet exported • %d channels • proxy %s")%(count,(result or {}).get("proxy_port") or ""))
            show_notice(self.session,_("Live bouquet exported • %d channels • EPGImport source created") % count, timeout=6, owner=self)
        self._run_async(work,ok,lambda e:self["status"].setText(_("Bouquet export failed: %s")%e))


def _stamp_cached_live_export_picons(profile, channels):
    """Attach already-downloaded live logos before a full bouquet export.

    This does not fetch artwork. A full portal can be tens of thousands of
    channels; only logos Ultra Stalker has already cached are published.
    """
    try:
        from .ui import _cached_live_picon_path, _image_url
    except Exception:
        return
    for row in channels or []:
        if not isinstance(row, dict) or row.get("_receiver_picon_local"):
            continue
        try:
            cached = _cached_live_picon_path(_image_url(row), profile, row)
            if cached:
                row["_receiver_picon_local"] = cached
                row["_receiver_picon_source_local"] = cached
        except Exception:
            continue


# R5.245: plugin-owned front-panel identity.
try:
    from .frontpanel_plugin import bind_plugin_front_summary as _bind_plugin_front_summary
    _bind_plugin_front_summary(PortalManagerPremiumScreen, FreeLibraryShellScreen, PortalListScreen)
except Exception:
    pass

