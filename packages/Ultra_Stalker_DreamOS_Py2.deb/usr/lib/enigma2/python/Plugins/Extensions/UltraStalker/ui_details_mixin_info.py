# -*- coding: utf-8 -*-
"""Image reload and inline information overlay.

Methods moved verbatim out of ``ContentDetailsScreen`` (ui_screens_details.py); behaviour is unchanged.
This module is imported by ui_screens_details.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, max
from .ui_screens_details import (
    _,
    _clean_person_name,
    _strip_arabic_tashkeel,
    os,
)


class DetailsInfoMixin(object):
    """Image reload and inline information overlay."""

    def reload_image(self):
        self._image_token += 1
        ph = "grid_placeholder_movie_921.png" if self.media_type == "vod" else "grid_placeholder_series_921.png"
        self._decode_picture(asset(ph))
        try:self["cinematic_bg"].hide()
        except Exception as exc:optional_failure("ui.silent_guard",exc)
        self._load_tmdb_metadata()
        self["status"].setText(_("Reloading external artwork..."))

    def _information_page_up(self):
        try:
            pages=list(getattr(self,"_info_desc_pages",[]) or [])
            if len(pages) <= 1:return
            self._info_desc_index=(int(getattr(self,"_info_desc_index",0))-1)%len(pages)
            self["info_description"].setText(pages[self._info_desc_index])
            self["info_page"].setText("%d/%d"%(self._info_desc_index+1,len(pages)))
            self._fit_information_inline_overview()
        except Exception as exc:optional_failure("ui.info_inline_page_up",exc)

    def _information_page_down(self):
        try:
            pages=list(getattr(self,"_info_desc_pages",[]) or [])
            if len(pages) <= 1:return
            self._info_desc_index=(int(getattr(self,"_info_desc_index",0))+1)%len(pages)
            self["info_description"].setText(pages[self._info_desc_index])
            self["info_page"].setText("%d/%d"%(self._info_desc_index+1,len(pages)))
            self._fit_information_inline_overview()
        except Exception as exc:optional_failure("ui.info_inline_page_down",exc)

    def _hide_information_inline(self, initial=False):
        for _name in getattr(self,"_info_inline_widgets",()):
            try:self[_name].hide()
            except Exception:pass
        if not initial:
            self._info_inline_active=False
        self._info_desc_pages=[]
        self._info_desc_index=0

    def _close_information_overlay(self,*args):
        if not getattr(self,"_info_inline_active",False):
            return
        self._hide_information_inline()
        try:self["info_overlay_actions"].setEnabled(False)
        except Exception:pass
        try:self["actions"].setEnabled(True)
        except Exception:pass
        try:self._restore_details_visual_state()
        except Exception as exc:optional_failure("ui.info_inline_restore",exc)

    @staticmethod
    def _info_inline_text(value):
        if value in (None,"",[],{}):return ""
        if isinstance(value,(list,tuple)):
            out=[]
            for x in value:
                if isinstance(x,dict):
                    x=x.get("name") or x.get("title") or x.get("iso_3166_1") or x.get("iso_639_1") or ""
                x=str(x or "").strip()
                if x:out.append(x)
            return ", ".join(out)
        if isinstance(value,dict):
            return str(value.get("name") or value.get("title") or value.get("value") or "").strip()
        return str(value).strip()

    @staticmethod
    def _info_inline_rating(value):
        try:
            n=float(value)
            return ("%.1f"%n) if n>0 else "-"
        except Exception:
            return str(value or "-")[:5]

    @staticmethod
    def _info_inline_money(value):
        try:
            n=int(float(value or 0))
            return ("$%s"%format(n,",")) if n>0 else ""
        except Exception:return ""

    @staticmethod
    def _info_inline_runtime(value):
        try:
            n=int(float(value or 0))
            if n<=0:return ""
            h,m=divmod(n,60)
            return ((str(h)+"h ") if h else "") + ((str(m)+"m") if m else "")
        except Exception:return ""

    @staticmethod
    def _build_info_overview_pages(text,limit=560):
        value=str(text or "").replace("\r"," ").replace("\n"," ").strip()
        value=_strip_arabic_tashkeel(value)
        if not value:return [""]
        words=value.split();pages=[];current=[];current_len=0
        for word in words:
            token=str(word);extra=(1 if current else 0)+len(token)
            if current and current_len+extra>int(limit):
                pages.append(" ".join(current).strip());current=[token];current_len=len(token)
            else:
                current.append(token);current_len+=extra
        if current:pages.append(" ".join(current).strip())
        return pages or [value]

    @staticmethod
    def _pick_best_info_overview(*candidates):
        pool=[]
        def add_value(value):
            value=str(value or "").replace("\r"," ").replace("\n"," ").strip()
            if value and value not in pool:
                pool.append(value)
        for candidate in candidates:
            if isinstance(candidate,dict):
                for _k,_v in candidate.items():
                    if isinstance(_v,dict):
                        add_value(_v.get("overview") or _v.get("description") or _v.get("plot"))
                    else:
                        add_value(_v)
            elif isinstance(candidate,(list,tuple,set)):
                for _v in candidate:
                    add_value(_v)
            else:
                add_value(candidate)
        if not pool:
            return ""
        try:
            from .details_authority import choose_description_for_settings
            _arabic_first=choose_description_for_settings(pool)
            if _arabic_first:return _arabic_first
        except Exception:pass
        pool.sort(key=lambda s:(len(s), s.count(" ")), reverse=True)
        return pool[0]

    def _build_information_frost(self):
        """Return a simple transparent dim scrim above the live Details page.

        The Details screen must stay physically present behind the Information
        card (poster, backdrop and metadata are still there), but the user's
        visual focus should shift to the card itself.  So we use one fullscreen
        semi-transparent scrim instead of a fake new page or a custom backdrop
        blur render.
        """
        try:
            dim=asset("us88_focus_dim_scrim.png")
            if dim and os.path.isfile(dim):return dim
        except Exception as exc:
            optional_failure("ui.info_focus_scrim",exc)
        return asset("us20_player_info_scrim.png")

    def _fit_information_inline_box(self,name,max_size,min_size=11):
        try:
            value=str(self[name].getText() or "").strip();inst=self[name].instance
            if not value or inst is None:return
            safe_h=max(20,int(inst.size().height()*0.96));chosen=int(min_size)
            for size in range(int(max_size),int(min_size)-1,-1):
                try:
                    inst.setFont(_ultra_rfont("Regular",size));needed=int(inst.calculateSize().height()*1.05)
                except Exception:needed=safe_h+1
                if needed<=safe_h:
                    chosen=size;break
            inst.setFont(_ultra_rfont("Regular",chosen))
        except Exception as exc:optional_failure("ui.info_inline_fit",exc)

    def _fit_information_inline_overview(self):
        try:
            value=str(self["info_description"].getText() or "").strip();inst=self["info_description"].instance
            if not value or inst is None:return
            try:mode=str(load_settings().get("overview_font_scale") or "normal").strip().lower()
            except Exception:mode="normal"
            preferred={"normal":26,"large":34,"larger":42,"xlarge":52}.get(mode,26)
            safe_h=max(40,int(inst.size().height()*0.99));chosen=14
            for size in range(int(preferred),13,-1):
                try:
                    inst.setFont(_ultra_rfont("Regular",size));needed=int(inst.calculateSize().height()*1.06)
                except Exception:needed=safe_h+1
                if needed<=safe_h:
                    chosen=size;break
            inst.setFont(_ultra_rfont("Regular",chosen))
        except Exception as exc:optional_failure("ui.info_inline_overview_fit",exc)

    def _show_information_inline(self,title,payload,meta,poster_path):
        data=payload if isinstance(payload,dict) else {}
        txt=self._info_inline_text
        clean_title=str(title or _("Information")).replace("\n"," ").strip()
        self["info_title"].setText(clean_title[:105])
        desc=txt(data.get("overview") or data.get("description_full") or data.get("description") or data.get("descr") or data.get("plot")) or _("No additional description is available.")
        self._info_desc_pages=self._build_info_overview_pages(desc,420)
        self._info_desc_index=0
        self["info_description"].setText(self._info_desc_pages[0] if self._info_desc_pages else desc)
        self["info_page"].setText(("1/%d"%len(self._info_desc_pages)) if len(self._info_desc_pages)>1 else "")
        cast=_clean_person_name(txt(data.get("actors") or data.get("cast") or data.get("actor")))
        director=txt(data.get("director") or data.get("directors"))
        writer=txt(data.get("writer") or data.get("writers") or data.get("creator"))
        self["info_cast_label"].setText(_("Cast") if cast else "");self["info_cast"].setText(cast)
        self["info_director_label"].setText(_("Director") if director else "");self["info_director"].setText(director)
        self["info_writer_label"].setText(_("Writer") if writer else "");self["info_writer"].setText(writer)

        genres=txt(data.get("genres") or data.get("genre"));countries=txt(data.get("countries") or data.get("country"))
        production=txt(data.get("production_companies") or data.get("production"));prod_countries=txt(data.get("production_countries"))
        rating_raw=data.get("rating") or data.get("vote_average") or data.get("tmdb_rating") or "";votes=data.get("vote_count") or ""
        try:rating_num=float(rating_raw);rating=("%.1f/10"%rating_num) if rating_num>0 else ""
        except Exception:rating_num=0;rating=txt(rating_raw)
        age=txt(data.get("age_rating") or data.get("certification"));release=txt(data.get("release_date") or data.get("first_air_date"))
        status=txt(data.get("status"));lang=txt(data.get("original_language"));original=txt(data.get("original_title") or data.get("original_name"));tagline=txt(data.get("tagline"))
        if status.isdigit():status=""
        runtime_hm=self._info_inline_runtime(data.get("runtime") or data.get("duration") or data.get("time"))
        meta_bits=[]
        if age:meta_bits.append(age)
        if release:meta_bits.append(release + ((" ("+countries.split(",")[0].strip()+")") if countries else ""))
        if runtime_hm:meta_bits.append(runtime_hm)
        if genres:meta_bits.append(genres)
        self["info_meta"].setText("   •   ".join(meta_bits) if meta_bits else str(meta or ""))
        self["info_desc_label"].setText(_("OVERVIEW"))
        self["info_votes"].setText(("%s %s"%(votes,_("votes"))) if votes else "")

        extra=[];tail=[]
        if original:extra.append(_("Original Title")+": "+original)
        if lang:extra.append(_("Original Language")+": "+lang.upper())
        if status:extra.append(_("Status")+": "+status)
        if countries:extra.append(_("Country")+": "+countries)
        if production:extra.append(_("Production")+": "+production)
        if prod_countries and prod_countries!=countries:extra.append(_("Production Countries")+": "+prod_countries)
        if self.media_type in ("series","tv"):
            seasons=txt(data.get("number_of_seasons"));episodes=txt(data.get("number_of_episodes"));last_air=txt(data.get("last_air_date"))
            networks=txt(data.get("networks") or data.get("network"));created=txt(data.get("created_by") or data.get("creators"));show_type=txt(data.get("type"));in_prod=data.get("in_production")
            if seasons:extra.append(_("Seasons")+": "+seasons)
            if episodes:extra.append(_("Episodes")+": "+episodes)
            if last_air:extra.append(_("Last Air Date")+": "+last_air)
            if networks:tail.append(_("Networks")+": "+networks)
            if created:tail.append(_("Created By")+": "+created)
            if show_type:tail.append(_("Type")+": "+show_type)
            if isinstance(in_prod,bool):tail.append(_("In Production")+": "+(_("Yes") if in_prod else _("No")))
        else:
            budget=self._info_inline_money(data.get("budget"));revenue=self._info_inline_money(data.get("revenue"))
            if budget:tail.append(_("Budget")+": "+budget)
            if revenue:tail.append(_("Revenue")+": "+revenue)
        if votes:tail.append(_("Votes")+": "+str(votes))
        if tagline:tail.append(_("Tagline")+": "+tagline)
        self["info_left"].setText("   •   ".join(extra));self["info_right"].setText("   •   ".join(tail))
        self["info_imdb_value"].setText(self._info_inline_rating(data.get("imdb_rating") or data.get("imdb_score") or data.get("rating_imdb")))
        self["info_tmdb_value"].setText(self._info_inline_rating(data.get("vote_average") or data.get("tmdb_rating") or data.get("rating")))

        self._info_inline_poster_path=str(poster_path or "")
        try:
            scrim=self._build_information_frost()
            if scrim and os.path.isfile(scrim):self["info_scrim"].instance.setPixmapFromFile(scrim)
            imdb=asset("us65_logo_imdb_94x36.png")
            tmdb=asset("us62_icon_tmdb.png")
            if imdb and os.path.isfile(imdb):self["info_imdb_logo"].instance.setPixmapFromFile(imdb)
            if tmdb and os.path.isfile(tmdb):self["info_tmdb_logo"].instance.setPixmapFromFile(tmdb)
            if self._info_inline_poster_path and os.path.isfile(self._info_inline_poster_path):
                self["info_poster"].instance.setPixmapFromFile(self._info_inline_poster_path)
            from .services.player_artwork import _adaptive_info_frames
            _info_palette_source=str(getattr(self,"_adaptive_source_local","") or getattr(self,"_adaptive_authoritative_source","") or getattr(self,"_poster_authoritative_source","") or self._info_inline_poster_path or "")
            if not (_info_palette_source and os.path.isfile(_info_palette_source)):
                _info_palette_source=self._info_inline_poster_path
            frames=_adaptive_info_frames(_info_palette_source) or {}
            for widget_name,key in (("info_adaptive_main","main"),("info_adaptive_poster","poster"),("info_poster_rating_bg","rating"),("info_adaptive_desc","desc_d"),("info_adaptive_cast","cast_d"),("info_adaptive_director","director_d"),("info_adaptive_writer","writer_d"),("info_adaptive_extra","extra")):
                path=frames.get(key)
                if path and os.path.isfile(path):self[widget_name].instance.setPixmapFromFile(path)
        except Exception as exc:optional_failure("ui.info_inline_art",exc)

        for _name in self._info_inline_widgets:
            try:self[_name].show()
            except Exception:pass
        self._info_inline_active=True
        try:self["actions"].setEnabled(False)
        except Exception:pass
        try:self["info_overlay_actions"].setEnabled(True)
        except Exception:pass
        self._fit_information_inline_overview()
        for _name,_max in (("info_cast",19),("info_director",18),("info_writer",18),("info_left",16),("info_right",16)):
            self._fit_information_inline_box(_name,_max,11)

    def show_information(self):
        # R80: mirror Settings. Information is a group of widgets on the current
        # Details Screen, never a session.open()/instantiateDialog Screen.
        if getattr(self,"_info_inline_active",False):
            self._close_information_overlay();return
        if isinstance(self.item,dict):
            try:title=str(self["name"].getText() or "").strip() or _clean_display_text(self.item.get("name") or self.item.get("title") or _("Information"),90)
            except Exception:title=_clean_display_text(self.item.get("name") or self.item.get("title") or _("Information"),90)
        else:title=_("Information")
        payload=dict(self.item) if isinstance(self.item,dict) else {}
        from .manual_identity import selected
        if selected(payload):
            payload.pop("status",None);payload.pop("type",None)
        tmdb_data=getattr(self,"_tmdb_data",None)
        if isinstance(tmdb_data,dict):
            for key,value in tmdb_data.items():
                if value not in (None,"",[],{}):payload[key]=value
        try:
            cached_overviews={}
            if isinstance(tmdb_data,dict):
                cached_overviews=tmdb_data.get("_description_overviews") or {}
            if not cached_overviews and isinstance(payload,dict):
                cached_overviews=payload.get("_description_overviews") or {}
            # The Information card shows the synopsis the Details box shows. The
            # old "longest text of everything" pick stays only as a fallback while
            # the box has nothing but the loading placeholder.
            _shown_synopsis=str(getattr(self,"_description_source","") or "").strip()
            if _shown_synopsis and _shown_synopsis!=str(_("Loading metadata…")):
                payload["description_full"]=_shown_synopsis
            else:payload["description_full"]=self._pick_best_info_overview(
                (tmdb_data.get("overview") if isinstance(tmdb_data,dict) else ""),
                (tmdb_data.get("description") if isinstance(tmdb_data,dict) else ""),
                (tmdb_data.get("plot") if isinstance(tmdb_data,dict) else ""),
                (tmdb_data.get("_details_visible_overview") if isinstance(tmdb_data,dict) else ""),
                (payload.get("_details_visible_overview") if isinstance(payload,dict) else ""),
                cached_overviews,
                getattr(self,"_details_visible_overview",""),
                getattr(self,"_description_source",""),
                payload.get("overview") if isinstance(payload,dict) else "",
                payload.get("description") if isinstance(payload,dict) else "",
                payload.get("descr") if isinstance(payload,dict) else "",
                payload.get("plot") if isinstance(payload,dict) else "",
            )
        except Exception as exc:optional_failure("ui.info_inline_field",exc)
        try:payload["description"]=payload.get("description_full") or payload.get("description") or ""
        except Exception as exc:optional_failure("ui.info_inline_field",exc)
        try:payload["cast"]=self["cast_text"].getText() or payload.get("cast") or ""
        except Exception as exc:optional_failure("ui.info_inline_field",exc)
        poster_path=""
        try:
            state=getattr(self,"_details_visual_state",{}) or {}
            poster_path=str(state.get("detail_poster") or state.get("poster") or getattr(self,"_poster_authoritative_source","") or getattr(self,"_image_displayed_path","") or "")
            if poster_path and not os.path.isfile(poster_path):poster_path=""
        except Exception as exc:optional_failure("ui.info_inline_poster",exc)
        meta_parts=[]
        for value in (self["quality_text"].getText(),self["year_text"].getText(),self["runtime_text"].getText(),self["country_text"].getText()):
            value=str(value or "").strip()
            if value and value not in ("—","-"):meta_parts.append(value)
        self._show_information_inline(title,payload,"   •   ".join(meta_parts),poster_path)
from .wqhd_layout import responsive_font as _ultra_rfont, factors as _ultra_factors

def _ultra_osd_scale():
    return _ultra_factors()[1]
