# -*- coding: utf-8 -*-
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str, int, map, OSError, native_str, native_text
os = _us_env.os
time = _us_env.time
import glob
from Plugins.Plugin import PluginDescriptor
from . import _
from .compat import startup_preflight, format_preflight_error
from .log import get_logger, configure_logger
LOG = get_logger()
try:
    import keymapparser
    _KEYMAP = os.path.join(os.path.dirname(__file__), 'keymap.xml')
    if os.path.isfile(_KEYMAP):
        keymapparser.readKeymap(native_text(_KEYMAP))
except Exception as exc:
    LOG.warning('Keymap load failed: %s', exc)
_DEPS_TOOL = '/usr/bin/ultrastalker-deps'

def _install_receiver_guards():
    try:
        from .receiver_guards import install_session_guards
        state = install_session_guards()
        LOG.info('Receiver guards: %s', state)
    except Exception as exc:
        LOG.warning('Receiver guards unavailable: %s', exc)

def _missing_installable(report):
    """True when a fatal item is a Python library that apt-get/opkg can normally supply."""
    return any(('python3-' in str(item) or 'python-' in str(item) for item in report.get('fatal') or []))

def _run_dependency_install(session):
    """Run the bundled dependency installer in a visible console, then offer a GUI restart."""
    try:
        from Screens.Console import Console
        from Screens.MessageBox import MessageBox

        def _after(*_args):

            def _answer(yes):
                if yes:
                    try:
                        from Screens.Standby import TryQuitMainloop
                        session.open(TryQuitMainloop, 3)
                    except Exception as exc:
                        LOG.error('GUI restart request failed: %s', exc)
            session.openWithCallback(_answer, MessageBox, _('Restart Enigma2 now to finish?'), MessageBox.TYPE_YESNO)
        session.openWithCallback(_after, Console, title=_('Ultra Stalker - installing requirements'), cmdlist=['%s fix' % _DEPS_TOOL], closeOnSuccess=False)
    except Exception as exc:
        LOG.error('Dependency installer could not be opened: %s', exc)

def _show_startup_error(session, report):
    text = format_preflight_error(report)
    try:
        from Screens.MessageBox import MessageBox
        if _missing_installable(report) and os.path.isfile(_DEPS_TOOL):
            _re = _us_env.re
            default_pkg = 'python-sqlite3' if _us_env.PY2 else 'python3-sqlite3'
            pkgs = ' '.join(_re.findall('package: (python3?-[a-z0-9_-]+)', ' '.join(map(str, report.get('fatal') or [])))) or default_pkg
            manual_cmd = 'apt-get update && apt-get install -y ' + pkgs if _us_env.IS_DREAMOS else 'opkg update && opkg install ' + pkgs
            text += '\n\nInstall the missing requirement(s) now? (needs internet on the receiver)\nManual alternative: ' + manual_cmd

            def _answer(yes):
                if yes:
                    _run_dependency_install(session)
            session.openWithCallback(_answer, MessageBox, text, MessageBox.TYPE_YESNO)
        else:
            session.open(MessageBox, text, MessageBox.TYPE_ERROR, timeout=15)
    except Exception as exc:
        LOG.error('Startup compatibility failure: %s; MessageBox unavailable: %s', text.replace('\n', ' | '), exc)

def _preflight(session=None):
    report = startup_preflight()
    if not report.get('ok'):
        LOG.error('Startup preflight failed: %s', '; '.join(report.get('fatal') or []))
        if session is not None:
            _show_startup_error(session, report)
        return None
    for warning in report.get('warnings') or []:
        LOG.warning('Startup preflight warning: %s', warning)
    return report

def _defer_runtime_services(session, screen=None):
    """Recover runtime services after the Splash has been opened."""
    try:
        from enigma import eTimer
        timer = eTimer()

        def run():
            # Do not compete with a slow cold UI import. The timer is a safety
            # net; normal recorder/proxy startup is owned by session_start().
            if screen is not None and not getattr(screen, "_portal_list_opened", False):
                if getattr(screen, "_startup_failed", False):
                    timer.stop()
                    return
                timer.start(250, True)
                return
            try:
                configure_logger()
            except Exception:
                pass
            try:
                from .core.recording import start_recording_manager
                start_recording_manager(session, initial_tick=False)
            except Exception as exc:
                LOG.warning('Deferred recording manager start failed: %s', exc)
            try:
                from .core.bouquets import start_proxy_server
                start_proxy_server()
            except Exception as exc:
                LOG.warning('Deferred proxy start failed: %s', exc)
            try:
                from .webcleaner import start as start_webcleaner
                start_webcleaner()
            except Exception as exc:
                LOG.warning('Web Cleaner auto-start failed: %s', exc)
            try:
                from .updater import deferred_auto_check
                deferred_auto_check(session, delay_ms=5000)
            except Exception as exc:
                LOG.warning('Online update check unavailable: %s', exc)
            try:
                threading = _us_env.threading

                def _provider_bootstrap_reconcile_worker():
                    try:
                        from .provider_bootstrap import reconcile_tmdb_state
                        state = reconcile_tmdb_state()
                        LOG.info('R113 provider bootstrap state: %s', state)
                    except Exception as _exc:
                        LOG.warning('R113 provider bootstrap reconcile unavailable: %s', _exc)
                _bt = threading.Thread(target=_provider_bootstrap_reconcile_worker, name='UltraStalkerProviderBootstrapReconcile')
                _bt.daemon = True
                _bt.start()
                setattr(holder, '_ultrastalker_provider_bootstrap_reconcile_thread', _bt)
            except Exception as exc:
                LOG.warning('R113 provider bootstrap reconcile scheduling failed: %s', exc)
            try:
                from .release_cleanup_r249 import schedule_title_logo_migration
                schedule_title_logo_migration()
            except Exception as exc:
                LOG.warning('R249 title-logo migration scheduling failed: %s', exc)
            try:
                timer.stop()
            except Exception:
                pass
        try:
            conn = timer.timeout.connect(run)
        except Exception:
            timer.callback.append(run)
            conn = None
        holder = screen if screen is not None else session
        setattr(holder, '_ultrastalker_runtime_start_timer', timer)
        if conn is not None:
            setattr(holder, '_ultrastalker_runtime_start_conn', conn)
        timer.start(8000, True)
    except Exception as exc:
        LOG.warning('Runtime service deferral unavailable: %s', exc)

def _schedule_stale_session_cleanup(session, delay_ms=20000):
    """PERFLAB10: clean old presentation sessions off the UI thread.

    The current session and all canonical/BLUE artwork are outside the deletion
    target.  A short startup delay also keeps HDD traversal away from first paint.
    """
    try:
        if getattr(session, '_ultrastalker_session_cleanup_timer', None) is not None:
            return
        from enigma import eTimer
        timer = eTimer()

        def worker():
            try:
                time = _us_env.time
                from .persistent_cache import cleanup_stale_session_caches, cleanup_legacy_alt_cache_roots
                result = None
                for attempt in range(3):
                    result = cleanup_stale_session_caches()
                    if result.get('ready'):
                        break
                    if attempt < 2:
                        time.sleep(10.0)
                if isinstance(result, dict):
                    LOG.info('PerfLab stale-session cleanup: removed=%s live=%s errors=%s ready=%s', result.get('removed', 0), result.get('skipped_live', 0), result.get('errors', 0), result.get('ready', False))
                try:
                    legacy = cleanup_legacy_alt_cache_roots()
                    if isinstance(legacy, dict):
                        LOG.info('Legacy alternate cache cleanup: removed=%s same=%s errors=%s ready=%s', legacy.get('removed', 0), legacy.get('skipped_same', 0), legacy.get('errors', 0), legacy.get('ready', False))
                except Exception as exc:
                    LOG.warning('Legacy alternate cache cleanup unavailable: %s', exc)
            except Exception as exc:
                LOG.warning('PerfLab stale-session cleanup unavailable: %s', exc)

        def run():
            try:
                timer.stop()
            except Exception:
                pass
            try:
                threading = _us_env.threading
                thread = threading.Thread(target=worker, name='UltraStalkerSessionCleanup')
                thread.daemon = True
                setattr(session, '_ultrastalker_session_cleanup_thread', thread)
                thread.start()
            except Exception as exc:
                LOG.warning('PerfLab session cleanup worker start failed: %s', exc)
        try:
            conn = timer.timeout.connect(run)
        except Exception:
            timer.callback.append(run)
            conn = None
        setattr(session, '_ultrastalker_session_cleanup_timer', timer)
        if conn is not None:
            setattr(session, '_ultrastalker_session_cleanup_conn', conn)
        timer.start(int(delay_ms), True)
    except Exception as exc:
        LOG.warning('PerfLab stale-session cleanup scheduling failed: %s', exc)

def main(session, **kwargs):
    _perf_t0 = time.monotonic()
    LOG.info('PERF25 startup main_enter mono_ms=%d', int(_perf_t0 * 1000))
    try:
        from .core.playback_buffer import hide_visible_buffer_folder
        hide_visible_buffer_folder()
    except Exception:
        pass
    _phase = time.monotonic()
    if _preflight(session) is None:
        return
    LOG.info('PERF25 startup preflight_done elapsed_ms=%d', int((time.monotonic() - _phase) * 1000))
    _install_receiver_guards()
    try:
        try:
            from .release_cleanup_r249 import prepare_backdrops_once
            prepare_backdrops_once()
        except Exception as exc:
            LOG.warning('R249 backdrop layout preparation unavailable: %s', exc)
        _phase = time.monotonic()
        from .ui_screens_splash import SplashScreen
        LOG.info('PERF25 startup splash_import_done elapsed_ms=%d', int((time.monotonic() - _phase) * 1000))
        _phase = time.monotonic()
        from .core.runtime_manager import capability_report
        report = capability_report(include_hdd=False)
        LOG.info('PERF25 startup capability_done elapsed_ms=%d', int((time.monotonic() - _phase) * 1000))
        if not report.get('pillow'):
            LOG.error('Pillow unavailable; refusing to start incomplete artwork architecture')
            try:
                from Screens.MessageBox import MessageBox
                session.open(MessageBox, _('Ultra Stalker requires Pillow for artwork and Adaptive UI.\n\nInstall the required runtime capability, then reopen the plugin.'), MessageBox.TYPE_ERROR, timeout=20)
            except Exception as msg_exc:
                LOG.error('Pillow capability message failed: %s', msg_exc)
            return
        _phase = time.monotonic()
        screen = session.open(SplashScreen)
        LOG.info('PERF25 startup splash_open_return elapsed_ms=%d total_ms=%d', int((time.monotonic() - _phase) * 1000), int((time.monotonic() - _perf_t0) * 1000))
        _defer_runtime_services(session, screen)
    except Exception as exc:
        LOG.exception('Plugin startup failed after preflight')
        try:
            from Screens.MessageBox import MessageBox
            session.open(MessageBox, _('Ultra Stalker failed to start:\n\n%s') % exc, MessageBox.TYPE_ERROR, timeout=15)
        except Exception:
            pass

def _cleanup_stale_runtime_temp():
    """Remove only plugin-owned temporary outputs, never user installers."""
    patterns=(
        "/tmp/UltraStalker_online_update.deb",
        "/tmp/UltraStalker_online_update.deb.part",
        "/tmp/UltraStalker_online_update.ipk",
        "/tmp/UltraStalker_online_update.ipk.part",
        "/tmp/ultrastalker_webcleaner_qr.png.tmp*",
        "/tmp/us_r188_fast_bd_*",
        "/tmp/us_r243_original_*",
        "/tmp/ultrastalker_firstpaint/*.tmp.*",
        "/etc/enigma2/ultrastalker/portals.txt.webcleaner.tmp*",
    )
    removed=0
    for pattern in patterns:
        for path in glob.glob(pattern):
            try:
                if os.path.islink(path) or os.path.isfile(path):
                    os.unlink(path);removed+=1
            except OSError:pass
    if removed:LOG.info("Removed %d stale Ultra Stalker temporary file(s)",removed)
    return removed

def session_start(reason, session=None, **kwargs):
    if reason == 0 and session is not None:
        LOG.info('UltraStalker build marker: DREAMOS-V9.2.6')
        _install_receiver_guards()
        try:
            _cleanup_stale_runtime_temp()
        except Exception as exc:
            LOG.warning('Temporary-file cleanup skipped: %s', exc)
        try:
            from .core.bouquets import restore_exported_media_on_session_start
            restore_exported_media_on_session_start()
        except Exception as exc:
            LOG.warning('Saved media startup restore unavailable: %s', exc.__class__.__name__)
        if _preflight(None) is None:
            return
        try:
            from .core.runtime_manager import capability_report
            if not capability_report(include_hdd=False).get('pillow'):
                LOG.error('Runtime services deferred because Pillow capability is unavailable')
                return
        except Exception as exc:
            LOG.warning('Capability gate unavailable at session start: %s', exc)
        try:
            from .release_cleanup_r249 import prepare_backdrops_once, schedule_title_logo_migration
            prepare_backdrops_once()
            schedule_title_logo_migration()
        except Exception as exc:
            LOG.warning('R249 HDD cleanup scheduling unavailable at session start: %s', exc)
        try:
            from .core.recording import start_recording_manager
            from .core.bouquets import start_proxy_server, set_export_player_session
            try:
                set_export_player_session(session)
            except Exception as exc:
                LOG.warning('Export Player session bind failed: %s', exc)
            try:
                configure_logger()
            except Exception as exc:
                LOG.warning('Logger setup failed at session start: %s', exc)
            try:
                start_recording_manager(session)
            except Exception as exc:
                LOG.warning('Recording manager start failed: %s', exc)
            try:
                start_proxy_server()
            except Exception as exc:
                LOG.warning('Bouquet proxy start failed: %s', exc)
        except Exception as exc:
            LOG.exception('Runtime service imports failed after preflight: %s', exc)
        _schedule_stale_session_cleanup(session)
        return
    if reason != 0:
        try:
            from .webcleaner import stop as stop_webcleaner
            stop_webcleaner()
        except Exception as exc:
            LOG.warning('Web Cleaner shutdown failed: %s', exc)
        try:
            from .core.runtime_manager import shutdown_runtime
            shutdown_runtime(wait=False)
        except Exception as exc:
            LOG.warning('Runtime shutdown failed: %s', exc)

def main_local(session, **kwargs):
    """Open the Local library directly: no splash, portal or internet needed.

    Local only reads receiver storage (HDD/USB/flash), so it must stay usable
    when the network or every portal is down.
    """
    if _preflight(session) is None:
        return
    try:
        from . import ui as runtime_ui
        try:
            runtime_ui.begin_plugin_launch(session)
        except Exception as exc:
            LOG.warning('Local launch snapshot failed: %s', exc)
        from .ui_screens_local import LocalLibraryScreen

        def _closed(*_args):
            try:
                runtime_ui.restore_plugin_service(session)
            except Exception as exc:
                LOG.warning('Local launch service restore failed: %s', exc)
        session.openWithCallback(_closed, LocalLibraryScreen, {})
    except Exception as exc:
        LOG.exception('Ultra Stalker Local failed to start')
        try:
            from Screens.MessageBox import MessageBox
            session.open(MessageBox, _('Ultra Stalker failed to start:\n\n%s') % exc, MessageBox.TYPE_ERROR, timeout=15)
        except Exception as msg_exc:
            LOG.error('Local start error message failed: %s', msg_exc)

def main_menu_entry(menuid, **kwargs):
    """Expose Ultra Stalker directly in Enigma2 Main Menu when enabled.

    The setting is read when the menu is opened, so toggling it takes effect
    immediately without restarting Enigma2. The normal Plugins-menu entry is
    always kept as a safe way back into the plugin.
    """
    if str(menuid or '') != 'mainmenu':
        return []
    try:
        from .storage import load_settings
        if not bool(load_settings().get('show_main_menu', True)):
            return []
    except Exception as exc:
        LOG.warning('Main-menu visibility read failed: %s', exc)
    return [(native_text(_('Ultra Stalker')), main, native_str('ultrastalker_main'), 50), (native_text(_('Ultra Stalker Local')), main_local, native_str('ultrastalker_local'), 51)]

def Plugins(**kwargs):
    return [PluginDescriptor(name=native_text(_('Ultra Stalker')), description=native_text(_('Ultra Stalker')), where=PluginDescriptor.WHERE_PLUGINMENU, icon=native_str('plugin.png'), fnc=main), PluginDescriptor(name=native_text(_('Ultra Stalker Local')), description=native_text(_('Play files stored on this receiver')), where=PluginDescriptor.WHERE_PLUGINMENU, icon=native_str('plugin_local.png'), fnc=main_local), PluginDescriptor(where=PluginDescriptor.WHERE_MENU, fnc=main_menu_entry), PluginDescriptor(where=PluginDescriptor.WHERE_SESSIONSTART, fnc=session_start)]
