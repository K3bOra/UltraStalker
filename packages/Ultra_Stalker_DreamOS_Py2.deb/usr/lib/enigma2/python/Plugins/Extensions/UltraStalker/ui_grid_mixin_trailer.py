# -*- coding: utf-8 -*-
"""Trailer identity, language policy, cache and playback."""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, max, min
from .ui_grid_base import (
    _,
    reactor,
    threading,
    weakref,
)


class GridTrailerMixin(object):
    """Trailer identity, language policy, cache and playback."""

    def _cancel_grid_trailer_request(self):
        """Cancel only the direct Trailer action owned by this grid screen."""
        try:
            event=getattr(self,"_grid_trailer_cancel_event",None)
            if event is not None:event.set()
        except Exception:pass
        self._grid_trailer_busy=False
        self._grid_trailer_token=int(getattr(self,"_grid_trailer_token",0) or 0)+1

    def _grid_trailer_identity_state(self,item):
        """Return the canonical TMDb identity owned by this grid item or local cache."""
        row=item if isinstance(item,dict) else {}
        state=(getattr(self,"_grid_item_state",{}) or {}).get(id(item),{}) if item is not None else {}
        record={}
        try:
            reader=getattr(self,"_record",None)
            record=reader(item) if callable(reader) else {}
            if not isinstance(record,dict):record={}
        except Exception:record={}
        snap={}
        try:
            from .persistent_cache import load_detail_snapshot,load_shared_detail_snapshot
            snap=(load_shared_detail_snapshot(self.profile,self.media_type,row) if row.get("_xtream") else load_detail_snapshot(self.profile,self.media_type,row)) or {}
            if not isinstance(snap,dict):snap={}
        except Exception:snap={}
        fast_snap={}
        try:
            from .artwork_v2 import load_fast_local_poster, load_manifest
            fast_snap=load_fast_local_poster(self.profile,self.media_type,row) or load_manifest(self.profile,self.media_type,row) or {}
            if not isinstance(fast_snap,dict):fast_snap={}
        except Exception:fast_snap={}
        values=(
            row.get("_locked_tmdb_id"),row.get("_ultra_search_verified_tmdb_id"),
            state.get("tmdb_id"),
            row.get("tmdb_id"),row.get("tmdbid"),row.get("tmdb"),
            record.get("_locked_tmdb_id"),record.get("_ultra_search_verified_tmdb_id"),
            record.get("tmdb_id"),
            snap.get("tmdb_id"),
            fast_snap.get("tmdb_id"),
        )
        for value in values:
            if value in (None,""):continue
            sval=str(value).strip()
            if sval.isdigit():
                try:return int(sval),record,(snap or fast_snap)
                except Exception:continue
        return None,record,(snap or fast_snap)

    def _grid_trailer_language_policy(self,item,record,snap):
        merged={}
        for row in (item,record,snap):
            if isinstance(row,dict):merged.update(row)
        title=str(merged.get("name") or merged.get("title") or "")
        try:
            from .ui_screens_details import _details_is_arabic_work
            if _details_is_arabic_work(merged,title):return "ar-EG","ar"
        except Exception:pass
        original=str(merged.get("original_language") or "").strip().lower().replace("_","-")
        if original=="ar" or original.startswith("ar-"):return "ar-EG","ar"
        if original and len(original)>=2:
            short=original.split("-",1)[0]
            if short not in ("en","ar"):
                return original,short
        return "en-US","en"

    def _grid_cached_trailer_state(self,item,record,snap,preferred_language):
        try:
            from .trailer_runtime import trailer_from_rows
            trailer=trailer_from_rows(snap,record,item)
        except Exception:
            trailer={}
        checked=False;policy_checked=""
        for row in (snap,record,item):
            if not isinstance(row,dict):continue
            if row.get("_trailer_checked"):checked=True
            value=str(row.get("trailer_policy_language") or "").strip().lower().split("-",1)[0]
            if value:policy_checked=value
        if preferred_language=="ar" and policy_checked!="ar":
            if trailer:
                cached_lang=str(trailer.get("language") or "").strip().lower().split("-",1)[0]
                if cached_lang!="ar":return {},False
            elif checked:return {},False
        return (trailer if isinstance(trailer,dict) else {}),checked

    def _grid_remember_trailer(self,item,trailer,policy_language):
        if not isinstance(item,dict) or not isinstance(trailer,dict) or not trailer.get("key"):return
        item.update({
            "_trailer_checked":True,"trailer_site":"YouTube",
            "trailer_key":str(trailer.get("key") or ""),
            "trailer_name":str(trailer.get("name") or "Trailer"),
            "trailer_url":str(trailer.get("url") or ""),
            "trailer_official":bool(trailer.get("official")),
            "trailer_language":str(trailer.get("language") or ""),
            "trailer_policy_language":str(trailer.get("policy_language") or policy_language or ""),
        })

    def _open_selected_trailer_stream(self,item,stream_url,trailer,fallback_urls=None):
        stream_url=str(stream_url or "").strip()
        if not stream_url:return
        title=str((item or {}).get("name") or (item or {}).get("title") or "").strip() if isinstance(item,dict) else ""
        trailer_title=(title+" • "+_("Trailer")) if title else str((trailer or {}).get("name") or _("Trailer"))
        def closed(result=None):
            try:
                if isinstance(result,dict) and result.get("state")=="failed":self["status"].setText(_("Trailer playback failed"))
                else:self["status"].setText("")
            except Exception:pass
        parent_media="series" if self.media_type in ("series","episode") else "vod"
        payload=_player_payload(item,self.profile,media_type=parent_media)
        for key in ("_resume_position","_resume_duration","_history_item","_quality_parent_item"):
            payload.pop(key,None)
        payload["_trailer_parent_media_type"]=parent_media
        if fallback_urls:
            payload["_trailer_fallback_urls"]=[str(u) for u in fallback_urls if str(u or "").strip() and str(u)!=stream_url]
        self.session.openWithCallback(closed,UltraStalkerPlayer,stream_url,trailer_title,"trailer",4097,payload)

    def play_selected_trailer(self):
        """Run the Details Trailer pipeline directly from a catalogue view MENU."""
        if self.media_type not in ("vod","series") or not self.grid_items:return
        if getattr(self,"_grid_trailer_busy",False):
            try:self["status"].setText(_("Loading trailer..."))
            except Exception:pass
            return
        item=self.grid_items[self.index]
        tmdb_id,record,snap=self._grid_trailer_identity_state(item)
        trailer_locale,trailer_language=self._grid_trailer_language_policy(item,record,snap)
        cached,checked=self._grid_cached_trailer_state(item,record,snap,trailer_language)

        if not getattr(self,"_grid_trailer_close_hook_installed",False):
            try:self.onClose.append(self._cancel_grid_trailer_request)
            except Exception:pass
            self._grid_trailer_close_hook_installed=True
        self._grid_trailer_busy=True
        self._grid_trailer_token=int(getattr(self,"_grid_trailer_token",0) or 0)+1
        token=self._grid_trailer_token
        try:
            old=getattr(self,"_grid_trailer_cancel_event",None)
            if old is not None:old.set()
        except Exception:pass
        cancel_event=threading.Event();self._grid_trailer_cancel_event=cancel_event
        try:self["status"].setText(_("Loading trailer..."))
        except Exception:pass

        cfg=load_settings() or {}
        credential=str(cfg.get("tmdb_credential") or "").strip()
        timeout=min(12,max(5,int(cfg.get("timeout",10) or 10)))
        media="tv" if self.media_type=="series" else "movie"
        profile_copy=dict(getattr(self,"profile",{}) or {})
        owner_ref=weakref.ref(self)
        item_ref=item

        def worker():
            result={"state":"failed"}
            resolved_tid=tmdb_id
            try:
                if cancel_event.is_set():return
                if resolved_tid in (None,"") and credential and cfg.get("tmdb_enabled",True) and isinstance(item_ref,dict):
                    try:
                        from .artwork_v2_impl import ArtworkV2 as _ArtworkV2Impl
                        resolver=_ArtworkV2Impl(credential,cfg.get("tmdb_language","ar-EG"),timeout)
                        _mt,rid,_conf,_src,_cand=resolver._resolve_identity("series" if media=="tv" else "vod",item_ref,{})
                        if not rid:
                            _rmt,rid,_rconf,_rseed,_rtr=resolver._resolve_poster_rescue("series" if media=="tv" else "vod",item_ref)
                        if rid:resolved_tid=int(rid)
                    except Exception:pass
                    if resolved_tid in (None,""):
                        try:
                            from .tmdb import TMDBClient
                            enr=TMDBClient(credential,cfg.get("tmdb_language","ar-EG"),timeout).enrich("series" if media=="tv" else "vod",item_ref,artwork_mode="metadata") or {}
                            if enr.get("tmdb_id"):resolved_tid=int(enr.get("tmdb_id"))
                        except Exception:pass
                if resolved_tid in (None,"") and not cached:
                    result={"state":"missing"}
                else:
                    candidates=[]
                    if cached and cached.get("key"):
                        candidates.append({
                            "site":"YouTube","key":str(cached.get("key") or ""),
                            "name":str(cached.get("name") or "Trailer"),
                            "url":str(cached.get("url") or ""),
                            "official":bool(cached.get("official")),
                            "language":str(cached.get("language") or ""),
                            "policy_language":trailer_language,
                        })
                    if not candidates and credential and cfg.get("tmdb_enabled",True) and resolved_tid not in (None,""):
                        from .tmdb import TMDBClient
                        from .details_authority import _pick_tmdb_youtube_trailers
                        client=TMDBClient(credential,trailer_locale,timeout)
                        langs=[]
                        for lcode in (str(trailer_locale or "en").split("-",1)[0].lower(),str(cfg.get("tmdb_language","ar-EG")).split("-",1)[0].lower(),"ar","en","null"):
                            if lcode and lcode not in langs:langs.append(lcode)
                        payload=client._get("/%s/%s/videos"%(media,int(resolved_tid)),{"include_video_language":",".join(langs)}) or {}
                        picked_list=_pick_tmdb_youtube_trailers(payload,trailer_locale,limit=4)
                        if not picked_list:
                            payload_all=client._get("/%s/%s/videos"%(media,int(resolved_tid)),{}) or {}
                            picked_list=_pick_tmdb_youtube_trailers(payload_all,trailer_locale,limit=4)
                        existing_keys=set(c.get("key") for c in candidates)
                        for picked in (picked_list or []):
                            pkey=str(picked.get("trailer_key") or "")
                            if pkey and pkey not in existing_keys:
                                existing_keys.add(pkey)
                                candidates.append({
                                    "site":"YouTube","key":pkey,
                                    "name":str(picked.get("trailer_name") or "Trailer"),
                                    "url":str(picked.get("trailer_url") or ""),
                                    "official":bool(picked.get("trailer_official")),
                                    "language":str(picked.get("trailer_language") or ""),
                                    "policy_language":trailer_language,
                                })
                    if not candidates:
                        result={"state":"missing","tmdb_id":resolved_tid}
                    else:
                        from .trailer_runtime import resolve_youtube_trailer_candidates
                        chosen_trailer=candidates[0]
                        streams=[]
                        for cand in candidates:
                            if cancel_event.is_set():return
                            streams=resolve_youtube_trailer_candidates(cand.get("key"),timeout=max(14,timeout+4),cancel_event=cancel_event)
                            if streams:
                                chosen_trailer=cand
                                break
                        if cancel_event.is_set():return
                        if streams:
                            result={"state":"ready","trailer":chosen_trailer,"stream":streams[0],"fallbacks":streams[1:],"tmdb_id":resolved_tid}
                        else:
                            result={"state":"resolver_unavailable","trailer":chosen_trailer,"tmdb_id":resolved_tid}
            except Exception as exc:
                result={"state":"error","error":exc}
            if cancel_event.is_set():return
            def deliver():
                owner=owner_ref()
                if owner is None or getattr(owner,"_screen_closed",False):return
                if token!=int(getattr(owner,"_grid_trailer_token",0) or 0):return
                owner._grid_trailer_busy=False
                if result.get("tmdb_id") not in (None,"") and isinstance(item_ref,dict):
                    item_ref.setdefault("_locked_tmdb_id",result.get("tmdb_id"))
                    item_ref.setdefault("tmdb_id",result.get("tmdb_id"))
                state=str(result.get("state") or "")
                trailer=result.get("trailer") if isinstance(result.get("trailer"),dict) else {}
                if state=="missing":
                    if isinstance(item_ref,dict):
                        item_ref["_trailer_checked"]=True;item_ref["trailer_policy_language"]=trailer_language
                    try:owner["status"].setText(_("No trailer available"))
                    except Exception:pass
                    return
                if trailer:owner._grid_remember_trailer(item_ref,trailer,trailer_language)
                if state!="ready" or not result.get("stream"):
                    if state=="error":
                        try:optional_failure("ui.grid_trailer",result.get("error"))
                        except Exception:pass
                    try:owner["status"].setText(_("Trailer found, but no native 1080p/720p stream is available"))
                    except Exception:pass
                    return
                try:owner["status"].setText(_("Opening trailer..."))
                except Exception:pass
                try:owner._open_selected_trailer_stream(item_ref,result.get("stream"),trailer,result.get("fallbacks"))
                except Exception as exc:
                    optional_failure("ui.grid_trailer_open",exc)
                    try:owner["status"].setText(_("Trailer playback failed"))
                    except Exception:pass
            try:reactor.callFromThread(deliver)
            except Exception:
                try:deliver()
                except Exception:pass

        try:
            thread=threading.Thread(target=worker,name="UltraGridTrailerResolve")
            thread.daemon=True;thread.start()
        except Exception as exc:
            self._grid_trailer_busy=False
            optional_failure("ui.grid_trailer_thread",exc)
            try:self["status"].setText(_("Trailer playback failed"))
            except Exception:pass
