# -*- coding: utf-8 -*-
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str, int, max, min, us_casefold
"""Poster Grid 2 resident metadata: no I/O, decode or network on paint."""
from .age_rating import display_certification
OrderedDict = _us_env.collections.OrderedDict
re = _us_env.re

_METADATA_FIELDS = ("_tmdb_rating", "rating", "rating_imdb", "imdb_rating", "vote_average", "year", "release_date", "first_air_date", "certification", "age_rating", "_age_rating_checked", "number_of_seasons", "seasons_count", "season_count")

_GLOBAL_BADGE_METADATA = OrderedDict()
_BADGE_LOCK = _us_env.threading.RLock()


def _extract_valid_score(*values):
    for val in values:
        if isinstance(val, bool) or val in (None, ""):
            continue
        m = re.search(r"\d+(?:\.\d+)?", str(val))
        if m:
            try:
                score = float(m.group(0))
                if 0.0 < score <= 10.0:
                    return score
            except Exception:
                pass
    return 0.0


def merge_badge_metadata(screen, item, row):
    """Merge only the selected, validated row's independent badge fields."""
    if not isinstance(item, dict) or not isinstance(row, dict) or not row:
        return
    known = item.get("_locked_tmdb_id") or item.get("_ultra_search_verified_tmdb_id")
    incoming = row.get("tmdb_id") or row.get("_locked_tmdb_id")
    if known and incoming and str(known) != str(incoming):
        return
    if incoming and (known or row.get("identity_verified") or row.get("identity_pointer_verified") or row.get("_details_authority_ready")):
        item["_locked_tmdb_id"] = incoming
    if row.get("_age_rating_checked") and not display_certification(row.get("certification") or row.get("age_rating")):
        item.pop("certification", None)
        item.pop("age_rating", None)
    for field in _METADATA_FIELDS:
        value = row.get(field)
        if value not in (None, "", [], {}) and not (isinstance(value, bool) and field != "_age_rating_checked"):
            item[field] = value
    score = _extract_valid_score(
        row.get("_tmdb_rating"),
        row.get("vote_average"),
        row.get("rating"),
        row.get("rating_imdb"),
        row.get("imdb_rating"),
    )
    if 0.0 < score <= 10.0:
        item["_tmdb_rating"] = score
    seed_badge_metadata(screen, item)


def _tmdb_badge_key(screen, item):
    if not isinstance(item, dict):
        return ""
    tid = item.get("_locked_tmdb_id") or item.get("_ultra_search_verified_tmdb_id") or item.get("tmdb_id") or item.get("tmdbid") or item.get("tmdb")
    if tid not in (None, ""):
        mt = "tv" if str(getattr(screen, "media_type", "")).lower() in ("series", "tv") else "movie"
        return "tmdb:%s:%s" % (mt, str(tid).strip())
    return ""


def _title_badge_key(screen, item):
    if not isinstance(item, dict):
        return ""
    try:
        from .title_clean import catalogue_title
        raw = str(item.get("_raw_name") or item.get("name") or item.get("title") or "").strip()
        clean = re.sub(r"\s+", " ", us_casefold(catalogue_title(raw)).strip()) if raw else ""
        if not clean:
            return ""
        mt = "tv" if str(getattr(screen, "media_type", "")).lower() in ("series", "tv") else "movie"
        year = ""
        for yk in ("year", "release_date", "first_air_date"):
            m = re.search(r"(?:19|20)\d{2}", str(item.get(yk) or ""))
            if m:
                year = m.group(0)
                break
        return "title:%s:%s:%s" % (mt, clean, year)
    except Exception:
        return ""


def seed_badge_metadata(screen, item):
    with _BADGE_LOCK:
        """Restore resolved metadata before first paint and prefetch gates, RAM only."""
        key = screen._page_visual_key(item)
        if not key:
            return
        cache = getattr(screen, "_premium_badge_metadata", None)
        if cache is None:
            cache = screen._premium_badge_metadata = OrderedDict()
        tkey = _tmdb_badge_key(screen, item)
        title_key = _title_badge_key(screen, item)
        cached = {}
        if title_key and title_key in _GLOBAL_BADGE_METADATA:
            cached.update(_GLOBAL_BADGE_METADATA.get(title_key) or {})
        if tkey and tkey in _GLOBAL_BADGE_METADATA:
            cached.update(_GLOBAL_BADGE_METADATA.get(tkey) or {})
        cached.update(cache.get(key, {}))
        if item.get("_age_rating_checked") and not (item.get("certification") or item.get("age_rating")):
            cached.pop("certification", None)
            cached.pop("age_rating", None)
        for field, value in cached.items():
            if item.get(field) in (None, "", 0, False):
                item[field] = value
        if not (0.0 < _extract_valid_score(item.get("_tmdb_rating")) <= 10.0):
            fallback_score = _extract_valid_score(
                item.get("vote_average"),
                item.get("rating"),
                item.get("rating_imdb"),
                item.get("imdb_rating"),
                cached.get("_tmdb_rating"),
                cached.get("vote_average"),
                cached.get("rating"),
            )
            if 0.0 < fallback_score <= 10.0:
                item["_tmdb_rating"] = fallback_score
        resolved = dict(cached)
        for field in _METADATA_FIELDS:
            value = item.get(field)
            if value not in (None, "", 0, False) or (field == "number_of_seasons" and value == 0):
                resolved[field] = value
        if resolved:
            cache[key] = resolved
            cache.move_to_end(key)
            while len(cache) > 1024:
                cache.popitem(last=False)
            for gkey in (_tmdb_badge_key(screen, item), _title_badge_key(screen, item)):
                if gkey:
                    _GLOBAL_BADGE_METADATA[gkey] = dict(resolved)
                    _GLOBAL_BADGE_METADATA.move_to_end(gkey)
                    while len(_GLOBAL_BADGE_METADATA) > 2048:
                        _GLOBAL_BADGE_METADATA.popitem(last=False)


def badge_values(screen, item):
    try:
        year = int(screen._folder_year_value(item) or 0)
    except Exception:
        year = 0
    try:
        score = float(screen._folder_rating_value(item) or 0)
    except Exception:
        score = 0
    age = display_certification(item.get("certification") or item.get("age_rating"))
    try:
        seasons = int(item.get("number_of_seasons") or item.get("seasons_count") or item.get("season_count") or 0)
    except Exception:
        seasons = 0
    return {
        "year": str(year) if year > 0 else "",
        "score": "%.1f" % min(10, score) if score > 0 else "",
        "age": age or "",
        "seasons": str(seasons) if screen.media_type == "series" and seasons > 0 else "",
    }


def paint_badges(screen, item, pos):
    seed_badge_metadata(screen, item)
    values = badge_values(screen, item)
    for key, value in values.items():
        label = screen["item_%s%d" % (key, pos)]
        label.setText(value)
        (label.show if value else label.hide)()
        bg = screen["item_%s_bg%d" % (key, pos)]
        (bg.show if value else bg.hide)()
    for key, present in (("star", bool(values["score"])), ("seasons_icon", bool(values["seasons"]))):
        icon = screen["item_%s%d" % (key, pos)]
        (icon.show if present else icon.hide)()
    screen["item_meta%d" % pos].hide()
    return any(values.values())
