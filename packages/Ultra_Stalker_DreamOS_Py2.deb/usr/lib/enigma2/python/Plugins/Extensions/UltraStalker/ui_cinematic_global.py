# -*- coding: utf-8 -*-
"""Global-library-only Cinematic presentation for Movies and Series.

Hard rule: this screen never calls TMDB/network resolver.  It is a renderer over
PremiumGridBase catalogue/navigation plus the one persistent Global TMDB Library.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str, int, round, max, min, us_func
from .adaptive_mode import accent_hex, adaptive_enabled
from . import _
from .ui_floating_notice import show_notice
from .age_rating import display_certification
from Screens.MessageBox import MessageBox
from .localization import current_language
import tempfile, unicodedata, weakref, logging, math; hashlib = _us_env.hashlib; json = _us_env.json; os = _us_env.os; queue = _us_env.queue; time = _us_env.time; threading = _us_env.threading; shutil = _us_env.shutil; re = _us_env.re
deque = _us_env.collections.deque
from .core.executor import LazyThreadPoolExecutor
from .core.shared_executors import CATALOGUE_EXECUTOR, METADATA_EXECUTOR
try:
    from PIL import Image as _PILImage, ImageDraw as _ImageDraw, ImageFilter as _ImageFilter
except Exception:
    _PILImage=None;_ImageDraw=None;_ImageFilter=None
try:
    from enigma import gFont, ePoint, eSize
except Exception:
    gFont=None; ePoint=None; eSize=None
try:
    from enigma import eLabel
except Exception:
    eLabel=None
try:
    from skin import parseColor as _cin_parse_color
except Exception:
    _cin_parse_color=None

# Fast backdrop transport is Ultra-owned and independent of presentation logic.
# It keeps Enigma2's proven Twisted reactor/Agent network engine while the
# selection, cache policy and presentation remain Ultra Stalker code.
from .backdrop_transport import FastBackdropTransport
from .shared_tmdb_cache import backdrop_path as _shared_backdrop_path, cached_backdrop as _shared_cached_backdrop, fetch_backdrop as _shared_fetch_backdrop

from .ui_grid_base import PremiumGridBase, _page_backdrop_fetch_original_q60
from .ui_async import AsyncScreenMixin
from .artwork_v2 import load_manifest, ArtworkV2, save_manual_rescue_art, canonical_art_paths, _download as _artwork_download
from .tmdb import TMDBClient
from .fanart import fetch_artwork as _fanart_fetch
from .storage import load_settings, load_api_keys
from .persistent_cache import ROOT, BACKDROPS, GENERATED, INDEX, BLUE_CACHE, TITLE_LOGOS, ADAPTIVE, VIEWS, ensure_persistent_dirs, durable_view_path, load_detail_snapshot, load_detail_snapshot_by_tmdb, hdd_read_ready, hdd_ready
from .media_library import readiness as _library_readiness, metadata_complete as _metadata_complete, load as _media_library_load, save as _media_library_save, ensure_adaptive as _media_library_ensure_adaptive
from .core.image_budget import image_budgeted
from .ui_clean_glass import glass as _cg_glass
from .ui_dynamic_chrome import _cached_dynamic_details_chrome
from .ui_dynamic_chrome import _build_category_extended_backdrop, _build_dynamic_settings_episode_rows, _cached_dynamic_settings_episode_rows, _build_dynamic_details_chrome, canonical_dynamic_details_key, canonical_dynamic_rows_key, _dynamic_palette, _lift_dynamic_accent, _mix_rgb
from .ui_fixed_adaptive import fixed_settings_rows, fixed_exact_surface
from .ui_fixed_glass import fixed_details_chrome as _fixed_content_details_chrome
from .log import optional_failure
from .title_clean import display_title as _catalogue_title
from .ui_icon_menu import IconMenuList
from .ui_settings_inline_choice import SettingsInlineChoiceOverlay
from .ui_parts.catalog import strip_arabic_tashkeel as _shared_strip_arabic_tashkeel
from .ui_parts.catalog import clean_person_name as _clean_person_name
_CIN_TITLE_LOGO_API = None
def _cin_title_logo_api():
    global _CIN_TITLE_LOGO_API
    if _CIN_TITLE_LOGO_API is None:
        from .title_logo_ultra import resolve_ultra_title_logo, ultra_title_logo_cached
        _CIN_TITLE_LOGO_API = (resolve_ultra_title_logo, ultra_title_logo_cached)
    return _CIN_TITLE_LOGO_API

def resolve_ultra_title_logo(*args, **kwargs):
    return _cin_title_logo_api()[0](*args, **kwargs)
def ultra_title_logo_cached(*args, **kwargs):
    return _cin_title_logo_api()[1](*args, **kwargs)
from .services.player_visuals import _adaptive_player_frames, _progress_neon_frame

CINEMATIC_GLOBAL_SKIN=""
_CIN_HYBRID_EXECUTOR=LazyThreadPoolExecutor(max_workers=1, thread_name_prefix="ultrastalker-cinematic-hybrid")
_CIN_PAGE_EXECUTOR=CATALOGUE_EXECUTOR
_FAST_BACKDROP_META_EXECUTOR=LazyThreadPoolExecutor(max_workers=2, thread_name_prefix="ultrastalker-fast-backdrop-meta")
_HQ_BACKDROP_EXECUTOR=LazyThreadPoolExecutor(max_workers=1, thread_name_prefix="ultrastalker-hq-backdrop")


def _age_rating_display(value):
    return display_certification(value)
# Feature gate retained for receiver A/B safety.
_FAST_BACKDROP_ENABLED=True
# R196 legacy raw ORIGINAL cache is kept untouched for rollback/reference.
_R196_ORIGINAL_ROOT=os.path.join(ROOT,"cinematic_original_v196")
# R242 isolated storage experiment: first paint still uses the exact TMDb ORIGINAL
# bytes, but HDD persistence stores only a decoder-friendly Full-HD JPEG.  The raw
# ORIGINAL lives in /tmp for the active session and is removed by the existing
# fast-backdrop cleanup, so the old R196 folder is never mutated by this test.
_R242_FULLHD_ROOT=BACKDROPS
_R242_FULLHD_EXECUTOR=LazyThreadPoolExecutor(max_workers=1, thread_name_prefix="ultrastalker-r242-fullhd")
_R242_FULLHD_LOCK=threading.RLock()
_R242_FULLHD_PENDING=set()
# Issue 10: Cinematic/BG1/BG2 share one decoder-ready backdrop authority.
# The canonical master lives in ArtworkV2; this executor only prepares the one
# presentation JPEG in the background so switching view modes never requires
# another Cache Artwork pass.
_SHARED_CIN_BACKDROP_EXECUTOR=LazyThreadPoolExecutor(max_workers=1, thread_name_prefix="ultrastalker-shared-backdrop")
_SHARED_CIN_BACKDROP_LOCK=threading.RLock()
_SHARED_CIN_BACKDROP_PENDING=set()
# R151 root authority: one persistent decoder-ready cache shared by Cinematic,
# Backdrop Grid 1 and Backdrop Grid 2.  Unlike GENERATED, BLUE_CACHE survives
# Enigma2 restarts, so a completed Cache Artwork pass stays genuinely hot.
_THREE_VIEW_FAST_ROOT=os.path.join(BLUE_CACHE,"three_view_fast_v151")
_CIN_PACKAGE_DIR=os.path.join(VIEWS,"cinematic_packages")
_THREE_VIEW_FAST_SCHEMA=1

def _cinematic_menu_scrim_skin(skin):
    value=str(skin or "")
    if 'name="settings_menu_scrim"' in value:
        return value
    from .wqhd_layout import scale_skin as _scale_new_widgets
    widget=_scale_new_widgets('\n <widget name="settings_menu_scrim" position="0,0" size="1920,1080" alphatest="blend" scale="1" transparent="1" zPosition="29"/>\n')
    marker='<widget name="settings_menu_list"'
    pos=value.find(marker)
    if pos>=0:
        return value[:pos]+widget+value[pos:]
    return value.replace('</screen>',widget+'</screen>',1)


def configure_cinematic_global(**deps):
    globals().update(deps)
    for _mixin_module in _MIXIN_MODULES:
        _mixin_module.__dict__.update(deps)
    if "CINEMATIC_GLOBAL_SKIN" in deps:
        PremiumGlobalCinematicScreen.skin=_cinematic_menu_scrim_skin(deps["CINEMATIC_GLOBAL_SKIN"])


def _strip_arabic_tashkeel(value):
    """Use the exact Details description display policy."""
    return _shared_strip_arabic_tashkeel(value)

_CIN_ARAB_CAST_COUNTRY_TOKENS={"EG","LB","SA","AE","KW","QA","BH","OM","JO","SY","IQ","PS","YE","MA","DZ","TN","LY","SD"}


def _hex_rgb(value, fallback=(202,145,65)):
    value=str(value or "").strip().lstrip("#")
    if len(value)==6:
        try:return tuple(int(value[i:i+2],16) for i in (0,2,4))
        except Exception:pass
    return fallback

@image_budgeted
def _build_cinematic_backdrop(source,target,accent_hex):
    """Build the Cinematic presentation backdrop from the one global HDD image."""
    if _PILImage is None or not source or not os.path.isfile(source):return ""
    if os.path.isfile(target) and os.path.getsize(target)>1024:return target
    if not ensure_persistent_dirs(os.path.dirname(target)):return ""
    temp=target+".tmp.%d.%d"%(os.getpid(),threading.get_ident());accent=_hex_rgb(accent_hex,(38,28,18))
    try:
        tw,th=1920,1080;res=getattr(getattr(_PILImage,"Resampling",_PILImage),"LANCZOS",1)
        with _PILImage.open(source) as src:
            src=src.convert("RGB")
            if src.width<16 or src.height<16:return ""
            scale=max(float(tw)/src.width,float(th)/src.height);nw=max(tw,int(round(src.width*scale)));nh=max(th,int(round(src.height*scale)))
            src=src.resize((nw,nh),res);left=max(0,min(nw-tw,int((nw-tw)*0.58)));top=max(0,(nh-th)//2);src=src.crop((left,top,left+tw,top+th)).convert("RGBA")
        src=_PILImage.alpha_composite(src,_PILImage.new("RGBA",(tw,th),(accent[0]//5,accent[1]//5,accent[2]//5,24)))
        # Premium left rail veil: strong enough to keep the floating rows
        # readable, but feathered so the backdrop never exposes a hard edge.
        left_alpha=[]
        for x in range(780):
            t=float(x)/779.0;left_alpha.append(max(0,min(255,int(236*((1.0-t)**1.85)))))
        la=_PILImage.new("L",(780,1));la.putdata(left_alpha);la=la.resize((780,th))
        veil=_PILImage.new("RGBA",(tw,th),(2,6,10,0));veil.putalpha(_PILImage.new("L",(tw,th),0));veil.alpha_composite(_PILImage.merge("RGBA",(_PILImage.new("L",(780,th),2),_PILImage.new("L",(780,th),6),_PILImage.new("L",(780,th),10),la)),(0,0))
        src=_PILImage.alpha_composite(src,veil)
        # match the approved older composition.  The backdrop is strong
        # above the details area, then genuinely fades OUT into a dark adaptive
        # page plane.  Do not merely darken a full-screen wallpaper; the lower
        # area must read as UI background carrying a restrained current-title hue.
        art_alpha=[]
        fade_start,fade_end=470.0,900.0
        for y in range(th):
            if y<=fade_start:a=255
            elif y>=fade_end:a=0
            else:
                tt=(float(y)-fade_start)/(fade_end-fade_start);smooth=tt*tt*(3.0-2.0*tt);a=int(255*(1.0-smooth))
            art_alpha.append(max(0,min(255,a)))
        aa=_PILImage.new("L",(1,th));aa.putdata(art_alpha);aa=aa.resize((tw,th))
        if _ImageFilter is not None:
            try:aa=aa.filter(_ImageFilter.GaussianBlur(radius=9))
            except Exception:pass
        src.putalpha(aa)
        # dark adaptive footer, visibly tied to the selected title while still cinematic.
        mood=(max(5,int(accent[0]*0.18)),max(7,int(accent[1]*0.18)),max(10,int(accent[2]*0.18)),255)
        base=_PILImage.new("RGBA",(tw,th),mood)
        # A very subtle vertical lift keeps the footer premium rather than flat.
        md=_ImageDraw.Draw(base) if _ImageDraw is not None else None
        if md is not None:
            lower=(max(4,int(accent[0]*0.12)),max(6,int(accent[1]*0.12)),max(9,int(accent[2]*0.12)),255)
            md.rectangle((0,760,tw,th),fill=lower)
            for yy in range(760,th,12):
                t=(yy-760)/float(max(1,th-760));a=max(0.0,1.0-t)
                col=(max(lower[0],int(accent[0]*(0.16+0.06*a))),
                     max(lower[1],int(accent[1]*(0.16+0.06*a))),
                     max(lower[2],int(accent[2]*(0.16+0.06*a))),255)
                md.rectangle((0,yy,tw,min(th,yy+12)),fill=col)
        src=_PILImage.alpha_composite(base,src)
        src.save(temp,"PNG",compress_level=3);os.replace(temp,target);return target
    except Exception as exc:
        optional_failure("cinematic.backdrop",exc)
        try:
            if os.path.exists(temp):os.unlink(temp)
        except Exception:pass
        return ""


def _prepare_shared_cinematic_backdrop(source,key,row=None,build=True,accent_hint=""):
    """R259 single-backdrop authority.

    Never build/copy/recompress a view-specific backdrop.  The already prepared
    backdrop file itself is the one display authority for Cinematic, BG1 and BG2.
    In the normal focus lane this is the R249/R251 Full-HD Q60 file under
    /media/hdd/UltraStalker/backdrops.
    """
    source=str(source or "").strip()
    try:
        return source if source and os.path.isfile(source) and os.path.getsize(source)>1024 else ""
    except Exception:
        return ""


_COUNTRY_NAMES = {
    "EG":"مصر","LB":"لبنان","SA":"السعودية","AE":"الإمارات","KW":"الكويت","QA":"قطر","BH":"البحرين","OM":"عُمان","JO":"الأردن","SY":"سوريا","IQ":"العراق","PS":"فلسطين","YE":"اليمن","MA":"المغرب","DZ":"الجزائر","TN":"تونس","LY":"ليبيا","SD":"السودان","US":"USA","GB":"UK","FR":"France","DE":"Germany","IT":"Italy","ES":"Spain","TR":"Turkey","IN":"India","KR":"Korea","JP":"Japan","CN":"China","CA":"Canada","MX":"Mexico","BR":"Brazil","AR":"Argentina","RU":"Russia","AU":"Australia"
}
_COUNTRY_CODES_EN = {
    "EG":"EG","LB":"LB","SA":"KSA","AE":"UAE","KW":"KW","QA":"QA","BH":"BH","OM":"OM","JO":"JO","SY":"SY","IQ":"IQ","PS":"PS","YE":"YE","MA":"MA","DZ":"DZ","TN":"TN","LY":"LY","SD":"SD",
    "US":"USA","GB":"UK","FR":"FR","DE":"DE","IT":"IT","ES":"ES","TR":"TR","IN":"IN","KR":"KR","JP":"JP","CN":"CN","CA":"CA","MX":"MX","BR":"BR","AR":"AR","RU":"RU","AU":"AU"
}

def _country_code(value):
    if isinstance(value,(list,tuple,set)):
        for row in value:
            code=_country_code(row)
            if code:return code
        return ""
    if isinstance(value,dict):
        for key in ("iso_3166_1","country_code","code","name"):
            code=_country_code(value.get(key))
            if code:return code
        return ""
    raw=str(value or "").strip()
    if not raw:return ""
    upper=raw.upper().strip()
    if upper=="IL":return ""
    aliases={
        "EGYPT":"EG","ARAB REPUBLIC OF EGYPT":"EG","مصر":"EG","جمهورية مصر العربية":"EG",
        "LEBANON":"LB","لبنان":"LB","SAUDI ARABIA":"SA","السعودية":"SA",
        "UNITED ARAB EMIRATES":"AE","UAE":"AE","الإمارات":"AE",
        "UNITED STATES":"US","UNITED STATES OF AMERICA":"US","USA":"US",
        "UNITED KINGDOM":"GB","GREAT BRITAIN":"GB","UK":"GB",
        "TURKEY":"TR","TÜRKIYE":"TR","TURKIYE":"TR",
        "SOUTH KOREA":"KR","REPUBLIC OF KOREA":"KR","KOREA":"KR",
        "NORTH KOREA":"KP","JAPAN":"JP","CHINA":"CN","INDIA":"IN",
        "FRANCE":"FR","GERMANY":"DE","ITALY":"IT","SPAIN":"ES",
        "CANADA":"CA","MEXICO":"MX","BRAZIL":"BR","ARGENTINA":"AR",
        "RUSSIA":"RU","RUSSIAN FEDERATION":"RU","AUSTRALIA":"AU",
        "KUWAIT":"KW","QATAR":"QA","BAHRAIN":"BH","OMAN":"OM",
        "JORDAN":"JO","SYRIA":"SY","IRAQ":"IQ","PALESTINE":"PS",
        "MOROCCO":"MA","ALGERIA":"DZ","TUNISIA":"TN","LIBYA":"LY","SUDAN":"SD"
    }
    if upper in aliases:return aliases[upper]
    for code,name in _COUNTRY_NAMES.items():
        if upper==str(name).upper():return code
    if len(upper)==2 and upper.isalpha():return upper
    return ""

def _normalized_country(value):
    code=_country_code(value);raw=str(value or "").strip()
    if current_language()=="en":
        return _COUNTRY_CODES_EN.get(code,code or (raw[:12] if raw else ""))
    return _COUNTRY_NAMES.get(code,raw[:12] if raw else "")

def _quality_asset_name(value):
    """Legacy quality artwork retired; metadata shows age certification."""
    return None


@image_budgeted
def _cinematic_row_progress_cached(value, width=300):
    """Path of an already-built flat bar (no Pillow, no write); '' if absent."""
    try:
        value=max(0,min(100,int(value)));w=max(80,min(600,int(width or 300)))
        target=durable_view_path("flat_%03d_%03d.png"%(value,w),"cinematic_row_progress_flat175")
        return target if (os.path.isfile(target) and os.path.getsize(target)>128) else ""
    except Exception:
        return ""


def _cinematic_row_progress_frame(accent_hex, value, width=300):
    """Flat silver watch-progress bar for Cinematic / Episode rows (R5.175).

    Replaces the old laser + glowing head.  Rounded translucent track with a soft
    silver fill and a faint top highlight; no glow, no head dot.  The canvas keeps
    the old 34px height so row geometry is unchanged, and the track leaves a
    24px right margin like the old beam did (the percentage text sits there).
    Enigma2 MultiContent clips instead of scaling, so it is rendered at the row's
    real width (7% really is 7%).
    """
    if _PILImage is None or _ImageDraw is None:return ""
    try:
        value=max(0,min(100,int(value)))
        w=max(80,min(600,int(width or 300)));h=34
        target=durable_view_path("flat_%03d_%03d.png"%(value,w),"cinematic_row_progress_flat175")
        root=os.path.dirname(target)
        if not ensure_persistent_dirs(root):return ""
        if os.path.isfile(target) and os.path.getsize(target)>128:return target
        S=4;bar_h=7;track_w=w-24;y0=(h-bar_h)//2
        big=_PILImage.new("RGBA",(w*S,h*S),(0,0,0,0));d=_ImageDraw.Draw(big)
        r=bar_h*S//2
        x0=2*S;x1=(2+track_w)*S
        d.rounded_rectangle((x0,y0*S,x1,(y0+bar_h)*S-1),r,fill=(255,255,255,46))
        if value>0:
            fw=max(bar_h*S,int((x1-x0)*value/100.0))
            fill=_PILImage.new("RGBA",(fw,bar_h*S));fd=_ImageDraw.Draw(fill)
            for k in range(fw):
                t=k/float(max(1,fw-1));c=int(200+40*t);fd.line([(k,0),(k,bar_h*S)],fill=(c,c,min(255,c+10),240))
            mask=_PILImage.new("L",(fw,bar_h*S),0);_ImageDraw.Draw(mask).rounded_rectangle((0,0,fw-1,bar_h*S-1),r,fill=255)
            big.paste(fill,(x0,y0*S),mask)
            d.rounded_rectangle((x0+r//2,y0*S+S//2,x0+fw-r//2,y0*S+S+S//2),S//2,fill=(255,255,255,120))
        resample=getattr(getattr(_PILImage,"Resampling",_PILImage),"LANCZOS",1)
        img=big.resize((w,h),resample)
        temp=target+".tmp.%d.%d"%(os.getpid(),threading.get_ident());img.save(temp,"PNG");os.replace(temp,target);return target
    except Exception as exc:
        optional_failure("cinematic.row_progress_frame",exc);return ""

# Split: related method groups live in ui_cine_mixin_*.py modules. They are imported here, after every module-level helper above exists,
# and listed BEFORE the other bases so they override them exactly like the methods that used to sit in this class body.
from .ui_cine_mixin_surfaces import CineSurfacesMixin
from .ui_cine_mixin_init import CineInitMixin
from .ui_cine_mixin_hqbackdrop import CineHqBackdropMixin
from .ui_cine_mixin_menu import CineMenuMixin
from .ui_cine_mixin_fastbd import CineFastBdMixin
from .ui_cine_mixin_logo import CineLogoMixin
from .ui_cine_mixin_paging import CinePagingMixin
from .ui_cine_mixin_adaptive import CineAdaptiveMixin
from .ui_cine_mixin_lifecycle import CineLifecycleMixin
from .ui_cine_mixin_assets import CineAssetsMixin
from .ui_cine_mixin_package import CinePackageMixin
from .ui_cine_mixin_blue import CineBlueMixin
from .ui_cine_mixin_records import CineRecordsMixin
from .ui_cine_mixin_gridui import CineGridUiMixin
from .ui_cine_mixin_poll import CinePollMixin
from .ui_cine_mixin_fit import CineFitMixin
from .ui_cine_mixin_apply import CineApplyMixin
import sys as _split_sys
_MIXIN_MODULES = tuple(_split_sys.modules[_m.__module__] for _m in (CineSurfacesMixin, CineInitMixin, CineHqBackdropMixin, CineMenuMixin, CineFastBdMixin, CineLogoMixin, CinePagingMixin, CineAdaptiveMixin, CineLifecycleMixin, CineAssetsMixin, CinePackageMixin, CineBlueMixin, CineRecordsMixin, CineGridUiMixin, CinePollMixin, CineFitMixin, CineApplyMixin,))


class PremiumGlobalCinematicScreen(
    CineSurfacesMixin,
    CineInitMixin,
    CineHqBackdropMixin,
    CineMenuMixin,
    CineFastBdMixin,
    CineLogoMixin,
    CinePagingMixin,
    CineAdaptiveMixin,
    CineLifecycleMixin,
    CineAssetsMixin,
    CinePackageMixin,
    CineBlueMixin,
    CineRecordsMixin,
    CineGridUiMixin,
    CinePollMixin,
    CineFitMixin,
    CineApplyMixin,
    PremiumGridBase,
):
    """Cinematic list presentation over the exact same Global TMDB record."""
    artwork_cache_backdrops = True

    shared_footer=True
    wide_section_path=True
    skin=CINEMATIC_GLOBAL_SKIN
    columns=1;page_size=12;image_size=(1,1);placeholder="grid_placeholder_movie_921.png";selection_asset="portal_selection_clear.png"
    card_positions=[(50,130+i*73) for i in range(12)]

    def __init__(self,session,profile,client,media_type,genre,category_title="",initial_search=""):
        self._cin_record_key="";self._cin_visual_key="";self._cin_jobs=queue.Queue();self._cin_pending=set();self._cin_last_record={};self._cin_row_refresh_cursor=0;self._cin_row_complete=set();self._cin_page_records={};self._cin_committed_adaptive_key=""
        self._cin_adaptive_generation=0;self._cin_adaptive_target_sig="";self._cin_adaptive_cancel=None;self._cin_visual_future=None
        # R224 Stage 3: visible adaptive material is owned by one selected title.
        self._cin_display_adaptive_owner_sig="";self._cin_nav_adaptive_pending_sig=""
        self._cin_fixed_progress_accent="#75d2ab"
        # R214 Stage 1: Cinematic cold paint starts from the exact bundled fixed-green
        # application material.  This is a static packaged asset lookup only; no
        # palette/Pillow/network work is allowed before the first title settles.
        # R5.232: first paint now uses the exact old fixedoff2 / Premium Dark
        # material that R5.230 used to manufacture only after the page settled.
        # It is bundled in fixed_green_details, so OFF mode has zero palette/Pillow
        # work and no dark->light handoff. The old R63 utility row is fallback only.
        _fixed_rows=fixed_settings_rows() or {}
        _fixed_content=_fixed_content_details_chrome() or {}
        self._settings_row_asset=str(_fixed_content.get("series_row") or _fixed_rows.get("normal") or asset("series_floating_row.png"))
        self._settings_row_selected_asset=str(_fixed_content.get("series_row_selected") or _fixed_rows.get("selected") or self._settings_row_asset)
        self._cin_fixed_row_asset=self._settings_row_asset
        self._cin_fixed_row_selected_asset=self._settings_row_selected_asset
        self._cin_adaptive_rows_active=False
        self._cin_off_committed=not adaptive_enabled()
        self._cin_progress_accent="#75d2ab"
        # hybrid policy: only the focused title may hydrate while browsing.
        # Everything completed is persisted as one immutable HDD package and reused forever.
        self._cin_package_schema=5
        self._cin_focus_cancel=None;self._cin_focus_future=None;self._cin_focus_sig=""
        self._cin_fast_info_cancel=None;self._cin_fast_info_future=None;self._cin_fast_info_sig=""
        self._cin_background_cancel=None;self._cin_background_future=None
        self._cin_missed=deque();self._cin_missed_keys=set();self._cin_last_focus_item=None
        self._cin_last_nav_at=time.monotonic();self._cin_hidden=False
        # Stage 7: page navigation has a virtual destination independent of the
        # currently painted page. Remote key-repeat can therefore advance several
        # pages while one provider read is still pending, without replaying every
        # intermediate page afterwards.
        self._cin_page_nav_target=0
        self._cin_page_nav_row=0
        self._cin_page_nav_generation=0
        # One native full-screen backdrop widget, exactly like Backdrop Grid.
        # The old two-widget flip could invalidate neighbouring HUD gPixmaps on
        # some OpenBH/Broadcom receivers.  Keep the stage allocated only for skin
        # compatibility, but never use it for navigation swaps.
        self._cin_active_pixmap={"cin_backdrop":"cin_backdrop"};self._cin_pixmap_paths={};self._cin_widget_paths={};self._cin_suspended_visual_paths={}
        self._cin_shared_backdrop_retry=0
        # release: page-local trusted package/backdrop index. Navigation must never
        # open package JSON or scan the HDD after an arrow press. The tiny package
        # files are indexed once when the page is painted; only the selected JPEG
        # is decoded on demand.
        self._cin_page_packages={};self._cin_page_backdrops={}
        # R171 hot-page visual index: cached final adaptive + title-logo paths are
        # discovered once while the page is painted. Arrow navigation then stays
        # RAM-only and can swap these tiny already-decoded-file authorities
        # immediately, instead of waiting for the 850ms stable-focus lane.
        # release: provider-key aliases point straight at the FINAL prepared Cinematic backdrop.
        self._cin_nav_alias_ram={}
        self._cin_logo_pending=set();self._cin_logo_path="";self._cin_logo_cancel=None;self._cin_logo_active_sig=""
        self._cin_logo_executor=LazyThreadPoolExecutor(2,"ultrastalker-cinematic-logo")
        # Clean-room fast backdrop lane: same proven Twisted timing class as
        # R208 while selection, cache and presentation remain Ultra-owned.
        self._fast_bd_enabled=bool(_FAST_BACKDROP_ENABLED)
        self._fast_bd_req_id=0;self._fast_bd_deferred=None;self._fast_bd_path="";self._fast_bd_sig="";self._fast_bd_started_at=0.0;self._fast_bd_inflight=False
        self._fast_bd_meta_pending=set();self._fast_bd_meta_latest_sig="";self._fast_bd_fast_cache={};self._fast_bd_fast_order=deque();self._fast_bd_fast_limit=12;self._fast_bd_locked_sig="";self._fast_bd_locked_path=""
        self._fast_bd_transport=None
        if self._fast_bd_enabled:
            try:self._fast_bd_transport=FastBackdropTransport()
            except Exception as exc:optional_failure("cinematic.fast_backdrop_transport",exc)
        self._folder_artwork_worker_window=1
        self._cin_cache_exclusive=False
        self._folder_artwork_fast_art_only=False
        us_func(PremiumGridBase.__init__)(self,session,profile,client,media_type,genre,category_title,initial_search)
        # the right side is the native Details information cluster itself.
        # Catalogue/navigation/HDD hydration remain owned by PremiumGridBase.
        self["cin_backdrop"]=Pixmap()
        self["cin_backdrop_stage"]=Pixmap()
        self["title_logo"]=Pixmap()
        self["artwork_status_bg"]=Pixmap()
        for name in ("panel_bg","overview_bg","cast_card_bg","quality_pill_bg","year_pill_bg","runtime_pill_bg","country_pill_bg","genre_pill_bg","quality_logo","runtime_icon","country_flag"):
            self[name]=Pixmap()
        for name in ("name","quality_text","year_text","runtime_text","country_text","genre_text","age_rating_text","cast_text","description"):
            self[name]=Label("")
        # R199: exact R81 Cinematic rail. Native list rows own selection; no per-key geometry relayout.
        self["cin_list"]=IconMenuList([], width=430, item_height=70, icon_size=40, primary_font=21, secondary_font=15, row_style="settings_episode")
        self["settings_menu_scrim"]=Pixmap()
        try:self["settings_menu_scrim"].hide()
        except Exception:pass
        self._settings_inline_menu=SettingsInlineChoiceOverlay(self,"settings_menu_list","settings_menu_actions",asset,_,optional_failure)
        self._cin_list_icon=asset("settings_icons_40/artwork.png")
        self._cin_poll=eTimer();self._cin_poll_conn=None;self._cin_poll_interval=600
        try:self._cin_poll_conn=self._cin_poll.timeout.connect(self._cin_poll_hdd)
        except Exception:self._cin_poll.callback.append(self._cin_poll_hdd)
        # Warm Cinematic libraries can have a decoder-ready 1080p backdrop for
        # every row. Loading one on every key-repeat can overwhelm native image
        # surfaces. Move the highlight immediately, but bind the cached backdrop
        # only after navigation has been quiet briefly.
        self._cin_nav_backdrop_timer=eTimer();self._cin_nav_backdrop_conn=None
        try:self._cin_nav_backdrop_conn=self._cin_nav_backdrop_timer.timeout.connect(self._cin_apply_debounced_backdrop)
        except Exception:self._cin_nav_backdrop_timer.callback.append(self._cin_apply_debounced_backdrop)
        self._cin_nav_adaptive_timer=eTimer();self._cin_nav_adaptive_conn=None
        try:self._cin_nav_adaptive_conn=self._cin_nav_adaptive_timer.timeout.connect(self._cin_apply_nav_adaptive_baseline)
        except Exception:self._cin_nav_adaptive_timer.callback.append(self._cin_apply_nav_adaptive_baseline)
        self._cin_fast_info_timer=eTimer();self._cin_fast_info_conn=None
        try:self._cin_fast_info_conn=self._cin_fast_info_timer.timeout.connect(self._cin_apply_fast_info)
        except Exception:self._cin_fast_info_timer.callback.append(self._cin_apply_fast_info)
        # R5.234: Cinematic title-logo owns a short Poster-Grid-3-style lane.
        # Logo discovery starts after 180 ms of quiet focus; metadata follows at
        # 360 ms, so neither waits behind the old Details-heavy cadence.
        self._cin_fast_logo_timer=eTimer();self._cin_fast_logo_conn=None
        try:self._cin_fast_logo_conn=self._cin_fast_logo_timer.timeout.connect(self._cin_apply_fast_logo)
        except Exception:self._cin_fast_logo_timer.callback.append(self._cin_apply_fast_logo)
        self._cin_page_nav_timer=eTimer();self._cin_page_nav_conn=None
        try:self._cin_page_nav_conn=self._cin_page_nav_timer.timeout.connect(self._cin_commit_page_nav)
        except Exception:self._cin_page_nav_timer.callback.append(self._cin_commit_page_nav)
        self.onLayoutFinish.append(self._cin_layout_ready);self.onClose.append(self._cin_stop)
        try:self.onHide.append(self._cin_hidden_start)
        except Exception:pass
        self._refresh_search_sort_controls()
        self["blue"].setText(_("Cache Artwork"))
        # Exact SeriesEpisodes direction grammar. PremiumGridBase's grid left/right
        # means adjacent card; Cinematic is a vertical episode-style list, so
        # LEFT/RIGHT must page while UP/DOWN move one row with global wrap.
        self["actions"] = ActionMap(["OkCancelActions","ColorActions","DirectionActions","MenuActions","UltraStalkerMenuActions","InfoActions"], {
            "cancel":self.close,"red":self.open_folder_search,"ok":self.open_selected,
            "left":self._cin_page_left,"right":self._cin_page_right,
            "up":self._cin_wrap_up,"down":self._cin_wrap_down,
            "green":self.toggle_selected_favorite,"yellow":self.cycle_folder_sort,
            "blue":self.cache_folder_artwork,"menu":self.open_menu,"info":self.show_information},-1)


