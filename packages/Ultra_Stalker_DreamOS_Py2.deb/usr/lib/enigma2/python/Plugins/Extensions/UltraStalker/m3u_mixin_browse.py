# -*- coding: utf-8 -*-
"""Account info, genres, ordered listings and provider metadata merge.

Methods moved verbatim out of ``M3UClient`` (m3u_adapter.py); behaviour is unchanged.
This module is imported by m3u_adapter.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, max
from .m3u_adapter import (
    LOG,
    _lstrf,
    re,
    time,
)


class M3UBrowseMixin(object):
    """Account info, genres, ordered listings and provider metadata merge."""

    def authorize(self,cancel_event=None):
        try:
            self._ensure(cancel_event)
            self.token="m3u";return {"token":"m3u","source_type":"m3u"}
        except Exception as exc:
            self._last_error=str(exc);raise

    def health_snapshot(self):
        return {"health":"excellent" if self._loaded else "unknown","latency_ms":0,"last_error":self._last_error,"source_type":"m3u"}

    def _format_xtream_expiry(self, value):
        raw=str(value or "").strip()
        if not raw or raw in ("0","None","null","NULL"):
            return ""
        try:
            stamp=int(float(raw))
            if stamp <= 0:return ""
            return _lstrf("%B %d, %Y",time.localtime(stamp))
        except Exception:
            return raw

    def account_info(self):
        if self._mode=="xtream" and self._xtream:
            if not self._xtream_account:
                self._xtream_probe()
            user=self._xtream_account.get("user_info") if isinstance(self._xtream_account.get("user_info"),dict) else {}
            exp=self._format_xtream_expiry(user.get("exp_date"))
            return {
                "status":str(user.get("status") or "Active"),
                "account_status":str(user.get("status") or "Active"),
                "source_type":"m3u",
                "playlist_mode":"xtream",
                "expire_billing_date":exp,
                "end_date":exp,
                "active_cons":user.get("active_cons"),
                "max_connections":user.get("max_connections"),
                "playlist_items":sum(len(v) for v in self._items.values()) if self._loaded else 0,
            }
        self._ensure()
        return {"status":"Active","account_status":"Active","source_type":"m3u","playlist_mode":"m3u","playlist_items":sum(len(v) for v in self._items.values())}

    def _xtream_genre_rows(self, media_type):
        typ=str(media_type or "itv").lower()
        mapping=self._xtream_categories.get(typ,{}) or {}
        ids=self._xtream_category_ids.get(typ,{}) or {}
        rows=[]
        for name in self._genres.get(typ,[]) or []:
            cid=ids.get(str(name)) or ""
            if not cid:
                for raw_id,raw_name in mapping.items():
                    if str(raw_name)==str(name):
                        cid=str(raw_id);break
            rows.append({
                "id":str(cid or ""),
                "genre_id":str(cid or ""),
                "category_id":str(cid or ""),
                "title":str(name),
                "name":str(name),
                "_xtream":True,
            })
        return rows

    def genres(self,media_type="itv",cancel_event=None):
        typ=str(media_type or "itv").lower()
        drop=getattr(self,"_drop_stale_catalogue",None)
        if callable(drop):drop()
        # Splash already filled these maps. Do not pull the whole saved
        # catalogue into RAM just to paint folder names.
        if self._xtream and (typ in getattr(self,"_xtream_category_ready",set()) or self._genres.get(typ) or self._xtream_categories.get(typ)):
            self._mode="xtream"
            if typ=="itv":self._start_epg_prepare()
            return self._xtream_genre_rows(typ)
        self._ensure(cancel_event)
        if typ=="itv":self._start_epg_prepare()

        # Migration safety: older caches may contain visible genre names
        # but no Xtream provider category IDs. Without this, every folder falls
        # back to get_*_streams without category_id and shows the same catalogue.
        if self._mode=="xtream" and not (self._xtream_categories.get(typ) or {}):
            LOG.info("Xtream category mapping missing for %s; refreshing category bootstrap only",typ)
            self._load_xtream(cancel_event,media_type=typ)
            self._write_persistent()

        if self._mode=="xtream":
            mapping=self._xtream_categories.get(typ,{}) or {}
            rows=[]
            for name in self._genres.get(typ,[]):
                cid=self._xtream_category_ids.get(typ,{}).get(str(name))
                if not cid:
                    for raw_id,raw_name in mapping.items():
                        if str(raw_name)==str(name):
                            cid=str(raw_id);break
                rows.append({
                    "id":str(cid or ""),
                    "genre_id":str(cid or ""),
                    "category_id":str(cid or ""),
                    "title":str(name),
                    "name":str(name),
                    "_xtream":True,
                })
            return rows

        return [{"id":g,"title":g,"name":g} for g in self._genres.get(typ,[])]

    def ordered_page(self,media_type="itv",genre="*",page=1,cancel_event=None):
        self._ensure(cancel_event)
        typ=str(media_type or "itv").lower()
        if typ=="itv":self._start_epg_prepare()
        if self._mode=="xtream":
            rows=self._load_xtream_category(typ,genre,cancel_event,shared=True)
            shared_rows=True
        else:
            shared_rows=False
            rows=list(self._items.get(typ,[]))
            if genre not in ("*","",None):
                rows=list(x for x in rows if str(x.get("category_id") or x.get("category") or "")==str(genre))
        page=max(1,int(page or 1));size=self.PAGE_SIZE;start=(page-1)*size
        items=rows[start:start+size]
        if shared_rows:items=list(dict(x) if isinstance(x,dict) else x for x in items)
        if typ=='itv':
            if self._mode!='xtream' and self._xtream:
                items=[dict(row) for row in items]
                items=self._enrich_m3u_live_rows(items,cancel_event,cache_only=True)
                self._schedule_m3u_live_enrichment(items)
            self._remember_epg_channels(items)
        return {"items":items,"page":page,"page_size":size,"total":len(rows)}

    def ordered_list(self,media_type="itv",genre="*",page=1,cancel_event=None):
        return self.ordered_page(media_type,genre,page,cancel_event).get("items",[])

    def ordered_all(self,media_type="itv",genre="*",start_page=1,max_pages=None,max_items=None,cancel_event=None):
        self._ensure(cancel_event)
        typ=str(media_type or "itv").lower()
        if typ=="itv":self._start_epg_prepare()
        if self._mode=="xtream":
            rows=self._load_xtream_category(typ,genre,cancel_event)
        else:
            rows=list(self._items.get(typ,[]))
            if genre not in ("*","",None):
                rows=[x for x in rows if str(x.get("category_id") or x.get("category") or "")==str(genre)]
            if typ=="itv" and self._xtream:
                rows=self._enrich_m3u_live_rows(rows,cancel_event)
        result=rows[:int(max_items or len(rows))]
        if typ=='itv':self._remember_epg_channels(result)
        return result

    @staticmethod
    def _first_info_value(*values):
        def useful(value):
            if value in (None,"",False):
                return False
            text=str(value).strip()
            return text.lower() not in ("0","false","none","null","n/a","na","[]","{}")
        for value in values:
            if isinstance(value,(list,tuple)):
                for part in value:
                    if useful(part):
                        return part
            elif useful(value):
                return value
        return ""

    def _merge_xtream_provider_info(self, item, payload, kind):
        """Merge rich Xtream info into a normalized catalogue row in-place."""
        if not isinstance(item,dict) or not isinstance(payload,dict):
            return item
        info=payload.get("info") if isinstance(payload.get("info"),dict) else {}
        movie_data=payload.get("movie_data") if isinstance(payload.get("movie_data"),dict) else {}
        src={}
        # Preserve useful movie_data values when `info` repeats the same field
        # with panel placeholders such as 0/false/N/A.
        for origin in (movie_data,info):
            for key,value in origin.items():
                if self._first_info_value(value):
                    src[key]=value
        # Ultra Stalker keeps a deterministic provider-cover policy per media type.
        # The policy is expressed locally so catalogue normalization is independent
        # from any external plugin implementation.
        cover_fields={
            "series":("cover_big","cover","movie_image","cover_tmdb","stream_icon"),
            "vod":("cover_big","movie_image","cover_tmdb","cover","stream_icon"),
        }
        cover=""
        for field in cover_fields["series" if kind=="series" else "vod"]:
            cover=self._first_info_value(src.get(field))
            if cover:
                break
        backdrop=self._first_info_value(src.get("backdrop_path"),src.get("backdrop"),src.get("backdrops"),src.get("background"),src.get("fanart"))
        if cover:
            cover=str(cover)
            for key in ("logo","logo_url","cover","cover_url","poster","poster_url"):
                item[key]=cover
        if backdrop:
            backdrop=str(backdrop)
            item["backdrop"]=backdrop; item["backdrop_url"]=backdrop; item["backdrop_path"]=backdrop
            candidates=[]
            for field in ("backdrop_path","backdrop","backdrops","background","fanart"):
                raw=src.get(field)
                if isinstance(raw,(list,tuple)):
                    for value in raw:
                        if self._first_info_value(value) and value not in candidates:candidates.append(value)
            if candidates:item["backdrops"]=candidates
        # Rich get_vod_info/get_series_info is authoritative for identity and
        # metadata. List rows are frequently stale or decorated.
        mappings=(
            ("tmdb_id",("tmdb_id","tmdb")),
            ("imdb_id",("imdb_id","imdb")),
            ("year",("year","releaseDate","release_date","releasedate")),
            ("plot",("plot","description","overview")),
            ("description",("description","plot","overview")),
            ("rating",("rating","rating_5based","rating_imdb")),
            ("rating_imdb",("rating_imdb","rating")),
            ("genre",("genre","genres","category_name")),
            ("actors",("actors","cast","actor")),
            ("cast",("cast","actors","actor")),
            ("director",("director","directors")),
            ("writer",("writer","writers","creator")),
            ("duration",("duration","runtime","time")),
            ("time",("time","duration","runtime")),
            ("country",("country","country_name","countries","origin_country")),
            ("number_of_seasons",("number_of_seasons","seasons_count","season_count")),
            ("number_of_episodes",("number_of_episodes","episodes_count","episode_count")),
            ("certification",("certification","age_rating")),
        )
        for dst,keys in mappings:
            for key in keys:
                value=self._first_info_value(src.get(key))
                if value:
                    raw=src.get(key)
                    if dst in ("actors","cast","director","writer","genre","country") and isinstance(raw,(list,tuple)):
                        value=[part for part in raw if self._first_info_value(part)]
                    item[dst]=value
                    break

        # Rich provider title is a search alias only. The visible list title
        # remains untouched so users do not see random language/title changes.
        rich_name=self._first_info_value(
            src.get("name"),src.get("title"),src.get("movie_name"),
            src.get("o_name"),src.get("original_name"),src.get("original_title")
        )
        if rich_name:
            # Search hint only. Generic package labels must never outrank the
            # real catalogue title as original_title.
            item["_provider_name"]=str(rich_name)

        # Some Xtream panels put an IMDb tt-id in tmdb_id.
        raw_tid=str(item.get("tmdb_id") or "").strip()
        imdb_match=re.search(r"tt\d{5,12}",raw_tid,re.I)
        if imdb_match:
            item["imdb_id"]=imdb_match.group(0).lower()

        item["_provider_info_loaded"]=True
        return item
