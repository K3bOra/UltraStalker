# -*- coding: utf-8 -*-
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str, int, open, max, OSError, FileNotFoundError, us_clear
os = _us_env.os; re = _us_env.re; json = _us_env.json; time = _us_env.time; threading = _us_env.threading; hashlib = _us_env.hashlib; urllib = _us_env.urllib
OrderedDict = _us_env.collections.OrderedDict
from .persistent_cache import ROOT as CACHE_ROOT, hdd_read_ready, persistent_write_gate
from .log import get_logger
from .netsec import validate_remote_media_url, build_safe_media_opener
from .storage import load_settings
from .core.download_guard import ensure_capacity, reserve_bytes, CHECK_INTERVAL_BYTES

LOG=get_logger()
ROOT=os.path.join(CACHE_ROOT,"Downloads")
STATE_FILE=os.path.join(ROOT,"downloads.json")

def _reject_error_document(data=b'',content_type=''):
    mime=str(content_type or '').split(';',1)[0].strip().lower()
    prefix=data.lstrip(b'\xef\xbb\xbf \r\n\t').lower()
    if mime in ('text/html','application/xhtml+xml','application/json','text/json') or prefix.startswith(
            (b'<!doctype html',b'<html',b'<head',b'<body')):
        raise RuntimeError('Server returned an error document instead of a video file')

def _validated_download_path(path):
    """Return a canonical download target confined to the Downloads root."""
    if not isinstance(path, str) or not path.strip():
        raise ValueError("invalid download path")
    candidate=os.path.abspath(path)
    base=os.path.abspath(ROOT)
    try:
        if os.path.commonpath((base,candidate)) != base:
            raise ValueError("download path escaped Downloads root")
        # Resolve existing symlinks too, so a tampered state file cannot route
        # a download through a symlinked directory outside the managed root.
        real_base=os.path.realpath(base); real_candidate=os.path.realpath(candidate)
        if os.path.commonpath((real_base,real_candidate)) != real_base:
            raise ValueError("download path escaped Downloads root")
    except (OSError, ValueError):
        raise ValueError("download path escaped Downloads root")
    return candidate

def _mkdir(path):
    path=os.path.abspath(str(path or "")); base=os.path.abspath(CACHE_ROOT)
    try:
        if os.path.commonpath((base,path)) != base: raise OSError("download path escaped UltraStalker root")
        if not persistent_write_gate(path): raise OSError("Ultra Stalker HDD is not ready")
        return True
    except Exception as exc:
        LOG.debug("Download directory unavailable %s: %s",path,exc); return False

def _clean(text,fallback="download"):
    text=str(text or "").strip(); text=re.sub(r'[\\/:*?"<>|\x00-\x1f]+','_',text); text=re.sub(r'\s+',' ',text).strip(' ._')
    return (text or fallback)[:140]

def _atomic_json(path,data):
    if not persistent_write_gate(path): raise OSError("download HDD unavailable")
    tmp="%s.tmp.%d.%d"%(path,os.getpid(),threading.get_ident())
    if not persistent_write_gate(tmp): raise OSError("download HDD unavailable")
    try:
        with open(tmp,"w",encoding="utf-8") as f:
            json.dump(data,f,ensure_ascii=False,indent=2); f.flush(); os.fsync(f.fileno())
        if not persistent_write_gate(path): raise OSError("download HDD disappeared before state commit")
        try: os.chmod(tmp,0o600)
        except OSError: pass
        os.replace(tmp,path)
    finally:
        if os.path.exists(tmp) and persistent_write_gate(tmp):
            try: os.unlink(tmp)
            except OSError: pass

class DownloadManager(object):
    def __init__(self):
        self.lock=threading.RLock(); self.jobs=OrderedDict(); self._resolvers={}; self._wake=threading.Event(); self._stop=threading.Event()
        self._active_response=None; self._active_response_lock=threading.RLock(); self.worker=None; self._loaded=False; self._load()
    def _ensure_worker(self):
        with self.lock:
            if self._stop.is_set(): return False
            if self.worker is not None and self.worker.is_alive(): return True
            self.worker=threading.Thread(target=self._loop,name="UltraStalkerDownloadManager",daemon=True); self.worker.start(); return True
    def shutdown(self,wait=False,timeout=2.5):
        self._stop.set(); self._wake.set()
        with self.lock:
            for row in self.jobs.values():
                if row.get("status") in ("queued","resolving","downloading"):
                    row["cancel"]=True
                    if row.get("status") != "downloading": row["status"]="paused"
            if not self._save(): LOG.warning("Download state could not be saved during shutdown")
        with self._active_response_lock:
            response=self._active_response; self._active_response=None
        if response is not None:
            try:response.close()
            except Exception:pass
        thread=self.worker
        if wait and thread is not None and thread.is_alive(): thread.join(max(0.0,float(timeout or 0.0)))
        return not bool(thread is not None and thread.is_alive())
    def _load(self):
        # Fail closed when the real HDD is not mounted. Never consume a shadow
        # /media/hdd tree from receiver flash. A failed late-mount attempt stays
        # retryable so a manager first touched before HDD mount does not remain
        # permanently empty for the rest of the Enigma2 session.
        if not hdd_read_ready(force=True):
            return False
        self._loaded=True
        try:
            with open(STATE_FILE,"r",encoding="utf-8") as f: rows=json.load(f)
            for row in rows if isinstance(rows,list) else []:
                if not isinstance(row,dict): continue
                try:
                    row["path"]=_validated_download_path(row.get("path"))
                except ValueError as exc:
                    LOG.warning("Rejected unsafe persisted download %r: %s", row.get("id"), exc)
                    continue
                # Resolvers are session-local: queued rows also need a fresh portal link.
                if row.get("status") in ("queued","downloading","resolving"):
                    row["status"]="paused"
                    row["cancel"]=False
                self.jobs[str(row.get("id"))]=row
            return True
        except OSError as exc:
            if not isinstance(exc, FileNotFoundError): raise
            return True
        except (OSError, ValueError, TypeError) as exc:
            LOG.debug("Download state load skipped: %s", exc); return True
    def _ensure_loaded(self):
        if not self._loaded:
            self._load()
        return self._loaded
    def _save(self):
        try:
            _atomic_json(STATE_FILE,list(self.jobs.values())); return True
        except Exception as exc:
            LOG.debug("Download state save failed: %s",exc); return False
    def snapshot(self):
        with self.lock:
            self._ensure_loaded(); return [dict(x) for x in self.jobs.values()]
    def add(self,job,resolver):
        with self.lock:
            self._ensure_loaded()
            if not hdd_read_ready(force=True): return (False,"Download HDD is unavailable")
            jid=str(job.get("id") or "")
            if not jid:return(False,"Invalid download")
            old=self.jobs.get(jid)
            if old and old.get("status") in ("queued","resolving","downloading"):
                return(False,"Already queued")
            if old and old.get("status")=="completed":
                try:
                    previous_path=_validated_download_path(old.get("path"))
                    if os.path.isfile(previous_path) and os.path.getsize(previous_path)>0:
                        return(False,"Already downloaded")
                except (OSError,ValueError):
                    pass
            row=dict(job); row.setdefault("status","queued"); row.setdefault("downloaded",0); row.setdefault("total",0); row.setdefault("created",int(time.time())); row["error"]=""
            try: row["path"]=_validated_download_path(row.get("path"))
            except ValueError: return(False,"Invalid download path")
            # R5.244: Blue Remove intentionally leaves completed media on HDD.
            # If the user later chooses Download for the same title after removing
            # its manager entry, do not waste bandwidth or overwrite the existing
            # completed file. A zero-byte placeholder is not considered complete.
            try:
                if os.path.isfile(row["path"]) and os.path.getsize(row["path"])>0:
                    return(False,"Already downloaded")
            except OSError:
                pass
            previous_resolver=self._resolvers.get(jid)
            self.jobs[jid]=row; self._resolvers[jid]=resolver
            if not self._save():
                if old is None:self.jobs.pop(jid,None)
                else:self.jobs[jid]=old
                if previous_resolver is None:self._resolvers.pop(jid,None)
                else:self._resolvers[jid]=previous_resolver
                return(False,"Download HDD is unavailable")
            self._ensure_worker(); self._wake.set(); return(True,"Added to downloads")
    def cancel(self,jid):
        with self.lock:
            self._ensure_loaded(); row=self.jobs.get(str(jid))
            if not row:return False
            row["cancel"]=True
            if row.get("status") in ("queued","paused"):row["status"]="cancelled"
            self._save();self._wake.set();return True
    def retry(self,jid,resolver=None):
        with self.lock:
            self._ensure_loaded(); row=self.jobs.get(str(jid))
            if not row:return False
            # A transfer that is still active (or still stopping after Cancel) must
            # not be re-queued: that would clear its cancel flag mid-download.
            if row.get("status") in ("queued","resolving","downloading"):return False
            row["status"]="queued";row["cancel"]=False;row["error"]=""
            if resolver:self._resolvers[str(jid)]=resolver
            self._save();self._ensure_worker();self._wake.set();return True
    def remove(self,jid):
        """Remove a finished/stopped entry from the Downloads list only.

        This intentionally never deletes, truncates, renames, or otherwise
        touches the completed media file or any partial file on HDD. Active
        transfers must be cancelled first so they are not hidden while the
        worker is still using their manager entry.
        """
        jid=str(jid or "")
        if not jid:return False
        with self.lock:
            self._ensure_loaded(); row=self.jobs.get(jid)
            if not row:return False
            if row.get("status") in ("queued","resolving","downloading"):
                return False
            removed=self.jobs.pop(jid,None)
            resolver=self._resolvers.pop(jid,None)
            if not self._save():
                if removed is not None:self.jobs[jid]=removed
                if resolver is not None:self._resolvers[jid]=resolver
                return False
            return True
    def _next(self):
        with self.lock:
            for jid,row in self.jobs.items():
                if row.get("status")=="queued" and not row.get("cancel") and jid in self._resolvers:
                    row["status"]="resolving";self._save();return jid,row
        return None,None
    def _loop(self):
        if not _mkdir(ROOT): return
        while not self._stop.is_set():
            jid,row=self._next()
            if not row:self._wake.wait(1.0);us_clear(self._wake);continue
            try:self._download(jid,row)
            except Exception as exc:
                with self.lock:
                    live=self.jobs.get(jid)
                    if live and not self._stop.is_set(): live["status"]="failed";live["error"]=str(exc)[:220];self._save()
    @staticmethod
    def _content_range_total(headers):
        value=str((headers or {}).get("Content-Range") or "")
        m=re.search(r'\*/(\d+)$',value) or re.search(r'bytes\s+\d+-\d+/(\d+)$',value,re.I)
        return int(m.group(1)) if m else 0
    def _download(self,jid,row):
        resolver=self._resolvers.get(jid)
        if not resolver:raise RuntimeError("Download needs portal reconnection")
        url=resolver()
        with self.lock:
            live=self.jobs.get(jid)
            if live is not None and live.get("cancel"):
                # Cancelled while the portal link was being resolved: do not open a stream.
                live["status"]="cancelled";self._save();return
        if not isinstance(url,str) or not url.strip():raise RuntimeError("Portal returned no stream link")
        url=url.strip()
        scheme=str(urllib.parse.urlsplit(url).scheme or "").lower()
        if scheme not in ("http","https"):
            raise RuntimeError("Downloads support HTTP/HTTPS streams only")
        trusted_origin=str(row.get("portal_origin") or "").strip()
        trusted=(trusted_origin,) if trusted_origin else ()
        try:
            validate_remote_media_url(url, trusted_private_origins=trusted)
            opener=build_safe_media_opener(trusted_private_origins=trusted)
        except Exception as exc:
            raise RuntimeError("Unsafe download destination: %s" % exc)
        try: final=_validated_download_path(row.get("path"))
        except ValueError as exc: raise RuntimeError("Unsafe download path: %s" % exc)
        row["path"]=final; part=final+".part"
        if not _mkdir(os.path.dirname(final)):raise RuntimeError("Download HDD is unavailable")
        if not hdd_read_ready(force=True):raise RuntimeError("Download HDD is unavailable")
        existing=os.path.getsize(part) if os.path.isfile(part) else 0;response=None
        if existing:
            with open(part,"rb") as previous:
                prefix=previous.read(64)
            try:_reject_error_document(prefix)
            except RuntimeError:
                if persistent_write_gate(part):os.unlink(part)
                raise
            if prefix.lstrip(b"\xef\xbb\xbf \r\n\t").startswith(b"#EXTM3U"):
                raise RuntimeError("HLS playlist cannot be resumed as a video file. Use a direct video link.")
        reserve=reserve_bytes(load_settings())
        ensure_capacity(part, reserve=reserve)
        for attempt in range(2):
            headers={"User-Agent":"Mozilla/5.0 (UltraStalker/10)","Accept":"*/*","Connection":"close"}
            if existing>0:headers["Range"]="bytes=%d-"%existing
            try:response=opener.open(urllib.request.Request(url,headers=headers),timeout=18);break
            except urllib.error.HTTPError as exc:
                if exc.code==416 and existing>0:
                    remote_total=self._content_range_total(getattr(exc,"headers",{}))
                    try:exc.close()
                    except Exception:pass
                    if remote_total and remote_total==existing:
                        if not persistent_write_gate(part, final):
                            raise RuntimeError("Download HDD disappeared before completion")
                        os.replace(part,final)
                        with self.lock:
                            live=self.jobs[jid];live["status"]="completed";live["downloaded"]=existing;live["total"]=existing;live["completed_at"]=int(time.time());self._save()
                        return
                    if persistent_write_gate(part):
                        try:os.unlink(part)
                        except OSError:pass
                    existing=0
                    if attempt==0:continue
                raise
        if response is None:raise RuntimeError("Could not open download stream")
        with self._active_response_lock:self._active_response=response
        try:
            mime=str(response.headers.get("Content-Type") or "").split(";",1)[0].strip().lower()
            _reject_error_document(content_type=mime)
            if mime in ("application/vnd.apple.mpegurl","application/x-mpegurl","audio/mpegurl","audio/x-mpegurl"):
                raise RuntimeError("HLS playlist cannot be downloaded as a video file. Use a direct video link.")
            code=getattr(response,"status",None) or response.getcode()
            if existing and int(code or 0)==200:existing=0
            range_total=0
            if existing and int(code or 0)==206:
                # Appending is only safe when the server resumed exactly where
                # the partial file ends; otherwise bytes would be duplicated.
                span=re.match(r'\s*bytes\s+(\d+)-(\d+)/(\d+|\*)\s*$',str(response.headers.get("Content-Range") or ""),re.I)
                if not span or int(span.group(1))!=existing or int(span.group(2))<existing or (span.group(3)!="*" and int(span.group(2))>=int(span.group(3))):
                    if persistent_write_gate(part):
                        try:os.unlink(part)
                        except OSError:pass
                    raise RuntimeError("Server returned a mismatched Content-Range; partial file discarded, retry to restart")
                range_total=int(span.group(3)) if span.group(3)!="*" else 0
            mode="ab" if existing and int(code or 0)==206 else "wb";clen=int(response.headers.get("Content-Length") or 0);total=existing+clen if clen else 0
            if range_total:total=range_total
            if clen:
                ensure_capacity(part, incoming_bytes=clen, reserve=reserve)
            with self.lock:
                live=self.jobs[jid];live["status"]="downloading";live["downloaded"]=existing;live["total"]=total;live["error"]="";self._save()
            last_save=time.time();downloaded=existing;last_capacity_check=existing
            if not persistent_write_gate(part):
                raise RuntimeError("Download HDD disappeared before file write")
            with open(part,mode) as out:
                while not self._stop.is_set():
                    with self.lock:
                        if self.jobs[jid].get("cancel"):self.jobs[jid]["status"]="cancelled";self._save();return
                    chunk=response.read(256*1024)
                    if not chunk:break
                    # A few providers label HLS as octet-stream. Inspect the
                    # first body bytes before writing or marking it complete.
                    if downloaded==0:
                        while len(chunk)<64:
                            more=response.read(64-len(chunk))
                            if not more:break
                            chunk+=more
                        if chunk.lstrip(b"\xef\xbb\xbf \r\n\t").startswith(b"#EXTM3U"):
                            raise RuntimeError("HLS playlist cannot be downloaded as a video file. Use a direct video link.")
                        _reject_error_document(chunk[:512])
                    if downloaded-last_capacity_check >= CHECK_INTERVAL_BYTES:
                        ensure_capacity(part, reserve=reserve)
                        last_capacity_check=downloaded
                    out.write(chunk);downloaded+=len(chunk)
                    if time.time()-last_save>=1.0:
                        with self.lock:self.jobs[jid]["downloaded"]=downloaded;self.jobs[jid]["total"]=total;self._save()
                        last_save=time.time()
                out.flush();os.fsync(out.fileno())
            if self._stop.is_set():
                with self.lock:
                    if jid in self.jobs:self.jobs[jid]["status"]="paused";self._save()
                return
            if downloaded<=0:raise RuntimeError("Empty download")
            if total and downloaded<total:raise RuntimeError("Incomplete download (%d/%d bytes)"%(downloaded,total))
            if not persistent_write_gate(part, final):
                raise RuntimeError("Download HDD disappeared before final commit")
            os.replace(part,final)
            with self.lock:
                live=self.jobs[jid];live["status"]="completed";live["downloaded"]=downloaded;live["total"]=total or downloaded;live["completed_at"]=int(time.time());self._save()
        finally:
            with self._active_response_lock:
                if self._active_response is response:self._active_response=None
            try:response.close()
            except Exception:pass

_MANAGER=None
_MANAGER_LOCK=threading.RLock()

def _get_manager():
    global _MANAGER
    with _MANAGER_LOCK:
        if _MANAGER is None:
            _MANAGER=DownloadManager()
        return _MANAGER

class _LazyDownloadManager(object):
    """Import-safe facade. The real manager and HDD state load are lazy."""
    def snapshot(self): return _get_manager().snapshot()
    def add(self,job,resolver): return _get_manager().add(job,resolver)
    def cancel(self,jid): return _get_manager().cancel(jid)
    def retry(self,jid,resolver=None): return _get_manager().retry(jid,resolver)
    def remove(self,jid): return _get_manager().remove(jid)
    def shutdown(self,wait=False,timeout=2.5):
        with _MANAGER_LOCK:
            manager=_MANAGER
        return True if manager is None else manager.shutdown(wait=wait,timeout=timeout)

MANAGER=_LazyDownloadManager()
def shutdown_download_manager(wait=False,timeout=2.5):return MANAGER.shutdown(wait=wait,timeout=timeout)


def _portal_origin(profile):
    try:
        parts=urllib.parse.urlsplit(str((profile or {}).get("portal", "") or "").strip())
        scheme=(parts.scheme or "").lower();host=parts.hostname
        if scheme not in ("http","https") or not host:return ""
        port=parts.port or (443 if scheme=="https" else 80)
        display="[%s]"%host if ":" in host and not host.startswith("[") else host
        return "%s://%s:%d"%(scheme,display,port)
    except Exception:
        return ""

def _download_source_key(profile):
    # Never lowercase the path/query: M3U usernames and tokens are case-sensitive.
    # Only hashes are persisted, not account credentials or the full source URL.
    profile=profile if isinstance(profile,dict) else {}
    portal=str(profile.get("portal") or "").strip()
    try:
        parts=urllib.parse.urlsplit(portal)
        source=[_portal_origin(profile),parts.path.rstrip('/'),parts.query,
                parts.username or "",parts.password or ""]
    except ValueError:
        source=[portal]
    source.extend([str(profile.get("mac") or "").upper(),
                   str(profile.get("username") or profile.get("user") or "")])
    raw=json.dumps(source,ensure_ascii=False,separators=(',',':')).encode('utf-8')
    return hashlib.sha256(raw).hexdigest()


def _download_identity(profile,kind,identity):
    source=_download_source_key(profile)
    raw=json.dumps([source,kind,identity],ensure_ascii=False,sort_keys=True,
                   separators=(',',':')).encode('utf-8')
    digest=hashlib.sha256(raw).hexdigest()
    return kind+":"+digest, digest[:20], source


def movie_job(profile, item):
    item=item if isinstance(item,dict) else {}
    title=_clean(item.get("name") or item.get("title") or "Movie")
    ident=str(item.get("movie_id") or item.get("id") or item.get("cmd") or item.get("url") or title)
    jid,short,source=_download_identity(profile,"movie",ident)
    path=os.path.join(ROOT,"Movies","%s [%s].ts"%(title,short))
    return {"id":jid,"kind":"movie","title":title,"path":path,
            "source_key":source,"portal_origin":_portal_origin(profile)}


def episode_job(profile, series_item, season, item, index=0):
    series_item=series_item if isinstance(series_item,dict) else {}
    season=season if isinstance(season,dict) else {}
    item=item if isinstance(item,dict) else {}
    series=_clean(series_item.get("name") or series_item.get("title") or item.get("_series_title") or "Series")
    def first_present(data,keys,fallback):
        for key in keys:
            if data.get(key) not in (None,""):return data[key]
        return fallback
    sn=first_present(season,("season","season_number","season_id"),1)
    try: sn=int(str(sn).split(":")[-1])
    except (TypeError,ValueError): sn=1
    ep=first_present(item,("episode_num","episode","number","episode_number"),index+1)
    try: ep=int(str(ep).split(":")[-1])
    except (TypeError,ValueError): ep=index+1
    parent=str(series_item.get("series_id") or series_item.get("id") or item.get("series_id") or item.get("_series_id") or series)
    ident={"series":parent,"season":sn,"episode":ep,
           "episode_id":str(item.get("episode_id") or item.get("id") or "")}
    jid,short,source=_download_identity(profile,"episode",ident)
    title="%s - S%02dE%02d"%(series,sn,ep)
    path=os.path.join(ROOT,"Series",series,"Season %02d"%sn,"%s [%s].ts"%(title,short))
    # Legacy manager entries retain their IDs and paths; their account cannot be
    # inferred safely from portal_origin alone. Never rename/delete those files.
    return {"id":jid,"kind":"episode","title":title,"path":path,"season":sn,
            "episode":ep,"source_key":source,"portal_origin":_portal_origin(profile)}
