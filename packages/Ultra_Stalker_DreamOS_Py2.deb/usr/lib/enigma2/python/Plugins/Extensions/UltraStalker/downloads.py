# -*- coding: utf-8 -*-
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str, int, open, max, min, OSError, FileNotFoundError, us_clear
os = _us_env.os; re = _us_env.re; json = _us_env.json; time = _us_env.time; threading = _us_env.threading; hashlib = _us_env.hashlib; urllib = _us_env.urllib; ssl = _us_env.ssl
OrderedDict = _us_env.collections.OrderedDict
from .persistent_cache import ROOT as CACHE_ROOT, hdd_read_ready, persistent_write_gate
from .log import get_logger

LOG = get_logger()
DEFAULT_RESERVE_BYTES = 128 * 1024 * 1024

def _resolve_download_root():
    """Find the best writable storage mount (/media/hdd, /media/usb, /media/mmc, /media/sdcard, etc.)."""
    candidates = [
        "/media/hdd",
        "/media/usb",
        "/media/mmc",
        "/media/sdcard",
        "/hdd",
    ]
    try:
        if os.path.isdir("/media"):
            for name in sorted(os.listdir("/media")):
                p = os.path.join("/media", name)
                if p not in candidates and os.path.isdir(p):
                    candidates.append(p)
    except Exception:
        pass
    for base in candidates:
        try:
            real = os.path.realpath(base)
            if not os.path.isdir(real) or not os.access(real, os.W_OK):
                continue
            dl_dir = os.path.join(base, "UltraStalker", "Downloads")
            os.makedirs(dl_dir, mode=0o700, exist_ok=True)
            st = os.statvfs(dl_dir)
            free_b = int(st.f_bavail) * int(st.f_frsize)
            if free_b >= 64 * 1024 * 1024:
                return dl_dir
        except Exception:
            continue
    fallback = os.path.join(CACHE_ROOT, "Downloads")
    try:
        os.makedirs(fallback, mode=0o700, exist_ok=True)
    except Exception:
        pass
    return fallback

ROOT = _resolve_download_root()
STATE_FILE = os.path.join(ROOT, "downloads.json")

def _refresh_root():
    global ROOT, STATE_FILE
    ROOT = _resolve_download_root()
    STATE_FILE = os.path.join(ROOT, "downloads.json")
    return ROOT

def _free_bytes_at(path):
    target = os.path.abspath(str(path or ROOT))
    while not os.path.exists(target):
        parent = os.path.dirname(target)
        if parent == target:
            break
        target = parent
    try:
        st = os.statvfs(target)
        return int(st.f_bavail) * int(st.f_frsize)
    except Exception:
        return 10 * 1024 * 1024 * 1024

def _check_space(path, incoming_bytes=0):
    free_b = _free_bytes_at(path)
    needed = DEFAULT_RESERVE_BYTES + max(0, int(incoming_bytes or 0))
    if free_b < needed:
        raise RuntimeError("Insufficient disk space (%.1f MB free)" % (free_b / 1048576.0))
    return free_b

def _reject_error_document(data=b"", content_type=""):
    mime = str(content_type or "").split(";", 1)[0].strip().lower()
    prefix = data.lstrip(b"\xef\xbb\xbf \r\n\t").lower()
    if mime in ("text/html", "application/xhtml+xml", "application/json", "text/json") or prefix.startswith(
            (b"<!doctype html", b"<html", b"<head", b"<body", b'{"error"')):
        raise RuntimeError("Server returned an error page instead of a video stream")

def _validated_download_path(path):
    if not isinstance(path, str) or not path.strip():
        raise ValueError("invalid download path")
    _refresh_root()
    candidate = os.path.abspath(path)
    # Allow paths under current ROOT or any /media/*/UltraStalker/Downloads
    base = os.path.abspath(ROOT)
    if candidate.startswith(base + os.sep):
        return candidate
    rel_parts = candidate.replace("\\", "/").split("/UltraStalker/Downloads/")
    if len(rel_parts) == 2 and ".." not in rel_parts[1]:
        return os.path.abspath(os.path.join(base, rel_parts[1]))
    raise ValueError("download path escaped Downloads root")

def _mkdir(path):
    try:
        os.makedirs(os.path.abspath(str(path or ROOT)), mode=0o700, exist_ok=True)
        return True
    except Exception as exc:
        LOG.debug("Download directory unavailable %s: %s", path, exc)
        return False

def _clean(text, fallback="download"):
    text = str(text or "").strip()
    text = re.sub(r'[\\/:*?"<>|\x00-\x1f]+', "_", text)
    text = re.sub(r"\s+", " ", text).strip(" ._")
    return (text or fallback)[:140]

def _atomic_json(path, data):
    parent = os.path.dirname(os.path.abspath(path))
    if not _mkdir(parent):
        raise OSError("download storage unavailable")
    tmp = "%s.tmp.%d.%d" % (path, os.getpid(), threading.get_ident())
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
            f.flush()
            try:
                os.fsync(f.fileno())
            except Exception:
                pass
        try:
            os.chmod(tmp, 0o600)
        except OSError:
            pass
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            try:
                os.unlink(tmp)
            except OSError:
                pass

def _normalize_stream_url(raw_url, mac=""):
    text = str(raw_url or "").strip().strip('"').strip("'")
    if not text:
        return ""
    first, sep, rem = text.partition(" ")
    if sep and first.lower() in ("ffmpeg", "auto", "ffplay"):
        text = rem.strip()
    m = re.search(r"(?i)(https?://\S+)", text)
    if m:
        text = m.group(1).strip().strip('"').strip("'")
    if mac:
        text = re.sub(r"%mac%", str(mac), text, flags=re.IGNORECASE)
    try:
        parts = urllib.parse.urlsplit(text)
        scheme = (parts.scheme or "").lower()
        if scheme not in ("http", "https") or not parts.netloc:
            return text
        path = urllib.parse.quote(urllib.parse.unquote(parts.path or "/"), safe="/:@&%=+$,;-_.~()[]!'*")
        query = urllib.parse.quote(urllib.parse.unquote(parts.query or ""), safe="/:@&%=+$,;-_.~()[]!'*?")
        return urllib.parse.urlunsplit((scheme, parts.netloc, path, query, ""))
    except Exception:
        return text

class _IPTVRedirectHandler(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        target = _normalize_stream_url(urllib.parse.urljoin(req.full_url, newurl))
        new_req = urllib.request.Request(target)
        for k, v in list(req.headers.items()) + list(req.unredirected_hdrs.items()):
            if k.lower() in ("user-agent", "accept", "range", "cookie", "referer"):
                new_req.add_header(k, v)
        return new_req

def _build_iptv_opener(verify_ssl=True):
    handlers = [urllib.request.ProxyHandler({}), _IPTVRedirectHandler()]
    try:
        if verify_ssl:
            ctx = ssl.create_default_context()
        else:
            ctx = ssl._create_unverified_context()
        handlers.append(urllib.request.HTTPSHandler(context=ctx))
    except Exception:
        pass
    return urllib.request.build_opener(*handlers)

_USER_AGENTS = (
    "VLC/3.0.20 LibVLC/3.0.20",
    "Lavf/60.3.100",
    "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3",
    "GStreamer souphttpsrc 1.22.0",
)

def _detect_extension(item, url=""):
    if isinstance(item, dict):
        ext = str(item.get("container_extension") or "").strip().lstrip(".").lower()
        if ext in ("mp4", "mkv", "ts", "avi", "mov", "m4v"):
            return "." + ext
    for candidate in (url, (item.get("url") if isinstance(item, dict) else ""), (item.get("cmd") if isinstance(item, dict) else "")):
        s = str(candidate or "").strip()
        if not s:
            continue
        try:
            p = urllib.parse.urlsplit(s).path.lower()
            for valid_ext in (".mp4", ".mkv", ".avi", ".mov", ".m4v", ".ts"):
                if p.endswith(valid_ext):
                    return valid_ext
        except Exception:
            pass
    if isinstance(item, dict) and (item.get("_xtream") or item.get("_m3u_series")):
        return ".mp4"
    return ".ts"

class DownloadManager(object):
    def __init__(self):
        self.lock = threading.RLock()
        self.jobs = OrderedDict()
        self._resolvers = {}
        self._wake = threading.Event()
        self._stop = threading.Event()
        self._active_response = None
        self._active_response_lock = threading.RLock()
        self.worker = None
        self._loaded = False
        self._load()

    def _ensure_worker(self):
        with self.lock:
            if self._stop.is_set():
                return False
            if self.worker is not None and self.worker.is_alive():
                return True
            self.worker = threading.Thread(target=self._loop, name="UltraStalkerDownloadManager", daemon=True)
            self.worker.start()
            return True

    def shutdown(self, wait=False, timeout=2.5):
        self._stop.set()
        self._wake.set()
        with self.lock:
            for row in self.jobs.values():
                if row.get("status") in ("queued", "resolving", "downloading"):
                    row["cancel"] = True
                    if row.get("status") != "downloading":
                        row["status"] = "paused"
                    row["speed"] = 0
            self._save()
        with self._active_response_lock:
            response = self._active_response
            self._active_response = None
        if response is not None:
            try:
                response.close()
            except Exception:
                pass
        thread = self.worker
        if wait and thread is not None and thread.is_alive():
            thread.join(max(0.0, float(timeout or 0.0)))
        return not bool(thread is not None and thread.is_alive())

    def _load(self):
        _refresh_root()
        if not _mkdir(ROOT):
            return False
        self._loaded = True
        try:
            if not os.path.isfile(STATE_FILE):
                return True
            with open(STATE_FILE, "r", encoding="utf-8") as f:
                rows = json.load(f)
            for row in rows if isinstance(rows, list) else []:
                if not isinstance(row, dict):
                    continue
                try:
                    row["path"] = _validated_download_path(row.get("path"))
                except ValueError:
                    continue
                if row.get("status") in ("queued", "downloading", "resolving"):
                    row["status"] = "paused"
                    row["cancel"] = False
                row["speed"] = 0
                self.jobs[str(row.get("id"))] = row
            return True
        except Exception as exc:
            LOG.debug("Download state load skipped: %s", exc)
            return True

    def _ensure_loaded(self):
        if not self._loaded:
            self._load()
        return self._loaded

    def _save(self):
        try:
            _refresh_root()
            _atomic_json(STATE_FILE, list(self.jobs.values()))
            return True
        except Exception as exc:
            LOG.debug("Download state save failed: %s", exc)
            return False

    def snapshot(self):
        with self.lock:
            self._ensure_loaded()
            return [dict(x) for x in self.jobs.values()]

    def _build_auto_resolver(self, row):
        reconnect = row.get("reconnect") if isinstance(row, dict) else None
        if not isinstance(reconnect, dict):
            return None
        profile = reconnect.get("profile") if isinstance(reconnect.get("profile"), dict) else {}
        media_type = str(reconnect.get("media_type") or "vod")
        item = dict(reconnect.get("item") or {})
        episode_id = reconnect.get("episode_id")
        direct_url = str(reconnect.get("direct_url") or item.get("url") or "").strip()

        def auto_resolve():
            # 1. For M3U / Xtream direct HTTP(S) links that do not need Stalker create_link
            source_type = str(profile.get("source_type") or "").lower()
            portal_url = str(profile.get("portal") or "").strip()
            is_m3u = source_type == "m3u" or ".m3u" in portal_url.lower() or "get.php" in portal_url.lower()
            if is_m3u and direct_url.lower().startswith(("http://", "https://")):
                return direct_url
            try:
                if is_m3u:
                    from .m3u_adapter import M3UClient
                    client = M3UClient(portal_url, profile.get("mac") or "M3U", timeout=15)
                else:
                    from .client import StalkerClient
                    client = StalkerClient(
                        portal_url,
                        profile.get("mac"),
                        timeout=15,
                        allow_http_fallback=profile.get("allow_http_fallback", True),
                        tls_mode=profile.get("tls_mode", "auto"),
                        device_profile=profile.get("device_profile", "auto"),
                        allow_tls_fallback=True,
                        http_fallback_accepted=True,
                    )
                try:
                    if media_type in ("series", "episode"):
                        return client.create_link(item, "series", episode_id)
                    return client.create_link(item, "vod")
                finally:
                    try:
                        client.close()
                    except Exception:
                        pass
            except Exception:
                if direct_url.lower().startswith(("http://", "https://")):
                    return direct_url
                raise
        return auto_resolve

    def add(self, job, resolver=None):
        with self.lock:
            self._ensure_loaded()
            _refresh_root()
            if not _mkdir(ROOT):
                return (False, "Download storage is unavailable")
            jid = str(job.get("id") or "")
            if not jid:
                return (False, "Invalid download")
            old = self.jobs.get(jid)
            if old and old.get("status") in ("queued", "resolving", "downloading"):
                return (False, "Already queued")
            if old and old.get("status") == "completed":
                try:
                    previous_path = _validated_download_path(old.get("path"))
                    if os.path.isfile(previous_path) and os.path.getsize(previous_path) > 0:
                        return (False, "Already downloaded")
                except (OSError, ValueError):
                    pass
            row = dict(job)
            row["status"] = "queued"
            row.setdefault("downloaded", 0)
            row.setdefault("total", 0)
            row.setdefault("created", int(time.time()))
            row["error"] = ""
            row["cancel"] = False
            row["speed"] = 0
            try:
                row["path"] = _validated_download_path(row.get("path"))
            except ValueError:
                return (False, "Invalid download path")
            try:
                if os.path.isfile(row["path"]) and os.path.getsize(row["path"]) > 0:
                    row["status"] = "completed"
                    row["downloaded"] = os.path.getsize(row["path"])
                    row["total"] = row["downloaded"]
                    self.jobs[jid] = row
                    self._save()
                    return (False, "Already downloaded")
            except OSError:
                pass
            self.jobs[jid] = row
            if resolver is not None:
                self._resolvers[jid] = resolver
            elif jid not in self._resolvers:
                auto_res = self._build_auto_resolver(row)
                if auto_res is not None:
                    self._resolvers[jid] = auto_res
            self._save()
            self._ensure_worker()
            self._wake.set()
            return (True, "Added to downloads")

    def cancel(self, jid):
        with self.lock:
            self._ensure_loaded()
            row = self.jobs.get(str(jid))
            if not row:
                return False
            row["cancel"] = True
            row["speed"] = 0
            if row.get("status") in ("queued", "paused", "resolving"):
                row["status"] = "cancelled"
            self._save()
            self._wake.set()
        with self._active_response_lock:
            resp = self._active_response
        if resp is not None:
            try:
                resp.close()
            except Exception:
                pass
        return True

    def retry(self, jid, resolver=None):
        with self.lock:
            self._ensure_loaded()
            jid = str(jid or "")
            row = self.jobs.get(jid)
            if not row:
                return False
            if row.get("status") in ("queued", "resolving", "downloading"):
                return False
            if resolver is not None:
                self._resolvers[jid] = resolver
            elif jid not in self._resolvers:
                auto_res = self._build_auto_resolver(row)
                if auto_res is not None:
                    self._resolvers[jid] = auto_res
            row["status"] = "queued"
            row["cancel"] = False
            row["error"] = ""
            row["speed"] = 0
            self._save()
            self._ensure_worker()
            self._wake.set()
            return True

    def remove(self, jid):
        jid = str(jid or "")
        if not jid:
            return False
        with self.lock:
            self._ensure_loaded()
            row = self.jobs.get(jid)
            if not row:
                return False
            if row.get("status") in ("queued", "resolving", "downloading"):
                return False
            self.jobs.pop(jid, None)
            self._resolvers.pop(jid, None)
            self._save()
            return True

    def _next(self):
        with self.lock:
            for jid, row in self.jobs.items():
                if row.get("status") == "queued" and not row.get("cancel"):
                    if jid not in self._resolvers:
                        auto_res = self._build_auto_resolver(row)
                        if auto_res is not None:
                            self._resolvers[jid] = auto_res
                    if jid in self._resolvers:
                        row["status"] = "resolving"
                        row["speed"] = 0
                        self._save()
                        return jid, row
        return None, None

    def _loop(self):
        _refresh_root()
        _mkdir(ROOT)
        while not self._stop.is_set():
            jid, row = self._next()
            if not row:
                self._wake.wait(1.0)
                us_clear(self._wake)
                continue
            try:
                self._download(jid, row)
            except Exception as exc:
                with self.lock:
                    live = self.jobs.get(jid)
                    if live and not self._stop.is_set():
                        if live.get("cancel"):
                            live["status"] = "cancelled"
                        else:
                            live["status"] = "failed"
                            live["error"] = str(exc)[:220]
                        live["speed"] = 0
                        self._save()

    @staticmethod
    def _content_range_total(headers):
        value = str((headers or {}).get("Content-Range") or "")
        m = re.search(r"\*/(\d+)$", value) or re.search(r"bytes\s+\d+-\d+/(\d+)$", value, re.I)
        return int(m.group(1)) if m else 0

    def _resolve_job_url(self, jid, row, force_fresh=False):
        reconnect = row.get("reconnect") if isinstance(row, dict) else {}
        profile = (reconnect.get("profile") if isinstance(reconnect, dict) else {}) or {}
        mac = str(profile.get("mac") or "")
        resolver = None if force_fresh else self._resolvers.get(jid)
        if resolver is None:
            resolver = self._build_auto_resolver(row)
            if resolver is not None:
                self._resolvers[jid] = resolver
        url = ""
        if resolver is not None:
            try:
                url = resolver()
            except Exception as exc:
                auto_res = self._build_auto_resolver(row)
                if auto_res is not None and auto_res is not resolver:
                    self._resolvers[jid] = auto_res
                    url = auto_res()
                else:
                    raise exc
        return _normalize_stream_url(url, mac=mac)

    def _open_stream(self, url, existing=0, profile=None):
        profile = profile if isinstance(profile, dict) else {}
        mac = str(profile.get("mac") or "").strip()
        portal = str(profile.get("portal") or "").strip()
        referer = _portal_origin(profile)

        # Build candidate URLs (for Xtream VOD/Series, also try .mkv / .ts / .mp4 fallback on 404)
        url_candidates = [url]
        if "/movie/" in url or "/series/" in url:
            base_no_ext, dot, cur_ext = url.rpartition(".")
            if dot and cur_ext.lower() in ("mp4", "mkv", "ts", "avi") and "/" not in cur_ext:
                for alt_ext in ("mp4", "mkv", "ts"):
                    alt_u = base_no_ext + "." + alt_ext
                    if alt_u not in url_candidates:
                        url_candidates.append(alt_u)

        last_err = None
        for cand_url in url_candidates:
            for verify_ssl in (True, False):
                opener = _build_iptv_opener(verify_ssl=verify_ssl)
                for ua in _USER_AGENTS:
                    for use_range in ([True, False] if existing > 0 else [False]):
                        headers = {
                            "User-Agent": ua,
                            "Accept": "*/*",
                            "Connection": "keep-alive",
                        }
                        if referer:
                            headers["Referer"] = referer + "/"
                        if mac and mac != "M3U":
                            headers["Cookie"] = "mac=%s; stb_lang=en; timezone=GMT" % mac
                        if use_range and existing > 0:
                            headers["Range"] = "bytes=%d-" % existing
                        try:
                            req = urllib.request.Request(cand_url, headers=headers)
                            resp = opener.open(req, timeout=22)
                            return resp, (existing if use_range else 0), opener, headers
                        except urllib.error.HTTPError as exc:
                            last_err = exc
                            code = int(getattr(exc, "code", 0) or 0)
                            try:
                                exc.close()
                            except Exception:
                                pass
                            if code == 416 and use_range and existing > 0:
                                continue
                            if code in (400, 401, 403, 405, 406, 458, 500, 502, 503):
                                continue
                            if code == 404:
                                break
                        except Exception as exc:
                            last_err = exc
                            if "SSL" in str(exc).upper() or "CERTIFICATE" in str(exc).upper():
                                break
                            continue
                    else:
                        continue
                    break
        if last_err is not None:
            raise last_err
        raise RuntimeError("Could not open stream URL")

    def _download_hls_segments(self, jid, row, playlist_url, playlist_bytes, part, final, opener, headers):
        text = playlist_bytes.decode("utf-8", "replace")
        lines = [l.strip() for l in text.splitlines() if l.strip()]
        # If Master Playlist (#EXT-X-STREAM-INF), select highest bandwidth variant
        if any(l.startswith("#EXT-X-STREAM-INF") for l in lines):
            best_bw = -1
            best_uri = ""
            for i, l in enumerate(lines):
                if l.startswith("#EXT-X-STREAM-INF"):
                    m = re.search(r"BANDWIDTH=(\d+)", l)
                    bw = int(m.group(1)) if m else 0
                    for j in range(i + 1, len(lines)):
                        if not lines[j].startswith("#"):
                            if bw >= best_bw:
                                best_bw = bw
                                best_uri = urllib.parse.urljoin(playlist_url, lines[j])
                            break
            if best_uri:
                playlist_url = _normalize_stream_url(best_uri)
                req = urllib.request.Request(playlist_url, headers={k: v for k, v in headers.items() if k.lower() != "range"})
                with opener.open(req, timeout=20) as resp:
                    text = resp.read(2 * 1024 * 1024).decode("utf-8", "replace")
                lines = [l.strip() for l in text.splitlines() if l.strip()]

        segments = []
        for l in lines:
            if l.startswith("#EXT-X-MAP:"):
                m = re.search(r'URI="([^"]+)"', l)
                if m:
                    segments.append(_normalize_stream_url(urllib.parse.urljoin(playlist_url, m.group(1))))
            elif not l.startswith("#"):
                segments.append(_normalize_stream_url(urllib.parse.urljoin(playlist_url, l)))

        if not segments:
            raise RuntimeError("HLS playlist contained no playable video segments")

        total_segs = len(segments)
        downloaded = 0
        t_start = time.time()
        last_save = t_start
        seg_headers = {k: v for k, v in headers.items() if k.lower() != "range"}

        with open(part, "wb") as out:
            for idx, seg_url in enumerate(segments, 1):
                if self._stop.is_set():
                    with self.lock:
                        if jid in self.jobs:
                            self.jobs[jid]["status"] = "paused"
                            self.jobs[jid]["speed"] = 0
                            self._save()
                    return
                with self.lock:
                    if self.jobs[jid].get("cancel"):
                        self.jobs[jid]["status"] = "cancelled"
                        self.jobs[jid]["speed"] = 0
                        self._save()
                        return
                req = urllib.request.Request(seg_url, headers=seg_headers)
                with opener.open(req, timeout=20) as seg_resp:
                    while True:
                        chunk = seg_resp.read(256 * 1024)
                        if not chunk:
                            break
                        out.write(chunk)
                        downloaded += len(chunk)
                now = time.time()
                if now - last_save >= 0.8 or idx == total_segs:
                    elapsed = max(0.2, now - t_start)
                    est_total = int(downloaded * float(total_segs) / float(max(1, idx)))
                    with self.lock:
                        live = self.jobs[jid]
                        live["downloaded"] = downloaded
                        live["total"] = max(downloaded, est_total)
                        live["speed"] = int(downloaded / elapsed)
                        self._save()
                    last_save = now
            out.flush()
            try:
                os.fsync(out.fileno())
            except Exception:
                pass

        if downloaded <= 0:
            raise RuntimeError("Empty HLS stream download")
        os.replace(part, final)
        with self.lock:
            live = self.jobs[jid]
            live["status"] = "completed"
            live["downloaded"] = downloaded
            live["total"] = downloaded
            live["speed"] = 0
            live["completed_at"] = int(time.time())
            self._save()

    def _download(self, jid, row):
        _refresh_root()
        reconnect = row.get("reconnect") if isinstance(row, dict) else {}
        profile = (reconnect.get("profile") if isinstance(reconnect, dict) else {}) or {}
        url = self._resolve_job_url(jid, row, force_fresh=False)
        with self.lock:
            live = self.jobs.get(jid)
            if live is not None and live.get("cancel"):
                live["status"] = "cancelled"
                live["speed"] = 0
                self._save()
                return
        if not isinstance(url, str) or not url.strip():
            raise RuntimeError("Portal returned no stream link")
        url = url.strip()
        scheme = str(urllib.parse.urlsplit(url).scheme or "").lower()
        if scheme not in ("http", "https"):
            raise RuntimeError("Downloads support HTTP/HTTPS streams only")
        final = _validated_download_path(row.get("path"))
        row["path"] = final
        part = final + ".part"
        if not _mkdir(os.path.dirname(final)):
            raise RuntimeError("Download storage is unavailable")
        existing = os.path.getsize(part) if os.path.isfile(part) else 0
        if existing > 0:
            try:
                with open(part, "rb") as prev:
                    prefix = prev.read(64)
                _reject_error_document(prefix)
            except Exception:
                try:
                    os.unlink(part)
                except OSError:
                    pass
                existing = 0

        _check_space(part)
        response = None
        try:
            response, existing, opener, used_headers = self._open_stream(url, existing=existing, profile=profile)
        except Exception:
            # If Stalker one-time link expired, mint a fresh link once and retry
            fresh_url = self._resolve_job_url(jid, row, force_fresh=True)
            if fresh_url and fresh_url != url:
                url = fresh_url
            response, existing, opener, used_headers = self._open_stream(url, existing=0, profile=profile)

        with self._active_response_lock:
            self._active_response = response
        try:
            mime = str(response.headers.get("Content-Type") or "").split(";", 1)[0].strip().lower()
            _reject_error_document(content_type=mime)
            first_chunk = response.read(256 * 1024)
            if not first_chunk:
                raise RuntimeError("Stream returned 0 bytes")
            trimmed = first_chunk.lstrip(b"\xef\xbb\xbf \r\n\t")
            if mime in ("application/vnd.apple.mpegurl", "application/x-mpegurl", "audio/mpegurl", "audio/x-mpegurl") or trimmed.startswith(b"#EXTM3U"):
                rest = response.read(1024 * 1024)
                try:
                    response.close()
                except Exception:
                    pass
                with self._active_response_lock:
                    self._active_response = None
                with self.lock:
                    live = self.jobs[jid]
                    live["status"] = "downloading"
                    live["error"] = ""
                    self._save()
                self._download_hls_segments(jid, row, getattr(response, "url", url) or url, first_chunk + rest, part, final, opener, used_headers)
                return

            _reject_error_document(first_chunk[:512])
            code = getattr(response, "status", None) or response.getcode()
            if existing and int(code or 0) == 200:
                existing = 0
            range_total = 0
            if existing and int(code or 0) == 206:
                span = re.match(r"\s*bytes\s+(\d+)-(\d+)/(\d+|\*)\s*$", str(response.headers.get("Content-Range") or ""), re.I)
                if span and span.group(3) != "*":
                    range_total = int(span.group(3))
            mode = "ab" if existing and int(code or 0) == 206 else "wb"
            clen = int(response.headers.get("Content-Length") or 0)
            total = existing + clen if clen else 0
            if range_total:
                total = range_total
            if clen:
                _check_space(part, incoming_bytes=clen)
            with self.lock:
                live = self.jobs[jid]
                live["status"] = "downloading"
                live["downloaded"] = existing
                live["total"] = total
                live["error"] = ""
                self._save()

            downloaded = existing
            session_bytes = 0
            t_start = time.time()
            last_save = t_start
            last_space_check = downloaded

            with open(part, mode) as out:
                out.write(first_chunk)
                downloaded += len(first_chunk)
                session_bytes += len(first_chunk)
                while not self._stop.is_set():
                    with self.lock:
                        if self.jobs[jid].get("cancel"):
                            self.jobs[jid]["status"] = "cancelled"
                            self.jobs[jid]["speed"] = 0
                            self._save()
                            return
                    chunk = response.read(256 * 1024)
                    if not chunk:
                        break
                    out.write(chunk)
                    downloaded += len(chunk)
                    session_bytes += len(chunk)
                    if downloaded - last_space_check >= 8 * 1024 * 1024:
                        _check_space(part)
                        last_space_check = downloaded
                    now = time.time()
                    if now - last_save >= 0.8:
                        elapsed = max(0.2, now - t_start)
                        with self.lock:
                            live = self.jobs[jid]
                            live["downloaded"] = downloaded
                            live["total"] = total
                            live["speed"] = int(session_bytes / elapsed)
                            self._save()
                        last_save = now
                out.flush()
                try:
                    os.fsync(out.fileno())
                except Exception:
                    pass

            if self._stop.is_set():
                with self.lock:
                    if jid in self.jobs:
                        self.jobs[jid]["status"] = "paused"
                        self.jobs[jid]["speed"] = 0
                        self._save()
                return
            if downloaded <= 0:
                raise RuntimeError("Empty download")
            if total and downloaded < int(total * 0.98):
                raise RuntimeError("Incomplete download (%d/%d MB)" % (downloaded // 1048576, total // 1048576))
            os.replace(part, final)
            with self.lock:
                live = self.jobs[jid]
                live["status"] = "completed"
                live["downloaded"] = downloaded
                live["total"] = total or downloaded
                live["speed"] = 0
                live["completed_at"] = int(time.time())
                self._save()
        finally:
            with self._active_response_lock:
                if self._active_response is response:
                    self._active_response = None
            try:
                response.close()
            except Exception:
                pass

_MANAGER = None
_MANAGER_LOCK = threading.RLock()

def _get_manager():
    global _MANAGER
    with _MANAGER_LOCK:
        if _MANAGER is None:
            _MANAGER = DownloadManager()
        return _MANAGER

class _LazyDownloadManager(object):
    def snapshot(self): return _get_manager().snapshot()
    def add(self, job, resolver=None): return _get_manager().add(job, resolver)
    def cancel(self, jid): return _get_manager().cancel(jid)
    def retry(self, jid, resolver=None): return _get_manager().retry(jid, resolver)
    def remove(self, jid): return _get_manager().remove(jid)
    def shutdown(self, wait=False, timeout=2.5):
        with _MANAGER_LOCK:
            manager = _MANAGER
        return True if manager is None else manager.shutdown(wait=wait, timeout=timeout)

MANAGER = _LazyDownloadManager()
def shutdown_download_manager(wait=False, timeout=2.5): return MANAGER.shutdown(wait=wait, timeout=timeout)

def _portal_origin(profile):
    try:
        parts = urllib.parse.urlsplit(str((profile or {}).get("portal", "") or "").strip())
        scheme = (parts.scheme or "").lower()
        host = parts.hostname
        if scheme not in ("http", "https") or not host:
            return ""
        port = parts.port or (443 if scheme == "https" else 80)
        display = "[%s]" % host if ":" in host and not host.startswith("[") else host
        return "%s://%s:%d" % (scheme, display, port)
    except Exception:
        return ""

def _download_source_key(profile):
    profile = profile if isinstance(profile, dict) else {}
    portal = str(profile.get("portal") or "").strip()
    try:
        parts = urllib.parse.urlsplit(portal)
        source = [_portal_origin(profile), parts.path.rstrip("/"), parts.query, parts.username or "", parts.password or ""]
    except ValueError:
        source = [portal]
    source.extend([str(profile.get("mac") or "").upper(), str(profile.get("username") or profile.get("user") or "")])
    raw = json.dumps(source, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()

def _download_identity(profile, kind, identity):
    source = _download_source_key(profile)
    raw = json.dumps([source, kind, identity], ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    digest = hashlib.sha256(raw).hexdigest()
    return kind + ":" + digest, digest[:20], source

def _compact_reconnect_item(item):
    if not isinstance(item, dict):
        return {}
    keys = (
        "id", "movie_id", "series_id", "season_id", "episode_id", "stream_id",
        "season", "episode", "number", "episode_num", "episode_number",
        "cmd", "command", "url", "name", "title", "container_extension",
        "_xtream", "_xtream_kind", "_m3u_series",
    )
    return {k: item.get(k) for k in keys if item.get(k) not in (None, "", [], {})}

def movie_job(profile, item):
    _refresh_root()
    item = item if isinstance(item, dict) else {}
    title = _clean(item.get("name") or item.get("title") or "Movie")
    ident = str(item.get("movie_id") or item.get("id") or item.get("stream_id") or item.get("cmd") or item.get("url") or title)
    jid, short, source = _download_identity(profile, "movie", ident)
    ext = _detect_extension(item)
    path = os.path.join(ROOT, "Movies", "%s [%s]%s" % (title, short, ext))
    direct = str(item.get("url") or item.get("cmd") or item.get("command") or "").strip()
    reconnect = {
        "profile": dict(profile or {}) if isinstance(profile, dict) else {},
        "media_type": "vod",
        "item": _compact_reconnect_item(item),
        "direct_url": direct if direct.lower().startswith(("http://", "https://")) else "",
    }
    return {
        "id": jid, "kind": "movie", "title": title, "path": path,
        "source_key": source, "portal_origin": _portal_origin(profile),
        "reconnect": reconnect,
    }

def episode_job(profile, series_item, season, item, index=0):
    _refresh_root()
    series_item = series_item if isinstance(series_item, dict) else {}
    season = season if isinstance(season, dict) else {}
    item = item if isinstance(item, dict) else {}
    series = _clean(series_item.get("name") or series_item.get("title") or item.get("_series_title") or "Series")
    def first_present(data, keys, fallback):
        for key in keys:
            if data.get(key) not in (None, ""):
                return data[key]
        return fallback
    sn = first_present(season, ("season", "season_number", "season_id"), 1)
    try:
        sn = int(str(sn).split(":")[-1])
    except (TypeError, ValueError):
        sn = 1
    ep = first_present(item, ("episode_num", "episode", "number", "episode_number"), index + 1)
    try:
        ep = int(str(ep).split(":")[-1])
    except (TypeError, ValueError):
        ep = index + 1
    parent = str(series_item.get("series_id") or series_item.get("id") or item.get("series_id") or item.get("_series_id") or series)
    eid = str(item.get("id") or item.get("episode_id") or item.get("series") or item.get("number") or "")
    ident = {"series": parent, "season": sn, "episode": ep, "episode_id": eid}
    jid, short, source = _download_identity(profile, "episode", ident)
    title = "%s - S%02dE%02d" % (series, sn, ep)
    ext = _detect_extension(item)
    path = os.path.join(ROOT, "Series", series, "Season %02d" % sn, "%s [%s]%s" % (title, short, ext))
    direct = str(item.get("url") or item.get("cmd") or item.get("command") or "").strip()
    reconnect = {
        "profile": dict(profile or {}) if isinstance(profile, dict) else {},
        "media_type": "series",
        "episode_id": eid or parent,
        "item": _compact_reconnect_item(item),
        "direct_url": direct if direct.lower().startswith(("http://", "https://")) else "",
    }
    return {
        "id": jid, "kind": "episode", "title": title, "path": path,
        "season": sn, "episode": ep, "source_key": source,
        "portal_origin": _portal_origin(profile),
        "reconnect": reconnect,
    }
