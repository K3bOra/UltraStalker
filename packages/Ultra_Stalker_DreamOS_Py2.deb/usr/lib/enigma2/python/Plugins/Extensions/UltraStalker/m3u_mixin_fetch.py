# -*- coding: utf-8 -*-
"""HTTP headers, playlist open/decode, probe, fetch, parse and ensure.

Methods moved verbatim out of ``M3UClient`` (m3u_adapter.py); behaviour is unchanged.
This module is imported by m3u_adapter.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str, int, max, min, TimeoutError, us_casefold
from .m3u_adapter import LOG, M3UCancelledError, _MEM_LOCK, _attr_map, _episode_numbers, _kind, _mode_hint_set, _series_base, _slug_id, provider_urlopen, socket, time, urllib, zlib
from .provider_requests import account_gate, Events, ProviderBusyError, ProviderCancelled, retry_delay, LeasedResponse

class M3UFetchMixin(object):
    """HTTP headers, playlist open/decode, probe, fetch, parse and ensure."""

    def _request_headers(self, browser=False, range_prefix=False):
        headers = {'User-Agent': 'Mozilla/5.0 (Linux; Enigma2) AppleWebKit/537.36 Chrome/120 Safari/537.36' if browser else 'VLC/3.0.20 LibVLC/3.0.20', 'Accept': 'audio/x-mpegurl,application/x-mpegurl,application/vnd.apple.mpegurl,text/plain,*/*', 'Accept-Encoding': 'gzip, deflate', 'Connection': 'close'}
        if range_prefix:
            headers['Range'] = 'bytes=0-131071'
        return headers

    def _normalized_url(self):
        url = str(self.url or '').strip()
        low = url.lower()
        if low.startswith('m3u://'):
            url = 'http://' + url[6:]
        elif low.startswith('m3u8://'):
            url = 'http://' + url[7:]
        return url

    def _is_timeout_error(self, exc):
        if isinstance(exc, (socket.timeout, TimeoutError)):
            return True
        reason = getattr(exc, 'reason', None)
        if isinstance(reason, (socket.timeout, TimeoutError)):
            return True
        return 'timed out' in str(exc or '').lower()

    def _open_playlist(self, timeout, browser=False, range_prefix=False, cancel_event=None):
        url = self._normalized_url()
        gate = account_gate(self)
        event = Events(getattr(self, '_epg_stop', None), cancel_event)
        for attempt in range(2):
            lease = None
            try:
                lease = gate.acquire(event, timeout=25)
                req = urllib.request.Request(url, headers=self._request_headers(browser, range_prefix))
                response = provider_urlopen(req, timeout=max(3, int(timeout or self.timeout)))
                lease.bind(response)
                return LeasedResponse(response, lease)
            except ProviderCancelled as exc:
                if lease is not None:
                    lease.release()
                raise M3UCancelledError(str(exc))
            except urllib.error.HTTPError as exc:
                if lease is not None:
                    lease.release()
                if int(exc.code) not in (429, 469):
                    exc.close()
                    raise
                delay = retry_delay(exc.headers)
                code = exc.code
                exc.close()
                gate.defer(delay, code)
                if attempt:
                    raise ProviderBusyError(code, delay)
            except Exception:
                if lease is not None:
                    lease.release()
                raise

    @staticmethod
    def _bounded_decompress(raw, wbits, max_output):
        """Decompress *raw* without allowing an attacker-controlled output blow-up."""
        limit = max(1, int(max_output or 1))
        obj = zlib.decompressobj(wbits)
        parts = []
        total = 0
        view = memoryview(raw) if _us_env.PY3 else raw
        for offset in range(0, len(view), 256 * 1024):
            pending = view[offset:offset + 256 * 1024]
            while pending:
                room = limit - total
                if room <= 0:
                    raise ValueError('Compressed M3U exceeds the decoded size limit')
                chunk = obj.decompress(pending, room + 1)
                if chunk:
                    total += len(chunk)
                    if total > limit:
                        raise ValueError('Compressed M3U exceeds the decoded size limit')
                    parts.append(chunk)
                pending = obj.unconsumed_tail
        room = limit - total
        tail = obj.flush(room + 1)
        total += len(tail)
        if total > limit:
            raise ValueError('Compressed M3U exceeds the decoded size limit')
        if tail:
            parts.append(tail)
        return b''.join(parts)

    def _decode_body(self, raw, encoding='', max_output=128 * 1024 * 1024):
        encoding = str(encoding or '').lower().strip()
        if encoding == 'gzip':
            try:
                raw = self._bounded_decompress(raw, 16 + zlib.MAX_WBITS, max_output)
            except Exception as exc:
                LOG.warning('M3U gzip decode failed: %s', exc)
                raise
        elif encoding == 'deflate':
            try:
                raw = self._bounded_decompress(raw, zlib.MAX_WBITS, max_output)
            except zlib.error:
                raw = self._bounded_decompress(raw, -zlib.MAX_WBITS, max_output)
            except Exception as exc:
                LOG.warning('M3U deflate decode failed: %s', exc)
                raise
        try:
            return raw.decode('utf-8-sig')
        except UnicodeDecodeError:
            return raw.decode('latin-1', 'replace')

    def probe(self, cancel_event=None, allow_cache=False):
        """Validate provider, optionally using a fresh persistent catalogue cache."""
        if cancel_event is not None and cancel_event.is_set():
            return {'ok': False, 'cancelled': True}
        if allow_cache and (not self._loaded) and self._read_persistent():
            return {'ok': True, 'mode': self._mode, 'status': 200, 'cached': True}
        if self._xtream:
            try:
                result = self._xtream_probe(cancel_event)
                LOG.info('M3U source accepted through Xtream-first probe')
                return result
            except ProviderBusyError:
                raise
            except ProviderCancelled as exc:
                raise M3UCancelledError(str(exc))
            except M3UCancelledError:
                return {'ok': False, 'cancelled': True}
            except Exception as xtream_first_exc:
                if self._mode == 'xtream':
                    LOG.warning('Remembered Xtream probe failed; falling back to M3U probe: %s', xtream_first_exc)
                else:
                    LOG.info('Xtream-first probe unavailable; trying M3U payload: %s', xtream_first_exc)
        last_exc = None
        for browser in (False, True):
            if cancel_event is not None and cancel_event.is_set():
                return {'ok': False, 'cancelled': True}
            try:
                attempt_timeout = self.probe_timeout + (20 if browser else 0)
                response = self._track_response(self._open_playlist(attempt_timeout, browser=browser, range_prefix=True, cancel_event=cancel_event))
                try:
                    status = int(getattr(response, 'status', 200) or 200)
                    final_url = str(getattr(response, 'geturl', lambda: self.url)() or self.url)
                    info = response.info()
                    encoding = str(info.get('Content-Encoding') or '')
                    content_type = str(info.get('Content-Type') or '')
                    raw = response.read(128 * 1024)
                finally:
                    self._untrack_response(response)
                    try:
                        response.close()
                    except Exception:
                        pass
                text = self._decode_body(raw, encoding, max_output=4 * 1024 * 1024)
                valid = text.lstrip().startswith('#EXTM3U') or '#EXTINF' in text
                LOG.info('M3U probe status=%s valid=%s bytes=%s type=%s', status, valid, len(raw), content_type or '?')
                if valid:
                    self._mode = 'm3u'
                    with _MEM_LOCK:
                        _mode_hint_set(self._cache_key(), 'm3u')
                    self._write_mode_hint('m3u')
                    self._last_error = ''
                    self._last_success = time.time()
                    return {'ok': True, 'mode': 'm3u', 'status': status, 'bytes': len(raw), 'content_type': content_type}
                last_exc = ValueError('Server responded, but the response was not an M3U playlist.')
            except ProviderBusyError:
                raise
            except Exception as exc:
                last_exc = exc
                LOG.warning('M3U probe attempt browser=%s failed: %s', browser, exc)
        self._last_error = str(last_exc or 'M3U probe failed')
        raise last_exc or RuntimeError('M3U probe failed')

    def _fetch(self, cancel_event=None):
        if cancel_event is not None and cancel_event.is_set():
            return ''
        last_exc = None
        attempts = ((False, 0), (True, 0), (False, 1), (True, 1))
        for browser, retry_no in attempts:
            if cancel_event is not None and cancel_event.is_set():
                return ''
            try:
                timeout = self.full_timeout + (15 if retry_no else 0)
                response = self._track_response(self._open_playlist(timeout, browser=browser, range_prefix=False, cancel_event=cancel_event))
                try:
                    status = int(getattr(response, 'status', 200) or 200)
                    final_url = str(getattr(response, 'geturl', lambda: self.url)() or self.url)
                    info = response.info()
                    content_type = str(info.get('Content-Type') or '')
                    encoding = str(info.get('Content-Encoding') or '').lower().strip()
                    chunks = []
                    total = 0
                    limit = 96 * 1024 * 1024
                    while total <= limit:
                        if cancel_event is not None and cancel_event.is_set():
                            raise M3UCancelledError('M3U fetch cancelled')
                        chunk = response.read(min(256 * 1024, limit + 1 - total))
                        if not chunk:
                            break
                        chunks.append(chunk)
                        total += len(chunk)
                    if total > limit:
                        raise ValueError('M3U playlist exceeds the compressed/raw size limit')
                    raw = b''.join(chunks)
                finally:
                    self._untrack_response(response)
                    try:
                        response.close()
                    except Exception:
                        pass
                text = self._decode_body(raw, encoding, max_output=128 * 1024 * 1024)
                if not text.lstrip().startswith('#EXTM3U') and '#EXTINF' not in text:
                    raise ValueError('The URL did not return a valid M3U playlist.')
                LOG.info('M3U fetch status=%s type=%s encoding=%s bytes=%s final=%s attempt=%s', status, content_type or '?', encoding or 'identity', len(raw), final_url, '%s/%s' % ('browser' if browser else 'vlc', retry_no + 1))
                return text
            except ProviderBusyError:
                raise
            except ProviderCancelled as exc:
                raise M3UCancelledError(str(exc))
            except M3UCancelledError:
                raise
            except Exception as exc:
                last_exc = exc
                LOG.warning('M3U full fetch attempt browser=%s retry=%s failed: %s', browser, retry_no, exc)
                if retry_no and (not self._is_timeout_error(exc)):
                    break
        self._last_error = str(last_exc or 'M3U fetch failed')
        raise last_exc or RuntimeError('M3U fetch failed')

    def _m3u_art_base(self):
        """Return a stable origin/directory for relative artwork in M3U rows."""
        try:
            parts = urllib.parse.urlsplit(self.url)
            if parts.scheme in ('http', 'https') and parts.netloc:
                path = parts.path or '/'
                if not path.endswith('/'):
                    path = path.rsplit('/', 1)[0] + '/' if '/' in path else '/'
                return urllib.parse.urlunsplit((parts.scheme, parts.netloc, path, '', ''))
        except (TypeError, ValueError):
            LOG.debug('Invalid M3U artwork base URL', exc_info=True)
        return self.url

    def _parse(self, text):
        import io
        live = []
        movies = []
        series_groups = {}
        genre_order = {'itv': [], 'vod': [], 'series': []}
        art_base = self._m3u_art_base()
        pending = None
        self._xmltv_urls = []
        self._xmltv_header_pending = False
        self._live_epg_map = {}
        self._live_native_refs = {}

        def add_genre(kind, group):
            if group not in genre_order[kind]:
                genre_order[kind].append(group)
        for raw in io.StringIO(str(text or '')):
            line = raw.strip()
            if not line:
                continue
            if line.lstrip('\ufeff').startswith('#EXTM3U'):
                from .xmltv_source import header_urls
                self._xmltv_urls = header_urls(line, self._normalized_url())
                continue
            if line.startswith('#EXTINF'):
                body = line.split(':', 1)[1] if ':' in line else ''
                quote = ''
                split_at = None
                for index, char in enumerate(body):
                    if char in ('"', "'"):
                        if not quote:
                            quote = char
                        elif char == quote:
                            quote = ''
                    elif char == ',' and (not quote):
                        split_at = index
                        break
                left = body if split_at is None else body[:split_at]
                title = '' if split_at is None else body[split_at + 1:]
                attrs = _attr_map(left)
                from .receiver_epg import reference_from_row
                pending = {'name': (attrs.get('tvg-name') or attrs.get('tvg_name') or title or 'Untitled').strip(), 'group': (attrs.get('group-title') or attrs.get('group_title') or attrs.get('group') or 'Other').strip() or 'Other', 'logo': (attrs.get('tvg-logo') or attrs.get('tvg_logo') or attrs.get('logo') or attrs.get('icon') or attrs.get('channel-logo') or '').strip(), 'tvg_id': (attrs.get('tvg-id') or attrs.get('tvg_id') or '').strip(), 'service_ref': reference_from_row(attrs)}
                continue
            if line.startswith('#'):
                if pending is not None:
                    if line.upper().startswith('#EXTGRP:'):
                        grp = line.split(':', 1)[1].strip()
                        if grp and pending.get('group') in ('', 'Other'):
                            pending['group'] = grp
                    elif line.upper().startswith('#EXTIMG:'):
                        img = line.split(':', 1)[1].strip()
                        if img and (not pending.get('logo')):
                            pending['logo'] = img
                continue
            if pending is None:
                pending = {'name': 'Stream', 'group': 'Other', 'logo': '', 'tvg_id': ''}
            e = pending
            pending = None
            name = e['name']
            group = e['group']
            url = line
            logo = e['logo']
            kind = _kind(group, name, url)
            common = {'name': name, 'title': name, 'cmd': url, 'url': url, 'logo': logo, 'logo_url': logo, 'picon': logo, 'stream_icon': logo, 'genre': group, 'category': group, 'category_id': group, 'tvg_id': e.get('tvg_id') or '', 'service_ref': e.get('service_ref') or '', '_art_base': art_base}
            provider_kind, provider_sid = self._xtream_stream_identity(url)
            if provider_sid:
                common['stream_id'] = provider_sid
                common['_xtream'] = True
                common['_xtream_kind'] = provider_kind or kind
                common['_art_base'] = self._xtream.get('base', '') or common.get('_art_base')
            if kind == 'series':
                nums = _episode_numbers(name)
                if not nums:
                    row = dict(common)
                    row['id'] = 'm3u-vod-' + _slug_id(url, name)
                    row['movie_id'] = row['id']
                    movies.append(row)
                    add_genre('vod', group)
                    continue
                season, episode = nums
                base = _series_base(name) or name
                skey = (us_casefold(group), us_casefold(base))
                sid = 'm3u-series-' + _slug_id(group, base)
                bucket = series_groups.setdefault(skey, {'id': sid, 'name': base, 'group': group, 'logo': logo, 'episodes': []})
                ep = dict(common)
                ep.update({'id': 'm3u-ep-' + _slug_id(url, name), 'episode_id': str(episode), 'episode': episode, 'number': episode, 'season': season, 'season_id': str(season), 'movie_id': sid, 'series_id': sid})
                bucket['episodes'].append(ep)
                add_genre('series', group)
            elif kind == 'vod':
                row = dict(common)
                row['id'] = 'm3u-vod-' + _slug_id(url, name)
                row['movie_id'] = row['id']
                movies.append(row)
                add_genre('vod', group)
            else:
                row = dict(common)
                row['id'] = 'm3u-live-' + _slug_id(url, name)
                row['ch_id'] = row['id']
                row['number'] = len(live) + 1
                live.append(row)
                add_genre('itv', group)
                self._remember_epg_channels([row])
        series = []
        self._series_index = {}
        for bucket in series_groups.values():
            eps = sorted(bucket['episodes'], key=lambda x: (int(x.get('season') or 0), int(x.get('episode') or 0)))
            provider_series = bool(self._xtream and any((isinstance(ep, dict) and ep.get('_xtream') for ep in eps)))
            item = {'id': bucket['id'], 'series_id': bucket['id'], 'movie_id': bucket['id'], 'name': bucket['name'], 'title': bucket['name'], 'genre': bucket['group'], 'category': bucket['group'], 'category_id': bucket['group'], 'logo': bucket['logo'], 'cover': bucket['logo'], 'cover_url': bucket['logo'], '_m3u_series': True, '_xtream': provider_series, '_xtream_kind': 'series', '_art_base': self._xtream.get('base', '') if provider_series else art_base}
            series.append(item)
            seasons = {}
            for ep in eps:
                seasons.setdefault(str(ep.get('season') or 1), []).append(ep)
            self._series_index[bucket['id']] = {'item': item, 'seasons': seasons}
        self._items = {'itv': live, 'vod': movies, 'series': series}
        self._genres = genre_order

    def _ensure(self, cancel_event=None, force=False):
        with self._lock:
            if self._loaded and (not force):
                return
            if not force and self._read_persistent():
                return
            if self._xtream:
                try:
                    self._xtream_probe(cancel_event)
                    self._load_xtream(cancel_event)
                    self._write_persistent()
                    return
                except ProviderBusyError:
                    raise
                except ProviderCancelled as exc:
                    raise M3UCancelledError(str(exc))
                except M3UCancelledError:
                    raise
                except Exception as xtream_boot_exc:
                    low = str(xtream_boot_exc).lower()
                    if any((marker in low for marker in ('469', '429', 'busy'))):
                        self._last_error = str(xtream_boot_exc)
                        raise
                    if self._mode == 'xtream':
                        LOG.warning('Xtream bootstrap failed; trying M3U payload: %s', xtream_boot_exc)
                    else:
                        LOG.info('Xtream bootstrap unavailable; trying M3U payload: %s', xtream_boot_exc)
            try:
                text = self._fetch(cancel_event)
                if not text.lstrip().startswith('#EXTM3U') and '#EXTINF' not in text:
                    raise ValueError('The URL did not return a valid M3U playlist.')
                self._parse(text)
                self._mode = 'm3u'
                self._loaded = True
                self._loaded_at = time.time()
                self._last_success = time.time()
                self._last_error = ''
                self._write_persistent()
                return
            except ProviderBusyError:
                raise
            except ProviderCancelled as exc:
                raise M3UCancelledError(str(exc))
            except M3UCancelledError:
                raise
            except Exception as m3u_exc:
                self._last_error = str(m3u_exc)
                raise
