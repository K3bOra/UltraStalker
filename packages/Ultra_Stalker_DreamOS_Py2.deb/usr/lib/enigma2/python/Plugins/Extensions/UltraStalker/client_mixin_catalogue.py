# -*- coding: utf-8 -*-
"""Genres, ordered lists and content/category search.

Methods moved verbatim out of ``StalkerClient`` (client.py); behaviour is unchanged.
This module is imported by client.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, zip, max, min, us_casefold
from .client import (
    CACHE,
    LOG,
    PERF,
    PortalCancelledError,
    PortalError,
    ThreadPoolExecutor,
    time,
)


class ClientCatalogueMixin(object):
    """Genres, ordered lists and content/category search."""

    def genres(self, media_type="itv", cancel_event=None):
        """Return provider categories without locally rewriting their names.

        Most Stalker portals expose Live folders through ``get_genres``.  A few
        newer variants return only short routing labels there (for example many
        different rows all called ``AR``) while ``get_categories`` contains the
        real folder names.  Only when the first response is clearly collapsed do
        we make the alternate request, so normal/older portals keep the original
        one-request fast path.
        """
        if not self.token:
            self.authorize(cancel_event=cancel_event)
        media_type = str(media_type or "itv").lower()
        errors = []

        def request_category(params):
            # Home already resolved/authorized a working MAG endpoint. Category
            # navigation should use that exact endpoint instead of scanning every
            # historical loader candidate with three retries each (which can turn
            # one dead request into several minutes of apparent UI freeze).
            cached = self._cache_get(params)
            if cached is not None:
                return cached
            endpoint = str(self.endpoint or "").strip()
            if not endpoint:
                return self._get(params, use_cache=True, cancel_event=cancel_event)
            seen_token = self.token
            try:
                data = self._request_endpoint(endpoint, params, cancel_event=cancel_event, max_attempts=1)
            except PortalCancelledError:
                raise
            except PortalError as exc:
                message = str(exc).lower()
                if any(marker in message for marker in ("http 401", "http 403", "authorization", "token")):
                    self._reauthorize(seen_token, cancel_event=cancel_event)
                    endpoint = str(self.endpoint or endpoint)
                    data = self._request_endpoint(endpoint, params, cancel_event=cancel_event, max_attempts=1)
                else:
                    raise
            self._cache_put_usable(params, data)
            return data

        def fetch(action):
            # Compatibility sort is useful only when a portal successfully returns
            # an empty result. Do not repeat a network timeout merely to add sortby.
            for compatibility_sort in (False, True):
                try:
                    params = {"type": media_type, "action": action, "JsHttpRequest": "1-xml"}
                    if compatibility_sort:
                        params["sortby"] = "number"
                    js = self._unwrap(request_category(params))
                    rows = self._as_list(js)
                    if rows or isinstance(js, list):
                        return rows if rows else js
                    # Successful empty response may need the legacy sortby variant.
                    continue
                except PortalError as exc:
                    errors.append(str(exc))
                    break
            return []

        def label(row):
            if not isinstance(row, dict):
                return str(row or "").strip()
            return str(row.get("title") or row.get("name") or row.get("category_name") or
                       row.get("genre_name") or row.get("label") or "").strip()

        def collapsed(rows):
            if not isinstance(rows, list) or len(rows) < 8:
                return False
            counts = {}
            usable = 0
            for row in rows:
                text = label(row)
                if not text:
                    continue
                usable += 1
                key = us_casefold(text)
                counts[key] = counts.get(key, 0) + 1
            if usable < 8:
                return False
            # Trigger only on repeated short routing labels.  This catches the
            # AR/AR/AR style response without penalising normal category lists.
            for key, count in counts.items():
                if count >= 3 and len(key) <= 4:
                    return True
            return False

        def quality(rows):
            if not isinstance(rows, list):
                return (0, 0, 0)
            labels = [label(row) for row in rows]
            labels = list(x for x in labels if x)
            if not labels:
                return (0, 0, 0)
            distinct = len(set(us_casefold(x) for x in labels))
            descriptive = sum(1 for x in labels if len(x) > 4 or any(sep in x for sep in ("|", " / ", " - ", "•")))
            total_chars = sum(min(len(x), 80) for x in labels)
            return (distinct, descriptive, total_chars)

        if media_type == "itv":
            primary = fetch("get_genres")
            if primary and collapsed(primary):
                alternate = fetch("get_categories")
                if alternate and quality(alternate) > quality(primary):
                    return alternate
            if primary:
                return primary
        else:
            for action in ("get_categories", "get_genres"):
                rows = fetch(action)
                if rows:
                    return rows

        if errors:
            raise PortalError(errors[-1])
        return []

    def ordered_page(self, media_type="itv", genre="*", page=1, cancel_event=None, force=False):
        """Return one native portal page plus pagination metadata.

        Catalogue navigation is latency-sensitive. Once Home/authorization has
        resolved the working MAG endpoint, use that exact endpoint for content
        pages too. Scanning every historic loader candidate (each with retries)
        made one category open take minutes on otherwise healthy portals.
        """
        if not self.token:
            self.authorize(cancel_event=cancel_event)
        media_type = str(media_type or "itv").lower()

        def request_catalogue(params):
            if not force:
                cached = self._cache_get(params)
                if cached is not None:
                    return cached
            endpoint = str(self.endpoint or "").strip()
            if not endpoint:
                return self._get(params, use_cache=True, cancel_event=cancel_event)
            seen_token = self.token
            try:
                data = self._request_endpoint(endpoint, params, cancel_event=cancel_event, max_attempts=1)
            except PortalCancelledError:
                raise
            except PortalError as exc:
                message = str(exc).lower()
                if any(marker in message for marker in ("http 401", "http 403", "authorization", "token")):
                    self._reauthorize(seen_token, cancel_event=cancel_event)
                    endpoint = str(self.endpoint or endpoint).strip()
                    data = self._request_endpoint(endpoint, params, cancel_event=cancel_event, max_attempts=1)
                else:
                    raise
            self._cache_put_usable(params, data)
            from .folder_refresh import note_fresh
            note_fresh(self,media_type,genre)
            return data

        # Compatibility sort is retried only after a successful empty response.
        # A timeout/transport failure must not immediately repeat the same slow
        # network path with a cosmetic sort parameter.
        for compatibility_sort in (False, True):
            params = {
                "type": media_type, "action": "get_ordered_list",
                "p": int(page), "JsHttpRequest": "1-xml",
            }
            if compatibility_sort:
                params["sortby"] = "number"
            if media_type == "itv":
                params["genre"] = genre
                params["force_ch_link_check"] = "1" if self._live_force_link_check else "0"
            elif media_type == "vod":
                params["category"] = genre
            elif media_type == "series":
                params.update({
                    "movie_id": "0", "season_id": "0", "episode_id": "0", "category": genre
                })
            js = self._unwrap(request_catalogue(params))
            if media_type == "itv":
                self._remember_live_link_policy(js if isinstance(js,dict) else {})
            rows = [row for row in self._as_list(js) if isinstance(row, dict) and row]
            meta = js if isinstance(js, dict) else {}
            result = {
                "items": rows,
                "page": self._int_value(meta.get("cur_page") or meta.get("page") or page or 1, page or 1),
                "page_size": max(1, self._int_value(meta.get("max_page_items") or meta.get("page_size") or len(rows) or 1, len(rows) or 1)),
                "total": max(0, self._int_value(meta.get("total_items") or meta.get("total") or 0, 0)),
            }
            LOG.info("CATALOGUE_DIAG type=%s category=%s page=%s rows=%s total=%s page_size=%s sort=%s", media_type, genre, page, len(rows), result.get("total"), result.get("page_size"), compatibility_sort)
            if rows or compatibility_sort:
                return result
        return {"items": [], "page": int(page), "page_size": 1, "total": 0}

    def ordered_list(self, media_type="itv", genre="*", page=1, cancel_event=None):
        return self.ordered_page(media_type, genre, page, cancel_event=cancel_event).get("items", [])

    def ordered_all(self, media_type="itv", genre="*", start_page=1, max_pages=None, max_items=None, cancel_event=None):
        """Collect a portal catalogue across native pages with loop protection."""
        max_pages = max(1, min(self._int_value(max_pages, self.MAX_CATALOG_PAGES), self.MAX_CATALOG_PAGES))
        max_items = max(1, min(self._int_value(max_items, self.MAX_CATALOG_ITEMS), self.MAX_CATALOG_ITEMS))
        page = max(1, self._int_value(start_page, 1))
        out, seen = [], set()
        for _ in range(max_pages):
            if cancel_event is not None and getattr(cancel_event, "is_set", lambda: False)():
                break
            payload = (self.ordered_page(media_type, genre, page, cancel_event=cancel_event)
                       if cancel_event is not None else self.ordered_page(media_type, genre, page))
            rows = payload.get("items") or []
            if not rows:
                break
            added = 0
            for row in rows:
                marker = self._item_identity(row)
                if marker in seen:
                    continue
                seen.add(marker)
                out.append(row)
                added += 1
                if len(out) >= max_items:
                    return out
            if not added:
                break
            total = max(0, self._int_value(payload.get("total"), 0))
            page_size = max(1, self._int_value(payload.get("page_size"), len(rows) or 1))
            if total and len(out) >= total:
                break
            if not total and len(rows) < page_size:
                break
            page += 1
        return out

    def _search_params(self, media_type, page, key=None, query=None):
        params = {"type": media_type, "action": "get_ordered_list", "p": int(page), "JsHttpRequest": "1-xml"}
        if media_type == "itv":
            params["genre"] = "*"
        elif media_type == "vod":
            params["category"] = "*"
        else:
            params.update({"movie_id": "0", "season_id": "0", "episode_id": "0", "category": "*"})
        if key:
            params[key] = str(query or "")
        return params

    def _search_catalogue(self, media_type, query, needle, limit, max_pages, cancel_event=None, deadline=None):
        """Search one catalogue with native search then a bounded full scan."""
        def stopped():
            if cancel_event is not None and getattr(cancel_event, "is_set", lambda: False)():
                return True
            return deadline is not None and time.monotonic() >= deadline

        selected_key = None
        first_payload = None
        for key in ("search", "search_str", "name"):
            if stopped(): return []
            try:
                js = self._unwrap(self._get(self._search_params(media_type, 1, key, query), use_cache=False, cancel_event=cancel_event))
                rows = self._as_list(js)
                if rows:
                    selected_key, first_payload = key, js
                    break
            except PortalCancelledError:
                return []
            except PortalError as exc:
                LOG.debug("Portal search variant failed type=%s key=%s: %s", media_type, key, exc)
        pages = first_payload if first_payload is not None else None
        result, seen = [], set(); page = 1
        for _ in range(max_pages):
            if stopped(): break
            if page == 1 and pages is not None:
                js = pages
            else:
                try:
                    params = self._search_params(media_type, page, selected_key, query) if selected_key else self._search_params(media_type, page)
                    js = self._unwrap(self._get(params, use_cache=not bool(selected_key), cancel_event=cancel_event))
                except PortalCancelledError:
                    break
                except PortalError:
                    break
            rows = list(row for row in self._as_list(js) if isinstance(row, dict))
            if not rows: break
            new_page = 0
            for row in rows:
                if stopped(): break
                marker = self._item_identity(row)
                if marker in seen: continue
                seen.add(marker); new_page += 1
                title = str(row.get("name") or row.get("title") or row.get("id") or "")
                hay = us_casefold(title + " " + str(row.get("description") or row.get("descr") or ""))
                if needle not in hay: continue
                item = dict(row); item["_search_media_type"] = media_type; result.append(item)
                if len(result) >= limit: return result
            if stopped() or not new_page: break
            meta = js if isinstance(js, dict) else {}
            total = max(0, self._int_value(meta.get("total_items") or meta.get("total"), 0))
            page_size = max(1, self._int_value(meta.get("max_page_items") or meta.get("page_size"), len(rows) or 1))
            if total and len(seen) >= total: break
            if not total and len(rows) < page_size: break
            page += 1
        return result

    def search_metadata_copies(self,query,media_type="vod",cancel_event=None,time_budget=4):
        """Filtered sibling lookup; no catalogue crawl or user Search-state mutation."""
        from .core.search_native import search_native
        from .provider_metadata_lookup import MetadataCandidates
        class SearchView(object):
            def __init__(self,owner):self.owner=owner
            def __getattr__(self,name):return getattr(self.owner,name)
            def _item_identity(self,row):
                # The same stream id can appear in two folders with different
                # prose. Metadata discovery must retain both language variants.
                return (str(self.owner._item_identity(row)),str(row.get('category_id') or row.get('genre_id') or ''),
                        str(row.get('description') or row.get('descr') or row.get('plot') or row.get('overview') or ''))
        view=SearchView(self)
        rows=search_native(view,query,(media_type,),24,3,cancel_event,
                           time_budget,None,allow_catalogue_fallback=False)
        return MetadataCandidates(rows,view._last_search_complete)

    def search_content_fast(self, query, media_types=("vod","series"), limit=80, max_pages=40, cancel_event=None, time_budget=8, on_partial=None, native_only=False):
        """Low-latency Stalker search with a non-destructive catalogue augment.

        Phase 1 intentionally preserves the old reliable behaviour: every media
        type gets its provider-native search turn first and every hit is published
        immediately.  Phase 2 then augments those hits from the real category
        catalogue, prioritising the category IDs learned from native matches.

        This ordering matters on portals where a provider-wide search returns one
        exact row while the browsable category contains several decorated copies.
        A slow movie catalogue must never consume the whole budget before Series
        gets its native request, and catalogue augmentation must never erase or
        delay already-found native results.
        """
        if native_only:
            from .core.search_native import search_native
            return search_native(self, query, media_types, max(1, int(limit)),
                                 max(1, int(max_pages)), cancel_event, time_budget, on_partial)
        started = time.monotonic()
        needle = us_casefold(str(query or "").strip())
        if not needle:
            return []
        limit = max(1, self._int_value(limit, 80))
        max_pages = max(1, min(self._int_value(max_pages, 40), 80))
        deadline = started + max(2.0, min(45.0, float(time_budget or 8)))
        if not self.token:
            self.authorize(cancel_event=cancel_event)

        media_types = tuple(str(x).lower() for x in media_types)
        out = []
        seen = set()
        native_hits = dict((typ, 0) for typ in media_types)
        priority_categories = dict((typ, []) for typ in media_types)

        def stopped(local_deadline=None):
            cap = deadline if local_deadline is None else min(deadline, local_deadline)
            return time.monotonic() >= cap or (cancel_event is not None and cancel_event.is_set())

        def row_category(row):
            if not isinstance(row, dict):
                return ""
            return str(row.get("category_id") or row.get("genre_id") or row.get("category") or row.get("genre") or "").strip()

        def add_rows(rows, media_type, forced_category=""):
            added = 0
            for row in rows or []:
                if stopped() or len(out) >= limit:
                    break
                if not isinstance(row, dict):
                    continue
                title = str(row.get("name") or row.get("title") or row.get("id") or "")
                hay = us_casefold(title + " " + str(row.get("description") or row.get("descr") or ""))
                if needle not in hay:
                    continue
                marker = (media_type, self._item_identity(row))
                if marker in seen:
                    continue
                seen.add(marker)
                item = dict(row)
                item["_search_media_type"] = media_type
                if forced_category and not row_category(item):
                    item["category_id"] = str(forced_category)
                out.append(item)
                added += 1
                cid = row_category(item)
                if cid and cid not in priority_categories.setdefault(media_type, []):
                    priority_categories[media_type].append(cid)
                if callable(on_partial):
                    try:
                        on_partial([dict(item)])
                    except Exception:
                        pass
            return added

        # Phase 1: native provider search for BOTH Movies and Series first.
        # Do not scan any catalogue until every type has had this quick turn.
        for media_type in media_types:
            if stopped() or len(out) >= limit:
                break
            for search_key in ("search", "search_str", "name"):
                if stopped():
                    break
                try:
                    js = self._unwrap(self._get(
                        self._search_params(media_type, 1, search_key, query),
                        use_cache=False, cancel_event=cancel_event,
                    ))
                    native_rows = list(x for x in self._as_list(js) if isinstance(x, dict))
                except Exception:
                    native_rows = []
                added = add_rows(native_rows, media_type)
                if added:
                    native_hits[media_type] = native_hits.get(media_type, 0) + added
                    # One useful native key is enough. Move to the next media
                    # type immediately so Series can never be starved by VOD.
                    break

        if stopped() or len(out) >= limit:
            return out

        # Phase 2: best-effort catalogue augmentation. Types with a native hit
        # go first because their category IDs give us a strong, cheap hint about
        # where sibling/decorated copies live. Remaining time is sliced fairly so
        # a huge VOD catalogue cannot starve Series (or vice versa).
        ordered_types = sorted(media_types, key=lambda typ: (0 if native_hits.get(typ) else 1, media_types.index(typ)))
        for type_pos, media_type in enumerate(ordered_types):
            if stopped() or len(out) >= limit:
                break
            now = time.monotonic()
            remaining = max(0.0, deadline - now)
            remaining_types = max(1, len(ordered_types) - type_pos)
            type_deadline = min(deadline, now + max(0.75, remaining / float(remaining_types)))

            cat_ids = list(priority_categories.get(media_type, []) or [])
            cat_seen = set(cat_ids)
            try:
                categories = self.genres(media_type, cancel_event=cancel_event) or []
            except Exception:
                categories = []
            for cat in categories:
                cid = str((cat or {}).get("id") or (cat or {}).get("genre_id") or (cat or {}).get("category_id") or "").strip() if isinstance(cat, dict) else ""
                if cid and cid not in cat_seen:
                    cat_seen.add(cid)
                    cat_ids.append(cid)
            if not cat_ids:
                cat_ids = ["*"]

            exhausted = set()
            page = 1
            # R5.64: fetch up to 3 categories of the same page concurrently on a
            # private short-lived pool (never the shared lanes: callers may
            # already run on them).  Results are consumed strictly in category
            # order, so ordering/limit/exhaustion rules equal the sequential
            # loop.  Playback-flagged threads stay sequential (thread-local).
            pool = None
            if (len(cat_ids) > 1 and not bool(getattr(self._priority_local, "playback", False))):
                pool = ThreadPoolExecutor(max_workers=3, thread_name_prefix="ultrastalker-search")

            def fetch_cat(cid_, page_):
                try:
                    payload_ = self.ordered_page(media_type, cid_, page_, cancel_event=cancel_event) or {}
                    return payload_, [x for x in payload_.get("items", []) if isinstance(x, dict)], False
                except Exception:
                    return {}, [], True

            try:
                while page <= max_pages and not stopped(type_deadline) and len(out) < limit:
                    any_live = False
                    live = list(c for c in cat_ids if c not in exhausted)
                    idx = 0
                    while idx < len(live):
                        if stopped(type_deadline) or len(out) >= limit:
                            break
                        batch = live[idx:idx + (3 if pool is not None else 1)]
                        idx += len(batch)
                        any_live = True
                        if pool is not None and len(batch) > 1:
                            futs = list(pool.submit(fetch_cat, c, page) for c in batch)
                            fetched = []
                            for f in futs:
                                try:
                                    fetched.append(f.result())
                                except Exception:
                                    fetched.append(({}, [], True))
                        else:
                            fetched = list(fetch_cat(c, page) for c in batch)
                        for cid, (payload, rows, failed) in zip(batch, fetched):
                            if stopped(type_deadline) or len(out) >= limit:
                                break
                            if failed or not rows:
                                exhausted.add(cid)
                                continue
                            add_rows(rows, media_type, forced_category=cid)
                            total = max(0, self._int_value(payload.get("total") or payload.get("total_items"), 0))
                            page_size = max(1, self._int_value(payload.get("page_size") or payload.get("max_page_items"), len(rows) or 1))
                            if total and page * page_size >= total:
                                exhausted.add(cid)
                            elif not total and len(rows) < page_size:
                                exhausted.add(cid)
                    if not any_live:
                        break
                    page += 1
            finally:
                if pool is not None:
                    try:
                        pool.shutdown(wait=False, cancel_futures=True)
                    except TypeError:
                        try:
                            pool.shutdown(wait=False)
                        except Exception:
                            pass
                    except Exception:
                        pass

        return out

    def search_category_fast(self, query, media_type="vod", category="*", limit=120, max_pages=18, cancel_event=None, time_budget=5):
        """Fast search constrained to one provider folder/category.

        Unlike :meth:`search_content_fast`, this never intentionally broadens to
        the whole portal.  It asks the native ordered-list endpoint with the
        *current* category plus the provider search key, then falls back to a
        bounded scan of that same category only.  The UI owns the authoritative
        full-folder fallback when a provider cannot search its category natively.
        """
        started=time.monotonic();needle=us_casefold(str(query or "").strip())
        if not needle:return []
        media_type=str(media_type or "vod").lower();category=str(category if category not in (None,"") else "*")
        limit=max(1,self._int_value(limit,120));max_pages=max(1,min(self._int_value(max_pages,18),40))
        deadline=started+max(1.5,min(10.0,float(time_budget or 5)))
        if not self.token:self.authorize(cancel_event=cancel_event)
        out=[];seen=set()
        def stopped():
            return ((cancel_event is not None and cancel_event.is_set()) or time.monotonic()>=deadline)
        def wanted(row):
            title=str(row.get("name") or row.get("title") or row.get("id") or "")
            hay=us_casefold(title+" "+str(row.get("description") or row.get("descr") or ""))
            if needle not in hay:return False
            # When the provider supplies an explicit folder marker, require it
            # to agree with the folder we asked for.  Missing markers are common
            # on Stalker search rows and are trusted only because the request
            # itself is category-scoped.
            marker=row.get("category_id")
            if marker in (None,""):marker=row.get("category")
            if marker in (None,""):marker=row.get("genre_id")
            if marker in (None,""):marker=row.get("genre")
            if marker not in (None,"") and category not in ("*","") and str(marker)!=category:
                return False
            return True
        def add_rows(rows):
            for row in rows:
                if stopped():break
                if not isinstance(row,dict) or not wanted(row):continue
                ident=self._item_identity(row)
                if ident in seen:continue
                seen.add(ident);item=dict(row);item["_search_media_type"]=media_type;out.append(item)
                if len(out)>=limit:return True
            return False

        # Native search, but with the CURRENT category instead of '*'.
        for search_key in ("search","search_str","name"):
            if stopped():break
            page=1;native_found=False
            while page<=max_pages and not stopped():
                params=self._search_params(media_type,page,search_key,query)
                if media_type=="itv":params["genre"]=category
                else:params["category"]=category
                try:
                    js=self._unwrap(self._get(params,use_cache=False,cancel_event=cancel_event))
                    rows=list(x for x in self._as_list(js) if isinstance(x,dict))
                except Exception:
                    rows=[];js={}
                if not rows:break
                # A few Stalker implementations accept the search parameter but
                # silently ignore the requested category and return portal-wide
                # rows.  One explicit foreign folder marker is enough to distrust
                # that native response entirely; never mix its marker-less rows
                # into a folder-scoped result.  Fall through to exact-folder page
                # scanning instead.
                foreign=False
                if category not in ("*",""):
                    for _row in rows:
                        if not isinstance(_row,dict):continue
                        _marker=_row.get("category_id")
                        if _marker in (None,""):_marker=_row.get("category")
                        if _marker in (None,""):_marker=_row.get("genre_id")
                        if _marker in (None,""):_marker=_row.get("genre")
                        if _marker not in (None,"") and str(_marker)!=category:
                            foreign=True;break
                if foreign:
                    out=[];seen=set();native_found=False;break
                before=len(out)
                if add_rows(rows):return out
                native_found=native_found or len(out)>before
                meta=js if isinstance(js,dict) else {}
                total=max(0,self._int_value(meta.get("total_items") or meta.get("total"),0))
                page_size=max(1,self._int_value(meta.get("max_page_items") or meta.get("page_size"),len(rows) or 1))
                if total and page*page_size>=total:break
                if not total and len(rows)<page_size:break
                page+=1
            if native_found:return out

        # Some portals ignore all native search keys.  Scan only the current
        # folder, bounded by the same short UI budget.  If this returns empty,
        # the grid performs the old complete-folder authoritative fallback.
        page=1
        while page<=max_pages and not stopped():
            try:payload=self.ordered_page(media_type,category,page,cancel_event=cancel_event) or {};rows=list(x for x in payload.get("items",[]) if isinstance(x,dict))
            except Exception:break
            if not rows:break
            if add_rows(rows):return out
            total=max(0,self._int_value(payload.get("total"),0));page_size=max(1,self._int_value(payload.get("page_size"),len(rows) or 1))
            if total and page*page_size>=total:break
            if not total and len(rows)<page_size:break
            page+=1
        return out

    def search_content(self, query, media_types=("itv", "vod", "series"), limit=120, max_pages=None, cancel_event=None, time_budget=12):
        """Unified search with cache, cancellation and an overall time budget."""
        started=time.monotonic()
        needle = us_casefold(str(query or "").strip())
        if not needle: return []
        limit = max(1, self._int_value(limit, 120))
        max_pages = max(1, min(self._int_value(max_pages, self.MAX_CATALOG_PAGES), self.MAX_CATALOG_PAGES))
        budget=max(1.0,min(30.0,float(time_budget or 12)))
        media_types=tuple(str(x).lower() for x in media_types)
        cache_params={"action":"search_content","q":needle,"types":",".join(media_types),"limit":limit,"pages":max_pages,"budget":int(budget)}
        cache_key=self._cache_key(cache_params)
        cached=CACHE.get(cache_key)
        if isinstance(cached,list):
            PERF.increment("search.cache_hits")
            return cached
        if cancel_event is not None and getattr(cancel_event, "is_set", lambda: False)(): return []
        deadline=started+budget
        if not self.token:
            self.authorize(cancel_event=cancel_event)
        result, seen = [], set()
        for media_type in media_types:
            if time.monotonic() >= deadline or (cancel_event is not None and getattr(cancel_event, "is_set", lambda: False)()): break
            remaining = limit - len(result)
            if remaining <= 0: break
            rows = self._search_catalogue(media_type, query, needle, remaining, max_pages, cancel_event=cancel_event, deadline=deadline)
            for item in rows:
                marker = (media_type, self._item_identity(item))
                if marker in seen: continue
                seen.add(marker); result.append(item)
                if len(result) >= limit: break
            if len(result) >= limit: break
        if not (cancel_event is not None and getattr(cancel_event, "is_set", lambda: False)()):
            CACHE.put(cache_key,result,self.SEARCH_CACHE_TTL)
        PERF.record("search.total_ms",(time.monotonic()-started)*1000.0)
        PERF.increment("search.executions")
        return result
