# -*- coding: utf-8 -*-
"""Ultra Stalker receiver-local media library.

R56 turns Local into a first-class media source:
- Local Home is only three Home-style cards on the Palestine master background.
- Movies / Series open the *existing* Premium Global Cinematic presentation.
- Local inventory warms after mount discovery; cached Movies / Series open immediately.
- Local poster/backdrop files are reused immediately when present.
- Missing metadata/artwork is left to the existing TMDb/cache authority, so it is
  resolved once and reused from HDD on later visits.
- Series use the native Details -> Seasons -> Episodes hierarchy.
- Playback stays on the existing UltraStalkerPlayer via a local-path client.
- Browse remains a clean glass-card grid for manual filesystem access.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str, int, open, round, zip, max, min, OSError, us_clear, us_casefold, us_func

hashlib = _us_env.hashlib
json = _us_env.json
os = _us_env.os
OrderedDict = _us_env.collections.OrderedDict
re = _us_env.re
threading = _us_env.threading
time = _us_env.time

from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap
from enigma import ePoint, eSize, eTimer, gFont, getDesktop
from skin import parseColor

from .ui_compact_footer import compact_footer_skin, install_compact_footer
from . import _
from .storage import load_settings
from .log import optional_failure
from .title_clean import display_title as _display_title
from .ui_fixed_adaptive import fixed_home_assets
from .persistent_cache import INDEX as _CACHE_INDEX, hdd_ready as _hdd_ready, hdd_read_ready as _hdd_read_ready, ensure_persistent_dirs as _ensure_cache_dirs, persistent_write_gate as _persistent_write_gate


VIDEO_EXTENSIONS = {
    ".mkv", ".mp4", ".avi", ".mov", ".m4v", ".ts", ".m2ts", ".mts",
    ".webm", ".mpg", ".mpeg", ".vob", ".wmv", ".flv", ".3gp",
}
IMAGE_EXTENSIONS = (".jpg", ".jpeg", ".png", ".webp")
MOVIE_DIR_NAMES = {
    "movie", "movies", "film", "films", "video", "videos", "vod",
    "افلام", "أفلام", "فيلم",
}
SERIES_DIR_NAMES = {
    "series", "serie", "serial", "serials", "tv", "tvshow", "tvshows",
    "tv show", "tv shows", "shows", "show", "مسلسل", "مسلسلات",
}
SEASON_RE = re.compile(r"(?i)^(?:season|series|s)[ ._-]*(\d{1,3})$")
_BARE_SEASON_RE = re.compile(r"^\s*0*(\d{1,3})\s*$")
_LOCALIZED_SEASON_RE = re.compile(r"(?iu)^(?:part|pt|الموسم|موسم|الجزء|جزء)[ ._-]*(\d{1,3})$")
EPISODE_RE = re.compile(r"(?i)(?:\bS(\d{1,3})[ ._-]*E(\d{1,4})\b|\b(\d{1,3})x(\d{1,4})\b)")
YEAR_RE = re.compile(r"(?<!\d)((?:19|20)\d{2})(?!\d)")
_SIMPLE_EPISODE_RE = re.compile(r"(?iu)^\s*(?:(episode|ep|e|الحلقة|حلقه)[ ._-]*)?0*(\d{1,4})(?:[ ._-]+.*)?$")
_EPISODE_FALSE_NUMBERS = {360, 480, 576, 720, 1080, 1440, 2160, 4320}

# R57: Local Movies/Series scan the storage itself instead of trusting one
# specially named library folder.  Technical receiver/cache trees are pruned so
# a media scan never wastes time walking picons, backups or Ultra Stalker cache.
_MEDIA_SCAN_SKIP = {
    "ajpanel backup", "ajpanel eliesatpanel", "backup", "backups",
    "channels backup", "crossepg", "imagebackups", "picon", "setpicon",
    "timeshift", "title logos", "transmission", "ultrastalker",
    "lost+found", "cache", "tmp", "temp",
}
RECEIVER_LOCAL_ROOT = "/home/root"

# R60 Local index: classification is expensive only once.  The index lives in
# Ultra Stalker's existing HDD index directory, not in a separate Local cache.
# Movies/Series reopen from this compact JSON without walking the HDD again.
_LOCAL_INDEX_SCHEMA = 5
_LOCAL_INDEX_PATH = os.path.join(_CACHE_INDEX, "local_media_index_v3.json")
_LOCAL_INDEX_LOCK = threading.RLock()
_LOCAL_BUILD_LOCK = threading.RLock()
_LOCAL_INDEX_MEMORY_MAX = 4
_LOCAL_INDEX_MEMORY = OrderedDict()
# Last successful presentation only. Fresh discovery still runs on each entry;
# no filesystem probes or JSON parsing are needed to paint this snapshot.
_LOCAL_HOME_SNAPSHOT = None
_LOCAL_CHECK_PENDING = set()
_LOCAL_CHECK_AT = {}
_LOCAL_SUMMARY_TTL = 60.0


def _remember_local_media_index(key,row):
    if not isinstance(row,dict):
        return
    with _LOCAL_INDEX_LOCK:
        try:_LOCAL_INDEX_MEMORY.pop(key,None)
        except Exception:pass
        _LOCAL_INDEX_MEMORY[key]=dict(row)
        while len(_LOCAL_INDEX_MEMORY)>_LOCAL_INDEX_MEMORY_MAX:
            try:_LOCAL_INDEX_MEMORY.popitem(last=False)
            except Exception:break


def _local_index_key(roots):
    values=[]
    for path in roots or []:
        try:values.append(os.path.realpath(str(path or "")))
        except Exception:pass
    return tuple(sorted(set(x for x in values if x)))


def _local_directory_stamp(path):
    st=os.stat(path)
    return [int(st.st_dev),int(st.st_ino),
            int(getattr(st,"st_mtime_ns",st.st_mtime*1000000000)),
            int(getattr(st,"st_ctime_ns",st.st_ctime*1000000000))]


def _local_inventory_unchanged(row, cancel_event=None):
    """Check directory identities/timestamps, never list files on a cache hit.

    Every visited directory (including empty ones) is tracked: a new nested
    movie/season, deletion or rename changes its parent's stamp. Device/inode
    checks also reject a replacement drive mounted at the same path.
    """
    stamps=row.get("directory_stamps") if isinstance(row,dict) else None
    if not isinstance(stamps,dict) or not stamps:return False
    for path,stamp in stamps.items():
        if cancel_event is not None and cancel_event.is_set():return False
        try:
            if _local_directory_stamp(path)!=stamp:return False
        except OSError:return False
    return True


def _local_roots_match(row, roots):
    stamps=row.get("directory_stamps") or {}
    for root in roots:
        saved=stamps.get(root)
        if not saved:return False
        try:
            if _local_directory_stamp(root)[:2]!=saved[:2]:return False
        except OSError:return False
    return True


def _schedule_local_index_check(roots):
    """One bounded background validation per root set, shared by Movies/Series."""
    roots=list(roots);key=_local_index_key(roots);now=time.monotonic()
    with _LOCAL_INDEX_LOCK:
        if len(_LOCAL_CHECK_PENDING)>=4 or key in _LOCAL_CHECK_PENDING or now-_LOCAL_CHECK_AT.get(key,-1e9)<30:return
        _LOCAL_CHECK_PENDING.add(key)
    def work():
        try:LocalMediaClient(roots,"vod")._scan_inventory(None)
        except Exception as exc:optional_failure("ui.local_index_check",exc)
        finally:
            with _LOCAL_INDEX_LOCK:
                _LOCAL_CHECK_PENDING.discard(key)
                if len(_LOCAL_CHECK_AT)>16:_LOCAL_CHECK_AT.clear()
                _LOCAL_CHECK_AT[key]=time.monotonic()
    try:
        from .core.shared_executors import LOCAL_STORAGE_EXECUTOR
        LOCAL_STORAGE_EXECUTOR.submit(work)
    except Exception:
        with _LOCAL_INDEX_LOCK:_LOCAL_CHECK_PENDING.discard(key)


def _load_local_media_index(roots):
    key=_local_index_key(roots)
    with _LOCAL_INDEX_LOCK:
        row=_LOCAL_INDEX_MEMORY.get(key)
        if isinstance(row,dict):
            try:_LOCAL_INDEX_MEMORY.move_to_end(key)
            except Exception:pass
            return dict(row)
    if not _hdd_read_ready():return {}
    try:
        with open(_LOCAL_INDEX_PATH,"r",encoding="utf-8") as h:row=json.load(h)
        if not isinstance(row,dict) or int(row.get("schema") or 0) not in (4,_LOCAL_INDEX_SCHEMA):return {}
        if tuple(row.get("roots") or ())!=key:return {}
        if not isinstance(row.get("movies"),list) or not isinstance(row.get("series"),list):return {}
        _remember_local_media_index(key,row)
        return row
    except Exception:
        return {}


def _save_local_media_index(roots,movies,groups,directory_stamps=None):
    key=_local_index_key(roots)
    movie_rows=[]
    for raw in movies or []:
        path=str(raw.get("path") if isinstance(raw,dict) else raw or "")
        if not path:continue
        title=str(raw.get("title") or "") if isinstance(raw,dict) else ""
        if not title:title=_clean_filename(path)
        movie_rows.append({
            "path":path,"title":title,"year":str((raw.get("year") if isinstance(raw,dict) else "") or _year_from(os.path.basename(path)))[:4],
            "poster":str((raw.get("poster") if isinstance(raw,dict) else "") or _sidecar_art(path,"poster") or ""),
            "backdrop":str((raw.get("backdrop") if isinstance(raw,dict) else "") or _sidecar_art(path,"backdrop") or ""),
        })
    payload={
        "schema":_LOCAL_INDEX_SCHEMA,"roots":list(key),"built_at":int(time.time()),
        "movies":movie_rows,"series":[],"directory_stamps":dict(directory_stamps or {}),"ordered":True,
    }
    for _key,group in (groups or {}).items():
        if not isinstance(group,dict):continue
        series_dir=str(group.get("dir") or "")
        seasons=sorted({int(x[1]) for x in (group.get("episodes") or []) if isinstance(x,(list,tuple)) and len(x)>=4})
        payload["series"].append({
            "id":_stable_id("local-series",series_dir+"/__ultra_series__/"+_norm(group.get("title") or "")),
            "seasons":seasons,"episode_count":len(group.get("episodes") or []),
            "title":str(group.get("title") or ""),"dir":series_dir,
            "poster":str(group.get("poster") or _sidecar_art(series_dir,"poster") or ""),
            "backdrop":str(group.get("backdrop") or _sidecar_art(series_dir,"backdrop") or ""),
            "episodes":list([str(x[0]),int(x[1]),int(x[2]),str(x[3] or "")] for x in (group.get("episodes") or []) if isinstance(x,(list,tuple)) and len(x)>=4),
        })
    payload["movies"].sort(key=lambda x:_natural_key(x.get("title") or ""))
    payload["series"].sort(key=lambda x:_natural_key(x.get("title") or ""))
    _remember_local_media_index(key,payload)
    if not _hdd_ready():return False
    try:
        if not _ensure_cache_dirs(_CACHE_INDEX):return False
        temp=_LOCAL_INDEX_PATH+".tmp.%d.%d"%(os.getpid(),threading.get_ident())
        if not _persistent_write_gate(temp):return False
        with open(temp,"w",encoding="utf-8") as h:
            json.dump(payload,h,ensure_ascii=False,separators=(",",":"));h.flush();os.fsync(h.fileno())
        if not _persistent_write_gate(_LOCAL_INDEX_PATH):return False
        os.replace(temp,_LOCAL_INDEX_PATH)
        return True
    except Exception:
        try:
            if os.path.exists(temp) and _persistent_write_gate(temp):os.unlink(temp)
        except Exception:pass
        return False


def _decode_local_media_index(row):
    movies=[]
    for raw in row.get("movies") or []:
        if isinstance(raw,dict) and raw.get("path"):
            movies.append({"path":str(raw.get("path")),"title":str(raw.get("title") or ""),"year":str(raw.get("year") or "")[:4],"poster":str(raw.get("poster") or ""),"backdrop":str(raw.get("backdrop") or "")})
        elif raw:
            movies.append({"path":str(raw),"title":"","year":"","poster":"","backdrop":""})
    groups={}
    for idx,group in enumerate(row.get("series") or []):
        if not isinstance(group,dict):continue
        title=str(group.get("title") or "").strip();series_dir=str(group.get("dir") or "")
        episodes=[]
        for x in group.get("episodes") or []:
            try:episodes.append((str(x[0]),int(x[1]),int(x[2]),str(x[3] or "")))
            except Exception:continue
        if title and episodes:groups[(idx,title,series_dir)]={"title":title,"dir":series_dir,"poster":str(group.get("poster") or ""),"backdrop":str(group.get("backdrop") or ""),"episodes":episodes}
    return movies,groups


def _invalidate_local_media_index(roots=None):
    key=_local_index_key(roots or []) if roots is not None else None
    with _LOCAL_INDEX_LOCK:
        if key is None:us_clear(_LOCAL_INDEX_MEMORY)
        else:_LOCAL_INDEX_MEMORY.pop(key,None)
    try:
        if _hdd_ready() and os.path.isfile(_LOCAL_INDEX_PATH) and _persistent_write_gate(_LOCAL_INDEX_PATH):os.unlink(_LOCAL_INDEX_PATH)
    except Exception:pass


def _asset(name):
    return os.path.join(os.path.dirname(__file__), "assets_fhd", str(name or ""))


def _natural_key(value):
    return [int(x) if x.isdigit() else x.lower() for x in re.split(r"(\d+)", str(value or ""))]


def _norm(value):
    text = us_casefold(str(value or "").strip()).replace("_", " ").replace("-", " ")
    return " ".join(text.split())


def _clean_text(value):
    raw = re.sub(r"[._]+", " ", str(value or ""))
    raw = re.sub(r"\s+", " ", raw).strip()
    try:
        return str(_display_title(raw, enabled=True) or raw).strip()
    except Exception:
        return raw


_DOWNLOAD_TAG_RE = re.compile(r"\s*\[[0-9a-f]{20}\]\s*$", re.I)


def _strip_download_tag(stem):
    """Remove the ' [<20 hex>]' id the download manager appends to file names."""
    return _DOWNLOAD_TAG_RE.sub("", str(stem or "")) or str(stem or "")


def _clean_filename(path):
    return _clean_text(_strip_download_tag(os.path.splitext(os.path.basename(path))[0]))


def _is_storage_path(path):
    try:
        path = os.path.realpath(path)
        if not os.path.isdir(path):
            return False
        root_dev = os.stat("/").st_dev
        return os.stat(path).st_dev != root_dev or os.path.ismount(path)
    except Exception:
        return False


def _is_swap_storage(path, source="", fs=""):
    """Recognize dedicated swap mounts, never a data drive merely hosting swap."""
    if str(fs or "").lower() in ("swap","linux-swap","linux-swap(v1)"):return True
    markers={"swap","swapfile","swapfiles","swapspace","swap-partition","swap_partition","linux-swap","linux_swap"}
    parts=str(path or "").replace("\\","/").rstrip("/").lower().split("/")
    if any(part in markers for part in parts):return True
    src=str(source or "").rstrip("/").lower()
    return bool(("/by-label/" in src or src.startswith("label=")) and src.rsplit("/",1)[-1].replace("label=","") in markers)


def _swap_storage_sources():
    """Resolve only /dev label symlinks; do not probe or mount any partition."""
    out=set();folder="/dev/disk/by-label"
    try:
        for label in os.listdir(folder):
            if _is_swap_storage("/"+label):out.add(os.path.realpath(os.path.join(folder,label)))
    except OSError:pass
    return out


def _storage_roots():
    """Discover mounted local drives without waking every /media automount."""
    out=[];seen=set();swap_sources=_swap_storage_sources()
    try:
        with open("/proc/mounts","r") as stream:
            for line in stream:
                fields=line.split()
                if len(fields)<3:continue
                path=fields[1].replace("\\040"," ").replace("\\134","\\")
                fs=fields[2].lower()
                if fs=="autofs" or fields[0] in swap_sources or _is_swap_storage(path,fields[0],fs):continue
                if not path.startswith(("/media/","/mnt/")):continue
                if path not in seen:seen.add(path);out.append(path)
    except OSError:
        # Fallback is bounded to the conventional local mount points.
        for path in ("/media/hdd","/media/usb"):
            if not _is_swap_storage(path) and _is_storage_path(path) and path not in seen:seen.add(path);out.append(path)
    receiver=os.path.realpath(RECEIVER_LOCAL_ROOT)
    if receiver not in seen and os.path.isdir(receiver):out.append(receiver)
    out.sort(key=lambda p:(0 if p=="/media/hdd" else 1 if p==receiver else 2,_natural_key(p)))
    return out


def _discover_named_dirs(roots, aliases):
    aliases = {_norm(x) for x in aliases}
    found, seen = [], set()
    for root in roots:
        try:
            names = os.listdir(root)
        except Exception:
            continue
        for name in names:
            if name.startswith(".") or _norm(name) not in aliases:
                continue
            path = os.path.realpath(os.path.join(root, name))
            try:
                if not os.path.isdir(path) or path in seen:
                    continue
            except Exception:
                continue
            seen.add(path)
            found.append(path)
    found.sort(key=_natural_key)
    return found


def _iter_video_files(base, cancel_event=None, directory_stamps=None):
    """One traversal; record stamps before listing so concurrent edits retry."""
    pending=[base]
    while pending:
        if cancel_event is not None and cancel_event.is_set():return
        current=pending.pop()
        # One unreadable / vanished / permission-locked folder must not abort the
        # whole library scan (it would leave Movies and Series empty).
        try:stamp=_local_directory_stamp(current)
        except OSError:continue
        if directory_stamps is not None:directory_stamps[current]=stamp
        try:scanner=os.scandir(current)
        except OSError:continue
        with scanner as entries:
            while True:
                if cancel_event is not None and cancel_event.is_set():return
                try:entry=next(entries)
                except StopIteration:break
                except OSError:break
                try:
                    name=entry.name
                    if name.startswith(".") or name=="@eaDir":continue
                    if entry.is_dir(follow_symlinks=False):
                        if _norm(name) not in _MEDIA_SCAN_SKIP:pending.append(entry.path)
                        elif _norm(name)=="ultrastalker":
                            # The plugin cache tree stays pruned, but movies and
                            # episodes downloaded by the plugin are real media.
                            sub=os.path.join(entry.path,"Downloads")
                            if os.path.isdir(sub):pending.append(sub)
                        continue
                    is_video=os.path.splitext(name)[1].lower() in VIDEO_EXTENSIONS and entry.is_file()
                except OSError:
                    continue
                if is_video:yield entry.path


def _stable_id(prefix, value):
    digest = hashlib.sha1(os.path.realpath(str(value or "")).encode("utf-8", "ignore")).hexdigest()[:20]
    return "%s-%s" % (prefix, digest)


def _year_from(value):
    match = YEAR_RE.search(str(value or ""))
    return match.group(1) if match else ""


def _simple_episode_number(value):
    """Return a conservative episode number for filenames like 08 / E08 / Episode 08.

    Bare four-digit movie years/resolutions are deliberately rejected.  This is
    used only after folder context says the file is series-like.
    """
    stem=os.path.splitext(os.path.basename(str(value or "")))[0]
    match=_SIMPLE_EPISODE_RE.match(stem)
    if not match:return None
    try:number=int(match.group(2) or 0)
    except Exception:return None
    if number<=0 or number>9999:return None
    explicit=bool(match.group(1))
    if not explicit:
        if number in _EPISODE_FALSE_NUMBERS:return None
        if 1900<=number<=2099:return None
        # Bare numeric episode filenames above three digits are too ambiguous.
        if len(str(number))>3:return None
    return number


def _is_under(path, root):
    try:
        real=os.path.realpath(path);base=os.path.realpath(root)
        return real==base or real.startswith(base.rstrip("/")+"/")
    except Exception:return False


def _meaningful_series_dir(path):
    name=os.path.basename(os.path.realpath(str(path or "")).rstrip("/"))
    norm=_norm(name)
    generic={_norm(x) for x in (MOVIE_DIR_NAMES|SERIES_DIR_NAMES)}|set(_MEDIA_SCAN_SKIP)|{"hdd","usb","media","mnt","root"}
    return bool(name and norm and norm not in generic)


def _season_dir_number(value, allow_bare=False):
    """Return a real season number from a folder label.

    Named labels (Season 2 / S02 / Part 2 / الموسم 2) are always accepted.
    Bare numeric folders (1 / 02 / 3) are accepted only when the caller has
    already established series/show context.  Keeping that context requirement
    prevents numeric movie/show titles such as ``24`` from being mistaken for a
    season at the library root.
    """
    text=str(value or "").strip()
    match=SEASON_RE.match(text) or _LOCALIZED_SEASON_RE.match(text)
    if not match and allow_bare:
        match=_BARE_SEASON_RE.match(text)
    if not match:return None
    try:number=int(match.group(1) or 0)
    except Exception:return None
    if number<1 or number>999:return None
    return number


def _named_series_show_dir(path, named_roots):
    """Return the first show folder below a conventional Series/TV root."""
    real=os.path.realpath(path)
    for root in sorted([os.path.realpath(x) for x in (named_roots or [])],key=len,reverse=True):
        if not _is_under(real,root) or real==root:continue
        try:parts=os.path.relpath(real,root).split(os.sep)
        except Exception:continue
        # parts includes the filename.  A show folder must exist before it.
        if len(parts)>=2 and not SEASON_RE.match(str(parts[0] or "").strip()):
            return os.path.join(root,parts[0])
    return ""


def _smart_series_identity(path, named_series_roots=None, direct_stats=None):
    """Classify one local video as an episode using filename + folder structure.

    Priority is explicit SxxEyy/1x02 and Season folders, followed by receiver-local
    library structure: Series/Show/08.mkv or Show/08.mkv.  Numeric files inside a
    movie/vod tree need multiple episode-like siblings before they are promoted to
    a series, preventing numeric movie titles from being stolen by the TV lane.
    """
    explicit=_series_identity(path)
    if explicit:
        title,season,episode,episode_title,series_dir=explicit
        # Repair a generic fallback title (e.g. .../series/Season 01/08.mkv)
        # from the first meaningful show folder when one exists.
        show_dir=_named_series_show_dir(path,named_series_roots or [])
        if show_dir and _norm(title) in ({_norm(x) for x in SERIES_DIR_NAMES}|{_norm(x) for x in MOVIE_DIR_NAMES}):
            title=_clean_text(os.path.basename(show_dir.rstrip("/")));series_dir=show_dir
        return title,season,episode,episode_title,series_dir

    parent=os.path.dirname(os.path.realpath(path));stem=_strip_download_tag(os.path.splitext(os.path.basename(path))[0])
    simple=_simple_episode_number(stem)
    show_dir=_named_series_show_dir(path,named_series_roots or [])
    season=1
    # If a conventional Series/TV root owns the file, the first child folder is
    # the show identity even when episodes are named only 01.mkv / Pilot.mkv.
    if show_dir:
        cur=parent
        while _is_under(cur,show_dir) and cur!=show_dir:
            # R66: many receiver libraries use bare numeric season folders:
            #   Series/Bloodhounds/1/01.mkv
            #   Series/Bloodhounds/2/01.mkv
            # In established show context, 1/2 are Season 1/2, not generic
            # subfolders.  This keeps duplicate episode numbers separated.
            parsed_season=_season_dir_number(os.path.basename(cur.rstrip("/")),allow_bare=True)
            if parsed_season is not None:
                season=int(parsed_season)
                break
            nxt=os.path.dirname(cur.rstrip("/")) or cur
            if nxt==cur:break
            cur=nxt
        stats=(direct_stats or {}).get(parent,{})
        episode=simple
        if episode is None:
            # In an explicit Series tree, arbitrary episode labels are legal.
            # Give them a stable natural-order number supplied by the inventory.
            episode=(stats.get("ordinal") or {}).get(os.path.realpath(path))
        if episode:
            title=_clean_text(os.path.basename(show_dir.rstrip("/")))
            ep_title=_clean_text(stem)
            if not ep_title or ep_title==str(episode):ep_title=_("Episode %s")%int(episode)
            return title,int(season),int(episode),ep_title,show_dir

    # R66: outside a conventionally named Series/TV root, a bare numeric
    # parent folder still carries season meaning when its parent is a sensible
    # show folder.  Example: /media/hdd/My Show/2/08.mkv.
    bare_season=_season_dir_number(os.path.basename(parent.rstrip("/")),allow_bare=True)
    if simple is not None and bare_season is not None:
        show_parent=os.path.dirname(parent.rstrip("/"))
        if _meaningful_series_dir(show_parent):
            stats=(direct_stats or {}).get(parent,{})
            if int(stats.get("count") or 0)>=1:
                title=_clean_text(os.path.basename(show_parent.rstrip("/")))
                ep_title=_clean_text(stem)
                if not ep_title or ep_title==str(simple):ep_title=_("Episode %s")%int(simple)
                return title,int(bare_season),int(simple),ep_title,show_parent

    if simple is None or not _meaningful_series_dir(parent):return None
    stats=(direct_stats or {}).get(parent,{})
    simple_count=int(stats.get("simple_count") or 0);count=int(stats.get("count") or 0)
    parent_parent=_norm(os.path.basename(os.path.dirname(parent.rstrip("/"))))
    movie_parents={_norm(x) for x in MOVIE_DIR_NAMES}
    # Outside a named Series root, a direct numeric/Episode filename is accepted
    # when the folder clearly contains an episode run.  A single episode is also
    # accepted outside a conventional movie/vod folder.
    if simple_count<2 and parent_parent in movie_parents:return None
    if simple_count<1 or count<1:return None
    title=_clean_text(os.path.basename(parent.rstrip("/")))
    ep_title=_clean_text(stem)
    if not ep_title or ep_title==str(simple):ep_title=_("Episode %s")%int(simple)
    return title,1,int(simple),ep_title,parent


def _series_identity(path):
    stem = _strip_download_tag(os.path.splitext(os.path.basename(path))[0])
    parent = os.path.dirname(path)
    parent_name = os.path.basename(parent.rstrip("/"))
    season_dir_match = SEASON_RE.match(parent_name.strip())
    match = EPISODE_RE.search(stem)
    fallback_match = None
    if not match and season_dir_match:
        # Common local-library layouts use Season 01/01.mkv or
        # Season 01/Episode 01.mkv instead of repeating S01E01 in every file.
        fallback_match = re.search(r"(?i)(?:^|[ ._-])(?:episode|ep|e)[ ._-]*(\d{1,4})(?:\b|$)", stem)
        if not fallback_match:
            fallback_match = re.search(r"^\s*(\d{1,4})(?:[ ._-]|$)", stem)
    if not match and not fallback_match:
        return None
    if match:
        season = int(match.group(1) or match.group(3) or 0)
        episode = int(match.group(2) or match.group(4) or 0)
        prefix = re.sub(r"[._-]+", " ", stem[:match.start()]).strip()
        suffix = re.sub(r"^[ ._-]+", "", stem[match.end():])
    else:
        season = int(season_dir_match.group(1) or 0)
        episode = int(fallback_match.group(1) or 0)
        prefix = ""
        suffix = re.sub(r"^[ ._-]+", "", stem[fallback_match.end():])
    series_dir = os.path.dirname(parent) if season_dir_match else parent
    title = _clean_text(prefix) if prefix else _clean_text(os.path.basename(series_dir.rstrip("/")))
    if not title:
        title = _clean_text(os.path.basename(os.path.dirname(parent).rstrip("/")))
    episode_title = _clean_text(suffix)
    if not episode_title or episode_title == title:
        episode_title = _("Episode %s") % episode
    return title, season, episode, episode_title, series_dir


def _first_existing(candidates):
    for path in candidates:
        try:
            if path and os.path.isfile(path) and os.path.getsize(path) > 100:
                return path
        except Exception:
            pass
    return ""


def _sidecar_art(video_or_dir, kind):
    """Reuse common local-media artwork names without copying or rescaling them."""
    is_dir = os.path.isdir(video_or_dir)
    base_dir = video_or_dir if is_dir else os.path.dirname(video_or_dir)
    stem = "" if is_dir else os.path.splitext(os.path.basename(video_or_dir))[0]
    names = []
    if kind == "poster":
        if stem:
            names += list(stem + ext for ext in IMAGE_EXTENSIONS)
            names += list(stem + "-poster" + ext for ext in IMAGE_EXTENSIONS)
        for base in ("poster", "folder", "cover", "movie", "season"):
            names += list(base + ext for ext in IMAGE_EXTENSIONS)
    else:
        if stem:
            for suffix in ("-fanart", "-backdrop", "-background"):
                names += list(stem + suffix + ext for ext in IMAGE_EXTENSIONS)
        for base in ("fanart", "backdrop", "background", "landscape"):
            names += list(base + ext for ext in IMAGE_EXTENSIONS)
    return _first_existing([os.path.join(base_dir, name) for name in names])


def _attach_local_art(item, poster="", backdrop=""):
    if poster and os.path.isfile(poster):
        item["poster_local"] = poster
        item["_poster_local"] = poster
        item["_poster_source_local"] = poster
        item["_cin_provider_poster_local"] = poster
        item["_ultra_poster_source"] = poster
        item["_ultra_palette_source"] = poster
        item["_adaptive_source_local"] = poster
        item["_player_poster"] = poster
    if backdrop and os.path.isfile(backdrop):
        item["backdrop_local"] = backdrop
        item["_backdrop_source_local"] = backdrop
        item["_cin_provider_backdrop_local"] = backdrop
    return item


def _base_local_item(path, title, media_type="vod"):
    item_id = _stable_id("local-%s" % media_type, path)
    item = {
        "id": item_id,
        "movie_id": item_id if media_type == "vod" else None,
        "series_id": item_id if media_type == "series" else None,
        "name": str(title or ""),
        "title": str(title or ""),
        "_raw_name": str(title or ""),
        "_local_path": str(path or ""),
        "cmd": str(path or ""),
        "url": str(path or ""),
        "_source_type": "local",
        "source_type": "local",
        "_portal": "local://receiver",
        "_mac": "local",
        "_server_name": "Local",
        "_local_media": True,
        "_local_artwork_required": True,
        # Local has no provider TMDb id. Resolve the clean name first, then hand
        # the verified id to the one shared canonical HDD media library.
        "_local_name_first_identity": True,
        "_local_identity_title": str(title or ""),
        "media_type": ("tv" if media_type == "series" else ("episode" if media_type == "episode" else "movie")),
        "_provider_name": str(title or ""),
        "display_name": str(title or ""),
    }
    year = _year_from(os.path.basename(path) if path else title)
    if year:
        item["year"] = year
    item["_history_item"] = dict(item)
    return {k: v for k, v in item.items() if v is not None}


def _movie_item(path):
    title = _clean_filename(path)
    if _norm(title) in {_norm(x) for x in MOVIE_DIR_NAMES}|{"video","file"}:
        parent=os.path.basename(os.path.dirname(os.path.realpath(path)).rstrip("/"))
        if parent and _norm(parent) not in {_norm(x) for x in MOVIE_DIR_NAMES|SERIES_DIR_NAMES}:
            title=_clean_text(parent)
    item = _base_local_item(path, title, "vod")
    item["movie_name"]=title
    return _attach_local_art(item, _sidecar_art(path, "poster"), _sidecar_art(path, "backdrop"))


def _episode_item(path, title, season, episode, episode_title, series_item=None):
    item = _base_local_item(path, episode_title, "episode")
    item.update({
        "episode_id": item["id"],
        "episode": int(episode),
        "episode_number": int(episode),
        "number": int(episode),
        "season": int(season),
        "season_number": int(season),
        "series_title": title,
        "_series_title": title,
    })
    if isinstance(series_item, dict):
        item["_series_id"] = series_item.get("series_id") or series_item.get("id")
        poster = str(series_item.get("_poster_source_local") or series_item.get("poster_local") or "")
        if poster and os.path.isfile(poster):
            item["_player_poster"] = poster
            item["_adaptive_source_local"] = poster
    item["_history_item"] = dict(item)
    return item


def _make_local_profile(profile=None):
    out = dict(profile or {})
    out.update({
        "portal": "local://receiver",
        "mac": "LOCAL",
        "name": "Local",
        "source_type": "local",
        "type": "local",
    })
    # Never let stale provider credentials/source flags classify Local as M3U/Xtream.
    for key in ("m3u_url", "playlist_url", "xtream", "xtream_url"):
        out.pop(key, None)
    return out


class LocalMediaClient(object):
    """Tiny provider-compatible adapter backed exclusively by receiver storage.

    R6 speed contract:
    - HDD walking happens only when the index is missing, directory stamps
      change, or GREEN Refresh is pressed on Local Home.
    - Normal Movies/Series entry reads the already-cached JSON inventory from
      RAM/HDD and materializes only the requested 14-item page.
    - Series episodes are materialized only after one series is opened.
    """
    PAGE_SIZE = 14

    def __init__(self, roots, mode):
        self.roots = [x for x in (roots or []) if not _is_swap_storage(x)]
        self.mode = "series" if str(mode) == "series" else "vod"
        self._items = None
        self._series = {}
        self._catalog = None
        self._ordered_raw = None
        self._series_raw = {}


    def _scan_inventory(self, cancel_event=None):
        # Serialize builders; a second opener rechecks the completed first build.
        with _LOCAL_BUILD_LOCK:
            return self._scan_inventory_owned(cancel_event)

    def _scan_inventory_owned(self, cancel_event=None):
        """Reuse an unchanged inventory; rebuild only after directory changes.

        Paths/classification stay independent from shared TMDb metadata/artwork.
        Directory stamps are captured in the same traversal as the inventory.
        """
        cached=_load_local_media_index(self.roots)
        if cached and _local_inventory_unchanged(cached,cancel_event):
            return _decode_local_media_index(cached)
        videos=[];seen=set();directory_stamps={}
        # Scan each real storage root once. Named movie/series directories are
        # classification hints, not separate recursive scans of the same bytes.
        for base in list(self.roots or []):
            for path in _iter_video_files(base,cancel_event,directory_stamps):
                if cancel_event is not None and cancel_event.is_set():return [],{}
                try:real=os.path.realpath(path)
                except Exception:continue
                if real in seen:continue
                seen.add(real);videos.append(real)
        videos.sort(key=_natural_key)

        direct={}
        for path in videos:
            parent=os.path.dirname(path);row=direct.setdefault(parent,{"files":[],"count":0,"simple_count":0,"ordinal":{}})
            row["files"].append(path);row["count"]+=1
            if _simple_episode_number(os.path.splitext(os.path.basename(path))[0]) is not None:row["simple_count"]+=1
        for parent,row in direct.items():
            for pos,path in enumerate(sorted(row.get("files") or [],key=_natural_key),1):row["ordinal"][os.path.realpath(path)]=pos

        named_series=_discover_named_dirs(self.roots,SERIES_DIR_NAMES)
        groups={};movies=[]
        for path in videos:
            if cancel_event is not None and cancel_event.is_set():return [],{}
            parsed=_smart_series_identity(path,named_series,direct)
            if not parsed:
                movies.append(path);continue
            title,season,episode,episode_title,series_dir=parsed
            key=(_norm(title),os.path.realpath(series_dir))
            group=groups.setdefault(key,{"title":title,"dir":series_dir,"episodes":[]})
            group["episodes"].append((path,int(season),int(episode),episode_title))
        if cancel_event is not None and cancel_event.is_set():return [],{}
        _save_local_media_index(self.roots,movies,groups,directory_stamps)
        cached=_load_local_media_index(self.roots)
        return _decode_local_media_index(cached) if cached else (movies,groups)

    def _ensure_catalog(self, cancel_event=None):
        """Load a validated compact inventory and materialize one page only.

        RAM/disk hits require directory stats, never a recursive file listing.
        Natural ordering is persisted so reopen does not sort the whole library.
        """
        if isinstance(self._catalog,dict):
            return self._catalog
        # Runs on the existing async page worker, never on GUI paint.
        # Root identity is cheap; full directory validation runs off this page worker.
        row=_load_local_media_index(self.roots)
        if not row or not _local_roots_match(row,self.roots):
            self._scan_inventory(cancel_event)
        else:
            _schedule_local_index_check(self.roots)
        if cancel_event is not None and cancel_event.is_set():
            return {"movies":[],"series":[]}
        row=_load_local_media_index(self.roots)
        if not isinstance(row,dict):row={}
        self._catalog=row
        if self.mode == "series":
            raw=list(row.get("series") or [])
            if not row.get("ordered"):raw.sort(key=lambda x:_natural_key(str(x.get("title") or "")))
            self._ordered_raw=raw
            self._series_raw={}
            for group in raw:
                title=str(group.get("title") or "").strip();series_dir=str(group.get("dir") or "")
                if not title or not series_dir:continue
                sid=str(group.get("id") or "") or _stable_id("local-series",series_dir+"/__ultra_series__/"+_norm(title))
                self._series_raw[sid]=group
        else:
            raw=list(row.get("movies") or [])
            if not row.get("ordered"):raw.sort(key=lambda x:_natural_key(str(x.get("title") or "") or _clean_filename(str(x.get("path") or ""))))
            self._ordered_raw=raw
        return self._catalog

    def _movie_from_raw(self, raw):
        path=str(raw.get("path") or "")
        title=str(raw.get("title") or "") or _clean_filename(path)
        item=_base_local_item(path,title,"vod");item["movie_name"]=title
        if raw.get("year"):item["year"]=str(raw.get("year"))[:4]
        return _attach_local_art(item,str(raw.get("poster") or ""),str(raw.get("backdrop") or ""))

    def _series_from_raw(self, group):
        title=str(group.get("title") or "").strip();series_dir=str(group.get("dir") or "")
        if not title or not series_dir:return None
        episode_count=int(group.get("episode_count") or len(group.get("episodes") or []))
        seasons=group.get("seasons")
        if not isinstance(seasons,list):
            seasons=sorted({int(x[1]) for x in group.get("episodes") or [] if len(x)>=4})
        if not episode_count:return None
        item=_base_local_item(series_dir,title,"series")
        logical_id=str(group.get("id") or "") or _stable_id("local-series",series_dir+"/__ultra_series__/"+_norm(title))
        item["id"]=logical_id;item["series_id"]=logical_id;item["series_name"]=title
        item["_history_item"]=dict(item)
        item["number_of_seasons"]=len(seasons);item["number_of_episodes"]=episode_count
        item["_local_season_count"]=len(seasons)
        item["_local_max_season"]=max(seasons) if seasons else 0
        item["_local_episode_count"]=episode_count
        item["_local_series_key"]=logical_id;item["_local_series_dir"]=series_dir
        return _attach_local_art(item,str(group.get("poster") or ""),str(group.get("backdrop") or ""))

    def _build_movies(self, cancel_event=None):
        self._ensure_catalog(cancel_event)
        rows=[]
        for raw in self._ordered_raw or []:
            if cancel_event is not None and cancel_event.is_set():break
            rows.append(self._movie_from_raw(raw))
        return rows

    def _build_series(self, cancel_event=None):
        self._ensure_catalog(cancel_event)
        rows=[]
        for group in self._ordered_raw or []:
            if cancel_event is not None and cancel_event.is_set():break
            item=self._series_from_raw(group)
            if item:rows.append(item)
        return rows

    def _ensure(self, cancel_event=None):
        # Compatibility path for any external caller that explicitly asks for a
        # fully materialized catalog. Normal Cinematic paging no longer uses it.
        if self._items is None:
            self._items = self._build_series(cancel_event) if self.mode == "series" else self._build_movies(cancel_event)
        return self._items

    def ordered_page(self, media_type, genre, page, cancel_event=None):
        """Materialize only the requested page instead of the whole library."""
        self._ensure_catalog(cancel_event)
        raw=self._ordered_raw or []
        page=max(1,int(page or 1));size=self.PAGE_SIZE;start=(page-1)*size
        chunk=raw[start:start+size]
        items=[]
        if self.mode == "series":
            for group in chunk:
                if cancel_event is not None and cancel_event.is_set():break
                item=self._series_from_raw(group)
                if item:items.append(item)
        else:
            for row in chunk:
                if cancel_event is not None and cancel_event.is_set():break
                items.append(self._movie_from_raw(row))
        return {"items":items,"page_size":size,"total":len(raw)}

    def create_link(self, item_or_cmd, media_type="itv", series_id=None, cancel_event=None):
        if cancel_event is not None and cancel_event.is_set():
            return ""
        if isinstance(item_or_cmd, dict):
            return str(item_or_cmd.get("_local_path") or item_or_cmd.get("cmd") or item_or_cmd.get("url") or "")
        return str(item_or_cmd or "")

    def _series_episode_map(self, sid, series_item=None, cancel_event=None):
        if sid in self._series:
            return self._series.get(sid,{})
        self._ensure_catalog(cancel_event)
        group=self._series_raw.get(sid)
        if not isinstance(group,dict):return {}
        title=str(group.get("title") or "").strip();raw=[]
        for x in group.get("episodes") or []:
            try:raw.append((str(x[0]),int(x[1]),int(x[2]),str(x[3] or "")))
            except Exception:continue
        raw.sort(key=lambda x:(int(x[1]),int(x[2]),_natural_key(x[0])))
        if series_item is None:
            series_item=self._series_from_raw(group) or {}
        by_season={}
        for path,season,episode,episode_title in raw:
            if cancel_event is not None and cancel_event.is_set():return {}
            by_season.setdefault(int(season),[]).append(_episode_item(path,title,season,episode,episode_title,series_item))
        self._series[sid]=by_season
        return by_season

    def series_seasons(self, series_item, cancel_event=None):
        self._ensure_catalog(cancel_event)
        sid=str((series_item or {}).get("_local_series_key") or (series_item or {}).get("series_id") or (series_item or {}).get("id") or "")
        seasons=self._series_episode_map(sid,series_item,cancel_event)
        rows=[]
        for number in sorted(seasons):
            episodes=[dict(x) for x in seasons.get(number,[]) if isinstance(x,dict)]
            rows.append({
                "id":int(number),"season_id":int(number),"season":int(number),"season_number":int(number),
                "name":_("Season %s") % int(number),"episodes":episodes,"series":episodes,
                "parent_series_id":sid,"episode_count":len(episodes),
            })
        return rows

    def series_episodes(self, series_item, season_item, cancel_event=None):
        if cancel_event is not None and cancel_event.is_set():return []
        self._ensure_catalog(cancel_event)
        sid=str((series_item or {}).get("_local_series_key") or (series_item or {}).get("series_id") or (series_item or {}).get("id") or "")
        try:sn=int((season_item or {}).get("season_number") or (season_item or {}).get("season") or (season_item or {}).get("season_id") or (season_item or {}).get("id") or 0)
        except Exception:sn=0
        seasons=self._series_episode_map(sid,series_item,cancel_event)
        return [dict(x) for x in seasons.get(sn,[]) if isinstance(x,dict)]

    def enrich_provider_artwork(self, item, media_type, cancel_event=None, force=False):
        return dict(item or {})

    def reset_failure_backoff(self, *args, **kwargs):
        return None

    def _bump_content_cache_generation(self, *args, **kwargs):
        return None


# ---------------------------------------------------------------------------
# Local root + manual Browse. Movies / Series use the existing Cinematic UI.
# ---------------------------------------------------------------------------
def _build_local_skin():
    AS = "/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/"
    parts = [r'''
<screen name="LocalLibraryScreen" position="center,center" size="1920,1080" backgroundColor="#02070b" flags="wfNoBorder">
 <ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/ultra_bg_clean_1920x1080.png" alphatest="off" zPosition="0"/>
 <widget name="page_title" position="62,52" size="700,64" font="Regular;46" halign="left" valign="center" foregroundColor="#ffffff" transparent="1" zPosition="8" noWrap="1" shadowColor="#000000" shadowOffset="2,2"/>
 <widget name="page_sub" position="64,114" size="1100,34" font="Regular;22" halign="left" valign="center" foregroundColor="#c9ccd1" transparent="1" zPosition="8" noWrap="1" shadowColor="#000000" shadowOffset="2,2"/>
 <ePixmap position="64,156" size="120,4" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/page_underline_120x4.png" alphatest="blend" zPosition="8"/>
''']
    for i in range(3):
        x = 250 + i * 470
        parts.append(' <widget name="root_bg%d" position="%d,487" size="340,296" alphatest="blend" scale="1" transparent="1" zPosition="5"/>\n' % (i, x + 20))
        parts.append(' <widget name="root_icon%d" position="%d,544" size="136,102" alphatest="blend" scale="1" transparent="1" zPosition="12"/>\n' % (i, x + 122))
        parts.append(' <widget name="root_title%d" position="%d,670" size="340,50" font="Regular;30" halign="center" valign="center" foregroundColor="#c9ccd1" transparent="1" zPosition="8" noWrap="1" shadowColor="#000000" shadowOffset="1,1"/>\n' % (i, x + 20))
        parts.append(' <widget name="root_sub%d" position="%d,733" size="380,30" font="Regular;19" halign="center" valign="center" foregroundColor="#9fd6bf" transparent="1" zPosition="8" noWrap="1" shadowColor="#000000" shadowOffset="1,1"/>\n' % (i, x))
    for i in range(3):
        parts.append(' <widget name="sp_bg%d" position="2000,0" size="460,140" alphatest="blend" scale="1" transparent="1" zPosition="4"/>\n' % i)
        parts.append(' <widget name="sp_cap%d" position="2000,0" size="300,24" font="Regular;17" halign="left" valign="center" foregroundColor="#9fd6bf" transparent="1" zPosition="8" noWrap="1"/>\n' % i)
        parts.append(' <widget name="sp_name%d" position="2000,0" size="300,40" font="Regular;26" halign="left" valign="center" foregroundColor="#ffffff" transparent="1" zPosition="8" noWrap="1" shadowColor="#000000" shadowOffset="1,1"/>\n' % i)
        parts.append(' <widget name="sp_track%d" position="2000,0" size="404,10" alphatest="blend" scale="1" transparent="1" zPosition="6"/>\n' % i)
        parts.append(' <widget name="sp_fill%d" position="2000,0" size="404,10" alphatest="blend" scale="1" transparent="1" zPosition="7"/>\n' % i)
        parts.append(' <widget name="sp_used%d" position="2000,0" size="300,28" font="Regular;20" halign="left" valign="center" foregroundColor="#e8eaed" transparent="1" zPosition="8" noWrap="1" shadowColor="#000000" shadowOffset="1,1"/>\n' % i)

    xs = (55, 313, 571, 829, 1087, 1345, 1603);ys = (675, 885);slot = 0
    for y in ys:
        for x in xs:
            parts.append(' <widget name="grid_bg%d" position="%d,%d" size="238,190" alphatest="blend" transparent="1" zPosition="5"/>\n' % (slot, x, y))
            parts.append(' <widget name="grid_icon%d" position="%d,%d" size="112,82" alphatest="blend" scale="1" transparent="1" zPosition="12"/>\n' % (slot, x + 63, y + 18))
            parts.append(' <widget name="grid_title%d" position="%d,%d" size="212,66" font="Regular;20" halign="center" valign="center" foregroundColor="#ffffff" transparent="1" zPosition="8" shadowColor="#000000" shadowOffset="1,1"/>\n' % (slot, x + 13, y + 108))
            parts.append(' <widget name="grid_sel%d" position="%d,%d" size="238,190" alphatest="blend" transparent="1" zPosition="10"/>\n' % (slot, x, y))
            slot += 1
    parts.append(' <widget name="refresh_status" position="55,1042" size="760,28" font="Regular;18" halign="left" valign="center" foregroundColor="#8fffc1" transparent="1" zPosition="30" noWrap="1"/>\n')
    parts.append(' <widget name="red_dash" position="1456,1033" size="56,42" alphatest="blend" scale="1" transparent="1" zPosition="28"/>\n')
    parts.append(' <widget name="red" position="1514,1033" size="126,42" font="Regular;20" halign="left" valign="center" foregroundColor="#ffffff" transparent="1" zPosition="29" noWrap="1" shadowColor="#000000" shadowOffset="1,1"/>\n')
    parts.append(' <widget name="green_dash" position="1690,1033" size="56,42" alphatest="blend" scale="1" transparent="1" zPosition="28"/>\n')
    parts.append(' <widget name="green" position="1748,1033" size="126,42" font="Regular;20" halign="left" valign="center" foregroundColor="#ffffff" transparent="1" zPosition="29" noWrap="1" shadowColor="#000000" shadowOffset="1,1"/>\n')
    parts.append("</screen>")
    return "".join(parts)


from .wqhd_layout import scale_skin as _wqhd_scale_skin, xy as _wqhd_xy, wh as _wqhd_wh, font_size as _wqhd_font

LOCAL_SKIN = _wqhd_scale_skin(compact_footer_skin(_build_local_skin()))


class LocalLibraryScreen(Screen):
    skin = LOCAL_SKIN
    PAGE_SIZE = 14;COLS = 7
    GRID_X = (55, 313, 571, 829, 1087, 1345, 1603);GRID_Y = (675, 885)

    def __init__(self, session, profile=None):
        us_func(Screen.__init__)(self, session)
        self.profile = dict(profile or {})
        self.local_profile = _make_local_profile(self.profile)
        # Root discovery, large index JSON and statvfs can wake an HDD/NFS
        # mount. None belongs in Screen construction or the first draw.
        snapshot=_LOCAL_HOME_SNAPSHOT or {}
        self.roots=[x for x in (snapshot.get('roots') or []) if not _is_swap_storage(x)]
        self._local_closed=False;self._local_summary_again=False
        self._local_summary_ready=bool(self.roots);self._local_summary_running=False
        self._local_summary_generation=0;self._local_summary_at=float(snapshot.get("at") or 0.)
        self._local_counts=tuple(snapshot.get('counts') or (0,0,0))
        self._local_storage_rows=[dict(row) for row in (snapshot.get('devices') or []) if not _is_swap_storage(row.get('name'))]
        self._local_open_pending=None;self._local_summary_future=None
        self._browse_visuals_bound=False
        self.mode = "root";self.current_path = None;self.entries = [];self.index = 0;self._visuals_bound = False
        for i in range(3):
            self["root_bg%d" % i] = Pixmap();self["root_icon%d" % i] = Pixmap();self["root_title%d" % i] = Label("");self["root_sub%d" % i] = Label("")
        self["page_title"] = Label("");self["page_sub"] = Label("")
        for _i in range(3):
            self["sp_bg%d" % _i] = Pixmap();self["sp_track%d" % _i] = Pixmap();self["sp_fill%d" % _i] = Pixmap()
            for _n in ("sp_cap","sp_name","sp_used"):self["%s%d" % (_n, _i)] = Label("")
        self["red_dash"] = Pixmap();self["red"] = Label(_("Back"))
        self._root_state = {}
        for i in range(self.PAGE_SIZE):
            self["grid_bg%d" % i] = Pixmap();self["grid_sel%d" % i] = Pixmap();self["grid_icon%d" % i] = Pixmap();self["grid_title%d" % i] = Label("")
        self["refresh_status"] = Label("")
        self["green_dash"] = Pixmap()
        self["green"] = Label(_("Refresh"))
        self._local_refresh_pending=False
        self._local_refresh_start_timer=eTimer();self._local_refresh_hide_timer=eTimer()
        self._local_refresh_start_conn=None;self._local_refresh_hide_conn=None
        try:self._local_refresh_start_conn=self._local_refresh_start_timer.timeout.connect(self._run_local_refresh)
        except Exception:self._local_refresh_start_timer.callback.append(self._run_local_refresh)
        try:self._local_refresh_hide_conn=self._local_refresh_hide_timer.timeout.connect(self._hide_local_refresh_status)
        except Exception:self._local_refresh_hide_timer.callback.append(self._hide_local_refresh_status)
        self.onClose.append(self._stop_local_refresh_timers)
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "ColorActions"], {
            "cancel": self.go_back, "ok": self.open_selected,
            "left": lambda: self._move(-1, 0), "right": lambda: self._move(1, 0),
            "up": lambda: self._move(0, -1), "down": lambda: self._move(0, 1),
            # GREEN is the deliberate manual Local re-index for newly copied
            # media; normal entry validates directory stamps on the page worker.
            "green": self.refresh_local_index,
        }, -1)
        self.onLayoutFinish.append(self._first_paint)
        install_compact_footer(self)

    def refresh_local_index(self):
        # Manual refresh is intentionally available only on the three-card
        # Local Home. Show visible feedback first, then rebuild on the next UI
        # turn so the viewer can see that GREEN was accepted.
        if self.mode != "root" or getattr(self,"_local_refresh_pending",False):
            return
        self._local_refresh_pending=True
        try:self._local_refresh_hide_timer.stop()
        except Exception:pass
        try:self["refresh_status"].setText(_("Refreshing local library..."));self["refresh_status"].show()
        except Exception:pass
        try:self._local_refresh_start_timer.start(30,True)
        except Exception:self._run_local_refresh()

    def _run_local_refresh(self):
        # The walk can take a long time on a large HDD; never block the GUI for it.
        roots=list(self.roots or [])
        def work():
            ok=True
            try:
                roots=_storage_roots()
                _invalidate_local_media_index(roots)
                # Movies and Series share one inventory, so one scan rebuilds both.
                LocalMediaClient(roots, "vod")._scan_inventory(None)
            except Exception:
                ok=False
            try:
                from twisted.internet import reactor
                reactor.callFromThread(self._local_refresh_done,ok)
            except Exception:
                pass
        try:
            threading.Thread(target=work,name="ultrastalker-local-refresh",daemon=True).start()
        except Exception:
            self._local_refresh_done(False)

    def _local_refresh_done(self,ok):
        self._local_refresh_pending=False
        if getattr(self,"_local_closed",False):return
        try:
            if self.mode=="root":self._request_local_summary(force=True)
        except Exception:pass
        try:
            self["refresh_status"].setText(_("Local library refreshed") if ok else _("Local refresh failed"))
            self["refresh_status"].show()
        except Exception:pass
        try:self._local_refresh_hide_timer.start(2200,True)
        except Exception:pass

    def _hide_local_refresh_status(self):
        try:self["refresh_status"].setText("");self["refresh_status"].hide()
        except Exception:pass

    def _stop_local_refresh_timers(self):
        cancel=getattr(self,"_browse_scan_cancel",None)
        if cancel is not None:cancel.set()
        self._local_closed=True;self._local_summary_generation+=1
        future=getattr(self,'_local_summary_future',None)
        if future is not None:future.cancel()
        self._local_open_pending=None
        for timer in (getattr(self,"_local_refresh_start_timer",None),getattr(self,"_local_refresh_hide_timer",None)):
            if timer is None:continue
            try:timer.stop()
            except Exception:pass
        for timer,conn,callback in (
            (getattr(self,"_local_refresh_start_timer",None),getattr(self,"_local_refresh_start_conn",None),self._run_local_refresh),
            (getattr(self,"_local_refresh_hide_timer",None),getattr(self,"_local_refresh_hide_conn",None),self._hide_local_refresh_status),
        ):
            if timer is None:continue
            try:
                if conn is not None:conn.disconnect()
            except Exception:pass
            try:
                if callback in timer.callback:timer.callback.remove(callback)
            except Exception:pass

    def _first_paint(self):
        self._bind_visuals();self.show_root()

    def _bind_visuals(self):
        if self._visuals_bound:return
        try:self["green_dash"].instance.setPixmapFromFile(_asset("player_keyline_green_dash_56x42.png"))
        except Exception:pass
        try:self["red_dash"].instance.setPixmapFromFile(_asset("player_keyline_red_dash_56x42.png"))
        except Exception:pass
        self._visuals_bound=True

    def _bind_browse_visuals(self):
        if self._browse_visuals_bound:return
        fixed=fixed_home_assets() or {};mood=fixed.get('mood') or {};focus=fixed.get('focus') or {}
        normal=str(mood.get('menu') or _asset('fixed_master_r63/home_menu.png'))
        selected=str(focus.get('menu') or _asset('fixed_master_r63/home_menu_focus.png'))
        from .ui import cached_png
        images={path:cached_png(path) for path in (normal,selected)}
        for i in range(self.PAGE_SIZE):
            for name,path in (('grid_bg%d'%i,normal),('grid_sel%d'%i,selected)):
                try:
                    inst=self[name].instance
                    if images[path] is not None:inst.setPixmap(images[path])
                    else:inst.setPixmapFromFile(path)
                except Exception:pass
        self._browse_visuals_bound=True

    def _request_local_summary(self,force=False):
        if self._local_closed:return
        if self._local_summary_running:
            if force:self._local_summary_again=True
            return
        if not force and self._local_summary_ready and self._local_storage_rows and time.monotonic()-self._local_summary_at<_LOCAL_SUMMARY_TTL:return
        self._local_summary_running=True;self._local_summary_generation+=1
        generation=self._local_summary_generation
        import weakref
        from twisted.internet import reactor
        from .core.shared_executors import LOCAL_STORAGE_EXECUTOR
        owner_ref=weakref.ref(self)
        def complete(stage,value):
            global _LOCAL_HOME_SNAPSHOT
            owner=owner_ref()
            if owner is None or owner._local_closed or generation!=owner._local_summary_generation:return
            if stage=='roots':
                owner.roots=list(value);owner._local_summary_ready=True
                owner._local_summary_at=time.monotonic()
                if not owner._local_refresh_pending:
                    owner['refresh_status'].setText('');owner['refresh_status'].hide()
            elif stage=='devices':owner._local_storage_rows=list(value)
            elif stage=='counts':owner._local_counts=tuple(value)
            elif stage=='error':
                owner['refresh_status'].setText(_("Local storage unavailable; press OK to retry"))
                owner['refresh_status'].show()
            if stage in ('roots','devices','counts'):
                _LOCAL_HOME_SNAPSHOT={'roots':list(owner.roots),'counts':tuple(owner._local_counts),
                    'devices':[dict(row) for row in owner._local_storage_rows],'at':time.monotonic()}
                if owner.mode=='root':
                    pending=owner._local_open_pending;owner._local_open_pending=None
                    owner.show_root()
                    # Opening a library depends only on discovered roots, never
                    # on statvfs, cached inventory size or unrelated cache jobs.
                    if pending=='browse':owner._enter_browse()
                    elif pending is not None:owner._open_cinematic(pending)
            if stage=='done':
                owner._local_summary_running=False;owner._local_summary_future=None
                owner._local_summary_at=time.monotonic()
                again=owner._local_summary_again;owner._local_summary_again=False
                if again:owner._request_local_summary(force=True)
        def work():
            owner=owner_ref()
            if owner is None or owner._local_closed:return
            try:
                roots=_storage_roots()
                reactor.callFromThread(complete,'roots',roots)
                _schedule_local_index_check(roots)
                # Publish storage before reading a potentially large index.
                try:reactor.callFromThread(complete,'devices',owner._storage_devices(roots,on_update=lambda rows:reactor.callFromThread(complete,'devices',rows)))
                except Exception as exc:optional_failure('ui.local_storage',exc)
                if not owner._local_closed:
                    reactor.callFromThread(complete,'counts',owner._library_counts(roots))
            except Exception as exc:
                optional_failure('ui.local_summary',exc)
                reactor.callFromThread(complete,'error',None)
            finally:reactor.callFromThread(complete,'done',None)
        def start():
            owner=owner_ref()
            if owner is None or owner._local_closed:return
            try:
                owner._local_summary_future=LOCAL_STORAGE_EXECUTOR.submit(work)
            except Exception as exc:
                optional_failure('ui.local_summary_submit',exc)
                complete('error',None);complete('done',None)
        reactor.callLater(.01,start)

    ROOT_ICONS = ("movies", "series", "local")

    def _hide_root(self):
        for i in range(3):
            for suffix in ("bg", "icon", "title", "sub"):
                try:self["root_%s%d" % (suffix, i)].hide()
                except Exception:pass
        for i in range(3):
            for name in ("sp_bg", "sp_cap", "sp_name", "sp_track", "sp_fill", "sp_used"):
                try:self["%s%d" % (name, i)].hide()
                except Exception:pass
        self._root_state = {}

    def _hide_grid(self):
        for i in range(self.PAGE_SIZE):
            for suffix in ("bg", "sel", "icon", "title"):
                try:self["grid_%s%d" % (suffix, i)].hide()
                except Exception:pass

    def _set_header(self, title, sub):
        try:self["page_title"].setText(title);self["page_sub"].setText(sub)
        except Exception:pass

    def _library_counts(self,roots=None):
        try:
            row = _load_local_media_index(self.roots if roots is None else roots) or {}
            return len(row.get("movies") or []), len(row.get("series") or []), int(row.get("built_at") or 0)
        except Exception:
            return 0, 0, 0

    def _storage_devices(self,roots=None,on_update=None):
        """Publish receiver space first; publish each drive as its probe finishes."""
        out=[];seen=set();receiver=os.path.realpath(RECEIVER_LOCAL_ROOT)
        paths=[receiver]+[x for x in (self.roots if roots is None else roots) or [] if x!=receiver]
        for real in paths:
            if _is_swap_storage(real):continue
            try:
                dev=os.stat(real).st_dev
                if dev in seen:continue
                st=os.statvfs(real)
                total=float(st.f_blocks*st.f_frsize);free=float(st.f_bavail*st.f_frsize)
                if total<=0:continue
                seen.add(dev)
                kind=self._storage_title(real)
                cap=_("RECEIVER") if real==receiver else kind if kind in ("HDD","USB") else _("FLASH")
                out.append({"cap":cap,"name":real,"pct":int(round(100.0*(total-free)/total)),
                            "used":_("%d GB used  •  %d GB free")%(int((total-free)/1073741824.0),int(free/1073741824.0))})
                if on_update is not None:on_update([dict(row) for row in out[:3]])
                if len(out)>=3:break
            except Exception:pass
        return out[:3]

    def _paint_storage(self):
        devices=list(self._local_storage_rows)
        if not devices:
            # Draw the storage panel on first paint, including a cold HDD.
            # Replace its text and bar as soon as the background probe finishes.
            devices=[{'cap':_("STORAGE"),'name':_("HDD  •  USB  •  Receiver"),
                'pct':0,'used':_("Loading storage information...")}]
        n=len(devices)
        pw = {1: 1420, 2: 695, 3: 460}[n];gap = {1: 0, 2: 30, 3: 20}[n];bw = pw - 56;y = 850
        for i in range(3):
            if i >= n:
                for name in ("sp_bg", "sp_cap", "sp_name", "sp_track", "sp_fill", "sp_used"):
                    try:self["%s%d" % (name, i)].hide()
                    except Exception:pass
                continue
            d = devices[i];px = 250 + i * (pw + gap)
            try:
                self["sp_bg%d" % i].instance.setPixmapFromFile(_asset("page_panel_%dx140.png" % pw))
                self["sp_track%d" % i].instance.setPixmapFromFile(_asset("page_bar_track_%dx10.png" % bw))
                self["sp_fill%d" % i].instance.setPixmapFromFile(_asset("page_bar_fill_%dx10.png" % bw))
                for name, (dx, dy, w, h) in (("sp_bg", (0, 0, pw, 140)), ("sp_cap", (28, 14, bw, 24)), ("sp_name", (28, 36, bw, 40)),
                                             ("sp_track", (28, 84, bw, 10)), ("sp_fill", (28, 84, max(10, int(bw * d["pct"] / 100.0)), 10)),
                                             ("sp_used", (28, 100, bw, 28))):
                    inst = self["%s%d" % (name, i)].instance
                    inst.move(ePoint(*_wqhd_xy(px + dx, y + dy)));inst.resize(eSize(*_wqhd_wh(w, h)))
                self["sp_cap%d" % i].setText(d["cap"]);self["sp_name%d" % i].setText(d["name"]);self["sp_used%d" % i].setText(d["used"])
                for name in ("sp_bg", "sp_cap", "sp_name", "sp_track", "sp_fill", "sp_used"):self["%s%d" % (name, i)].show()
            except Exception:pass

    def show_root(self):
        self.mode = "root";self.current_path = None;self.entries = [];self.index = max(0, min(2, self.index if self.index < 3 else 0));self._hide_grid()
        _m,_s,_b=self._local_counts
        _sub = _("Play files stored on this receiver")
        if _m or _s:
            _mins = max(0, int((time.time() - _b) / 60)) if _b else -1
            _sub = _("%d movies  •  %d series") % (_m, _s) + (("  •  " + (_("Last scan %d min ago") % _mins if _mins < 120 else _("Last scan %d h ago") % int(_mins / 60))) if _mins >= 0 else "")
        self._set_header(_("LOCAL"), _sub)
        try:self["green_dash"].show();self["green"].show();self["red_dash"].show();self["red"].show()
        except Exception:pass
        movies,series,_built=self._local_counts
        self._root_subs = (
            (_("%d movies") % movies) if movies else _("Movies on this receiver"),
            (_("%d series") % series) if series else _("TV series on this receiver"),
            _("HDD  •  USB  •  Receiver"),
        )
        for i, title in enumerate((_("Movies"), _("Series"), _("Browse"))):
            self["root_title%d" % i].setText(title)
            self["root_sub%d" % i].setText(self._root_subs[i])
            for suffix in ("bg", "icon", "title"):
                try:self["root_%s%d" % (suffix, i)].show()
                except Exception:pass
        self._root_state = {}
        self._render_root_focus()
        self._paint_storage()
        self._local_footer_layout()
        self._request_local_summary()

    def _local_footer_layout(self):
        """Center the complete Local footer, including its surface padding."""
        try:
            desktop=getDesktop(0).size()
            sx=desktop.width()/1920.0;sy=desktop.height()/1080.0
            colors=("red","green") if self.mode=="root" else ("red",)
            labels=list(self[c].instance for c in colors)
            dashes=list(self[c+"_dash"].instance for c in colors)
            if any(inst is None for inst in labels+dashes):return
            signature=(self.mode,desktop.width(),desktop.height(),tuple(id(x) for x in labels+dashes),tuple(self[c].getText() for c in colors))
            if signature!=getattr(self,"_local_footer_signature",None):
                y=int(round(1026*sy));h=int(round(42*sy))
                widths=[]
                for color in colors:
                    label=self[color].instance
                    label.setFont(gFont("Regular",int(round(20*sy))))
                    label.resize(eSize(int(round(400*sx)),h))
                    widths.append(max(1,min(int(round(400*sx)),label.calculateSize().width())))
                icon_gap=int(round(58*sx));pair_gap=int(round(32*sx))
                total=sum(widths)+len(colors)*icon_gap+(len(colors)-1)*pair_gap
                # The bundled surface adds 8px left and 12px right padding.
                # Include that asymmetry so the whole bar centers at x=960.
                x=int(round((desktop.width()-total-int(round(4*sx)))/2.0))
                for color,width in zip(colors,widths):
                    label=self[color].instance;dash=self[color+"_dash"].instance
                    dash.move(ePoint(x,y));dash.resize(eSize(int(round(56*sx)),h))
                    label.move(ePoint(x+icon_gap,y));label.resize(eSize(width,h))
                    x+=icon_gap+width+pair_gap
                self._local_footer_signature=signature
            refresh=getattr(self,"_compact_footer_refresh",None)
            if callable(refresh):refresh()
        except Exception:
            # A cosmetic layout failure must never stop Local navigation.
            pass

    def _render_root_focus(self):
        for i in range(3):
            focused = (i == self.index);x = 250 + i * 470
            state = (focused,)
            try:
                bg = self["root_bg%d" % i].instance;ic = self["root_icon%d" % i].instance
                if focused:
                    bg.move(ePoint(*_wqhd_xy(x, 470)));bg.resize(eSize(*_wqhd_wh(380, 330)));ic.move(ePoint(*_wqhd_xy(x + 102, 524)));ic.resize(eSize(*_wqhd_wh(176, 132)))
                else:
                    bg.move(ePoint(*_wqhd_xy(x + 20, 487)));bg.resize(eSize(*_wqhd_wh(340, 296)));ic.move(ePoint(*_wqhd_xy(x + 122, 544)));ic.resize(eSize(*_wqhd_wh(136, 102)))
                if self._root_state.get(i) != state:
                    bg.setPixmapFromFile(_asset("page_card_focus_380x330.png" if focused else "page_card_340x296_%d.png"%{"movies":1,"series":2,"local":3}.get(self.ROOT_ICONS[i],1)))
                    ic.setPixmapFromFile(_asset("home_%s_line%s.png" % (self.ROOT_ICONS[i], "_xl" if focused else "_big")))
                    self._root_state[i] = state
                tl = self["root_title%d" % i];ti = tl.instance
                if ti is not None:
                    ti.setFont(gFont("Regular", _wqhd_font(36 if focused else 30)))
                    ti.setForegroundColor(parseColor("#ffffff" if focused else "#c9ccd1"))
                    ti.move(ePoint(*_wqhd_xy(x if focused else x + 20, 679 if focused else 670)));ti.resize(eSize(*_wqhd_wh(380 if focused else 340, 50)))
                    tl.setText(tl.getText())
                # R5.246: keep the Movies and Series totals visible on both cards
                # so their counts can be compared without moving focus. Browse keeps
                # its contextual subtitle focus-only.
                if i in (0, 1) or focused:self["root_sub%d" % i].show()
                else:self["root_sub%d" % i].hide()
            except Exception:pass

    def _open_cinematic(self, mode):
        if not self._local_summary_ready:
            self._local_open_pending=mode;self._request_local_summary()
            return
        client = LocalMediaClient(self.roots, "series" if mode == "series" else "vod")
        media_type = "series" if mode == "series" else "vod"
        title = _("Series") if mode == "series" else _("Movies")
        # Local follows the same Movies View / Series View choice as the portal
        # browser (Cinematic, Backdrop Grid 1/2, Poster Grid, Poster Grid V2, Poster Grid 3).
        # If the chosen view cannot be created, Cinematic (the previous fixed view) is used.
        for screen in (self._local_view_screen(media_type), self._local_cinematic_screen()):
            if screen is None:continue
            try:
                self.session.open(screen, self.local_profile, client, media_type, "*", title)
                return
            except Exception as exc:
                try:optional_failure("ui.local_open_view",exc)
                except Exception:pass
        # Keep Local Home alive even if a receiver image rejects every child.
        return

    @staticmethod
    def _local_cinematic_screen():
        try:
            from .ui_cinematic_global import PremiumGlobalCinematicScreen
            return PremiumGlobalCinematicScreen
        except Exception:
            return None

    def _local_view_screen(self, media_type):
        """Screen class for the user's Movies View / Series View setting (None = Cinematic)."""
        try:
            key = "movies_view_mode" if media_type == "vod" else "series_view_mode"
            mode = str((load_settings() or {}).get(key) or "cinematic").strip().lower()
            if mode == "cinematic":return None
            if mode == "backdrop2":
                from .ui_backdrop_grid2 import PremiumBackdropGrid2Screen
                return PremiumBackdropGrid2Screen
            if mode == "backdrop":
                from .ui_backdrop_grid import PremiumBackdropGridScreen
                return PremiumBackdropGridScreen
            if mode == "poster3":
                from .ui_poster_grid3 import PremiumPosterGrid3Screen
                return PremiumPosterGrid3Screen
            from .ui_grid_screens import PremiumPosterGridScreen, PremiumPosterGridV2Screen
            return PremiumPosterGridScreen if mode == "poster_legacy" else PremiumPosterGridV2Screen
        except Exception as exc:
            try:optional_failure("ui.local_view_screen",exc)
            except Exception:pass
            return None

    def _allowed(self, path):
        try:
            real = os.path.realpath(path)
            return any(real == r or real.startswith(r.rstrip("/") + "/") for r in self.roots)
        except Exception:return False

    def _storage_title(self, path):
        real=os.path.realpath(str(path or ""))
        if real == os.path.realpath("/media/hdd"):return "HDD"
        if real == os.path.realpath(RECEIVER_LOCAL_ROOT):return "Receiver"
        low=real.lower()
        if "usb" in low:return "USB"
        return os.path.basename(real.rstrip("/")) or real

    def _browse_root_entries(self):
        rows=[]
        for root in self.roots:
            rows.append({"kind":"storage","title":self._storage_title(root),"path":root,"icon":"home_local_line.png"})
        return rows

    def _browse_entries(self, path, cancel_event=None):
        rows=[]
        try:
            with os.scandir(path) as entries:
                for entry in entries:
                    if cancel_event is not None and cancel_event.is_set():return []
                    name=entry.name
                    if name.startswith("."):continue
                    try:
                        if entry.is_dir():rows.append({"kind":"folder","title":name,"path":entry.path,"icon":"home_local_line.png","_sort":name})
                        elif os.path.splitext(name)[1].lower() in VIDEO_EXTENSIONS and entry.is_file():rows.append({"kind":"file","title":_clean_filename(entry.path),"path":entry.path,"icon":"home_movies_line.png","_sort":name})
                    except OSError:continue
        except OSError:return []
        rows.sort(key=lambda row:_natural_key(row["_sort"]))
        for row in rows:row.pop("_sort",None)
        return rows

    def _browse_load_directory(self,path):
        previous=getattr(self,"_browse_scan_cancel",None)
        if previous is not None:previous.set()
        cancel=threading.Event();self._browse_scan_cancel=cancel
        self.current_path=path;self.entries=[];self.index=0;self._render_grid()
        self._set_header(_("BROWSE"),_("Loading…"))
        import weakref
        from twisted.internet import reactor
        from .core.shared_executors import LOCAL_STORAGE_EXECUTOR
        owner_ref=weakref.ref(self)
        def complete(rows):
            owner=owner_ref()
            if owner is None or owner._local_closed or cancel.is_set() or owner.mode!="browse" or owner.current_path!=path:return
            owner.entries=rows;owner.index=0;owner._render_grid()
        def work():
            owner=owner_ref()
            if owner is None or owner._local_closed or cancel.is_set():return
            rows=owner._browse_entries(path,cancel)
            reactor.callFromThread(complete,rows)
        try:LOCAL_STORAGE_EXECUTOR.submit(work)
        except Exception as exc:
            optional_failure("ui.local_browse_submit",exc);complete([])

    def _enter_browse(self):
        if not self._local_summary_ready:
            self._local_open_pending='browse';self._request_local_summary()
            return
        self._bind_browse_visuals()
        self.mode = "browse";self.current_path = None;self.index = 0
        self._set_header(_("BROWSE"), _("Choose a storage"))
        try:self["green_dash"].hide();self["green"].hide()
        except Exception:pass
        self.entries = self._browse_root_entries()
        self._render_grid()

    def _render_grid(self):
        self._hide_root()
        if self.current_path:self._set_header(_("BROWSE"), str(self.current_path))
        try:self["green_dash"].hide();self["green"].hide()
        except Exception:pass
        self._local_footer_layout()
        page = int(self.index // self.PAGE_SIZE) if self.entries else 0;start = page * self.PAGE_SIZE;visible = self.entries[start:start + self.PAGE_SIZE]
        one_row = len(visible) <= self.COLS
        for slot in range(self.PAGE_SIZE):
            if slot >= len(visible):
                for suffix in ("bg", "sel", "icon", "title"):
                    try:self["grid_%s%d" % (suffix, slot)].hide()
                    except Exception:pass
                continue
            entry = visible[slot]
            col = slot % self.COLS;logical_row = slot // self.COLS
            # A single row sits on the bottom rail. Two rows occupy the final
            # 405 px of the page, leaving only 5 px below the bottom cards.
            row_y = self.GRID_Y[1] if one_row else self.GRID_Y[logical_row]
            icon_name = str(entry.get("icon") or "home_local_line.png")
            xoff = 63
            for suffix in ("bg", "sel", "icon", "title"):
                try:self["grid_%s%d" % (suffix, slot)].show()
                except Exception:pass
            try:
                self["grid_bg%d" % slot].instance.move(ePoint(*_wqhd_xy(self.GRID_X[col], row_y)))
                self["grid_sel%d" % slot].instance.move(ePoint(*_wqhd_xy(self.GRID_X[col], row_y)))
                self["grid_title%d" % slot].instance.move(ePoint(*_wqhd_xy(self.GRID_X[col] + 13, row_y + 108)))
                inst = self["grid_icon%d" % slot].instance
                if inst is not None:
                    inst.move(ePoint(*_wqhd_xy(self.GRID_X[col] + xoff, row_y + 18)));inst.setPixmapFromFile(_asset(icon_name))
            except Exception:pass
            self["grid_title%d" % slot].setText(str(entry.get("title") or "")[:42])
            try:(self["grid_sel%d" % slot].show() if (start + slot) == self.index else self["grid_sel%d" % slot].hide())
            except Exception:pass

    def _move(self, horizontal, vertical):
        if self.mode == "root":
            delta = horizontal if horizontal else vertical
            if delta:self.index = (self.index + (1 if delta > 0 else -1)) % 3;self._render_root_focus()
            return
        if not self.entries:return
        old = self.index
        if horizontal:self.index = max(0, min(len(self.entries)-1, self.index + (1 if horizontal > 0 else -1)))
        elif vertical:
            target = self.index + (self.COLS if vertical > 0 else -self.COLS)
            if 0 <= target < len(self.entries):self.index = target
            elif vertical > 0 and len(self.entries)-1 > self.index:self.index = len(self.entries)-1
        if old != self.index:self._render_grid()

    def open_selected(self):
        if self.mode == "root":
            if self.index == 0:self._open_cinematic("movies")
            elif self.index == 1:self._open_cinematic("series")
            else:self._enter_browse()
            return
        if not self.entries or not (0 <= self.index < len(self.entries)):return
        entry = self.entries[self.index];path = os.path.realpath(str(entry.get("path") or ""))
        if not self._allowed(path):return
        if entry.get("kind") in ("folder", "storage"):
            self._browse_load_directory(path);return
        if entry.get("kind") != "file" or not os.path.isfile(path):return
        item = _movie_item(path);media_type = "episode" if _series_identity(path) else "vod"
        if media_type == "episode":
            parsed = _series_identity(path)
            if parsed:
                title, season, episode, ep_title, series_dir = parsed
                item = _episode_item(path, title, season, episode, ep_title)
        try:
            ref = self.session.nav.getCurrentlyPlayingServiceReference()
            if ref is not None:item["_return_service_ref_string"] = ref.toString()
        except Exception:pass
        try:engine = int(load_settings().get("service_type", 4097) or 4097)
        except Exception:engine = 4097
        if engine not in (4097, 5001, 5002, 8193):engine = 4097
        try:
            from .services.player import UltraStalkerPlayer
            self.session.open(UltraStalkerPlayer, path, str(item.get("name") or os.path.basename(path)), media_type, engine, item)
        except Exception:pass

    def go_back(self):
        cancel=getattr(self,"_browse_scan_cancel",None)
        if cancel is not None:cancel.set()
        if self.mode == "root":self.close();return
        # Browse chooser -> Local Home.  Inside a storage tree BACK always means
        # parent; at the storage root it returns to HDD / Receiver / USB chooser.
        if not self.current_path:
            self.show_root();return
        current = os.path.realpath(self.current_path)
        roots = {os.path.realpath(x) for x in self.roots}
        if current in roots:
            self.current_path = None;self.entries = self._browse_root_entries();self.index = 0;self._render_grid();return
        parent = os.path.dirname(current.rstrip("/")) or current
        if parent == current or not self._allowed(parent):
            self.current_path = None;self.entries = self._browse_root_entries();self.index = 0;self._render_grid();return
        self._browse_load_directory(parent)

# R5.245: plugin-owned front-panel identity.
try:
    from .frontpanel_plugin import bind_plugin_front_summary as _bind_plugin_front_summary
    _bind_plugin_front_summary(LocalLibraryScreen)
except Exception:
    pass

