"""Receiver-owned ResumePoints for exported bouquet VOD.

The persistent record belongs exclusively to Enigma2's normal
/etc/enigma2/resumepoints.pkl database, never UltraStalker history.
Both common OE-A global-cache and OpenViX instance-cache APIs work.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .. import us_env as _us_env
from ..us_env import str, int, max
hashlib = _us_env.hashlib
time = _us_env.time


def export_resume_key(profile_key, channel_key):
    raw = (str(profile_key or "") + "|" + str(channel_key or "")).encode("utf-8", "ignore")
    digest = hashlib.sha1(raw).hexdigest()
    # A stable, stream-shaped service key, independent of the portal's
    # short-lived direct URL, token, engine or proxy listen port.
    return "4097:0:1:0:0:0:0:0:0:0:http%%3a//127.0.0.1/ultrastalker-export/%s" % digest


def _receiver_cache():
    try:
        from Screens import InfoBarGenerics as module
    except Exception:
        return None, None
    owner = getattr(module, "resumePointsInstance", None)
    if owner is not None:
        cache = getattr(owner, "resumePointCache", None)
        saver = getattr(owner, "saveResumePoints", None)
        if isinstance(cache, dict) and callable(saver):
            return cache, saver
    cache = getattr(module, "resumePointCache", None)
    saver = getattr(module, "saveResumePoints", None)
    if isinstance(cache, dict) and callable(saver):
        return cache, saver
    return None, None


def read_export_resume(key):
    if not key:
        return 0, 0
    cache, _ = _receiver_cache()
    if cache is None:
        return 0, 0
    try:
        row = cache.get(key) or []
        position = max(0, int(row[1] or 0))
        duration = max(0, int(row[2] or 0)) if len(row) > 2 else 0
        return position, duration
    except (TypeError, ValueError, IndexError):
        return 0, 0


def save_export_resume(key, position, duration=0, completed=False):
    if not key:
        return False
    cache, saver = _receiver_cache()
    if cache is None:
        return False
    if completed:
        if key not in cache:
            return True
        del cache[key]
    else:
        try:
            position = max(0, int(position or 0))
            duration = max(0, int(duration or 0))
        except (TypeError, ValueError):
            return False
        if position < 10 * 90000:
            return False
        if duration and position >= duration - 10 * 90000:
            cache.pop(key, None)
        else:
            cache[key] = [int(time.time()), position, duration or None]
    try:
        saver()
        return True
    except Exception:
        return False
