# -*- coding: utf-8 -*-
"""Small thread-safe progress tracker for folder exports.

The export worker calls ``set`` / ``tick``; a UI timer reads ``text`` and shows
"Label  [=====-----]  12/80  15%" in the screen's status line.  ASCII only, so it
renders with every skin font.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import int, round, max, min
threading = _us_env.threading
time = _us_env.time


def bar(done, total, width=18):
    try:
        done = int(done); total = int(total)
    except Exception:
        return ""
    if total <= 0:
        return ""
    done = max(0, min(done, total))
    fill = int(round(width * done / float(total)))
    return "[" + "=" * fill + "-" * (width - fill) + "]"


class ExportProgress(object):
    def __init__(self, label=""):
        self._lock = threading.Lock()
        self.label = label
        self.done = 0
        self.total = 0
        self._t0 = time.time()

    def set(self, label=None, done=None, total=None):
        with self._lock:
            if label is not None:
                if label != self.label:
                    self._t0 = time.time()
                self.label = label
            if done is not None:
                self.done = int(done)
            if total is not None:
                self.total = int(total)

    def tick(self, n=1):
        with self._lock:
            self.done += int(n)

    def text(self):
        with self._lock:
            label, done, total, t0 = self.label, self.done, self.total, self._t0
        if len(label) > 40:
            label = label[:39].rstrip() + u"\u2026"
        if total > 0:
            pct = int(100 * min(done, total) / float(total))
            return "%s  %s  %d/%d  %d%%" % (label, bar(done, total), min(done, total), total, pct)
        # Steps without a count (writing the bouquet...) show the seconds they have taken.
        return "%s  %s  %d s" % (label, "." * (1 + int(time.time() - t0) % 3), int(time.time() - t0))


def start_poll(screen, progress, interval_ms=400):
    """Show progress in screen['status'] until the returned ``stop()`` is called."""
    try:
        from enigma import eTimer
    except Exception:
        return lambda: None
    previous = getattr(screen, "_export_progress_stop", None)
    if callable(previous):
        previous()
    timer = eTimer()
    state = {"conn": None, "on": True}

    def line():
        """The label this screen really shows (the Categories page has its own notice line)."""
        try:
            from .ui_floating_notice import _label_for
            name, widget = _label_for(screen)
            if widget is not None:
                return name, widget
        except Exception:
            pass
        try:
            return "status", screen["status"]
        except Exception:
            return None, None

    def tick():
        if not state["on"]:
            return
        try:
            name, widget = line()
            if widget is None:
                return
            widget.setText(progress.text())
            if name == "cat_inline_notice":
                widget.show()
        except Exception:
            pass

    try:
        state["conn"] = timer.timeout.connect(tick)
    except Exception:
        timer.callback.append(tick)

    def stop():
        if state["on"]:
            try:
                name, widget = line()
                if name == "cat_inline_notice" and widget is not None:
                    widget.setText("")
                    widget.hide()
            except Exception:
                pass
        state["on"] = False
        try:
            timer.stop()
        except Exception:
            pass
        try:
            if state["conn"] is not None:
                state["conn"].disconnect()
                state["conn"] = None
        except Exception:
            pass
        try:
            if tick in timer.callback:
                timer.callback.remove(tick)
        except Exception:
            pass
        try:
            if stop in screen.onClose:
                screen.onClose.remove(stop)
        except Exception:
            pass
        if getattr(screen, "_export_progress_stop", None) is stop:
            screen._export_progress_stop = None

    screen._export_progress_stop = stop
    tick()
    try:
        timer.start(int(interval_ms), False)
    except Exception:
        pass
    try:
        screen.onClose.append(stop)
    except Exception:
        pass
    return stop
