"""Transition mixin extracted from ui.py without changing behavior."""
from __future__ import absolute_import, division, print_function, unicode_literals
__metaclass__ = type  # new-style classes on Python 2

from .log import optional_failure

class TransitionMixin:
    """OpenBH-safe reveal. Widgets stay visible if timer callbacks differ by image build."""
    def _transition_init(self, names):
        self._transition_names = list(names)
        self._transition_pos = len(self._transition_names)
        self._transition_timer = None
        self._transition_connection = None
        # Fail-open: never hide essential controls. Some OpenBH builds do not
        # reliably deliver repeated one-shot eTimer callbacks during layout.
        for name in self._transition_names:
            try:
                self[name].show()
            except Exception as exc:
                optional_failure("ui", exc)


