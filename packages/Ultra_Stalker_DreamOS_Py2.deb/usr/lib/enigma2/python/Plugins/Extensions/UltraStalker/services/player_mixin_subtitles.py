# -*- coding: utf-8 -*-
"""Native, external and online subtitles (menus, styling, sync).

Methods moved verbatim out of ``UltraStalkerPlayer`` (player_native.py); behaviour is unchanged.
This module is imported by player_native.py once its module-level helpers exist, so the
names below are taken from that module (partially initialised at this point) on purpose.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from ..us_env import str, int, open, max, min, us_func
from .player_native import _dreamos_subtitle_tracks, _is_subtitle_selected, _subtitle_track_lang, _us_service_subtitle, _us_subtitle_api_report, InfoBarSubtitleSupport, Label, MessageBox, Screen, SUBTITLE_POSITION_PRESETS, SUBTITLE_STYLE_COLORS, SubtitleDisplay, UltraInfobarVisibility, _, _ExternalSubtitleProviderBridge, _PLAYER_BG_EXECUTOR, _SUBTITLE_SESSION_LOCK, _SUBTITLE_SESSION_STATE, _cached_poster, _subtitle_color_name, _subtitle_position_name, _subtitle_session_load_store_locked, _subtitle_session_persist_store_locked, _subtitle_session_remove_store_locked, _track_prefs, download_candidate, download_subsource_candidate, ePoint, eSize, gFont, getDesktop, interface_language_choices, interface_subtitle_language_code, is_supported_subtitle_language, json, load_settings, optional_failure, os, parseColor, parse_srt, queue, save_settings, search_language, search_subsource_language, show_notice, subtitle_language_name, threading, time
from ..wqhd_layout import scale_skin as _wqhd_scale_skin

class _DreamOSOnlineSubtitleDialog(Screen):
    _is_dreamos_dialog = True
    skin = _wqhd_scale_skin('<screen name="UltraStalkerOnlineSubtitleDialog" position="0,0" size="1920,1080" backgroundColor="#ff000000" flags="wfNoBorder" zPosition="-1"><widget name="subtitles" position="120,860" size="1680,160" font="Regular;38" halign="center" valign="bottom" foregroundColor="#ffffff" backgroundColor="#000000" shadowColor="#000000" shadowOffset="3,3" transparent="1" zPosition="2" /></screen>')

    def __init__(self, session):
        Screen.__init__(self, session)
        self['subtitles'] = Label('')

    def showSubtitles(self, text):
        txt = str(text or '')
        try:
            self['subtitles'].setText(txt)
            self['subtitles'].show()
        except Exception:
            pass
        try:
            self.show()
        except Exception:
            pass

    def hideSubtitles(self):
        try:
            self['subtitles'].setText('')
            self['subtitles'].hide()
        except Exception:
            pass
        try:
            self.hide()
        except Exception:
            pass

    def hideScreen(self):
        self.hideSubtitles()

class PlayerSubtitleMixin(object):
    """Native, external and online subtitles (menus, styling, sync)."""

    def _init_online_subtitle_display(self):
        if self._online_subtitle_display is not None:
            return
        try:
            maker = getattr(self.session, 'instantiateDialog', None)
            if callable(maker):
                display = maker(SubtitleDisplay) if SubtitleDisplay is not None else None
                if display is not None and (not (hasattr(display, 'showSubtitles') and hasattr(display, 'hideSubtitles'))):
                    _us_subtitle_api_report('SubtitleDisplay', display)
                    deleter = getattr(self.session, 'deleteDialog', None)
                    if callable(deleter):
                        try:
                            deleter(display)
                        except Exception:
                            pass
                    display = None
                if display is None:
                    display = maker(_DreamOSOnlineSubtitleDialog)
                self._online_subtitle_display = display
                (getattr(display, 'hideScreen', None) or display.hide)()
                self._apply_subtitle_style_native()
        except Exception as exc:
            optional_failure('player.native_online_subtitle_init', exc)
            self._online_subtitle_display = None

    def _set_online_subtitle_text(self, text, force=False):
        text = str(text or '')
        if not force and text == getattr(self, '_online_subtitle_current_text', None):
            return
        self._online_subtitle_current_text = text
        display = self._online_subtitle_display
        if display is None:
            try:
                self['online_subtitle'].setText(text)
                if text:
                    self['online_subtitle'].show()
                else:
                    self['online_subtitle'].hide()
            except Exception:
                pass
            return
        try:
            if text:
                display.showSubtitles(text)
                self._apply_subtitle_style_native()
            else:
                display.hideSubtitles()
        except Exception as exc:
            optional_failure('player.native_online_subtitle_text', exc)

    def _subtitle_volume_osd_event(self):
        if self._online_subtitle_active and self._online_subtitle_current_text:
            try:
                self._set_online_subtitle_text(self._online_subtitle_current_text, force=True)
            except Exception:
                pass
            try:
                self.subtitle_volume_restore_timer.stop()
                self.subtitle_volume_restore_timer.start(80, True)
            except Exception:
                pass
        return 0

    def _restore_subtitle_after_volume_osd(self):
        if not self._online_subtitle_active or not self._online_subtitle_current_text:
            return
        try:
            self._set_online_subtitle_text(self._online_subtitle_current_text, force=True)
            display = self._online_subtitle_display
            if display is not None:
                try:
                    display.show()
                except Exception:
                    pass
        except Exception as exc:
            optional_failure('player.subtitle_volume_restore', exc)

    def _subtitle_take_key_ownership(self):
        """Temporarily unbind the Player's EXIT handlers while subtitle UI owns input.

        This mirrors the ownership boundary of Enigma2's native Audio screen:
        while the child UI is active, the Player must not also receive the same
        BACK/EXIT event.  The inline subtitle UI itself remains unchanged.
        """
        if self._subtitle_player_keymaps_suspended:
            return
        self._subtitle_player_keymaps_suspended = True
        for name in ('hard_exit_actions', 'player_actions'):
            try:
                self[name].setEnabled(False)
            except Exception as exc:
                optional_failure('player.subtitle_key_owner_disable_%s' % name, exc)

    def _subtitle_release_key_ownership(self):
        if not self._subtitle_player_keymaps_suspended:
            return
        self._subtitle_player_keymaps_suspended = False
        for name in ('player_actions', 'hard_exit_actions'):
            try:
                self[name].setEnabled(True)
            except Exception as exc:
                optional_failure('player.subtitle_key_owner_enable_%s' % name, exc)

    def _subtitle_inline_lock(self):
        if self._subtitle_inline_locked:
            return
        self._subtitle_inline_locked = True
        self._subtitle_take_key_ownership()
        try:
            us_func(UltraInfobarVisibility.lockShow)(self)
        except Exception as exc:
            optional_failure('player.subtitle_inline_lock', exc)

    def _subtitle_native_hold_begin(self):
        if self._subtitle_native_selector_hold:
            return
        self._subtitle_native_selector_hold = True
        self._subtitle_native_was_playing = self._transport_is_playing()
        self._subtitle_native_before = getattr(self, 'selected_subtitle', None)
        try:
            us_func(UltraInfobarVisibility.lockShow)(self)
        except Exception as exc:
            optional_failure('player.subtitle_native_hold_begin', exc)

    def _subtitle_native_hold_end(self, *_args, **_kwargs):
        if not self._subtitle_native_selector_hold:
            return
        self._subtitle_native_selector_hold = False
        try:
            us_func(UltraInfobarVisibility.unlockShow)(self)
        except Exception as exc:
            optional_failure('player.subtitle_native_hold_end', exc)
        if not self.restored and (not self._closing_playback):
            changed = getattr(self, 'selected_subtitle', None) != getattr(self, '_subtitle_native_before', None)
            if changed and getattr(self, '_subtitle_native_was_playing', False) and (not self._transport_is_playing()):
                self._set_transport_paused(False)
            self._subtitle_native_was_playing = False
            try:
                us_func(UltraInfobarVisibility.doShow)(self)
            except Exception as exc:
                optional_failure('player.subtitle_native_hold_show', exc)
            try:
                self._subtitle_session_capture()
            except Exception as exc:
                optional_failure('player.subtitle_native_immediate_capture', exc)

    def _subtitle_inline_finish(self):
        try:
            if getattr(self, '_subtitle_inline_overlay', None) is not None and self._subtitle_inline_overlay.active:
                self._subtitle_inline_overlay.hide()
        except Exception as exc:
            optional_failure('player.subtitle_inline_hide', exc)
        self._subtitle_inline_level = ''
        if self._subtitle_inline_locked:
            self._subtitle_inline_locked = False
            try:
                us_func(UltraInfobarVisibility.unlockShow)(self)
            except Exception as exc:
                optional_failure('player.subtitle_inline_unlock', exc)
        self._subtitle_release_key_ownership()
        try:
            self.startHideTimer()
        except Exception:
            pass

    def _subtitle_inline_show(self, choices, selection, on_accept, on_close, level):
        self._subtitle_inline_lock()
        self._subtitle_inline_level = str(level or '')
        frames = dict(getattr(self, '_player_chrome_frames', {}) or {})
        source = str(getattr(self, '_player_chrome_source', '') or '')
        if not (source and os.path.isfile(source)):
            try:
                source = str(_cached_poster(self.item, self.name, self.media_type) or '')
            except Exception:
                source = ''
        if not (source and os.path.isfile(source)):
            candidate = str(frames.get('main') or '')
            if candidate and os.path.isfile(candidate):
                source = candidate
        return self._subtitle_inline_overlay.show(choices, selection=selection, center_x=960, anchor_bottom=780, on_accept=on_accept, on_close=on_close, min_card_w=180, max_card_w=520, padding=38, visual_style='player_premium', row_h=70, max_visible=5, adaptive_source=source, adaptive_accent=frames.get('accent'), adaptive_accent_soft=frames.get('accent_soft'))

    def _subtitle_back_from_tracks(self):
        self.subtitleSelection('subtitle_tracks')

    def _subtitle_back_from_settings(self):
        self.subtitleSelection('subtitle_settings')

    def _subtitle_back_from_size(self):
        self._open_subtitle_settings_menu('style_size')

    def _subtitle_back_from_color(self):
        self._open_subtitle_settings_menu('style_color')

    def _subtitle_back_from_background(self):
        self._open_subtitle_settings_menu('style_background')

    def _subtitle_back_from_position(self):
        self._open_subtitle_settings_menu('style_position')

    def _subtitle_back_from_online_languages(self):
        provider = str(getattr(self, '_online_subtitle_provider', 'subdl') or 'subdl').lower()
        self._open_subtitle_tracks_menu('online_subsource' if provider == 'subsource' else 'online_subdl')

    def _subtitle_back_from_online_results(self):
        language = str(getattr(self, '_online_subtitle_language', 'EN') or 'EN').upper().replace('-', '_')
        self._open_online_subtitle_languages_menu(language)

    def subtitleSelection(self, preselect_action=None):
        """Show the compact subtitle hub inside the Player itself."""
        self._subtitle_manual_action()
        try:
            self.subtitle_default_timer.stop()
        except Exception as exc:
            optional_failure('player', exc)
        choices = [(_('Choose Subtitles'), 'subtitle_tracks'), (_('Subtitle Settings'), 'subtitle_settings')]
        _pre = str(preselect_action or '')
        selected = 1 if _pre == 'subtitle_settings' or _pre.startswith(('style_', 'delay_', 'sync_', 'auto_sync')) else 0
        try:
            return self._subtitle_inline_show(choices, selected, self._subtitle_hub_selected, self._subtitle_inline_finish, 'hub')
        except Exception as exc:
            optional_failure('player.subtitle_menu', exc)
            self._subtitle_inline_finish()
            return self._open_native_subtitles()

    def _subtitle_hub_selected(self, choice=None):
        if not choice:
            return self._subtitle_inline_finish()
        action = choice[1] if isinstance(choice, (tuple, list)) and len(choice) > 1 else choice
        if action == 'subtitle_tracks':
            self._open_subtitle_tracks_menu()
        elif action == 'subtitle_settings':
            if not self._external_subtitle_settings():
                self._open_subtitle_settings_menu()

    def _open_subtitle_tracks_menu(self, preselect_action=None):
        choices = [(_('Local subtitles'), 'embedded'), (_('Subtitle file') + ' • HDD / USB', 'subtitle_file'), (_('Online subtitles') + ' • SubDL', 'online_subdl'), (_('Online subtitles') + ' • SubSource', 'online_subsource'), (_('SubsSupport') + ' • Enigma2', 'subssupport'), ('SubsSupportPro • Enigma2', 'subssupportpro'), (_('Disable subtitles'), 'disable')]
        selected = 0
        if preselect_action:
            for idx, row in enumerate(choices):
                if isinstance(row, (tuple, list)) and len(row) > 1 and (row[1] == preselect_action):
                    selected = idx
                    break
        return self._subtitle_inline_show(choices, selected, self._subtitle_track_selected, self._subtitle_back_from_tracks, 'tracks')

    def _online_subtitle_language_choices(self, provider=None):
        provider = str(provider or getattr(self, '_online_subtitle_provider', 'subdl') or 'subdl').strip().lower()
        provider_name = 'SubSource' if provider == 'subsource' else 'SubDL'
        choices = []
        for display_name, interface_code in interface_language_choices():
            language = interface_subtitle_language_code(interface_code)
            choices.append(('%s • %s' % (display_name, provider_name), 'online_%s' % language))
        return choices

    def _open_online_subtitle_languages_menu(self, preselect_language=None, provider=None):
        if provider:
            self._online_subtitle_provider = str(provider).strip().lower()
        elif not getattr(self, '_online_subtitle_provider', None):
            self._online_subtitle_provider = 'subdl'
        choices = self._online_subtitle_language_choices(self._online_subtitle_provider)
        selected = 0
        wanted = str(preselect_language or '').strip().upper().replace('-', '_')
        if wanted:
            wanted = 'online_%s' % wanted
            for idx, row in enumerate(choices):
                if isinstance(row, (tuple, list)) and len(row) > 1 and (row[1] == wanted):
                    selected = idx
                    break
        return self._subtitle_inline_show(choices, selected, self._online_subtitle_language_selected, self._subtitle_back_from_online_languages, 'online_languages')

    def _online_subtitle_language_selected(self, choice=None):
        if not choice:
            return self._subtitle_back_from_online_languages()
        action = choice[1] if isinstance(choice, (tuple, list)) and len(choice) > 1 else choice
        if str(action).startswith('online_'):
            return self._start_online_subtitles(str(action).split('_', 1)[1], getattr(self, '_online_subtitle_provider', 'subdl'))

    def _external_subtitle_ui_hold_begin(self):
        if getattr(self, '_external_subtitle_ui_hold', False):
            return
        was_playing = self._transport_is_playing()
        self._external_subtitle_ui_hold = True
        self._external_subtitle_ui_seen_foreign = False
        self._external_subtitle_ui_return_ticks = 0
        self._external_subtitle_ui_resume_after = bool(was_playing)
        bridge = getattr(self, '_external_subtitle_bridge', None)
        self._external_subtitle_previous = bridge.snapshot() if bridge is not None else None
        self._external_subtitle_ui_hold_started = time.monotonic()
        if was_playing:
            self._set_transport_paused(True)
        try:
            self.external_subtitle_ui_timer.stop()
            self.external_subtitle_ui_timer.start(180, True)
        except Exception as exc:
            optional_failure('player.external_subtitle_hold_timer', exc)

    def _external_subtitle_ui_hold_end(self):
        if not getattr(self, '_external_subtitle_ui_hold', False):
            return
        resume_after = bool(getattr(self, '_external_subtitle_ui_resume_after', False))
        self._external_subtitle_ui_hold = False
        self._external_subtitle_ui_seen_foreign = False
        self._external_subtitle_ui_return_ticks = 0
        self._external_subtitle_ui_resume_after = False
        self._external_subtitle_ui_hold_started = 0.0
        try:
            self.external_subtitle_ui_timer.stop()
        except Exception:
            pass
        if resume_after and (not self.restored) and (not self._closing_playback):
            self._set_transport_paused(False)
        if not self.restored and (not self._closing_playback):
            try:
                bridge = getattr(self, '_external_subtitle_bridge', None)
                if bridge is not None and bridge.is_loaded():
                    self._disable_online_subtitles()
                    self._disable_native_subtitles()
                    self._subtitle_source = bridge.kind
                    try:
                        bridge.service_started()
                    except Exception:
                        pass
                elif bridge is not None and getattr(self, '_external_subtitle_previous', None):
                    bridge.restore(self._external_subtitle_previous)
                    self._subtitle_source = bridge.kind
                self._subtitle_session_capture()
                if self._lb_active():
                    self._lb_langs_update(force=True)
            except Exception as exc:
                optional_failure('player.subtitle_external_immediate_capture', exc)

    def _external_subtitle_ui_watch(self):
        if not getattr(self, '_external_subtitle_ui_hold', False):
            return
        try:
            current = getattr(self.session, 'current_dialog', None)
        except Exception:
            current = None
        if current is not None and current is not self:
            self._external_subtitle_ui_seen_foreign = True
            self._external_subtitle_ui_return_ticks = 0
        elif current is self and getattr(self, '_external_subtitle_ui_seen_foreign', False):
            ticks = int(getattr(self, '_external_subtitle_ui_return_ticks', 0) or 0) + 1
            self._external_subtitle_ui_return_ticks = ticks
            if ticks >= 2:
                self._external_subtitle_ui_hold_end()
                return
        elif not getattr(self, '_external_subtitle_ui_seen_foreign', False):
            if time.monotonic() - float(getattr(self, '_external_subtitle_ui_hold_started', 0.0) or 0.0) > 1.5:
                self._external_subtitle_ui_hold_end()
                return
        try:
            self.external_subtitle_ui_timer.start(180, True)
        except Exception as exc:
            optional_failure('player.external_subtitle_hold_watch', exc)

    def _subtitle_session_clear(self):
        """Forget only this title's remembered subtitle choice."""
        key = str(getattr(self, '_subtitle_session_key', '') or '')
        if not key:
            return
        with _SUBTITLE_SESSION_LOCK:
            _subtitle_session_remove_store_locked(key)

    def _subtitle_manual_action(self):
        self._subtitle_manual_override = True
        if getattr(self, '_subtitle_restore_loading', False):
            self._subtitle_restore_loading = False
            self._online_subtitle_generation += 1
            future = getattr(self, '_online_subtitle_future', None)
            if future is not None:
                future.cancel()
        self._subtitle_user_override = True
        self._track_pref_audio_done = True
        self._track_pref_sub_done = True
        self._subtitle_session_restore_done = True
        self._subtitle_session_restore_pending = False
        try:
            self.subtitle_session_restore_timer.stop()
        except Exception:
            pass
        try:
            self.subtitle_default_timer.stop()
        except Exception:
            pass

    def _subtitle_session_capture(self):
        """Persist only an explicit, successfully committed source for this title."""
        key = str(getattr(self, '_subtitle_session_key', '') or '')
        if not key or getattr(self, '_subtitle_session_restoring', False):
            return
        source = str(getattr(self, '_subtitle_source', '') or '')
        state = None
        if source == 'off':
            state = {'source': 'off'}
        elif source == 'online' and getattr(self, '_online_subtitle_active', False):
            state = {'source': 'online', 'path': str(self._online_subtitle_path or ''), 'provider': str(getattr(self, '_online_subtitle_active_provider', 'subdl')), 'language': str(getattr(self, '_online_subtitle_active_language', 'EN'))}
        elif source == 'native':
            selected = getattr(self, 'selected_subtitle', None)
            if _is_subtitle_selected(selected):
                try:
                    service = self.session.nav.getCurrentService()
                except Exception:
                    service = None
                lang = _subtitle_track_lang(service, selected)
                track_val = ['dreamos_track', int(selected), lang, '', lang] if isinstance(selected, int) else list(selected)
                state = {'source': 'native', 'track': track_val, 'language': lang}
        elif source in ('subssupport', 'subssupportpro'):
            bridge = getattr(self, '_external_subtitle_bridge', None)
            state = bridge.snapshot() if bridge is not None else None
        if not state:
            return
        self._subtitle_runtime_choice = dict(state)
        if not getattr(self, '_cfg_remember_tracks', True):
            return
        with _SUBTITLE_SESSION_LOCK:
            _subtitle_session_load_store_locked()
            old = dict(_SUBTITLE_SESSION_STATE.get(key) or {})
            old.pop('saved_at', None)
            if old == state:
                _subtitle_session_persist_store_locked()
                return
            state = dict(state)
            state['saved_at'] = time.time()
            _SUBTITLE_SESSION_STATE[key] = state
            while len(_SUBTITLE_SESSION_STATE) > 96:
                oldest = min((k for k in _SUBTITLE_SESSION_STATE if k != key), key=lambda k: float(_SUBTITLE_SESSION_STATE[k].get('saved_at', 0) or 0))
                _SUBTITLE_SESSION_STATE.pop(oldest, None)
            _subtitle_session_persist_store_locked()

    def _subtitle_saved_choice(self):
        state = getattr(self, '_subtitle_runtime_choice', None)
        if isinstance(state, dict):
            return dict(state)
        if not getattr(self, '_cfg_remember_tracks', True):
            return {}
        key = str(getattr(self, '_subtitle_session_key', '') or '')
        with _SUBTITLE_SESSION_LOCK:
            _subtitle_session_load_store_locked()
            state = dict(_SUBTITLE_SESSION_STATE.get(key) or {})
        if not state:
            pref = _track_prefs.get(self._track_pref_key()) or {}
            lang = str(pref.get('sub') or '')
            if lang:
                state = {'source': 'off'} if lang == 'off' else {'source': 'native', 'language': lang}
        return state

    def _schedule_subtitle_session_restore(self, delay_ms=700):
        if getattr(self, '_subtitle_session_restore_done', False) or getattr(self, '_subtitle_user_override', False):
            return False
        if not self._subtitle_saved_choice():
            return False
        self._subtitle_session_restore_pending = True
        self.subtitle_session_restore_timer.start(max(100, int(delay_ms)), True)
        return True

    def _subtitle_session_restore_tick(self):
        if self.restored or self._closing_playback or self._subtitle_user_override:
            return
        if not self.started or self._resume_target or (not getattr(self, '_track_pref_audio_done', True)):
            self.subtitle_session_restore_timer.start(500, True)
            return
        self._subtitle_session_restore_attempts += 1
        if self._subtitle_session_restore_attempts > 30:
            self._subtitle_session_restore_done = True
            self._subtitle_session_restore_pending = False
            return
        state = self._subtitle_saved_choice()
        source = str(state.get('source') or '')
        self._subtitle_session_restoring = True
        try:
            if source == 'off':
                self._disable_online_subtitles()
                self._external_subtitle_stop()
                self._disable_native_subtitles()
                self._subtitle_source = 'off'
                self._subtitle_user_override = True
            elif source == 'native':
                tracks = self._native_subtitle_track_list() or []
                wanted = tuple(state.get('track') or ())
                lang = str(state.get('language') or '')
                selected = next((t for t in tracks if wanted and tuple(t) == wanted), None)
                if selected is None and wanted and (len(wanted) >= 2) and (wanted[0] == 'dreamos_track'):
                    selected = next((t for t in tracks if len(t) >= 2 and t[0] == 'dreamos_track' and (t[1] == wanted[1])), None)
                if selected is None and lang:
                    selected = next((t for t in tracks if len(t) > 4 and _track_prefs.normalize_language(t[4]) == lang), None)
                if selected is None:
                    self.subtitle_session_restore_timer.start(500, True)
                    return
                self.enableSubtitle(selected)
            elif source == 'online':
                path = str(state.get('path') or '')
                if path and os.path.isfile(path):
                    self._online_subtitle_generation += 1
                    generation = self._online_subtitle_generation
                    result_queue = self._online_subtitle_queue

                    def worker():
                        try:
                            result = dict(state)
                            result['_cues'] = parse_srt(path)
                            result_queue.put(('restore_file', (result, generation)))
                        except Exception as exc:
                            result_queue.put(('error', (str(exc), generation)))
                    self._subtitle_restore_loading = True
                    self._online_subtitle_future = _PLAYER_BG_EXECUTOR.submit(worker)
                    self.online_subtitle_result_timer.start(150, False)
            elif source in ('subssupport', 'subssupportpro'):
                bridge = self._external_subtitle_bridge
                if bridge.restore(state):
                    self._disable_online_subtitles()
                    self._disable_native_subtitles()
                    self._subtitle_source = source
                    self._subtitle_user_override = True
            self._subtitle_session_restore_done = True
            self._subtitle_session_restore_pending = False
        except Exception as exc:
            optional_failure('player.subtitle_restore', exc)
        finally:
            self._subtitle_session_restoring = False

    def enableSubtitle(self, selectedSubtitle):
        """Commit native ownership only when the receiver accepts a real choice."""
        restoring = bool(getattr(self, '_subtitle_session_restoring', False))
        if not restoring and (not getattr(self, '_subtitle_native_selector_hold', False)):
            source = str(getattr(self, '_subtitle_source', '') or '')
            if not getattr(self, '_subtitle_user_override', False) or source in ('online', 'off', 'subssupport', 'subssupportpro'):
                self._disable_native_subtitles()
                return 0
        if not restoring:
            self._subtitle_manual_action()
        if isinstance(selectedSubtitle, (tuple, list)) and len(selectedSubtitle) >= 2 and (selectedSubtitle[0] == 'dreamos_track'):
            selectedSubtitle = int(selectedSubtitle[1])
        previous = getattr(self, 'selected_subtitle', None)
        result = None
        try:
            result = us_func(InfoBarSubtitleSupport.enableSubtitle)(self, selectedSubtitle)
        except Exception:
            try:
                service = self.session.nav.getCurrentService()
                st = _dreamos_subtitle_tracks(service)
                if st is not None and isinstance(selectedSubtitle, int) and (selectedSubtitle >= 0):
                    st.enableSubtitles(int(selectedSubtitle))
                    self.selected_subtitle = int(selectedSubtitle)
                    win = getattr(self, 'subtitle_window', None)
                    if win is not None:
                        win.show()
                else:
                    self.selected_subtitle = previous
                    raise
            except Exception:
                self.selected_subtitle = previous
                raise
        try:
            service = self.session.nav.getCurrentService()
            st = _dreamos_subtitle_tracks(service)
            if st is not None and isinstance(selectedSubtitle, int) and (selectedSubtitle >= 0):
                try:
                    st.enableSubtitles(int(selectedSubtitle))
                except Exception:
                    pass
                self.selected_subtitle = int(selectedSubtitle)
                win = getattr(self, 'subtitle_window', None)
                if win is not None:
                    try:
                        win.show()
                    except Exception:
                        pass
        except Exception:
            pass
        self._disable_online_subtitles()
        self._external_subtitle_stop()
        enabled = _is_subtitle_selected(selectedSubtitle)
        self._subtitle_source = 'native' if enabled else 'off'
        self._subtitle_user_override = True
        if not enabled:
            self._disable_native_subtitles()
        if not restoring:
            self._subtitle_session_capture()
            self._track_pref_capture_subtitle()
        try:
            if self._lb_active():
                self._lb_langs_update(force=True)
        except Exception:
            pass
        return result

    def _external_subtitle_stop(self):
        bridge = getattr(self, '_external_subtitle_bridge', None)
        if bridge is not None:
            bridge.close()

    def _external_subtitle_open(self, kind):
        """Hand subtitle ownership to SubsSupport/Pro without touching its files."""
        self._subtitle_inline_finish()
        if self.media_type not in ('vod', 'series', 'episode', 'catchup'):
            try:
                show_notice(self.session, _('Online subtitles are available for Movies and Series.'), timeout=5, owner=self)
            except Exception:
                pass
            return 0
        self._external_subtitle_ui_hold_begin()
        bridge = getattr(self, '_external_subtitle_bridge', None)
        if bridge is None:
            bridge = _ExternalSubtitleProviderBridge(self)
            self._external_subtitle_bridge = bridge
        try:
            if bridge.open_menu(kind):
                return 1
        except ImportError as exc:
            optional_failure('player.external_subtitle_import', exc)
            label = 'SubsSupportPro' if kind == 'subssupportpro' else 'SubsSupport'
            try:
                show_notice(self.session, '%s\n\n%s' % (label, _('SubsSupport plugin is not installed.')), timeout=6, owner=self)
            except Exception:
                pass
            self._external_subtitle_ui_hold_end()
            return 0
        except Exception as exc:
            optional_failure('player.external_subtitle_open', exc)
            label = 'SubsSupportPro' if kind == 'subssupportpro' else 'SubsSupport'
            try:
                try:
                    detail = '%s: %s' % (type(exc).__name__, exc)
                except Exception:
                    detail = type(exc).__name__
                show_notice(self.session, '%s\n\n%s\n%s' % (label, _('SubsSupport could not be opened.'), detail[:160]), timeout=10, owner=self)
            except Exception:
                pass
            self._external_subtitle_ui_hold_end()
            return 0
        self._external_subtitle_ui_hold_end()
        return 0

    def _external_subtitle_settings(self):
        bridge = getattr(self, '_external_subtitle_bridge', None)
        if bridge is None or bridge.owner is None:
            return False
        self._subtitle_inline_finish()
        try:
            return bool(bridge.open_status())
        except Exception as exc:
            optional_failure('player.external_subtitle_status', exc)
            return False

    def _external_subtitle_after_seek(self):
        bridge = getattr(self, '_external_subtitle_bridge', None)
        if bridge is not None:
            bridge.after_seek()

    def _external_subtitle_play_state(self, value):
        bridge = getattr(self, '_external_subtitle_bridge', None)
        if bridge is not None:
            bridge.play_state(value)

    _SUBTITLE_FILE_EXTS = (".srt", ".ass", ".ssa", ".vtt")
    _SUBTITLE_FILE_ROOTS = ("/media/hdd", "/media/usb", "/media/usb1", "/media/usb2", "/media/sdcard", "/media/mmc", "/media/net", "/media/autofs", "/hdd", "/autofs", "/home/root", "/tmp")

    @staticmethod
    def _subtitle_file_label(name, limit=46):
        name = str(name)
        if len(name) <= limit:
            return name
        keep = (limit - 3) // 2
        return name[:keep] + "..." + name[-keep:]

    def _subtitle_file_roots(self):
        roots = []
        try:
            for name in sorted(os.listdir("/media")):
                path = os.path.join("/media", name)
                if os.path.isdir(path) and path not in roots:
                    roots.append(path)
        except Exception:
            pass
        for path in self._SUBTITLE_FILE_ROOTS:
            try:
                if os.path.isdir(path) and path not in roots:
                    roots.append(path)
            except Exception:
                pass
        # A file played from the receiver: its own folder first.
        try:
            stream = str(getattr(self, "streamurl", "") or "")
            if stream.startswith("/") and os.path.isfile(stream):
                folder = os.path.dirname(stream)
                if folder in roots:
                    roots.remove(folder)
                roots.insert(0, folder)
        except Exception:
            pass
        return roots

    def _open_subtitle_file_browser(self, folder=None, preselect=None):
        """Browse the receiver storage for a subtitle file (SRT / ASS / VTT)."""
        if folder is None:
            folder = str(getattr(self, "_subtitle_browse_dir", "") or "")
            if not folder:
                try:
                    folder = str(load_settings().get("player_subtitle_browse_dir") or "")
                except Exception:
                    folder = ""
            if folder and not os.path.isdir(folder):
                folder = ""
        choices = []
        if not folder:
            for path in self._subtitle_file_roots():
                choices.append((path + "/", ("dir", path)))
            if not choices:
                try:
                    show_notice(self.session, _("No storage found on the receiver"), timeout=5, owner=self)
                except Exception:
                    pass
                return self._open_subtitle_tracks_menu("subtitle_file")
        else:
            choices.append(("..  " + _("Back"), ("up", folder)))
            dirs, files = [], []
            try:
                names = os.listdir(folder)
            except Exception as exc:
                optional_failure("player.subtitle_file_list", exc)
                names = []
            for name in names:
                try:
                    name = str(name)
                except Exception:
                    continue
                if name.startswith("."):
                    continue
                path = os.path.join(folder, name)
                try:
                    if os.path.isdir(path):
                        dirs.append(name)
                    elif os.path.splitext(name)[1].lower() in self._SUBTITLE_FILE_EXTS:
                        files.append(name)
                except Exception:
                    continue
            # Subtitle files first: that is what the user is looking for.
            for name in sorted(files, key=lambda x: x.lower())[:300]:
                choices.append((self._subtitle_file_label(name), ("file", os.path.join(folder, name))))
            for name in sorted(dirs, key=lambda x: x.lower())[:300]:
                choices.append((self._subtitle_file_label(name) + "/", ("dir", os.path.join(folder, name))))
            if len(choices) == 1:
                choices.append((_("No subtitle files here"), ("up", folder)))
        self._subtitle_browse_dir = folder
        selected = 0
        if preselect:
            for idx, row in enumerate(choices):
                if row[1][1] == preselect:
                    selected = idx
                    break
        elif folder and len(choices) > 1:
            selected = 1
        return self._subtitle_inline_show(choices, selected, self._subtitle_file_selected, self._subtitle_file_back, "subtitle_file")

    def _subtitle_file_back(self):
        folder = str(getattr(self, "_subtitle_browse_dir", "") or "")
        if not folder:
            return self._open_subtitle_tracks_menu("subtitle_file")
        parent = os.path.dirname(folder.rstrip("/"))
        roots = self._subtitle_file_roots()
        if folder in roots or not parent or parent == folder or parent in ("/", "/media"):
            return self._open_subtitle_file_browser("", preselect=folder)
        return self._open_subtitle_file_browser(parent, preselect=folder)

    def _subtitle_file_selected(self, choice=None):
        if not choice:
            return self._subtitle_file_back()
        try:
            kind, path = choice[1]
        except Exception:
            return self._subtitle_file_back()
        if kind == "dir":
            return self._open_subtitle_file_browser(path)
        if kind == "up":
            return self._subtitle_file_back()
        self._subtitle_user_override = True
        try:
            self.subtitle_default_timer.stop()
        except Exception:
            pass
        try:
            if os.path.getsize(path) > 8 * 1024 * 1024:
                raise RuntimeError(_("file is too large"))
            cues = parse_srt(path)
            if not cues:
                raise RuntimeError(_("no readable subtitle lines"))
            self._subtitle_inline_finish()
            self._activate_online_subtitle(path, os.path.splitext(os.path.basename(path))[0], prepared_cues=cues)
            try:
                settings = load_settings()
                settings["player_subtitle_browse_dir"] = os.path.dirname(path)
                save_settings(settings)
            except Exception as exc:
                optional_failure("player.subtitle_file_remember", exc)
            try:
                show_notice(self.session, _("Subtitle file loaded") + "  \u2022  " + self._subtitle_file_label(os.path.basename(path)), timeout=4, owner=self)
            except Exception:
                pass
            return True
        except Exception as exc:
            optional_failure("player.subtitle_file_load", exc)
            try:
                show_notice(self.session, _("Subtitle file could not be loaded") + ": %s" % str(exc)[:120], timeout=7, owner=self)
            except Exception:
                pass
            return self._open_subtitle_file_browser(os.path.dirname(path), preselect=path)

    def _subtitle_track_selected(self, choice=None):
        if not choice:
            return self._subtitle_back_from_tracks()
        action = choice[1] if isinstance(choice, (tuple, list)) and len(choice) > 1 else choice
        if action == "subtitle_file":
            return self._open_subtitle_file_browser()
        if action in ('embedded', 'online_subdl', 'online_subsource', 'subssupport', 'subssupportpro', 'disable'):
            self._subtitle_user_override = True
            try:
                self.subtitle_default_timer.stop()
            except Exception:
                pass
        if action == 'embedded':
            self._subtitle_inline_finish()
            return self._open_native_subtitles()
        if action == 'online_subdl':
            return self._open_online_subtitle_languages_menu(provider='subdl')
        if action == 'online_subsource':
            return self._open_online_subtitle_languages_menu(provider='subsource')
        if action == 'subssupport':
            return self._external_subtitle_open('subssupport')
        if action == 'subssupportpro':
            return self._external_subtitle_open('subssupportpro')
        if action == 'disable':
            self._external_subtitle_stop()
            self._disable_online_subtitles()
            self._disable_native_subtitles()
            try:
                _srv = self.session.nav.getCurrentService()
                self.selected_subtitle = None if _dreamos_subtitle_tracks(_srv) is not None else (0, 0, 0, 0)
            except Exception:
                pass
            self._subtitle_user_override = True
            self._subtitle_session_restore_done = True
            self._subtitle_session_restore_pending = False
            self._subtitle_session_post_refresh_pending = False
            self._embedded_subtitle_probe_pending = False
            for timer_name in ('subtitle_session_restore_timer', 'embedded_subtitle_probe_timer', 'subtitle_volume_restore_timer'):
                try:
                    getattr(self, timer_name).stop()
                except Exception:
                    pass
            self._subtitle_source = 'off'
            try:
                self._subtitle_session_capture()
            except Exception as exc:
                optional_failure('player.subtitle_session_disable_save', exc)
            try:
                _tp_key = self._track_pref_key()
                if _tp_key:
                    _track_prefs.put(_tp_key, sub='off')
            except Exception as exc:
                optional_failure('player.track_pref_sub_off', exc)
            try:
                self['connection'].setText(_('PLAYING  •  SUBTITLES OFF'))
            except Exception:
                pass
            try:
                if self._lb_active():
                    self._lb_langs_update(force=True)
            except Exception:
                pass
            self._subtitle_inline_finish()
            return 1

    def _open_subtitle_settings_menu(self, preselect_action=None):
        _size = int(self._subtitle_style.get('size', 38) or 38)
        _size_name = 'Normal' if _size <= 38 else 'Large' if _size <= 44 else 'Larger' if _size <= 50 else 'Extra Large'
        choices = [(_('Subtitle Size • %s') % _(_size_name), 'style_size'), (_('Subtitle Color • %s') % _(_subtitle_color_name(self._subtitle_style.get('color'))), 'style_color'), (_('Subtitle Background • %s') % (_('Black') if self._subtitle_style.get('background') else _('Off')), 'style_background'), (_('Subtitle Position • %s') % _(_subtitle_position_name(self._subtitle_style.get('position'))), 'style_position')]
        if self._online_subtitle_active:
            choices += [(_('Auto Sync • lightweight'), 'auto_sync'), (_('Subtitle delay -0.5 sec'), 'delay_minus'), (_('Subtitle delay +0.5 sec'), 'delay_plus'), (_('Reset subtitle sync'), 'sync_reset')]
        selected = 0
        if preselect_action:
            for idx, row in enumerate(choices):
                if isinstance(row, (tuple, list)) and len(row) > 1 and (row[1] == preselect_action):
                    selected = idx
                    break
        return self._subtitle_inline_show(choices, selected, self._subtitle_settings_selected, self._subtitle_back_from_settings, 'settings')

    def _subtitle_settings_selected(self, choice=None):
        if not choice:
            return self._subtitle_back_from_settings()
        action = choice[1] if isinstance(choice, (tuple, list)) and len(choice) > 1 else choice
        if action == 'style_size':
            self._open_subtitle_size_menu()
        elif action == 'style_color':
            self._open_subtitle_color_menu()
        elif action == 'style_background':
            self._open_subtitle_background_menu()
        elif action == 'style_position':
            self._open_subtitle_position_menu()
        elif action == 'delay_minus':
            self._adjust_subtitle_delay(-500)
            self._open_subtitle_settings_menu('delay_minus')
        elif action == 'delay_plus':
            self._adjust_subtitle_delay(500)
            self._open_subtitle_settings_menu('delay_plus')
        elif action == 'sync_reset':
            self._online_subtitle_offset_ms = 0
            self._online_subtitle_scale = 1.0
            self._save_subtitle_sync()
            self._open_subtitle_settings_menu('sync_reset')
        elif action == 'auto_sync':
            self._subtitle_inline_finish()
            self._auto_sync_subtitle()

    def _native_subtitle_track_list(self):
        """Return the current service's real embedded subtitle list.

        ``None`` means this image/engine does not expose ``getSubtitleList``
        through the public subtitle interface, in which case the stock Enigma2
        selector remains the authority. An empty list means the interface is
        available but tracks have not been published yet (or truly do not
        exist).
        """
        try:
            service = self.session.nav.getCurrentService()
            subtitle = _us_service_subtitle(service)
            if subtitle is None:
                st = _dreamos_subtitle_tracks(service)
                if st is not None:
                    count = int(st.getNumberOfSubtitleTracks() or 0)
                    out = []
                    for idx in range(max(0, count)):
                        lang = ''
                        desc = ''
                        try:
                            info = st.getSubtitleTrackInfo(idx)
                            if info is not None:
                                gl = getattr(info, 'getLanguage', None)
                                if callable(gl):
                                    lang = str(gl() or '').strip()
                                gd = getattr(info, 'getDescription', None)
                                if callable(gd):
                                    desc = str(gd() or '').strip()
                        except Exception:
                            pass
                        out.append(('dreamos_track', int(idx), lang or 'Track %d' % (idx + 1), desc, lang or 'und'))
                    return out
                return []
            getter = getattr(subtitle, 'getSubtitleList', None)
            if not callable(getter):
                return None
            tracks = getter()
            if tracks is None:
                return []
            try:
                return list(tracks)
            except TypeError:
                return [tracks] if tracks else []
        except Exception as exc:
            optional_failure('player.embedded_subtitle_probe', exc)
            return []

    def _open_native_subtitle_selector_now(self):
        """Open OpenBH's real subtitle screen without the InfoBar pre-gate.

        InfoBarSubtitleSupport.subtitleSelection() first checks getSubtitleList()
        and silently returns when ServiceApp has not published the list at that
        exact instant. Our probe has already done the readiness check, so calling
        that wrapper here can make the user fall straight back to the player.
        Open the stock SubtitleSelection screen itself instead. The UI and track
        handling remain 100% native Enigma2/OpenBH.
        """
        self._embedded_subtitle_probe_pending = False
        try:
            self.embedded_subtitle_probe_timer.stop()
        except Exception:
            pass
        self._subtitle_native_hold_begin()
        try:
            from Screens.AudioSelection import SubtitleSelection as _NativeSubtitleSelection
            self.session.openWithCallback(self._subtitle_native_hold_end, _NativeSubtitleSelection, infobar=self)
            return 1
        except Exception as exc:
            optional_failure('player.native_subtitle_screen', exc)
            self._subtitle_native_hold_end()
        try:
            return us_func(InfoBarSubtitleSupport.subtitleSelection)(self)
        except Exception as exc:
            optional_failure('player.native_subtitleSelection', exc)
            return 0

    def _embedded_subtitle_probe_tick(self):
        if not self._embedded_subtitle_probe_pending:
            return 0
        if self.restored or self._closing_playback:
            self._embedded_subtitle_probe_pending = False
            return 0
        self._embedded_subtitle_probe_attempts += 1
        tracks = self._native_subtitle_track_list()
        if tracks is None:
            return self._open_native_subtitle_selector_now()
        if tracks:
            return self._open_native_subtitle_selector_now()
        if self._embedded_subtitle_probe_attempts < 12:
            try:
                self['connection'].setText(_('WAITING  •  EMBEDDED SUBTITLES'))
            except Exception:
                pass
            try:
                self.embedded_subtitle_probe_timer.stop()
                self.embedded_subtitle_probe_timer.start(450, True)
                return 1
            except Exception as exc:
                optional_failure('player.embedded_subtitle_timer', exc)
                return self._open_native_subtitle_selector_now()
        self._embedded_subtitle_probe_pending = False
        try:
            self['connection'].setText('')
        except Exception:
            pass
        try:
            show_notice(self.session, _('No embedded subtitles were reported by this stream.'), timeout=5, owner=self)
        except Exception:
            pass
        return 0

    def _open_native_subtitles(self):
        """Open the receiver's native embedded-subtitle screen immediately.

        This is an explicit user action, so do not hide the native screen behind
        InfoBarSubtitleSupport's subtitle-list readiness gate. OpenBH's
        SubtitleSelection screen already listens for service-info updates and can
        populate tracks as ServiceApp publishes them.
        """
        self._subtitle_inline_finish()
        self._subtitle_manual_action()
        try:
            self.subtitle_default_timer.stop()
        except Exception:
            pass
        try:
            self.embedded_subtitle_probe_timer.stop()
        except Exception:
            pass
        self._embedded_subtitle_probe_pending = False
        return self._open_native_subtitle_selector_now()

    def _persist_subtitle_style(self):
        try:
            save_settings({'subtitle_color': str(self._subtitle_style.get('color') or '#FFFFFF'), 'subtitle_background': bool(self._subtitle_style.get('background', False)), 'subtitle_position': max(-260, min(260, int(self._subtitle_style.get('position', 0) or 0))), 'subtitle_size': max(30, min(56, int(self._subtitle_style.get('size', 38) or 38)))})
        except Exception as exc:
            optional_failure('player.subtitle_style_save', exc)

    def _apply_subtitle_style_native(self):
        """Style the stock OpenBH SubtitleDisplay in-place.

        No replacement Screen, no alternate subtitle lifecycle. The receiver still
        owns show/hide/timing; Ultra only changes the existing label presentation.
        """
        display = self._online_subtitle_display
        if display is None:
            return
        try:
            label = display['subtitles']
            inst = getattr(label, 'instance', None)
            if inst is None:
                return
            font_size = max(30, min(56, int(self._subtitle_style.get('size', 38) or 38)))
            try:
                inst.setFont(_ultra_rfont('Regular', font_size))
            except Exception:
                pass
            try:
                fallback_inst = self['online_subtitle'].instance
                if fallback_inst is not None:
                    fallback_inst.setFont(_ultra_rfont('Regular', font_size))
            except Exception:
                pass
            inst.setForegroundColor(parseColor(str(self._subtitle_style.get('color') or '#FFFFFF')))
            background = bool(self._subtitle_style.get('background', False))
            try:
                inst.setBackgroundColor(parseColor('#000000'))
            except Exception:
                pass
            try:
                inst.setTransparent(0 if background else 1)
            except Exception:
                pass
            try:
                from ..wqhd_layout import factors
                sx, sy = factors()
                desktop = getDesktop(0).size()
                offset = max(-260, min(260, int(self._subtitle_style.get('position', 0) or 0)))
                if getattr(display, '_is_dreamos_dialog', False):
                    max_w = max(int(round(200 * sx)), desktop.width() - int(round(160 * sx)))
                    max_h = max(int(font_size * sy * 3.2), int(round(140 * sy)))
                    inst.resize(eSize(max_w, max_h))
                    width = max_w
                    height = max_h
                    if background:
                        try:
                            cs = inst.calculateSize()
                            if cs is not None and cs.width() > 0:
                                width = min(max_w, max(int(round(160 * sx)), int(cs.width()) + int(round(48 * sx))))
                                height = min(max_h, max(int(font_size * sy * 1.8), int(cs.height()) + int(round(20 * sy))))
                        except Exception:
                            pass
                else:
                    size = label.getSize()
                    width = max(int(round(100 * sx)), int(size[0]) + int(round(36 * sx)))
                    height = max(int(font_size * sy * 2.4), int(size[1]) + int(round(16 * sy)))
                x = max(0, (desktop.width() - width) // 2)
                y = max(20, min(desktop.height() - height - 18, desktop.height() - height - 32 - offset))
                inst.resize(eSize(width, height))
                inst.move(ePoint(x, y))
            except Exception as exc:
                optional_failure('player.subtitle_style_position', exc)
        except Exception as exc:
            optional_failure('player.subtitle_style_native', exc)

    def _refresh_online_subtitle_style(self):
        self._persist_subtitle_style()
        if self._online_subtitle_active and self._online_subtitle_current_text:
            self._set_online_subtitle_text(self._online_subtitle_current_text, force=True)
        else:
            self._apply_subtitle_style_native()

    def _open_subtitle_size_menu(self):
        current = max(30, min(56, int(self._subtitle_style.get('size', 38) or 38)))
        presets = ((_('Normal'), 38), (_('Large'), 44), (_('Larger'), 50), (_('Extra Large'), 56))
        choices = [(('✓ ' if int(value) == current else '') + name, int(value)) for name, value in presets]
        selected = next((i for i, row in enumerate(choices) if int(row[1]) == current), 0)
        return self._subtitle_inline_show(choices, selected, self._subtitle_size_selected, self._subtitle_back_from_size, 'size')

    def _subtitle_size_selected(self, choice=None):
        if not choice:
            return self._subtitle_back_from_size()
        try:
            value = max(30, min(56, int(choice[1] if isinstance(choice, (tuple, list)) and len(choice) > 1 else 38)))
        except Exception:
            return self._open_subtitle_settings_menu('style_size')
        self._subtitle_style['size'] = value
        self._refresh_online_subtitle_style()
        self._open_subtitle_settings_menu('style_size')

    def _open_subtitle_color_menu(self):
        current = str(self._subtitle_style.get('color') or '#FFFFFF').upper()
        choices = [(('✓ ' if value.upper() == current else '') + _(name), value) for name, value in SUBTITLE_STYLE_COLORS]
        selected = next((i for i, row in enumerate(choices) if str(row[1]).upper() == current), 0)
        return self._subtitle_inline_show(choices, selected, self._subtitle_color_selected, self._subtitle_back_from_color, 'color')

    def _subtitle_color_selected(self, choice=None):
        if not choice:
            return self._subtitle_back_from_color()
        value = str(choice[1] if isinstance(choice, (tuple, list)) and len(choice) > 1 else choice or '').upper()
        valid = {v.upper() for _n, v in SUBTITLE_STYLE_COLORS}
        if value not in valid:
            return self._open_subtitle_color_menu()
        self._subtitle_style['color'] = value
        self._refresh_online_subtitle_style()
        self._open_subtitle_settings_menu('style_color')

    def _open_subtitle_background_menu(self):
        enabled = bool(self._subtitle_style.get('background', False))
        choices = [(('✓ ' if not enabled else '') + _('Off • text only'), False), (('✓ ' if enabled else '') + _('Black • behind subtitle text'), True)]
        return self._subtitle_inline_show(choices, 1 if enabled else 0, self._subtitle_background_selected, self._subtitle_back_from_background, 'background')

    def _subtitle_background_selected(self, choice=None):
        if not choice:
            return self._subtitle_back_from_background()
        self._subtitle_style['background'] = bool(choice[1] if isinstance(choice, (tuple, list)) and len(choice) > 1 else False)
        self._refresh_online_subtitle_style()
        self._open_subtitle_settings_menu('style_background')

    def _open_subtitle_position_menu(self):
        current = int(self._subtitle_style.get('position', 0) or 0)
        choices = [(('✓ ' if int(offset) == current else '') + _(name), int(offset)) for name, offset in SUBTITLE_POSITION_PRESETS]
        selected = next((i for i, row in enumerate(choices) if int(row[1]) == current), 0)
        return self._subtitle_inline_show(choices, selected, self._subtitle_position_selected, self._subtitle_back_from_position, 'position')

    def _subtitle_position_selected(self, choice=None):
        if not choice:
            return self._subtitle_back_from_position()
        try:
            value = int(choice[1] if isinstance(choice, (tuple, list)) and len(choice) > 1 else 0)
        except Exception:
            return self._open_subtitle_position_menu()
        self._subtitle_style['position'] = max(-260, min(260, value))
        self._refresh_online_subtitle_style()
        self._open_subtitle_settings_menu('style_position')

    def _disable_native_subtitles(self):
        try:
            service = self.session.nav.getCurrentService()
            st = _dreamos_subtitle_tracks(service)
            self.selected_subtitle = None if st is not None else (0, 0, 0, 0)
            if st is not None:
                try:
                    st.disableSubtitles()
                except Exception:
                    pass
            subtitle = _us_service_subtitle(service)
            if subtitle is not None:
                window = getattr(self, 'subtitle_window', None)
                instance = getattr(window, 'instance', None) if window is not None else None
                if instance is not None:
                    subtitle.disableSubtitles(instance)
                else:
                    try:
                        subtitle.disableSubtitles()
                    except TypeError:
                        pass
            window = getattr(self, 'subtitle_window', None)
            if window is not None:
                window.hide()
        except Exception as exc:
            optional_failure('player.disable_native_subtitles', exc)

    def _disable_online_subtitles(self):
        self._online_subtitle_active = False
        self._online_subtitle_searching = False
        self._online_subtitle_generation += 1
        try:
            self._online_subtitle_cancel.set()
        except Exception:
            pass
        future = getattr(self, '_online_subtitle_future', None)
        if future is not None:
            try:
                future.cancel()
            except Exception:
                pass
        self._online_subtitle_future = None
        self._online_subtitle_cues = []
        self._online_subtitle_index = 0
        self._online_subtitle_path = ''
        try:
            self.online_subtitle_timer.stop()
        except Exception:
            pass
        try:
            self.online_subtitle_result_timer.stop()
        except Exception:
            pass
        try:
            while True:
                self._online_subtitle_queue.get_nowait()
        except Exception:
            pass
        try:
            self._set_online_subtitle_text('')
        except Exception:
            pass

    def _start_online_subtitles(self, language='EN', provider='subdl'):
        if self._online_subtitle_searching:
            return None
        language = str(language or 'EN').strip().upper().replace('-', '_')
        if not is_supported_subtitle_language(language):
            return None
        language_name = subtitle_language_name(language)
        provider = str(provider or 'subdl').strip().lower()
        if provider not in ('subdl', 'subsource'):
            provider = 'subdl'
        provider_name = 'SubSource' if provider == 'subsource' else 'SubDL'
        self._online_subtitle_provider = provider
        self._online_subtitle_language = language
        self._online_subtitle_language_name = language_name
        if self.media_type not in ('vod', 'series', 'episode'):
            self._subtitle_inline_finish()
            try:
                show_notice(self.session, _('Online subtitles are available for Movies and Series.'), timeout=5, owner=self)
            except Exception:
                pass
            return None
        if self._online_subtitle_searching:
            return None
        settings_data = load_settings()
        key_name = 'subsource_api_key' if provider == 'subsource' else 'subdl_api_key'
        api_key = str(settings_data.get(key_name) or '').strip()
        if not api_key:
            self._subtitle_inline_finish()
            message = _('SubSource API key is not configured.') if provider == 'subsource' else _('SubDL API key is not configured.')
            try:
                self.session.open(MessageBox, message, MessageBox.TYPE_ERROR, timeout=6)
            except Exception:
                pass
            return None
        self._subtitle_inline_finish()
        self._online_subtitle_request_context = (provider, language)
        self._subtitle_inline_finish()
        self._online_subtitle_searching = True
        self._online_subtitle_generation += 1
        generation = self._online_subtitle_generation
        try:
            self._online_subtitle_cancel.set()
        except Exception:
            pass
        self._online_subtitle_cancel = threading.Event()
        cancel_token = self._online_subtitle_cancel
        result_queue = self._online_subtitle_queue
        try:
            self['connection'].setText((_('SEARCHING  •  SUBSOURCE %s') if provider == 'subsource' else _('SEARCHING  •  SUBDL %s')) % language_name.upper())
            self.show()
        except Exception:
            pass
        item = dict(self.item)
        media_type = self.media_type
        name = self.name

        def worker():
            try:
                if provider == 'subsource':
                    candidates, ident = search_subsource_language(api_key, item, media_type, name, language)
                else:
                    candidates, ident = search_language(api_key, item, media_type, name, language)
                if cancel_token.is_set():
                    return
                result_queue.put(('choices', (candidates, ident, generation)))
            except Exception as exc:
                if cancel_token.is_set():
                    return
                result_queue.put(('error', (str(exc), generation)))
        try:
            self._online_subtitle_future = _PLAYER_BG_EXECUTOR.submit(worker)
            self.online_subtitle_result_timer.start(250, False)
        except Exception as exc:
            self._online_subtitle_searching = False
            self._subtitle_inline_finish()
            cancel_token.set()
            future = getattr(self, '_online_subtitle_future', None)
            if future is not None:
                try:
                    future.cancel()
                except Exception:
                    pass
            self._online_subtitle_future = None
            optional_failure('player.subtitle_search_start', exc)
            try:
                self.session.open(MessageBox, _('Subtitle search failed: %s') % _('Unknown error'), MessageBox.TYPE_ERROR, timeout=7)
            except Exception:
                pass

    def _drain_online_subtitle_result(self):
        if self.restored or self._closing_playback:
            try:
                self.online_subtitle_result_timer.stop()
            except Exception:
                pass
            return
        while True:
            try:
                kind, payload = self._online_subtitle_queue.get_nowait()
            except queue.Empty:
                return
            generation = self._online_subtitle_generation
            if kind == 'choices' and isinstance(payload, tuple) and (len(payload) == 3):
                candidates, ident, generation = payload
                if generation != self._online_subtitle_generation:
                    continue
                payload = (candidates, ident)
            elif kind == 'error' and isinstance(payload, tuple) and (len(payload) == 2):
                message, generation = payload
                if generation != self._online_subtitle_generation:
                    continue
                payload = message
            elif kind in ('downloaded', 'restore_file') and isinstance(payload, tuple) and (len(payload) == 2):
                result, generation = payload
                if generation != self._online_subtitle_generation:
                    continue
                payload = result
            break
        self._online_subtitle_future = None
        self._subtitle_restore_loading = False
        self._online_subtitle_searching = False
        try:
            self.online_subtitle_result_timer.stop()
        except Exception:
            pass
        if kind == 'error':
            raw_error = str(payload or '')
            optional_failure('player.online_subtitle_operation', RuntimeError(raw_error or 'unknown subtitle error'))
            low = raw_error.lower()
            language_name = getattr(self, '_online_subtitle_language_name', _('English'))
            if 'no ' in low and 'subtitle' in low:
                payload = _('No %s subtitle found') % language_name
            elif 'download' in low or 'archive' in low or 'extract' in low:
                payload = _('Subtitle download failed: %s') % _('Unknown error')
            else:
                payload = _('Subtitle search failed: %s') % _('Unknown error')
        if kind in ('downloaded', 'restore_file') and isinstance(payload, dict):
            self._subtitle_restore_loading = False
            try:
                self._online_subtitle_active_provider = str(payload.get('provider') or 'subdl')
                self._online_subtitle_active_language = str(payload.get('language') or 'EN')
                self._online_subtitle_language = self._online_subtitle_active_language
                self._online_subtitle_language_name = subtitle_language_name(self._online_subtitle_active_language)
                self._activate_online_subtitle(str(payload.get('path') or ''), str(payload.get('release') or getattr(self, '_online_subtitle_language_name', 'English')), prepared_cues=payload.get('_cues'))
                self._subtitle_inline_finish()
                if kind == 'restore_file':
                    return
                try:
                    us_func(UltraInfobarVisibility.doShow)(self)
                except Exception:
                    pass
                return
            except Exception as exc:
                optional_failure('player.subtitle_activate', exc)
                payload = _('Could not load subtitle: %s') % _('Unknown error')
        if kind == 'choices':
            candidates, ident = payload
            provider, language = self._online_subtitle_request_context
            self._online_subtitle_provider = provider
            self._online_subtitle_language = language
            self._online_subtitle_language_name = subtitle_language_name(language)
            self._online_subtitle_candidates = (candidates, ident, provider, language)
            choices = []
            for idx, c in enumerate(candidates):
                label = str(c.get('name') or _('%s subtitle') % getattr(self, '_online_subtitle_language_name', _('English')))
                if c.get('cached_path'):
                    label = '★ ' + label
                choices.append((label[:110], idx))
            if not choices:
                payload = _('No %s subtitle found') % getattr(self, '_online_subtitle_language_name', _('English'))
            else:
                try:
                    self._subtitle_inline_show(choices, 0, self._online_subtitle_choice_selected, self._subtitle_back_from_online_results, 'online_results')
                    return
                except Exception as exc:
                    optional_failure('player.subtitle_results_open', exc)
                    payload = _('Could not open subtitle results: %s') % _('Unknown error')
        self._subtitle_inline_finish()
        try:
            self['connection'].setText(_('PLAYING  •  NO %s SUBTITLE') % getattr(self, '_online_subtitle_language_name', _('English')).upper())
            show_notice(self.session, str(payload or _('No %s subtitle found') % getattr(self, '_online_subtitle_language_name', _('English'))), timeout=8, owner=self)
        except Exception:
            pass

    def _online_subtitle_choice_selected(self, choice=None):
        if not choice:
            language = str(getattr(self, '_online_subtitle_language', 'EN') or 'EN').upper().replace('-', '_')
            return self._open_online_subtitle_languages_menu(language)
        try:
            idx = int(choice[1])
        except Exception:
            return None
        try:
            if self._online_subtitle_searching:
                return None
            candidates, ident, provider, language = self._online_subtitle_candidates
            candidate = candidates[idx]
            api_key = str(load_settings().get('subsource_api_key') or '').strip() if provider == 'subsource' else ''
        except Exception:
            return None
        self._subtitle_inline_finish()
        self._online_subtitle_searching = True
        self._online_subtitle_generation += 1
        generation = self._online_subtitle_generation
        try:
            self._online_subtitle_cancel.set()
        except Exception:
            pass
        self._online_subtitle_cancel = threading.Event()
        cancel_token = self._online_subtitle_cancel
        result_queue = self._online_subtitle_queue
        try:
            self['connection'].setText(_('DOWNLOADING  •  %s SUBTITLE') % getattr(self, '_online_subtitle_language_name', _('English')).upper())
            self.show()
        except Exception:
            pass

        def worker():
            try:
                if provider == 'subsource':
                    result = download_subsource_candidate(api_key, candidate, ident)
                else:
                    result = download_candidate(candidate, ident)
                result = dict(result)
                result['_cues'] = parse_srt(str(result.get('path') or ''))
                result['provider'] = provider
                result['language'] = language
                if cancel_token.is_set():
                    return
                result_queue.put(('downloaded', (result, generation)))
            except Exception as exc:
                if cancel_token.is_set():
                    return
                result_queue.put(('error', (str(exc), generation)))
        try:
            self._online_subtitle_future = _PLAYER_BG_EXECUTOR.submit(worker)
            self.online_subtitle_result_timer.start(250, False)
        except Exception as exc:
            self._online_subtitle_searching = False
            cancel_token.set()
            future = getattr(self, '_online_subtitle_future', None)
            if future is not None:
                try:
                    future.cancel()
                except Exception:
                    pass
            self._online_subtitle_future = None
            optional_failure('player.subtitle_download_start', exc)
            try:
                self.session.open(MessageBox, _('Subtitle download failed: %s') % _('Unknown error'), MessageBox.TYPE_ERROR, timeout=7)
            except Exception:
                pass

    def _subtitle_sync_file(self):
        path = str(self._online_subtitle_path or '')
        return path + '.sync.json' if path else ''

    def _load_subtitle_sync(self):
        self._online_subtitle_offset_ms = 0
        self._online_subtitle_scale = 1.0
        path = self._subtitle_sync_file()
        if not path:
            return
        try:
            with open(path, 'r', encoding='utf-8') as h:
                data = json.load(h)
            self._online_subtitle_offset_ms = max(-300000, min(300000, int(data.get('offset_ms') or 0)))
            scale = float(data.get('scale') or 1.0)
            self._online_subtitle_scale = scale if 0.94 <= scale <= 1.06 else 1.0
        except Exception:
            pass

    def _save_subtitle_sync(self):
        path = self._subtitle_sync_file()
        if not path:
            return
        try:
            temp = path + '.tmp'
            with open(temp, 'w', encoding='utf-8') as h:
                json.dump({'offset_ms': int(self._online_subtitle_offset_ms), 'scale': float(self._online_subtitle_scale)}, h, separators=(',', ':'))
                h.flush()
                os.fsync(h.fileno())
            os.replace(temp, path)
        except Exception as exc:
            optional_failure('player.subtitle_sync_save', exc)

    def _adjust_subtitle_delay(self, delta_ms):
        if not self._online_subtitle_active:
            return
        self._online_subtitle_offset_ms = max(-300000, min(300000, int(self._online_subtitle_offset_ms) + int(delta_ms)))
        self._save_subtitle_sync()
        try:
            show_notice(self.session, _('Subtitle delay: %+.1f sec') % (self._online_subtitle_offset_ms / 1000.0), timeout=2, owner=self)
        except Exception:
            pass

    def _auto_sync_subtitle(self):
        """Safe lightweight drift correction without an always-running AI model.

        Detect only the two common 23.976<->25fps timing drifts when evidence is
        strong. Constant offsets stay user-adjustable in 0.5s steps.
        """
        if not self._online_subtitle_active or not self._online_subtitle_cues:
            return
        try:
            service = self.session.nav.getCurrentService()
            seek = service.seek() if service else None
            length = seek.getLength() if seek else None
            duration_ms = int(length[1] or 0) // 90 if length and (not length[0]) else 0
        except Exception:
            duration_ms = 0
        last_ms = int(self._online_subtitle_cues[-1][1] or 0)
        if duration_ms <= 20 * 60 * 1000 or last_ms <= 15 * 60 * 1000:
            try:
                show_notice(self.session, _('Auto Sync needs a stable movie duration. Use delay +/- for this subtitle.'), timeout=5, owner=self)
            except Exception:
                pass
            return
        ratio = float(duration_ms) / float(last_ms)
        candidates = (25.0 / 23.976, 23.976 / 25.0)
        best = min(candidates, key=lambda x: abs(x - ratio))
        if abs(best - ratio) <= 0.008 and last_ms >= int(duration_ms * 0.88):
            self._online_subtitle_scale = float(best)
            self._save_subtitle_sync()
            try:
                show_notice(self.session, _('Auto Sync applied • timing scale %.5f') % best, timeout=4, owner=self)
            except Exception:
                pass
        else:
            try:
                show_notice(self.session, _('No safe automatic drift detected. Use subtitle delay +/- for this release.'), timeout=5, owner=self)
            except Exception:
                pass

    def _activate_online_subtitle(self, path, release_name='Arabic', prepared_cues=None):
        cues = prepared_cues if prepared_cues is not None else parse_srt(path)
        if not cues:
            raise RuntimeError('subtitle file contains no readable cues')
        self._external_subtitle_stop()
        self._disable_native_subtitles()
        if self._online_subtitle_display is None:
            self._init_online_subtitle_display()
        self._online_subtitle_path = path
        self._online_subtitle_cues = cues
        self._online_subtitle_index = 0
        self._load_subtitle_sync()
        self._online_subtitle_active = True
        self._subtitle_source = 'online'
        self._subtitle_user_override = True
        try:
            self['online_subtitle'].hide()
        except Exception:
            pass
        try:
            display = self._online_subtitle_display
            if display is not None:
                display.show()
        except Exception:
            pass
        self._set_online_subtitle_text('')
        try:
            self.online_subtitle_timer.stop()
            self.online_subtitle_timer.start(80, True)
        except Exception:
            pass
        try:
            language_code = str(getattr(self, '_online_subtitle_active_language', 'AR') or 'AR').upper().replace('-', '_')
            if language_code == 'AR':
                self['connection'].setText(_('PLAYING  •  ARABIC SUBTITLES'))
            else:
                language_label = str(getattr(self, '_online_subtitle_language_name', '') or language_code).upper()
                self['connection'].setText(_('PLAYING  •  %s SUBTITLES') % language_label)
        except Exception:
            pass
        if not bool(getattr(self, '_subtitle_session_restoring', False)):
            try:
                self._subtitle_session_capture()
            except Exception as exc:
                optional_failure('player.subtitle_online_immediate_capture', exc)
        try:
            if self._lb_active():
                self._lb_langs_update(force=True)
        except Exception:
            pass
        return True

    def _online_subtitle_tick(self):
        if not self._online_subtitle_active or self.restored or self._closing_playback:
            try:
                self['online_subtitle'].setText('')
            except Exception:
                pass
            return
        try:
            service = self.session.nav.getCurrentService()
            seek = service.seek() if service else None
            pos = seek.getPlayPosition() if seek else None
            if not pos or pos[0]:
                try:
                    self.online_subtitle_timer.start(140, True)
                except Exception:
                    pass
                return
            ms = max(0, int(pos[1] or 0) // 90)
            scale = float(self._online_subtitle_scale or 1.0)
            timeline_ms = max(0, int((ms - int(self._online_subtitle_offset_ms or 0)) / scale))
        except Exception:
            try:
                self.online_subtitle_timer.start(140, True)
            except Exception:
                pass
            return
        ms = timeline_ms
        cues = self._online_subtitle_cues
        idx = max(0, min(int(self._online_subtitle_index or 0), max(0, len(cues) - 1)))
        while idx > 0 and (idx >= len(cues) or cues[idx - 1][1] >= ms):
            idx -= 1
        while idx < len(cues) and cues[idx][1] < ms:
            idx += 1
        self._online_subtitle_index = idx
        text = ''
        if idx < len(cues):
            start, end, body = cues[idx]
            if start <= ms <= end:
                text = body
        try:
            self._set_online_subtitle_text(text)
        except Exception as exc:
            optional_failure('player.online_subtitle_tick', exc)
        try:
            wait = 700
            if idx < len(cues):
                start, end, _body = cues[idx]
                boundary = end if start <= ms <= end else start
                wait = max(90, min(700, int(abs(boundary - ms))))
            self.online_subtitle_timer.start(wait, True)
        except Exception:
            pass

    def _enforce_default_subtitles_off(self):
        """Block cached/automatic subtitles until the user explicitly opens the selector."""
        if self.restored or self._subtitle_user_override:
            return
        try:
            service = self.session.nav.getCurrentService()
            st = _dreamos_subtitle_tracks(service)
            self.selected_subtitle = None if st is not None else (0, 0, 0, 0)
            if st is not None:
                try:
                    st.disableSubtitles()
                except Exception:
                    pass
            subtitle = _us_service_subtitle(service)
            if subtitle is not None:
                window = getattr(self, 'subtitle_window', None)
                instance = getattr(window, 'instance', None) if window is not None else None
                if instance is not None:
                    subtitle.disableSubtitles(instance)
                else:
                    try:
                        subtitle.disableSubtitles()
                    except TypeError:
                        pass
            window = getattr(self, 'subtitle_window', None)
            if window is not None:
                window.hide()
        except Exception as exc:
            optional_failure('player.default_subtitles_off', exc)
        self._subtitle_disable_attempts += 1
        if self._subtitle_disable_attempts < 4 and (not self._subtitle_user_override):
            try:
                self.subtitle_default_timer.start(900, True)
            except Exception as exc:
                optional_failure('player', exc)
from ..wqhd_layout import responsive_font as _ultra_rfont, factors as _ultra_factors

def _ultra_osd_scale():
    return _ultra_factors()[1]
