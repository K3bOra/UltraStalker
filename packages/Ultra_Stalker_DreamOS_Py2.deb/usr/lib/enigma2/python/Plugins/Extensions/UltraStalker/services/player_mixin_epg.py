# -*- coding: utf-8 -*-
"""Live EPG lookup, matching and painting.

Methods moved verbatim out of ``UltraStalkerPlayer`` (player_native.py); behaviour is unchanged.
This module is imported by player_native.py once its module-level helpers exist, so the
names below are taken from that module (partially initialised at this point) on purpose.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from ..us_env import str, int, max, us_casefold
from .player_native import (
    _PLAYER_BG_EXECUTOR,
    _clean_live_name,
    gFont,
    optional_failure,
    queue,
    re,
    time,
)


class PlayerEpgMixin(object):
    """Live EPG lookup, matching and painting."""

    @staticmethod
    def _epg_ts(value):
        try:
            if isinstance(value,(int,float)):return int(value)
            text=str(value or "").strip()
            if text.isdigit():return int(text)
            for fmt in ("%Y-%m-%d %H:%M:%S","%Y-%m-%dT%H:%M:%S"):
                try:return int(time.mktime(time.strptime(text[:19],fmt)))
                except Exception:pass
        except Exception:pass
        return 0

    @staticmethod
    def _epg_title(row):
        if not isinstance(row,dict):return ""
        return str(row.get("name") or row.get("title") or row.get("descr") or row.get("description") or "").replace("\n"," ").strip()

    @classmethod
    def _epg_events(cls, rows):
        """(start, stop, title) for the current and next programme, or None."""
        cur,nxt=cls._epg_pick(rows)
        def pack(event):
            if not event:return None
            st,sp,row=event;title=cls._epg_title(row)
            return (int(st or 0),int(sp or 0),title) if title else None
        return pack(cur),pack(nxt)

    @classmethod
    def _epg_lines(cls, rows):
        current,nxt=cls._epg_pick(rows)
        def line(event):
            if not event:return ""
            st,sp,row=event;title=cls._epg_title(row)
            if not title:return ""
            if st and sp:return "%s - %s   %s"%(time.strftime("%H:%M",time.localtime(st)),time.strftime("%H:%M",time.localtime(sp)),title)
            return title
        return line(current),line(nxt)

    @classmethod
    def _epg_pick(cls, rows):
        now=int(time.time());events=[]
        for row in rows if isinstance(rows,list) else []:
            if not isinstance(row,dict):continue
            start=next((v for v in (cls._epg_ts(row.get(k)) for k in ("time","start_timestamp","start")) if v>0),0)
            stop=next((v for v in (cls._epg_ts(row.get(k)) for k in ("time_to","stop_timestamp","stop","end")) if v>0),0)
            # MAG short-EPG commonly supplies start + duration rather than an
            # absolute stop timestamp.  Accept both shapes so Now/Next works on
            # portals that never emit stop_timestamp.
            if not stop and start:
                try:
                    duration=int(float(row.get("duration") or row.get("length") or 0))
                    if duration>0:stop=start+duration
                except Exception:pass
            if stop and start and stop<=start:
                if stop<86400:stop=start+stop
                elif start-stop<24*3600:stop+=86400
                else:stop=0
            events.append((start,stop,row))
        events.sort(key=lambda x:x[0] or 0)
        events=list((s,(e or (events[i+1][0] if i+1<len(events) else 0)),r) for i,(s,e,r) in enumerate(events))
        current=None;nxt=None
        for idx,event in enumerate(events):
            st,sp,row=event
            if st and sp and st<=now<sp:
                current=event;nxt=events[idx+1] if idx+1<len(events) else None;break
        if current is None and events:
            future=list(e for e in events if not e[0] or e[0]>=now)
            current=future[0] if future else events[0]
            try:pos=events.index(current);nxt=events[pos+1] if pos+1<len(events) else None
            except Exception:nxt=None
        return current,nxt

    def _fit_live_epg_widget(self, name, max_size, min_size):
        try:
            widget=self[name];inst=widget.instance
            if inst is None:return
            if hasattr(inst,"setNoWrap"):inst.setNoWrap(1)
            width=max(160,int(inst.size().width())-10)
            chosen=int(max_size)
            for size in range(int(max_size),int(min_size)-1,-1):
                inst.setFont(_ultra_rfont("Regular",size))
                try:measured=int(inst.calculateSize().width())
                except Exception:measured=0
                if measured<=0 or int(measured*1.06)<=width:
                    chosen=size;break
                chosen=max(int(min_size),size-1)
            inst.setFont(_ultra_rfont("Regular",chosen))
        except Exception as exc:optional_failure("player.live_epg_font_fit",exc)

    def _paint_live_epg(self, now_line="", next_line=""):
        if self.media_type not in ("itv","live"):return
        now_text=str(now_line or "").replace("\n"," ").strip()
        next_text=str(next_line or "").replace("\n"," ").strip()
        try:
            self["live_epg_now"].setText(now_text)
            self._fit_live_epg_widget("live_epg_now",25,12)
        except Exception:pass
        try:
            self["live_epg_next"].setText(next_text)
            self._fit_live_epg_widget("live_epg_next",18,10)
        except Exception:pass
        self._lb_set_epg(None,None,now_text,next_text)

    @staticmethod
    def _live_epg_row_ids(row):
        """Return every plausible provider EPG id, strongest field first.

        Home/Favorites/history rows can retain a playback ``id`` that is not the
        Stalker ``ch_id`` expected by get_short_epg.  Folder rows usually carry
        both.  Trying the provider-specific id first keeps normal category opens
        at one request while making compact reopen rows safe.
        """
        if not isinstance(row,dict):return []
        out=[]
        for key in ("ch_id","channel_id","id","stream_id"):
            value=row.get(key)
            if value in (None,""):continue
            text=str(value).strip()
            if text and text not in out:out.append(text)
        return out

    @staticmethod
    def _live_epg_row_command(row):
        if not isinstance(row,dict):return ""
        value=str(row.get("cmd") or row.get("command") or row.get("url") or "").strip().strip('"').strip("'")
        low=value.lower()
        for prefix in ("ffmpeg ","auto "):
            if low.startswith(prefix):
                value=value[len(prefix):].strip();low=value.lower()
        return value

    @staticmethod
    def _live_epg_row_name(row):
        if not isinstance(row,dict):return ""
        value=str(row.get("name") or row.get("title") or row.get("channel_name") or "").strip()
        try:value=_clean_live_name(value,True)
        except Exception:pass
        return us_casefold(re.sub(r"\s+"," ",value).strip())

    @classmethod
    def _live_epg_same_channel(cls,left,right):
        """Strict-enough identity bridge for compact Home/My List rows.

        This is used only after a direct short-EPG lookup failed.  Playback
        ownership remains untouched; the bridge resolves the provider row only
        for EPG identity.
        """
        if not isinstance(left,dict) or not isinstance(right,dict):return False
        lids=set(cls._live_epg_row_ids(left));rids=set(cls._live_epg_row_ids(right))
        if lids and rids and lids.intersection(rids):return True
        lc=cls._live_epg_row_command(left);rc=cls._live_epg_row_command(right)
        if lc and rc and lc==rc:return True
        ln=cls._live_epg_row_name(left);rn=cls._live_epg_row_name(right)
        return bool(ln and rn and ln==rn)

    def _live_epg_candidate_rows(self):
        """Snapshot rows that may own EPG for the channel currently playing.

        The in-player drawer owns an authoritative provider page even when the
        Player was opened from Home/Favorites.  Prefer that exact row over the
        compact saved item, then fall back to the item itself.
        """
        rows=[]
        try:
            index=int(getattr(self,"_zap_index",0) or 0);channels=getattr(self,"_zap_channels",[]) or []
            if 0<=index<len(channels) and isinstance(channels[index],dict):rows.append(dict(channels[index]))
        except Exception:pass
        if isinstance(self.item,dict):
            current=dict(self.item)
            if not rows or not self._live_epg_same_channel(rows[0],current):rows.append(current)
            else:
                # Keep runtime refs from self.item available to the preferred row.
                for key in ("_live_client_ref","_player_client_ref","_live_category_id","_live_folder_title"):
                    if current.get(key) is not None and rows[0].get(key) is None:rows[0][key]=current.get(key)
        return rows

    @classmethod
    def _live_epg_best_match(cls,target,rows):
        rows=[dict(x) for x in (rows or []) if isinstance(x,dict)]
        if not rows:return None
        # Exact command/id match wins.  Exact normalized title is the bounded
        # fallback used by provider search for old compact favorites/history.
        for row in rows:
            if cls._live_epg_same_channel(target,row):return row
        return None

    def _refresh_live_epg(self):
        if self.media_type not in ("itv","live") or self.restored or self._closing_playback:return
        candidates=self._live_epg_candidate_rows()
        row=candidates[0] if candidates else (self.item if isinstance(self.item,dict) else {})

        # Build channel identity before touching the labels. playService()/evStart
        # legitimately call this method several times for the SAME channel. The old
        # path blanked Now/Next on every call, which made good EPG visibly blink.
        request_key=(self._live_epg_row_command(row) or "|").strip()+"|"+(self._live_epg_row_name(row) or "")
        if request_key=="|":request_key="|".join(self._live_epg_row_ids(row)) or str(self.name or "live")
        same_channel=bool(request_key and request_key==str(getattr(self,"_live_epg_last_channel","") or ""))
        self._apply_live_infobar_layout()
        if not same_channel:
            # Genuine channel boundaries still clear once so the old channel can
            # never leak into the new one. Same-channel refreshes keep the paint.
            self._lb_epg_state="loading";self._lb_epg_expired=0
            self._paint_live_epg("","")

        immediate=str(row.get("now") or row.get("program") or row.get("epg_title") or "").strip()
        nxt=str(row.get("next") or row.get("next_program") or row.get("epg_next") or "").strip()
        if not (immediate or nxt) and isinstance(self.item,dict):
            immediate=str(self.item.get("now") or self.item.get("program") or self.item.get("epg_title") or "").strip()
            nxt=str(self.item.get("next") or self.item.get("next_program") or self.item.get("epg_next") or "").strip()
        if (immediate or nxt) and (not same_channel or not (self._lb_epg_now or self._lb_epg_now_text)):self._paint_live_epg(immediate,nxt)

        # Remember identity even when this source has no EPG client. This prevents
        # repeated service lifecycle callbacks from clearing already-painted text.
        self._live_epg_last_channel=request_key
        client=(self.item.get("_live_client_ref") or self.item.get("_player_client_ref")) if isinstance(self.item,dict) else None
        if client is None or not hasattr(client,"epg"):
            if self._lb_epg_state=="loading":self._lb_set_epg(self._lb_epg_now,self._lb_epg_next,self._lb_epg_now_text,self._lb_epg_next_text,state="none")
            return

        # A stable request identity is independent of whichever candidate id
        # eventually succeeds.  That lets the worker fall through from a compact
        # Home/My List row to the exact provider row without racing a later zap.
        self._live_epg_generation+=1;generation=self._live_epg_generation
        q=self._live_epg_queue
        category_id=str(getattr(self,"_zap_category_id","") or row.get("_live_category_id") or row.get("category_id") or row.get("genre_id") or "")
        query=str(row.get("name") or row.get("title") or self.name or "").strip()
        candidate_snapshot=[dict(x) for x in candidates if isinstance(x,dict)]

        def worker():
            _nl_error = [None]
            _nl_error[0]=None;tried=set()
            def try_row(test_row):
                pass
                for epg_id in self._live_epg_row_ids(test_row):
                    if epg_id in tried:continue
                    tried.add(epg_id)
                    try:
                        rows=client.epg(epg_id,4) or []
                        if rows:return epg_id,rows
                    except Exception as exc:_nl_error[0]=exc
                return "",[]
            # Fast path: exact provider drawer row first, then saved Player row.
            for test_row in candidate_snapshot:
                cid,rows=try_row(test_row)
                if rows:q.put((generation,request_key,rows,None));return

            target=candidate_snapshot[0] if candidate_snapshot else dict(row or {})
            resolved=None
            # A saved Home/Favorites/My List row may be intentionally compact.
            # Resolve EPG identity only after direct ids fail; playback/create_link
            # identity is never changed by this fallback.
            if query and category_id and hasattr(client,"search_category_fast"):
                try:
                    found=client.search_category_fast(query,media_type="itv",category=category_id,limit=24,max_pages=8,time_budget=4) or []
                    resolved=self._live_epg_best_match(target,found)
                except Exception as exc:_nl_error[0]=exc
            if resolved is None and query and hasattr(client,"search_content_fast"):
                try:
                    found=client.search_content_fast(query,media_types=("itv",),limit=24,max_pages=8,time_budget=4) or []
                    resolved=self._live_epg_best_match(target,found)
                except Exception as exc:_nl_error[0]=exc
            if isinstance(resolved,dict):
                cid,rows=try_row(resolved)
                if rows:q.put((generation,request_key,rows,None));return
            q.put((generation,request_key,[],_nl_error[0]))
        try:
            fut=getattr(self,"_live_epg_future",None)
            if fut is not None:
                try:fut.cancel()
                except Exception:pass
            self._live_epg_future=_PLAYER_BG_EXECUTOR.submit(worker)
            self.live_epg_timer.stop();self.live_epg_timer.start(100,False)
        except Exception as exc:optional_failure("player.live_epg_start",exc)

    def _drain_live_epg_result(self):
        if self.restored or self._closing_playback:
            try:self.live_epg_timer.stop()
            except Exception:pass
            return
        # Multiple refreshes are normal around playService()/evStart.  A stale
        # worker can finish after a newer generation has already started.  Never
        # let that stale queue item stop the timer and strand the current EPG
        # result behind it.
        matched=None
        while True:
            try:result=self._live_epg_queue.get_nowait()
            except queue.Empty:break
            try:generation,request_key,rows,error=result
            except Exception:continue
            if generation==self._live_epg_generation and request_key==self._live_epg_last_channel:
                matched=(rows,error)
        if matched is None:
            future=getattr(self,"_live_epg_future",None)
            if future is not None and not future.done():return
            try:self.live_epg_timer.stop()
            except Exception:pass
            return
        try:self.live_epg_timer.stop()
        except Exception:pass
        rows,error=matched
        if not error:
            now_line,next_line=self._epg_lines(rows)
            if now_line or next_line:
                self._paint_live_epg(now_line,next_line)
                try:
                    cur,nxt=self._epg_events(rows)
                    self._lb_set_epg(cur,nxt,cur[2] if cur else "",nxt[2] if nxt else "",state="ready")
                except Exception as exc:optional_failure("player.live_bar_epg_events",exc)
                return
        # Nothing new from the provider: keep any row-supplied text, otherwise
        # replace "Loading" with an honest "No EPG information".
        self._lb_set_epg(self._lb_epg_now,self._lb_epg_next,self._lb_epg_now_text,self._lb_epg_next_text,state="none")

    def _now_text(self):
        # The compact InfoBar is for playback state, not a duplicate channel name.
        # For Live, center text is reserved for real EPG only.
        if self.media_type in ("vod", "series", "episode", "catchup"):
            return ""
        text = self.item.get("now") or self.item.get("program") or self.item.get("epg_title") or ""
        text = str(text or "").strip()
        if not text:
            return ""
        try:
            if us_casefold(_clean_live_name(text,self._cfg_clean_titles)) == us_casefold(_clean_live_name(self.name,self._cfg_clean_titles)):
                return ""
        except Exception:
            if us_casefold(text) == us_casefold(str(self.name or "")):
                return ""
        return text[:62]

from ..wqhd_layout import responsive_font as _ultra_rfont, factors as _ultra_factors

def _ultra_osd_scale():
    return _ultra_factors()[1]
