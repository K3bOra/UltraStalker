# -*- coding: utf-8 -*-
"""Technical chips, codec/quality/audio probes and provider live picons.

Methods moved verbatim out of ``UltraStalkerPlayer`` (player_native.py); behaviour is unchanged.
This module is imported by player_native.py once its module-level helpers exist, so the
names below are taken from that module (partially initialised at this point) on purpose.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from ..us_env import str, int, open, round, max, min, OSError, us_casefold
from ..core.shared_executors import LIVE_PICON_EXECUTOR
from .player_native import (
    LOG,
    PERSISTENT_CACHE_ROOT,
    _,
    _PILImage,
    _asset,
    _fallback_player_frames,
    _normalize_provider_image_url,
    build_safe_media_opener,
    hashlib,
    iServiceInformation,
    optional_failure,
    os,
    queue,
    re,
    threading,
    time,
    urllib,
    validate_remote_media_url,
)


class PlayerChipsMixin(object):
    """Technical chips, codec/quality/audio probes and provider live picons."""

    @staticmethod
    def _read_proc_number(paths, base=10):
        for pathname in paths:
            try:
                if os.path.exists(pathname):
                    with open(pathname, "r") as handle:
                        value = handle.read().strip()
                    if value:
                        return int(value, base)
            except Exception as exc:
                optional_failure("player", exc)
        return None

    @staticmethod
    def _info_number(info, name, default=None):
        try:
            key = getattr(iServiceInformation, name)
            value = info.getInfo(key)
            if value == -2:
                raw = info.getInfoString(key)
                return int(str(raw).strip())
            if value is not None and value >= 0:
                return int(value)
        except Exception as exc:
            optional_failure("player", exc)
        return default

    @staticmethod
    def _audio_codec_text(service, info):
        try:
            tracks = service.audioTracks()
            if tracks and tracks.getNumberOfTracks() > 0:
                current = tracks.getCurrentTrack()
                if current < 0:
                    current = 0
                desc = str(tracks.getTrackInfo(current).getDescription() or "").strip()
                if desc:
                    token = desc.split()[0].upper()
                    aliases = {"AC-3": "AC3", "AC3+": "E-AC3", "HE-AAC": "AAC"}
                    return aliases.get(token, token)[:12]
        except Exception as exc:
            optional_failure("player", exc)
        try:
            key = getattr(iServiceInformation, "sAudioType")
            raw = info.getInfoString(key)
            if raw:
                return str(raw).upper()[:12]
        except Exception as exc:
            optional_failure("player", exc)
        return "AUDIO"

    @staticmethod
    def _audio_track_signature(service, info=None):
        """Return stable audio descriptors exposed by the current Enigma2 service."""
        values=[]
        try:
            tracks=service.audioTracks() if service is not None else None
            count=int(tracks.getNumberOfTracks()) if tracks is not None else 0
            count=max(0,min(count,32))
            for idx in range(count):
                try:
                    track=tracks.getTrackInfo(idx)
                except Exception:
                    track=None
                if track is None:
                    continue
                for getter in ("getDescription","getLanguage"):
                    try:
                        fn=getattr(track,getter,None)
                        value=str(fn() or "").strip() if callable(fn) else ""
                    except Exception:
                        value=""
                    if value and value.lower() not in ("none","unknown","und"):
                        values.append(value)
        except Exception:
            pass
        if info is not None:
            try:
                key=getattr(iServiceInformation,"sAudioType",None)
                if key is not None:
                    raw=str(info.getInfoString(key) or "").strip()
                    if raw:values.append(raw)
            except Exception:
                pass
        for pathname in (
            "/proc/stb/audio/0/codec",
            "/proc/stb/audio/0/format",
            "/proc/stb/audio/0/bitstream",
            "/proc/stb/audio/0/codec_name",
        ):
            try:
                if os.path.exists(pathname):
                    with open(pathname,"r") as handle:
                        raw=handle.read().strip()
                    if raw:values.append(raw)
            except Exception:
                pass
        seen=set();result=[]
        for value in values:
            normalized=" ".join(str(value or "").split()).strip()
            key=us_casefold(normalized)
            if normalized and key not in seen:
                seen.add(key);result.append(normalized)
        return tuple(result)

    @staticmethod
    def _audio_signature_badge_key(signature):
        """Classify the strongest advertised audio format into one bundled badge.

        Ordering matters: Atmos/JOC outranks its TrueHD/E-AC3 carrier; DTS-HD
        outranks plain DTS; DD+ outranks DD.  Unknown/MPEG-only audio stays blank
        rather than showing a misleading badge.
        """
        blob=" | ".join(str(v or "") for v in (signature or ())).lower()
        if not blob:
            return ""
        # Dolby Atmos can arrive as explicit Atmos text or E-AC3 JOC metadata.
        if re.search(r"(?<![a-z0-9])atmos(?![a-z0-9])",blob) or re.search(r"(?<![a-z0-9])joc(?![a-z0-9])",blob):
            return "atmos"
        # Lossless Dolby carrier.  MLP is the codec family used by TrueHD.
        if re.search(r"true[ _-]?hd",blob) or re.search(r"(?<![a-z0-9])mlp(?![a-z0-9])",blob):
            return "truehd"
        # DTS-HD / Master Audio before generic DTS.
        if (re.search(r"dts[ _-]?hd",blob) or re.search(r"dts[ _-]?(?:ma|master)",blob)
                or "master audio" in blob):
            return "dtshd"
        # Dolby Digital Plus / E-AC3 before AC3.
        if (re.search(r"e[ _-]?ac[ _-]?3",blob) or re.search(r"(?<![a-z0-9])eac3(?![a-z0-9])",blob)
                or "dolby digital plus" in blob or re.search(r"(?<![a-z0-9])dd\+(?![a-z0-9])",blob)
                or re.search(r"(?<![a-z0-9])ac3\+(?![a-z0-9])",blob)):
            return "ddplus"
        if (re.search(r"(?<![a-z0-9])ac[ _-]?3(?![a-z0-9])",blob) or "dolby digital" in blob
                or re.search(r"(?<![a-z0-9])dd(?![a-z0-9+])",blob)):
            return "dd"
        if re.search(r"(?<![a-z0-9])dts(?![a-z0-9])",blob):
            return "dts"
        if (re.search(r"(?<![a-z0-9])aac(?![a-z0-9])",blob) or "he-aac" in blob
                or "heaac" in blob):
            return "aac"
        if re.search(r"(?<![a-z0-9])(?:lpcm|pcm)(?![a-z0-9])",blob):
            return "pcm"
        return ""

    @staticmethod
    def _audio_badge_asset(key):
        key=str(key or "").strip().lower()
        names={
            "atmos":"player_typo_audio_atmos_201x46.png",
            "truehd":"player_typo_audio_truehd_201x46.png",
            "ddplus":"player_typo_audio_ddplus_201x46.png",
            "dd":"player_typo_audio_dd_201x46.png",
            "dtshd":"player_typo_audio_dtshd_201x46.png",
            "dts":"player_typo_audio_dts_201x46.png",
            "aac":"player_typo_audio_aac_201x46.png",
            "pcm":"player_typo_audio_pcm_201x46.png",
        }
        name=names.get(key,"")
        if not name:return ""
        path=_asset(name)
        return path if path and os.path.isfile(path) else name

    def _paint_audio_format_badge(self, key):
        key=str(key or "").strip().lower()
        active=bool(key)
        self._audio_format_badge_key=key if active else ""
        self._audio_format_badge_path=self._audio_typo_asset(key) if active else ""
        self._audio_format_badge_active=active
        try:
            if self["audio_format_badge"].instance is not None:
                try:self["audio_format_badge"].instance.setPixmap(None)
                except Exception:pass
            self["audio_format_badge"].hide()
        except Exception:pass
        try:self._sync_typographic_technical_row()
        except Exception as exc:optional_failure("player.audio_typographic_row",exc)
        return active

    def _update_live_audio_format_badge(self, service, info=None):
        if self.media_type in ("vod","series","episode"):
            return
        try:
            signature=self._audio_track_signature(service,info)
            self._paint_audio_format_badge(self._audio_signature_badge_key(signature))
        except Exception as exc:
            optional_failure("player.live_audio_format_badge",exc)
            self._paint_audio_format_badge("")

    def _set_stream_info_text(self, widget_name, value):
        text=str(value or "")
        cache=self._stream_info_text_cache
        if cache.get(widget_name)==text:return False
        self[widget_name].setText(text);cache[widget_name]=text
        return True

    def _apply_technical_row_layout(self, audio_badge_active=None):
        try:self._sync_typographic_technical_row()
        except Exception as exc:optional_failure("player.typographic_row_layout",exc)

    @staticmethod
    def _tech_asset(name):
        path=_asset(str(name or ""))
        return path if path and os.path.isfile(path) else ""

    def _current_fps(self):
        """Whole frames-per-second of the running service, 0 when unknown (read at most once a second)."""
        try:
            stamp,val=self._fps_cache
            now=time.monotonic()
            if now-stamp<1.0 and val:return val
            raw=self._read_proc_number(("/proc/stb/vmpeg/0/framerate",),10) or 0
            if not raw:
                info=None
                try:
                    service=self.session.nav.getCurrentService();info=service and service.info()
                except Exception:info=None
                if info is not None:raw=self._info_number(info,"sFrameRate",0) or 0
            raw=int(raw or 0)
            if raw>1000:fps=int(round(raw/1000.0))
            elif raw>0:fps=int(round(raw))
            else:fps=0
            if not 1<=fps<=240:fps=0
            self._fps_cache=(now,fps)
            return fps
        except Exception as exc:
            optional_failure("player.fps",exc);return 0

    def _set_typographic_chip(self, widget_name, path, force=False):
        path=str(path or "")
        try:
            cache=getattr(self,"_typographic_chip_paths",None)
            if cache is None:
                cache={};self._typographic_chip_paths=cache
            widget=self[widget_name]
            inst=widget.instance
            if not path or not os.path.isfile(path):
                cache.pop(widget_name,None)
                if inst is not None:
                    try:inst.setPixmap(None)
                    except Exception:pass
                widget.hide();return False
            # Before skin creation Pixmap.instance is None. Never cache an image
            # that was not actually bound, otherwise the onLayoutFinish pass
            # would think it was already painted and leave a blank card.
            if inst is None:
                cache.pop(widget_name,None)
                return False
            # Typography is a transparent, native-size layer.  Never merge it
            # with adaptive glass at runtime: that used PIL/blur/resize on the GUI
            # thread and made OK/InfoBar response visibly lag.
            if force or cache.get(widget_name)!=path:
                inst.setPixmapFromFile(path)
                cache[widget_name]=path
            widget.show();return True
        except Exception as exc:
            optional_failure("player.typographic_chip",exc);return False

    def _bind_technical_glass_frames(self, force=False):
        """Bind cached adaptive glass as a separate layer behind transparent typography.

        The glass is generated once by the existing Player chrome cache for the
        current artwork.  InfoBar OK presses only rebind tiny cached PNGs; there
        is no PIL composition, blur, resize or file generation on the GUI thread.
        """
        mapping=(
            ("chip_quality","chip_video_quality_bg"),
            ("chip_audio_codec","chip_audio_codec_bg"),
            ("chip_video","chip_video_codec_bg"),
            ("chip_fps","chip_fps_bg"),
            ("chip_stream","chip_stream_bg"),
            ("chip_audio","chip_audio_bg"),
            ("chip_engine","chip_engine_bg"),
        )
        if self._lb_active():
            self._lb_suppress_legacy();return
        frames=dict(getattr(self,"_player_chrome_frames",{}) or _fallback_player_frames())
        cache=getattr(self,"_technical_glass_paths",None)
        if cache is None:
            cache={};self._technical_glass_paths=cache
        for key,widget_name in mapping:
            try:
                path=str(frames.get(key) or "")
                widget=self[widget_name];inst=widget.instance
                if not path or not os.path.isfile(path):
                    cache.pop(widget_name,None)
                    if inst is not None:
                        try:inst.setPixmap(None)
                        except Exception:pass
                    widget.hide();continue
                if inst is None:
                    cache.pop(widget_name,None);continue
                if force or cache.get(widget_name)!=path:
                    inst.setPixmapFromFile(path);cache[widget_name]=path
                widget.show()
            except Exception as exc:
                optional_failure("player.technical_glass",exc)

    def _sync_typographic_technical_row(self, force=False):
        """Paint the six technical cards using the original Player chip slots.

        Typography is static and frame colour is generated from the current
        adaptive Player palette. The same exact-size row is used by Live, Movies,
        Series, Episodes and Catch-up without changing the playback lifecycle.
        """
        if self._lb_active():
            # R5.541: Live shows its technical info as measured chips in the bar.
            try:
                self._lb_suppress_legacy();self._lb_layout_top(force)
            except Exception as exc:optional_failure("player.live_bar_chips",exc)
            return
        try:
            # Runtime Labels remain as hidden state holders for metadata/menu
            # code. Presentation is owned entirely by the six PNG chip slots.
            for name in ("video_quality","audio_codec","video_codec","extension","audio_tag","engine",
                         "vod_quality_badge","audio_format_badge","chip_subtitles","subtitle_tag"):
                try:self[name].hide()
                except Exception:pass

            quality=str(self["video_quality"].getText() or "")
            if quality.upper() in ("","AUTO","VIDEO"):
                quality=str(getattr(self,"_observed_quality","") or getattr(self,"_static_quality","") or "")
            qpath=self._quality_typo_asset(quality)
            # If decoder + catalogue still say AUTO, keep only the glass
            # background visible until the quality probe resolves.
            self._bind_technical_glass_frames(force=False)
            if not self._current_fps():
                try:self["chip_fps_bg"].hide()
                except Exception:pass
            if self._chips_text_mode():
                self._sync_text_technical_row(quality,force)
                return
            self._restore_english_technical_geometry()
            for _tn in ("quality","audio_codec","video_codec","fps","stream","audio","engine"):
                try:self["chipt_%s"%_tn].hide()
                except Exception:pass
            self._chip_text_cache={}
            self._set_typographic_chip("chip_video_quality",qpath,force)
            self._set_typographic_chip("chip_audio_codec",self._audio_typo_asset(getattr(self,"_audio_format_badge_key",""),self["audio_codec"].getText()),force)
            self._set_typographic_chip("chip_video_codec",self._video_typo_asset(self["video_codec"].getText()),force)
            self._set_typographic_chip("chip_fps",self._fps_typo_asset(self._current_fps()),force)
            self._set_typographic_chip("chip_stream",self._tech_asset("player_typo_stream_194x46.png"),force)
            self._set_typographic_chip("chip_audio",self._tech_asset("player_typo_audio_tag_189x46.png"),force)
            self._set_typographic_chip("chip_engine",self._engine_typo_asset(self["engine"].getText()),force)
        except Exception as exc:
            optional_failure("player.typographic_row_sync",exc)

    @staticmethod
    def _chips_text_mode():
        """V9.2.2-r6: every language, English included, gets plain translated text in the chips."""
        return True

    def _real_resolution_text(self):
        """The decoder's real picture size ("1920x800"), or "" until it is known."""
        try:
            w=int(getattr(self,"_observed_width",0) or 0);h=int(getattr(self,"_observed_height",0) or 0)
        except Exception:
            return ""
        return "%dx%d"%(w,h) if (160<=w<=8192 and 120<=h<=4320) else ""

    def _sync_text_technical_row(self, quality, force=False):
        """Non-English: the six chip frames carry translated text that is fitted inside the card."""
        labels={"AAC":"AAC","DD":"DD","DDPLUS":"DD+","ATMOS":"ATMOS","TRUEHD":"TRUEHD","DTS":"DTS","DTSHD":"DTS-HD","PCM":"PCM"}
        q=str(quality or "").upper()
        qtext="4K" if ("4K" in q or "UHD" in q) else ("FULL HD" if ("FULL" in q or "FHD" in q) else ("HD" if "HD" in q else ("SD" if "SD" in q else "")))
        akey=str(getattr(self,"_audio_format_badge_key","") or "").strip().lower()
        if not akey:
            try:akey=str(self._audio_signature_badge_key((str(self["audio_codec"].getText() or ""),)) or "").lower()
            except Exception:akey=""
        audio_word=_("AUDIO")
        atext=("%s %s"%(labels.get(akey.upper(),""),audio_word)).strip() if akey.upper() in labels else audio_word
        vraw=str(self["video_codec"].getText() or "").strip()
        vtext=_("VIDEO") if (not vraw or vraw.upper()=="VIDEO") else vraw
        fps=self._fps_snap(self._current_fps())
        engine=str(self["engine"].getText() or "")
        for word in ("Native","Engine"):
            if engine==word or engine.startswith(word+" "):
                engine=_(word)+engine[len(word):];break
        qtext=self._real_resolution_text() or qtext
        texts=(("chipt_quality",qtext and (qtext if "x" in qtext else _(qtext))),("chipt_audio_codec",atext),("chipt_video_codec",vtext),("chipt_fps",("%d %s"%(fps,_("FPS"))) if fps else ""),
               ("chipt_stream",_("STREAM")),("chipt_audio",audio_word),("chipt_engine",engine))
        for png in ("chip_video_quality","chip_audio_codec","chip_video_codec","chip_fps","chip_stream","chip_audio","chip_engine"):
            self._set_typographic_chip(png,"",force)
        self._layout_localized_technical_cards(texts,force)
        cache=self._chip_text_cache
        for name,text in texts:
            try:
                widget=self[name]
                if not text:
                    cache.pop(name,None);widget.hide();continue
                if force or cache.get(name)!=text:
                    widget.setText(text)
                    cache[name]=text
                widget.show()
            except Exception as exc:
                optional_failure("player.text_chip_%s"%name,exc)

    def _provider_live_picon_urls(self, item):
        row=item if isinstance(item,dict) else {}
        base=str(row.get("_art_base") or self.item.get("_art_base") or self.item.get("_portal") or "").strip()
        urls=[]
        explicit=str(row.get("_player_picon_url") or "").strip()
        if explicit and explicit.lower() not in ("null","none"):
            norm=_normalize_provider_image_url(explicit)
            if norm.startswith("//"):norm="https:"+norm
            if norm.lower().startswith(("http://","https://")):urls.append(norm)
        try:
            from ..provider_art import picon_urls
            for u in picon_urls(row,{"portal":base}):
                if u and u not in urls:urls.append(u)
        except Exception:pass
        return urls

    def _provider_live_picon_url(self, item):
        """Resolve only provider-owned Live artwork. Never consult TMDb."""
        urls=self._provider_live_picon_urls(item)
        return urls[0] if urls else ""

    def _provider_live_picon_cached(self, item):
        row=item if isinstance(item,dict) else {}
        for key in ("_player_picon","_receiver_picon_local","picon_local","logo_local","image_local"):
            path=str(row.get(key) or "").strip()
            if path and os.path.isfile(path) and os.path.getsize(path)>100:return path
        urls=self._provider_live_picon_urls(row)
        if not urls:return ""
        root=os.path.join(PERSISTENT_CACHE_ROOT,"live_picons")
        for url in urls[:6]:
            digest=hashlib.sha1(url.encode("utf-8","ignore")).hexdigest()
            for ext in (".png",".jpg",".jpeg",".webp"):
                path=os.path.join(root,digest+ext)
                try:
                    if os.path.isfile(path) and os.path.getsize(path)>16:return path
                except OSError:pass
        return ""

    def _provider_live_picon_download(self, item, cancel_event=None):
        """Fetch one provider stream_icon into the existing Live picon cache."""
        cached=self._provider_live_picon_cached(item)
        if cached:return cached
        if cancel_event is not None and cancel_event.is_set():return ""
        url=self._provider_live_picon_url(item)
        if not url:return ""
        parts=urllib.parse.urlsplit(url)
        if parts.scheme.lower() not in ("http","https") or not parts.hostname:return ""
        root=os.path.join(PERSISTENT_CACHE_ROOT,"live_picons")
        try:os.makedirs(root,0o700,exist_ok=True)
        except TypeError:
            try:os.makedirs(root,0o700)
            except OSError:pass
        digest=hashlib.sha1(url.encode("utf-8","ignore")).hexdigest()
        tmp=os.path.join(root,digest+".player.%d.%d"%(os.getpid(),threading.get_ident()))
        headers={"User-Agent":"UltraStalker/10","Accept":"image/png,image/jpeg,image/*,*/*"}
        client=self.item.get("_live_client_ref") if isinstance(self.item,dict) else None
        try:
            if client is not None and hasattr(client,"_request_headers"):
                safe_headers=client._request_headers(browser=True,range_prefix=False) or {}
                for key,value in safe_headers.items():
                    if str(key).lower() not in ("authorization","cookie","x-auth-token","x-access-token"):
                        headers[str(key)]=str(value)
        except Exception:pass
        req=urllib.request.Request(url,headers=headers)
        trusted=[]
        for base in (str((item or {}).get("_art_base") or ""),str(self.item.get("_portal") or "")):
            try:
                parts=urllib.parse.urlsplit(base)
                if parts.scheme.lower() in ("http","https") and parts.hostname:
                    port=parts.port or (443 if parts.scheme.lower()=="https" else 80)
                    host=("[%s]"%parts.hostname) if ":" in parts.hostname and not parts.hostname.startswith("[") else parts.hostname
                    trusted.append("%s://%s:%d"%(parts.scheme.lower(),host,port))
            except Exception:pass
        validate_remote_media_url(url,trusted_private_origins=tuple(trusted))
        opener=build_safe_media_opener(trusted_private_origins=tuple(trusted))
        total=0;head=b""
        try:
            with opener.open(req,timeout=4.5) as response,open(tmp,"wb") as handle:
                while True:
                    if cancel_event is not None and cancel_event.is_set():
                        raise RuntimeError("live picon cancelled")
                    chunk=response.read(64*1024)
                    if not chunk:break
                    if not head:head=chunk[:16]
                    total+=len(chunk)
                    if total>2*1024*1024:raise ValueError("live picon exceeds 2 MB")
                    handle.write(chunk)
            if cancel_event is not None and cancel_event.is_set():raise RuntimeError("live picon cancelled")
            if total<=128:raise ValueError("empty live picon")
            if head.startswith(b"\x89PNG\r\n\x1a\n"):ext=".png"
            elif head.startswith(b"\xff\xd8\xff"):ext=".jpg"
            elif head[:4]==b"RIFF" and head[8:12]==b"WEBP":ext=".webp"
            else:ext=""
            if not ext:
                if _PILImage is None:raise ValueError("unsupported live picon format")
                target=os.path.join(root,digest+".png")
                with _PILImage.open(tmp) as im:
                    im.seek(0);im=im.convert("RGBA" if "A" in im.getbands() else "RGB");im.save(target,"PNG",optimize=False)
                try:os.unlink(tmp)
                except OSError:pass
            else:
                target=os.path.join(root,digest+ext);os.replace(tmp,target)
            if os.path.isfile(target) and os.path.getsize(target)>256:
                try:LOG.info("R68 live_provider_picon_download channel=%r key=%s bytes=%d",str((item or {}).get("name") or ""),digest[:10],int(total))
                except Exception:pass
                return target
            return ""
        except Exception as exc:
            try:
                if os.path.exists(tmp):os.unlink(tmp)
            except OSError:pass
            if cancel_event is None or not cancel_event.is_set():
                optional_failure("player.live_provider_picon_download",exc)
            return ""

    def _request_provider_live_picon(self, item):
        if self.media_type not in ("itv","live") or not isinstance(item,dict):return ""
        local=self._provider_live_picon_cached(item)
        if local:return local
        url=self._provider_live_picon_url(item)
        if not url:return ""
        try:self._live_picon_fetch_cancel.set()
        except Exception:pass
        self._live_picon_fetch_cancel=threading.Event()
        cancel_event=self._live_picon_fetch_cancel
        self._live_picon_fetch_generation+=1
        generation=self._live_picon_fetch_generation
        self._live_picon_fetch_inflight=True
        row=dict(item);result_queue=self._live_picon_fetch_queue
        def worker():
            path=self._provider_live_picon_download(row,cancel_event=cancel_event)
            if cancel_event.is_set():return
            try:result_queue.put((generation,url,path))
            except Exception:pass
        try:
            try:LOG.info("R68 live_provider_picon_request channel=%r key=%s",str(row.get("name") or ""),hashlib.sha1(url.encode("utf-8","ignore")).hexdigest()[:10])
            except Exception:pass
            self._live_picon_fetch_future=LIVE_PICON_EXECUTOR.submit(worker,priority=0)
        except Exception as exc:
            self._live_picon_fetch_inflight=False;optional_failure("player.live_provider_picon_worker",exc)
        return ""

    def _drain_provider_live_picon(self):
        if self.media_type not in ("itv","live"):return
        latest=None
        while True:
            try:latest=self._live_picon_fetch_queue.get_nowait()
            except queue.Empty:break
        if latest is None:return
        generation,url,path=latest
        if generation!=self._live_picon_fetch_generation:return
        self._live_picon_fetch_inflight=False;self._live_picon_fetch_future=None
        if not path or not os.path.isfile(path):return
        current_url=self._provider_live_picon_url(self.item)
        if current_url!=url:return
        self.item["_player_picon"]=path;self.item["_player_picon_url"]=url
        try:
            if 0<=int(getattr(self,"_zap_index",0))<len(getattr(self,"_zap_channels",[]) or []):
                row=(getattr(self,"_zap_channels",[]) or [])[int(self._zap_index)]
                if isinstance(row,dict):row["_player_picon"]=path;row["_player_picon_url"]=url
        except Exception:pass
        try:
            self._load_live_picon(path);self._apply_adaptive_player_chrome()
            try:LOG.info("R68 live_provider_picon_apply channel=%r key=%s",str(self.name or ""),hashlib.sha1(url.encode("utf-8","ignore")).hexdigest()[:10])
            except Exception:pass
        except Exception as exc:optional_failure("player.live_provider_picon_apply",exc)

    def _vod_quality_resolution_sources(self, info=None):
        """Return decoder /proc and current-service dimensions separately.

        KiddaC-style service converters treat /proc/stb/vmpeg as the decoder
        source and service.info() as fallback. Keep the two values separate here
        so a previous title cannot win merely because it has the larger frame.
        """
        try:
            if info is None:
                service=self.session.nav.getCurrentService()
                info=service and service.info()
        except Exception:
            info=None

        def sane(width,height):
            try:
                width=int(width or 0);height=int(height or 0)
            except Exception:
                return (0,0)
            if 160 <= width <= 8192 and 120 <= height <= 4320:
                return (width,height)
            return (0,0)

        proc_pair=sane(self._read_proc_number(("/proc/stb/vmpeg/0/xres",),16) or 0,
                       self._read_proc_number(("/proc/stb/vmpeg/0/yres",),16) or 0)
        info_pair=(0,0)
        if info is not None:
            info_pair=sane(self._info_number(info,"sVideoWidth",0) or 0,
                           self._info_number(info,"sVideoHeight",0) or 0)
        return proc_pair,info_pair

    def _vod_quality_preplay_snapshot(self):
        proc_pair,info_pair=self._vod_quality_resolution_sources()
        if proc_pair!=(0,0) and info_pair!=(0,0) and proc_pair==info_pair:
            return proc_pair
        return proc_pair if proc_pair!=(0,0) else info_pair

    def _reset_vod_quality_probe(self):
        """Erase the previous title's badge and capture its decoder size only as a guard."""
        if self.media_type not in ("vod","series","episode"):
            return
        try:
            timer=getattr(self,"vod_quality_timer",None)
            if timer is not None:timer.stop()
        except Exception:
            pass
        try:pre=self._vod_quality_preplay_snapshot()
        except Exception:pre=(0,0)
        self._vod_quality_probe_generation=int(getattr(self,"_vod_quality_probe_generation",0) or 0)+1
        self._vod_quality_probe_active=False
        self._vod_quality_badge_locked=False
        self._vod_quality_badge_path=""
        self._vod_quality_badge_resolution=(0,0)
        self._vod_quality_probe_preplay=pre
        self._vod_quality_probe_started_at=0.0
        self._vod_quality_probe_size_event=False
        self._vod_quality_probe_size_event_at=0.0
        self._vod_quality_probe_updated_event=False
        self._vod_quality_probe_candidate=(0,0)
        self._vod_quality_probe_candidate_count=0
        self._vod_quality_probe_candidate_since=0.0
        self._observed_quality=""
        self._observed_width=0
        self._observed_height=0
        try:
            if self["vod_quality_badge"].instance is not None:
                self["vod_quality_badge"].instance.setPixmap(None)
            self["vod_quality_badge"].hide()
            self["chip_video_quality"].hide();self["video_quality"].hide()
        except Exception:
            pass

    def _arm_vod_quality_probe(self):
        """Start one short settlement session for the newly-started VOD service."""
        if self.media_type not in ("vod","series","episode"):
            return
        if getattr(self,"_vod_quality_badge_locked",False):
            return
        self._vod_quality_probe_active=True
        self._vod_quality_probe_started_at=time.monotonic()
        self._vod_quality_probe_size_event=False
        self._vod_quality_probe_size_event_at=0.0
        self._vod_quality_probe_updated_event=False
        self._vod_quality_probe_candidate=(0,0)
        self._vod_quality_probe_candidate_count=0
        self._vod_quality_probe_candidate_since=0.0
        try:
            self.vod_quality_timer.stop();self.vod_quality_timer.start(120,True)
        except Exception as exc:
            optional_failure("player.vod_quality_probe_start",exc)

    def _stop_vod_quality_probe(self):
        self._vod_quality_probe_active=False
        try:self.vod_quality_timer.stop()
        except Exception:pass

    def _vod_quality_updated_info_event(self):
        """Record fresh current-service information without doing any continuous work."""
        if self.media_type not in ("vod","series","episode") or not getattr(self,"_vod_quality_probe_active",False):
            return
        try:
            if not self._event_matches_current_reference():return
        except Exception:
            return
        self._vod_quality_probe_updated_event=True
        try:
            self.vod_quality_timer.stop();self.vod_quality_timer.start(60,True)
        except Exception:pass

    def _vod_video_size_changed(self):
        """Debounce decoder-size events for the current service, then let the short probe settle."""
        if self.media_type not in ("vod","series","episode"):
            return
        if not getattr(self,"_vod_quality_probe_active",False):
            return
        try:
            if not self._event_matches_current_reference():return
        except Exception:
            return
        self._vod_quality_probe_size_event=True
        self._vod_quality_probe_size_event_at=time.monotonic()
        try:
            self.vod_quality_timer.stop();self.vod_quality_timer.start(60,True)
        except Exception as exc:
            optional_failure("player.vod_quality_size_event",exc)

    def _reset_vod_audio_probe(self):
        """Clear the old title's audio badge and keep old descriptors only as a handoff guard."""
        try:
            timer=getattr(self,"vod_audio_timer",None)
            if timer is not None:timer.stop()
        except Exception:
            pass
        pre=()
        if self.media_type in ("vod","series","episode"):
            try:
                service=self.session.nav.getCurrentService()
                info=service and service.info()
                pre=self._audio_track_signature(service,info)
            except Exception:
                pre=()
        self._vod_audio_probe_generation=int(getattr(self,"_vod_audio_probe_generation",0) or 0)+1
        self._vod_audio_probe_active=False
        self._vod_audio_badge_locked=False
        self._vod_audio_probe_preplay=tuple(pre or ())
        self._vod_audio_probe_started_at=0.0
        self._vod_audio_probe_updated_event=False
        self._vod_audio_probe_candidate=()
        self._vod_audio_probe_candidate_count=0
        self._vod_audio_probe_candidate_since=0.0
        self._paint_audio_format_badge("")

    def _arm_vod_audio_probe(self):
        """Start one bounded audio-capability request for the newly-started VOD service."""
        if self.media_type not in ("vod","series","episode"):
            return
        if getattr(self,"_vod_audio_badge_locked",False):
            return
        self._vod_audio_probe_active=True
        self._vod_audio_probe_started_at=time.monotonic()
        self._vod_audio_probe_updated_event=False
        self._vod_audio_probe_candidate=()
        self._vod_audio_probe_candidate_count=0
        self._vod_audio_probe_candidate_since=0.0
        try:
            self.vod_audio_timer.stop();self.vod_audio_timer.start(120,True)
        except Exception as exc:
            optional_failure("player.vod_audio_probe_start",exc)

    def _stop_vod_audio_probe(self):
        self._vod_audio_probe_active=False
        try:self.vod_audio_timer.stop()
        except Exception:pass

    def _vod_audio_updated_info_event(self):
        if self.media_type not in ("vod","series","episode") or not getattr(self,"_vod_audio_probe_active",False):
            return
        try:
            if not self._event_matches_current_reference():return
        except Exception:
            return
        self._vod_audio_probe_updated_event=True
        try:
            self.vod_audio_timer.stop();self.vod_audio_timer.start(60,True)
        except Exception:
            pass

    def _lock_vod_audio_badge(self, key):
        if self.media_type not in ("vod","series","episode") or getattr(self,"_vod_audio_badge_locked",False):
            return False
        key=str(key or "").strip().lower()
        if not key or not self._audio_badge_asset(key):
            return False
        self._vod_audio_badge_locked=True
        self._stop_vod_audio_probe()
        return self._paint_audio_format_badge(key)

    def _vod_audio_probe_tick(self):
        """Resolve one audio-format badge at startup, then stop probing for this title."""
        if self.media_type not in ("vod","series","episode"):
            return self._stop_vod_audio_probe()
        if not getattr(self,"_vod_audio_probe_active",False) or getattr(self,"_vod_audio_badge_locked",False):
            return self._stop_vod_audio_probe()
        if self.restored or self._closing_playback or not self.started:
            return self._stop_vod_audio_probe()
        try:
            if not self._event_matches_current_reference():
                self.vod_audio_timer.start(120,True);return
        except Exception:
            self.vod_audio_timer.start(120,True);return

        now=time.monotonic()
        elapsed=max(0.0,now-float(getattr(self,"_vod_audio_probe_started_at",0.0) or 0.0))
        try:
            service=self.session.nav.getCurrentService()
            info=service and service.info()
            signature=self._audio_track_signature(service,info)
        except Exception:
            signature=()

        candidate=tuple(signature or ())
        if candidate:
            if candidate==getattr(self,"_vod_audio_probe_candidate",()):
                self._vod_audio_probe_candidate_count=int(getattr(self,"_vod_audio_probe_candidate_count",0) or 0)+1
            else:
                self._vod_audio_probe_candidate=candidate
                self._vod_audio_probe_candidate_count=1
                self._vod_audio_probe_candidate_since=now
            hits=int(getattr(self,"_vod_audio_probe_candidate_count",0) or 0)
            stable_for=max(0.0,now-float(getattr(self,"_vod_audio_probe_candidate_since",now) or now))
            badge_key=self._audio_signature_badge_key(candidate)
            if badge_key:
                pre=tuple(getattr(self,"_vod_audio_probe_preplay",()) or ())
                if candidate!=pre and hits>=3 and stable_for>=0.20:
                    return self._lock_vod_audio_badge(badge_key)
                if (candidate==pre and getattr(self,"_vod_audio_probe_updated_event",False)
                        and hits>=6 and stable_for>=0.70 and elapsed>=0.90):
                    return self._lock_vod_audio_badge(badge_key)

        if elapsed>=5.0:
            self._paint_audio_format_badge("")
            return self._stop_vod_audio_probe()
        try:self.vod_audio_timer.start(120,True)
        except Exception as exc:
            optional_failure("player.vod_audio_probe_tick",exc);self._stop_vod_audio_probe()

    @staticmethod
    def _vod_quality_choose_transition_pair(proc_pair, info_pair, pre):
        """Choose the new-service frame without letting the old decoder win a handoff."""
        zero=(0,0)
        proc_pair=tuple(proc_pair or zero);info_pair=tuple(info_pair or zero);pre=tuple(pre or zero)
        if proc_pair!=zero and info_pair!=zero:
            if proc_pair==info_pair:
                return proc_pair,"agree"
            # During a service replacement one source commonly updates before the
            # other. If exactly one still equals the pre-play frame, the other one
            # is the fresh title and must win, irrespective of pixel area.
            if proc_pair==pre and info_pair!=pre:
                return info_pair,"info-transition"
            if info_pair==pre and proc_pair!=pre:
                return proc_pair,"proc-transition"
            # Two different non-old values means the decoder is still settling.
            return zero,"disagree"
        return (proc_pair if proc_pair!=zero else info_pair),("single" if (proc_pair!=zero or info_pair!=zero) else "none")

    def _vod_quality_probe_tick(self):
        """Settle one new-title resolution, paint one badge, then stop forever for this playback."""
        if self.media_type not in ("vod","series","episode"):
            return self._stop_vod_quality_probe()
        if not getattr(self,"_vod_quality_probe_active",False) or getattr(self,"_vod_quality_badge_locked",False):
            return self._stop_vod_quality_probe()
        if self.restored or self._closing_playback or not self.started:
            return self._stop_vod_quality_probe()
        try:
            if not self._event_matches_current_reference():
                self.vod_quality_timer.start(120,True);return
        except Exception:
            self.vod_quality_timer.start(120,True);return

        now=time.monotonic()
        elapsed=max(0.0,now-float(getattr(self,"_vod_quality_probe_started_at",0.0) or 0.0))
        try:
            service=self.session.nav.getCurrentService()
            info=service and service.info()
            proc_pair,info_pair=self._vod_quality_resolution_sources(info)
        except Exception:
            proc_pair=info_pair=(0,0)

        pre=tuple(getattr(self,"_vod_quality_probe_preplay",(0,0)) or (0,0))
        pair,source=self._vod_quality_choose_transition_pair(proc_pair,info_pair,pre)
        if pair!=(0,0):
            if pair==getattr(self,"_vod_quality_probe_candidate",(0,0)):
                self._vod_quality_probe_candidate_count=int(getattr(self,"_vod_quality_probe_candidate_count",0) or 0)+1
            else:
                self._vod_quality_probe_candidate=pair
                self._vod_quality_probe_candidate_count=1
                self._vod_quality_probe_candidate_since=now
            hits=int(getattr(self,"_vod_quality_probe_candidate_count",0) or 0)
            stable_for=max(0.0,now-float(getattr(self,"_vod_quality_probe_candidate_since",now) or now))
            changed=(pre==(0,0) or pair!=pre)

            # Different from the old title: this is the clean handoff signal.
            # A few short samples are enough, and both source-order cases work
            # (4K->FHD and FHD->4K) without choosing the larger stale frame.
            if changed and hits>=3 and stable_for>=0.20:
                return self._lock_vod_quality_badge(pair[0],pair[1])

            # Same numeric resolution as the old title is accepted only after a
            # fresh decoder-size event for the NEW service. No polling-only path
            # may latch the previous movie's size. A short debounce lets adaptive
            # starts change again before the badge is committed.
            size_at=float(getattr(self,"_vod_quality_probe_size_event_at",0.0) or 0.0)
            if (not changed and getattr(self,"_vod_quality_probe_size_event",False)
                    and size_at>=float(getattr(self,"_vod_quality_probe_started_at",0.0) or 0.0)
                    and hits>=4 and stable_for>=0.65 and (now-size_at)>=0.55):
                return self._lock_vod_quality_badge(pair[0],pair[1])

            # Some external players omit evVideoSizeChanged when two titles have
            # identical frames. Only then use evUpdatedInfo as a conservative
            # startup fallback, never as an immediate carry-over latch.
            if (not changed and getattr(self,"_vod_quality_probe_updated_event",False)
                    and source=="agree" and hits>=8 and elapsed>=2.20):
                return self._lock_vod_quality_badge(pair[0],pair[1])

            # V9.2.2-r12: ExtePlayer3 may send no size event at all, and a film with the
            # same picture size as the previous one never looked "changed".  Once the
            # picture has really been playing for 3 s with a stable reading, accept it.
            if not changed and hits>=6 and elapsed>=4.0:
                try:
                    _sk=service.seek() if service else None
                    _pp=_sk.getPlayPosition() if _sk is not None else None
                    _pos=int(_pp[1]) if (_pp and int(_pp[0])==0) else 0
                except Exception:
                    _pos=0
                if _pos>=3*90000:
                    return self._lock_vod_quality_badge(pair[0],pair[1])

        # This is a startup-only detector: at most five seconds / ~42 tiny reads,
        # then absolutely no quality polling for the rest of a two-hour movie.
        # V9.2.2-r12: slow starts (black screen, resume seek) can take far longer than 5 s
        # to expose the size, so keep looking for up to 90 s, at a relaxed 500 ms pace after
        # the first 5 s.
        if elapsed>=90.0:
            return self._stop_vod_quality_probe()
        try:self.vod_quality_timer.start(120 if elapsed<5.0 else 500,True)
        except Exception as exc:
            optional_failure("player.vod_quality_probe_tick",exc);self._stop_vod_quality_probe()

    def _vod_quality_badge_asset(self, width, height):
        try:
            width=int(width or 0);height=int(height or 0)
        except Exception:
            width=height=0
        if width>=3200 or height>=1800:name="player_typo_quality_4k_196x46.png"
        elif width>=1700 or height>=1000:name="player_typo_quality_fullhd_196x46.png"
        elif width>=1200 or height>=700:name="player_typo_quality_hd_196x46.png"
        elif width>0 and height>0:name="player_typo_quality_sd_196x46.png"
        else:return ""
        # V9.2.2-r6 removed the engraved quality artwork; the chip is plain text now,
        # so the class is still recorded (the file itself is no longer needed).
        path=_asset(name)
        return path if path and os.path.isfile(path) else name

    def _lock_vod_quality_badge(self, width, height):
        """Paint the Movies/Series quality icon once, then never reclassify it."""
        if self.media_type not in ("vod","series","episode"):
            return False
        if getattr(self,"_vod_quality_badge_locked",False):
            return False
        path=self._vod_quality_badge_asset(width,height)
        if not path:
            return False
        self._vod_quality_badge_path=path
        self._vod_quality_badge_resolution=(int(width or 0),int(height or 0))
        self._vod_quality_badge_locked=True
        if int(width or 0) >= 3000 or int(height or 0) >= 1700:
            quality="4K UHD"
        elif int(width or 0) >= 1700 or int(height or 0) >= 900:
            quality="FHD"
        elif int(width or 0) >= 1200 or int(height or 0) >= 700:
            quality="HD"
        else:
            quality="SD"
        self._observed_quality=quality
        self._observed_width=int(width or 0);self._observed_height=int(height or 0)
        self._stop_vod_quality_probe()
        try:
            if self["vod_quality_badge"].instance is not None:
                try:self["vod_quality_badge"].instance.setPixmap(None)
                except Exception:pass
            self["vod_quality_badge"].hide()
            self["video_quality"].hide()
            self._sync_typographic_technical_row()
        except Exception as exc:
            optional_failure("player.vod_quality_badge",exc)
        return True

    def _update_stream_info(self):
        if getattr(self, "restored", False):
            return
        try:self._recent_live_context_tick()
        except Exception as exc:optional_failure("player.recent_live_context",exc)
        try:self._drain_provider_live_picon()
        except Exception as exc:optional_failure("player.live_provider_picon_drain",exc)
        try:
            service = self.session.nav.getCurrentService()
            info = service and service.info()
            if info:
                if self.media_type in ("vod","series","episode"):
                    # The regular stream-info timer never probes VOD quality. The
                    # startup-only quality session owns that work and dies after
                    # choosing one icon.
                    if getattr(self,"_vod_quality_badge_locked",False):
                        width,height=getattr(self,"_vod_quality_badge_resolution",(0,0))
                        quality=str(getattr(self,"_observed_quality","") or "AUTO")
                    else:
                        width=height=0;quality="AUTO"
                else:
                    proc_width = self._read_proc_number(("/proc/stb/vmpeg/0/xres",), 16) or 0
                    proc_height = self._read_proc_number(("/proc/stb/vmpeg/0/yres",), 16) or 0
                    info_width = self._info_number(info, "sVideoWidth", 0) or 0
                    info_height = self._info_number(info, "sVideoHeight", 0) or 0
                    candidates=[]
                    for cw,ch in ((proc_width,proc_height),(info_width,info_height)):
                        try:cw=int(cw or 0);ch=int(ch or 0)
                        except Exception:continue
                        if 160 <= cw <= 8192 and 120 <= ch <= 4320:candidates.append((cw*ch,cw,ch))
                    if candidates:_area,width,height=max(candidates,key=lambda row:row[0])
                    else:width=height=0
                    if width >= 3200 or height >= 1800:quality="4K UHD"
                    elif width >= 1700 or height >= 1000:quality="FHD"
                    elif width >= 1200 or height >= 700:quality="HD"
                    elif width > 0 and height > 0:quality="SD"
                    else:quality="AUTO"
                    self._observed_quality=quality
                    self._observed_width=int(width or 0);self._observed_height=int(height or 0)
                    if (width or height) and not self._engine_video_confirmed:
                        self._engine_video_confirmed=True;self._video_guard_misses=0
                self._set_stream_info_text("video_quality",quality[:15])
                self._set_stream_info_text("video_codec",self._video_codec_text(info))
                self._set_stream_info_text("audio_codec",self._audio_codec_text(service, info))
                self._sync_typographic_technical_row()
                # VOD owns a short one-shot audio-format request just like its quality
                # request. Live/catch-up follow the existing stream-info cadence.
                if self.media_type not in ("vod","series","episode"):
                    self._update_live_audio_format_badge(service,info)
        except Exception as exc:
            optional_failure("player", exc)
        if self._lb_active():
            try:self._lb_layout_epg()
            except Exception as exc:optional_failure("player.live_bar_tick",exc)
        try:
            self.stream_info_timer.stop()
            interval=1000 if getattr(self,"_player_infobar_visible",True) else 5000
            self.stream_info_timer.start(interval, True)
        except Exception as exc:
            optional_failure("player", exc)
