# -*- coding: utf-8 -*-
"""Diagnostics screen: card layout with status dots (R5.159).

The skin (``DIAGNOSTICS_SKIN`` in ui_skin_templates.py) defines six cards of six
rows.  Every row has a key label ``c<i>r<j>_k``, a value label ``c<i>r<j>_v`` and a
status dot ``c<i>r<j>_d``.  ``_build_cards`` returns plain data so the logic stays
testable without Enigma2.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str, int, OSError, us_func, native_str

from . import _, current_language, language_name
os = _us_env.os
threading = _us_env.threading
time = _us_env.time
import weakref

from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap
from twisted.internet import reactor

from .core.diagnostics import snapshot as diagnostic_snapshot, export_support_bundle
from .core.backup import list_backups
from .persistent_cache import PORTAL_ART as IMAGE_CACHE_DIR, hdd_read_ready
from .storage import load_settings
from .ultra import engine_memory_count
from .version import PLUGIN_VERSION, PLUGIN_REVISION
from .log import optional_failure, LOG_FILE

DIAGNOSTICS_SKIN = ""

_DOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets_fhd")
_DOT_FILES = {
    "ok": "pt_dot_green.png",
    "warn": "pt_dot_amber.png",
    "bad": "pt_dot_red.png",
}

_ROWS_PER_CARD = 6
_RSS_WARN_KB = 350 * 1024
_RSS_BAD_KB = 500 * 1024
_DISK_WARN_PERCENT = 15.0
_AVG_HTTP_WARN_MS = 800.0
_AVG_SEARCH_WARN_MS = 1500.0


def _num(value, default=0.0):
    try:
        return float(value)
    except (TypeError, ValueError):
        return float(default)


def _kb(text):
    """'29196 kB' -> 29196 (0 when unknown)."""
    try:
        return int(str(text or "").split()[0])
    except (ValueError, IndexError):
        return 0


def _host_of(portal):
    text = str(portal or "").strip()
    if not text:
        return ""
    try:
        urlsplit = _us_env.urllib_parse.urlsplit
        host = urlsplit(text if "://" in text else "http://" + text).hostname
        return str(host or text)[:40]
    except Exception:
        return text[:40]


def _size_text(nbytes):
    nbytes = float(nbytes or 0)
    if nbytes >= 1024.0 ** 3:
        return "%.1f GB" % (nbytes / 1024.0 ** 3)
    return "%.0f MB" % (nbytes / 1024.0 ** 2)


def _build_cards(d, profile, cfg, image_files, image_bytes, backups_count, memories, active_threads):
    """Return six cards: (title, [(label, value, status), ...]); status in ok/warn/bad/None."""
    ok_word, missing_word = _("Installed"), _("Missing")
    caps = d.get("runtime_capabilities") or {}
    compat = d.get("python_compatibility") or {}
    db = d.get("database") or {}
    perf = d.get("performance") or {}
    pcache = d.get("persistent_cache") or {}
    disk = pcache.get("disk") or {}
    health = d.get("runtime_health") or {}
    endurance = d.get("endurance") or {}
    profile = profile if isinstance(profile, dict) else {}

    def engine(name):
        return (ok_word, "ok") if caps.get(name) else (missing_word, "warn")

    # ---- card 0: plugin & system
    py_ok = bool(compat.get("supported", True))
    tls_loose = (str(profile.get("tls_mode") or "auto").lower() == "compatible"
                 or bool(profile.get("tls_fallback_accepted", False)))
    card0 = (_("Plugin & system"), [
        (_("Version"), "%s (build R5.%s)" % (PLUGIN_VERSION, PLUGIN_REVISION), None),
        (_("Python"), str(d.get("python") or _("unknown")), "ok" if py_ok else "warn"),
        (_("Python support"), _("Supported") if py_ok else str(compat.get("message") or _("unknown"))[:40], "ok" if py_ok else "warn"),
        (_("Platform"), str(d.get("platform") or _("unknown")).split("-with-")[0][:34], None),
        (_("Active threads"), "%d" % active_threads, None),
        (_("TLS security"), _("Unverified") if tls_loose else _("Verified"), "warn" if tls_loose else "ok"),
    ])

    # ---- card 1: playback engines
    retry_on = bool(cfg.get("smart_recovery", True)) and int(cfg.get("playback_retry_limit",3)) > 0
    s_val, s_st = engine("serviceapp")
    g_val, g_st = engine("gstplayer")
    e_val, e_st = engine("exteplayer3")
    card1 = (_("Playback engines"), [
        ("ServiceApp", s_val, s_st),
        ("gstplayer", g_val, g_st),
        ("exteplayer3", e_val, e_st),
        (_("Playback preference"), str(cfg.get("service_type", 4097)), None),
        (_("Smart recovery"), (_("ON") if retry_on else _("OFF")) + " • " + _("retries %s") % cfg.get("playback_retry_limit", 3), "ok" if retry_on else "warn"),
        (_("Engine memories"), str(memories), None),
    ])

    # ---- card 2: libraries
    libs = []
    for name in ("ssl", "zlib", "ctypes", "hmac", "sqlite3"):
        try:
            __import__(native_str(name))
            libs.append((name, _("OK"), "ok"))
        except Exception:
            libs.append((name, _("Missing"), "bad"))
    db_ok = bool(db.get("ok", True)) and str(db.get("integrity", "ok")).lower() == "ok"
    libs.append((_("Database"), _("Healthy") if db_ok else _("Check failed"), "ok" if db_ok else "bad"))
    card2 = (_("Libraries"), libs)

    # ---- card 3: storage & cache
    free_pct = _num(disk.get("free_percent", 0.0))
    if not disk:
        disk_val, disk_st = _("unknown"), None
    else:
        disk_val = "%s • %.0f%%" % (_size_text(disk.get("free", 0)), free_pct)
        disk_st = "bad" if disk.get("low_space") else ("warn" if free_pct < _DISK_WARN_PERCENT else "ok")
    rss_kb = _kb(health.get("vmrss"))
    if rss_kb:
        proc_val = "%d MB • %s" % (rss_kb // 1024, _("%d threads") % int(_num(health.get("threads"), active_threads)))
        proc_st = "bad" if rss_kb >= _RSS_BAD_KB else ("warn" if rss_kb >= _RSS_WARN_KB else "ok")
    else:
        proc_val, proc_st = _("unknown"), None
    card3 = (_("Storage & cache"), [
        (_("Image cache"), _("%d files / %.1f MB") % (image_files, image_bytes / (1024.0 * 1024.0)), None),
        (_("Artwork use / budget"), "%s / %s" % (_size_text(_num(pcache.get("bytes",0))), _size_text(int(cfg.get("persistent_cache_mb",20480))*1024*1024)), "warn" if _num(pcache.get("bytes",0)) > int(cfg.get("persistent_cache_mb",20480))*1024*1024 else None),
        (_("Disk free"), disk_val, disk_st),
        (_("Saved backups"), "%d" % backups_count, None),
        (_("Cache location"), str(pcache.get("root") or _("unknown"))[:34], None),
        (_("Memory"), proc_val, proc_st),
    ])

    # ---- card 4: network performance
    http = perf.get("http.request_ms") or {}
    reqs = perf.get("http.requests") or {}
    keep = perf.get("http.keepalive_reuse") or {}
    bulk = perf.get("sqlite.bulk_state_ms") or {}
    srch = perf.get("search.total_ms") or {}
    http_avg = http.get("avg_ms")
    srch_avg = srch.get("avg_ms")
    peak_rss = _num(((endurance.get("peak") or {}).get("rss_kb")), 0)
    card4 = (_("Network performance"), [
        (_("HTTP requests"), "%d" % int(_num(reqs.get("count", 0))), None),
        (_("Average response"), ("%s ms" % http_avg) if http_avg not in (None, "") else "-",
         None if http_avg in (None, "") else ("warn" if _num(http_avg) > _AVG_HTTP_WARN_MS else "ok")),
        (_("Keep-alive reuse"), "%d" % int(_num(keep.get("count", 0))), None),
        (_("SQLite page state"), _("%d runs • %s ms") % (int(_num(bulk.get("count", 0))), bulk.get("avg_ms", "-")), None),
        (_("Search"), _("%d runs • %s ms") % (int(_num(srch.get("count", 0))), srch_avg if srch_avg not in (None, "") else "-"),
         None if srch_avg in (None, "") else ("warn" if _num(srch_avg) > _AVG_SEARCH_WARN_MS else "ok")),
        (_("Peak memory"), ("%d MB" % int(peak_rss // 1024)) if peak_rss else "-", None),
    ])

    # ---- card 5: selected portal
    host = _host_of(profile.get("portal"))
    last_ok = profile.get("last_success")
    last_err = str(profile.get("last_error") or "").strip()
    try:
        last_ok_text = time.strftime("%Y-%m-%d %H:%M", time.localtime(int(last_ok))) if last_ok else _("Never")
    except Exception:
        last_ok_text = _("Never")
    card5 = (_("Selected portal"), [
        (_("Portal"), host or _("None"), ("ok" if host else None)),
        (_("Last success"), last_ok_text, None),
        (_("Last error"), last_err[:34] if last_err else _("None"), "warn" if last_err else "ok"),
        (_("Channel list mode"), str(cfg.get("channel_list_mode", "epg")), None),
        (_("Clean titles"), _("ON") if cfg.get("clean_titles", True) else _("OFF"), "ok" if cfg.get("clean_titles", True) else None),
        (_("Language"), str(language_name(current_language())), None),
    ])
    cards = [card0, card1, card2, card3, card4, card5]
    for _title, rows in cards:
        while len(rows) < _ROWS_PER_CARD:
            rows.append(("", "", None))
    return cards


class DiagnosticsScreen(Screen):
    skin = DIAGNOSTICS_SKIN

    def __init__(self, session, profile=None):
        us_func(Screen.__init__)(self, session)
        self.profile = profile
        self["title"] = Label(_("Diagnostics"))
        self["subtitle"] = Label(_("System health • Plugin • Playback • Storage • Network"))
        self["status"] = Label(_("GREEN: refresh  •  YELLOW: support bundle  •  BLUE: log path"))
        self["green"] = Label(_("Refresh"))
        self["yellow"] = Label(_("Support bundle"))
        self["blue"] = Label(_("Log path"))
        for ci in range(6):
            self["c%d_title" % ci] = Label("")
            for ri in range(_ROWS_PER_CARD):
                self["c%dr%d_k" % (ci, ri)] = Label("")
                self["c%dr%d_v" % (ci, ri)] = Label("")
                self["c%dr%d_d" % (ci, ri)] = Pixmap()
        self["actions"] = ActionMap(
            ["OkCancelActions", "ColorActions"],
            {"cancel": self._close_screen, "green": self.refresh, "yellow": self.export_report, "blue": self.show_log_path},
            -1,
        )
        self["background"] = Pixmap()
        self._diag_closed = False
        self._diag_generation = 0
        self._diag_busy = False
        self._export_busy = False
        self.onClose.append(self._mark_closed)
        self.onLayoutFinish.append(self._paint_background)
        self.onLayoutFinish.append(self.refresh)

    def _paint_background(self):
        # Same shared bundled background used by Settings and the browser pages.
        try:
            inst = self["background"].instance
            path = os.path.join(_DOT_DIR, "ultra_bg_clean_1920x1080.png")
            if inst is not None and os.path.isfile(path):
                inst.setPixmapFromFile(path)
        except Exception as exc:
            optional_failure("diagnostics.background", exc)

    def _set_dot(self, ci, ri, status):
        widget = self["c%dr%d_d" % (ci, ri)]
        try:
            if status in _DOT_FILES:
                widget.instance.setPixmapFromFile(os.path.join(_DOT_DIR, _DOT_FILES[status]))
                widget.show()
            else:
                widget.hide()
        except Exception as exc:
            optional_failure("ui.diag_dot", exc)

    def _mark_closed(self):
        self._diag_closed = True
        self._diag_generation += 1

    def _close_screen(self):
        self._mark_closed()
        self.close()

    @staticmethod
    def _collect(profile):
        """Blocking scans (cache tree, backups, HDD listing). Runs in a worker thread, never in a GUI callback."""
        try:
            d = diagnostic_snapshot(profile)
        except Exception as exc:
            d = {"error": str(exc)}
        files = 0
        size = 0
        try:
            if hdd_read_ready(force=True):
                for n in os.listdir(IMAGE_CACHE_DIR):
                    p = os.path.join(IMAGE_CACHE_DIR, n)
                    if os.path.isfile(p):
                        files += 1
                        size += os.path.getsize(p)
        except Exception as exc:
            optional_failure("ui", exc)
        try:
            backups = len(list_backups())
        except Exception as exc:
            optional_failure("ui.diag_backups", exc)
            backups = 0
        try:
            memories = engine_memory_count()
        except Exception as exc:
            optional_failure("ui.diag_memories", exc)
            memories = 0
        return d, files, size, backups, memories, threading.active_count()

    def refresh(self):
        if self._diag_closed or self._diag_busy:
            return
        self._diag_busy = True
        self._diag_generation += 1
        generation = self._diag_generation
        profile = self.profile
        settings = load_settings() or {}
        ref = weakref.ref(self)
        try:
            self["status"].setText(_("Collecting diagnostics..."))
        except Exception as exc:
            optional_failure("ui.diag_status", exc)

        def work():
            try:
                data = DiagnosticsScreen._collect(profile)
            except Exception as exc:
                data = ({"error": str(exc)}, 0, 0, 0, 0, threading.active_count())
            owner = ref()
            if owner is None:
                return
            try:
                reactor.callFromThread(owner._apply_refresh, generation, data, settings)
            except Exception as exc:
                optional_failure("ui.diag_deliver", exc)

        try:
            threading.Thread(target=work, name="us-diagnostics", daemon=True).start()
        except Exception as exc:
            self._diag_busy = False
            optional_failure("ui.diag_thread", exc)

    def _apply_refresh(self, generation, data, settings):
        self._diag_busy = False
        if self._diag_closed or generation != self._diag_generation:
            return
        d, files, size, backups, memories, threads = data
        cards = _build_cards(d, self.profile, settings, files, size, backups, memories, threads)
        for ci, (title, rows) in enumerate(cards):
            self["c%d_title" % ci].setText(str(title).upper())
            for ri, (label, value, status) in enumerate(rows):
                self["c%dr%d_k" % (ci, ri)].setText(str(label))
                self["c%dr%d_v" % (ci, ri)].setText(str(value))
                self._set_dot(ci, ri, status)
        self["status"].setText(_("Diagnostics refreshed at %s") % time.strftime("%H:%M:%S") + "  •  " + _("Log: %s") % LOG_FILE)

    def show_log_path(self):
        try:
            size = os.path.getsize(LOG_FILE)
            self["status"].setText(_("Log: %s") % LOG_FILE + "  •  %.0f KB" % (size / 1024.0))
        except OSError:
            self["status"].setText(_("Log: %s") % LOG_FILE + "  •  " + _("not created yet"))

    def export_report(self):
        if self._diag_closed or self._export_busy:
            return
        self._export_busy = True
        profile = self.profile
        ref = weakref.ref(self)
        self["status"].setText(_("Building support bundle..."))

        def work():
            try:
                result = (export_support_bundle('/tmp/ultrastalker-support.zip', profile), None)
            except Exception as exc:
                result = (None, exc)
            owner = ref()
            if owner is None:
                return
            try:
                reactor.callFromThread(owner._apply_export, result)
            except Exception as exc:
                optional_failure("ui.diag_export_deliver", exc)

        try:
            threading.Thread(target=work, name="us-diagnostics-export", daemon=True).start()
        except Exception as exc:
            self._export_busy = False
            self["status"].setText(_("Export failed: %s") % exc)

    def _apply_export(self, result):
        self._export_busy = False
        if self._diag_closed:
            return
        path, error = result
        if error is not None:
            self["status"].setText(_("Export failed: %s") % error)
        else:
            self["status"].setText(_("Exported: %s") % path)

# R5.245: plugin-owned front-panel identity.
try:
    from .frontpanel_plugin import bind_plugin_front_summary as _bind_plugin_front_summary
    _bind_plugin_front_summary(DiagnosticsScreen)
except Exception:
    pass

