"""Spotlight material for the native Live drawer's existing pixmap slots.

Geometry is a nine-slice of Poster Grid 3's actual panel. Its alpha corners,
hairline rim and grey material stay authoritative for both Fixed and Adaptive.
Only colour changes for adaptive mode and for the selected-row rim.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import int, round, zip, map, max, min
from PIL import Image, ImageChops, ImageFilter

# Pillow < 9.1 has no Image.Resampling; keep older receiver images working.
_LANCZOS = getattr(getattr(Image, 'Resampling', Image), 'LANCZOS', 1)


def build_surface(source, size, selected=False, accent=None, hot=None):
    with Image.open(source) as im:
        src = im.convert('RGBA')
    w, h = map(int, size)
    sw, sh = src.size
    sc = min(24, sw // 2 - 1, sh // 2 - 1)
    dc = min(sc, w // 2 - 1, h // 2 - 1)
    out = Image.new('RGBA', (w, h))
    # Source and destination corner sizes are independent. Short pills scale
    # the complete source corner, rather than cutting it off halfway through.
    xs = ((0, sc, 0, dc), (sc, sw-sc, dc, w-dc), (sw-sc, sw, w-dc, w))
    ys = ((0, sc, 0, dc), (sc, sh-sc, dc, h-dc), (sh-sc, sh, h-dc, h))
    for a, b, x, z in xs:
        for c, d, y, t in ys:
            patch = src.crop((a, c, b, d))
            if patch.size != (z-x, t-y):
                patch = patch.resize((z-x, t-y), _LANCZOS)
            out.paste(patch, (x, y))
    alpha = out.getchannel('A')
    if h < 100:
        # A full-size panel's top 24px must not turn into half a short row's
        # fill. Preserve its complete soft material gradient inside the rim.
        strip = src.crop((sw//2, 5, sw//2+1, sh-5)).convert('RGB')
        material = strip.resize((1, h), _LANCZOS).resize((w, h))
        rim = ImageChops.subtract(alpha, alpha.filter(ImageFilter.MinFilter(5)))
        rgb = Image.composite(out.convert('RGB'), material, rim)
        out = rgb.convert('RGBA'); out.putalpha(alpha)
    if accent is not None:
        # Gentle colour in the original dark material; alpha/rim geometry is
        # unchanged and never replaced by a second glass/focus surface.
        tint = Image.new('RGB', out.size, tuple(map(int, accent)))
        rgb = Image.blend(out.convert('RGB'), tint, 0.06)
        out = rgb.convert('RGBA'); out.putalpha(alpha)
    if selected:
        top = tuple(accent or (100, 207, 157))
        bottom = tuple(hot or (215, 77, 102))
        rim = ImageChops.subtract(alpha, alpha.filter(ImageFilter.MinFilter(5)))
        line = Image.new('RGB', (1, h))
        line.putdata(list(tuple(round(a+(b-a)*y/max(1,h-1)) for a,b in zip(top,bottom)) for y in range(h)))
        colour = line.resize(out.size)
        rgb = Image.composite(colour, out.convert('RGB'), rim)
        out = rgb.convert('RGBA'); out.putalpha(alpha)
    return out
