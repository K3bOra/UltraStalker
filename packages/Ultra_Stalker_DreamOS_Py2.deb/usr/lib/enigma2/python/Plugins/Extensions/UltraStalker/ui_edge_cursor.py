# -*- coding: utf-8 -*-
"""Load bundled Premium cursors; all rendering happens during package construction."""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
os = _us_env.os
_PKG = os.path.dirname(os.path.abspath(__file__))

def poster_cursor_asset(name):
    """Bundled poster cursor path for one of POSTER_CURSORS; '' when unknown/missing."""
    try:
        path = os.path.join(_PKG, "assets_fhd", name)
        return path if os.path.isfile(path) else ""
    except Exception:
        return ""
