# -*- coding: utf-8 -*-
"""Genre/root rows, selection changes and D-pad navigation.

Methods moved verbatim out of ``PortalBrowserScreen`` (ui_screens_browser.py); behaviour is unchanged.
This module is imported by ui_screens_browser.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, max, min
from .ui_screens_browser import (
    LOG,
    _,
    _mem34,
    _provider_display_raw,
    _visibility_category_id,
    time,
)


class BrowserNavigationMixin(object):
    """Genre/root rows, selection changes and D-pad navigation."""

    def _render_genre_rows(self):
        if self.level != "genres":
            return
        _r51_t0=time.monotonic()
        chrome = self._category_chrome or self._load_category_chrome()
        try:
            selected = self["list"].getSelectedIndex()
        except Exception:
            selected = 0
        cfg = load_settings()
        rows = []
        # R51: the folder asset is identical for every category row.  Resolving
        # asset() inside the loop caused one filesystem existence probe per row
        # (911 probes on a large Live portal) before Enigma2 could paint anything.
        # Resolve it once and reuse the stable receiver-local path.
        _category_folder_icon=asset("us89_folder_yellow_42.png")
        _cat_max = 1320 if str(getattr(self, "media_type", "") or "").lower() in ("itv", "vod", "series") else 860
        card_w=max(426,min(_cat_max,int(getattr(self,"_category_row_card_w",426) or 426)))
        title_font=int(getattr(self,"_category_title_font",0) or 0)
        selected_title_font=int(getattr(self,"_category_selected_title_font",10) or 10)
        selected_ids=set(getattr(self,"_category_selected_ids",set()) or set()) if getattr(self,"_category_select_mode",False) else set()
        _glass=self._category_glass_wanted()
        for i, e in enumerate(self.content_items):
            title = self._category_display_title(e, cfg)
            gid=_visibility_category_id(e)
            if _glass:
                details = self._category_glass_details(e, i == selected, bool(gid and gid in selected_ids))
            else:
                details = {
                    "selected": i == selected,
                    "checked": bool(gid and gid in selected_ids),
                    "row_asset": chrome.get("row"),
                    "row_selected_asset": chrome.get("row_selected"),
                    "card_w": card_w,
                    "title_font": title_font,
                    "selected_title_font": selected_title_font,
                }
            # Folder identity is stable on first paint and during selection. The
            # check mark lives in its own fixed right-side column.
            rows.append((title, _category_folder_icon, e, details))
        self["list"].set_icon_rows(rows)
        try:
            self["list"].moveToIndex(max(0, min(selected, len(rows) - 1)))
        except Exception as exc:
            optional_failure("ui.silent_guard",exc)
        _mem34("browser_genres_rendered", media=str(getattr(self,"media_type","") or ""), rows=len(rows))
        try:
            LOG.info("PERF51 category_rows media=%s rows=%d elapsed_ms=%d",str(getattr(self,"media_type","") or ""),len(rows),int((time.monotonic()-_r51_t0)*1000))
        except Exception:
            pass

    def _set_root_rows(self):
        try:self._restore_browser_geometry()
        except Exception as exc:optional_failure("ui.silent_guard",exc)
        self._set_list_density("root")
        cfg=load_settings(); self.active_modes=[]
        enabled={"itv":cfg.get("show_live",True),"vod":cfg.get("show_movies",True),"series":cfg.get("show_series",True),"catchup":cfg.get("show_catchup",True)}
        for mode in self.ALL_MODES:
            if mode[1] not in enabled or enabled[mode[1]]: self.active_modes.append(mode)
        self.MODES=tuple(self.active_modes)
        rows=[]
        fav_count, recent_count = self._root_counts()
        health = self.client.health_snapshot() if getattr(self.client, "token", None) else {"health":"ready","latency_ms":0}
        descriptions={"itv":"Professional channel list with lazy Now / Next EPG","vod":"Movies with artwork, details, favorites and watched state","series":"Series, seasons, episodes and resume support","catchup":"Archived programmes and replay TV","favorites":_("Your saved content  •  Items: %d") % fav_count,"recent":_("Continue watching  •  Items: %d") % recent_count,"account":"Subscription and portal health details","search":"One search across Live, Movies and Series","settings":"Themes, lists, Smart Engine, privacy and cache"}
        for title,key,icon in self.MODES: rows.append((_(title),asset(icon),key,_(descriptions[key])))
        self["blue"].setText(_("Open / Play"))
        self["list"].set_icon_rows(rows); self["counter"].setText(_("PORTAL HOME  •  Sections: %d") % len(rows))
        try:self["list"].moveToIndex(0)
        except Exception as exc:optional_failure("ui",exc)

    def _selection_changed(self):
        try: idx=self["list"].getSelectedIndex()
        except Exception: return
        if self.level in ("catchup_channels","catchup_programs"):
            try:self._catchup_selection_changed(idx)
            except Exception as exc:optional_failure("ui.catchup_selection",exc)
            return
        if self.level == "root" and 0 <= idx < len(self.MODES):
            title,key,_icon=self.MODES[idx]
            self["info_title"].setText(_(title))
            self["info"].setText(_("Press OK to browse %s") % _(title))
            ph={"itv":"us80_section_live_530x382.png","vod":"us80_section_movies_530x382.png","series":"us80_section_series_530x382.png","favorites":"us81_section_favorites_530x382.png","recent":"us80_section_movies_530x382.png","settings":"us81_section_settings_530x382.png","search":"us81_section_search_530x382.png","catchup":"us81_section_catchup_530x382.png","account":"us81_section_settings_530x382.png"}.get(key,"us81_section_settings_530x382.png")
            # Root art is local and authoritative for this focus. Cancel any
            # provider-art request left behind by the previous content row.
            self._image_supersede()
            self._decode_picture(asset(ph))
        elif 0 <= idx < len(self.content_items):
            item=self.content_items[idx]
            if self.level == "genres":
                try:self._restore_category_side_identity()
                except Exception as exc:optional_failure("ui.category_identity_selection",exc)
                try:
                    chrome=self._category_chrome or self._load_category_chrome()
                    cfg=self._selection_settings();_cat_max=1320 if str(getattr(self,"media_type","") or "").lower() in ("itv","vod","series") else 860;card_w=max(426,min(_cat_max,int(getattr(self,"_category_row_card_w",426) or 426)));title_font=int(getattr(self,"_category_title_font",0) or 0);selected_title_font=int(getattr(self,"_category_selected_title_font",10) or 10)
                    _glass=self._category_glass_wanted()
                    for j in set((idx, getattr(self,"_genre_last_idx",idx))):
                        if 0 <= j < len(self.content_items):
                            e=self.content_items[j];title=self._category_display_title(e,cfg)
                            gid=_visibility_category_id(e)
                            _checked=bool(getattr(self,"_category_select_mode",False) and gid in set(getattr(self,"_category_selected_ids",set()) or set()))
                            if _glass:details=self._category_glass_details(e,j==idx,_checked)
                            else:details={"selected":j==idx,"checked":_checked,"row_asset":chrome.get("row"),"row_selected_asset":chrome.get("row_selected"),"card_w":card_w,"title_font":title_font,"selected_title_font":selected_title_font}
                            self["list"].update_icon_row(j,(title,asset("us89_folder_yellow_42.png"),e,details))
                    # update_icon_row() invalidates only the old/new selected
                    # entries. A full list invalidate here repaints every category
                    # on each arrow press and defeats the incremental renderer.
                    self._genre_last_idx=idx
                    if _glass:self._category_glass_selection(idx)
                except Exception as exc: optional_failure("ui.category_selection",exc)
                # Categories intentionally show no provider preview; invalidate a
                # late item-art worker from the page we just left.
                try:self._image_supersede()
                except Exception as exc:optional_failure("ui.category_preview_supersede",exc)
                return
            if self.level == "favorites_live":
                try:
                    old=int(getattr(self,"_favorite_live_last_idx",idx) or idx)
                    entries=list(getattr(self,"_favorite_card_entries",[]) or [])
                    for j in set((old,idx)):
                        if 0<=j<len(entries):
                            e=entries[j];row_item=dict(e.get("item") or {});row_item["_saved_media_type"]="itv"
                            title=self._favorite_clean_title("itv",row_item,120)
                            self["list"].update_icon_row(j,(title,self._favorite_live_icon(row_item),row_item,{"selected":j==idx}))
                    self._favorite_live_last_idx=idx
                except Exception as exc:optional_failure("ui.favorite_live_selection",exc)
                return
            _clean_titles=bool(self._selection_settings().get("clean_titles",True))
            raw_title=_provider_display_raw(item,_clean_titles,item.get("id") or _("Result"))
            title=(_clean_display_text(item.get("title") or item.get("name") or item.get("category_name") or item.get("genre_name") or item.get("id") or _("Categories"),100) or _("Categories")) if self.level=="genres" else (premium_title(raw_title,True) if _clean_titles else str(raw_title).strip())
            self["info_title"].setText(title[:34])
            if self.media_type=="itv" and self.level=="items": self._schedule_epg_preview(item)
            if self.level == "genres":
                try:self["accent_frame"].hide()
                except Exception as exc:optional_failure("ui.silent_guard",exc)
                self["info"].setText(_("Category folder"))
                section_icon = {
                    "itv": "us80_section_live_530x382.png",
                    "vod": "us80_section_movies_530x382.png",
                    "series": "us80_section_series_530x382.png",
                }.get(self.media_type, "us81_placeholder_movies_480x345.png")
                self._decode_picture(asset(section_icon))
            else:
                if self._utility_mode_active():
                    try:
                        if self["accent_frame"].instance is not None:
                            self["accent_frame"].instance.setPixmap(None)
                        self["accent_frame"].hide()
                    except Exception as exc:optional_failure("ui.silent_guard",exc)
                else:
                    self._set_accent(title, poster=(self.media_type in ("vod","series") and self.level=="items"))
                meta=[]
                for k in ("year","number","rating","genre"):
                    if item.get(k): meta.append(str(item.get(k)))
                self["info"].setText("  •  ".join(meta)[:58] or self._mode_name(self.media_type))
                if self._utility_mode_active():
                    try:self["preview"].hide()
                    except Exception:pass
                else:
                    ph=(_letter_placeholder(title) if self.media_type=="itv" else ("us81_placeholder_movies_480x345.png" if self.media_type=="vod" else "us81_placeholder_series_480x345.png"))
                    self._load_item_image(item if (self.media_type=="itv" or (isinstance(item,dict) and item.get("_xtream"))) else _strip_portal_artwork(item),ph)

    def _set_accent(self, value, poster=False):
        name = _accent_for(value)
        filename = "accent_poster_%s.png" % name if poster else "accent_logo_%s.png" % name
        try:
            self["accent_frame"].instance.setPixmapFromFile(asset(filename))
            self["accent_frame"].show()
        except Exception as exc: optional_failure("ui",exc)

    def _nav_up(self):
        if getattr(self,"_category_menu_active",False):return self._category_menu_overlay.move("up")
        if self.level=="favorites_cards":return self._favorite_focus_tabs()
        if self.level=="favorites_root":return
        return self["list"].wrap_up()

    def _nav_down(self):
        if getattr(self,"_category_menu_active",False):return self._category_menu_overlay.move("down")
        if self.level=="favorites_root":return self._favorite_enter_tab()
        if self.level=="favorites_cards":return
        return self["list"].wrap_down()

    def _nav_left(self):
        if getattr(self,"_category_menu_active",False):return self._category_menu_overlay.move("left")
        if self.level=="favorites_root":return self._favorite_root_move(-1)
        if self.level=="favorites_cards":
            return self._favorite_reorder_step(-1) if getattr(self,"_favorite_reorder_active",False) else self._favorite_move(-1)
        return self["list"].page_left()

    def _nav_right(self):
        if getattr(self,"_category_menu_active",False):return self._category_menu_overlay.move("right")
        if self.level=="favorites_root":return self._favorite_root_move(1)
        if self.level=="favorites_cards":
            return self._favorite_reorder_step(1) if getattr(self,"_favorite_reorder_active",False) else self._favorite_move(1)
        return self["list"].page_right()
