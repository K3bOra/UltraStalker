# -*- coding: utf-8 -*-
"""Record application and visual scheduling and job draining.

Methods moved verbatim out of ``PremiumGlobalCinematicScreen`` (ui_cinematic_global.py); behaviour is unchanged.
This module is imported by ui_cinematic_global.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int
from .ui_cinematic_global import _, _age_rating_display, _build_dynamic_details_chrome, _build_dynamic_settings_episode_rows, _clean_person_name, _country_code, _normalized_country, _strip_arabic_tashkeel, accent_hex, adaptive_enabled, canonical_dynamic_details_key, canonical_dynamic_rows_key, hashlib, optional_failure, os, queue, re, threading, weakref

class CineApplyMixin(object):
    """Record application and visual scheduling and job draining."""

    def _cin_apply_record(self, item, row, allow_build=False, hold_missing=False):
        """Paint Details metadata without ever blanking a field mid-navigation.

        ``hold_missing`` is used by the arrow/fast-info lane.  Any value already
        visible remains resident until the new title supplies that field.  Once
        the authoritative Details snapshot is ready, normal painting may clear a
        field that TMDb genuinely does not provide.
        """
        row = dict(row or {})
        new_key = self._record_key(row, item)
        identity_changed = bool(new_key and new_key != self._cin_record_key)
        self._cin_last_record = row
        self._cin_record_key = new_key
        provisional = str(row.get('_details_provider_backdrop_local') or '')
        sig = self._page_visual_key(item)
        canonical = str(row.get('backdrop_local') or '')
        clean_locked = bool(sig and str(getattr(self, '_fast_bd_locked_sig', '') or '') == str(sig))
        if provisional and (not (canonical and os.path.isfile(canonical))) and (not clean_locked):
            try:
                if os.path.isfile(provisional) and self['cin_backdrop'].instance is not None:
                    self['cin_backdrop'].instance.setPixmapFromFile(provisional)
                    self['cin_backdrop'].show()
                    self._cin_pixmap_paths['cin_backdrop'] = provisional
            except Exception as exc:
                optional_failure('cinematic.provider_backdrop_fallback', exc)
        if identity_changed:
            pass

        def _set_text(name, value, fit=None):
            text = str(value or '')
            if text or not hold_missing:
                try:
                    widget = self[name]
                    current = str(widget.getText() or '')
                    if current == text:
                        return False
                    widget.setText(text)
                except Exception:
                    return False
                if fit:
                    try:
                        fit(text)
                    except Exception:
                        pass
                return True
            return False
        title = self._rail_title(item, row) or str(row.get('title') or row.get('name') or '')
        display_title = title[:120]
        self._cin_show_title_logo(item, row)
        _set_text('name', display_title, lambda text: self._cin_fit_single_line_font('name', text, 38, 9))
        try:
            self['cin_list'].update_icon_row(self.index, self._cin_list_row(self.index, selected=True, record=row))
        except Exception:
            pass
        genres = row.get('genres') or row.get('genre') or []
        if isinstance(genres, str):
            genres = [genres]
        genre_names = []
        for value in genres[:3]:
            if isinstance(value, dict):
                value = value.get('name') or ''
            value = str(value or '').strip()
            if value:
                genre_names.append(value)
        genre_value = ' / '.join(genre_names)[:78]
        _set_text('genre_text', genre_value, lambda text: self._cin_fit_single_line_font('genre_text', text, 25, 12))
        age_value = _age_rating_display(row.get('certification') or row.get('age_rating'))
        _set_text('age_rating_text', age_value)
        cast = row.get('cast') or row.get('actors') or []
        if isinstance(cast, str):
            cast = [x.strip() for x in re.split('[,،|]', cast) if x.strip()]
        names = []
        for actor in cast[:8]:
            if isinstance(actor, dict):
                actor = actor.get('name') or actor.get('original_name') or ''
            actor = _clean_person_name(actor)
            if actor and actor not in names:
                names.append(actor)
            if len(names) >= 6:
                break
        cast_value = ', '.join(names)[:220]
        _set_text('cast_text', cast_value, lambda text: self._cin_fit_single_line_font('cast_text', text, 18, 11))
        details_overview = ''
        details_overview_ready = False
        _authority_failed = False
        try:
            from .details_authority import details_overview
            details_overview, details_overview_ready = details_overview(self.profile, self.media_type, item, row)
        except Exception as exc:
            _authority_failed = True
            optional_failure('cinematic.details_overview_authority', exc)
        overview = str(row.get('overview') or '' if _authority_failed else details_overview or '').strip()
        overview_value = _strip_arabic_tashkeel(overview[:1800])
        if _set_text('description', overview_value):
            try:
                self._cin_fit_description_font()
            except Exception:
                pass
        try:
            _quality_state = (getattr(self, '_grid_item_state', {}) or {}).get(id(item), {}) or {}
            q = str(_quality_state.get('quality') or '').strip()
        except Exception:
            q = ''
        q = q or _('AUTO')
        year = str(row.get('year') or '')
        if self.media_type == 'series':
            seasons = row.get('number_of_seasons') or 0
            try:
                seasons = int(seasons or 0)
            except Exception:
                seasons = 0
            runtime = _('%d season') % seasons if seasons == 1 else _('%d seasons') % seasons if seasons > 1 else ''
        else:
            runtime_value = row.get('runtime')
            try:
                runtime_value = int(float(runtime_value or 0))
            except Exception:
                runtime_value = 0
            runtime = _('%s min') % runtime_value if runtime_value else ''
        _set_text('year_text', year[:8], lambda text: self._cin_fit_compact_text('year_text', text, max_size=22, min_size=10, padding=4))
        if runtime or not hold_missing:
            _set_text('runtime_text', runtime[:14])
            if self.media_type == 'series':
                try:
                    self._cin_fit_runtime_like_details()
                except Exception:
                    pass
            else:
                try:
                    self._cin_fit_compact_text('runtime_text', runtime[:14], max_size=24, min_size=15, padding=2)
                except Exception:
                    pass
        for name in ('quality_logo', 'quality_text'):
            try:
                self[name].hide()
            except Exception:
                pass
        runtime_shell = str((getattr(self, '_cin_last_chrome', {}) or {}).get('runtime') or '')
        if not (runtime_shell and os.path.isfile(runtime_shell)):
            runtime_shell = str((self._cin_fixed_master_chrome() or {}).get('runtime') or '')
        if runtime:
            if runtime_shell:
                self._set_native_pixmap('runtime_pill_bg', runtime_shell)
            self._set_native_pixmap('runtime_icon', 'metadata_icons_premium/seasons_32.png' if self.media_type == 'series' else 'metadata_icons_premium/duration_32.png')
        elif not hold_missing:
            try:
                self['runtime_icon'].hide()
            except Exception:
                pass
            if runtime_shell:
                self._set_native_pixmap('runtime_pill_bg', runtime_shell)
        countries = row.get('countries') or row.get('country') or []
        raw_country = countries[0] if isinstance(countries, (list, tuple)) and countries else countries
        code = _country_code(raw_country)
        country_value = _normalized_country(raw_country)
        if country_value or not hold_missing:
            _set_text('country_text', country_value, lambda text: self._cin_fit_compact_text('country_text', text, max_size=20, min_size=8, padding=6))
            self._set_native_pixmap('country_flag', 'flags_iso/%s.png' % code.lower() if code else None)
        if allow_build and row:
            self._cin_schedule_visuals(item, row)

    def _cin_schedule_visuals(self, item, row):
        """Prepare adaptive material for the latest settled Cinematic title only.

        Stage 9 fixes two independent stalls from the old lane:
        1) visual work was not part of the poll heartbeat, so a completed result
           could sit in ``_cin_jobs`` until some unrelated later action woke it;
        2) queued/running work had no selection generation, so an old title could
           occupy the single image lane while the user had already moved on.

        Work is now generation-owned and cooperatively cancellable between the
        row and Details-chrome phases.  Last-good adaptive surfaces remain on the
        GUI until the current generation has both complete halves ready.
        """
        if not adaptive_enabled():
            return None
        row = dict(row or {})
        key = self._record_key(row, item)
        if not key:
            return None
        generation = int(self._cin_set_adaptive_target(item) or 0)
        target_sig = str(getattr(self, '_cin_adaptive_target_sig', '') or '')
        if not target_sig:
            return None
        token = '%d|%s' % (generation, key)
        if token in self._cin_pending:
            return None
        source = self._cin_adaptive_source_for(item, row)
        if not source:
            return False
        self._cin_pending.add(token)
        index = int(self.index)
        backdrop = str(row.get('backdrop_local') or '')
        accent = str(accent_hex(row.get('adaptive_accent') or row.get('adaptive_primary') or '#c99141'))
        fingerprint = str(row.get('adaptive_fingerprint') or '')
        if not fingerprint and source and os.path.isfile(source):
            try:
                _st = os.stat(source)
                fingerprint = '%s:%s' % (int(_st.st_mtime), int(_st.st_size))
            except Exception:
                fingerprint = ''
        source_sig = '%s|%s' % (source, fingerprint)
        cancel_event = getattr(self, '_cin_adaptive_cancel', None)
        if cancel_event is None:
            cancel_event = threading.Event()
            self._cin_adaptive_cancel = cancel_event
        owner_ref = weakref.ref(self)
        item_snapshot = dict(item or {}) if isinstance(item, dict) else item
        profile = self.profile
        media_type = self.media_type

        def stale():
            owner = owner_ref()
            if owner is None or cancel_event.is_set():
                return True
            try:
                if owner._screen_closed:
                    return True
                if int(getattr(owner, '_cin_adaptive_generation', 0) or 0) != generation:
                    return True
                if str(getattr(owner, '_cin_adaptive_target_sig', '') or '') != target_sig:
                    return True
            except Exception:
                return True
            return False

        def chrome_ready(chrome):
            chrome = chrome if isinstance(chrome, dict) else {}
            required = ('panel_detail', 'overview_detail', 'cast_detail', 'quality', 'year', 'runtime', 'country', 'genre_detail')
            try:
                return all((str(chrome.get(name) or '') and os.path.isfile(str(chrome.get(name) or '')) for name in required))
            except Exception:
                return False

        def worker():
            if stale():
                return False
            result = {'kind': 'adaptive_visual', 'key': key, 'pending_token': token, 'index': index, 'row': row, 'backdrop': '', 'chrome': {}, 'settings_rows': {}, 'adaptive_generation': generation, 'target_sig': target_sig, 'source_sig': source_sig}
            try:
                if stale():
                    return False
                if stale():
                    return False
                if source and os.path.isfile(source):
                    settings_key = canonical_dynamic_rows_key(source, selected_rim_only=True, cinematic_premium=False) or 'cin232_adaptive_rows_%s_%s' % (key, hashlib.sha1((source + fingerprint).encode('utf-8', 'ignore')).hexdigest()[:14])
                    result['settings_rows'] = _build_dynamic_settings_episode_rows(source, settings_key, selected_rim_only=True, cinematic_premium=False) or {}
                    if stale():
                        return False
                    if True:
                        chrome_key = canonical_dynamic_details_key(source) or 'cin534_focus_%s_%s' % (key, hashlib.sha1((source + fingerprint).encode('utf-8', 'ignore')).hexdigest()[:14])
                        result['chrome'] = _build_dynamic_details_chrome(source, chrome_key, only=('panel_detail', 'overview_detail', 'cast_detail', 'quality', 'year', 'runtime', 'country', 'genre_detail')) or {}
                        result['chrome_partial'] = True
                if stale():
                    return False
            except Exception as exc:
                optional_failure('cinematic.visual_worker', exc)
                if stale():
                    return False
            self._cin_jobs.put(result)
            return True
        try:
            future = getattr(self, '_cin_visual_executor', _GRID_ACCENT_EXECUTOR).submit(worker, priority=0, _task_key='cin-visual:%x' % id(self), _replace_task_key=True)
            self._cin_visual_future = future

            def completed(done, pending_token=token, ref=owner_ref):
                owner = ref()
                if owner is None:
                    return
                queued = False
                try:
                    queued = not done.cancelled() and bool(done.result())
                except Exception:
                    queued = False
                if not queued:
                    try:
                        owner._cin_pending.discard(pending_token)
                    except Exception:
                        pass
                try:
                    if getattr(owner, '_cin_visual_future', None) is done:
                        owner._cin_visual_future = None
                except Exception:
                    pass
            future.add_done_callback(completed)
            self._cin_kick_poll()
        except Exception as exc:
            self._cin_pending.discard(token)
            self._cin_visual_future = None
            optional_failure('cinematic.visual_submit', exc)

    def _cin_drain_jobs(self):
        _budget = 6
        while _budget > 0:
            try:
                r = self._cin_jobs.get_nowait()
            except queue.Empty:
                break
            except Exception:
                break
            _budget -= 1
            kind = str(r.get('kind') or '')
            if kind == 'hidden_done':
                continue
            if kind == 'fast_backdrop_meta':
                sig = str(r.get('sig') or '')
                self._fast_bd_meta_pending.discard(sig)
                if sig == str(getattr(self, '_fast_bd_meta_latest_sig', '') or ''):
                    self._fast_bd_meta_latest_sig = ''
                if self._screen_closed or not self.grid_items or sig != self._fast_bd_current_sig():
                    continue
                current = self.grid_items[self.index]
                canonical = self._cin_page_records.get(int(self.index), {}) or self._record(current) or {}
                resolved = r.get('row') if isinstance(r.get('row'), dict) else {}
                keys = ('tmdb_id', 'media_type', 'backdrop_local', 'backdrop_url', '_backdrop_url', 'tmdb_backdrop_url', 'backdrop_path', 'clean_backdrop_choice', 'clean_backdrop_iso', 'clean_backdrop_selector_version', 'identity_verified')
                candidate = dict(canonical)
                for key in keys:
                    value = resolved.get(key)
                    if value not in (None, '', [], {}):
                        candidate[key] = value
                try:
                    self._fast_bd_schedule(current, candidate)
                except Exception as exc:
                    optional_failure('cinematic.r199_direct_backdrop_meta', exc)
                continue
            if kind == 'title_logo':
                sig = str(r.get('sig') or '')
                self._cin_logo_pending.discard(sig)
                if self._screen_closed or not self.grid_items:
                    continue
                current = self.grid_items[self.index]
                row = self._record(current) or {}
                current_sig, _unused = self._cin_title_logo_signature(current, row)
                if sig != current_sig:
                    continue
                path = str(r.get('path') or '')
                try:
                    if path and os.path.isfile(path) and (self['title_logo'].instance is not None):
                        self['title_logo'].instance.setPixmapFromFile(path)
                        self._cin_logo_path = path
                        self['title_logo'].show()
                    elif bool(r.get('missing')):
                        self['title_logo'].hide()
                        self._cin_logo_path = ''
                    else:
                        held = str(getattr(self, '_cin_logo_path', '') or '')
                        if held and os.path.isfile(held) and (os.path.getsize(held) > 256):
                            self['title_logo'].show()
                        else:
                            self['title_logo'].hide()
                            self._cin_logo_path = ''
                except Exception as exc:
                    optional_failure('cinematic.title_logo_apply', exc)
                continue
            if kind == 'fast_info':
                self._cin_fast_info_future = None
                self._cin_fast_info_cancel = None
                self._cin_fast_info_sig = ''
                if self._screen_closed or not self.grid_items:
                    continue
                current = self.grid_items[self.index]
                sig = self._page_visual_key(current)
                if str(r.get('sig') or '') != sig:
                    continue
                row = r.get('row') if isinstance(r.get('row'), dict) else {}
                if row:
                    try:
                        self._cin_page_records[int(self.index)] = dict(row)
                    except Exception:
                        pass
                    try:
                        from .details_authority import metadata_language_ready
                        ready = metadata_language_ready(row, self._grid_settings or {})
                    except Exception:
                        ready = bool(row.get('_details_authority_ready'))
                    try:
                        self._cin_apply_record(current, row, allow_build=False, hold_missing=not ready)
                    except TypeError:
                        self._cin_apply_record(current, row, allow_build=False)
                    except Exception as exc:
                        optional_failure('cinematic.fast_info_apply', exc)
                continue
            if kind == 'focus':
                if self._screen_closed or not self.grid_items:
                    continue
                current = self.grid_items[self.index]
                sig = self._page_visual_key(current)
                if str(r.get('sig') or '') != sig:
                    continue
                row = r.get('row') if isinstance(r.get('row'), dict) else self._record(current) or {}
                package = r.get('package') if isinstance(r.get('package'), dict) else {}
                try:
                    self._cin_page_records[int(self.index)] = dict(row)
                except Exception:
                    pass
                try:
                    poster = str(row.get('poster_local') or '')
                    backdrop = str(row.get('backdrop_local') or '')
                    if poster and os.path.isfile(poster):
                        current['_cin_provider_poster_local'] = poster
                        current['_ultra_palette_source'] = poster
                        current['_ultra_poster_source'] = poster
                        current['_player_poster'] = poster
                        current['_adaptive_source_local'] = poster
                        self._grid_palette_sources[self.index] = poster
                    if backdrop and os.path.isfile(backdrop):
                        current['_cin_provider_backdrop_local'] = backdrop
                        current['_backdrop_source_local'] = backdrop
                except Exception as exc:
                    optional_failure('cinematic.focus_handoff', exc)
                try:
                    from .details_authority import metadata_language_ready
                    _focus_info_ready = metadata_language_ready(row, self._grid_settings or {})
                except Exception:
                    _focus_info_ready = bool(row.get('_details_authority_ready'))
                self._cin_apply_record(current, row, allow_build=False, hold_missing=not _focus_info_ready)
                adaptive_committed = False
                if package:
                    try:
                        self._cin_page_packages[int(self.index)] = dict(package)
                    except Exception:
                        pass
                    adaptive_committed = bool(self._cin_apply_package(current, row, package))
                if not adaptive_committed:
                    try:
                        self._cin_schedule_visuals(current, row)
                    except Exception as exc:
                        optional_failure('cinematic.atomic_focus_adaptive_schedule', exc)
                if getattr(self, '_fast_bd_enabled', False):
                    try:
                        self._fast_bd_schedule(current, row)
                    except Exception as exc:
                        optional_failure('cinematic.r199_focus_backdrop_rebind', exc)
                continue
            if kind == 'adaptive_visual':
                pending_token = str(r.get('pending_token') or '')
                if pending_token:
                    self._cin_pending.discard(pending_token)
                if self._screen_closed or not self.grid_items:
                    continue
                generation = int(r.get('adaptive_generation') or -1)
                target_sig = str(r.get('target_sig') or '')
                if generation != int(getattr(self, '_cin_adaptive_generation', 0) or 0):
                    continue
                if target_sig != str(getattr(self, '_cin_adaptive_target_sig', '') or ''):
                    continue
                item = self.grid_items[self.index]
                try:
                    current_sig = str(self._page_visual_key(item) or '')
                except Exception:
                    current_sig = ''
                if not target_sig or target_sig != current_sig:
                    continue
                row = self._cin_page_records.get(int(self.index), {}) or self._record(item) or {}
                key = self._record_key(row, item)
                if str(r.get('key') or '') != key:
                    continue
                current_source = self._cin_adaptive_source_for(item, row)
                current_fp = str((row or {}).get('adaptive_fingerprint') or '')
                if not current_fp and current_source and os.path.isfile(current_source):
                    try:
                        _st = os.stat(current_source)
                        current_fp = '%s:%s' % (int(_st.st_mtime), int(_st.st_size))
                    except Exception:
                        current_fp = ''
                current_source_sig = '%s|%s' % (current_source, current_fp)
                if str(r.get('source_sig') or '') != current_source_sig:
                    try:
                        self._cin_schedule_visuals(item, row)
                    except Exception as exc:
                        optional_failure('cinematic.adaptive_source_refresh', exc)
                    continue
                settings_rows = r.get('settings_rows') if isinstance(r.get('settings_rows'), dict) else {}
                chrome = r.get('chrome') if isinstance(r.get('chrome'), dict) else {}
                if chrome and (not r.get('chrome_partial')):
                    try:
                        poster = str((row or {}).get('poster_local') or '')
                        if poster and os.path.isfile(poster):
                            _save_visual_bundle(self.profile, self.media_type, item, {'poster': poster, 'chrome': chrome}, snapshot=row)
                    except Exception as exc:
                        optional_failure('cinematic.adaptive_bundle_repair_save', exc)
                try:
                    committed = self._cin_commit_adaptive_presentation(item, row, settings_rows, chrome, str((row or {}).get('adaptive_accent') or (row or {}).get('adaptive_primary') or ''))
                    if committed:
                        self._cin_apply_record(item, row, allow_build=False, hold_missing=True)
                except Exception as exc:
                    optional_failure('cinematic.atomic_visual_apply', exc)
                continue
            self._cin_pending.discard(str(r.get('key') or ''))
            if self._screen_closed or not self.grid_items:
                continue
            item = self.grid_items[self.index]
            row = self._record(item)
            key = self._record_key(row, item)
            if str(r.get('key') or '') != key:
                continue
            settings_rows = r.get('settings_rows') if isinstance(r.get('settings_rows'), dict) else {}
            chrome = r.get('chrome') if isinstance(r.get('chrome'), dict) else {}
            if chrome and (not r.get('chrome_partial')):
                try:
                    poster = str((row or {}).get('poster_local') or '')
                    if poster and os.path.isfile(poster):
                        _save_visual_bundle(self.profile, self.media_type, item, {'poster': poster, 'chrome': chrome}, snapshot=row)
                except Exception as exc:
                    optional_failure('cinematic.adaptive_bundle_repair_save', exc)
            try:
                committed = self._cin_commit_adaptive_presentation(item, row, settings_rows, chrome, str((row or {}).get('adaptive_accent') or (row or {}).get('adaptive_primary') or ''))
                if committed:
                    self._cin_apply_record(item, row, allow_build=False, hold_missing=True)
            except Exception as exc:
                optional_failure('cinematic.atomic_visual_apply', exc)
