# -*- coding: utf-8 -*-
"""Shared bounded worker lanes for Ultra Stalker UI background work.

Performance step 3: keep the existing jobs and callbacks intact, but cap the
number of simultaneously-created worker threads across screens.  The pools are
lazy, so importing this module does not start any threads.

The lanes are deliberately split by work type so a slow provider/catalogue
request cannot monopolise the same workers used for visible artwork.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .executor import LazyThreadPoolExecutor, PriorityLazyExecutor

# Best-effort page publication runs only after first paint. Keep its disk
# writes independent from visible catalogue, poster and metadata worker lanes.
PAGE_MAINTENANCE_EXECUTOR = PriorityLazyExecutor(max_workers=1,max_pending=4,thread_name_prefix='ultrastalker-page-maintenance')

# Live logos must never queue behind movie backdrops, poster transforms or EPG.
LIVE_PICON_EXECUTOR = PriorityLazyExecutor(max_workers=4,max_pending=64,thread_name_prefix='ultrastalker-picon')
LIVE_PICON_RENDER_EXECUTOR = PriorityLazyExecutor(max_workers=2,max_pending=64,thread_name_prefix='ultrastalker-picon-fit')

# Visible artwork can involve provider/TMDB HTTP plus file decode/write.  Four
# workers is the old single-pool ceiling already used by provider first-paint,
# now shared by Grid + Search instead of each screen owning more workers.
VISIBLE_ARTWORK_EXECUTOR = LazyThreadPoolExecutor(
    max_workers=2, thread_name_prefix="ultrastalker-artwork"
)

# R231: provider catalogue posters are the low-latency first-paint hedge for
# visible VOD/Series cards. Keep these HTTP reads independent from the canonical
# TMDb/ArtworkV2 lane above: a slow provider CDN must not block TMDb fallback,
# and a slow TMDb match must not leave provider-backed cards as placeholders.
VISIBLE_PROVIDER_ARTWORK_EXECUTOR = LazyThreadPoolExecutor(
    max_workers=3, thread_name_prefix="ultrastalker-provider-poster"
)

# Explicit poster caching has its own bounded network lane. It never fills
# the visible-page queue; heavy Pillow decoding still uses the image budget.
POSTER_CACHE_EXECUTOR = PriorityLazyExecutor(max_workers=4, max_pending=8, thread_name_prefix="ultrastalker-poster-cache")


def iter_poster_cache_results(rows, process, cancel_event=None):
    """Rolling four-title window; publish fast completions before slow ones."""
    from .executor import queue
    iterator=iter(rows)
    pending={}
    completed=queue.Queue()
    def stopped():return bool(cancel_event is not None and cancel_event.is_set())
    def submit_one():
        if stopped():return False
        try:pair=next(iterator)
        except StopIteration:return False
        future=POSTER_CACHE_EXECUTOR.submit(process,pair[0],pair[1],priority=4,_queue_block=True,_queue_timeout=1.0)
        pending[future]=pair
        future.add_done_callback(completed.put)
        return True
    try:
        for unused in range(4):
            if not submit_one():break
        while pending and not stopped():
            try:future=completed.get(timeout=0.25)
            except queue.Empty:continue
            pair=pending.pop(future,None)
            if pair is None:continue
            try:result=future.result()
            except Exception:result=(False,"","")
            yield pair,result
            submit_one()
    finally:
        for future in pending:
            try:future.cancel()
            except Exception:pass


# Catalogue/page warming is intentionally small.  Two workers preserve the old
# ability for a hierarchy/category request and a page warm to overlap, while
# preventing several screens from each creating their own one-worker pool.
CATALOGUE_EXECUTOR = LazyThreadPoolExecutor(
    max_workers=1, thread_name_prefix="ultrastalker-catalogue"
)

# Visible card metadata/EPG/TMDB lookups. Six workers allow 14-card and 27-card
# poster grids to hydrate ratings and age certifications rapidly in parallel.
METADATA_EXECUTOR = PriorityLazyExecutor(
    max_workers=2, max_pending=128, thread_name_prefix="ultrastalker-metadata"
)

# Local navigation/storage probes must not queue behind poster cache batches.
LOCAL_STORAGE_EXECUTOR = LazyThreadPoolExecutor(
    max_workers=2, thread_name_prefix="ultrastalker-local-storage"
)

# Read-mostly local cache jobs (poster HDD batches / picon cache).  Keep these
# off the image-generation lane and cap them globally.
CACHE_IO_EXECUTOR = LazyThreadPoolExecutor(
    max_workers=1, thread_name_prefix="ultrastalker-cacheio"
)

_SHARED = (
    PAGE_MAINTENANCE_EXECUTOR,
    LIVE_PICON_EXECUTOR,
    LIVE_PICON_RENDER_EXECUTOR,
    VISIBLE_ARTWORK_EXECUTOR,
    POSTER_CACHE_EXECUTOR,
    VISIBLE_PROVIDER_ARTWORK_EXECUTOR,
    CATALOGUE_EXECUTOR,
    METADATA_EXECUTOR,
    CACHE_IO_EXECUTOR,
    LOCAL_STORAGE_EXECUTOR,
)


def shutdown_shared_executors(wait=False):
    """Stop all shared lanes once during plugin/runtime shutdown."""
    for executor in _SHARED:
        try:
            executor.shutdown(wait=bool(wait), cancel_futures=True)
        except TypeError:
            executor.shutdown(wait=bool(wait))
