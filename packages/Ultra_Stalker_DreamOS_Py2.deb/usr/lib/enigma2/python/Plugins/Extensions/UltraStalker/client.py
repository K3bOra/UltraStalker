# -*- coding: utf-8 -*-
"""Native Stalker/MAG protocol client used by Ultra Stalker.

The UI, storage and plugin namespace are Ultra Stalker.  This client keeps
only the protocol behaviours needed for portal compatibility: endpoint
selection, MAG handshake/profile, category/content retrieval, series expansion
and stream-link resolution.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str, bytes, int, max, min

import gzip
import zlib
hashlib = _us_env.hashlib
http = _us_env.http
http = _us_env.http
http = _us_env.http
json = _us_env.json
import random
re = _us_env.re
socket = _us_env.socket
ssl = _us_env.ssl
import string
threading = _us_env.threading
time = _us_env.time
urllib = _us_env.urllib
urllib = _us_env.urllib
urllib = _us_env.urllib
ThreadPoolExecutor = _us_env.concurrent_futures.ThreadPoolExecutor
OrderedDict = _us_env.collections.OrderedDict
from datetime import datetime

from .core.cache import CACHE, CachePolicy
from .core.perf import PERF
from .repositories.database import DB
from .core.errors import (
    PortalConnectionError, PortalAuthenticationError, PortalRateLimitError,
    PortalResponseError, PlaybackLinkError,
)
from .log import get_logger
from .netsec import validate_http_url
from .portal_compat import (
    EMULATOR_USER_AGENT, MAX_FRONTEND_BYTES, compatibility_state_key,
    compatible_identity, endpoint_log_label, extract_declared_endpoints,
    frontend_candidates, portal_roots, same_origin,
)

LOG = get_logger()


class PortalError(PortalConnectionError):
    """Backward-compatible protocol error base."""
    code = "PORTAL"


class PortalAuthError(PortalError, PortalAuthenticationError):
    code = "PORTAL_AUTH"


class PortalThrottleError(PortalError, PortalRateLimitError):
    code = "PORTAL_RATE_LIMIT"


class PortalDataError(PortalError, PortalResponseError):
    code = "PORTAL_RESPONSE"


class PortalLinkError(PortalError, PlaybackLinkError):
    code = "PLAYBACK_LINK"


class PortalSecurityConsentError(PortalError):
    code = "PORTAL_SECURITY_CONSENT"


class PortalCancelledError(PortalError):
    code = "PORTAL_CANCELLED"


def _bounded_gzip_decompress(payload, limit):
    """Incrementally inflate gzip data without ever allocating beyond ``limit``."""
    limit = max(1, int(limit))
    inflater = zlib.decompressobj(16 + zlib.MAX_WBITS)
    out = bytearray()
    try:
        for offset in range(0, len(payload), 64 * 1024):
            chunk = payload[offset:offset + 64 * 1024]
            remaining = limit + 1 - len(out)
            if remaining <= 0:
                raise PortalDataError("Expanded portal response is too large")
            out.extend(inflater.decompress(chunk, remaining))
            if len(out) > limit or inflater.unconsumed_tail:
                raise PortalDataError("Expanded portal response is too large")
        remaining = limit + 1 - len(out)
        out.extend(inflater.flush(max(0, remaining)))
        if len(out) > limit:
            raise PortalDataError("Expanded portal response is too large")
        return bytes(out)
    except PortalDataError:
        raise
    except zlib.error as exc:
        raise PortalDataError("Portal returned invalid gzip data: %s" % exc)


# Split: related method groups live in client_mixin_*.py modules. They are imported here, after every module-level helper above exists,
# and listed BEFORE the other bases so they override them exactly like the methods that used to sit in this class body.
from .client_mixin_tls import ClientTlsMixin
from .client_mixin_content import ClientContentMixin
from .client_mixin_endpoints import ClientEndpointsMixin
from .client_mixin_resilience import ClientResilienceMixin
from .client_mixin_http import ClientHttpMixin
from .client_mixin_auth import ClientAuthMixin
from .client_mixin_catalogue import ClientCatalogueMixin
from .client_mixin_epg import ClientEpgMixin
from .client_mixin_series import ClientSeriesMixin
from .client_mixin_links import ClientLinksMixin
from .client_mixin_catchup import ClientCatchupMixin


class StalkerClient(
    ClientTlsMixin,
    ClientContentMixin,
    ClientEndpointsMixin,
    ClientResilienceMixin,
    ClientHttpMixin,
    ClientAuthMixin,
    ClientCatalogueMixin,
    ClientEpgMixin,
    ClientSeriesMixin,
    ClientLinksMixin,
    ClientCatchupMixin,
):
    MAX_RESPONSE_BYTES = 16 * 1024 * 1024
    RETRY_CODES = (408, 429, 500, 502, 503, 504)
    RETRY_DELAYS = (0.35, 0.8)
    CIRCUIT_FAILURE_LIMIT = 5
    CIRCUIT_COOLDOWN = 60
    _circuit_state = {}
    _latency_state = {}

    _PLAYABLE_SCHEMES = ("http", "https", "rtmp", "rtsp", "udp", "rtp")
    MAX_CATALOG_PAGES = 250
    MAX_CATALOG_ITEMS = 25000
    SEARCH_CACHE_TTL = 90
    TLS_MODES = ("auto", "strict", "compatible")
    DEVICE_PROFILES = {
        "mag250": {
            "model": "MAG250", "x_user_agent": "Model: MAG250; Link: WiFi",
            "user_agent": "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG250 stbapp ver: 2 rev: 250 Safari/533.3",
            "ver": "ImageDescription: 0.2.18-r23-250; PORTAL version: 5.3.0; API Version: JS API version: 343; STB API version: 146; Player Engine version: 0x58c",
            "image_version": "218", "hw_version": "1.7-BD-00", "api_signature": "262",
        },
        "mag254": {
            "model": "MAG254", "x_user_agent": "Model: MAG254; Link: Ethernet",
            "user_agent": "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG254 stbapp ver: 4 rev: 272 Safari/533.3",
            "ver": "ImageDescription: 0.2.18-r23-254; PORTAL version: 5.3.0; API Version: JS API version: 343; STB API version: 146; Player Engine version: 0x58c",
            "image_version": "218", "hw_version": "2.6-IB-00", "api_signature": "262",
        },
        "mag256": {
            "model": "MAG256", "x_user_agent": "Model: MAG256; Link: Ethernet",
            "user_agent": "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/537.4 (KHTML, like Gecko) MAG256 stbapp Safari/537.4",
            "ver": "ImageDescription: 2.20.03-256; PORTAL version: 5.3.0; API Version: JS API version: 343; STB API version: 146",
            "image_version": "220", "hw_version": "1.0-BD-00", "api_signature": "263",
        },
    }

    def __init__(self, portal, mac, timeout=10, allow_http_fallback=False, tls_mode="auto", device_profile="auto",
                 allow_tls_fallback=False, http_fallback_accepted=False):
        self.entry_url = self._normalize_entry_url(portal)
        # HARDENED BUILD: never downgrade an HTTPS portal to HTTP and never
        # disable certificate verification, even when an old profile still
        # contains previously-approved compatibility flags. Explicit http://
        # portal URLs remain explicit user configuration; there is no fallback.
        self.http_fallback_available = False
        self.http_fallback_accepted = False
        self.allow_http_fallback = False
        self.allow_tls_fallback = False
        self.mac = self._normalize_mac(mac)
        self.timeout = max(3, min(int(timeout or 10), 30))
        self.security_warning = ""
        self.used_http_fallback = False
        self.used_unverified_tls = False
        # HARDENED BUILD: verified TLS only. "strict" is forced so stale
        # compatible/auto-fallback settings cannot re-enable unverified TLS.
        self.tls_mode = "strict"
        self.device_profile = str(device_profile or "auto").strip().lower()
        if self.device_profile not in tuple(self.DEVICE_PROFILES) + ("auto",):
            self.device_profile = "auto"
        self.resolved_device_profile = None

        self.host, self.path_prefix, self.referer = self._split_entry(self.entry_url)
        self._state_host = self.host
        self._state_entry_url = self.entry_url
        self.portal = self.host
        self.endpoint = None
        self.token = None
        self.token_random = ""
        self.play_token = ""
        self.profile_initialized = False
        self.account_valid = False
        # Live link policy learned from the authenticated portal profile/catalogue.
        # Keep it session-local; no credentials or stream URLs are persisted here.
        self._live_force_link_check = False

        self.cookies = http.cookiejar.CookieJar()
        self.opener = self._build_opener(verified=True)
        self._transport_local = threading.local()
        self._transport_lock = threading.RLock()
        # Playback/auth coordination is deliberately separate from transport IO.
        # A user Play action must not race a background metadata worker that is
        # refreshing the shared MAG token, and it must not inherit a temporary
        # background circuit pause.  RLock keeps nested authorize/reset calls safe.
        self._auth_lock = threading.RLock()
        self._priority_local = threading.local()
        self._transport_connections = {}
        self._transport_generation = 0
        self._server_cookies = {}
        self._server_cookie_lock = threading.RLock()
        # Compatible TLS cannot authenticate a self-signed/invalid certificate.
        # Pin the first certificate seen for each origin for this client session
        # so a later connection cannot silently switch certificates mid-session.
        self._compatible_tls_pins = {}
        self._persisted_compatible_tls_pins = {}
        # Stable series hierarchy cache. Some Stalker portals intermittently
        # return only a suffix/subset of seasons for the same movie_id.
        self._series_hierarchy_lock = threading.RLock()
        self._series_hierarchy_memory = {}; self._series_hierarchy_memory_at={}
        self._timezone = self._local_timezone()
        self._persisted_endpoint = None
        self._persisted_device_profile = None
        self._compat_state = {}
        self._compat_cached_endpoint = ""
        self._compat_cached_method = ""
        self._compat_cached_profile_variant = ""
        self._compat_cached_ua_variant = ""
        self._compat_use_emulator_ua = False
        self._compat_mac_override = ""
        self._compat_discovery_attempted = False
        self._compat_discovered_candidates = []
        self._compat_endpoint_methods = {}
        self._load_transport_state()
        self._load_compat_state()
        self._content_cache_generation = self._load_content_cache_generation()


    _TLS_CONTEXT_CACHE = {}

    @staticmethod
    def _tls_context(verified=True):
        if verified:
            cached = StalkerClient._TLS_CONTEXT_CACHE.get("ctx")
            if cached is not None:
                return cached
            context = ssl.create_default_context()
        else:
            # HARDENED BUILD: callers are not permitted to request an
            # unauthenticated TLS context. Fail closed instead.
            raise PortalSecurityConsentError("Unverified TLS is disabled in this hardened build")
        try:
            if hasattr(ssl, "TLSVersion"):
                context.minimum_version = ssl.TLSVersion.TLSv1_2
        except (AttributeError, ValueError):
            pass
        try:
            context.options |= getattr(ssl, "OP_NO_COMPRESSION", 0)
        except (AttributeError, TypeError):
            pass
        # R5.163: configured once and shared (never mutated after this point).
        StalkerClient._TLS_CONTEXT_CACHE["ctx"] = context
        return context


    _AUTH_MARKERS = ("authorization failed", "not valid token", "token expired")

    @staticmethod
    def _series_row_identity(row, index=0):
        """Return a stable identity for a season/episode row."""
        if not isinstance(row, dict):
            return ("invalid", index)
        episode = row.get("episode_id") or row.get("episode")
        season = row.get("season") or row.get("season_number")
        sid = row.get("season_id")
        rid = row.get("id")
        if episode not in (None, ""):
            return ("episode", str(season or sid or ""), str(episode), str(rid or ""))
        number = StalkerClient._season_number(row, "")
        if number not in (None, ""):
            return ("season", str(number))
        if sid not in (None, ""):
            return ("season_id", str(sid))
        if rid not in (None, ""):
            return ("id", str(rid))
        return ("row", str(row.get("name") or row.get("title") or ""), index)
