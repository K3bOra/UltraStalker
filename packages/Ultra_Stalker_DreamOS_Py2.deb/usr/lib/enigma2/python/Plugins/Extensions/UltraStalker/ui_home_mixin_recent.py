# -*- coding: utf-8 -*-
"""Recent/continue-watching cards.

Methods moved verbatim out of ``PortalHomeScreen`` (ui_screens_home.py); behaviour is unchanged.
This module is imported by ui_screens_home.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, round, max, min, us_casefold
from .ui_screens_home import (
    NovaSettingsScreen,
    PERSISTENT_GENERATED_DIR,
    PortalBrowserScreen,
    _,
    _IMAGE_EXECUTOR,
    _cached_recently_played,
    _clean_display_text,
    _fit_live_picon_canvas,
    _home_cached_art,
    asset,
    ePoint,
    eSize,
    getDesktop,
    history_revision,
    load_profiles,
    optional_failure,
    os,
    premium_title,
    re,
    splash_home_is_warm,
    splash_home_recent_assets,
)


class HomeRecentMixin(object):
    """Recent/continue-watching cards."""

    def open_settings(self):self.session.open(NovaSettingsScreen,self.profile,self.client)

    def open_account(self):self.session.open(PortalBrowserScreen,self.profile,"account",self.client,self._current_category_adaptive_source())

    @staticmethod
    def _recent_profile_key(profile):
        profile=profile if isinstance(profile,dict) else {}
        return (str(profile.get("portal") or "").rstrip("/").lower(),str(profile.get("mac") or "").upper())

    def _recent_visible_on_this_home(self,entry,item):
        """Show Recent/Continue rows owned by this exact portal only.

        Federated Search and in-player server handoff may play a copy from another
        configured source, but that source owns its own history/artwork.  Never
        surface a foreign Portal/Xtream row on the current Home merely because
        playback was launched while this Home happened to be open.
        """
        current=self._recent_profile_key(self.profile)
        source=(str((entry or {}).get("portal") or "").rstrip("/").lower(),str((entry or {}).get("mac") or "").upper())
        return bool(source==current)

    def _recent_source_profile(self,entry):
        """Resolve the actual history source without persisting credentials."""
        source=(str((entry or {}).get("portal") or "").rstrip("/").lower(),str((entry or {}).get("mac") or "").upper())
        if source==self._recent_profile_key(self.profile):return self.profile
        try:
            for row in load_profiles() or []:
                if self._recent_profile_key(row)==source:return row
        except Exception as exc:
            optional_failure("ui.home_recent_source_profile",exc)
        return None

    @staticmethod
    def _recent_series_identity(item,mtype):
        """Return one stable *show* identity for Home Recent-Series de-duplication.

        Episode history is intentionally keyed per episode for resume.  Home is
        different: its three Series slots represent three shows, so seasons and
        episodes from the same parent series must collapse to the newest row.
        Prefer an explicit series TMDb id, then the provider parent-series id,
        and use a normalized parent title only when the source exposes no ids.
        """
        item=item if isinstance(item,dict) else {}
        mt=str(mtype or "").lower()
        tmdb_keys=("_series_tmdb_id","series_tmdb_id","tv_tmdb_id")
        if mt=="series":tmdb_keys=tmdb_keys+("_locked_tmdb_id","tmdb_id")
        for key in tmdb_keys:
            value=item.get(key)
            if value not in (None,""):return "tmdb:%s"%str(value).strip()
        provider_keys=("_series_id","series_id","series_uid","parent_id","series") if mt=="episode" else ("series_id","id","series_uid","_series_id")
        for key in provider_keys:
            value=item.get(key)
            if value not in (None,""):return "provider:%s"%str(value).strip()
        if mt=="episode":raw=item.get("_series_title") or item.get("series_title") or item.get("series_name") or ""
        else:raw=item.get("original_name") or item.get("original_title") or item.get("name") or item.get("title") or ""
        title=re.sub(r"[^\w\u0600-\u06ff]+"," ",us_casefold(str(raw or "")),flags=re.UNICODE)
        title=re.sub(r"\s+"," ",title).strip()
        return "title:%s"%title if title else ""

    def _continue_for_this_portal(self):
        """Return three Live, three Movie and three *different-show* Series rows.

        The history query is already newest-first.  For Series we therefore
        keep the first row for each show identity, which naturally means the
        latest season/episode progress wins.  Home remains a pure local
        SQLite/cache consumer: no portal, TMDb or artwork network work happens
        here.
        """
        portal=str(self.profile.get("portal") or "").rstrip("/").lower();mac=str(self.profile.get("mac") or "").upper()
        groups=[[],[],[]];seen_series=set()
        try: recent=_cached_recently_played()
        except Exception: recent=[]
        for entry in recent:
            if not isinstance(entry,dict):continue
            item=entry.get("item") if isinstance(entry.get("item"),dict) else entry
            if not self._recent_visible_on_this_home(entry,item):continue
            mtype=str(entry.get("media_type") or item.get("_saved_media_type") or "").lower()
            group=0 if mtype in ("itv","live") else (1 if mtype=="vod" else (2 if mtype in ("series","episode") else -1))
            if group<0:continue
            # Old exported-player evStart calls inserted zero-progress bouquet
            # rows into plugin history. Native export Resume owns these rows;
            # keep the database intact and show real plugin Recent entries.
            receiver_type=str(item.get("_receiver_media_type") or "").lower()
            if item.get("_external_export_playback") or item.get("_export_native_resume") or receiver_type in ("itv","live","vod","movie","series","episode","catchup"):continue
            if group==2:
                identity=self._recent_series_identity(item,mtype)
                if identity and identity in seen_series:continue
                if identity:seen_series.add(identity)
            if len(groups[group])<3:groups[group].append((entry,item,mtype))
            if all(len(rows)>=3 for rows in groups):break
        for rows in groups:
            while len(rows)<3:rows.append(None)
        return groups[0]+groups[1]+groups[2]

    @staticmethod
    def _recent_group(index):
        try:return max(0,min(2,int(index)//3))
        except Exception:return 0

    @staticmethod
    def _recent_row(index):
        try:return max(0,min(2,int(index)%3))
        except Exception:return 0

    @staticmethod
    def _recent_group_range(group):
        base=max(0,min(2,int(group)))*3
        return range(base,base+3)

    @staticmethod
    def _recent_placeholder(group):
        return ("us168_live_placeholder_220x132.png","grid_placeholder_movie_921.png","grid_placeholder_series_921.png")[max(0,min(2,int(group)))]

    def _recent_list_entry(self,index,selected=False):
        try:index=max(0,min(8,int(index)))
        except Exception:index=0
        packed=self._recent_entries[index] if index<len(self._recent_entries) else None
        title,meta,pct=self._recent_row_text(index,packed)
        details={
            "selected":bool(selected),
            "row_asset":self._recent_row_normal_path,
            "row_selected_asset":self._recent_row_selected_path,
            "meta":str(meta or "")[:46],
            "progress":max(0,min(100,int(pct or 0))),
            "show_progress":self._recent_group(index)!=0 and int(pct or 0)>0,
        }
        return (title,None,packed,details)

    def _set_recent_row_focus(self,index):
        """Invalidate at most two MultiContent entries; no Pixmap widget swapping."""
        try:new=-1 if index is None else max(0,min(8,int(index)))
        except Exception:new=-1
        try:old=int(getattr(self,"_recent_focus_drawn",-1))
        except Exception:old=-1
        if old==new:return
        for absolute,selected in ((old,False),(new,True)):
            if not (0<=absolute<9):continue
            group=self._recent_group(absolute);row=self._recent_row(absolute)
            try:self["recent_list%d"%group].update_icon_row(row,self._recent_list_entry(absolute,selected))
            except Exception as exc:optional_failure("ui.home_recent_focus",exc)
        self._recent_focus_drawn=new

    def _bind_recent_group_art(self,group,index=None):
        """Bind one already-cached art file for the group; never create/download art.

        Empty focus rows no longer hide/show the group art.  The lower Home card
        is a resident surface: while at least one row in that group has content,
        keep a valid artwork bound exactly like the fixed cards above it.
        """
        group=max(0,min(2,int(group)))
        chosen=None
        candidates=[]
        if index is not None and self._recent_group(index)==group:
            selected=int(index)
            if selected<len(self._recent_entries) and self._recent_entries[selected]:
                candidates.append(selected)
        candidates.extend(i for i in self._recent_group_range(group) if i not in candidates)
        for i in candidates:
            if i>=len(self._recent_entries):continue
            packed=self._recent_entries[i]
            path=self._recent_art_paths[i] if i<len(self._recent_art_paths) else None
            if packed and path and os.path.isfile(str(path)):
                chosen=(i,str(path));break
        if chosen is None:
            # Empty recent slots stay genuinely empty. Do not synthesize a
            # group icon/placeholder merely because the panel exists.
            self._recent_group_art_paths[group]=""
            try:self["recent_art%d"%group].hide()
            except Exception as exc:optional_failure("ui.home_recent_art_empty",exc)
            return
        path=chosen[1]
        if group==0:
            # Live Recent artwork is never bound from a raw provider image.
            # A raw picon can be re-expanded by ePixmap after returning from a
            # child Player screen even when the widget geometry is still 220x132.
            # Always bind the persistent aspect-safe 220x132 transparent canvas.
            try:
                placeholder=asset("us168_live_placeholder_220x132.png")
                already_fitted=("%slive_picon_fit%s"%(os.sep,os.sep)) in os.path.abspath(path) and str(path).endswith("_220x132.png")
                if not already_fitted and os.path.basename(str(path))!=os.path.basename(str(placeholder)):
                    fitted=_fit_live_picon_canvas(str(path),PERSISTENT_GENERATED_DIR,(220,132)) if callable(_fit_live_picon_canvas) else ""
                    path=str(fitted or placeholder)
                    try:self._recent_art_paths[chosen[0]]=path
                    except Exception:pass
            except Exception as exc:
                optional_failure("ui.home_recent_live_hard_fit",exc)
                path=asset("us168_live_placeholder_220x132.png")
        # Home stays resident underneath child screens.  Some OE-A images can
        # leave a Pixmap instance with the geometry from a previously painted
        # surface after returning from fullscreen playback.  Re-assert the
        # native Recent-card geometry on every bind, even when the artwork path
        # itself did not change.  Live is therefore always hard-clamped to the
        # intended 220x132 slot instead of occasionally expanding on return.
        self._set_recent_art_geometry(group)
        if self._recent_group_art_paths[group]==path:
            try:
                inst=self["recent_art%d"%group].instance
                if group==0 and inst is not None:inst.setPixmapFromFile(path)
                self["recent_art%d"%group].show()
            except Exception:pass
            return
        self._recent_group_art_paths[group]=path
        try:
            inst=self["recent_art%d"%group].instance
            if inst is not None:inst.setPixmapFromFile(path)
            self["recent_art%d"%group].show()
        except Exception as exc:optional_failure("ui.home_recent_art_bind",exc)

    @staticmethod
    def _recent_number(value):
        if value in (None,""):return ""
        try:return str(int(value))
        except Exception:return str(value).strip()

    def _recent_row_text(self,index,packed):
        group=self._recent_group(index)
        if not packed:
            return "", "", 0
        entry,item,mtype=packed;item=item if isinstance(item,dict) else {}
        clean=bool(getattr(self,"_home_clean_titles",True))
        raw=item.get("_raw_name") or item.get("name") or item.get("title") or item.get("episode_name") or _("Recent")
        title=premium_title(raw,True) if clean else str(raw).strip()
        if group==2 and mtype=="episode":
            series_raw=item.get("_raw_series_title") or item.get("_series_title") or item.get("series_title") or item.get("series_name") or ""
            if series_raw:title=premium_title(series_raw,True) if clean else str(series_raw).strip()
        title=_clean_display_text(title,46)
        if group==0:return title, _("Live TV  •  reopen channel"), 0
        pos=max(0,int(entry.get("_position") or 0)) if isinstance(entry,dict) else 0
        dur=max(0,int(entry.get("_duration") or 0)) if isinstance(entry,dict) else 0
        completed=bool(entry.get("_completed")) if isinstance(entry,dict) else False
        pct=min(100,int(pos*100.0/dur)) if pos and dur else (100 if completed else 0)
        if group==1:
            meta=_("Watched  •  play again") if completed else (_("Continue watching  •  %d%%")%pct if pct else _("Movie  •  open"))
            return title,meta,pct
        season=self._recent_number(item.get("_season_number") or item.get("season") or item.get("season_num") or item.get("season_number") or item.get("season_id"))
        episode=self._recent_number(item.get("episode_num") or item.get("episode") or item.get("number") or item.get("episode_number"))
        if mtype=="episode":
            bits=[]
            if season:bits.append("S%02d"%int(season) if season.isdigit() else "S%s"%season)
            if episode:bits.append("E%02d"%int(episode) if episode.isdigit() else "E%s"%episode)
            if pct:bits.append("%d%%"%pct)
            elif completed:bits.append("100%")
            meta="  •  ".join(bits) or _("Episode  •  open")
        else:meta=_("Series  •  open")
        return title,meta,pct

    def _set_recent_art_geometry(self, slot):
        """Restore the native media-art geometry for a populated recent panel."""
        normal=((60,852,220,132),(697,782,190,272),(1319,782,190,272))
        try:
            x,y,w,h=normal[int(slot)]
            desk=getDesktop(0).size();sx=float(desk.width())/1920.0;sy=float(desk.height())/1080.0
            inst=self["recent_art%d"%int(slot)].instance
            if inst is not None:
                inst.move(ePoint(int(round(x*sx)),int(round(y*sy))))
                inst.resize(eSize(int(round(w*sx)),int(round(h*sy))))
                try:inst.setScale(1)
                except Exception:pass
        except Exception as exc:optional_failure("ui.home_recent_geometry",exc)

    def _load_recent_cards(self,initial=False):
        """Fill the three resident Recent panels from SQLite/local artwork only.

        ``initial`` means first-paint preparation.  Later history refreshes reuse
        the already-instantiated MultiContent lists and invalidate entries in
        place instead of clearing/recreating the three lower cards.
        """
        self["continue_header"].setText(_("CONTINUE / RECENT"))
        self._cancel_recent_futures()
        self._recent_generation=int(getattr(self,"_recent_generation",0) or 0)+1
        self._recent_entries=self._continue_for_this_portal();self._recent_art_paths=[None]*9
        _warm_recent=False;_warm_art={}
        try:
            _warm_recent=bool(splash_home_is_warm and splash_home_is_warm(self.profile))
            if _warm_recent and callable(splash_home_recent_assets):
                _warm_art = splash_home_recent_assets(self.profile)[0]
        except Exception:
            _warm_recent=False;_warm_art={}
        # Artwork lookup remains HDD/RAM-only. No network job is launched here.
        # Live picons are special: the Home slot is 220x132 but the source must
        # never be stretched/upscaled to fill it.  Start with the lightweight
        # placeholder, then fit the already-cached local picon on the shared
        # image worker.  This keeps Pillow and file generation off the GUI thread.
        for i in range(9):
            packed=self._recent_entries[i] if i<len(self._recent_entries) else None
            if not packed:continue
            _entry,item,mtype=packed;group=self._recent_group(i)
            size=(220,132) if group==0 else (190,272);ph=self._recent_placeholder(group)
            try:
                _pre_art=str(_warm_art.get(i) or _warm_art.get(str(i)) or "") if _warm_recent else ""
                if group==0 and _pre_art and os.path.isfile(_pre_art):
                    self._recent_art_paths[i]=_pre_art
                    continue
                # Search may have played a copy from another configured source.
                # Use that source's portal/MAC only for local artwork cache keys;
                # this adds no network work and no profile-file read on Home paint.
                _art_profile=self.profile
                try:
                    _src_portal=str((_entry or {}).get("portal") or "")
                    _src_mac=str((_entry or {}).get("mac") or "")
                    if _src_portal:_art_profile={"portal":_src_portal,"mac":_src_mac}
                except Exception:pass
                cached=_home_cached_art(item,_art_profile,size,ph,mtype)
                if _warm_recent:
                    self._recent_art_paths[i]=str(cached or asset(ph))
                elif group==0 and cached and os.path.isfile(str(cached)) and os.path.basename(str(cached))!=os.path.basename(str(asset(ph))):
                    self._recent_art_paths[i]=asset(ph)
                    generation=int(self._recent_generation)
                    if _IMAGE_EXECUTOR is not None and callable(_fit_live_picon_canvas):
                        future=_IMAGE_EXECUTOR.submit(_fit_live_picon_canvas,str(cached),PERSISTENT_GENERATED_DIR,(220,132))
                        self._recent_futures.add(future)
                        def _done(_future,_index=i,_generation=generation):
                            try:
                                path=_future.result() or ""
                            except Exception as exc:
                                optional_failure("ui.home_recent_live_fit",exc);path=""
                            try:self._recent_futures.discard(_future)
                            except Exception:pass
                            if path:self._home_jobs.put(("recent_live_fit",_generation,_index,str(path)))
                        future.add_done_callback(_done)
                    else:
                        self._recent_art_paths[i]=str(cached)
                else:
                    self._recent_art_paths[i]=cached
            except Exception as exc:
                optional_failure("ui.home_recent_local_cache",exc);self._recent_art_paths[i]=asset(ph)
        focused=self.recent_index if self.focus_row=="recent" else -1
        first_bind=bool(initial or not getattr(self,"_recent_lists_initialized",False))
        for group in range(3):
            rows=[]
            for row in range(3):
                absolute=group*3+row
                rows.append(self._recent_list_entry(absolute,absolute==focused))
            try:
                if first_bind:
                    self["recent_list%d"%group].set_icon_rows(rows)
                else:
                    # Keep the native list resident. Per-row invalidation avoids
                    # the whole lower panel briefly disappearing on history refresh.
                    for row,entry in enumerate(rows):
                        self["recent_list%d"%group].update_icon_row(row,entry)
            except Exception as exc:optional_failure("ui.home_recent_list_bind",exc)
            preferred=self.recent_index if self.focus_row=="recent" and self._recent_group(self.recent_index)==group else group*3
            self._bind_recent_group_art(group,preferred)
        self._recent_lists_initialized=True
        self._recent_snapshot_ready=True
        self._recent_focus_drawn=focused
        try:self._recent_render_revision=int(history_revision()) if callable(history_revision) else int(getattr(self,"_recent_render_revision",-1))
        except Exception:pass
