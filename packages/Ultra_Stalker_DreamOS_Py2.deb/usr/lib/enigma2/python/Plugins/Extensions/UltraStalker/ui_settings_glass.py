# -*- coding: utf-8 -*-
"""Glass Settings design: native MultiContent row lists + skin for NovaSettingsScreen.

Everything here is presentation only.  Row PNGs are pre-rendered assets (set_*.png);
nothing is drawn with PIL at runtime.  Pixmaps are never scaled by MultiContent, so each
asset is authored at its final size.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str, int, max, us_func
from .wqhd_layout import responsive_font as _ultra_rfont, factors as _ultra_factors, register_pixmap_path as _register_pixmap_path

def _ultra_osd_scale():
    return _ultra_factors()[1]
os = _us_env.os

from Components.MultiContent import MultiContentEntryText
try:
    from Components.MultiContent import MultiContentEntryPixmapAlphaBlend
except Exception:  # pragma: no cover
    from Components.MultiContent import MultiContentEntryPixmapAlphaTest as MultiContentEntryPixmapAlphaBlend
from enigma import ePoint, eSize, gFont, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_HALIGN_CENTER, RT_VALIGN_CENTER, loadPNG
try:
    from enigma import RT_WRAP
except ImportError:
    RT_WRAP = 0

from .ui_icon_menu import IconMenuList

_AS = "/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/"
_ASSET_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets_fhd")

C_WHITE = 0xFFFFFF
C_SECOND = 0xC9CCD1
C_QUIET = 0x8E9AA3
C_MINT = 0x9FD6BF
C_CELL_NAME = 0xE3E6E9

LF_LEFT = RT_HALIGN_LEFT | RT_VALIGN_CENTER
LF_RIGHT = RT_HALIGN_RIGHT | RT_VALIGN_CENTER
LF_CENTER = RT_HALIGN_CENTER | RT_VALIGN_CENTER

# Settings that flip ON/OFF (mirrors the toggle branch of NovaSettingsScreen.select()).
BOOL_ACTIONS = frozenset((
    "smart_recovery",
    "images", "preview", "parental", "clean_titles", "quality_badges", "multi_portal_search",
    "diagnostic_logging", "show_watched", "tmdb_enabled", "crash_safe_progress", "remember_track_language",
    "auto_remove_completed", "show_main_menu", "category_preview_posters", "show_channel_numbers", "hide_empty_categories", "hide_adult",
))
# Rows that run something / open a text prompt / show info: no ‹ value › arrows.
ACTION_ACTIONS = frozenset((
    "refresh_content", "clear_temp_cache", "clear_persistent_artwork", "global_artwork_preload",
    "tmdb_test", "backup_restore", "support_bundle", "web_cleaner", "online_update", "about",
    "diagnostics", "pin", "adult_keywords", "parental_lock_now", "proxy_port", "tmdb_credential",
    "reset_settings", "fanart_api_key", "subdl_api_key", "subsource_api_key", "api_keys_file", "tmdb_credits",
))


def classify(action):
    action = str(action or "")
    if action.startswith("section:"):
        return "group"
    if action in BOOL_ACTIONS:
        return "bool"
    if action in ACTION_ACTIONS:
        return "action"
    return "choice"


def group_icon(key):
    return os.path.join(_ASSET_DIR, "set_ic_%s_40.png" % key)


_PNG = {}


def _png(name):
    p = _PNG.get(name)
    if p is None:
        full = os.path.join(_ASSET_DIR, name)
        try:
            p = loadPNG(full) if os.path.isfile(full) else False
            if p:
                _register_pixmap_path(p, full)
        except Exception:
            p = False
        _PNG[name] = p
    return p or None


def _png_path(path):
    p = _PNG.get(path)
    if p is None:
        try:
            p = loadPNG(path) if path and os.path.isfile(path) else False
            if p:
                _register_pixmap_path(p, path)
        except Exception:
            p = False
        _PNG[path] = p
    return p or None


def _clip(text, n):
    text = " ".join(str(text or "").split())
    return text if len(text) <= n else text[:n - 1] + "…"


def value_text(kind, value):
    """Right-hand text of an option row (switch graphics are handled separately)."""
    value = _clip(value, 24)
    if kind == "choice":
        return "‹  %s  ›" % value
    return value


def _pic(png, x, y, w, h):
    return MultiContentEntryPixmapAlphaBlend(pos=(x, y), size=(w, h), png=png)


def _txt(x, y, w, h, font, flags, text, color):
    return MultiContentEntryText(pos=(x, y), size=(w, h), font=font, flags=flags, text=str(text), color=color)


class SettingsGlassList(IconMenuList):
    """One native MultiContent list for both Settings levels (group rail / option rows).

    Rows are (title, icon_path, data, meta) exactly like IconMenuList.set_icon_rows();
    meta keys: level ("groups"/"options"), selected, kind, value, on, count.
    """

    def __init__(self, rows=None, width=440, item_height=98):
        us_func(IconMenuList.__init__)(self, rows or [], width=width, item_height=item_height, icon_size=0,
                              primary_font=24, secondary_font=17, row_style="settings_glass")
        self.l.setFont(20, _ultra_rfont("Regular", 27))
        self.l.setFont(21, _ultra_rfont("Regular", 24))
        self.l.setFont(22, _ultra_rfont("Regular", 22))
        self.l.setFont(23, _ultra_rfont("Regular", 17))

    def fit_visible_rows(self, count):
        """Own BOTH native row pitch and viewport after the receiver skin.

        The receiver can override the eListbox height/spacing independently of
        the Python content. Resizing its viewport alone does not repair that.
        Remember calls made before the native widget exists, then reapply after
        applySkin. Leave a two-pixel rounding margin below the final whole row.
        """
        from .wqhd_layout import font_size
        count = max(1, int(count))
        # Ten rows use the full 1000px rail with a visible inter-card gap.
        # An optional eleventh action still fits by using the shorter card.
        if self.row_height in (90, 100):
            pitch = 100 if count <= 10 else 90
            if self.row_height != pitch:
                self.row_height = pitch
                self._render_row_signatures = None
        self._native_visible_rows = count
        inst = self.instance
        if inst is None or getattr(self, "_native_geometry_busy", False):
            return
        self._native_geometry_busy = True
        try:
            row_px = font_size(self.row_height)
            self.l.setItemHeight(row_px)
            # Older DreamOS has no spacing API; its fixed vertical rows already
            # have zero spacing. Newer images may inherit it from a windowstyle.
            if hasattr(inst, "setItemSpacing"):
                inst.setItemSpacing(ePoint(0, 0))
            if hasattr(inst, "setItemHeight"):
                inst.setItemHeight(row_px)
            inst.resize(eSize(inst.size().width(), count * row_px + 2))
            if len(getattr(self, "list", []) or []) <= count and hasattr(inst, "setTopIndex"):
                inst.setTopIndex(0)
        finally:
            self._native_geometry_busy = False

    def applySkin(self, desktop, parent):
        result = us_func(IconMenuList.applySkin)(self, desktop, parent)
        from .wqhd_layout import font_size
        count = getattr(self, "_native_visible_rows", None)
        if count is None and self.instance is not None:
            count = max(1, self.instance.size().height() // font_size(self.row_height))
        if count is not None:
            self.fit_visible_rows(count)
        return result

    def make_row(self, text, icon_path, data=None, secondary=""):
        d = secondary if isinstance(secondary, dict) else {}
        title = _clip(text, 40) or "-"
        sel = bool(d.get("selected"))
        row = [data if data is not None else title]
        if d.get("level") == "options":
            self._option_row(row, title, d, sel)
        else:
            self._group_row(row, title, icon_path, d, sel, self.row_height)
        from .wqhd_layout import scale_multicontent_row
        return scale_multicontent_row(row)

    @staticmethod
    def _group_row(row, title, icon_path, d, sel, row_height=98):
        compact = row_height in (90, 100)
        card_h = (90 if row_height == 100 else 82) if compact else 98
        card_y = (row_height - card_h) // 2
        shift = 4 - (row_height - 90) // 2 if compact else 0
        bg = _png("set_grp_%s_440x%d.png" % ("sel" if sel else "row", card_h))
        if bg is not None:
            row.append(_pic(bg, 0, card_y, 440, card_h))

        # Free libraries borrow the numbered-card grammar from the main Portal
        # list while keeping the approved Settings glass row.  Reserve a fixed
        # lane for the absolute source number, then keep the existing semantic
        # icon and text to its right.  Font steps guarantee 3/4-digit values fit.
        free_library = bool(d.get("free_library_state"))
        source_number = d.get("source_number") if free_library else None
        numbered = source_number is not None
        if numbered:
            try:
                n = max(0, int(source_number))
                number_text = ("%02d" % n) if n < 100 else str(n)
            except Exception:
                number_text = str(source_number or "")[:4]
            digits = len(number_text)
            number_font = 20 if digits <= 2 else (21 if digits == 3 else 22)
            number_color = C_WHITE if sel else 0x8E9299
            row.append(_txt(8, 19 - shift, 68, 48, number_font, LF_CENTER, number_text, number_color))

        ic = _png_path(icon_path)
        if ic is not None:
            row.append(_pic(ic, 82 if numbered else 26, 29 - shift, 40, 40))
        count = d.get("count", "")
        if count:
            title_color = C_WHITE if sel else C_SECOND
            count_color = C_MINT if sel else C_QUIET
            # Portal Manager action details stay neutral even when focused.
            # This keeps the manager visually quiet and, more importantly,
            # allows its navigation path to use lightweight two-row updates
            # instead of rebuilding the whole list on every key press.
            if d.get("neutral_secondary"):
                count_color = C_QUIET
            # Free Portal / Free Xtream use the same Settings glass geometry,
            # but their source identity/state colours must not depend on focus.
            # This keeps every source name crisp white and makes SELECTED remain
            # unmistakably green even when the cursor is on another row.
            if free_library:
                try:
                    title_color = int(d.get("title_color", C_WHITE))
                except Exception:
                    title_color = C_WHITE
                try:
                    count_color = int(d.get("value_color", C_QUIET))
                except Exception:
                    count_color = C_QUIET
            text_x = 136 if numbered else 82
            text_w = 286 if numbered else 340
            row.append(_txt(text_x, 20 - shift, text_w, 32, 22, LF_LEFT, title, title_color))
            row.append(_txt(text_x, 54 - shift, text_w, 22, 23, LF_LEFT, count, count_color))
        else:
            # No second line (e.g. Portal Manager actions): centre the title vertically.
            row.append(_txt(82, 33 - shift, 340, 32, 22, LF_LEFT, title, C_WHITE if sel else C_SECOND))

    @staticmethod
    def _option_row(row, title, d, sel):
        bg = _png("settings_d_r5392/row_500x66_selected.png" if sel else "settings_d_r5392/row_500x66.png")
        if bg is not None:
            row.append(_pic(bg, 0, 0, 500, 66))
        right = 500
        left = 12
        kind = d.get("kind")
        # Narrow D panel: fixed control lane; long labels wrap at full font size.
        title_w = 386 if kind == "bool" else 294
        row.append(_txt(left, 6, title_w, 54, 21, LF_LEFT | RT_WRAP, title, C_WHITE if sel else C_CELL_NAME))
        if kind == "bool":
            sw = _png("set_sw_on_64x32.png" if d.get("on") else "set_sw_off_64x32.png")
            if sw is not None:
                row.append(_pic(sw, right - 12 - 64, 17, 64, 32))
        else:
            vt = value_text(kind, d.get("value", ""))
            if vt:
                row.append(_txt(right - 12 - 180, 8, 180, 50, 22, LF_RIGHT | RT_WRAP, vt,
                                C_MINT if (sel or kind == "choice") else C_SECOND))


def build_skin():
    A = _AS
    p = []
    p.append('<screen name="NovaSettingsScreen" position="center,center" size="1920,1080" backgroundColor="#02070b" flags="wfNoBorder">\n')
    p.append(' <widget name="ambient_bg" position="0,0" size="1920,1080" alphatest="blend" scale="1" transparent="1" zPosition="1"/>\n')
    p.append(' <widget name="hero_backdrop" position="0,0" size="1920,1080" alphatest="blend" scale="1" transparent="1" zPosition="2"/>\n')
    p.append(' <widget name="page_title" position="-2000,52" size="900,64" font="Regular;46" halign="left" valign="center" foregroundColor="#ffffff" transparent="1" zPosition="8" noWrap="1" shadowColor="#000000" shadowOffset="2,2"/>\n')
    p.append(' <widget name="page_sub" position="-2000,114" size="700,34" font="Regular;22" halign="left" valign="center" foregroundColor="#c9ccd1" transparent="1" zPosition="8" noWrap="1" shadowColor="#000000" shadowOffset="2,2"/>\n')
    p.append(' <widget name="page_dot" position="2000,114" size="22,34" font="Regular;22" halign="left" valign="center" foregroundColor="#46e196" transparent="1" zPosition="8" noWrap="1"/>\n')
    p.append(' <widget name="page_state" position="2000,114" size="200,34" font="Regular;22" halign="left" valign="center" foregroundColor="#7fe3ae" transparent="1" zPosition="8" noWrap="1" shadowColor="#000000" shadowOffset="2,2"/>\n')
    p.append(' <ePixmap position="-2000,156" size="120,4" pixmap="%spage_underline_120x4.png" alphatest="blend" zPosition="8"/>\n' % A)
    p.append(' <widget name="list" position="48,50" size="440,1000" foregroundColor="#ffffff" foregroundColorSelected="#ffffff" selectionPixmap="%sportal_selection_clear.png" scrollbarMode="showNever" transparent="1" zPosition="7"/>\n' % A)
    # right card (bottom-right): option rows of the focused group
    p.append(' <widget name="pv_panel" position="1340,380" size="560,680" alphatest="blend" transparent="1" zPosition="3"/>\n')
    p.append(' <widget name="pv_tile" position="1370,404" size="64,64" alphatest="blend" transparent="1" zPosition="5"/>\n')
    p.append(' <widget name="pv_icon" position="1382,416" size="40,40" alphatest="blend" transparent="1" zPosition="6"/>\n')
    p.append(' <widget name="pv_title" position="1450,400" size="420,76" font="Regular;29" halign="left" valign="center" foregroundColor="#ffffff" transparent="1" zPosition="6" noWrap="0" shadowColor="#000000" shadowOffset="2,2"/>\n')
    p.append(' <widget name="pv_desc" position="1370,469" size="500,66" font="Regular;20" halign="left" valign="center" foregroundColor="#c9ccd1" transparent="1" zPosition="6" noWrap="0" shadowColor="#000000" shadowOffset="1,1"/>\n')
    p.append(' <widget name="pv_hair" position="1370,537" size="500,2" alphatest="blend" transparent="1" zPosition="5"/>\n')
    p.append(' <widget name="pv_hair_bottom" position="1370,949" size="500,2" alphatest="blend" transparent="1" zPosition="5"/>\n')
    p.append(' <widget name="opt_list" position="1370,547" size="500,396" foregroundColor="#ffffff" foregroundColorSelected="#ffffff" scrollbarMode="showNever" transparent="1" zPosition="6"/>\n')
    # inline context (choice popup / notices) -- unchanged geometry, driven by code
    p.append(' <widget name="context_panel" position="1120,600" size="730,360" alphatest="blend" scale="1" transparent="1" zPosition="10"/>\n')
    p.append(' <widget name="context_title" position="1160,618" size="650,40" font="Regular;29" foregroundColor="#ffffff" transparent="1" zPosition="11" shadowColor="#000000" shadowOffset="1,1"/>\n')
    p.append(' <widget name="context_subtitle" position="1160,658" size="650,28" font="Regular;17" foregroundColor="#91b7ca" transparent="1" zPosition="11" shadowColor="#000000" shadowOffset="1,1"/>\n')
    p.append(' <widget name="context_message" position="1160,700" size="650,150" font="Regular;20" foregroundColor="#f4f8fb" noWrap="0" transparent="1" zPosition="11" shadowColor="#000000" shadowOffset="1,1"/>\n')
    p.append(' <widget name="context_list" position="1160,700" size="650,220" foregroundColor="#ffffff" foregroundColorSelected="#ffffff" selectionPixmap="%sportal_selection_clear.png" scrollbarMode="showNever" transparent="1" zPosition="12"/>\n' % A)
    p.append(' <widget name="context_hint" position="1160,925" size="650,28" font="Regular;16" halign="center" valign="center" foregroundColor="#a9c1d0" transparent="1" zPosition="12" shadowColor="#000000" shadowOffset="1,1"/>\n')
    # option description (options level only; hidden while the context popup is open)
    p.append(' <widget name="description" position="1370,955" size="500,94" font="Regular;20" halign="left" valign="top" foregroundColor="#ffffff" noWrap="0" shadowColor="#000000" shadowOffset="2,2" transparent="1" zPosition="9"/>\n')
    p.append(' <widget name="status" position="64,1034" size="1050,30" font="Regular;18" halign="left" valign="center" foregroundColor="#9fd6bf" shadowColor="#000000" shadowOffset="1,1" transparent="1" zPosition="9" noWrap="1"/>\n')
    p.append('</screen>')
    return "".join(p)
