# -*- coding: utf-8 -*-
"""Page navigation, edge hops, D-pad moves and opening the selected item.

Methods moved verbatim out of ``PremiumGridBase`` (ui_grid_base.py); behaviour is unchanged.
This module is imported by ui_grid_base.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, max, min
from .ui_grid_base import (
    _,
    os,
    time,
)


class GridNavMixin(object):
    """Page navigation, edge hops, D-pad moves and opening the selected item."""

    def _stop_grid_page_nav(self):
        try:self._grid_page_nav_timer.stop()
        except Exception:pass
        try:
            if self._grid_page_nav_conn is not None:self._grid_page_nav_conn.disconnect()
        except Exception:pass
        try:
            if self._commit_grid_page_nav in self._grid_page_nav_timer.callback:self._grid_page_nav_timer.callback.remove(self._commit_grid_page_nav)
        except Exception:pass
        self._grid_page_nav_target=0;self._grid_page_nav_index=0

    def _grid_nav_total_pages(self):
        total=int(self._active_total() or 0)
        # Zero means the provider did not publish a catalogue total.  Preserve
        # R217's open-ended next-page behavior instead of pretending the current
        # page is the last one.
        return max(1,(total+int(self.page_size or 1)-1)//int(self.page_size or 1)) if total else 0

    def _grid_virtual_page(self):
        return int(getattr(self,"_grid_page_nav_target",0) or getattr(self,"page",1) or 1)

    def _grid_virtual_index(self):
        if int(getattr(self,"_grid_page_nav_target",0) or 0):
            return max(0,int(getattr(self,"_grid_page_nav_index",0) or 0))
        return max(0,int(getattr(self,"index",0) or 0))

    def _queue_grid_page_target(self,target,restore_index=0,delay_ms=110):
        """Coalesce rapid VOD/Series page hops into one final provider request."""
        if self.media_type not in ("vod","series"):
            self.load_page(target,restore_index);return
        total_pages=self._grid_nav_total_pages();target=max(1,int(target or 1))
        if total_pages>0:target=min(target,total_pages)
        restore_index=max(0,int(restore_index or 0))
        # If a burst returns to the page that is still painted, cancel the queued
        # page request and apply only the requested local index immediately.
        if target==int(getattr(self,"page",1) or 1) and not bool(getattr(self,"_busy",False)):
            try:self._grid_page_nav_timer.stop()
            except Exception:pass
            self._grid_page_nav_target=0;self._grid_page_nav_index=0
            if self.grid_items:
                self.index=min(restore_index,max(0,len(self.grid_items)-1));self._update_selection();self._update_page_counter()
            return
        self._grid_page_nav_target=target;self._grid_page_nav_index=restore_index
        self._grid_page_nav_commit_at=0.0
        try:  # instant feedback: show the page being loaded right away
            _tp=self._grid_nav_total_pages();_tot=int(self._active_total() or 0)
            _abs=(target-1)*int(self.page_size or 1)+restore_index+1
            if _tot:_abs=min(_tot,_abs)
            _kind="Movie" if self.media_type=="vod" else "Series"
            self["page_label"].setText(_("Page %d / %d  •  %s %d / %d") % (target,max(1,_tp),_kind,_abs,_tot or _abs))
        except Exception:pass
        self._grid_page_nav_generation=int(getattr(self,"_grid_page_nav_generation",0) or 0)+1
        try:self._grid_page_nav_timer.stop();self._grid_page_nav_timer.start(max(1,int(delay_ms)),True)
        except Exception:self._commit_grid_page_nav()

    def _queue_grid_page_delta(self,delta,restore_index=0,wrap=True):
        total_pages=self._grid_nav_total_pages();base=self._grid_virtual_page();step=int(delta or 0)
        if total_pages==1:return
        # R5.200: one press = one page. While the hop requested by an earlier press
        # is already loading, further presses in the same direction are ignored
        # instead of being stored and stacking extra pages once the load ends.
        try:
            pending=int(getattr(self,"_grid_page_nav_target",0) or 0)
            started=float(getattr(self,"_grid_page_nav_commit_at",0.0) or 0.0)
            if pending and started and (time.monotonic()-started)<8.0 and step==int(getattr(self,"_grid_page_nav_dir",0) or 0):
                return
        except Exception as exc:optional_failure("ui.grid_page_hop_inflight",exc)
        target=base+step
        if total_pages>1:
            if wrap:target=((target-1)%total_pages)+1
            else:target=max(1,min(target,total_pages))
        else:
            # Unknown provider total: page forward freely and clamp backward at 1,
            # matching the original on-demand catalogue behavior.
            target=max(1,target)
            if target==base:return
        self._queue_grid_page_target(target,restore_index,110)
        self._grid_page_nav_dir=1 if step>0 else (-1 if step<0 else 0)

    def _commit_grid_page_nav(self):
        target=int(getattr(self,"_grid_page_nav_target",0) or 0)
        if target<=0 or getattr(self,"_screen_closed",False):return
        index=max(0,int(getattr(self,"_grid_page_nav_index",0) or 0))
        self._grid_page_nav_commit_at=time.monotonic()
        # Keep the virtual target alive while the provider request is in flight.
        # More key presses can replace it; load_page's generation gate will then
        # discard/cancel the older request before it can paint.
        self.load_page(target,index)

    def _nav_allowed(self):
        now=time.monotonic()
        # Stage 8: never discard a real DirectionActions event.  Heavy artwork,
        # metadata and adaptive work already sit behind stable-focus timers; the
        # arrow hot path should therefore only mark the burst and move focus.
        self._nav_burst_until=now+0.30
        self._last_nav_at=now
        return True

    def _update_page_counter(self):
        self._apply_shared_footer_geometry()
        total = int(self._active_total() or 0)
        total_pages = max(1, (total + self.page_size - 1) // self.page_size) if total else 1
        absolute = min(total, (self.page - 1) * self.page_size + self.index + 1) if total else (0 if not self.grid_items else ((self.page - 1) * self.page_size + self.index + 1))
        kind = "Channel" if self.media_type == "itv" else ("Movie" if self.media_type == "vod" else "Series")
        try:self["page_label"].setText(_("Page %d / %d  •  %s %d / %d") % (self.page, total_pages, kind, absolute, total or absolute))
        except Exception as exc:optional_failure("ui.silent_guard",exc)

    def _edge_page_hop(self,delta):
        # R5.167: LEFT on the first card / RIGHT on the last card of a page hops
        # to the previous / next page (no wrap) instead of doing nothing.
        try:
            restore=max(0,self.page_size-1) if delta<0 else 0
            if self.media_type in ("vod","series"):
                self._queue_grid_page_delta(delta,restore,wrap=False);return
            if delta<0:
                if self.page>1:self.load_page(self.page-1,restore)
            else:
                total=int(self._active_total() or 0)
                pages=max(1,(total+self.page_size-1)//self.page_size) if total else 0
                if pages and self.page<pages:self.load_page(self.page+1,0)
        except Exception as exc:optional_failure("ui.grid_edge_page_hop",exc)

    def move_left(self):
        if not (self.grid_items and self._nav_allowed()):return
        if self.index<=0:self._edge_page_hop(-1);return
        self.index-=1;self._update_selection();self._update_page_counter()

    def move_right(self):
        if not (self.grid_items and self._nav_allowed()):return
        if self.index>=len(self.grid_items)-1:self._edge_page_hop(1);return
        self.index+=1;self._update_selection();self._update_page_counter()

    def move_up(self):
        if not self.grid_items or not self._nav_allowed():
            return
        # Normal in-page movement remains immediate. If a page hop is already
        # queued, repeated boundary presses advance the virtual page instead of
        # repeatedly loading the page still painted underneath it.
        if not int(getattr(self,"_grid_page_nav_target",0) or 0) and self.index >= self.columns:
            self.index -= self.columns
            self._update_selection();self._update_page_counter()
            return
        column=self.index % self.columns
        restore=max(0,self.page_size-self.columns+column)
        if self.media_type in ("vod","series"):
            self._queue_grid_page_delta(-1,restore,wrap=True);return
        if self.page > 1:
            self.load_page(self.page - 1,restore);return
        total=int(self._active_total() or 0)
        if total > 0:
            last_page=max(1,(total+self.page_size-1)//self.page_size);self.load_page(last_page,self.page_size-1)
        else:
            self.index=len(self.grid_items)-1;self._update_selection();self._update_page_counter()

    def move_down(self):
        if not self.grid_items or not self._nav_allowed():
            return
        target = self.index + self.columns
        if not int(getattr(self,"_grid_page_nav_target",0) or 0) and target < len(self.grid_items):
            self.index = target
            self._update_selection();self._update_page_counter()
            return
        column = self.index % self.columns
        if self.media_type in ("vod","series"):
            self._queue_grid_page_delta(1,column,wrap=True);return
        total=int(self._active_total() or 0)
        total_pages=max(1,(total+self.page_size-1)//self.page_size) if total else 0
        if total_pages and self.page >= total_pages:
            self.load_page(1,0);return
        self.load_page(self.page + 1,column)

    def next_page(self):
        column=self.index % self.columns if self.grid_items else 0
        if self.media_type in ("vod","series"):
            self._queue_grid_page_delta(1,column,wrap=False);return
        self.load_page(self.page + 1,column)

    def previous_page(self):
        column=self.index % self.columns if self.grid_items else 0
        if self.media_type in ("vod","series"):
            self._queue_grid_page_delta(-1,max(0,self.page_size-self.columns+column),wrap=False);return
        if self.page <= 1:return
        self.load_page(self.page - 1,max(0,self.page_size-self.columns+column))

    def open_selected(self):
        if not self.grid_items:return
        if self._busy and not (getattr(self,"_view_active",False) and getattr(self,"_search_query","")):return
        item=self.grid_items[self.index]
        if self.media_type=="itv":
            self._play_live(item)
        else:
            self._remember_grid_state()
            self._pause_grid_background_for_child()
            # Carry the exact poster palette source used by the grid into Details.
            # This makes List -> Details one continuous adaptive identity.
            detail_item=dict(item) if isinstance(item,dict) else item
            try:
                if isinstance(detail_item,dict):
                    # R99 maintenance: views that already hold canonical Details
                    # state in RAM may hand it directly to the child.  This is an
                    # optional hook; ordinary grids keep their existing path.
                    try:
                        _snap_hook=getattr(self,"_details_handoff_snapshot",None)
                        _snap=_snap_hook(item) if callable(_snap_hook) else {}
                        if isinstance(_snap,dict) and _snap:
                            detail_item["_ultra_detail_snapshot"]=dict(_snap)
                    except Exception:pass
                    try:
                        _bundle_hook=getattr(self,"_details_handoff_bundle",None)
                        _bundle=_bundle_hook(item,self.index) if callable(_bundle_hook) else {}
                        if isinstance(_bundle,dict) and _bundle:
                            detail_item["_ultra_fast_open"]=True
                            detail_item["_ultra_fast_bundle"]=dict(_bundle)
                    except Exception:pass
                    # The screen that visibly owns the selected title is the
                    # identity/logo authority handed into Details/Player.
                    # R111 speed: the focused card already carries verified identity
                    # in RAM after normal hydration.  Reuse it before touching HDD.
                    state=(getattr(self,"_grid_item_state",{}) or {}).get(id(item),{})
                    locked=(detail_item.get("_locked_tmdb_id") or detail_item.get("_ultra_search_verified_tmdb_id") or state.get("tmdb_id"))
                    if locked in (None,""):
                        try:
                            record_reader=getattr(self,"_record",None)
                            row=record_reader(item) if callable(record_reader) else {}
                            row_verified=(row or {}).get("tmdb_id") if ((row or {}).get("identity_verified") or (row or {}).get("identity_pointer_verified")) else None
                            locked=(row or {}).get("_locked_tmdb_id") or (row or {}).get("_ultra_search_verified_tmdb_id") or row_verified
                        except Exception:
                            locked=None
                    # PGV2 seal is now fallback-only. A live locked id is newer/stronger
                    # than a rebuildable HDD seal and avoids a file read on normal OK.
                    if locked in (None,""):
                        try:
                            seal_reader=getattr(self,"_pgv2_read_logo_seal",None)
                            seal=seal_reader(item) if callable(seal_reader) else {}
                            locked=(seal or {}).get("tmdb_id")
                        except Exception:
                            locked=None
                    if locked not in (None,""):
                        detail_item["_locked_tmdb_id"]=locked;detail_item["tmdb_id"]=locked
                palette_source=(getattr(self,"_grid_palette_sources",{}).get(self.index) or self._grid_slot_paths.get(self.index) or "")
                visible_poster=self._visible_player_poster_path(item,self.index)
                if isinstance(detail_item,dict) and visible_poster:
                    # R5.234 single poster authority: the pixels the user is looking
                    # at when opening Details own this navigation session. TMDb may
                    # enrich metadata/backdrop/logo, but it may not swap this poster.
                    detail_item["_player_poster"]=str(visible_poster)
                    detail_item["_ultra_palette_source"]=str(visible_poster)
                    detail_item["_ultra_poster_source"]=str(visible_poster)
                    detail_item["_adaptive_source_local"]=str(visible_poster)
                    detail_item["_ultra_visible_poster_locked"]=True
                    _poster_key=self._page_visual_key(item) if isinstance(item,dict) else ""
                    if _poster_key:detail_item["_player_poster_identity"]=_poster_key
                # release instant-open handoff for Series: Details paints first,
                # then its normal async metadata/artwork lanes may enrich in-place.
                # Avoid synchronous HDD snapshot/bundle reads in the constructor.
                if isinstance(detail_item,dict) and self.media_type=="series":
                    detail_item["_ultra_fast_open"]=True
                    fast_bundle=dict(detail_item.get("_ultra_fast_bundle") or {}) if isinstance(detail_item.get("_ultra_fast_bundle"),dict) else {}
                    _handoff_poster=str(visible_poster or "")
                    if _handoff_poster and os.path.isfile(_handoff_poster):
                        fast_bundle["poster"]=_handoff_poster
                    elif palette_source and os.path.isfile(str(palette_source)):
                        fast_bundle["poster"]=str(palette_source)
                    back=str(detail_item.get("_backdrop_source_local") or detail_item.get("_cin_provider_backdrop_local") or "")
                    if back and os.path.isfile(back):
                        fast_bundle["backdrop"]=back
                    detail_item["_ultra_fast_bundle"]=fast_bundle
            except Exception as exc:
                optional_failure("ui.grid_palette_handoff",exc)
            self.session.openWithCallback(self._details_returned,ContentDetailsScreen,self.profile,self.client,self.media_type,detail_item)
