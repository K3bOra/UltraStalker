# -*- coding: utf-8 -*-
"""Shortcut overlay.

Methods moved verbatim out of ``PortalHomeScreen`` (ui_screens_home.py); behaviour is unchanged.
This module is imported by ui_screens_home.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, max, min
from .ui_screens_home import (
    _,
    ePoint,
    eSize,
    gFont,
    load_settings,
    optional_failure,
    parseColor,
)


class HomeShortcutsMixin(object):
    """Shortcut overlay."""

    def _sc_items(self):
        """(card title, setting key, default, ((value, label), ...)) for the seven cards."""
        return (
            (_("Live TV View"),"live_view_mode","columns",(("columns",_("3 Columns")),("classic",_("Classic list")),("wall",_("Logo wall")))),
            (_("Movies View"),"movies_view_mode","cinematic",tuple((v,_(l)) for v,l in self._SC_VIEWS)),
            (_("Series View"),"series_view_mode","cinematic",tuple((v,_(l)) for v,l in self._SC_VIEWS)),
            (_("Player View"),"player_view_mode","old",(("old","Player Old"),("new","Player New"),("new2","Player New 2"))),
            (_("Clean Display Names"),"clean_titles",True,((True,_("ON")),(False,_("OFF")))),
            (_("Info Bar Timeout"),"infobar_timeout",10,tuple((x,(_("Always On") if x==0 else _("%d seconds")%x)) for x in (3,6,10,15,30,0))),
            (_("Back"),None,None,()),
        )

    def _sc_value_index(self, item, cfg):
        title,key,default,options=item
        if not key:return 0
        current=cfg.get(key,default)
        if key=="infobar_timeout":
            try:current=int(current)
            except Exception:current=default
        elif key=="clean_titles":current=bool(current)
        else:current=str(current or default).lower()
        for i,(value,_label) in enumerate(options):
            if value==current:return i
        return 0

    def _sc_card_texts(self, slot, cfg=None):
        items=self._sc_items()
        item=items[slot]
        title,key,default,options=item
        if not key:return title.upper(),_("Home")
        cfg=cfg if cfg is not None else (load_settings() or {})
        label=options[self._sc_value_index(item,cfg)][1]
        if self._sc_edit and slot==self._sc_index:label="\u2039  %s  \u203a"%label
        return title.upper(),label

    def _sc_render(self):
        """Paint the seven cards in shortcut layout (icons hidden, setting + value)."""
        sx=float(getattr(self,"_home_sx",1.0) or 1.0);sy=float(getattr(self,"_home_sy",1.0) or 1.0)
        cfg=load_settings() or {}
        for slot in range(self.VISIBLE_CARD_COUNT):
            cx=self.CARD_X[slot]
            title,value=self._sc_card_texts(slot,cfg)
            focused=(slot==self._sc_index)
            try:self["menu_icon%d"%slot].hide()
            except Exception:pass
            self._home_icon_state[slot]=None
            try:
                inst=self["card_title%d"%slot].instance
                self["card_title%d"%slot].setText(title)
                if inst is not None:
                    inst.setFont(_ultra_rfont("Regular",18 if len(title)<=17 else 15))
                    inst.setForegroundColor(parseColor("#e2be6e"))
                    inst.move(ePoint(int((cx+13)*sx),int((534+30)*sy)));inst.resize(eSize(int(212*sx),int(32*sy)))
                self["card_title%d"%slot].show()
            except Exception as exc:optional_failure("ui.home_shortcut_title",exc)
            try:
                inst=self["card_sub%d"%slot].instance
                self["card_sub%d"%slot].setText(value)
                if inst is not None:
                    n=len(value)
                    inst.setFont(_ultra_rfont("Regular",30 if n<=9 else (26 if n<=13 else (22 if n<=17 else 18))))
                    inst.setForegroundColor(parseColor("#ffffff" if focused else "#d7dee2"))
                    inst.setNoWrap(1)
                    inst.move(ePoint(int((cx+13)*sx),int((534+84)*sy)));inst.resize(eSize(int(212*sx),int(56*sy)))
                self["card_sub%d"%slot].show()
            except Exception as exc:optional_failure("ui.home_shortcut_value",exc)

    def _sc_status(self):
        try:
            if self._sc_edit:self["status"].setText(_("LEFT / RIGHT Change • OK Done • BLUE Back"))
            else:self["status"].setText(_("LEFT / RIGHT Select • UP / DOWN Change • OK Edit • BLUE Back"))
        except Exception:pass

    def toggle_shortcuts(self):
        if getattr(self,"_sc_mode",False):return self._sc_exit()
        if getattr(self,"_screen_closed",False):return
        self._sc_saved=(self.index,self._menu_window_start,self.focus_row)
        self._sc_mode=True;self._sc_edit=False;self._sc_index=0
        self.focus_row="menu";self.index=0;self._menu_window_start=0
        self._sc_render();self._update_focus();self._sc_status()

    def _sc_exit(self):
        self._sc_mode=False;self._sc_edit=False
        saved=self._sc_saved or (0,0,"menu");self._sc_saved=None
        self.index,self._menu_window_start,self.focus_row=saved
        sx=float(getattr(self,"_home_sx",1.0) or 1.0);sy=float(getattr(self,"_home_sy",1.0) or 1.0)
        for slot in range(self.VISIBLE_CARD_COUNT):
            try:
                inst=self["card_title%d"%slot].instance
                if inst is not None:inst.resize(eSize(int(212*sx),int(32*sy)))
                sub=self["card_sub%d"%slot].instance
                if sub is not None:
                    sub.resize(eSize(int(212*sx),int(48*sy)));sub.setNoWrap(0)
                    sub.setFont(_ultra_rfont("Regular",14))  # shortcut mode used 18..30
                    sub.setForegroundColor(parseColor("#ffffff"))
            except Exception as exc:optional_failure("ui.home_shortcut_exit",exc)
        self._home_emph_done=False;self._home_icon_state={};self._home_focus_slot=-1
        self._render_menu_window(load_icons=True)
        self._update_focus()
        try:self._fit_home_localized_text()
        except Exception as exc:optional_failure("ui.home_shortcut_exit_fit",exc)

    def _home_cancel(self):
        if getattr(self,"_sc_mode",False):
            if self._sc_edit:
                self._sc_edit=False;self._sc_render();self._sc_status()
            else:self._sc_exit()
            return
        self.close()

    def _sc_horizontal(self, step):
        if self._sc_edit:return self._sc_change(step)
        target=max(0,min(self.VISIBLE_CARD_COUNT-1,self._sc_index+step))
        if target==self._sc_index:return
        self._sc_index=target;self.index=target
        self._sc_render();self._update_focus();self._sc_status()

    def _sc_ok(self):
        items=self._sc_items()
        if self._sc_index>=len(items) or not items[self._sc_index][1]:
            return self._sc_exit()
        self._sc_edit=not self._sc_edit
        self._sc_render();self._sc_status()

    def _sc_change(self, step):
        items=self._sc_items()
        if not (0<=self._sc_index<len(items)):return
        item=items[self._sc_index];title,key,default,options=item
        if not key or not options:return
        cfg=load_settings() or {}
        idx=(self._sc_value_index(item,cfg)+int(step))%len(options)
        value=options[idx][0]
        try:
            from .storage import save_settings as _sc_save
            _sc_save({key:value})
        except Exception as exc:
            optional_failure("ui.home_shortcut_save",exc);return
        if key=="clean_titles":
            self._home_clean_titles=bool(value)
            try:self._load_recent_cards()
            except Exception as exc:optional_failure("ui.home_shortcut_recent_refresh",exc)
        self._sc_render()
        try:self["status"].setText(_("Setting saved"))
        except Exception:pass
from .wqhd_layout import responsive_font as _ultra_rfont, factors as _ultra_factors

def _ultra_osd_scale():
    return _ultra_factors()[1]
