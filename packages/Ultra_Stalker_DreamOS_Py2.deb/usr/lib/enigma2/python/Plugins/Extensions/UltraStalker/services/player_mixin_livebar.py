# -*- coding: utf-8 -*-
"""The "lb" live/VOD info bar layout and text engine.

Methods moved verbatim out of ``UltraStalkerPlayer`` (player_native.py); behaviour is unchanged.
This module is imported by player_native.py once its module-level helpers exist, so the
names below are taken from that module (partially initialised at this point) on purpose.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .. import us_env as _us_env
from ..us_env import str, int, round, zip, max, min, us_clear
from .player_native import (
    Label,
    Pixmap,
    ProgressBar,
    _,
    _LB2_FIXED,
    _LB2_PANEL_DROP,
    _LB_CHIPS,
    _LB_DY,
    _LB_FONT_FACTORS,
    _LB_GEOM,
    _LB_LABELS,
    _LB_LEGACY,
    _LB_LEGACY_VOD,
    _LB_PIXMAPS,
    _LB_VOD_TYPES,
    _LB_WIDGETS,
    _asset,
    _clean_live_name,
    _is_subtitle_selected,
    _lb_lang_name,
    _lb_pill_width,
    _subtitle_track_lang,
    _track_prefs,
    _work_language_label,
    eTimer,
    gFont,
    load_settings,
    optional_failure,
    os,
    parseColor,
    re,
    time,
)


class PlayerLiveBarMixin(object):
    """The "lb" live/VOD info bar layout and text engine."""

    # ------------------------------------------------------------------
    # R5.541 Live InfoBar
    #
    # One static glass bar (assets_fhd/livebar) + runtime-measured labels.
    # Every text is measured with the receiver's own font (calculateSize), so
    # translated strings of any length/direction are fitted or ellipsised and
    # never overlap.  Colour keys keep the remote order red/green/yellow/blue
    # in every language.  Movies/Series/Episodes never call this code.
    # ------------------------------------------------------------------
    def _lb_init(self):
        for name in _LB_PIXMAPS:self[name]=Pixmap()
        for name in _LB_LABELS:self[name]=Label("")
        # Fill rasters are authored at native size and clipped to playback position.
        self["lb_prog"]=Pixmap()
        self["lb_buf"]=Pixmap()
        self._lb_vod_pos=(0,0);self._lb_buf_value=-1;self._lb_vod_meta_cache=None
        for name in _LB_WIDGETS:
            try:self[name].hide()
            except Exception:pass
        self._lb_sig={};self._lb_pix={};self._lb_visible=set()
        self._lb_title_full="";self._lb_epg_now=None;self._lb_epg_next=None
        self._lb_epg_now_text="";self._lb_epg_next_text="";self._lb_epg_state="none"
        self._lb_epg_expired=0;self._lb_prog_value=-1
        self._lb_sc=1.0
        try:
            cfg=load_settings() or {}
            self._lb_ff=min(1.15,float(_LB_FONT_FACTORS.get(str(cfg.get("font_scale") or "normal").lower(),1.0)))
            self._lb_show_numbers=bool(cfg.get("show_channel_numbers",True))
            # Settings > Media > Player View: "old" (default) keeps the classic
            # Player untouched; "new" enables this bar for Live, Movies and Series.
            _view=str(cfg.get("player_view_mode") or "old").strip().lower()
            self._lb_enabled=_view in ("new","new2")
            self._lb_variant="new2" if _view=="new2" else "new"
        except Exception:
            self._lb_ff=1.0;self._lb_show_numbers=True;self._lb_enabled=False;self._lb_variant="new"
        # Audio / subtitle language line (Player New / New 2, right column).
        self._lb_langs_last=None
        self.lb_langs_timer=eTimer();self.lb_langs_conn=None
        try:self.lb_langs_conn=self.lb_langs_timer.timeout.connect(self._lb_langs_update)
        except Exception:self.lb_langs_timer.callback.append(self._lb_langs_update)
        self.onFirstExecBegin.append(self._lb_langs_start)
        self.onClose.append(self._lb_langs_stop)

    def _lb_langs_start(self):
        if not getattr(self,"_lb_enabled",False):return
        try:self.lb_langs_timer.start(2000,False)
        except Exception as exc:optional_failure("player.lb_langs_timer",exc)

    def _lb_langs_stop(self):
        try:self.lb_langs_timer.stop()
        except Exception:pass
        try:
            if self.lb_langs_conn is not None:self.lb_langs_conn.disconnect()
        except Exception:pass

    def _lb_langs_text(self):
        """'Sub: Arabic  •  Audio: English' for the chosen / current tracks (never raises)."""
        sub=""
        try:
            if getattr(self,"_online_subtitle_active",False):
                sub=_lb_lang_name(getattr(self,"_online_subtitle_active_language","") or getattr(self,"_online_subtitle_language","")) or _("On")
            elif str(getattr(self,"_subtitle_source","") or "") in ("subssupport","subssupportpro"):
                sub=_("On")
            else:
                sel=getattr(self,"selected_subtitle",None)
                if _is_subtitle_selected(sel):
                    try:service=self.session.nav.getCurrentService()
                    except Exception:service=None
                    code=_subtitle_track_lang(service,sel)
                    sub=_lb_lang_name(code) or _("On")
                else:
                    # Not selected: show the languages the film itself carries, in brackets.
                    sub=_("Off")
                    codes=[]
                    for entry in (self._native_subtitle_track_list() or []):
                        try:code=_track_prefs.normalize_language(entry[4]) if len(entry)>4 else ""
                        except Exception:code=""
                        if code and code.upper() not in codes:codes.append(code.upper())
                    if codes:sub+=" (%s)"%", ".join(codes[:2])
        except Exception as exc:
            optional_failure("player.lb_langs_sub",exc);sub=""
        try:
            if str(getattr(self,"media_type","")) in ("vod","movie","series","episode","catchup","trailer"):
                audio=_(_work_language_label(getattr(self,"item",{}),getattr(self,"_history_item",{})))
            else:
                audio=_lb_lang_name(self._track_pref_current_audio_lang()) or _("Unknown")
        except Exception:audio=_("English") if str(getattr(self,"media_type","")) not in ("itv","live") else _("Unknown")
        parts=[]
        if sub:parts.append("%s: %s"%(_("Sub"),sub))
        if audio:parts.append("%s: %s"%(_("Audio"),audio))
        return "  \u2022  ".join(parts)

    def _lb_langs_update(self, force=False):
        if not self._lb_ready() or self.restored or getattr(self,"_closing_playback",False):return
        try:
            text=self._lb_langs_text()
            # A retry / reconnect message uses the same spot; it wins.
            if str(self["retry_status"].getText() or "").strip():text=""
        except Exception as exc:
            optional_failure("player.lb_langs_text",exc);return
        sig=(self._lb_sc,self._lb_variant,text)
        if not force and self._lb_langs_last==sig:return
        self._lb_langs_last=sig
        if not text:
            try:self["lb_langs"].setText("")
            except Exception:pass
            self._lb_show("lb_langs",False);return
        x,cy,w=(1540,968,296) if self._lb_variant=="new2" else (1616,975,220)
        fw,fh,size,shown=self._lb_fit("lb_langs",text,w-8,self._lb_font(15),max(10,self._lb_font(11)))
        self["lb_langs"].setText(shown)
        self._lb_text_box("lb_langs",x,cy,w,fh,size,"center")
        self._lb_colour("lb_langs","#b9c4cc")
        self._lb_show("lb_langs")

    def _lb_mode(self):
        """'live' for Live TV, 'vod' for Movies/Series/Episodes, '' otherwise."""
        if not getattr(self,"_lb_enabled",False):return ""
        media=str(getattr(self,"media_type","") or "").lower()
        if media in ("itv","live"):return "live"
        if media in _LB_VOD_TYPES:return "vod"
        return ""

    def _lb_active(self):
        return bool(self._lb_mode())

    def _lb_g(self):
        """Geometry of the active look/mode (never raises)."""
        return _LB_GEOM.get((self._lb_variant,self._lb_mode() or "live")) or _LB_GEOM[("new","live")]

    def _lb_colour(self, name, colour):
        """Set a label colour once (cached; skipped while the widget has no instance)."""
        key="col_"+name
        if self._lb_sig.get(key)==colour:return
        try:
            inst=self[name].instance
            if inst is not None:
                inst.setForegroundColor(parseColor(colour));self._lb_sig[key]=colour
        except Exception as exc:optional_failure("player.live_bar_colour",exc)

    def _lb_ready(self):
        """Live mode and the skin widgets exist (never cache a pre-layout pass)."""
        try:return self._lb_active() and self["lb_bg"].instance is not None
        except Exception:return False

    def _lb_font(self, base):
        return max(10,int(round(base*self._lb_ff*self._lb_sc)))

    def _lb_hide(self):
        for name in _LB_WIDGETS:
            try:self[name].hide()
            except Exception:pass
        self._lb_visible=set()

    def _lb_suppress_legacy(self):
        mode=self._lb_mode()
        if not mode:return
        for name in (_LB_LEGACY if mode=="live" else _LB_LEGACY_VOD):
            try:self[name].hide()
            except Exception:pass

    def _lb_show(self, name, visible=True):
        try:
            if visible:
                self[name].show();self._lb_visible.add(name)
            else:
                self[name].hide();self._lb_visible.discard(name)
        except Exception as exc:optional_failure("player.live_bar_show",exc)

    def _lb_place(self, name, x, y, w, h):
        sc=self._lb_sc
        # V9.2.2-r12: both new looks sit on the bottom edge like Player Old (key bar ends at y=1076).
        y=y+_LB_DY.get(self._lb_variant,0.0)
        # R21: Player New 2 floating panels sit 12 px lower, so only 4 px stay between them and the
        # key dock (the strip of subtitle that peeked through the gap is gone). Dock, engine
        # capsule, colour keys and the poster stay where they were.
        if self._lb_variant=="new2" and name not in _LB2_FIXED and not name.startswith("key_"):
            y=y+_LB2_PANEL_DROP
        self._localized_player_rect(name,x*sc,y*sc,max(1.0,w)*sc,max(1.0,h)*sc)

    def _lb_align(self, name, horizontal="center", vertical="center"):
        inst=self[name].instance
        if inst is None:return
        try:
            from ..label_align import halign as _h, valign as _v
            inst.setHAlign(_h(horizontal));inst.setVAlign(_v(vertical))
        except Exception as exc:optional_failure("player.live_bar_align",exc)

    def _lb_pixmap(self, name, rel):
        path=_asset(rel)
        if not os.path.isfile(path):
            self._lb_show(name,False);return False
        inst=self[name].instance
        if inst is None:return False
        if self._lb_pix.get(name)!=path:
            inst.setPixmapFromFile(path);self._lb_pix[name]=path
        return True

    def _lb_measure(self, name, text, size):
        """Pixel size of ``text`` in widget ``name`` at font ``size`` (design units)."""
        widget=self[name];inst=widget.instance
        widget.setText(str(text or ""))
        if inst is None:return 0.0,0.0
        inst.setFont(gFont("Regular",int(size)))
        try:inst.setNoWrap(1)
        except Exception:pass
        sc=self._lb_sc or 1.0
        # The clock ticks every second with digit templates, so the same text
        # is measured again and again: remember the answer (cheap on slow boxes).
        cache=self.__dict__.setdefault("_lb_measure_cache",{})
        key=(name,str(text or ""),int(size),sc)
        hit=cache.get(key)
        if hit is not None:return hit
        try:
            s=inst.calculateSize();w=float(s.width());h=float(s.height())
        except Exception:
            w=h=0.0
        if w>0:w=w*1.03+8.0   # safety margin: some images measure a little short and clip the last glyph
        if w>0 and _us_env.IS_DREAMOS:w+=2.0+0.25*float(int(size))  # DreamOS under-measures by ~1 glyph
        res=(w/sc,h/sc)
        if len(cache)>400:us_clear(cache)
        if w>0:cache[key]=res
        return res

    def _lb_fit(self, name, text, max_w, big, small):
        """Largest font in [small,big] that fits; otherwise ellipsis at ``small``.

        Returns (width, height, font_size, shown_text).  Text is cut on its
        logical end, so Arabic/Persian keep their right-to-left reading order.
        """
        text=" ".join(str(text or "").split())
        if not text:
            self[name].setText("");return 0.0,0.0,big,""
        max_w=max(8.0,float(max_w))
        for size in range(int(big),int(small)-1,-1):
            w,h=self._lb_measure(name,text,size)
            if w<=max_w:return w,h,size,text
        size=int(small);strip=" -–•|,:;"
        lo,hi=0,len(text)
        while lo<hi:
            mid=(lo+hi+1)//2
            w,h=self._lb_measure(name,text[:mid].rstrip(strip)+"…",size)
            if w<=max_w:lo=mid
            else:hi=mid-1
        shown=(text[:lo].rstrip(strip)+"…") if lo>0 else "…"
        w,h=self._lb_measure(name,shown,size)
        return min(w,max_w),h,size,shown

    def _lb_text_box(self, name, x, cy, w, h, size, horizontal="left"):
        """Place a measured single-line label; height follows the real font height."""
        lh=max(h,size/float(self._lb_sc or 1.0))+6
        self._lb_place(name,x,cy-lh/2.0,w,lh)
        self._lb_align(name,horizontal,"center")

    def _lb_place_poster(self, x, bottom):
        # Keep the frame inside the OSD, level with the bar or key dock.
        y = bottom - 365
        self._lb_place("logo", x + 8, y + 8, 232, 349)
        self._lb_place("lb_poster_edge", x, y, 248, 365)
        if self._lb_pixmap("lb_poster_edge", "player/infobar_premium/poster.png"):
            self._lb_show("lb_poster_edge")

    def _lb2_static(self, mode):
        """Player New 2: floating panels + key dock (and the poster edge for Movies/Series)."""
        if mode=="live":
            self._lb_place("live_picon",96,804,220,132)
            self._lb_show("lb_buf",False);self._lb_show("lb_poster_edge",False)
            specs=(("lb2_left",56,772,300,216,"livebar2/island_left_300x216.png"),
                   ("lb2_center",384,772,1100,216,"livebar2/island_center_live_1100x216.png"),
                   ("lb2_right",1512,772,352,216,"livebar2/island_right_352x216.png"),
                   ("lb2_dock",384,1004,1100,58,"livebar2/dock_1100x58.png"),
                   ("lb2_eng",1512,1004,352,58,"livebar2/dock_right_352x58.png"))
        else:
            # Poster bottom lines up with the key dock's bottom edge (y=1062).
            self._lb_place_poster(56, 1062)
            self._lb_show("lb2_left",False)
            specs=(("lb2_center",316,772,1172,216,"livebar2/island_center_vod_1172x216.png"),
                   ("lb2_right",1512,772,352,216,"livebar2/island_right_352x216.png"),
                   ("lb2_dock",316,1004,1172,58,"livebar2/dock_1172x58.png"),
                   ("lb2_eng",1512,1004,352,58,"livebar2/dock_right_352x58.png"))
        for name,x,y,w,h,rel in specs:
            self._lb_place(name,x,y,w,h)
            if self._lb_pixmap(name,rel):self._lb_show(name)

    def _live_bar_apply(self, force=False):
        if not self._lb_ready():return
        try:
            self._lb_suppress_legacy()
            sc=self._localized_player_scale()
            if sc!=self._lb_sc:
                self._lb_sc=sc;force=True
            mode=self._lb_mode()
            new2=self._lb_variant=="new2"
            if force or self._lb_sig.get("static")!=mode:
                self._lb_prog_value=-1;self._lb_buf_value=-1
                px,py,pw_=self._lb_g()["prog"]
                self._lb_place("lb_prog",px,py,pw_,4)
                self._lb_place("lb_buf",px,py,pw_,4)
                if new2:
                    self._lb_show("lb_bg",False)
                    self._lb2_static(mode)
                    if mode!="live":
                        self._lb_place("skip_hint",1540,946,296,26);self._lb_align("skip_hint","center","center")
                else:
                    self._lb_place("lb_bg",40,800,1840,250)
                    if mode=="live":
                        self._lb_place("live_picon",76,833,220,132)
                        self._lb_show("lb_buf",False)
                        self._lb_show("lb_poster_edge",False)
                    else:
                        self._lb_place_poster(32, 1050)
                        self._lb_place("skip_hint",1616,998,220,30);self._lb_align("skip_hint","right","center")
                        try:
                            inst=self["skip_hint"].instance
                            if inst is not None:inst.setFont(gFont("Regular",self._lb_font(22)));inst.setNoWrap(1)
                        except Exception as exc:optional_failure("player.live_bar_skip_font",exc)
                    self._lb_pixmap("lb_bg","livebar/bar_1840x250.png" if mode=="live" else "livebar/bar_vod_1840x250.png")
                self._lb_sig["static"]=mode
            if not new2:self._lb_show("lb_bg")
            self._lb_layout_live_badge(force)
            self._lb_layout_top(force)
            self._lb_layout_epg(force)
            self._lb_layout_keys(force)
            self._lb_layout_right(force)
            for name in tuple(self._lb_visible):
                try:self[name].show()
                except Exception:pass
        except Exception as exc:optional_failure("player.live_bar_apply",exc)

    def _lb_layout_live_badge(self, force=False):
        if not self._lb_ready():return
        if self._lb_mode()!="live":
            self._lb_show("lb_live_pill",False);self._lb_show("lb_live",False);return
        text=_("LIVE")
        sig=(self._lb_sc,text)
        if not force and self._lb_sig.get("live")==sig:return
        size=self._lb_font(16)
        w,h,size,shown=self._lb_fit("lb_live",text,204,size,max(10,size-5))
        pw=_lb_pill_width(w+36,84,240)
        bx,by=self._lb_g()["badge"]
        x=bx-pw/2.0
        if self._lb_pixmap("lb_live_pill","livebar/live_%d.png"%pw):
            self._lb_place("lb_live_pill",x,by,pw,26);self._lb_show("lb_live_pill")
        self._lb_place("lb_live",x,by,pw,26);self._lb_align("lb_live")
        self["lb_live"].setText(shown);self._lb_show("lb_live")
        self._lb_sig["live"]=sig

    def _lb_channel_number(self):
        if not self._lb_show_numbers:return ""
        rows=[]
        try:
            index=int(getattr(self,"_zap_index",0) or 0);channels=getattr(self,"_zap_channels",[]) or []
            if 0<=index<len(channels) and isinstance(channels[index],dict):rows.append(channels[index])
        except Exception:pass
        if not rows and isinstance(self.item,dict):rows.append(self.item)
        for row in rows:
            value=str(row.get("number") or row.get("num") or "").strip()
            if value.isdigit() and 0<int(value)<100000:return str(int(value))
        return ""

    def _lb_chip_texts(self):
        """Compact Live chips: quality, audio, video, fps, stream, engine (player)."""
        labels={"aac":"AAC","dd":"DD","ddplus":"DD+","atmos":"ATMOS","truehd":"TRUEHD","dts":"DTS","dtshd":"DTS-HD","pcm":"PCM"}
        def qclass(value):
            q=str(value or "").upper()
            if "4K" in q or "UHD" in q:return "4K"
            if "FULL" in q or "FHD" in q or "1080" in q:return "FULL HD"
            if "HD" in q or "720" in q:return "HD"
            if "SD" in q:return "SD"
            return ""
        qtext=""
        if self._lb_mode()=="vod":
            sources=(getattr(self,"_observed_quality",""),) if getattr(self,"_vod_quality_badge_locked",False) else ((getattr(self,"_observed_quality",""),getattr(self,"_static_quality","")) if str(getattr(self,"media_type","")).lower() in ("catchup","trailer") else ())
        else:
            sources=(self["video_quality"].getText(),getattr(self,"_observed_quality",""),getattr(self,"_static_quality",""))
        for source in sources:
            qtext=qclass(source)
            if qtext:break
        # The chip shows the real picture size (1920x800), not a class name.
        qtext=self._real_resolution_text() or qtext
        akey=str(getattr(self,"_audio_format_badge_key","") or "").strip().lower()
        if not akey:
            try:akey=str(self._audio_signature_badge_key((str(self["audio_codec"].getText() or ""),)) or "").lower()
            except Exception:akey=""
        atext=labels.get(akey,"")
        if not atext:
            raw=" ".join(str(self["audio_codec"].getText() or "").split())
            if raw and raw.upper()!="AUDIO" and raw!=_("AUDIO"):atext=self._lb_short(raw,14)
        vraw=" ".join(str(self["video_codec"].getText() or "").split())
        vtext="" if (not vraw or vraw.upper()=="VIDEO" or vraw==_("VIDEO")) else self._lb_short(vraw,12)
        fps=self._fps_snap(self._current_fps())
        engine=str(self["engine"].getText() or "").strip()
        for word in ("Native","Engine"):
            if engine==word or engine.startswith(word+" "):
                engine=_(word)+engine[len(word):];break
        # 4K / FULL HD / HD / SD stay as the universal TV labels in every
        # language (a translated "full high definition" does not fit a chip).
        return (("q",qtext),("ac",atext),("vc",vtext),
                ("fps",("%d %s"%(fps,_("FPS"))) if fps else ""),("st",_("STREAM")),("eng",engine))

    @staticmethod
    def _lb_short(text, limit):
        """Keep whole words of a technical label (e.g. 'H.265 HEVC Main10' -> 'H.265 HEVC')."""
        text=str(text or "").strip()
        if len(text)<=limit:return text
        cut=text[:limit+1].rsplit(" ",1)[0].strip()
        cut=cut if cut else text[:limit]
        # Never leave an opened bracket without its closing one ("H.264 (MPEG4").
        for opener,closer in (("(",")"),("[","]")):
            if cut.count(opener)>cut.count(closer):
                head=cut.rsplit(opener,1)[0].strip()
                cut=head if head else cut.replace(opener,"")
        return cut

    def _lb_layout_top(self, force=False):
        """Channel number + name on the left, technical chips right-aligned."""
        if not self._lb_ready():return
        if self._lb_mode()=="live":
            # R20: Player New 2 has no good spot for the number badge, so it is not drawn there.
            num="" if self._lb_variant=="new2" else self._lb_channel_number()
        else:
            try:num=str(self._episode_marker_text() or "")
            except Exception:num=""
        title=str(self._lb_title_full or "")
        if not title:
            try:title=_clean_live_name(str(self.name or ""),self._cfg_clean_titles)[:180]
            except Exception:title=str(self.name or "")[:180]
        chips=list((k,t) for k,t in self._lb_chip_texts() if t)
        # Player New 2: the player engine has its own capsule next to the key dock, so the
        # chip row keeps its room for the quality / audio / video / FPS / stream chips.
        eng_text=""
        if self._lb_variant in ("new","new2"):
            eng_text=next((t for k,t in chips if k=="eng"),"")
            chips=list((k,t) for k,t in chips if k!="eng")
        sig=(self._lb_sc,num,title,tuple(chips),eng_text)
        if not force and self._lb_sig.get("top")==sig:return
        g=self._lb_g()
        left,right,cy=g["L"],g["R"],g["top_cy"]
        x=left
        if num:
            size=self._lb_font(20)
            w,h,size,shown=self._lb_fit("lb_num",num,170,size,max(12,size-4))
            pw=_lb_pill_width(w+26,48,200)
            corner=g.get("num_corner")
            nx,ny=(corner if corner else (x,cy-18))
            if self._lb_pixmap("lb_num_pill","livebar/num_%d.png"%pw):
                self._lb_place("lb_num_pill",nx,ny,pw,36);self._lb_show("lb_num_pill")
            self._lb_place("lb_num",nx,ny,pw,36);self._lb_align("lb_num")
            self["lb_num"].setText(shown);self._lb_show("lb_num")
            if not corner:x+=pw+14
        else:
            self._lb_show("lb_num_pill",False);self._lb_show("lb_num",False)
        # Chips: shrink the font first, then drop the least important chips.
        # Quality and the player engine always stay.
        gap=8.0;min_name=240.0
        active=list(chips)
        size=self._lb_font(18);floor=max(12,self._lb_font(15))
        while True:
            widths={}
            for key,text in active:
                w,h=self._lb_measure("lb_c_"+key,text,size)
                widths[key]=_lb_pill_width(w+28,48,420)
            total=sum(widths.values())+gap*max(0,len(active)-1)
            if not active or total<=right-x-20-min_name:break
            if size>floor:
                size-=1;continue
            drop=list(k for k in ("st","fps","vc","ac") if k in dict(active))
            if not drop:break
            active=list((k,t) for k,t in active if k!=drop[0])
        cx=right-(sum(widths.values())+gap*max(0,len(active)-1)) if active else right
        chips_left=cx
        shown_keys=set()
        for key,text in active:
            pw=widths[key];style="n"   # V9.2.2-r12: the quality chip is no longer gold
            if self._lb_pixmap("lb_cbg_"+key,"livebar/chip_%s_%d.png"%(style,pw)):
                self._lb_place("lb_cbg_"+key,cx,cy-17,pw,34);self._lb_show("lb_cbg_"+key)
            w,h=self._lb_measure("lb_c_"+key,text,size)
            self._lb_place("lb_c_"+key,cx,cy-17,pw,34);self._lb_align("lb_c_"+key)
            self._lb_show("lb_c_"+key);shown_keys.add(key)
            cx+=pw+gap
        for key in _LB_CHIPS:
            if key not in shown_keys:
                self._lb_show("lb_cbg_"+key,False);self._lb_show("lb_c_"+key,False)
        if self._lb_variant=="new2":
            if eng_text:
                try:
                    inst=self["lb_c_eng"].instance
                    if inst is not None:inst.setFont(gFont("Regular",self._lb_font(19)))
                    self["lb_c_eng"].setText(eng_text)
                except Exception as exc:optional_failure("player.live_bar_engine_font",exc)
                self._lb_place("lb_c_eng",1512,1004,352,58);self._lb_align("lb_c_eng")
                self._lb_show("lb_c_eng")
            else:
                self._lb_show("lb_c_eng",False)
        elif self._lb_variant=="new":
            # Player New: the engine chip sits at the bottom of the right column, under the
            # Portal and Buffer lines, which leaves the whole chip row to the title.
            if eng_text:
                esize=self._lb_font(17);efloor=max(11,self._lb_font(12))
                while True:
                    ew,eh=self._lb_measure("lb_c_eng",eng_text,esize)
                    epw=_lb_pill_width(ew+28,48,420)
                    if epw<=200 or esize<=efloor:break
                    esize-=1
                ex=1726-epw/2.0;ey=1000
                if self._lb_pixmap("lb_cbg_eng","livebar/chip_n_%d.png"%epw):
                    self._lb_place("lb_cbg_eng",ex,ey,epw,34);self._lb_show("lb_cbg_eng")
                try:
                    inst=self["lb_c_eng"].instance
                    if inst is not None:inst.setFont(gFont("Regular",esize))
                    self["lb_c_eng"].setText(eng_text)
                except Exception as exc:optional_failure("player.live_bar_engine_font_new",exc)
                self._lb_place("lb_c_eng",ex,ey,epw,34);self._lb_align("lb_c_eng")
                self._lb_show("lb_c_eng")
        # Channel name gets everything between the number pill and the chips.
        room=(chips_left-20.0 if active else right)-x
        big=self._lb_font(g["top_big"]);small=max(14,self._lb_font(g["top_small"]))
        w,h,size,shown=self._lb_fit("channel",title,room,big,small)
        try:
            self["channel"].setText(shown)
            self._lb_text_box("channel",x,cy,min(room,w+8),h,size,"left")
            if shown:self["channel"].show()
        except Exception as exc:optional_failure("player.live_bar_title",exc)
        self._lb_sig["top"]=sig

    @staticmethod
    def _lb_clock(ts):
        try:return time.strftime("%H:%M",time.localtime(int(ts)))
        except Exception:return ""

    def _lb_epg_advance(self):
        """Roll Next into Now once the current programme has ended."""
        now=time.time()
        cur=self._lb_epg_now;nxt=self._lb_epg_next
        if cur and cur[1] and now>=cur[1]:
            if nxt and nxt[0] and nxt[0]<=now and (not nxt[1] or now<nxt[1]):
                self._lb_epg_now=nxt;self._lb_epg_next=None
                self._lb_epg_now_text=nxt[2];self._lb_epg_next_text=""
            if self._lb_epg_expired!=cur[1]:
                self._lb_epg_expired=cur[1]
                try:self._refresh_live_epg()
                except Exception as exc:optional_failure("player.live_bar_epg_refresh",exc)

    def _lb_fill(self, name, ratio):
        """Clip a native-size raster. No receiver-side scaling is required."""
        px,py,pw=self._lb_g()["prog"]
        ratio=max(0.0,min(1.0,float(ratio)))
        sc=self._lb_sc
        nw,nh=int(round(pw*sc)),max(1,int(round(4*sc)))
        typ="progress" if name=="lb_prog" else "buffer"
        rel="livebar/native_%s_%dx%d.png"%(typ,nw,nh)
        self._lb_pixmap(name,rel)
        # Round the endpoint in native pixels before clipping the line.
        end=int(round((px+pw*ratio)*sc))-int(round(px*sc))
        self._lb_place(name,px,py,max(1,end)/sc,4)
        self._lb_show(name,ratio>0)

    def _lb_progress(self):
        cur=self._lb_epg_now;now=time.time()
        if cur and cur[0] and cur[1] and cur[1]>cur[0] and cur[0]<=now<cur[1]:
            value=int(max(0,min(1000,(now-cur[0])*1000.0/(cur[1]-cur[0]))))
            if value!=self._lb_prog_value:
                self._lb_prog_value=value
                try:self._lb_fill("lb_prog",value/1000.0)
                except Exception:pass
            self._lb_show("lb_prog",value>0)
        else:
            self._lb_prog_value=-1
            self._lb_show("lb_prog",False);self._lb_show("lb_head",False)

    def _lb_layout_epg(self, force=False):
        """Now/Next rows: time column, title (fitted/ellipsised), remaining/duration."""
        if not self._lb_ready():return
        if self._lb_mode()=="vod":
            self._lb_layout_vod_rows(force);return
        if self._lb_variant=="new2":
            self._lb2_layout_live_rows(force);return
        self._lb_epg_advance()
        cur=self._lb_epg_now;nxt=self._lb_epg_next;now=time.time()
        now_title=self._lb_epg_now_text;next_title=self._lb_epg_next_text
        placeholder=""
        if not now_title and not next_title:
            placeholder=_("Loading EPG...") if self._lb_epg_state=="loading" else _("No EPG information")
        def times(ev):
            if ev and ev[0] and ev[1]:return "%s - %s"%(self._lb_clock(ev[0]),self._lb_clock(ev[1]))
            return ""
        now_time=times(cur) if now_title else ""
        next_time=times(nxt) if next_title else ""
        now_left=""
        if now_title and cur and cur[1] and now<cur[1]:
            now_left=_("%d min left")%max(1,int((cur[1]-now+59)//60))
        next_dur=""
        if next_title and nxt and nxt[0] and nxt[1] and nxt[1]>nxt[0]:
            next_dur=_("%s min")%int(round((nxt[1]-nxt[0])/60.0))
        sig=(self._lb_sc,now_title,next_title,placeholder,now_time,next_time,now_left,next_dur)
        self._lb_progress()
        if not force and self._lb_sig.get("epg")==sig:return
        left,right=332.0,1572.0
        rows=(("now",now_title or placeholder,now_time,now_left,904.0,28,22,22),
              ("next",next_title,next_time,next_dur,944.0,24,20,20))
        # One shared time column so both titles start on the same line.
        tsize={}
        col=0.0
        for key,_title,ttext,_r,_cy,_b,_s,tbase in rows:
            size=self._lb_font(tbase);tsize[key]=size
            if ttext:
                w,h=self._lb_measure("lb_%s_time"%key,ttext,size)
                col=max(col,w)
        col=(col+20.0) if col else 0.0
        for key,title,ttext,rtext,cy,big,small,tbase in rows:
            tname="lb_%s_time"%key;rname="lb_now_left" if key=="now" else "lb_next_dur";xname="lb_%s_title"%key
            if ttext:
                w,h=self._lb_measure(tname,ttext,tsize[key])
                self._lb_text_box(tname,left,cy,w+6,h,tsize[key],"left");self._lb_show(tname)
            else:
                self[tname].setText("");self._lb_show(tname,False)
            rw=0.0
            if rtext:
                rs=self._lb_font(20)
                rw,rh,rs,rshown=self._lb_fit(rname,rtext,220.0,rs,max(12,self._lb_font(14)))
                self[rname].setText(rshown)
                self._lb_text_box(rname,right-rw-6,cy,rw+6,rh,rs,"right");self._lb_show(rname)
            else:
                self[rname].setText("");self._lb_show(rname,False)
            tx=left+col;room=right-tx-((rw+24.0) if rw else 0.0)
            if title:
                w,h,size,shown=self._lb_fit(xname,title,room,self._lb_font(big),max(12,self._lb_font(small)))
                self[xname].setText(shown)
                self._lb_text_box(xname,tx,cy,min(room,w+8),h,size,"left");self._lb_show(xname)
            else:
                self[xname].setText("");self._lb_show(xname,False)
        try:
            colour="#8c96a0" if (placeholder and not now_title) else "#ffffff"
            if self._lb_sig.get("now_colour")!=colour and self["lb_now_title"].instance is not None:
                self["lb_now_title"].instance.setForegroundColor(parseColor(colour));self._lb_sig["now_colour"]=colour
        except Exception as exc:optional_failure("player.live_bar_epg_colour",exc)
        self._lb_sig["epg"]=sig

    # ---------------- Movies / Series / Episodes rows ----------------
    def _lb_episode_name(self):
        """Real episode name for the Player New info row ("" when there is none)."""
        try:
            if self.media_type not in ("series","episode"):return ""
            item=self.item if isinstance(self.item,dict) else {}
            cached=getattr(self,"_lb_ep_name_cache",None)
            if cached and cached[0]==id(item):return cached[1]
            from ..episode_labels import episode_name
            name=episode_name(item)
            self._lb_ep_name_cache=(id(item),name)
            return name
        except Exception as exc:
            optional_failure("player.live_bar_episode_name",exc)
            return ""

    def _lb_vod_meta(self):
        """(info line, plot) from the catalogue item; cached per title."""
        item=self.item if isinstance(self.item,dict) else {}
        key=(id(item),str(item.get("id") or ""),str(item.get("cmd") or item.get("name") or ""),self.media_type)
        cached=self._lb_vod_meta_cache
        if cached and cached[0]==key:return cached[1],cached[2]
        parent=item.get("_quality_parent_item") if isinstance(item.get("_quality_parent_item"),dict) else {}
        def clean(value):
            if isinstance(value,(list,tuple)):
                value=", ".join(str((v.get("name") if isinstance(v,dict) else v) or "").strip() for v in value[:2])
            text=" ".join(str(value or "").replace("\n"," ").split()).strip()
            return "" if text.lower() in ("none","null","n/a","0") else text
        def first(keys,sources=(item,parent)):
            for src in sources:
                for k in keys:
                    v=clean(src.get(k)) if isinstance(src,dict) else ""
                    if v:return v
            return ""
        parts=[]
        # The real episode name is its own gold label in front of this line
        # (see _lb_episode_name / _lb_layout_vod_rows), not part of the text.
        year=first(("year",))
        if not re.fullmatch(r"(19|20)\d\d",year or ""):
            year=first(("release_date","first_air_date","air_date"))[:4]
        if re.fullmatch(r"(19|20)\d\d",year or ""):parts.append(year)
        genre=first(("genres_str","genre","genres"))
        if genre:
            genre=", ".join([g.strip() for g in genre.split(",") if g.strip()][:2])
            if genre:parts.append(genre)
        rating=first(("rating_imdb","vote_average","rating"))
        try:
            value=float(str(rating).replace(",","."))
            if 0<value<=10:parts.append("%.1f/10"%value)
        except Exception:pass
        info=" • ".join(parts)
        if not info:
            try:info=self._category_label()
            except Exception:info=""
        plot=first(("overview","plot","description","descr"))
        self._lb_vod_meta_cache=(key,info,plot)
        return info,plot

    def _lb_vod_tick(self, position, duration):
        """Called with every playback time update (1 s and after each seek)."""
        if self._lb_mode()!="vod":return
        try:
            position=max(0,int(position or 0));duration=max(0,int(duration or 0))
        except Exception:
            position=duration=0
        if duration>0:position=min(position,duration)
        self._lb_vod_pos=(position,duration)
        if not self._lb_ready():return
        try:
            if duration>0:
                ratio=float(position)/float(duration)
                value=int(max(0,min(1000,round(ratio*1000.0))))
                if value!=self._lb_prog_value:
                    self._lb_prog_value=value
                    self._lb_fill("lb_prog",value/1000.0)
                self._lb_show("lb_prog",value>0)
                fill=None
                try:fill=self._buffer_fill_ratio(ratio)
                except Exception:fill=None
                if fill is not None and fill>ratio+0.002:
                    bvalue=int(max(0,min(100,round(fill*100.0))))
                    if bvalue!=self._lb_buf_value:
                        self._lb_buf_value=bvalue;self._lb_fill("lb_buf",fill)
                    self._lb_show("lb_buf")
                else:
                    self._lb_buf_value=-1;self._lb_show("lb_buf",False)
            else:
                self._lb_prog_value=-1;self._lb_buf_value=-1
                for name in ("lb_prog","lb_head","lb_buf"):self._lb_show(name,False)
            self._lb_layout_vod_rows()
        except Exception as exc:optional_failure("player.live_bar_vod_tick",exc)

    def _lb_layout_vod_rows(self, force=False):
        """Row 1: elapsed | info line | -remaining.  Row 2: duration | plot | ends at."""
        if not self._lb_ready() or self._lb_mode()!="vod":return
        if self._lb_variant=="new2":
            self._lb2_layout_vod_rows(force);return
        position,duration=self._lb_vod_pos
        fmt=self._format_player_pts
        elapsed=fmt(position) if (position>0 or duration>0) else ""
        total=fmt(duration) if duration>0 else ""
        remaining=("-"+fmt(duration-position)) if duration>0 else ""
        ends=""
        if duration>0:
            try:ends=_("Ends at %s")%time.strftime("%H:%M",time.localtime(time.time()+(duration-position)/90000.0))
            except Exception:ends=""
        info,plot=self._lb_vod_meta()
        ename=self._lb_episode_name()
        is_series=self.media_type in ("series","episode")
        left,right=332.0,1572.0
        # Widths come from digit templates, so the titles never jitter while
        # the clock runs (proportional digits on some receiver fonts).
        tsize_now=self._lb_font(22);tsize_next=self._lb_font(20);rsize=self._lb_font(20)
        def template(text):return re.sub(r"\d","8",text or "")
        col=0.0
        for name,text,size in (("lb_now_time",elapsed,tsize_now),("lb_next_time",total,tsize_next)):
            if text:col=max(col,self._lb_measure(name,template(text),size)[0])
        col=(col+20.0) if col else 0.0
        rw_now=min(220.0,self._lb_measure("lb_now_left",template(remaining),rsize)[0]) if remaining else 0.0
        rw_next=min(240.0,self._lb_measure("lb_next_dur",ends,rsize)[0]) if ends else 0.0
        sig=(self._lb_sc,info,plot,ename,int(col),int(rw_now),int(rw_next),bool(elapsed),bool(total))
        relayout=force or self._lb_sig.get("vod")!=sig
        rows=(("now",elapsed,tsize_now,remaining,rw_now,info,28,22,904.0),
              ("next",total,tsize_next,ends,rw_next,plot,24,20,944.0))
        for key,ttext,tsize,rtext,rw,title,big,small,cy in rows:
            tname="lb_%s_time"%key;rname="lb_now_left" if key=="now" else "lb_next_dur";xname="lb_%s_title"%key
            if ttext:
                w,h=self._lb_measure(tname,ttext,tsize)
                if relayout:self._lb_text_box(tname,left,cy,col-6.0,h,tsize,"left")
                self._lb_show(tname)
            else:
                self[tname].setText("");self._lb_show(tname,False)
            if rtext:
                w,h=self._lb_measure(rname,rtext,rsize)
                if relayout:self._lb_text_box(rname,right-rw-12,cy,rw+12,h,rsize,"right")
                self._lb_show(rname)
            else:
                self[rname].setText("");self._lb_show(rname,False)
            if not relayout:continue
            tx=left+col;room=right-tx-((rw+28.0) if rw else 0.0)
            side=max(col,rw+28.0)+8.0
            cx=left+side;cw=max(120.0,(right-left)-2*side)
            if key=="now":
                if is_series and ename:wname,label,other="lb_ep_name",ename,"lb_now_title"
                else:wname,label,other="lb_now_title",info,"lb_ep_name"
                centered=True
            else:
                wname,other=xname,None
                if is_series:label,centered=(info if ename else ""),True
                else:label,centered=plot,False
            if other:
                try:self[other].setText("")
                except Exception:pass
                self._lb_show(other,False)
            if label:
                try:
                    w,h,size,shown=self._lb_fit(wname,label,cw if centered else room,self._lb_font(big),max(12,self._lb_font(small)))
                    self[wname].setText(shown)
                    if centered:self._lb_text_box(wname,cx,cy,cw,h,size,"center")
                    else:self._lb_text_box(wname,tx,cy,min(room,w+8),h,size,"left")
                    self._lb_show(wname)
                except Exception as exc:
                    optional_failure("player.live_bar_vod_row_layout",exc)
            else:
                try:self[wname].setText("")
                except Exception:pass
                self._lb_show(wname,False)
        if relayout:
            try:
                if self._lb_sig.get("now_colour")!="#e2be6e" and self["lb_now_title"].instance is not None:
                    self["lb_now_title"].instance.setForegroundColor(parseColor("#e2be6e"));self._lb_sig["now_colour"]="#e2be6e"
            except Exception as exc:optional_failure("player.live_bar_vod_colour",exc)
            self._lb_sig["vod"]=sig

    # ---------------- Player New 2 rows (floating panels) ----------------
    def _lb2_hide_text(self, *names):
        for name in names:
            try:self[name].setText("")
            except Exception:pass
            self._lb_show(name,False)

    def _lb2_layout_live_rows(self, force=False):
        """Live: programme time, big title + minutes left, progress, Next row."""
        self._lb_epg_advance()
        cur=self._lb_epg_now;nxt=self._lb_epg_next;now=time.time()
        now_title=self._lb_epg_now_text;next_title=self._lb_epg_next_text
        placeholder=""
        if not now_title and not next_title:
            placeholder=_("Loading EPG...") if self._lb_epg_state=="loading" else _("No EPG information")
        def times(ev):
            if ev and ev[0] and ev[1]:return "%s - %s"%(self._lb_clock(ev[0]),self._lb_clock(ev[1]))
            return ""
        now_time=times(cur) if now_title else ""
        next_time=times(nxt) if next_title else ""
        now_left=""
        if now_title and cur and cur[1] and now<cur[1]:
            now_left=_("%d min left")%max(1,int((cur[1]-now+59)//60))
        next_dur=""
        if next_title and nxt and nxt[0] and nxt[1] and nxt[1]>nxt[0]:
            next_dur=_("%s min")%int(round((nxt[1]-nxt[0])/60.0))
        sig=("n2",self._lb_sc,now_title,next_title,placeholder,now_time,next_time,now_left,next_dur)
        self._lb_progress()
        if not force and self._lb_sig.get("epg")==sig:return
        g=self._lb_g();left,right=g["L"],g["R"]
        for name,colour in (("lb_now_time","#e2be6e"),("lb_now_left","#c8e6d6"),("lb_next_time","#8c96a0"),
                            ("lb_next_title","#a9b4be"),("lb_next_dur","#8c96a0")):
            self._lb_colour(name,colour)
        # Row A: programme time (gold)
        if now_time:
            size=self._lb_font(20)
            w,h=self._lb_measure("lb_now_time",now_time,size)
            self._lb_text_box("lb_now_time",left,860.0,w+6,h,size,"left");self._lb_show("lb_now_time")
        else:
            self._lb2_hide_text("lb_now_time")
        # Row B: big title, minutes left on the right
        rw=0.0
        if now_left:
            rs=self._lb_font(20)
            rw,rh,rs,rshown=self._lb_fit("lb_now_left",now_left,220.0,rs,max(12,self._lb_font(14)))
            self["lb_now_left"].setText(rshown)
            self._lb_text_box("lb_now_left",right-rw-6,899.0,rw+6,rh,rs,"right");self._lb_show("lb_now_left")
        else:
            self._lb2_hide_text("lb_now_left")
        title=now_title or placeholder
        if title:
            room=right-left-((rw+24.0) if rw else 0.0)
            w,h,size,shown=self._lb_fit("lb_now_title",title,room,self._lb_font(36),max(14,self._lb_font(26)))
            self["lb_now_title"].setText(shown)
            self._lb_text_box("lb_now_title",left,899.0,min(room,w+8),h,size,"left");self._lb_show("lb_now_title")
        else:
            self._lb2_hide_text("lb_now_title")
        self._lb_colour("lb_now_title","#8c96a0" if (placeholder and not now_title) else "#ffffff")
        # Row C: Next
        col=0.0
        tsz=self._lb_font(18)
        if next_time:
            w,h=self._lb_measure("lb_next_time",next_time,tsz)
            self._lb_text_box("lb_next_time",left,967.0,w+6,h,tsz,"left");self._lb_show("lb_next_time")
            col=w+22.0
        else:
            self._lb2_hide_text("lb_next_time")
        dw=0.0
        if next_dur:
            dw,h,dsz,dshown=self._lb_fit("lb_next_dur",next_dur,200.0,tsz,max(12,self._lb_font(14)))
            self["lb_next_dur"].setText(dshown)
            self._lb_text_box("lb_next_dur",right-dw-6,967.0,dw+6,h,dsz,"right");self._lb_show("lb_next_dur")
        else:
            self._lb2_hide_text("lb_next_dur")
        if next_title:
            room=right-left-col-((dw+24.0) if dw else 0.0)
            w,h,size,shown=self._lb_fit("lb_next_title",next_title,room,self._lb_font(22),max(12,self._lb_font(17)))
            self["lb_next_title"].setText(shown)
            self._lb_text_box("lb_next_title",left+col,967.0,min(room,w+8),h,size,"left");self._lb_show("lb_next_title")
        else:
            self._lb2_hide_text("lb_next_title")
        self._lb2_hide_text("lb_ep_name")
        self._lb_sig["epg"]=sig

    def _lb2_layout_vod_rows(self, force=False):
        """Movies/Series: info row, progress, elapsed/remaining, duration | plot | ends at."""
        position,duration=self._lb_vod_pos
        fmt=self._format_player_pts
        elapsed=fmt(position) if (position>0 or duration>0) else ""
        total=fmt(duration) if duration>0 else ""
        remaining=("-"+fmt(duration-position)) if duration>0 else ""
        ends=""
        if duration>0:
            try:ends=_("Ends at %s")%time.strftime("%H:%M",time.localtime(time.time()+(duration-position)/90000.0))
            except Exception:ends=""
        info,plot=self._lb_vod_meta()
        ename=self._lb_episode_name()
        g=self._lb_g();left,right=g["L"],g["R"]
        s_el=self._lb_font(19);s_tot=self._lb_font(17);s_end=self._lb_font(17)
        def template(text):return re.sub(r"\d","8",text or "")
        col=0.0
        if total:col=self._lb_measure("lb_next_time",template(total),s_tot)[0]+20.0
        rw_rem=min(220.0,self._lb_measure("lb_now_left",template(remaining),s_el)[0]) if remaining else 0.0
        rw_end=min(240.0,self._lb_measure("lb_next_dur",ends,s_end)[0]) if ends else 0.0
        sig=("n2v",self._lb_sc,info,plot,ename,int(col),int(rw_rem),int(rw_end),bool(elapsed),bool(total))
        relayout=force or self._lb_sig.get("vod")!=sig
        for name,colour in (("lb_now_time","#ffffff"),("lb_now_left","#d4dde3"),("lb_next_time","#cfd8dd"),
                            ("lb_next_title","#aebcc6"),("lb_next_dur","#cfd8dd"),("lb_now_title","#e2be6e")):
            self._lb_colour(name,colour)
        # Elapsed (left) and remaining (right) under the progress line
        if elapsed:
            tw=self._lb_measure("lb_now_time",template(elapsed),s_el)[0] if relayout else 0.0
            w,h=self._lb_measure("lb_now_time",elapsed,s_el)
            if relayout:self._lb_text_box("lb_now_time",left,924.0,max(w,tw)+6,h,s_el,"left")
            self._lb_show("lb_now_time")
        else:
            self._lb2_hide_text("lb_now_time")
        if remaining:
            w,h=self._lb_measure("lb_now_left",remaining,s_el)
            if relayout:self._lb_text_box("lb_now_left",right-rw_rem-12,924.0,rw_rem+12,h,s_el,"right")
            self._lb_show("lb_now_left")
        else:
            self._lb2_hide_text("lb_now_left")
        # Bottom row: duration | plot | ends at
        if total:
            w,h=self._lb_measure("lb_next_time",total,s_tot)
            if relayout:self._lb_text_box("lb_next_time",left,958.0,col-6.0,h,s_tot,"left")
            self._lb_show("lb_next_time")
        else:
            self._lb2_hide_text("lb_next_time")
        if ends:
            w,h=self._lb_measure("lb_next_dur",ends,s_end)
            if relayout:self._lb_text_box("lb_next_dur",right-rw_end-12,958.0,rw_end+12,h,s_end,"right")
            self._lb_show("lb_next_dur")
        else:
            self._lb2_hide_text("lb_next_dur")
        if not relayout:return
        is_series=self.media_type in ("series","episode")
        full_w=right-left
        if is_series and ename:
            top_name,top_text,bot_text,other="lb_ep_name",ename,info,"lb_now_title"
        else:
            top_name,top_text,bot_text,other="lb_now_title",info,("" if is_series else plot),"lb_ep_name"
        self._lb2_hide_text(other)
        # Top row: series -> gold episode name, movie -> gold year / genre / rating, both centred
        if top_text:
            try:
                w,h,size,shown=self._lb_fit(top_name,top_text,full_w-40.0,self._lb_font(26),max(12,self._lb_font(20)))
                self["lb_ep_name" if top_name=="lb_ep_name" else top_name].setText(shown)
                self._lb_text_box(top_name,left,861.0,full_w,h,size,"center");self._lb_show(top_name)
            except Exception as exc:
                optional_failure("player.live_bar2_top_row",exc)
        else:
            self._lb2_hide_text(top_name)
        # Bottom row: series -> centred genre / rating (no plot), movie -> plot as before
        if bot_text:
            try:
                if is_series:
                    side=max(col,rw_end+28.0)+8.0
                    bw=max(120.0,full_w-2*side)
                    w,h,size,shown=self._lb_fit("lb_next_title",bot_text,bw,self._lb_font(20),max(12,self._lb_font(16)))
                    self["lb_next_title"].setText(shown)
                    self._lb_text_box("lb_next_title",left+side,958.0,bw,h,size,"center")
                else:
                    room=right-left-col-((rw_end+28.0) if rw_end else 0.0)
                    w,h,size,shown=self._lb_fit("lb_next_title",bot_text,room,self._lb_font(20),max(12,self._lb_font(16)))
                    self["lb_next_title"].setText(shown)
                    self._lb_text_box("lb_next_title",left+col,958.0,min(room,w+8),h,size,"left")
                self._lb_show("lb_next_title")
            except Exception as exc:
                optional_failure("player.live_bar2_bottom_row",exc)
        else:
            self._lb2_hide_text("lb_next_title")
        self._lb_sig["vod"]=sig

    def _lb_set_epg(self, now_event=None, next_event=None, now_text="", next_text="", state=None):
        self._lb_epg_now=now_event;self._lb_epg_next=next_event
        self._lb_epg_now_text=str(now_text or "");self._lb_epg_next_text=str(next_text or "")
        if state:self._lb_epg_state=state
        self._lb_prog_value=-1
        if self._lb_active():
            try:self._lb_layout_epg(force=True)
            except Exception as exc:optional_failure("player.live_bar_epg",exc)

    def _lb_layout_keys(self, force=False):
        """Colour keys inside the bar: red, green, yellow, blue in remote order."""
        if not self._lb_ready():return
        colours=("red","green","yellow","blue")
        labels=(_("Exit") if self._lb_mode()=="live" else _("Buffer"),_("Aspect Ratio"),_("Subtitles"),_("Search"))
        sig=(self._lb_sc,labels)
        if not force and self._lb_sig.get("keys")==sig:
            for colour in colours:
                self._lb_show("key_dash_"+colour);self._lb_show("key_"+colour)
            return
        left,right,cy=self._lb_g()["keys"]
        slot=(right-left)/4.0
        line_w,line_x,join=38.0,9.0,12.0   # visible dash inside the 56x42 key asset
        big=self._lb_font(20);small=max(12,self._lb_font(16))
        for i,(colour,text) in enumerate(zip(colours,labels)):
            name="key_"+colour
            w,h,size,shown=self._lb_fit(name,text,slot-line_w-join-12,big,small)
            group=line_w+join+w
            gx=left+i*slot+(slot-group)/2.0
            self._lb_place("key_dash_"+colour,gx-line_x,cy-21,56,42)
            self[name].setText(shown)
            self._lb_text_box(name,gx+line_w+join,cy,w+8,h,size,"left")
            try:self[name].instance.setNoWrap(1)
            except Exception:pass
            self._lb_show("key_dash_"+colour);self._lb_show(name)
        self._lb_sig["keys"]=sig

    def _lb_layout_right(self, force=False):
        """Right column under the clock: portal, buffer and retry status."""
        if not self._lb_ready():return
        portal=str(getattr(self,"_active_server_name","") or "").strip()
        sig=(self._lb_sc,portal)
        if (force or self._lb_sig.get("right")!=sig) and self._lb_variant=="new2":
            # Clock + date come from the skin (centred in the right panel).
            size=self._lb_font(22)
            w,h,size,shown=self._lb_fit("server_name",portal,280,size,max(12,self._lb_font(16)))
            self["server_name"].setText(shown)
            self._lb_text_box("server_name",1540,925,296,h,size,"center")
            self._lb_colour("server_name","#e2be6e")
            self._lb_place("buffer_status",1540,941,296,22);self._lb_align("buffer_status","center","center")
            self._lb_place("retry_status",1540,968,296,22);self._lb_align("retry_status","center","center")
            try:
                for _n in ("retry_status","buffer_status"):
                    inst=self[_n].instance
                    if inst is not None:inst.setFont(gFont("Regular",self._lb_font(15)));inst.setNoWrap(1)
            except Exception as exc:optional_failure("player.live_bar_status_font2",exc)
            self._lb_sig["right"]=sig
        elif force or self._lb_sig.get("right")!=sig:
            size=self._lb_font(22)
            w,h,size,shown=self._lb_fit("server_name",portal,216,size,max(12,self._lb_font(17)))
            self["server_name"].setText(shown)
            self._lb_text_box("server_name",1616,914,220,h,size,"center")   # centred in the right column
            try:
                if self["server_name"].instance is not None:
                    self["server_name"].instance.setForegroundColor(parseColor("#e2be6e"))
            except Exception:pass
            self._lb_place("buffer_status",1616,935,220,26);self._lb_align("buffer_status","center","center")
            self._lb_place("retry_status",1616,960,220,22);self._lb_align("retry_status","center","center")
            try:
                inst=self["retry_status"].instance
                if inst is not None:inst.setFont(gFont("Regular",self._lb_font(15)));inst.setNoWrap(1)
                inst=self["buffer_status"].instance
                if inst is not None:inst.setFont(gFont("Regular",self._lb_font(16)));inst.setNoWrap(1)
            except Exception as exc:optional_failure("player.live_bar_status_font",exc)
            self._lb_sig["right"]=sig
        if portal:self._lb_show("server_name")
        else:self._lb_show("server_name",False)
        self._lb_langs_update(force=True)

    def _lb_fit_status(self, name):
        """Shrink (never wrap) a status line so it stays inside the right column."""
        if not self._lb_ready():return
        try:
            text=str(self[name].getText() or "")
            if self._lb_sig.get("status_"+name)==text:return
            w,h,size,shown=self._lb_fit(name,text,self._lb_g().get("status_w",214),self._lb_font(16),max(10,self._lb_font(12)))
            self[name].setText(shown);self._lb_sig["status_"+name]=shown
        except Exception as exc:optional_failure("player.live_bar_status_fit",exc)
