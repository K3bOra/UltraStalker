"""Request-scoped deadlines and first-paint sharing for Search only."""
from __future__ import absolute_import, division, print_function, unicode_literals
from .. import us_env as _us_env
from ..us_env import max, min
__metaclass__ = type  # new-style classes on Python 2
threading = _us_env.threading
time = _us_env.time


class SearchCancel:
    def __init__(self, parent, seconds):
        self.parent = parent
        self.deadline = time.monotonic() + max(0.01, float(seconds))
        self.event = threading.Event()

    def set(self):
        self.event.set()

    def is_set(self):
        return (self.event.is_set() or time.monotonic() >= self.deadline
                or (self.parent is not None and self.parent.is_set()))

    def wait(self, seconds):
        end = min(self.deadline, time.monotonic() + max(0.0, seconds))
        while not self.is_set() and time.monotonic() < end:
            self.event.wait(min(0.05, max(0.0, end - time.monotonic())))
        return self.is_set()


class SearchPosterFlights:
    """Share one title's two independent poster lanes, delivering first success.

    Owned by one screen generation. Workers only post messages; widgets and
    result identities remain owned by the GUI thread.
    """
    def __init__(self):
        self.lock = threading.RLock()
        self.jobs = {}

    def request(self, key, receive, lanes):
        with self.lock:
            job = self.jobs.setdefault(key, {"path": "", "receivers": [], "pending": 0, "lanes": set()})
            path = job["path"]
            if not path:
                job["receivers"].append(receive)
                fresh = [lane for lane in lanes if lane not in job["lanes"]]
                job["lanes"].update(fresh)
                job["pending"] += len(fresh)
                return fresh
        receive(path)
        return []

    def publish(self, key, path):
        if not path:
            return
        with self.lock:
            job = self.jobs.get(key)
            if job is None or job["path"]:
                return
            job["path"] = path
            receivers, job["receivers"] = job["receivers"], []
        for receive in receivers:
            receive(path)

    def ready(self, key):
        with self.lock:
            return bool(self.jobs.get(key, {}).get("path"))

    def finish(self, key):
        with self.lock:
            job = self.jobs.get(key)
            if job is not None:
                job["pending"] -= 1
                # Keep attempted lanes until the page generation ends. A later
                # source may add fresh URLs without restarting the same failures.
                job["pending"] = max(0, job["pending"])
