# -*- coding: utf-8 -*-
"""Portal checks, check-all and portal open.

Methods moved verbatim out of ``PortalListScreen`` (ui_screens_portallist.py); behaviour is unchanged.
This module is imported by ui_screens_portallist.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, max, min
from .ui_screens_portallist import (
    LOG,
    MessageBox,
    ThreadPoolExecutor,
    _,
    _clear_profile_connections,
    _probe_provider_connections,
    _run_bounded_probes,
    diagnostic_failure,
    time,
)


class PortalListCheckMixin(object):
    """Portal checks, check-all and portal open."""

    def check_portal(self):
        idx = self._index()
        if idx is None or self._busy:
            return
        p = self.profiles[idx]; self["status"].setText(_("Checking portal..."))
        def work(handle):
            if handle.cancelled():return None
            # A real Check is deliberately patient.  Give slow providers enough
            # time to return account/profile telemetry instead of bailing early.
            started = time.monotonic(); client = _client_from_profile(p, timeout=15)
            try:
                cancel_event = getattr(handle, "cancel_event", None)
                if str(p.get("source_type") or "").lower() == "m3u" and hasattr(client, "probe"):
                    client.probe(cancel_event=cancel_event, allow_cache=False)
                info = client.account_info()
                if handle.cancelled():return None
                health_data = client.health_snapshot()
                health_latency = health_data.get("latency_ms") or int((time.monotonic() - started) * 1000)
                connections = _probe_provider_connections(client, info, cancel_event=cancel_event)
                if handle.cancelled():return None
                return (info, health_latency, health_data, client.security_warning, connections)
            finally:
                client.close()
        def ok(result):
            info, latency, health_data, security_warning, connections = result
            expiry = info.get("phone") or info.get("end_date") or info.get("expire_billing_date") or ""
            state = info.get("status") or info.get("account_status") or "ONLINE"
            warning = security_warning
            p["state"] = "%s%s%s" % (state, (" / " + str(expiry)) if expiry else "", (" / INSECURE HTTP" if warning else ""))
            p["account_state"] = str(state)
            p["expiry"] = str(expiry or "")
            p["latency_ms"] = health_data.get("latency_ms") or latency
            p["health"] = health_data.get("health") or ("online" if latency < 1500 else "slow")
            if connections:
                p["active_connections"] = int(connections["active"])
                p["max_connections"] = int(connections["max"])
                p["connections_source"] = "provider_exact"
            else:
                _clear_profile_connections(p)
            p["last_success"] = int(time.time()); p.pop("last_error", None)
            try:
                self._save_active_category_profiles(self.profiles)
                save_note = ""
            except Exception as exc:
                save_note = " (state not saved: %s)" % exc
            self.refresh()
            self["status"].setText((security_warning or _("Portal Connected")) + save_note)
        def fail(exc):
            p["state"]="OFFLINE"; p["health"]="offline"; p["last_error"]=str(exc)[:240]; p.pop("latency_ms", None)
            _clear_profile_connections(p)
            try: self._save_active_category_profiles(self.profiles)
            except Exception as exc: optional_failure("ui",exc)
            self.refresh(); self["status"].setText(_friendly_portal_error(exc))
        self._run_async(work, ok, fail)

    @staticmethod
    def _check_all_signature(profile):
        p = profile if isinstance(profile, dict) else {}
        return "|".join((
            str(p.get("source_type") or "stalker").strip().lower(),
            str(p.get("portal") or "").strip().rstrip("/").lower(),
            str(p.get("mac") or "").strip().upper(),
            str(p.get("username") or "").strip(),
        ))

    def _profile_was_checked(self, profile):
        p = profile if isinstance(profile, dict) else {}
        sig = self._check_all_signature(p)
        stored = str(p.get("check_all_signature") or "").strip()
        if stored:
            return stored == sig
        if p.get("check_all_checked_at"):
            return True
        # Migration for profiles checked by older builds before this explicit
        # marker existed. New imports have none of these persisted probe fields.
        health = str(p.get("health") or "").strip().lower()
        return bool((p.get("last_success") or p.get("last_error")) and health in ("excellent","online","slow","offline"))

    def check_all_portals(self):
        if self._busy or not self.profiles:
            return
        # R5.70: YELLOW re-checks every saved source.  The old "skip previously
        # checked" rule meant that, once a portal had ever connected, Check All
        # silently did nothing.
        snapshot = list(self.profiles)
        # Already-checked sources get a quick probe (short timeout, account only);
        # new / changed ones get the full check.  Quick ones run first.
        quick_ids = set(id(p) for p in snapshot if self._profile_was_checked(p))
        snapshot.sort(key=lambda p: 0 if id(p) in quick_ids else 1)
        n_quick = len(quick_ids)
        progress_jobs=self._portal_progress_jobs
        self._set_check_progress(_("Checking %d sources...") % len(snapshot))
        self._start_portal_progress_poll()

        def work(handle):
            total = len(snapshot)
            aborters={}
            cancel_event = getattr(handle, "cancel_event", None)

            def probe_one(profile, force_full=False):
                import threading
                stopped=threading.Event();current=[None]
                class Cancel(object):
                    def is_set(self):return stopped.is_set() or (cancel_event is not None and cancel_event.is_set())
                    def wait(self,timeout):
                        end=time.monotonic()+max(0,float(timeout))
                        while not self.is_set() and time.monotonic()<end:stopped.wait(min(0.1,max(0,end-time.monotonic())))
                        return self.is_set()
                cancel=Cancel()
                def abort():
                    stopped.set()
                    client=current[0]
                    if client is not None:
                        try:client.cancel_pending_requests()
                        except Exception:pass
                aborters[id(profile)]=abort
                deadline=threading.Timer(55.0,abort);deadline.daemon=True;deadline.start()
                quick=(id(profile) in quick_ids) and not force_full
                try:
                    for short in ((True,False) if quick else (False,)):
                        client=None
                        try:
                            if cancel.is_set():raise RuntimeError("Check cancelled or deadline exceeded")
                            started=time.monotonic()
                            client=_client_from_profile(profile,timeout=(6 if short else 15));current[0]=client
                            if not short and str(profile.get("source_type") or "").lower()=="m3u" and hasattr(client,"probe"):
                                client.probe(cancel_event=cancel,allow_cache=False)
                            try:info=client.account_info(cancel_event=cancel)
                            except TypeError:info=client.account_info()
                            if cancel.is_set():raise RuntimeError("Check deadline exceeded")
                            health_data=client.health_snapshot()
                            latency=health_data.get("latency_ms") or int((time.monotonic()-started)*1000)
                            connections=_probe_provider_connections(client,info,cancel_event=cancel)
                            expiry=info.get("phone") or info.get("end_date") or info.get("expire_billing_date") or ""
                            state=info.get("status") or info.get("account_status") or "ONLINE"
                            warning=getattr(client,"security_warning","")
                            label="%s%s%s"%(state,(" / "+str(expiry)) if expiry else "",(" / INSECURE HTTP" if warning else ""))
                            return (profile,True,label,latency,str(expiry or ""),str(state),connections)
                        except Exception as exc:
                            if not short or cancel.is_set():return (profile,False,"OFFLINE: %s"%str(exc)[:100],0,"","OFFLINE",None)
                        finally:
                            current[0]=None
                            if client is not None:
                                try:client.close()
                                except Exception:pass
                finally:
                    deadline.cancel();aborters.pop(id(profile),None)

            # R5.70b: a portal that never answers (dead socket, huge M3U) must not
            # hold Check All open or starve the sources queued behind it. Every
            # probe has its own time limit counted from its real start; one that
            # exceeds it is reported as "timeout" and its slot is released.
            results = []
            done = [0]

            def finish(profile, result):
                results.append(result)
                done[0] += 1
                if not handle.cancelled():
                    try:
                        progress_jobs.put((done[0], total, profile.get("name") or profile.get("portal") or "Portal", bool(result[1])))
                    except Exception as exc:
                        optional_failure("ui.portal_progress_queue", exc)

            def on_result(profile, result, error):
                if error is not None:
                    result = (profile, False, "OFFLINE: %s" % str(error)[:100], 0, "", "OFFLINE", None)
                finish(profile, result)

            def on_timeout(profile):
                finish(profile, (profile, False, "OFFLINE: timeout", 0, "", "OFFLINE", None))

            _run_bounded_probes(snapshot, probe_one, handle.cancelled, on_result, on_timeout,
                                slots=max(1, min(4, total)), limit=60.0,
                                cancel_probe=lambda profile:aborters.get(id(profile),lambda:None)())
            return results

        def ok(results):
            self._drain_portal_progress()
            self._pause_portal_progress_poll()
            failed = []
            checked_at = int(time.time())
            for profile, success, state, latency, expiry, account_state, connections in results:
                profile["check_all_checked_at"] = checked_at
                profile["check_all_signature"] = self._check_all_signature(profile)
                profile["state"] = state
                profile["account_state"] = account_state
                if expiry or not success or id(profile) not in quick_ids:
                    profile["expiry"] = expiry
                profile["health"] = ("excellent" if latency < 700 else ("online" if latency < 1500 else "slow")) if success else "offline"
                if latency:
                    profile["latency_ms"] = latency
                else:
                    profile.pop("latency_ms", None)
                if success:
                    if connections:
                        profile["active_connections"] = int(connections["active"])
                        profile["max_connections"] = int(connections["max"])
                        profile["connections_source"] = "provider_exact"
                    else:
                        # Every successful check now probes connection telemetry.
                        # Never retain an old count if this provider omitted it.
                        _clear_profile_connections(profile)
                    profile["last_success"] = int(time.time())
                    profile.pop("last_error", None)
                else:
                    _clear_profile_connections(profile)
                    profile["last_error"] = state[:240]
                    failed.append(profile)
            try:
                self._save_active_category_profiles(self.profiles)
            except Exception as exc:
                self._set_check_progress("")
                self["status"].setText(_("Checks done; save failed: %s") % exc)
                self.refresh()
                return
            self.refresh()
            self._set_check_progress("")
            # R5.72: the result stays in the header line (no popup panel).
            self._failed_profiles = failed
            if not failed:
                self._pt_flash_result(_("Check done  \u2022  all %d working") % len(results))
            else:
                self._pt_flash_result(_("Check done  \u2022  %d working  \u2022  %d failed") % (len(results)-len(failed), len(failed)))

        def failed_bulk(error):
            self._drain_portal_progress()
            self._pause_portal_progress_poll()
            self._set_check_progress("")
            self["status"].setText(_("Bulk check failed: %s") % error)
        if not self._run_async(work, ok, failed_bulk):
            self._pause_portal_progress_poll()

    def _portal_open_http_confirmed(self, answer):
        idx = getattr(self, "_http_open_index", None)
        self._http_open_index = None
        if not answer:
            self["status"].setText(_("HTTP portal was not opened"))
            return
        if idx is None or idx < 0 or idx >= len(self.profiles):
            return
        profile = mark_http_consent(self.profiles[idx], True)
        self.profiles[idx] = profile
        try:
            self._save_active_category_profiles(self.profiles)
        except Exception as exc:
            self.session.open(MessageBox, _("Could not save HTTP consent: %s") % exc, MessageBox.TYPE_ERROR, timeout=7)
            return
        try:
            self["list"].moveToIndex(idx)
        except Exception as exc:
            optional_failure("ui.http_consent_selection", exc)
        self.open_portal()

    def open_portal(self):
        _perf_t0 = time.monotonic()
        idx = self._index()
        if idx is None or self._busy:
            return
        profile=self.profiles[idx]
        LOG.info("PERF25 portal_open begin mono_ms=%d source_type=%s", int(_perf_t0 * 1000), str(profile.get("source_type") or "stalker")[:12])
        # Legacy/imported HTTP profiles may predate the explicit transport
        # consent field.  Require a one-time UI acknowledgement before the
        # first connection, then persist it so normal opens are not noisy.
        if requires_http_consent(profile.get("portal")) and not bool(profile.get("explicit_http_accepted", False)):
            self._http_open_index = idx
            self.session.openWithCallback(
                self._portal_open_http_confirmed, MessageBox,
                http_warning_for(profile.get("portal")), MessageBox.TYPE_YESNO
            )
            return
        try:
            _validate_profile_client(profile)
        except Exception as exc:
            self.session.open(MessageBox, _("Invalid profile: %s") % exc, MessageBox.TYPE_ERROR, timeout=7)
            return

        if str(profile.get("source_type") or "").lower()=="m3u":
            # Large get.php playlists can take minutes to download. Opening a
            # source must never block on a full catalogue parse/probe. Home and
            # the category screens load only what the user actually opens.
            self["status"].setText(_("Opening M3U playlist…"))
            _phase = time.monotonic()
            from .ui_screens_splash import HomeWarmupSplashScreen
            self.session.openWithCallback(self._portal_home_closed, HomeWarmupSplashScreen, profile, PortalHomeScreen)
            LOG.info("R268 portal_open warm_splash_return elapsed_ms=%d total_ms=%d", int((time.monotonic() - _phase) * 1000), int((time.monotonic() - _perf_t0) * 1000))
            return

        _phase = time.monotonic()
        from .ui_screens_splash import HomeWarmupSplashScreen
        self.session.openWithCallback(self._portal_home_closed, HomeWarmupSplashScreen, profile, PortalHomeScreen)
        LOG.info("R268 portal_open warm_splash_return elapsed_ms=%d total_ms=%d", int((time.monotonic() - _phase) * 1000), int((time.monotonic() - _perf_t0) * 1000))

    def _portal_home_closed(self, result=None):
        # Home can discover fresher account/expiry state than PortalList had at
        # construction time. Reload persisted profiles while preserving selection.
        try:
            idx=self._index()
            self.profiles=load_profiles()
            self.refresh()
            if idx is not None and self.profiles:
                try:self["list"].moveToIndex(max(0,min(int(idx),len(self.profiles)-1)))
                except Exception as exc: diagnostic_failure("ui.portallist.failsoft", exc)
            self._selection_changed()
        except Exception as exc:
            optional_failure("ui.portal_home_refresh", exc)
