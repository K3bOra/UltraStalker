# -*- coding: utf-8 -*-
"""Remembered audio / embedded-subtitle LANGUAGE per movie or series (R5.145).

Design rules (the previous attempt re-enabled subtitles again and again):
* the LANGUAGE is stored, never a track number - tracks differ between files;
* it is applied ONCE per playback by the Player, inside a short window, and never
  again; any manual audio/subtitle choice cancels the pending apply;
* only a title the user has explicitly chosen a track for has an entry, so every
  other title keeps the default behaviour (subtitles off, stream default audio);
* a series shares ONE entry for all its episodes.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .. import us_env as _us_env
from ..us_env import str, bytes, open, min, us_casefold

hashlib = _us_env.hashlib
json = _us_env.json
os = _us_env.os
re = _us_env.re
threading = _us_env.threading
time = _us_env.time

from ..log import optional_failure
from ..persistent_cache import ROOT as _ROOT, persistent_write_gate

_FILE = os.path.join(_ROOT, "index", "track_prefs.json")
_LOCK = threading.RLock()
_STATE = {}
_LOADED = False
_MAX = 300
_TTL = 365 * 86400

_CANON = {}
for _code, _names in (
    ("en", ("en", "eng", "english")), ("ar", ("ar", "ara", "arb", "arabic")),
    ("fr", ("fr", "fra", "fre", "french")), ("de", ("de", "deu", "ger", "german")),
    ("es", ("es", "spa", "spanish")), ("it", ("it", "ita", "italian")),
    ("tr", ("tr", "tur", "turkish")), ("ru", ("ru", "rus", "russian")),
    ("hi", ("hi", "hin", "hindi")), ("ja", ("ja", "jpn", "japanese")),
    ("ko", ("ko", "kor", "korean")), ("zh", ("zh", "zho", "chi", "chinese")),
    ("fa", ("fa", "fas", "per", "persian", "farsi")), ("pt", ("pt", "por", "portuguese")),
    ("nl", ("nl", "nld", "dut", "dutch")), ("pl", ("pl", "pol", "polish")),
    ("he", ("he", "heb", "hebrew")), ("ur", ("ur", "urd", "urdu")),
):
    for _n in _names:
        _CANON[_n] = _code


# Explicit aliases only. Codec descriptions must never become fake languages
# through the former arbitrary text[:3] fallback (AAC/ACC/AC3/PCM, etc.).
for _code, _names in (
    ("sv", ("sv", "swe", "swedish")), ("da", ("da", "dan", "danish")),
    ("no", ("no", "nor", "nb", "nob", "nn", "nno", "norwegian")),
    ("fi", ("fi", "fin", "finnish")), ("el", ("el", "ell", "gre", "greek")),
    ("cs", ("cs", "ces", "cze", "czech")), ("ro", ("ro", "ron", "rum", "romanian")),
    ("hu", ("hu", "hun", "hungarian")), ("uk", ("uk", "ukr", "ukrainian")),
    ("bg", ("bg", "bul", "bulgarian")), ("sr", ("sr", "srp", "serbian")),
    ("hr", ("hr", "hrv", "croatian")), ("th", ("th", "tha", "thai")),
    ("vi", ("vi", "vie", "vietnamese")), ("id", ("id", "ind", "indonesian")),
    ("ms", ("ms", "msa", "may", "malay")), ("bn", ("bn", "ben", "bengali")),
    ("ta", ("ta", "tam", "tamil")), ("te", ("te", "tel", "telugu")),
    ("ml", ("ml", "mal", "malayalam")), ("pa", ("pa", "pan", "punjabi")),
    ("ko", ("한국어", "한국말", "الكورية", "كوري", "كورية")),
    ("ar", ("العربية", "عربي", "عربى")),
    ("en", ("الإنجليزية", "الانجليزية", "إنجليزي", "انجليزي")),
):
    for _n in _names:
        _CANON[_n] = _code

_CODEC_LANGUAGE_JUNK = re.compile(
    r"\b(?:HE[- ]?AAC(?:[- ]?(?:V2|LC))?|AAC[- ]?(?:HE|LC)|E[- ]?AC[- ]?3|"
    r"AC[- ]?3|AAC|ACC|DTS(?:[- ]?HD)?|TRUEHD|DDP?|PCM|LPCM|MPEG(?:[- ]?[24])?|"
    r"MP[23]|FLAC|OPUS|VORBIS|WMA|SBR|DOLBY|DIGITAL|ATMOS)\b", re.I)


def normalize_language(raw):
    """Read explicit language tags/names, including names after codec text."""
    if isinstance(raw, bytes):
        raw = raw.decode("utf-8", "replace")
    text = us_casefold(str(raw or "").strip())
    if not text:
        return ""
    if text in _CANON:
        return _CANON[text]
    text = _CODEC_LANGUAGE_JUNK.sub(" ", text)
    for token in re.findall(r"[^\W\d_]+", text, flags=re.UNICODE):
        if token in _CANON:
            return _CANON[token]
    return ""


def track_language(info):
    """Selected track evidence only; conflicting tags remain unknown."""
    def read(name):
        try:
            getter = getattr(info, name, None)
            return normalize_language(getter()) if callable(getter) else ""
        except Exception:
            return ""
    tagged, described = read("getLanguage"), read("getDescription")
    if tagged and described and tagged != described:
        return ""
    return tagged or described


def series_key(profile, series_id):
    series_id = str(series_id or "").strip()
    if not series_id:
        return ""
    profile = profile if isinstance(profile, dict) else {}
    portal = str(profile.get("portal") or "").rstrip("/").lower()
    mac = str(profile.get("mac") or "").upper()
    raw = json.dumps(["series-tracks", portal, mac, series_id], ensure_ascii=False, separators=(",", ":"))
    return hashlib.sha1(raw.encode("utf-8", "ignore")).hexdigest()


def _load_locked():
    global _LOADED
    if _LOADED:
        return
    _LOADED = True
    try:
        if not os.path.isfile(_FILE):
            return
        with open(_FILE, "r", encoding="utf-8") as handle:
            payload = json.load(handle)
        rows = payload.get("items") if isinstance(payload, dict) else None
        if not isinstance(rows, dict):
            return
        now = time.time()
        for key, value in rows.items():
            if not isinstance(value, dict):
                continue
            try:
                saved = float(value.get("saved_at", 0) or 0)
            except Exception:
                saved = 0.0
            if saved and now - saved > _TTL:
                continue
            _STATE[str(key)] = {
                "audio": normalize_language(value.get("audio")),
                "sub": str(value.get("sub") or "")[:8],
                "saved_at": saved or now,
            }
    except Exception as exc:
        optional_failure("track_prefs.load", exc)


def _persist_locked():
    try:
        if not persistent_write_gate(_FILE):
            return
        os.makedirs(os.path.dirname(_FILE), mode=0o700, exist_ok=True)
        ordered = sorted(_STATE.items(), key=lambda kv: float(kv[1].get("saved_at", 0) or 0), reverse=True)[:_MAX]
        tmp = _FILE + ".tmp.%d.%d" % (os.getpid(), threading.get_ident())
        with open(tmp, "w", encoding="utf-8") as handle:
            json.dump({"version": 1, "items": dict(ordered)}, handle, ensure_ascii=False, separators=(",", ":"))
            handle.flush()
            os.fsync(handle.fileno())
        try:
            os.chmod(tmp, 0o600)
        except Exception:
            pass
        os.replace(tmp, _FILE)
    except Exception as exc:
        optional_failure("track_prefs.save", exc)


def get(key):
    if not key:
        return {}
    with _LOCK:
        _load_locked()
        return dict(_STATE.get(str(key)) or {})


def put(key, audio=None, sub=None):
    """Update one entry.  ``audio``: language code; ``sub``: language code or 'off'."""
    if not key:
        return
    with _LOCK:
        _load_locked()
        row = dict(_STATE.get(str(key)) or {"audio": "", "sub": ""})
        if audio is not None:
            row["audio"] = normalize_language(audio)
        if sub is not None:
            row["sub"] = "off" if str(sub) == "off" else normalize_language(sub)
        row["saved_at"] = time.time()
        if _STATE.get(str(key)) == row:
            return
        _STATE[str(key)] = row
        while len(_STATE) > _MAX:
            oldest = min(_STATE.items(), key=lambda kv: float(kv[1].get("saved_at", 0) or 0))[0]
            _STATE.pop(oldest, None)
        _persist_locked()


def has(key):
    return bool(get(key))
