# -*- coding: utf-8 -*-
"""TMDb metadata loading and application, backdrop presentation and canonical visual identity.

Methods moved verbatim out of ``ContentDetailsScreen`` (ui_screens_details.py); behaviour is unchanged.
This module is imported by ui_screens_details.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, round, max, min
from .ui_screens_details import _, _age_rating_display, _clean_person_name, _clean_year_value, _details_backdrop_truth, _visual_source_fingerprint, durable_view_path, hashlib, os, reactor, weakref

class DetailsTmdbMixin(object):
    """TMDb metadata loading and application, backdrop presentation and canonical visual identity."""

    def _load_tmdb_metadata(self):
        cfg = load_settings()
        credential = str(cfg.get('tmdb_credential') or '').strip()
        self._tmdb_token += 1
        token = self._tmdb_token
        media_type = self.media_type
        item = dict(getattr(self, '_portal_item', self.item) or {}) if isinstance(getattr(self, '_portal_item', self.item), dict) else {}
        language = cfg.get('tmdb_language', 'ar-EG')
        timeout = min(6, max(3, int(cfg.get('timeout', 10) or 10)))
        hot = {}
        try:
            portal_item = getattr(self, '_portal_item', self.item)
            hot = load_detail_snapshot(self.profile, self.media_type, portal_item)
            art_hot = load_artwork_v2_manifest(self.profile, self.media_type, portal_item)
            art_hot_ok = bool(isinstance(art_hot, dict) and art_hot.get('matched') and (art_hot.get('identity_pointer_verified') or identity_cache_compatible(portal_item, art_hot)))
            if art_hot_ok:
                merged = dict(art_hot)
                if isinstance(hot, dict) and hot.get('_details_authority_ready'):
                    for _meta_key in ('overview', 'overview_language', 'description', 'plot', 'descr', 'genres', 'genre', 'cast', 'actors', 'actor', 'crew', 'directors', 'director', 'writers', 'writer', 'runtime', 'duration', 'time', 'length', 'number_of_seasons', 'seasons_count', 'season_count', 'number_of_episodes', 'episodes_count', 'episode_count', 'release_date', 'first_air_date', 'year', 'release_year', 'releaseDate', 'countries', 'country', 'country_code', 'production_country', 'production_countries', 'origin_country', 'rating', 'vote_count', 'original_language', 'certification', 'age_rating'):
                        merged.pop(_meta_key, None)
                merged.update(hot or {})
                hot = merged
                if art_hot.get('tmdb_id') and (not _detail_metadata_complete(hot)):
                    direct = load_detail_snapshot_by_tmdb(art_hot.get('media_type') or self.media_type, art_hot.get('tmdb_id'))
                    if isinstance(direct, dict) and direct:
                        enriched = dict(hot)
                        if direct.get('_details_authority_ready'):
                            for _meta_key in ('overview', 'overview_language', 'description', 'plot', 'descr', 'genres', 'genre', 'cast', 'actors', 'actor', 'crew', 'directors', 'director', 'writers', 'writer', 'runtime', 'duration', 'time', 'length', 'number_of_seasons', 'seasons_count', 'season_count', 'number_of_episodes', 'episodes_count', 'episode_count', 'release_date', 'first_air_date', 'year', 'release_year', 'releaseDate', 'countries', 'country', 'country_code', 'production_country', 'production_countries', 'origin_country', 'rating', 'vote_count', 'original_language', 'certification', 'age_rating'):
                                enriched.pop(_meta_key, None)
                        enriched.update(direct)
                        hot = enriched
            if isinstance(hot, dict) and hot.get('tmdb_id') and (not hot.get('identity_pointer_verified')) and (not identity_cache_compatible(portal_item, hot)):
                hot = {}
            if isinstance(hot, dict) and hot.get('matched') and hot.get('identity_verified'):
                source = str(hot.get('identity_source') or '')
                if source != 'portal_payload' and str(hot.get('source') or '').upper() != 'PORTAL':
                    self._tmdb_jobs.put((token, hot))
                poster_ok = bool(_verified_external_art(hot, 'poster'))
                backdrop_ok = bool(_details_backdrop_truth(_verified_external_art(hot, 'backdrop')))
                if hot.get('tmdb_id') and (hot.get('identity_verified') or hot.get('identity_pointer_verified') or hot.get('_details_authority_ready')):
                    item['_locked_tmdb_id'] = hot.get('tmdb_id')
                    item['_ultra_search_verified_tmdb_id'] = hot.get('tmdb_id')
                    item['_locked_tmdb_type'] = hot.get('media_type')
                try:
                    from .details_authority import metadata_language_ready
                    _language_ready = metadata_language_ready(hot, cfg)
                except Exception:
                    _language_ready = bool(hot.get('_details_authority_ready') and hot.get('tmdb_id'))
                if poster_ok and backdrop_ok and (source != 'portal_payload') and _detail_metadata_complete(hot) and _language_ready and (bool(hot.get('title_logo_checked')) or bool(hot.get('_details_authority_ready'))):
                    return None
        except Exception as exc:
            optional_failure('ui.hdd_hot_read', exc)
        if not credential:
            return None
        if not cfg.get('tmdb_enabled', True):
            return None
        cancel_event = self._details_cancel_event
        tmdb_jobs = self._tmdb_jobs
        profile = dict(self.profile or {})
        screen_ref = weakref.ref(self)
        provider_client = self.client
        content_key = str(getattr(self, '_details_content_key', '') or id(self))

        def _tok():
            owner = screen_ref()
            try:
                return int(getattr(owner, '_tmdb_token', token)) if owner is not None else token
            except Exception:
                return token

        def component_callback(kind, partial):
            owner = screen_ref()
            if owner is None or cancel_event.is_set():
                return
            try:
                reactor.callFromThread(owner._apply_first_paint_component, _tok(), kind, partial)
            except Exception:
                pass

        def clean_worker(base_data):
            if cancel_event.is_set() or not isinstance(base_data, dict) or (not base_data.get('tmdb_id')):
                return
            try:
                from .backdrop_clean_runtime import upgrade as _upgrade_clean_backdrop
                clean = _upgrade_clean_backdrop(profile, media_type, item, settings=cfg, cancel_event=cancel_event) or {}
                fresh = clean.get('data') if isinstance(clean, dict) else {}
                if isinstance(fresh, dict) and fresh and (not cancel_event.is_set()):
                    visual_keys = ('tmdb_id', 'media_type', 'poster_local', 'backdrop_local', 'poster_path', 'backdrop_path', 'poster_url', 'backdrop_url', '_backdrop_url', 'tmdb_backdrop_url', 'adaptive_primary', 'adaptive_secondary', 'adaptive_dark', 'adaptive_accent', 'adaptive_fingerprint', 'clean_backdrop_choice', 'clean_backdrop_iso', 'clean_backdrop_selector_version', 'backdrop_source', 'backdrop_state', 'identity_verified', 'identity_pointer_verified')
                    merged = dict(base_data)
                    for key in visual_keys:
                        value = fresh.get(key)
                        if value not in (None, '', [], {}):
                            merged[key] = value
                    tmdb_jobs.put((_tok(), merged))
            except Exception as _clean_exc:
                optional_failure('ui.details_clean_backdrop_upgrade', _clean_exc)

        def worker():
            if cancel_event.is_set():
                return
            try:
                from .details_authority import resolve_canonical
                data = resolve_canonical(profile, media_type, item, cancel_event=cancel_event, settings=cfg, provider_client=provider_client, provider_downloader=_download_portal_artwork, component_callback=component_callback) or {}
                if cancel_event.is_set():
                    return
                tmdb_jobs.put((_tok(), data if isinstance(data, dict) else {}))
                if isinstance(data, dict) and data.get('tmdb_id') and (not cancel_event.is_set()):
                    try:
                        clean_future = _DETAIL_PREFETCH_EXECUTOR.submit(clean_worker, dict(data), priority=3, _task_key='details-clean:%s' % content_key)
                        owner = screen_ref()
                        if owner is not None:
                            owner._track_details_future(clean_future)
                    except Exception as exc:
                        optional_failure('ui.details_clean_submit', exc)
            except Exception as exc:
                if not cancel_event.is_set():
                    tmdb_jobs.put((_tok(), {'matched': False, 'error': str(exc)}))
        try:
            future = _DETAIL_PREFETCH_EXECUTOR.submit(worker, priority=0, _task_key='details:%s' % str(getattr(self, '_details_content_key', '') or id(self)))
            self._track_details_future(future)
        except Exception as exc:
            optional_failure('ui', exc)

    def _backdrop_presentation_target(self, source):
        source = str(source or '')
        if not source or not os.path.isfile(source):
            return ''
        try:
            stamp = str(os.path.getmtime(source))
        except Exception:
            stamp = '0'
        digest = hashlib.sha1((source + '|' + stamp + '|us221-present-lower').encode('utf-8', 'ignore')).hexdigest()[:24]
        return durable_view_path('us221_detail_%s_1620x620_lower.png' % digest, source=source)

    def _schedule_backdrop_presentation(self, source, rank=5):
        source = str(source or '')
        if not source or not os.path.isfile(source) or self._screen_closed:
            return ''
        authority = str(getattr(self, '_details_backdrop_authority_source', '') or '')
        if getattr(self, '_details_backdrop_authority_locked', False) and authority:
            if os.path.abspath(source) != os.path.abspath(authority):
                return ''
            source = authority
        bundle = getattr(self, '_persistent_visual_bundle', {}) or {}
        target = self._backdrop_presentation_target(source)
        final_present = str(bundle.get('backdrop_present') or '')
        if final_present and target and (os.path.abspath(final_present) == os.path.abspath(target)) and os.path.isfile(final_present):
            self._persistent_backdrop_locked = True
            return final_present
        if target and _valid_cache_file(target):
            try:
                _save_visual_bundle(self.profile, self.media_type, getattr(self, '_portal_item', self.item), {'backdrop': source, 'backdrop_present': target}, snapshot=getattr(self, '_tmdb_data', None) or getattr(self, '_local_detail_cache', None))
                self._persistent_visual_bundle = _load_visual_bundle(self.profile, self.media_type, getattr(self, '_portal_item', self.item), getattr(self, '_tmdb_data', None) or getattr(self, '_local_detail_cache', None)) or bundle
                self._persistent_backdrop_locked = True
            except Exception as exc:
                optional_failure('ui.backdrop_present_lock', exc)
            return target
        if getattr(self, '_backdrop_present_pending', '') == source:
            return ''
        self._backdrop_present_pending = source
        self._backdrop_token += 1
        token = self._backdrop_token
        cancel_event = self._details_cancel_event
        backdrop_jobs = self._backdrop_jobs
        screen_ref = weakref.ref(self)

        def stale():
            screen = screen_ref()
            return bool(cancel_event.is_set() or screen is None or token != getattr(screen, '_backdrop_token', None))

        def worker():
            try:
                if stale():
                    return
                prepared = _build_integrated_backdrop(source, target, (1620, 620))
                if prepared and os.path.isfile(prepared) and (not stale()):
                    backdrop_jobs.put((token, prepared, int(rank or 5), source))
                else:
                    screen = screen_ref()
                    if screen is not None and token == getattr(screen, '_backdrop_token', None):
                        screen._backdrop_present_pending = ''
            except Exception as exc:
                screen = screen_ref()
                if screen is not None and token == getattr(screen, '_backdrop_token', None):
                    screen._backdrop_present_pending = ''
                optional_failure('ui.backdrop_present_worker', exc)
        try:
            future = _BACKDROP_PRESENT_EXECUTOR.submit(worker)
            self._track_details_future(future)
        except Exception as exc:
            optional_failure('ui.backdrop_present_submit', exc)
        return ''

    def _sync_search_visual_peers(self, data=None):
        """Publish one verified Details package to equivalent Search copies.

        Playback ownership is never shared: each peer keeps its own profile/id/
        command. Only verified TMDb metadata and paths to immutable HDD artwork/
        derived chrome are aliased. This is deliberately Search-scoped.
        """
        peers = list(getattr(self, '_search_visual_peers', []) or [])
        if not peers:
            return
        source = data if isinstance(data, dict) else {}
        local = getattr(self, '_local_detail_cache', {}) or {}
        if not source.get('tmdb_id') and isinstance(local, dict):
            source = local
        if not isinstance(source, dict) or not source.get('tmdb_id'):
            return
        trusted = bool(source.get('identity_verified') or source.get('identity_pointer_verified') or source.get('_details_authority_ready'))
        if not trusted:
            return
        tmdb_id = source.get('tmdb_id')
        snap = dict(local if isinstance(local, dict) and str(local.get('tmdb_id') or '') == str(tmdb_id) else source)
        if not snap.get('tmdb_id'):
            return
        payload = {}
        try:
            bundle = getattr(self, '_persistent_visual_bundle', {}) or {}
            if isinstance(bundle, dict):
                payload.update(bundle)
        except Exception:
            pass
        try:
            state = getattr(self, '_details_visual_state', {}) or {}
            if isinstance(state, dict):
                payload.update(state)
        except Exception:
            pass
        for key in ('poster_local', 'backdrop_local'):
            value = str(snap.get(key) or '')
            if value and os.path.isfile(value):
                payload['poster' if key == 'poster_local' else 'backdrop'] = value
        chrome = payload.get('chrome') if isinstance(payload.get('chrome'), dict) else {}
        fingerprint = '%s|%s|%s|%s|%s|%s|%s|%s' % (str(tmdb_id), str(payload.get('poster') or ''), str(payload.get('backdrop') or ''), str(payload.get('detail_poster') or ''), str(payload.get('backdrop_present') or ''), str(payload.get('theme') or ''), str(chrome.get('panel_detail') or ''), str(chrome.get('overview_detail') or ''))
        if fingerprint and fingerprint == str(getattr(self, '_search_peer_sync_fp', '') or ''):
            return
        for peer in peers:
            try:
                profile = peer.get('profile') or {}
                typ = peer.get('media_type') or self.media_type
                item = peer.get('item') or {}
                if not isinstance(item, dict):
                    continue
                trusted_peer = bool(peer.get('search_match_verified'))
                if not trusted_peer and (not identity_cache_compatible(item, snap)):
                    continue
                peer_item = dict(item)
                if trusted_peer:
                    peer_item['_ultra_search_verified_tmdb_id'] = tmdb_id
                    peer_item['_locked_tmdb_id'] = tmdb_id
                    peer_item['_locked_tmdb_type'] = snap.get('media_type') or ('tv' if typ == 'series' else 'movie')
                save_detail_snapshot(profile, typ, peer_item, snap)
                if payload:
                    _save_visual_bundle(profile, typ, peer_item, payload, snapshot=snap)
            except Exception as exc:
                optional_failure('ui.search_peer_publish', exc)
        self._search_peer_sync_fp = fingerprint

    def _commit_canonical_visual_identity(self, data):
        """Make one verified TMDb identity own poster and backdrop together.

        Grid/provider artwork is deliberately allowed for instant first paint.
        Once Details has a verified, provider-compatible TMDb identity, however,
        poster/backdrop derivatives and locks from any provisional identity must
        stop owning the screen. This is the Olympus-style correction path.
        """
        if not isinstance(data, dict) or not data.get('tmdb_id'):
            return
        trusted = bool(data.get('identity_verified') or data.get('identity_pointer_verified') or data.get('_details_authority_ready'))
        if not trusted:
            return
        if not identity_cache_compatible(getattr(self, '_portal_item', self.item), data):
            return
        canonical_id = str(data.get('tmdb_id') or '')
        canonical_type = str(data.get('media_type') or ('tv' if self.media_type == 'series' else 'movie'))
        previous_id = str(getattr(self, '_canonical_visual_tmdb_id', '') or '')
        previous_type = str(getattr(self, '_canonical_visual_media_type', '') or '')
        identity_changed = bool(previous_id and previous_id != canonical_id or (previous_type and previous_type != canonical_type))
        self._canonical_visual_tmdb_id = canonical_id
        self._canonical_visual_media_type = canonical_type
        poster = str(data.get('poster_local') or '')
        _entry_poster_locked = bool(getattr(self, '_entry_visible_poster_locked', False) and getattr(self, '_poster_authoritative_source', '') and os.path.isfile(str(getattr(self, '_poster_authoritative_source', '') or '')))
        if poster and os.path.isfile(poster) and (not _entry_poster_locked):
            old = str(getattr(self, '_poster_authoritative_source', '') or '')
            if old != poster or identity_changed:
                self._poster_prepare_token = int(getattr(self, '_poster_prepare_token', 0) or 0) + 1
                self._persistent_poster_locked = False
                self._persistent_detail_poster_locked = False
                bundle = dict(getattr(self, '_persistent_visual_bundle', {}) or {})
                fp = _visual_source_fingerprint(poster)
                if str(bundle.get('detail_poster_source_fp') or '') != fp:
                    bundle.pop('detail_poster', None)
                    bundle.pop('detail_poster_source_fp', None)
                    bundle.pop('detail_poster_final', None)
                    self._details_visual_state.pop('detail_poster', None)
                    self._details_visual_state.pop('detail_poster_source_fp', None)
                bundle['poster'] = poster
                self._persistent_visual_bundle = bundle
                self._poster_authoritative_source = poster
                self._adaptive_authoritative_source = poster
                self._details_visual_state['poster'] = poster
                self._image_token += 1
                self._decode_picture(poster)
        backdrop = str(data.get('backdrop_local') or '')
        if _details_backdrop_truth(backdrop):
            old = str(getattr(self, '_details_backdrop_authority_source', '') or '')
            if old != backdrop or identity_changed:
                fp = _visual_source_fingerprint(backdrop)
                bundle = dict(getattr(self, '_persistent_visual_bundle', {}) or {})
                if str(bundle.get('backdrop_present_source_fp') or '') != fp:
                    bundle.pop('backdrop_present', None)
                    bundle.pop('backdrop_present_source_fp', None)
                    bundle.pop('backdrop_final', None)
                    self._details_visual_state.pop('backdrop_present', None)
                bundle['backdrop'] = backdrop
                self._persistent_visual_bundle = bundle
                self._details_backdrop_authority_source = backdrop
                self._details_backdrop_authority_locked = True
                self._portal_backdrop_source_local = backdrop
                self._persistent_backdrop_source_locked = False
                self._persistent_backdrop_locked = False
                self._details_visual_state['backdrop'] = backdrop
                self._schedule_backdrop_presentation(backdrop, 5)
        try:
            self._persist_visual_bundle_async(self._details_visual_state, data)
        except Exception as exc:
            optional_failure('ui.canonical_visual_bundle_persist', exc)

    def _apply_tmdb_metadata(self, data):
        if not isinstance(data, dict):
            return None
        if data.get('matched') and data.get('tmdb_id') and (not data.get('identity_pointer_verified')) and (not identity_cache_compatible(getattr(self, '_portal_item', self.item), data)):
            data = {'matched': False, 'reason': 'identity_guard_rejected', 'confidence': float(data.get('confidence') or 0)}
        previous_good = self._tmdb_data if isinstance(getattr(self, '_tmdb_data', None), dict) and self._tmdb_data.get('matched') and self._tmdb_data.get('identity_verified') else None
        identity_source = str(data.get('identity_source') or '')
        confidence = float(data.get('confidence') or 0)
        evidence = int(data.get('identity_evidence') or 0)
        trusted_identity = bool((data.get('identity_verified') or data.get('identity_pointer_verified')) and data.get('tmdb_id') and (str(data.get('source') or '').upper() != 'PORTAL'))
        if data.get('matched') and trusted_identity:
            if getattr(self, '_is_xtream_item', False):
                try:
                    if not (_verified_external_art(data, 'poster') and _details_backdrop_truth(_verified_external_art(data, 'backdrop'))):
                        self._schedule_xtream_auto_retry()
                except Exception:
                    pass
            try:
                if data.get('tmdb_id') and data.get('identity_verified'):
                    overlay = {'year': data.get('year'), 'country': (data.get('countries') or [''])[0] if isinstance(data.get('countries'), list) else '', 'genre': ' / '.join(list((str(x) for x in (data.get('genres') or [])[:3]))), 'description': data.get('overview'), 'actors': ', '.join(list((str(x) for x in (data.get('cast') or [])[:6]))), 'director': ', '.join(list((str(x) for x in (data.get('directors') or [])[:3]))), 'writer': ', '.join(list((str(x) for x in (data.get('writers') or [])[:4]))), 'number_of_episodes': data.get('number_of_episodes'), 'number_of_seasons': data.get('number_of_seasons')}
                    snap = dict(data)
                    snap['item_overlay'] = {k: v for k, v in overlay.items() if v not in (None, '', [], {})}
                    portal_item = getattr(self, '_portal_item', self.item)
                    for obsolete in ('portal_poster_local', 'portal_backdrop_local'):
                        snap.pop(obsolete, None)
                    from .core.snapshot_writer import queue_detail_snapshot
                    queue_detail_snapshot(self.profile, self.media_type, portal_item, snap)
                    self._local_detail_cache = snap
                    self._schedule_search_visual_peer_sync(snap)
            except Exception as exc:
                optional_failure('ui.local_detail_cache_save', exc)
        if not data.get('matched'):
            provider = data.get('_details_provider_metadata') or getattr(self, '_portal_item', self.item)
            self._apply_provider_metadata(provider)
            self._load_provider_art(provider)
            if getattr(self, '_is_xtream_item', False):
                self._schedule_xtream_auto_retry()
            if isinstance(previous_good, dict):
                return None
            bundle = getattr(self, '_persistent_visual_bundle', {}) or {}
            authority = str(getattr(self, '_poster_authoritative_source', '') or '')
            authority_ok = bool(authority and os.path.isfile(authority))
            handoff_backdrop = str(getattr(self, '_portal_backdrop_source_local', '') or '')
            handoff_backdrop_ok = bool(handoff_backdrop and os.path.isfile(handoff_backdrop))
            locked_p = bool(authority_ok or (getattr(self, '_persistent_poster_locked', False) and str(bundle.get('poster') or '')))
            locked_b = bool(handoff_backdrop_ok or ((getattr(self, '_persistent_backdrop_source_locked', False) or getattr(self, '_persistent_backdrop_locked', False)) and str(bundle.get('backdrop') or bundle.get('backdrop_present') or getattr(self, '_backdrop_displayed_path', '') or '')))
            if not locked_p:
                try:
                    ph = 'grid_placeholder_movie_921.png' if self.media_type == 'vod' else 'grid_placeholder_series_921.png'
                    self._decode_picture(asset(ph))
                except Exception as exc:
                    optional_failure('ui.tmdb_miss_placeholder', exc)
            if not locked_b:
                try:
                    self['cinematic_bg'].hide()
                except Exception as exc:
                    optional_failure('ui.tmdb_miss_backdrop_hide', exc)
            if str(getattr(self, '_description_source', '') or '').strip() in ('', _('Loading metadata…'), 'Loading metadata…'):
                self._set_description_source(_('No description available.'))
            self['status'].setText(_('TMDb match unavailable') if not (locked_p or locked_b) else _('Backdrop ready • HDD') + ' • ' + _('TMDb match unavailable'))
            return None
        self._tmdb_data = data
        self._commit_canonical_visual_identity(data)
        try:
            if not str(getattr(self, '_country_raw', '') or '').strip():
                fallback_countries = data.get('countries') or data.get('production_countries') or data.get('origin_country') or []
                fallback_code = self._country_code(fallback_countries)
                if fallback_code:
                    self._country_raw = fallback_code
                    self['country_text'].setText(self._normalized_country(fallback_code))
                    self._refresh_detail_visuals()
        except Exception as exc:
            optional_failure('ui.details_country_fallback', exc)
        if not trusted_identity:
            self['status'].setText(_('Portal metadata • external match ignored'))
            return None
        title = str(getattr(self, '_server_display_name', '') or self['name'].getText() or data.get('title') or '')
        if title and str(self['name'].getText() or '') != title:
            self['name'].setText(title)
            self._fit_single_line_font('name', title, 42, 14)
            self._schedule_title_fit()
        self._schedule_details_title_logo(data, title)
        genres = ' / '.join(list((str(x) for x in (data.get('genres') or [])[:3])))
        if genres:
            self['subtitle'].setText(genres[:78])
        badges = self._detail_quality_value()
        self['quality_text'].setText((badges or '')[:10])
        self._refresh_detail_visuals()
        real_year = str(data.get('year') or '').strip()
        if real_year:
            self['year_text'].setText(_clean_year_value(real_year))
        if self.media_type == 'series':
            season_count = data.get('number_of_seasons') or 0
            if season_count:
                self['runtime_text'].setText(self._season_count_text(season_count))
                self._fit_compact_text('runtime_text', max_size=24, min_size=18, padding=4)
        elif data.get('runtime'):
            self['runtime_text'].setText((_('%s min') % data.get('runtime'))[:14])
            self._fit_compact_text('runtime_text', max_size=24, min_size=18, padding=4)
        countries = data.get('countries') or []
        country_code = self._country_code(countries)
        if country_code:
            self._country_raw = country_code
            self['country_text'].setText(self._normalized_country(country_code))
            self._refresh_detail_visuals()
        self['genre_text'].setText(genres[:54])
        self['age_rating_text'].setText(_age_rating_display(data.get('certification') or data.get('age_rating')))
        try:
            self._fit_compact_text('quality_text', max_size=21, min_size=11, padding=12)
            self._fit_compact_text('year_text', max_size=22, min_size=12, padding=8)
            self._fit_compact_text('runtime_text', max_size=24, min_size=18, padding=4)
            self._fit_compact_text('genre_text', max_size=26, min_size=17, padding=16)
        except Exception as exc:
            optional_failure('ui.detail_tmdb_font_refresh', exc)
        try:
            rating = float(data.get('rating') or 0)
            if rating > 0:
                self['rating_score'].setText('%.1f' % rating)
                self['rating_source'].setText(_('TMDB rating'))
        except Exception as exc:
            optional_failure('ui', exc)
        imdb_id = str(data.get('imdb_id') or '').strip()
        imdb_data = data.get('imdb') if isinstance(data.get('imdb'), dict) else {}
        portal_imdb = self.item.get('rating_imdb') or self.item.get('imdb_rating') or ''
        imdb_rating = imdb_data.get('rating') or portal_imdb
        if imdb_rating:
            try:
                imdb_label = '★ %.1f' % float(imdb_rating)
            except Exception:
                imdb_label = '★ %s' % str(imdb_rating)
        elif imdb_id:
            imdb_label = 'N/A'
        else:
            imdb_label = 'N/A'
        self['imdb_text'].setText(imdb_label[:24])
        self._refresh_detail_visuals()
        try:
            from .details_authority import metadata_language_ready, details_overview
            _cfg_now = load_settings()
            _visible_overview, _overview_ready = details_overview(self.profile, self.media_type, getattr(self, '_portal_item', self.item), data)
            if _overview_ready and str(_visible_overview or '').strip():
                self._set_description_source(str(_visible_overview).strip())
            elif str(data.get('overview') or '').strip() and str(getattr(self, '_description_source', '') or '').strip() in ('', _('Loading metadata…'), 'Loading metadata…'):
                self._set_description_source(str(data.get('overview') or '').strip())
            elif metadata_language_ready(data, _cfg_now) and str(getattr(self, '_description_source', '') or '').strip() in ('', _('Loading metadata…'), 'Loading metadata…'):
                self._set_description_source(_('No description available.'))
        except Exception as exc:
            optional_failure('ui.details_overview_language_lock', exc)
        cast = list((str(x) for x in (data.get('cast') or [])[:6] if str(x).strip()))
        if not cast and isinstance(data.get('imdb'), dict):
            cast = list((str(x) for x in (data['imdb'].get('cast') or [])[:6] if str(x).strip()))
        self['cast_text'].setText(', '.join((_clean_person_name(x) for x in cast))[:220])
        try:
            self._sync_detail_text_direction()
        except Exception as exc:
            optional_failure('ui.detail_cast_center', exc)
        poster = data.get('poster_local')
        real_source = str(data.get('backdrop_local') or '')
        if trusted_identity and data.get('tmdb_id') and (not (poster and os.path.isfile(str(poster))) or not _details_backdrop_truth(real_source)):
            retry_key = '%s:%s' % (str(data.get('media_type') or self.media_type), str(data.get('tmdb_id')))
            if retry_key not in self._artwork_gap_retry and (not self._screen_closed):
                self._artwork_gap_retry.add(retry_key)
                profile = dict(self.profile or {})
                media_type = self.media_type
                item = dict(self.item)
                cfg_now = load_settings()
                credential = str(cfg_now.get('tmdb_credential') or '').strip()
                language = cfg_now.get('tmdb_language', 'ar-EG')
                timeout = min(6, max(3, int(cfg_now.get('timeout', 10) or 10)))
                item['_locked_tmdb_id'] = data.get('tmdb_id')
                item['_ultra_search_verified_tmdb_id'] = data.get('tmdb_id')
                item['_locked_tmdb_type'] = data.get('media_type') or self.media_type
                token = self._tmdb_token
                cancel_event = self._details_cancel_event
                tmdb_jobs = self._tmdb_jobs

                def art_gap_worker():
                    if cancel_event.is_set() or not credential:
                        return
                    try:
                        resolver = ArtworkV2(credential, language, timeout)
                        repaired = resolver.resolve(profile, media_type, item, full=True, cancel_event=cancel_event)
                        if not _details_backdrop_truth((repaired or {}).get('backdrop_local') if isinstance(repaired, dict) else ''):
                            bfix = resolver.resolve_backdrop_only(profile, media_type, item, cancel_event=cancel_event)
                            if isinstance(bfix, dict) and _details_backdrop_truth(bfix.get('backdrop_local')):
                                merged = dict(repaired or {})
                                merged.update(bfix)
                                merged['matched'] = True
                                merged['identity_verified'] = True
                                repaired = merged
                                try:
                                    from .artwork_v2 import save_manifest
                                    save_manifest(profile, media_type, item, repaired)
                                except Exception as exc:
                                    optional_failure('ui.artwork_gap_direct_commit_manifest', exc)
                        if isinstance(repaired, dict) and repaired.get('matched') and (not cancel_event.is_set()):
                            tmdb_jobs.put((token, repaired))
                    except Exception as exc:
                        optional_failure('ui.artwork_gap_retry', exc)
                try:
                    self._track_details_future(_DETAIL_PREFETCH_EXECUTOR.submit(art_gap_worker, priority=0))
                except Exception as exc:
                    optional_failure('ui.artwork_gap_submit', exc)
        if not getattr(self, '_persistent_poster_locked', False) and poster and os.path.isfile(str(poster)) and (identity_source != 'portal_payload'):
            if not getattr(self, '_poster_authoritative_source', ''):
                self._image_token += 1
                self._decode_picture(str(poster))
        authority = str(getattr(self, '_poster_authoritative_source', '') or '')
        authority_ok = bool(authority and os.path.isfile(authority))
        if not getattr(self, '_persistent_poster_locked', False) and (not (poster and os.path.isfile(str(poster)))) and (not authority_ok):
            ph = 'grid_placeholder_movie_921.png' if self.media_type == 'vod' else 'grid_placeholder_series_921.png'
            try:
                self._decode_picture(asset(ph))
            except Exception as exc:
                optional_failure('ui.external_poster_gap', exc)
        authority = str(getattr(self, '_details_backdrop_authority_source', '') or '')
        locked = bool(getattr(self, '_details_backdrop_authority_locked', False) and authority and os.path.isfile(authority))
        sealed = bool(int(data.get('clean_backdrop_selector_version') or 0) >= 3 or trusted_identity)
        chosen = authority if locked else real_source if sealed and _details_backdrop_truth(real_source) else ''
        if chosen:
            if not locked:
                self._details_backdrop_authority_source = chosen
                self._details_backdrop_authority_locked = True
                self._portal_backdrop_source_local = chosen
                self._details_visual_state['backdrop'] = chosen
            rank = 5
            prepared = self._backdrop_presentation_target(chosen)
            if prepared and _valid_cache_file(prepared):
                try:
                    if self['cinematic_bg'].instance is not None and prepared != str(getattr(self, '_backdrop_displayed_path', '') or ''):
                        self['cinematic_bg'].instance.setPixmapFromFile(prepared)
                        self['cinematic_bg'].show()
                        self._backdrop_rank = rank
                        self._backdrop_displayed_path = prepared
                        self._details_visual_state['backdrop_present'] = prepared
                except Exception as exc:
                    optional_failure('ui.r197_details_backdrop_cached_apply', exc)
            elif not getattr(self, '_persistent_backdrop_locked', False):
                self._schedule_backdrop_presentation(chosen, rank)
        confidence = int(round(float(data.get('confidence') or 0) * 100))
        if identity_source == 'portal_payload':
            source = _('Portal metadata • HDD')
        else:
            source = _('TMDB • %d%% match') % confidence
            if imdb_id:
                source += _(' • IMDb linked')
        self['status'].setText(source)
        _runtime_endurance_log('details_metadata', media_type=self.media_type, source=identity_source or 'none', matched=True)
        self._refresh_detail_visuals()
        self._sync_detail_text_direction()
        self._ensure_description_visible()
        provider = data.get('_details_provider_metadata')
        if isinstance(provider, dict):
            self._apply_provider_metadata(provider)
            self._load_provider_art(provider)
        else:
            self._start_deferred_provider_enrichment(retry_tmdb=False)
