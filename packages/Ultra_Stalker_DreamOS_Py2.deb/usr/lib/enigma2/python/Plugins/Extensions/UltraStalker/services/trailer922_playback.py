# -*- coding: utf-8 -*-
"""Trailer-only playback behavior copied from the supplied 9.2.2 package.

Runtime globals are bound after player_native defines its screen. The normal
movie/live methods remain in their current modules; only trailers dispatch here.
"""
from __future__ import absolute_import, division, print_function, unicode_literals


def configure_trailer922(namespace):
    globals().update((key,value) for key,value in namespace.items() if not key.startswith("__"))


class Trailer922Mixin(object):
    def _trailer922__begin_playback(self):
        """Initialize playback and defer bookmark seeking until the service is ready.

        Ultra Stalker owns the bookmark identity and resume state. Playback starts
        first; the resume path waits for the active service to expose a usable seek
        interface before applying the stored absolute position.
        """
        self._resume_target = 0
        self._resume_seek_count = 0
        self._resume_verify_attempts = 0
        self._resume_verify_cycles = 0
        self._resume_prepared = False
        self._resume_prompt_open = False
        self._native_resume_started = False
        self._resume_failed_bookmark = 0
        self._resume_retries = 0
        behavior = self._cfg_resume_behavior
        self.resume_prompted = bool(behavior == "start")
        if self.reuse_current:
            try:
                current=self.session.nav.getCurrentlyPlayingServiceReference()
                if current is not None:
                    self.reference=current
                    try:self._owned_reference_string=current.toString()
                    except Exception:self._owned_reference_string=""
                    self.started=True;self.failed=False;self._startup_confirmed=True;self._watch_started_at=time.monotonic()
                    self.start_attempt=time.monotonic();self._last_network_activity=time.monotonic()
                    self._runtime_reconnects=0;self._recovery_attempts=0
                    self["connection"].setText("")
                    runtime_breadcrumb("player_adopt_current",media_type=self.media_type,engine=int(self.servicetype or 0))
                    try:self.stable_timer.stop();self.stable_timer.start(30000,True)
                    except Exception as exc:optional_failure("player.optional_guard",exc)
                    if self.media_type in ("vod","series","episode"):
                        self._reset_vod_quality_probe();self._arm_vod_quality_probe()
                    try:self.stream_info_timer.start(700,True)
                    except Exception as exc:optional_failure("player.optional_guard",exc)
                    return
            except Exception as exc:
                optional_failure("player.adopt_current",exc)
        self.playStream(self.servicetype, self.streamurl)

    def _trailer922_playStream(self, servicetype, streamurl):
        runtime_breadcrumb("player_start_request",media_type=self.media_type,engine=int(servicetype or 0))
        if self.restored or self._closing_playback:
            return
        if not streamurl:
            self._final_failure("Empty stream URL")
            return
        bypass = bool(getattr(self, "_buffer_bypass", False))
        self._buffer_bypass = False
        if not bypass and self.media_type in ("vod", "series", "episode"):
            try:
                buffer_mb = int(load_settings().get("playback_buffer_mb") or 0)
            except Exception:
                buffer_mb = 0
            if buffer_mb > 0 and not str(streamurl).startswith("http://127.0.0.1"):
                path = str(streamurl).split("?", 1)[0].lower()
                if not path.endswith(".m3u8"):
                    self._arm_playback_buffer(servicetype, streamurl, buffer_mb)
                    return

        try:
            service_value = int(servicetype)
        except Exception:
            service_value = 4097
        self.servicetype = service_value
        if self.media_type in ("vod","series","episode","catchup"):
            pending=int(getattr(self,"_resume_target",0) or 0)
            if pending>0:
                self.item["_resume_position"]=pending
                self._recovery_resume_pending=True
            self._resume_target=0;self._resume_seek_count=0
            self._native_resume_started=False;self.resume_prompted=False
            try:self.resume_verify_timer.stop()
            except Exception:pass
        self._reset_vod_quality_probe()
        self._reset_vod_audio_probe()
        self._play_generation += 1
        self.started = False
        self.failed = False
        self._early_eof_pending = False
        self._startup_guard_checks = 0
        self._startup_guard_last_position = -1
        self._startup_guard_reason = ""
        self._startup_guard_until = time.monotonic() + (8.0 if self.media_type in ("vod", "series", "episode", "catchup", "trailer") else 0.0)
        self._video_guard_misses = 0
        self._video_guard_last_engine = int(service_value)
        self._engine_video_confirmed = False
        self._subtitle_user_override = False
        self._subtitle_disable_attempts = 0
        self._embedded_subtitle_probe_pending = False
        self._embedded_subtitle_probe_attempts = 0
        try:
            self.embedded_subtitle_probe_timer.stop()
        except Exception:
            pass
        try:
            self.subtitle_default_timer.stop()
        except Exception as exc:
            optional_failure("player", exc)
        try:
            self.eof_guard_timer.stop()
        except Exception as exc:
            optional_failure("player", exc)
        self.start_attempt = time.monotonic()
        self._startup_deadline = self.start_attempt + 12.0
        self._startup_probe_position = -1
        self._startup_confirmed = False
        self._startup_live_pair = None
        self._startup_live_pair_hits = 0
        self.streamurl = str(streamurl or "")
        # R24: keep only the stable engine chip beside SUBTITLES.
        # The old floating engine/status text near the clock remains removed.
        try:self["engine"].setText(_engine_label(self.servicetype))
        except Exception:pass
        try:self["connection"].setText("")
        except Exception:pass
        self["extension"].setText(_("STREAM"))
        try:self._sync_typographic_technical_row()
        except Exception:pass

        try:
            self.reference = eServiceReference(self.servicetype, 0, str(streamurl))
            self.reference.setName(self.name)
            try:self._owned_reference_string=self.reference.toString()
            except Exception:self._owned_reference_string=""
            # Replace the active service directly from the player screen. Stopping
            # the previous service first can emit a stale EOF and incorrectly trigger
            # the startup fallback path, so the new Enigma2 reference is played directly.
            result = self.session.nav.playService(self.reference)
            try: self._owned_external_pids.update(set(_matching_external_player_pids(self.streamurl))-set(self._external_player_baseline))
            except Exception as exc: optional_failure("player.capture_external",exc)
            if result is False:
                raise RuntimeError("service engine rejected the stream")
            self.startup_timer.stop()
            self.startup_timer.start(750, True)
        except Exception as exc:
            self._try_next_engine(_("engine %s rejected stream: %s") % (self.servicetype, exc))

    def _trailer922__service_started(self):
        if self.restored or self._closing_playback:
            return
        try:
            current=self.session.nav.getCurrentlyPlayingServiceReference()
            if current is not None and self.reference is not None and current.toString()!=self.reference.toString():return
        except Exception:pass
        already_started = bool(self.started)
        self.started = True
        if self.media_type in ("vod","series","episode","catchup"):
            self._reference_resume()
        if not already_started or not self._watch_started_at:
            self._watch_started_at = time.monotonic()
        try:
            self.startup_timer.stop();self.startup_timer.start(750,True)
        except Exception as exc:
            optional_failure("player", exc)
        self["connection"].setText("")
        if not getattr(self,"_retry_visual_hold",False):
            self._auto_retry_deferred_reason="";self._auto_retry_next_allowed_at=0.0
            try:self.auto_retry_delay_timer.stop()
            except Exception:pass
            try:self["retry_status"].setText("")
            except Exception:pass
        else:
            # evStart can fire before a retry candidate has real decoded playback.
            # Keep the line held. Live uses a short quiet guard; VOD/Series clear
            # only after the play position advances on the replacement service.
            try:self["retry_status"].show()
            except Exception:pass
            try:self.retry_visual_success_timer.stop()
            except Exception:pass
            if self.media_type in ("itv","live"):
                try:self.retry_visual_success_timer.start(1500, True)
                except Exception as exc:optional_failure("player.retry_visual_success_timer", exc)
            else:
                self._retry_visual_progress_last=-1
                self._retry_visual_progress_advances=0
        if self.media_type in ("itv","live"):
            try:self._refresh_live_epg()
            except Exception as exc:optional_failure("player.live_epg_started",exc)
        runtime_breadcrumb("player_started",media_type=self.media_type,engine=int(self.servicetype or 0))
        try:
            self._owned_external_pids.update(set(_all_external_player_pids())-set(self._external_player_baseline))
        except Exception as exc:optional_failure("player.capture_external_started",exc)
        self._last_network_activity = time.monotonic()
        # R8.8 subtitle policy: every service starts OFF. No remembered embedded,
        # online or external subtitle is ever restored automatically.
        _remembered_subtitle={}
        try:self._schedule_subtitle_session_restore(0)
        except Exception:pass
        try:
            bridge=getattr(self,"_external_subtitle_bridge",None)
            if bridge is not None:bridge.service_started()
        except Exception as exc:optional_failure("player.external_subtitle_started",exc)
        try:
            self.memory_fuse_timer.stop();self.memory_fuse_timer.start(5000,False)
        except Exception as exc:optional_failure("player.silent_guard",exc)
        try:
            if not getattr(self,"_startup_confirmed",False):self.stable_timer.stop()
        except Exception as exc:
            optional_failure("player", exc)
        if not already_started:
            try:
                self.subtitle_default_timer.stop()
                self._enforce_default_subtitles_off()
            except Exception as exc:
                optional_failure("player", exc)
        # Last Viewed is intentionally separate from Resume. Touch recency as
        # soon as Enigma2 confirms real playback, while preserving any existing
        # resume point. Progress itself is still saved only after the 45s gate.
        if self.media_type in ("vod","series","episode","catchup"):
            try:
                profile=self._history_profile
                history_item=self._history_item
                touch_recently_played(profile,self.media_type,history_item)
            except Exception as exc:optional_failure("player",exc)
        elif self.media_type in ("itv","live"):
            # Home/Category launches already save the opening channel.  What used
            # to be missing was a channel selected later from inside the Player.
            # Commit that compact row only after Enigma2 confirms real playback.
            pending=getattr(self,"_pending_live_recent_item",None)
            if isinstance(pending,dict):
                try:
                    add_recently_played(self._history_profile,"itv",pending)
                    self._history_item=pending
                    self._pending_live_recent_item=None
                except Exception as exc:
                    optional_failure("player.live_recent_after_zap",exc)
        if self.media_type in ("vod","series","episode") and not already_started:
            self._arm_vod_quality_probe()
            self._arm_vod_audio_probe()
        self._update_stream_info()
        if self.media_type in ("vod", "series", "episode", "catchup"):
            try:
                self.progress_timer.stop(); self.progress_timer.start(self._cfg_progress_interval_ms, False)
            except Exception as exc:
                optional_failure("player", exc)
            if not self.resume_prompted:
                self.resume_prompted=True
        if self.media_type in ("vod", "series", "episode", "catchup", "trailer"):
            try:
                self.progress_visual_timer.stop();self._update_progress_visual();self.progress_visual_timer.start(1000, False)
            except Exception as exc:
                optional_failure("player.trailer_progress_visual", exc)
        if not already_started:
            self._schedule_buffer_after_start()
        timer=getattr(self,"_next_episode_timer",None)
        if timer is not None:
            try:timer.stop();timer.start(250,True)
            except Exception as exc:optional_failure("player.next_episode_watch_start",exc)

    def _trailer922__event_matches_current_reference(self, ignore_suppress=False):
        if getattr(self, "reference", None) is None or not getattr(self, "start_attempt", 0):
            return False
        if not ignore_suppress and time.monotonic() < float(getattr(self,"_event_suppress_until",0.0) or 0.0):
            return False
        try:
            current = self.session.nav.getCurrentlyPlayingServiceReference()
            if current is None or self.reference is None:
                return True
            s_cur = current.toString()
            s_ref = self.reference.toString()
            if s_cur == s_ref:
                return True
            p_cur = s_cur.split(":", 10)
            p_ref = s_ref.split(":", 10)
            if len(p_cur) >= 11 and len(p_ref) >= 11 and p_cur[10] and (p_cur[10] == p_ref[10]):
                return True
            return False
        except Exception:
            return True

    def _trailer922__service_failed(self):
        if self.restored or self._closing_playback:
            return
        if not self._event_matches_current_reference():
            return
        elapsed = time.monotonic() - self.start_attempt if self.start_attempt else 999
        if self.media_type in ("vod", "series", "episode", "catchup", "trailer") and elapsed < 8.0:
            if not getattr(self,"_retry_visual_hold",False):
                self["connection"].setText(_("PLAYING  •  verifying startup") if self.started else _("CONNECTING  •  verifying startup"))
            self._schedule_startup_guard("transient tune failed")
            return
        if self.started and self.media_type in ("itv", "live"):
            if self._handle_runtime_interruption("tune failed during playback"):
                return
        self._try_next_engine("tune failed")

    def _trailer922__service_eof(self):
        if self._fallback_from_buffer():
            return
        if self.restored or self._closing_playback:
            return
        if not self._event_matches_current_reference():
            return
        if self._resume_target and time.monotonic() < self._resume_grace_until:
            try:
                self.eof_guard_timer.stop(); self.eof_guard_timer.start(1800, True)
            except Exception as exc:
                optional_failure("player", exc)
            return
        elapsed = time.monotonic() - self.start_attempt if self.start_attempt else 999
        if self.media_type in ("vod", "series", "episode", "catchup", "trailer") and elapsed < 8.0:
            if not getattr(self,"_retry_visual_hold",False):
                self["connection"].setText(_("PLAYING  •  stabilizing stream") if self.started else _("CONNECTING  •  stabilizing stream"))
            self._schedule_startup_guard("transient early EOF")
            return
        if not self.started:
            self._try_next_engine("stream ended before playback started")
            return
        if self.media_type=="trailer":
            position, duration = self._service_progress_snapshot()
            if not getattr(self, "_startup_confirmed", False) or (duration > 0 and (position <= 0 or duration - position > 3 * 90000)):
                self._try_next_engine("trailer ended before confirmed completion")
                return
            self._close_player(save_progress=False)
            return
        if self.media_type in ("itv", "live"):
            if self._handle_runtime_interruption("stream ended during playback"):
                return
        if self.media_type in ("vod", "series", "episode", "catchup"):
            # Treat EOF as a broken source when a known duration says the viewer
            # is still well before the configured completion threshold. Natural
            # end-of-title behavior remains untouched near the real end.
            try:
                position,duration=self._service_progress_snapshot()
                position=position or int(self._last_progress_position or 0)
                duration=duration or int(self._last_progress_duration or 0)
                completed=bool(duration and (position>=int(duration*self._cfg_completion_threshold) or max(0,duration-position)<=self._cfg_completion_remaining_pts))
                if self.media_type=="episode":completed=bool(duration and position>=duration-10*90000)
            except Exception:
                position=duration=0;completed=False
            if duration>0 and position>0 and not completed:
                if self._begin_smart_recovery("unexpected EOF during playback"):
                    return
                self._final_failure("unexpected EOF during playback")
                return
            # Natural EOF is different from the user pressing BACK. Freeze the
            # periodic writer so it cannot overwrite the completed state while
            # the 10-second Next Episode prompt is on screen.
            try: self.progress_timer.stop()
            except Exception as exc: optional_failure("player", exc)
            if duration<=0 and self.media_type in ("vod","series","episode"):
                # Length unknown: this may be a dropped connection, not a finished
                # title. Keep the bookmark, do not mark completed, do not autoplay.
                self._save_history_progress(force=True)
                self._close_player(save_progress=False)
                return
            next_item = self.item.get("_next_episode_item") if self.media_type == "episode" else None
            if self.media_type=="episode" and getattr(self,"_next_card_live",False) and getattr(self,"_next_card_open",False):
                self._finish_next_episode(next_item)
                return
            self._save_history_progress(force=True, completed_override=True)
            self._next_episode_at_eof=True
            global NEXT_EPISODE_AUTOPLAY_SESSION
            if isinstance(next_item, dict) and next_item and NEXT_EPISODE_AUTOPLAY_SESSION and not getattr(self,"_next_episode_cancelled",False):
                # Natural episode EOF: show the Next Episode card (countdown from
                # Settings).  The info bar is hidden first so only the card is on
                # screen; play-now / countdown end hands the episode back to the
                # Series screen, cancel just leaves the Player.
                self._next_episode_prompted = True
                if self._show_next_episode_card(dict(next_item)):
                    return
                self._close_player({"next_episode": dict(next_item)}, save_progress=False)
                return
            self._close_player(save_progress=False)

    def _trailer922__schedule_startup_guard(self, reason):
        """Debounce stale EOF/tune-failed events from ServiceApp/ExtePlayer."""
        if self.media_type not in ("vod", "series", "episode", "catchup", "trailer"):
            return False
        self._early_eof_pending = True
        self._startup_guard_reason = str(reason or "startup interruption")
        self._startup_guard_checks = 0
        try:
            self.eof_guard_timer.stop()
            self.eof_guard_timer.start(1100, True)
            return True
        except Exception as exc:
            optional_failure("player", exc)
            return False

    def _trailer922__verify_early_eof(self):
        if not self._early_eof_pending or self.restored or self.failed:
            return
        now = time.monotonic()
        try:
            service = self.session.nav.getCurrentService()
            seekable = service.seek() if service else None
            pos = seekable.getPlayPosition() if seekable else None
            position = int(pos[1]) if pos and not pos[0] else -1
        except Exception:
            position = -1
        ref_ok = self._event_matches_current_reference()
        previous = self._startup_guard_last_position
        self._startup_guard_last_position = position
        self._startup_guard_checks += 1
        # Advancing decoded position is definitive proof that playback survived
        # the stale event; keep the current engine and do not restart.
        if ref_ok and position >= 0 and previous >= 0 and position > previous + 9000:
            self._early_eof_pending = False
            self["connection"].setText("")
            return
        # Never bounce engines during the protected startup window merely because
        # one probe cannot read a seek position yet. External players often expose
        # seek() a few seconds after video begins.
        if ref_ok and now < self._startup_guard_until and self._startup_guard_checks < 7:
            try:
                self.eof_guard_timer.start(1000, True)
            except Exception as exc:
                optional_failure("player", exc)
            return
        self._early_eof_pending = False
        if self._fallback_from_buffer():
            return
        self._try_next_engine(self._startup_guard_reason or "stream stopped during startup verification")

    def _trailer922__startup_timeout(self):
        if self.restored or self._closing_playback or self.failed:return
        if getattr(self,"_startup_confirmed",False):return
        now=time.monotonic()
        deadline=float(getattr(self,"_startup_deadline",self.start_attempt+12.0))
        # Deliberate pause / a visible resume question is not a stalled decoder.
        if self.started and (str(getattr(self,"_last_play_state_value","") or "")=="||" or getattr(self,"_resume_prompt_open",False)):
            self._startup_deadline=now+12.0
            self.startup_timer.start(750,True);return
        position=-1;seekable=None;service=None
        try:
            service=self.session.nav.getCurrentService()
            seekable=service.seek() if service else None
            value=seekable.getPlayPosition() if seekable else None
            if value and not value[0]:position=max(0,int(value[1]))
        except Exception:pass
        previous=int(getattr(self,"_startup_probe_position",-1))
        self._startup_probe_position=position
        confirmed=self.started and previous>=0 and position>previous+9000
        # Live engines may expose missing or permanently zero PTS; accept
        # consistent current-service video dimensions as their compatibility signal.
        if self.started and self.media_type in ("itv","live") and position<=0:
            try:
                info=service.info() if service else None
                pair=(int(self._info_number(info,"sVideoWidth",0) or 0),
                      int(self._info_number(info,"sVideoHeight",0) or 0)) if info else (0,0)
                previous_pair=getattr(self,"_startup_live_pair",None)
                hits=int(getattr(self,"_startup_live_pair_hits",0) or 0)+1 if pair==previous_pair else 1
                self._startup_live_pair=pair;self._startup_live_pair_hits=hits
                confirmed=bool(pair[0]>0 and pair[1]>0 and hits>=2 and now-self.start_attempt>=2.0)
            except Exception:pass
        if confirmed and not self._resume_target:
            self._startup_confirmed=True
            self.stable_timer.stop();self.stable_timer.start(30000,True)
            return
        if self._resume_target:
            deadline=max(deadline,float(self._resume_grace_until or 0.0)+1.0)
        if now>=deadline:
            self.started=False
            if self._fallback_from_buffer():return
            self._try_next_engine("startup produced no advancing playback")
            return
        self.startup_timer.start(750,True)

    def _trailer922__try_next_engine(self, reason):
        if self.restored or self._closing_playback or self.failed:return
        try:self.startup_timer.stop()
        except Exception as exc:optional_failure("player.silent_guard",exc)
        if self.media_type=="trailer" and isinstance(getattr(self,"item",None),dict):
            # First try alternate compatible engines (e.g. 5002 exteplayer3 for 720p &suburi=)
            # on the current highest-quality stream BEFORE dropping down to lower-quality fallback URLs.
            tried=set(getattr(self,"_trailer_tried_engines",set()) or {int(self.servicetype or 4097)})
            engine_candidates = (5002, 4097) if "&suburi=" in str(self.streamurl or "") else (5002, 5001, 4097, 8193)
            for cand_eng in engine_candidates:
                if cand_eng in tried:continue
                if cand_eng==5002 and not os.path.exists("/usr/bin/exteplayer3"):continue
                if cand_eng==5001 and not os.path.exists("/usr/bin/gstplayer"):continue
                tried.add(cand_eng)
                self._trailer_tried_engines=tried
                if cand_eng not in self.engines:self.engines.append(cand_eng)
                self._suppress_service_events(1.0)
                try:self.session.nav.stopService()
                except Exception:pass
                self.playStream(cand_eng,self.streamurl)
                return
            fallbacks=list(self.item.get("_trailer_fallback_urls") or [])
            while fallbacks:
                next_url=str(fallbacks.pop(0) or "").strip()
                self.item["_trailer_fallback_urls"]=fallbacks
                if next_url and next_url!=str(self.streamurl or ""):
                    self._trailer_tried_engines={4097}
                    self._suppress_service_events(1.0)
                    try:self.session.nav.stopService()
                    except Exception:pass
                    self.playStream(4097,next_url)
                    return
        if self._begin_smart_recovery(reason):return
        self._final_failure(reason)

    def _trailer922__final_failure(self, reason):
        if self.failed:
            return
        if int(getattr(self,"_recovery_attempts",0) or 0)>=3:
            self.failed=True
            self._retry_visual_set(_("Stream unavailable"))
            try:self["connection"].setText("")
            except Exception:pass
            return
        self.failed = True
        self["connection"].setText(_("PLAYBACK FAILED"))
        text = _("The stream could not start with the configured Enigma2 engine.\n\n%s\n\nTried: %s") % (
            _(str(reason)),
            ", ".join(str(x) for x in self.engines),
        )
        try:
            self.session.openWithCallback(lambda answer=None: self.back(), MessageBox, text, MessageBox.TYPE_ERROR, timeout=10)
        except Exception:
            self.back()

    def _trailer922__service_progress_snapshot(self, raw=False):
        """Read one sane 90kHz PTS snapshot from the active Enigma2 service."""
        try:
            service = self.session.nav.getCurrentService()
            seek = service.seek() if service else None
            pos_result = seek.getPlayPosition() if seek else None
            len_result = seek.getLength() if seek else None
            position = int(pos_result[1]) if pos_result and not pos_result[0] else 0
            duration = int(len_result[1]) if len_result and not len_result[0] else 0
            # Negative values are error/sentinel values on several OE-A builds;
            # never abs() them into a fake positive resume timestamp.
            position = max(0, position)
            duration = max(0, duration)
            if duration and position > duration + (5 * 90000):
                position = 0
            return position, duration
        except Exception as exc:
            try:
                if self._cfg_diagnostic_logging: optional_failure("player.progress_snapshot",exc)
            except Exception as exc:
                optional_failure("player.optional_guard", exc)
            return 0, 0

    def _trailer922__update_progress_visual(self):
        if not getattr(self,"_player_infobar_visible",True):
            try:self.progress_visual_timer.stop()
            except Exception as exc:optional_failure("player.hidden_progress_visual_guard",exc)
            return
        if self.restored or self.media_type not in ("vod","series","episode","catchup","trailer"):
            try:
                self["progress_neon"].hide(); self["progress_head"].hide()
                self._buffer_status_clear(); self["buffer_glass"].hide(); self["skip_hint"].setText("")
                self["elapsed_time"].setText(""); self["total_time"].setText(""); self["remaining_time"].setText("")
            except Exception as exc:
                optional_failure("player.progress_visual_hide", exc)
            return
        position,duration=self._service_progress_snapshot()
        self._update_buffer_status(duration)
        if getattr(self,"_buffer_job",None) is not None and position>0 and duration>0:
            self._buffer_watch_position=int(position)
            self._buffer_note_position(position, duration)
        self._retry_visual_note_vod_progress(position)
        # Only presentation uses the brief last-good snapshot. Buffer transport,
        # retry handling and saved Resume points always receive raw native PTS.
        position,duration=self._progress_visual_snapshot(position,duration)
        position=self._seek_display_position(position,duration)
        self._update_player_time_labels(position,duration)
        if self._lb_mode()=="vod":
            # The bar owns progress, downloaded line and times (ticked above).
            self._update_skip_hint(position, duration)
            return
        if duration <= 0:
            try:
                self["vod_progress"].setValue(0);self["vod_progress"].show()
                self["buffer_glass"].hide();self["progress_neon"].hide()
            except Exception:pass
            self._update_skip_hint(position, duration)
            return
        ratio=max(0.0,min(1.0,float(position)/float(duration)))
        try:
            value=max(0,min(100,int(round(ratio*100.0))))
            self["vod_progress"].setValue(value);self["vod_progress"].show()
            # Only swap the laser pixmap when the integer percentage changes. This keeps the
            # one-second timer cheap on the receiver while preserving smooth visual progress.
            self._apply_laser_progress(ratio)
        except Exception as exc:optional_failure("player.progress_visual",exc)
        self._update_skip_hint(position, duration)

    def _trailer922__configure_vod_title_area(self):
        """VOD/episode Player: Cinematic authority -> local Player presentation.

        The Player never resolves a separate Player-logo identity.  It consumes
        the current screen/Cinematic 420x144 Ultra authority.  When that
        authority is missing, one background job resolves the *Cinematic*
        variant for the current locked item, then derives the 1220x72 Player
        canvas locally from that exact file.
        """
        if self._lb_mode()=="vod":
            # R5.542: the bar shows the clean title as measured text next to the
            # chips (no 1220px title-logo canvas, no background logo job).
            try:
                self._player_title_logo_token+=1
                self._player_title_logo_pending=False;self._player_title_logo_path=""
                title=self._player_fallback_title(self.item,self.name,self.media_type,self._cfg_clean_titles)
                self._lb_title_full=str(title or "")[:180]
                self["vod_title"].setText(self._lb_title_full)
                self._lb_vod_meta_cache=None
                self._lb_sig.pop("top",None);self._lb_sig.pop("vod",None)
                self._lb_suppress_legacy()
                self._lb_layout_top();self._lb_layout_vod_rows(True)
            except Exception as exc:optional_failure("player.live_bar_vod_title",exc)
            return
        try:
            for name in ("channel","category","quality","connection","now"):
                try:self[name].hide()
                except Exception:pass
            title=self._player_fallback_title(self.item,self.name,self.media_type,self._cfg_clean_titles)
            title,title_font=self._player_fit_title(title)

            # New-title boundary: invalidate every previous async/logo surface, not
            # merely hide it. A hidden Pixmap can be shown again by an InfoBar
            # restore path, which is how an old title logo leaked onto logo-less
            # films. The fallback title is authoritative until this title resolves.
            self._player_title_logo_token+=1
            token=self._player_title_logo_token
            future=getattr(self,"_player_title_logo_future",None)
            if future is not None:
                try:future.cancel()
                except Exception:pass
            self._player_title_logo_future=None
            self._player_title_logo_pending=False
            self._player_title_logo_path=""
            try:
                while True:self._player_title_logo_queue.get_nowait()
            except queue.Empty:
                pass
            try:
                if self["title_logo"].instance is not None:self["title_logo"].instance.setPixmap(None)
                self["title_logo"].hide()
            except Exception:pass
            try:
                if self["vod_title"].instance is not None:self["vod_title"].instance.setFont(gFont("Regular",title_font))
            except Exception:pass
            marker=self._episode_marker_text()
            if marker:
                try:self["episode_marker"].setText(marker);self["episode_marker"].show()
                except Exception:pass
            else:
                try:self["episode_marker"].hide()
                except Exception:pass
            self["vod_title"].setText(title[:180]);self["vod_title"].show();self["title_logo"].hide();self._player_title_logo_path=""
            self._episode_name_apply()

            logo_item=(self.item.get("_quality_parent_item") if self.media_type=="episode" and isinstance(self.item,dict) and isinstance(self.item.get("_quality_parent_item"),dict) else self.item) if isinstance(self.item,dict) else {}
            if not isinstance(logo_item,dict):logo_item={}
            # R151: Trailer keeps its own playback lifecycle, but visual lookup
            # must use the movie/series identity that launched it.  Without this
            # bridge a cache miss was queried as media_type=trailer, so Portal
            # trailers could show an empty poster frame and plain text title.
            logo_media_type=self.media_type
            if self.media_type=="trailer" and isinstance(self.item,dict):
                parent=str(self.item.get("_trailer_parent_media_type") or "").strip().lower()
                if parent in ("vod","movie"):logo_media_type="vod"
                elif parent in ("series","episode","tv"):logo_media_type="series"
            # Preserve the Player handoff/locked identity on the actual logo owner.
            for key in ("_player_title_logo_tmdb_id","_locked_tmdb_id"):
                value=(self.item.get(key) if isinstance(self.item,dict) else None)
                if value not in (None,""):logo_item[key]=value
            authority=_player_title_logo_source(self.item if isinstance(self.item,dict) else logo_item,title,logo_media_type)
            if not authority:
                authority=_player_title_logo_source(logo_item,title,logo_media_type)
            # If this exact authority already has a prepared Player canvas, paint
            # it immediately without any Pillow work on the GUI thread.
            prepared=""
            try:
                target=_prepare_player_title_logo_cache_path(authority,(1220,72)) if authority else ""
                if target and os.path.isfile(target) and os.path.getsize(target)>256:prepared=target
            except Exception:prepared=""
            if prepared:
                if self["title_logo"].instance is not None:
                    self["title_logo"].instance.setPixmap(None);self["title_logo"].instance.setPixmapFromFile(prepared)
                self["title_logo"].show();self["vod_title"].hide();self._player_title_logo_path=prepared;self._episode_name_apply();return

            if self._player_title_logo_pending:return
            self._player_title_logo_pending=True
            result_queue=self._player_title_logo_queue
            media_copy=str(logo_media_type or self.media_type or "")
            profile_copy=dict(getattr(self,"_history_profile",{}) or {})
            logo_copy=dict(logo_item)
            authority_copy=str(authority or "")
            def worker():
                path="";source=authority_copy;resolved={}
                try:
                    # Missing Cinematic authority: resolve exactly the same
                    # 420x144 Ultra pipeline Cinematic uses, for this locked item.
                    if not (source and os.path.isfile(source) and os.path.getsize(source)>256):
                        from ..title_logo_ultra import resolve_ultra_title_logo
                        source,resolved=resolve_ultra_title_logo(profile_copy,media_copy,logo_copy,logo_copy,canvas_size=(420,144),visible_title=title,settings=load_settings() or {})
                    if source and os.path.isfile(source) and os.path.getsize(source)>256:
                        # Recent can be the first consumer of a freshly created
                        # Cinematic authority. Give the local Player derivative a
                        # few background-only retries so first open paints it; the
                        # user must never need to close/reopen the title.
                        for _attempt in range(3):
                            path=_prepare_player_title_logo(source,(1220,72)) or ""
                            if path:break
                            time.sleep(0.10)
                except Exception:pass
                try:result_queue.put((token,path,source,dict(resolved or {})))
                except Exception:pass
            try:
                self._player_title_logo_future=_PLAYER_BG_EXECUTOR.submit(worker)
                self.player_title_logo_timer.start(90,True)
            except Exception:
                self._player_title_logo_pending=False
                future=getattr(self,"_player_title_logo_future",None)
                if future is not None:
                    try:future.cancel()
                    except Exception:pass
                self._player_title_logo_future=None
        except Exception as exc:optional_failure("player.vod_title_area",exc)

    def _trailer922__resume_hidden_visual_timers(self):
        """Restore normal visual/status cadence as soon as the InfoBar is shown."""
        self._player_infobar_visible=True
        if self.restored or self._closing_playback or not self.started:return
        if self._memory_fuse_level < 2:
            try:self.stream_info_timer.stop();self._update_stream_info()
            except Exception as exc:optional_failure("player.visible_stream_info_resume",exc)
        if self.media_type in ("vod","series","episode","catchup","trailer"):
            try:
                self.progress_visual_timer.stop();self._update_progress_visual();self.progress_visual_timer.start(1000,False)
            except Exception as exc:optional_failure("player.visible_progress_visual_resume",exc)

    def _trailer922__pause_hidden_visual_timers(self):
        """Throttle purely visual/status polling while the InfoBar is hidden."""
        self._player_infobar_visible=False
        try:self.progress_visual_timer.stop()
        except Exception as exc:optional_failure("player.hidden_progress_visual_stop",exc)
        # Stream metadata is informational only. Keep a slow hidden refresh so
        # adaptive resolution changes are still learned without 1 Hz GUI I/O.
        if self.started and self._memory_fuse_level < 2 and not self.restored and not self._closing_playback:
            try:self.stream_info_timer.stop();self.stream_info_timer.start(5000,True)
            except Exception as exc:optional_failure("player.hidden_stream_info_throttle",exc)

    def _trailer922__layout_ready(self):
        try:
            if not self._resume_prepared:
                self["resume_mask"].hide()
        except Exception as exc:
            optional_failure("player.resume_mask_layout", exc)
        artwork=_cached_poster(self.item, self.name, self.media_type)
        if self.media_type in ("itv","live"):
            try:self["vod_title"].hide();self["title_logo"].hide();self["episode_marker"].hide();self["episode_name"].hide()
            except Exception:pass
            self._apply_live_channel_title()
            self._load_live_picon(artwork)
            self._apply_live_infobar_layout()
            self._refresh_live_epg()
        else:
            if not self._lb_active():self._lb_hide()
            self._configure_vod_title_area()
            self._load_poster(artwork)
            # R5.542: Movies/Series use the same bar, poster on its left corner.
            self._live_bar_apply(force=True)
        self._fit_player_keybar_labels()
        try:self._apply_technical_row_layout(bool(getattr(self,"_audio_format_badge_active",False)))
        except Exception as exc:optional_failure("player.technical_row_layout_ready",exc)
        self._update_stream_info()

    def _trailer922__memory_fuse_tick(self):
        if self.restored or self._closing_playback:
            try:self.memory_fuse_timer.stop()
            except Exception as exc:optional_failure("player.silent_guard",exc)
            return
        rss=_process_rss_kb();self._memory_fuse_last_rss=rss
        if not rss:return
        # 430 MB: shed decorative native pixmaps and Python garbage.
        if rss >= 430*1024 and self._memory_fuse_level < 1:
            self._memory_fuse_level=1
            runtime_breadcrumb("player_memory_fuse",level=1,rss_kb=int(rss))
            self._memory_fuse_release_visuals(False)
        # 510 MB: stop all non-essential player image polling/decoding.
        if rss >= 510*1024 and self._memory_fuse_level < 2:
            self._memory_fuse_level=2
            runtime_breadcrumb("player_memory_fuse",level=2,rss_kb=int(rss))
            self._memory_fuse_release_visuals(True)
            try:self["connection"].setText(_("MEMORY PROTECTION  •  playback preserved"))
            except Exception as exc:optional_failure("player.silent_guard",exc)
        pressure=False
        try:
            values={}
            with open("/proc/meminfo", "r") as stream:
                for line in stream:
                    fields=line.split()
                    if len(fields)>=2:values[fields[0].rstrip(":")]=int(fields[1])
            total=int(values.get("MemTotal",0))
            available=values.get("MemAvailable")
            if available is None:
                available=sum(values.get(k,0) for k in ("MemFree","Buffers","Cached","SReclaimable"))-values.get("Shmem",0)
            pressure=bool(total>0 and available < max(32768,min(98304,int(total*0.05))))
        except Exception:pass
        count=int(getattr(self,"_memory_pressure_checks",0) or 0)+1 if pressure and rss>=555*1024 else 0
        self._memory_pressure_checks=count
        if count>=3 and not self._memory_fuse_emergency:
            self._memory_fuse_emergency=True
            runtime_breadcrumb("player_memory_fuse",level=3,rss_kb=int(rss))
            try:self["connection"].setText(_("MEMORY SAFETY EXIT"))
            except Exception as exc:optional_failure("player.silent_guard",exc)
            try:self._save_history_progress(force=True)
            except Exception as exc:optional_failure("player.silent_guard",exc)
            self._close_player(save_progress=False)

    def _trailer922__memory_fuse_release_visuals(self, aggressive=False):
        # Playback service is deliberately left untouched. Only optional native
        # graphics/decoder helpers are released.
        # Never shed the core InfoBar glass.  With large portal libraries RSS can
        # already be above the old 430 MB threshold when Player opens; the old
        # fuse therefore stripped adaptive_main/keybar/chips a few seconds later
        # and left naked labels over video.  Only artwork/decorative layers are
        # disposable while playback continues.
        # Keep the core VOD/episode identity surfaces resident. They are small
        # compared with the video decoder and must survive InfoBar hide/show.
        # Only genuinely disposable live/progress pixmaps are shed here.
        for name in (
            "live_picon","adaptive_live_picon","progress_neon","progress_head"
        ):
            if name in ("progress_neon","progress_head"):
                self._laser_beam_path="";self._laser_head_path="";self._laser_end=-1
            try:
                widget=self[name]
                if widget.instance is not None:widget.instance.setPixmap(None)
                try:widget.hide()
                except Exception as exc:optional_failure("player.silent_guard",exc)
            except Exception as exc:optional_failure("player.silent_guard",exc)
        if aggressive:
            try:self.PicLoad.PictureData.get().remove(self._decode_poster)
            except Exception as exc:optional_failure("player.silent_guard",exc)
            try:self.stream_info_timer.stop()
            except Exception as exc:optional_failure("player.silent_guard",exc)
        try:
            with _PROGRESS_FRAME_LOCK:_PROGRESS_FRAME_PENDING.clear()
        except Exception as exc:optional_failure("player.silent_guard",exc)
        try:gc.collect()
        except Exception as exc:optional_failure("player.silent_guard",exc)
        _malloc_trim()

    def _trailer922__complete_service_handoff(self, restore_service=True):
        """Finish playback ownership and optionally return to the captured service."""
        self._closing_playback=True
        self._cancel_smart_recovery()

        exit_timers=(
            "startup_timer","resume_timer","resume_verify_timer","subtitle_session_restore_timer","subtitle_default_timer",
            "progress_timer","progress_visual_timer","seek_apply_timer","hard_stop_timer","eof_guard_timer",
            "recovery_timer","auto_retry_delay_timer","retry_visual_success_timer","zap_switch_timer","stable_timer","stream_info_timer","vod_quality_timer",
            "memory_fuse_timer","hideTimer","lb_langs_timer",
        )
        for name in exit_timers:
            timer=getattr(self,name,None)
            if timer is None:
                continue
            try:
                timer.stop()
            except Exception as exc:
                optional_failure("player.silent_guard",exc)

        nav=getattr(getattr(self,"session",None),"nav",None)
        if nav is None:
            return False

        try:
            nav.stopService()
        except Exception as exc:
            optional_failure("player.service_handoff_stop",exc)

        # YouTube trailer streams may be owned by ServiceApp/exteplayer3 rather
        # than the native nav service.  stopService() can therefore close the UI
        # while the external decoder keeps audio alive.  Trailers are disposable
        # playback, so kill only the processes owned by this exact trailer before
        # restoring the Details screen/service.
        # R5.68: the same hard stop now runs for EVERY media type.  Live/VOD
        # played through ServiceApp/GstPlayer/exteplayer3 kept the external
        # decoder (audio + network) alive after EXIT because only trailers were
        # killed here.
        if True:
            try:
                force_session_silence(
                    self.session,self.streamurl,force=True,stop_native=True,
                    exclude_pids=self._external_player_baseline,
                    owned_pids=self._owned_external_pids,
                )
            except Exception as exc:
                optional_failure("player.trailer_exit_silence",exc)
            targets=set(getattr(self,"_owned_external_pids",set()) or set())
            try:
                targets.update(set(_matching_external_player_pids(self.streamurl))-set(self._external_player_baseline))
            except Exception as exc:
                optional_failure("player.trailer_exit_match",exc)
            for pid in list(targets):
                try:os.kill(int(pid),signal.SIGKILL)
                except OSError:pass
                except Exception as exc:optional_failure("player.trailer_exit_kill",exc)

        service_restored=False
        return_ref=str(getattr(self,"_return_service_ref_string","") or "")
        if restore_service and return_ref:
            try:
                nav.playService(eServiceReference(return_ref))
                service_restored=True
            except Exception as exc:
                optional_failure("player.service_handoff_restore",exc)

        if restore_service:
            restore_aspect_mode(getattr(self,"_return_aspect_ratio",None), switch_cls=eAVSwitch)

        self._service_handoff_done=True
        try:
            gc.collect()
            _malloc_trim()
        except Exception as exc:
            optional_failure("player.silent_guard",exc)
        return service_restored

    def _trailer922__begin_hard_stop_close(self, result):
        # Compatibility entry point used by the rest of Ultra Stalker. Normal
        # EXIT follows the deterministic stop/restore/close flow.
        self._hard_stop_pending_result=result
        self._hard_stop_closing=True
        skip_restore=bool(isinstance(result,dict) and result.get("next_episode"))
        restored=self._complete_service_handoff(restore_service=not skip_restore)
        if isinstance(result,dict):result["service_restored"]=bool(restored)
        self._finalize_player_close()

    def _trailer922__verify_hard_stop(self):
        # Kept only for compatibility with an already-armed timer. No retry loop.
        if self._hard_stop_closing:self._finalize_player_close()

    def _trailer922__finalize_player_close(self):
        runtime_breadcrumb("player_close",media_type=self.media_type,engine=int(self.servicetype or 0),handoff=True)
        result=self._hard_stop_pending_result or {"engine":self.servicetype,"started":self.started,"failed":self.failed}
        self._hard_stop_pending_result=None;self._hard_stop_closing=False;self.reference=None
        self.close(result)

    def _trailer922__close_player(self, extra=None, save_progress=True):
        if self.restored or self._hard_stop_closing:return
        self._next_episode_watch_cleanup()
        try:self._subtitle_session_capture()
        except Exception as exc:optional_failure("player.subtitle_session_close_capture",exc)
        self._closing_playback=True
        if save_progress and self.media_type in ("vod","series","episode","catchup"):
            try:self._save_history_progress(force=True)
            except Exception as exc:optional_failure("player.close_save",exc)
        try:
            from ..core.playback_buffer import stop_buffer
            stop_buffer(getattr(self, "_buffer_job", None), keep=True)
            self._buffer_job = None
            self._buffer_pending = None
            timer = getattr(self, "_buffer_timer", None)
            if timer is not None:
                timer.stop()
        except Exception:
            pass
        result={"engine":self.servicetype,"started":self.started,"failed":self.failed}
        # VOD quality is runtime-only presentation. Never feed it back into
        # Details/catalogue metadata; every title starts its own blank session.
        if isinstance(extra,dict):result.update(extra)
        self.restored=True
        self._suppress_service_events(2.5)
        self._begin_hard_stop_close(result)

    def _trailer922__cleanup(self):
        self._next_episode_watch_cleanup()
        try:self._live_picon_fetch_generation+=1;self._live_picon_fetch_inflight=False;self._live_picon_fetch_cancel.set()
        except Exception:pass
        runtime_breadcrumb("player_cleanup",media_type=self.media_type,engine=int(self.servicetype or 0))
        # Safety net for closes that bypass _close_player(): stop the playback
        # buffer job and its poll timer (idempotent; no-ops after a normal close).
        try:
            self._closing_playback=True
            from ..core.playback_buffer import stop_buffer
            job=getattr(self,"_buffer_job",None)
            self._buffer_job=None;self._buffer_pending=None
            if job is not None:stop_buffer(job,keep=True)
        except Exception as exc:optional_failure("player.cleanup_buffer_stop",exc)
        try:
            buffer_timer=getattr(self,"_buffer_timer",None)
            if buffer_timer is not None:buffer_timer.stop()
            buffer_conn=getattr(self,"_buffer_timer_conn",None)
            if buffer_conn is not None:buffer_conn.disconnect()
            self._buffer_timer_conn=None;self._buffer_timer=None
        except Exception as exc:optional_failure("player.cleanup_buffer_timer",exc)
        try:self._external_subtitle_ui_hold_end()
        except Exception:pass
        try:self._external_subtitle_stop()
        except Exception as exc:optional_failure("player.external_subtitle_cleanup",exc)
        try:self._player_title_logo_token+=1;self._player_title_logo_pending=False
        except Exception:pass
        try:self._online_subtitle_generation+=1;self._online_subtitle_cancel.set()
        except Exception:pass
        try:self._server_search_generation+=1;self._server_search_cancel.set()
        except Exception:pass
        try:
            while True:self._live_picon_fetch_queue.get_nowait()
        except queue.Empty:pass
        except Exception:pass
        try:
            owned=getattr(self,"_server_search_owned_client",None)
            if owned is not None:owned.close()
            self._server_search_owned_client=None
        except Exception:pass
        try:self._zap_switch_generation+=1;self._zap_switch_inflight=False;self._zap_switch_started_at=0.0
        except Exception:pass
        for future_name in ("_player_title_logo_future","_live_picon_fetch_future","_online_subtitle_future","_zap_switch_future","_auto_retry_future","_live_epg_future","_server_search_future"):
            future=getattr(self,future_name,None)
            if future is not None:
                try:future.cancel()
                except Exception as exc:optional_failure("player.future_cancel",exc)
            try:setattr(self,future_name,None)
            except Exception:pass
        # Never leave global receiver audio muted if the screen closes while a
        # resume probe is still in progress.
        try: self._release_resume_shield()
        except Exception as exc: optional_failure("player.resume_cleanup", exc)
        # Final idempotent safety net.  Repeat the complete native + pnav +
        # external stop sequence in case the screen was closed through an
        # unexpected Enigma2 path rather than back().
        if not getattr(self,"_service_handoff_done",False):
            try:
                force_session_silence(self.session, self.streamurl, force=True, stop_native=True, exclude_pids=self._external_player_baseline, owned_pids=self._owned_external_pids)
            except Exception as exc:
                optional_failure("player.cleanup_hard_stop", exc)
        for timer_name in ("startup_timer", "resume_timer", "resume_verify_timer", "subtitle_session_restore_timer", "subtitle_default_timer", "embedded_subtitle_probe_timer", "online_subtitle_timer", "online_subtitle_result_timer", "subtitle_volume_restore_timer", "external_subtitle_ui_timer", "server_search_timer", "progress_timer", "progress_visual_timer", "seek_apply_timer", "hard_stop_timer", "eof_guard_timer", "recovery_timer", "auto_retry_delay_timer", "retry_visual_success_timer", "live_epg_timer", "zap_switch_timer", "stable_timer", "stream_info_timer", "vod_quality_timer", "vod_audio_timer", "player_title_logo_timer", "memory_fuse_timer", "hideTimer", "_chrome_build_timer", "lb_langs_timer"):
            timer = getattr(self, timer_name, None)
            if timer is not None:
                try:
                    timer.stop()
                except Exception as exc:
                    optional_failure("player", exc)
        for conn_name in ("startup_timer_conn", "resume_timer_conn", "resume_verify_timer_conn", "subtitle_session_restore_timer_conn", "subtitle_default_timer_conn", "embedded_subtitle_probe_timer_conn", "online_subtitle_timer_conn", "online_subtitle_result_timer_conn", "subtitle_volume_restore_timer_conn", "external_subtitle_ui_timer_conn", "server_search_timer_conn", "progress_timer_conn", "progress_visual_timer_conn", "seek_apply_timer_conn", "hard_stop_timer_conn", "eof_guard_timer_conn", "recovery_timer_conn", "auto_retry_delay_timer_conn", "retry_visual_success_timer_conn", "live_epg_timer_conn", "zap_switch_timer_conn", "stable_timer_conn", "stream_info_timer_conn", "vod_quality_timer_conn", "vod_audio_timer_conn", "player_title_logo_timer_conn", "memory_fuse_timer_conn", "PicLoad_conn", "hideTimer_conn", "_chrome_build_timer_conn", "lb_langs_conn"):
            conn = getattr(self, conn_name, None)
            if conn is not None:
                try:
                    conn.disconnect()
                except Exception as exc:
                    optional_failure("player", exc)
        callback_map=(
            ("startup_timer",self._startup_timeout),("resume_timer",self._reference_resume),("resume_verify_timer",self._verify_resume_position),
            ("subtitle_session_restore_timer",self._subtitle_session_restore_tick),("subtitle_default_timer",self._enforce_default_subtitles_off),
            ("embedded_subtitle_probe_timer",self._embedded_subtitle_probe_tick),
            ("online_subtitle_timer",self._online_subtitle_tick),("online_subtitle_result_timer",self._drain_online_subtitle_result),
            ("subtitle_volume_restore_timer",self._restore_subtitle_after_volume_osd),("external_subtitle_ui_timer",self._external_subtitle_ui_watch),("server_search_timer",self._drain_server_search_result),
            ("progress_timer",self._periodic_progress_save),
            ("progress_visual_timer",self._update_progress_visual),("hard_stop_timer",self._verify_hard_stop),
            ("eof_guard_timer",self._verify_early_eof),("recovery_timer",self._drain_recovery_result),("auto_retry_delay_timer",self._run_deferred_auto_retry),("retry_visual_success_timer",self._confirm_retry_visual_success),("seek_apply_timer",self._apply_pending_seek),("live_epg_timer",self._drain_live_epg_result),("zap_switch_timer",self._drain_zap_switch_result),
            ("stable_timer",self._mark_stream_stable),("stream_info_timer",self._update_stream_info),("vod_quality_timer",self._vod_quality_probe_tick),("vod_audio_timer",self._vod_audio_probe_tick),
            ("player_title_logo_timer",self._drain_player_title_logo),("memory_fuse_timer",self._memory_fuse_tick),("hideTimer",self.doTimerHide),
            ("_chrome_build_timer",self._poll_adaptive_player_chrome),("lb_langs_timer",self._lb_langs_update),
        )
        for timer_name,callback in callback_map:
            timer=getattr(self,timer_name,None)
            if timer is None:continue
            try:
                if callback in timer.callback:timer.callback.remove(callback)
            except Exception as exc:optional_failure("player.timer_callback_remove",exc)
        try:
            callbacks=self.PicLoad.PictureData.get()
            if self._decode_poster in callbacks:callbacks.remove(self._decode_poster)
        except Exception as exc:optional_failure("player.picload_callback_remove",exc)
        try:
            if self._play_state_changed in self.onPlayStateChanged:self.onPlayStateChanged.remove(self._play_state_changed)
        except Exception as exc:optional_failure("player.playstate_callback_remove",exc)
        for hooks,callback,label in (
            (getattr(self,"onShow",None),self._restore_player_chrome_after_show,"player.show_chrome_hook_remove"),
            (getattr(self,"onShow",None),self._resume_hidden_visual_timers,"player.show_timer_hook_remove"),
            (getattr(self,"onHide",None),self._pause_hidden_visual_timers,"player.hide_timer_hook_remove"),
        ):
            try:
                if hooks is not None and callback in hooks:hooks.remove(callback)
            except Exception as exc:optional_failure(label,exc)
        try:
            if self._online_subtitle_display is not None:
                self._online_subtitle_display.hideScreen()
                deleter=getattr(self.session,"deleteDialog",None)
                if callable(deleter):deleter(self._online_subtitle_display)
                self._online_subtitle_display=None
        except Exception as exc:optional_failure("player.native_online_subtitle_cleanup",exc)
        # Release decoded poster/picon buffers promptly on constrained receivers.
        for widget_name in ("logo","live_picon","adaptive_main","adaptive_poster","adaptive_live_picon","title_logo","vod_quality_badge","audio_format_badge","progress_neon","progress_head",
                            "chip_video_quality_bg","chip_audio_codec_bg","chip_video_codec_bg","chip_fps_bg","chip_stream_bg","chip_audio_bg","chip_engine_bg",
                            "chip_video_quality","chip_audio_codec","chip_video_codec","chip_fps","chip_stream","chip_audio","chip_engine")+_LB_PIXMAPS:
            try:
                widget=self[widget_name]
                if widget.instance is not None:widget.instance.setPixmap(None)
            except Exception as exc:optional_failure("player.optional_guard",exc)

    def _trailer922__exit_or_close_subtitle_overlay(self):
        """EXIT closes Player-owned inline UI before leaving playback."""
        buffer_overlay=getattr(self,"_buffer_inline_overlay",None)
        try:
            if buffer_overlay is not None and buffer_overlay.active:
                return buffer_overlay.close()
        except Exception as exc:
            optional_failure("player.buffer_menu_exit",exc)
        search_overlay=getattr(self,"_server_search_inline_overlay",None)
        try:
            if search_overlay is not None and search_overlay.active:
                return search_overlay.close()
            if getattr(self,"_server_search_mode_active",False):
                self._server_search_end_hold(hide_infobar=True)
                return True
        except Exception as exc:
            optional_failure("player.server_search_exit",exc)
        overlay=getattr(self,"_subtitle_inline_overlay",None)
        try:
            if overlay is not None and overlay.active:
                return overlay.close()
        except Exception as exc:
            optional_failure("player.subtitle_exit",exc)
        return self._close_player(save_progress=True)

    def _trailer922_back(self):
        self._close_player(save_progress=True)

