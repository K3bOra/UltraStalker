# -*- coding: utf-8 -*-
"""Artwork and visual preparation helpers for Ultra Stalker Player.

Player material is bundled opaque Premium chrome. Artwork identity, playback
progress and other overlay helpers retain their established behavior.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .. import us_env as _us_env
from ..us_env import str, int, round, zip, max, min, OSError

try:
    import colorsys
except Exception:
    from .. import compat_colorsys as colorsys

hashlib = _us_env.hashlib
os = _us_env.os
re = _us_env.re
import stat
threading = _us_env.threading
OrderedDict = _us_env.collections.OrderedDict

try:
    from PIL import Image as _PILImage, ImageDraw as _ImageDraw, ImageFilter as _ImageFilter
except Exception:
    _PILImage = None
    _ImageDraw = None
    _ImageFilter = None

from ..core.image_budget import image_budgeted
from ..securefs import secure_private_dir
from ..persistent_cache import ROOT as PERSISTENT_CACHE_ROOT, GENERATED as PERSISTENT_GENERATED_DIR
from ..storage import load_settings
from ..adaptive_mode import adaptive_enabled, fixed_palette
from ..ui_artwork_helpers import _fit_live_picon_canvas
from ..log import optional_failure
from .player_visuals import (
    _PROGRESS_FRAME_EXECUTOR, _PROGRESS_FRAME_PENDING, _PROGRESS_FRAME_LOCK,
    _progress_neon_frame, _schedule_progress_neon_frame, _letter_logo, _image_value,
)

PLUGIN_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ASSET_DIR = os.path.join(PLUGIN_DIR, "assets_fhd")
PLAYER_ASSET_DIR = os.path.join(ASSET_DIR, "player")
PLAYER_FALLBACK_INFOBAR_DIR = os.path.join(PLAYER_ASSET_DIR, "infobar_premium")

# Stage-2: bounded in-memory artwork memoization. Persistent files remain the
# source of truth; these caches only avoid reopening/re-analysing the same
# unchanged source image repeatedly during one Player session.
_ARTWORK_MEMO_LIMIT = 48
_ARTWORK_MEMO_LOCK = threading.RLock()
_FALLBACK_FRAMES_MEMO = None
_ADAPTIVE_INFO_MEMO = OrderedDict()
_LIVE_PICON_MEMO = OrderedDict()
_POSTER_RESOLUTION_MEMO = OrderedDict()

def _source_signature(path, min_size=1):
    try:
        source = str(path or "")
        if not source:
            return None
        st = os.stat(source)
        if not stat.S_ISREG(st.st_mode) or int(st.st_size) < int(min_size):
            return None
        stamp = int(getattr(st, "st_mtime_ns", int(st.st_mtime * 1000000000)))
        return (source, stamp, int(st.st_size))
    except Exception:
        return None

def _memo_get(cache, key):
    with _ARTWORK_MEMO_LOCK:
        value = cache.get(key)
        if value is None:
            return None
        try:
            cache.move_to_end(key)
        except Exception:
            pass
        return value

def _memo_put(cache, key, value):
    with _ARTWORK_MEMO_LOCK:
        cache[key] = value
        try:
            cache.move_to_end(key)
        except Exception:
            pass
        while len(cache) > _ARTWORK_MEMO_LIMIT:
            try:
                cache.popitem(last=False)
            except Exception:
                break
    return value

def _fallback_player_frames():
    """Bundled opaque Premium Player material, independent of old HDD caches.

    This is intentionally independent of poster/picon/HDD state.  It is the
    first-line player chrome so a late/missing adaptive source can never leave
    naked text and controls floating over video.
    """
    global _FALLBACK_FRAMES_MEMO
    with _ARTWORK_MEMO_LOCK:
        if _FALLBACK_FRAMES_MEMO is not None:
            return dict(_FALLBACK_FRAMES_MEMO)
    names=("main","poster","live_picon","track","keybar",
           "chip_quality","chip_video","chip_audio_codec",
           "chip_fps","chip_stream","chip_audio","chip_subtitles","chip_engine")
    out={}
    for name in names:
        path=os.path.join(PLAYER_FALLBACK_INFOBAR_DIR,"%s.png"%name)
        if os.path.isfile(path):
            out[name]=path
    out["accent"]="#6dcca1"
    out["accent_soft"]="#a8e3c8"
    out["accent_neon"]="#6dcca1"
    with _ARTWORK_MEMO_LOCK:
        _FALLBACK_FRAMES_MEMO=dict(out)
    return dict(out)

def _item_library_palette(item, media_type):
    """Library palette of the verified title (same source Details uses), or None.

    Only the verified/locked TMDb id is trusted; a raw provider id could belong
    to another title, in which case the poster-derived palette is used instead.
    """
    try:
        if str(media_type or "").lower() in ("itv","live") or not isinstance(item,dict):
            return None
        tid=item.get("_locked_tmdb_id") or item.get("_player_title_logo_tmdb_id")
        if tid in (None,""):
            return None
        mt=str(item.get("_trailer_parent_media_type") or media_type or "").lower()
        kind="tv" if mt in ("series","tv","episode","show") else "movie"
        from ..media_library import adaptive_palette_for_item
        return adaptive_palette_for_item(kind,tid)
    except Exception:
        return None




def _adaptive_player_frames_memo(source_path, palette=None):
    """R5.458: the only Player material is the bundled opaque Premium set."""
    return _fallback_player_frames()


def _adaptive_player_frames(source_path, palette=None):
    """Compatibility entry point: no legacy tinted/translucent Player builders.

    All panels and the exact-fit poster bezel are pre-rendered in the package.
    Source/palette do not alter the material or revive old HDD chrome caches.
    """
    return _fallback_player_frames()


LASER_W, LASER_H, LASER_HEAD_W, LASER_HEAD_TIP = 1350, 8, 8, 8
LASER_X, LASER_Y = 370, 905


def _render_laser_pair(accent_hex):
    """R5.18: the watched part fills the 1350x8 progress track EXACTLY.

    One pill-shaped bar (same 8px height / 4px radius as the track, no outer
    glow) plus one 8x8 rounded tip.  Progress = clip the bar width + move the tip,
    so playback never renders a PNG per percentage.
    """
    if _PILImage is None or _ImageDraw is None:
        return None
    hx=str(accent_hex or "#75d2ab").lstrip("#")
    if len(hx)!=6: hx="55b9ff"
    accent=tuple(int(hx[i:i+2],16) for i in (0,2,4))
    def mix(a,b,t):return tuple(int(a[i]*(1.0-t)+b[i]*t) for i in range(3))
    # Play position is the Settings mint: #6dcca1 fading to #c4f3df. The buffer ahead is the frosted bar.
    rows=[(109,204,161)]*8
    w,h=LASER_W,LASER_H;ss=4
    def pill(width):
        m=_PILImage.new("L",(width*ss,h*ss),0)
        _ImageDraw.Draw(m).rounded_rectangle((0,0,width*ss-1,h*ss-1),radius=4*ss,fill=255)
        return m.resize((width,h),getattr(getattr(_PILImage,"Resampling",_PILImage),"BOX",4))
    # mint start -> warm middle -> red head, same red/green family as the player chrome
    ramp=((109,204,161),(168,214,140),(222,190,110),(226,120,92),(212,65,79))
    def _beam_col(x):
        t=(x/float(w-1))*(len(ramp)-1);i=min(int(t),len(ramp)-2);return mix(ramp[i],ramp[i+1],t-i)
    cols=list(_beam_col(x) for x in range(w))
    beam=_PILImage.new("RGB",(w,h))
    beam.putdata(list(cols[x] for y in range(h) for x in range(w)))
    beam=beam.convert("RGBA");beam.putalpha(pill(w))
    hw=LASER_HEAD_W
    tip_rows=[(255,214,214)]*8
    tcol=_PILImage.new("RGB",(1,h));tcol.putdata(tip_rows)
    head=tcol.resize((hw,h)).convert("RGBA");head.putalpha(pill(hw))
    return beam,head


def _buffer_glass_asset():
    """One frosted bar. Playback clips it to show how far the download has reached."""
    try:
        cache=os.path.join(PERSISTENT_GENERATED_DIR,"progress_laser_v580")
        path=os.path.join(cache,"buffer_glass_v4.png")
        if os.path.isfile(path):
            return path
        if _PILImage is None or _ImageDraw is None:
            return ""
        secure_private_dir(cache)
        w,h=LASER_W,LASER_H
        ss=4
        mask=_PILImage.new("L",(w*ss,h*ss),0)
        _ImageDraw.Draw(mask).rounded_rectangle((0,0,w*ss-1,h*ss-1),radius=4*ss,fill=135)
        mask=mask.resize((w,h),getattr(getattr(_PILImage,"Resampling",_PILImage),"BOX",4))
        img=_PILImage.new("RGBA",(w,h),(214,220,226,0))
        img.putalpha(mask)
        tmp=path+".tmp.%d.%d"%(os.getpid(),threading.get_ident())
        img.save(tmp,"PNG",compress_level=1)
        os.replace(tmp,path)
        return path
    except Exception as exc:
        optional_failure("player.buffer_glass",exc)
        return ""


_LASER_PENDING=set()


def _laser_assets(accent_hex):
    """Return (beam, head) paths; build them once in the background if missing."""
    try:
        hx=str(accent_hex or "#75d2ab").lstrip("#")
        if len(hx)!=6: hx="55b9ff"
        cache=os.path.join(PERSISTENT_GENERATED_DIR,"progress_laser_v580")
        beam=os.path.join(cache,"%s_beam.png"%hx);head=os.path.join(cache,"%s_head.png"%hx)
        if os.path.isfile(beam) and os.path.isfile(head):return beam,head
        with _PROGRESS_FRAME_LOCK:
            if hx in _LASER_PENDING:return "",""
            _LASER_PENDING.add(hx)
        def work():
            try:
                secure_private_dir(cache)
                pair=_render_laser_pair("#"+hx)
                if pair:
                    for img,path in zip(pair,(beam,head)):
                        tmp=path+".tmp.%d.%d"%(os.getpid(),threading.get_ident());img.save(tmp,"PNG",compress_level=1);os.replace(tmp,path)
            except Exception as exc:optional_failure("player.laser_build",exc)
            finally:
                with _PROGRESS_FRAME_LOCK:_LASER_PENDING.discard(hx)
        try:
            _PROGRESS_FRAME_EXECUTOR.submit(work)
        except Exception:
            # A refused submit must not leave the colour marked as "building"
            # forever, or the laser assets would never be retried.
            with _PROGRESS_FRAME_LOCK:_LASER_PENDING.discard(hx)
            raise
    except Exception as exc:optional_failure("player.laser_assets",exc)
    return "",""






def _asset(name):
    return os.path.join(ASSET_DIR, name)






IMAGE_CACHE_DIR = os.path.join(PERSISTENT_GENERATED_DIR,"player_images")
try:
    secure_private_dir(IMAGE_CACHE_DIR)
except OSError:
    pass




@image_budgeted
def _adaptive_info_frames(source_path=None, palette=None):
    """Bundled premium Information panels; no runtime rendering or cache IO."""
    names = ("main", "poster", "rating", "facts", "desc", "cast", "director",
             "writer", "desc_d", "cast_d", "director_d", "writer_d", "extra")
    directory = os.path.join(PLAYER_ASSET_DIR, "premium_information_r5424")
    return {name: os.path.join(directory, "%s.png" % name) for name in names}


def _cached_poster(item, name, media_type):
    is_live=str(media_type or "").lower() in ("itv","live")
    data=item if isinstance(item,dict) else {}
    # Only memoize a real resolved file. Placeholders are intentionally never
    # memoized because a Live picon can arrive asynchronously a moment later.
    relevant=(
        str(data.get("_player_picon") or ""), str(data.get("_player_poster") or ""),
        str(data.get("_player_picon_url") or ""), str(data.get("stream_icon") or ""),
        str(data.get("picon") or ""), str(data.get("logo") or ""),
        str(data.get("poster") or ""), str(data.get("poster_url") or ""),
        str(data.get("cover") or ""), str(data.get("cover_url") or ""),
        str(data.get("icon") or ""), str(data.get("image") or ""), str(data.get("img") or ""),
    )
    memo_key=(str(media_type or "").lower(),str(name or ""),relevant)
    cached=_memo_get(_POSTER_RESOLUTION_MEMO,memo_key)
    if cached and _source_signature(cached,101) is not None:
        return cached

    explicit_key="_player_picon" if is_live else "_player_poster"
    direct = str(data.get(explicit_key) or data.get("_player_poster") or "").strip()
    if direct and _source_signature(direct,1) is not None:
        return _memo_put(_POSTER_RESOLUTION_MEMO,memo_key,direct)
    value = _image_value(data)
    if value and _source_signature(value,1) is not None:
        return _memo_put(_POSTER_RESOLUTION_MEMO,memo_key,value)
    # Prefer the absolute picon URL attached by the browser; its digest is the
    # same persistent HDD cache key used by the live grid.
    candidate_urls=[]
    if is_live:
        picon_url=str(data.get("_player_picon_url") or data.get("stream_icon") or data.get("picon") or data.get("logo") or data.get("icon") or data.get("image") or data.get("img") or "").strip()
        if picon_url:value=picon_url
        try:
            from ..provider_art import picon_urls
            base=str(data.get("_art_base") or data.get("_portal") or "").strip()
            candidate_urls=list(picon_urls(data,{"portal":base}) or [])
        except Exception:
            candidate_urls=[]
    if value and value.startswith(("http://", "https://")) and value not in candidate_urls:
        candidate_urls.insert(0,value)
    roots=[IMAGE_CACHE_DIR]
    if is_live:
        roots.insert(0,os.path.join(PERSISTENT_CACHE_ROOT,"live_picons"))
    for cand_url in candidate_urls[:6]:
        if not cand_url.startswith(("http://", "https://")):continue
        digest = hashlib.sha1(cand_url.encode("utf-8", "ignore")).hexdigest()
        for root in roots:
            for ext in (".png", ".jpg", ".jpeg", ".webp"):
                candidate = os.path.join(root, digest + ext)
                if _source_signature(candidate,16 if is_live else 101) is not None:
                    return _memo_put(_POSTER_RESOLUTION_MEMO,memo_key,candidate)
    # Live must never show a generated initial/letter. Until a real picon is
    # available use the neutral live asset; do not memoize it.
    if is_live:
        return _asset("us168_live_placeholder_220x132.png")
    return _letter_logo(name, media_type)

@image_budgeted
def _prepare_player_poster_fill(source_path, size=(242,330)):
    """Player reuses the exact HDD master poster path; no player-only poster copy."""
    return source_path

@image_budgeted
def _prepare_live_picon(source_path, size=(220,132)):
    """Aspect-fit Live picon on an exact transparent 220x132 Enigma-style canvas."""
    signature=_source_signature(source_path,101)
    if signature is None:return source_path
    try:tw,th=max(1,int(size[0])),max(1,int(size[1]))
    except Exception:tw,th=220,132
    memo_key=(signature,tw,th)
    cached=_memo_get(_LIVE_PICON_MEMO,memo_key)
    if cached and _source_signature(cached,101) is not None:return cached
    prepared=_fit_live_picon_canvas(signature[0],PERSISTENT_GENERATED_DIR,(tw,th)) or signature[0]
    if prepared and _source_signature(prepared,101) is not None:
        _memo_put(_LIVE_PICON_MEMO,memo_key,prepared)
    return prepared

def _player_title_logo_source(item, name, media_type):
    """Return the current title's cached logo authority, never a network lookup.

    Player is presentation-only.  It first honors an explicit current-screen
    handoff, then checks cached Ultra title-logo variants ((420,144), (432,210),
    (900,210), (900,125)) for the same locked TMDb identity.
    """
    item=item if isinstance(item,dict) else {}
    try:
        for key in ("_player_title_logo_cinematic_source","title_logo_local","logo_local"):
            candidate=str(item.get(key) or "")
            if candidate and os.path.isfile(candidate) and os.path.getsize(candidate)>256:return candidate
        from ..title_logo_ultra import (
            ultra_title_logo_cached, ultra_title_logo_cache_path,
            ultra_title_logo_identity_id, title_logo_policy_languages,
            valid_ultra_title_logo,
        )
        for csize in ((420,144),(432,210),(900,210),(900,125)):
            hit=ultra_title_logo_cached(media_type,item,item,csize,name)
            if hit and valid_ultra_title_logo(hit):return hit
        tmdb_id=ultra_title_logo_identity_id(item,item) or item.get("_player_title_logo_tmdb_id") or item.get("_locked_tmdb_id") or item.get("tmdb_id")
        if tmdb_id:
            langs=list(title_logo_policy_languages(item,item) or ())
            for extra_lang in ("ar","en","any","00"):
                if extra_lang not in langs:langs.append(extra_lang)
            for csize in ((900,210),(420,144),(432,210),(900,125)):
                for lang in langs:
                    p=ultra_title_logo_cache_path(media_type,tmdb_id,lang,csize)
                    if p and valid_ultra_title_logo(p):return p
        return ""
    except Exception as exc:
        optional_failure("player.title_logo_source",exc);return ""

def _prepare_player_title_logo_cache_path(source_path, canvas_size=(1220,78)):
    try:
        source=str(source_path or "")
        if not source or not os.path.isfile(source) or os.path.getsize(source)<=256:return ""
        st=os.stat(source)
        stamp="%s|%s"%(int(getattr(st,"st_mtime_ns",int(st.st_mtime*1000000000))),int(st.st_size))
        try:
            cw,ch=int(canvas_size[0]),int(canvas_size[1])
        except Exception:
            cw,ch=1220,78
        digest=hashlib.sha1((source+"|"+stamp+"|player-title-logo-%sx%s-v3"%(cw,ch)).encode("utf-8","ignore")).hexdigest()[:20]
        return os.path.join(PERSISTENT_GENERATED_DIR,"player_title_logos","%s.png"%digest)
    except Exception:return ""

@image_budgeted
def _prepare_player_title_logo(source_path, canvas_size=(1220,78)):
    """Create a pristine persistent Player presentation from the HDD master.

    Transparent margins are trimmed first, aspect ratio is preserved exactly,
    and LANCZOS is used only for down-scaling. The master is never modified.
    """
    if _PILImage is None:return ""
    try:
        source=str(source_path or "")
        if not source or not os.path.isfile(source) or os.path.getsize(source)<=256:return ""
        cw,ch=int(canvas_size[0]),int(canvas_size[1])
        target=_prepare_player_title_logo_cache_path(source,(cw,ch))
        if not target:return ""
        cache=os.path.dirname(target)
        secure_private_dir(cache)
        if os.path.isfile(target) and os.path.getsize(target)>256:return target
        with _PILImage.open(source) as src:
            im=src.convert("RGBA")
            try:
                bbox=im.getchannel("A").getbbox()
                if bbox:im=im.crop(bbox)
            except Exception:pass
            if im.width<2 or im.height<2:return ""
            max_w,max_h=max(1,cw-24),max(1,ch-4)
            scale=min(float(max_w)/float(im.width),float(max_h)/float(im.height),1.0)
            nw=max(1,int(round(im.width*scale)));nh=max(1,int(round(im.height*scale)))
            if (nw,nh)!=im.size:
                res=getattr(getattr(_PILImage,"Resampling",_PILImage),"LANCZOS",1)
                im=im.resize((nw,nh),res)
            canvas=_PILImage.new("RGBA",(cw,ch),(0,0,0,0))
            canvas.alpha_composite(im,((cw-nw)//2,max(0,(ch-nh)//2)))
            tmp=target+".tmp.%d.%d"%(os.getpid(),threading.get_ident())
            canvas.save(tmp,"PNG",compress_level=1);os.replace(tmp,target)
        return target if os.path.isfile(target) and os.path.getsize(target)>256 else ""
    except Exception as exc:
        optional_failure("player.title_logo_prepare",exc);return ""

def _apply_player_font_scale(xml):
    try:mode=str(load_settings().get("font_scale") or "normal").lower()
    except Exception:mode="normal"
    factor={"normal":1.0,"large":1.12,"larger":1.22,"xlarge":1.32}.get(mode,1.0)
    if factor<=1.0:return xml
    def _font(m):
        base=int(m.group(2))
        if base<12 or base>=56:return m.group(0)
        size=max(base,min(base+10,int(round(base*factor))))
        return 'font="%s;%d"'%(m.group(1),size)
    return re.sub(r'font="([^;]+);(\d+)"',_font,xml)
