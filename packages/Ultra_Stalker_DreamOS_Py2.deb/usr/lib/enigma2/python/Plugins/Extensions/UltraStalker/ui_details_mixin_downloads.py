# -*- coding: utf-8 -*-
"""Inline downloads overlay.

Methods moved verbatim out of ``ContentDetailsScreen`` (ui_screens_details.py); behaviour is unchanged.
This module is imported by ui_screens_details.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, round, max, min
from .ui_screens_details import (
    _,
    os,
    show_notice,
)


class DetailsDownloadsMixin(object):
    """Inline downloads overlay."""

    def _download_menu_selected(self, choice):
        if not choice:return
        action=choice[1]
        if action=='manual_match' and self.media_type in ('vod','series'):
            from .ui_manual_match import open_picker,refresh_details
            open_picker(self,getattr(self,'_portal_item',self.item),lambda changed:refresh_details(self,changed))
            return
        if action=="set_home_hero":
            self._pin_current_as_home_hero();return
        if action=="manager":
            self._show_downloads_inline(getattr(self,"_adaptive_source_local","") or getattr(self,"_backdrop_displayed_path","") or (self.item.get("_backdrop_source_local") if isinstance(self.item,dict) else ""));return
        if action=="reload":
            self.reload_image();return
        if action=="movie":
            item=dict(self.item)
            job=movie_job(self.profile,item)
            client=self.client
            def resolver():return client.create_link(item,"vod")
            ok,msg=DOWNLOADS.add(job,resolver)
            self["status"].setText(_(msg))
            if ok or str(msg) in ("Already queued","Already downloaded"):
                self._show_downloads_inline()

    # ------------------------------------------------------------------
    # R5.239 SAME-SCREEN DOWNLOADS OVERLAY
    # Information does not open another Screen: it shows widgets over the live
    # Details page. Downloads now follows that exact presentation mechanism.
    # ------------------------------------------------------------------
    def _downloads_inline_geom(self,name,x,y,w,h):
        try:
            desktop=getDesktop(0).size();sx=float(desktop.width())/1920.0;sy=float(desktop.height())/1080.0
            inst=self[name].instance
            if inst is not None:
                inst.move(ePoint(int(round(x*sx)),int(round(y*sy))))
                inst.resize(eSize(max(1,int(round(w*sx))),max(1,int(round(h*sy)))))
        except Exception as exc:optional_failure("ui.download_inline_geom",exc)

    def _downloads_layout_inline(self):
        count=max(1,min(4,len(self._downloads_rows or [])))
        list_h=count*80
        panel_x=480;panel_w=960;panel_h=190+list_h
        panel_y=(1080-panel_h)//2
        try:
            from .ui_icon_menu import _us_fit_png
            desktop=getDesktop(0).size();sx=float(desktop.width())/1920.0;sy=float(desktop.height())/1080.0
            path=(getattr(self,"_downloads_chrome",None) or {}).get("download_panel")
            if path and os.path.isfile(path) and self["downloads_frame"].instance is not None:
                fpath=_us_fit_png(path,max(1,int(round(panel_w*sx))),max(1,int(round(panel_h*sy))),True)
                if fpath and os.path.isfile(fpath):
                    self["downloads_frame"].instance.setPixmapFromFile(fpath)
        except Exception as exc:optional_failure("ui.download_inline_panel_fit",exc)
        self._downloads_inline_geom("downloads_frame",panel_x,panel_y,panel_w,panel_h)
        self._downloads_inline_geom("downloads_title",panel_x+40,panel_y+24,880,46)
        self._downloads_inline_geom("downloads_summary",panel_x+40,panel_y+74,880,30)
        self._downloads_inline_geom("downloads_list",panel_x+40,panel_y+112,880,max(1,list_h))
        footer_y=panel_y+panel_h-56
        self._downloads_inline_geom("downloads_red_dash",panel_x+24,footer_y-2,56,42)
        self._downloads_inline_geom("downloads_red",panel_x+80,footer_y,115,38)
        self._downloads_inline_geom("downloads_yellow_dash",panel_x+202,footer_y-2,56,42)
        self._downloads_inline_geom("downloads_yellow",panel_x+258,footer_y,220,38)
        self._downloads_inline_geom("downloads_green_dash",panel_x+470,footer_y-2,56,42)
        self._downloads_inline_geom("downloads_green",panel_x+526,footer_y,190,38)
        self._downloads_inline_geom("downloads_blue_dash",panel_x+716,footer_y-2,56,42)
        self._downloads_inline_geom("downloads_blue",panel_x+772,footer_y,150,38)

    @staticmethod
    def _downloads_human_bytes(value):
        try:value=max(0,int(value or 0))
        except Exception:value=0
        for base,label in ((1024.0**3,"GB"),(1024.0**2,"MB"),(1024.0,"KB")):
            if value>=base:
                return ("%.2f %s"%(value/base,label)) if label=="GB" else ("%.1f %s"%(value/base,label))
        return "%d B"%value

    def _downloads_apply_inline_chrome(self):
        # The approved Downloads panel/rows/progress remain byte-for-byte assets.
        base=os.path.join(os.path.dirname(__file__),"assets_fhd","fixed_master_r63","downloads")
        self._downloads_chrome={
            "download_panel":os.path.join(base,"downloads_overlay_panel_1320x670.png"),
            "download_row":os.path.join(base,"downloads_overlay_row_1090x72.png"),
            "download_focus":asset("poster_cursor_row_1090x72.png"),
            "progress_track":os.path.join(os.path.dirname(base),"home_recent_pbar_track.png"),
            "progress_fill":os.path.join(os.path.dirname(base),"home_recent_pbar_fill.png"),
        }
        try:
            # Literal reuse of the Information dim/frost resolver.
            scrim=self._build_information_frost()
            if scrim and os.path.isfile(scrim) and self["downloads_scrim"].instance is not None:
                self["downloads_scrim"].instance.setPixmapFromFile(scrim)
        except Exception as exc:optional_failure("ui.download_inline_scrim",exc)
        try:
            from .ui_icon_menu import _us_fit_png
            desktop=getDesktop(0).size();sx=float(desktop.width())/1920.0;sy=float(desktop.height())/1080.0
            count=max(1,min(4,len(self._downloads_rows or [])))
            path=self._downloads_chrome.get("download_panel")
            if path and os.path.isfile(path) and self["downloads_frame"].instance is not None:
                fpath=_us_fit_png(path,max(1,int(round(960*sx))),max(1,int(round((190+count*80)*sy))),True)
                self["downloads_frame"].instance.setPixmapFromFile(fpath or path)
        except Exception as exc:optional_failure("ui.download_inline_panel",exc)

    def _downloads_selection_changed(self):
        if getattr(self,"_downloads_inline_active",False) and not getattr(self,"_downloads_rendering",False):
            self._downloads_render_rows()

    def _downloads_update_summary(self):
        counts={"active":0,"queued":0,"completed":0,"failed":0}
        for row in self._downloads_rows:
            status=str(row.get("status") or "queued").lower()
            if status in ("resolving","downloading"):counts["active"]+=1
            elif status in ("queued","paused"):counts["queued"]+=1
            elif status=="completed":counts["completed"]+=1
            elif status in ("failed","cancelled"):counts["failed"]+=1
        parts=[]
        if counts["active"]:parts.append(_("Active")+" %d"%counts["active"])
        if counts["queued"]:parts.append(_("Pending")+" %d"%counts["queued"])
        if counts["completed"]:parts.append(_("Completed")+" %d"%counts["completed"])
        if counts["failed"]:parts.append(_("Failed")+" %d"%counts["failed"])
        if not parts:parts=[_("No downloads yet")]
        try:self["downloads_summary"].setText("  •  ".join(parts))
        except Exception:pass

    def _downloads_render_rows(self):
        if self._downloads_rendering:return
        self._downloads_rendering=True
        try:
            selected=self["downloads_list"].getSelectedIndex() if self._downloads_rows else 0
            rows=[]
            for i,row in enumerate(self._downloads_rows):
                try:done=max(0,int(row.get("downloaded") or 0))
                except Exception:done=0
                try:total=max(0,int(row.get("total") or 0))
                except Exception:total=0
                pct=min(100,int(done*100.0/total)) if total else 0
                raw_status=str(row.get("status") or "queued").lower();status=_(raw_status.upper())
                done_text=self._downloads_human_bytes(done);total_text=self._downloads_human_bytes(total) if total else ""
                size_text=(done_text+" / "+total_text) if total_text else done_text
                progress=("%d%%"%pct) if total else (("100%") if raw_status=="completed" else "")
                meta={"selected":bool(i==selected),"status":status,"progress":progress,"size_text":size_text,"progress_pct":pct,
                      "progress_track":self._downloads_chrome.get("progress_track"),"progress_fill":self._downloads_chrome.get("progress_fill"),
                      "row_asset":self._downloads_chrome.get("download_row"),
                      "focus_asset":self._downloads_chrome.get("download_focus")}
                rows.append((_clean_display_text(row.get("title") or _("Download"),100),"",row,meta))
            self["downloads_list"].set_icon_rows(rows)
            if self._downloads_rows:
                try:self["downloads_list"].moveToIndex(min(selected,len(self._downloads_rows)-1))
                except Exception as exc:optional_failure("ui.download_inline_move",exc)
        finally:self._downloads_rendering=False
        self._downloads_update_summary()

    def _refresh_downloads_inline(self):
        if not getattr(self,"_downloads_inline_active",False):return
        selected=self["downloads_list"].getSelectedIndex() if self._downloads_rows else 0
        self._downloads_rows=DOWNLOADS.snapshot()
        layout_count=min(4,len(self._downloads_rows or []))
        if layout_count!=self._downloads_last_layout_count:
            self._downloads_last_layout_count=layout_count;self._downloads_layout_inline()
        self._downloads_render_rows()
        if self._downloads_rows:
            try:self["downloads_list"].moveToIndex(min(selected,len(self._downloads_rows)-1))
            except Exception as exc:optional_failure("ui.download_inline_restore_index",exc)

    def _downloads_selected_job(self):
        idx=self["downloads_list"].getSelectedIndex()
        return self._downloads_rows[idx] if 0<=idx<len(self._downloads_rows) else None

    def _downloads_cancel_selected(self):
        row=self._downloads_selected_job()
        if row:DOWNLOADS.cancel(row.get("id"));self._refresh_downloads_inline()

    def _downloads_retry_selected(self):
        row=self._downloads_selected_job()
        if row and row.get("status") in ("failed","cancelled","paused"):
            error=str(row.get("error") or "")
            if error.startswith("HLS playlist"):
                show_notice(self.session, _("This source uses HLS. Download requires a direct video link."), timeout=8, owner=self)
                return
            show_notice(self.session, _("Re-open the movie/episode and choose Download again to refresh its portal link."), timeout=7, owner=self)

    def _downloads_delete_selected(self):
        row=self._downloads_selected_job()
        if row:DOWNLOADS.remove(row.get("id"));self._refresh_downloads_inline()

    def _hide_downloads_inline(self,initial=False):
        for name in getattr(self,"_downloads_inline_widgets",()):
            try:self[name].hide()
            except Exception:pass
        if not initial:self._downloads_inline_active=False

    def _show_downloads_inline(self,source_path=""):
        # Exact Information behavior: same Screen, same dim scrim, local widgets.
        if getattr(self,"_downloads_inline_active",False):
            self._refresh_downloads_inline();return True
        if getattr(self,"_info_inline_active",False):self._close_information_overlay()
        self._downloads_apply_inline_chrome()
        try:
            if self["downloads_list"].instance is not None:
                self["downloads_list"].instance.setSelectionEnable(0);self["downloads_list"].instance.setTransparent(1)
        except Exception as exc:optional_failure("ui.download_inline_selection_native_off",exc)
        self._downloads_inline_active=True
        self._downloads_last_layout_count=-1
        self._refresh_downloads_inline()
        for name in self._downloads_inline_widgets:
            try:self[name].show()
            except Exception:pass
        try:self["actions"].setEnabled(False)
        except Exception:pass
        try:self["info_overlay_actions"].setEnabled(False)
        except Exception:pass
        try:self["downloads_overlay_actions"].setEnabled(True)
        except Exception:pass
        try:self._downloads_timer.stop();self._downloads_timer.start(1000,False)
        except Exception as exc:optional_failure("ui.download_inline_timer_start",exc)
        return True

    def _close_downloads_overlay(self,*args):
        if not getattr(self,"_downloads_inline_active",False):return
        try:self._downloads_timer.stop()
        except Exception:pass
        self._hide_downloads_inline()
        try:self["downloads_overlay_actions"].setEnabled(False)
        except Exception:pass
        try:self["actions"].setEnabled(True)
        except Exception:pass
        try:self._restore_details_visual_state()
        except Exception as exc:optional_failure("ui.download_inline_restore",exc)

    def _stop_downloads_inline(self):
        try:self._downloads_timer.stop()
        except Exception:pass
        try:
            if getattr(self,"_downloads_timer_conn",None) is not None:
                self._downloads_timer_conn.disconnect()
        except Exception:pass
        self._downloads_timer_conn=None
        try:
            if self._refresh_downloads_inline in self._downloads_timer.callback:
                self._downloads_timer.callback.remove(self._refresh_downloads_inline)
        except Exception:pass
        try:
            callbacks=self["downloads_list"].onSelectionChanged
            if self._downloads_selection_changed in callbacks:callbacks.remove(self._downloads_selection_changed)
        except Exception:pass
