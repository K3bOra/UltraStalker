# -*- coding: utf-8 -*-
"""Real TMDB cast portraits for Poster Grid 3 (R5.22).

Background-only helper.  For one title it returns the top billed cast as
``[{"id","name","role","image"}]`` where ``image`` is a ready 96x96 RGBA circle
PNG on the HDD (or "" while it is missing).

Quality rules (the user asked for real photos that are never pixelated):
* source is TMDB ``w185`` (185x278) - more than enough pixels for a 96px disc,
  never the tiny ``w45`` thumbnail and never an upscale;
* the square face crop is reduced ONCE with LANCZOS straight to 96x96;
* the circle mask is drawn at 4x and reduced with LANCZOS, so the edge is
  anti-aliased instead of stair-stepped;
* output is a true RGBA PNG (never palette-quantised).

Everything is cached permanently below the persistent root:
``cast_portraits/credits_<mt>_<id>.json`` and ``cast_portraits/p<person>_96.png``.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str, int, open, round, max, min, us_clear

hashlib = _us_env.hashlib
json = _us_env.json
os = _us_env.os
threading = _us_env.threading
time = _us_env.time
urllib = _us_env.urllib

from .persistent_cache import ROOT, hdd_ready, hdd_read_ready, persistent_write_gate

try:
    from PIL import Image as _Image, ImageDraw as _Draw, ImageOps as _Ops
except Exception:  # pragma: no cover - receiver without Pillow
    _Image = None
    _Draw = None
    _Ops = None

CAST_DIR = os.path.join(ROOT, "cast_portraits")
SIZE = 96
SOURCE_SIZE = "w185"
IMAGE_BASE = "https://image.tmdb.org/t/p"
CREDITS_TTL = 30 * 86400
_LOCKS = {}
_LOCKS_GUARD = threading.Lock()


def _lock(key):
    with _LOCKS_GUARD:
        lk = _LOCKS.get(key)
        if lk is None:
            if len(_LOCKS) > 256:
                us_clear(_LOCKS)
            lk = _LOCKS[key] = threading.Lock()
        return lk


def _cancelled(ev):
    try:
        return bool(ev is not None and ev.is_set())
    except Exception:
        return False


def _mt(media_type):
    value = str(media_type or "").lower()
    return "tv" if value in ("series", "tv", "show") else "movie"


def portrait_path(person_id):
    return os.path.join(CAST_DIR, "p%s_%d.png" % (int(person_id), SIZE))


def _valid(path, min_size=400):
    try:
        return bool(path) and os.path.isfile(path) and os.path.getsize(path) >= min_size
    except Exception:
        return False


def _atomic_write(path, data):
    if not persistent_write_gate(path):
        return False
    temp = "%s.tmp.%d.%d" % (path, os.getpid(), threading.get_ident())
    try:
        with open(temp, "wb") as h:
            h.write(data)
            h.flush()
            os.fsync(h.fileno())
        os.replace(temp, path)
        return True
    except Exception:
        try:
            os.unlink(temp)
        except Exception:
            pass
        return False


def circle_from_image(img, size=SIZE, ring=(255, 255, 255, 70)):
    """Face-aware square crop -> one LANCZOS reduction -> AA circle (RGBA)."""
    img = img.convert("RGB")
    w, h = img.size
    side = min(w, h)
    # TMDB profiles are 2:3 portraits; the face sits in the upper part, so the
    # square is taken from ~8% below the top instead of the centre.
    top = 0 if h <= w else int(min(h - side, round(h * 0.08)))
    left = max(0, (w - side) // 2)
    face = img.crop((left, top, left + side, top + side))
    face = face.resize((size, size), _Image.LANCZOS)
    ss = 4
    big = _Image.new("L", (size * ss, size * ss), 0)
    _Draw.Draw(big).ellipse((0, 0, size * ss - 1, size * ss - 1), fill=255)
    mask = big.resize((size, size), _Image.LANCZOS)
    out = _Image.new("RGBA", (size, size), (0, 0, 0, 0))
    out.paste(face, (0, 0), mask)
    if ring and ring[3] > 0:
        rb = _Image.new("L", (size * ss, size * ss), 0)
        d = _Draw.Draw(rb)
        d.ellipse((0, 0, size * ss - 1, size * ss - 1), fill=255)
        d.ellipse((2 * ss, 2 * ss, size * ss - 1 - 2 * ss, size * ss - 1 - 2 * ss), fill=0)
        rmask = rb.resize((size, size), _Image.LANCZOS).point(lambda v: v * ring[3] // 255)
        layer = _Image.new("RGBA", (size, size), ring[:3] + (0,))
        layer.putalpha(rmask)
        out = _Image.alpha_composite(out, layer)
    return out


def _fetch_bytes(url, timeout):
    from .netsec import validate_remote_media_url, build_safe_media_opener
    validate_remote_media_url(url)
    req = urllib.request.Request(url, headers={"User-Agent": "UltraStalker", "Accept": "image/jpeg,image/png"})
    with build_safe_media_opener().open(req, timeout=timeout) as response:
        data = response.read(2 * 1024 * 1024 + 1)
    if not (800 < len(data) <= 2 * 1024 * 1024):
        return None
    head = data[:12]
    if not (head.startswith(b"\x89PNG") or head.startswith(b"\xff\xd8\xff") or (head[:4] == b"RIFF" and head[8:12] == b"WEBP")):
        return None
    return data


def build_portrait(person_id, profile_path, timeout=6):
    """Return the cached 96px circle for one person, downloading w185 once."""
    if _Image is None or not person_id or not profile_path:
        return ""
    target = portrait_path(person_id)
    if _valid(target):
        return target
    if not hdd_ready():
        return ""
    with _lock("p%s" % person_id):
        if _valid(target):
            return target
        try:
            path = str(profile_path)
            if not path.startswith("/"):
                path = "/" + path
            data = _fetch_bytes(IMAGE_BASE + "/" + SOURCE_SIZE + path, timeout)
            if not data:
                return ""
            import io
            img = _Image.open(io.BytesIO(data))
            img.load()
            out = circle_from_image(img)
            buf = io.BytesIO()
            out.save(buf, "PNG", optimize=True)
            return target if _atomic_write(target, buf.getvalue()) else ""
        except Exception:
            return ""


def _credits_path(mt, tmdb_id, lang):
    tag = hashlib.sha1(str(lang or "").encode("utf-8")).hexdigest()[:6]
    return os.path.join(CAST_DIR, "credits_%s_%s_%s.json" % (mt, int(tmdb_id), tag))


def load_credits(settings, media_type, tmdb_id, limit=4, cancel_event=None):
    """Top billed cast with profile paths; HDD cache first, TMDB once."""
    mt = _mt(media_type)
    try:
        tmdb_id = int(tmdb_id)
    except Exception:
        return []
    cfg = settings or {}
    lang = str(cfg.get("tmdb_language") or "en-US").strip() or "en-US"
    path = _credits_path(mt, tmdb_id, lang)
    stale = []
    if hdd_read_ready():
        try:
            with open(path, "r", encoding="utf-8") as h:
                row = json.load(h)
            if isinstance(row, dict):
                if time.time() - float(row.get("at") or 0) < CREDITS_TTL:
                    return list(row.get("cast") or [])[:limit]
                stale = list(row.get("cast") or [])[:limit]
        except Exception:
            pass
    credential = str(cfg.get("tmdb_credential") or "").strip()
    if not credential or not cfg.get("tmdb_enabled", True) or _cancelled(cancel_event):
        return stale
    try:
        from .tmdb import TMDBClient
        timeout = min(7, max(3, int(cfg.get("timeout", 10) or 10)))
        client = TMDBClient(credential, lang, timeout)
        endpoint = "/%s/%d/%s" % (mt, tmdb_id, "aggregate_credits" if mt == "tv" else "credits")
        payload = client._get(endpoint, {"language": lang}) or {}
    except Exception:
        # R5.63: TMDB unreachable -> keep the expired HDD cast instead of none.
        return stale
    cast = []
    for p in (payload.get("cast") or []):
        if not isinstance(p, dict) or not p.get("id") or not p.get("name"):
            continue
        role = p.get("character") or ""
        if not role and isinstance(p.get("roles"), list) and p["roles"]:
            role = (p["roles"][0] or {}).get("character") or ""
        cast.append({"id": int(p["id"]), "name": str(p.get("name") or ""),
                     "role": str(role or "").split("/")[0].strip(),
                     "profile": str(p.get("profile_path") or "")})
        if len(cast) >= 8:
            break
    if hdd_ready():
        try:
            # An empty cast is usually "TMDb has not filled it in yet": let it
            # expire after one day instead of pinning it for the full TTL.
            stamp = int(time.time()) if cast else int(time.time()) - (CREDITS_TTL - 86400)
            _atomic_write(path, json.dumps({"at": stamp, "cast": cast}, ensure_ascii=False).encode("utf-8"))
        except Exception:
            pass
    return cast[:limit]


def cached_cast(settings, media_type, tmdb_id, limit=4):
    """HDD-only lookup (no network); safe for a quick worker pass."""
    mt = _mt(media_type)
    try:
        lang = str((settings or {}).get("tmdb_language") or "en-US").strip() or "en-US"
        with open(_credits_path(mt, int(tmdb_id), lang), "r", encoding="utf-8") as h:
            rows = list((json.load(h) or {}).get("cast") or [])[:limit]
    except Exception:
        return []
    out = []
    for r in rows:
        p = portrait_path(r.get("id") or 0) if r.get("id") else ""
        out.append({"id": r.get("id"), "name": r.get("name") or "", "role": r.get("role") or "",
                    "image": p if _valid(p) else ""})
    return out


def resolve_cast(settings, media_type, tmdb_id, limit=4, cancel_event=None):
    rows = load_credits(settings, media_type, tmdb_id, limit=limit, cancel_event=cancel_event)
    out = []
    for r in rows:
        if _cancelled(cancel_event):
            break
        image = build_portrait(r.get("id"), r.get("profile")) if r.get("profile") else ""
        out.append({"id": r.get("id"), "name": r.get("name") or "", "role": r.get("role") or "", "image": image})
    return out
