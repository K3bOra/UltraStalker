# -*- coding: utf-8 -*-
"""Type-specific manual TMDb search with bounded provider-title aliases."""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str, int, max, min, InterruptedError, us_casefold
re = _us_env.re
import unicodedata
from difflib import SequenceMatcher
from .verified_identity import media_kind,positive_id
from .title_clean import tmdb_search_aliases,tmdb_search_title

_KOREAN_TAG=re.compile(r'(?i)(?:\b(?:KR|KOR|KOREAN|K[ -]?DRAMA)\b|كوري(?:ة)?|الكوري(?:ة)?)')
_ROUTE=r'(?:KR|KOR|KOREAN|K[ -]?DRAMA|المسلسل\s+الكوري|مسلسل\s+كوري|الفيلم\s+الكوري|فيلم\s+كوري|الكوري(?:ة)?|كوري(?:ة)?)'

def _search_queries(value):
    raw=unicodedata.normalize('NFKC',str(value or '')).strip()[:160]
    clean=raw
    # Strip known country/category metadata only at explicit label boundaries.
    for _ in range(4):
        old=clean
        clean=re.sub(r'^\s*[\[({]\s*'+_ROUTE+r'\s*[\])}]\s*','',clean,flags=re.I)
        clean=re.sub(r'^\s*'+_ROUTE+r'\s*[:|┃-]+\s*','',clean,flags=re.I)
        clean=re.sub(r'\s*[:|┃-]+\s*'+_ROUTE+r'\s*$','',clean,flags=re.I)
        if clean==old:break
    candidates=list(tmdb_search_aliases(clean))
    full=tmdb_search_title(clean)
    # A bilingual provider label may concatenate two independent title aliases.
    # Preserve whole Hangul/Arabic phrases rather than transliterating them away.
    groups=re.findall(r'[A-Za-z][A-Za-z0-9\s\-\'’:,.!?]*|[\uac00-\ud7af\u1100-\u11ff\u3130-\u318f][\uac00-\ud7af\u1100-\u11ff\u3130-\u318f\s0-9]*|[\u0600-\u06ff][\u0600-\u06ff\s0-9]*',clean)
    if len(groups)>1:
        for group in groups:
            part=tmdb_search_title(group).strip(' -:|,.')
            if len(re.sub(r'\W','',part))>=2 and not re.fullmatch(_KOREAN_TAG, part):candidates.append(part)
    candidates.append(full)
    out=[];seen=set()
    for value in candidates:
        value=re.sub(r'\s+',' ',value).strip(' -:|,.')
        if value and us_casefold(value) not in seen:
            seen.add(us_casefold(value));out.append(value)
    return out[:3]

def _fold(value):
    return re.sub(r'[^\w]+',' ',us_casefold(unicodedata.normalize('NFKC',str(value or '')))).strip()

def search_candidates(client,query,media_type,page=1,cancel_event=None):
    queries=_search_queries(query)
    if not queries:return {'rows':[],'page':1,'total_pages':1}
    page=max(1,min(500,int(page)));rows=[];pages=1;errors=[];seen=set();successes=0
    kind=media_kind(media_type) or 'movie'
    for alias in queries:
        if cancel_event is not None and cancel_event.is_set():raise InterruptedError('Search cancelled')
        # English labels keep internationally released Korean titles recognisable;
        # text search itself supports original, translated and alternative names.
        language='en-US' if re.search(r'[A-Za-z]',alias) and not re.search(r'[^\x00-\x7f]',alias) else client.language
        try:
            data=client._get('/search/'+kind,{'query':alias,'page':page,'language':language,'include_adult':'false'})
            successes+=1;pages=max(pages,min(500,int(data.get('total_pages') or 1)))
            for result in (data.get('results') or [])[:20]:
                ident=positive_id(result.get('id'))
                if not ident or (kind,ident) in seen:continue
                seen.add((kind,ident));row=dict(result);row.update(tmdb_id=int(ident),media_type=kind)
                row['title']=str(result.get('title') or result.get('name') or result.get('original_title') or result.get('original_name') or '')
                rows.append(row)
        except Exception as exc:errors.append(exc)
    if cancel_event is not None and cancel_event.is_set():raise InterruptedError('Search cancelled')
    if not successes and errors:raise errors[0]
    wanted=list(_fold(q) for q in queries)
    korean_hint=bool(_KOREAN_TAG.search(str(query))) or bool(re.search(r'[\uac00-\ud7af]',str(query)))
    def rank(row):
        names=[_fold(row.get(key)) for key in ('title','name','original_title','original_name') if row.get(key)]
        score=max(list(SequenceMatcher(None,q,name).ratio() for q in wanted for name in names) or [0])
        exact=any(q==name for q in wanted for name in names)
        korean=row.get('original_language')=='ko' or 'KR' in (row.get('origin_country') or [])
        return (int(exact),int(korean_hint and korean),score)
    rows.sort(key=rank,reverse=True)
    return {'rows':rows,'page':page,'total_pages':pages,'partial':bool(errors)}


def verify_candidate(client,row):
    ident=positive_id(row.get('tmdb_id') or row.get('id'));kind=media_kind(row.get('media_type'))
    if not ident or not kind:raise ValueError('Invalid TMDb selection')
    data=client._get('/%s/%s'%(kind,ident),{'language':client.language})
    if positive_id(data.get('id'))!=ident:raise ValueError('TMDb returned a different identity')
    result=dict(data);result.update(tmdb_id=int(ident),media_type=kind)
    return result
