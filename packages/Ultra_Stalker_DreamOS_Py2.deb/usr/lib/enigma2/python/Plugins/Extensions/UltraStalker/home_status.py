# -*- coding: utf-8 -*-
"""Pure formatting for the fixed Home card; no I/O, requests or artwork work."""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str, OSError
from datetime import datetime
re = _us_env.re
time = _us_env.time

def expiry_date(value, compact=False):
    text=str(value or '').strip()
    if not text:return ''
    try:
        if re.fullmatch(r'\d{9,13}',text):
            stamp=float(text)
            if stamp>1e11:stamp/=1000
            dt=datetime.fromtimestamp(stamp)
        else:
            dt=None
            clean=re.sub(r',\s*\d{1,2}:\d{2}.*$','',text).strip()
            try:dt=datetime.fromisoformat(clean.replace('Z','+00:00'))
            except (ValueError,AttributeError):
                for pattern in ('%B %d, %Y','%d %B %Y','%d %b %Y','%Y-%m-%d','%d/%m/%Y'):
                    try:dt=datetime.strptime(clean,pattern);break
                    except ValueError:continue
            if dt is None:return text[:64]
        return '%d %s %d'%(dt.day,dt.strftime('%b' if compact else '%B'),dt.year)
    except (ValueError,OverflowError,OSError):return text[:64]

def updated_text(stamp, translate=lambda s:s):
    try:
        stamp=float(stamp or 0)
        if stamp>0:
            dt=time.localtime(stamp)
            return '%s • %d %s, %s'%(translate('Updated'),dt.tm_mday,time.strftime('%b',dt),time.strftime('%H:%M',dt))
    except (ValueError,OverflowError,OSError):pass
    return '%s • —'%translate('Updated')
