# -*- coding: utf-8 -*-
"""Startup hero timer, runtime timer pause/resume and UI hook teardown.

Methods moved verbatim out of ``PortalHomeScreen`` (ui_screens_home.py); behaviour is unchanged.
This module is imported by ui_screens_home.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, max
from .ui_screens_home import (
    LOG,
    _mem34,
    _ui_diag,
    diagnostic_failure,
    optional_failure,
    splash_home_is_warm,
    time,
)


class HomeLifecycleMixin(object):
    """Startup hero timer, runtime timer pause/resume and UI hook teardown."""

    def _stop_startup_hero_timer(self):
        try:self._startup_hero_timer.stop()
        except Exception:pass
        try:
            if self._startup_hero_conn is not None:self._startup_hero_conn.disconnect()
        except Exception:pass
        try:
            if self._startup_hero_apply in self._startup_hero_timer.callback:self._startup_hero_timer.callback.remove(self._startup_hero_apply)
        except Exception:pass

    def _startup_hero_apply(self):
        try:self._startup_hero_timer.stop()
        except Exception:pass
        if getattr(self,"_screen_closed",False) or not getattr(self,"_home_runtime_visible",True):
            return
        _phase=time.monotonic()
        try:self._load_home_hero()
        except Exception as exc:optional_failure("ui.home_startup_hero",exc)
        try:self._update_focus()
        except Exception as exc:optional_failure("ui.home_startup_focus",exc)
        if LOG is not None:LOG.info("PERF26 home deferred_hero_done elapsed_ms=%d",int((time.monotonic()-_phase)*1000))
        _mem34("home_hero_settled", recent_futures=len(getattr(self,"_recent_futures",set()) or set()))
        # R132/R81 transplant: on this receiver family the proven R81 order is
        # faster in practice. Warm category routing immediately after Hero paint
        # so the user reaches Live/Movies/Series from RAM, rather than starting
        # portal I/O exactly while the first LEFT/RIGHT presses are happening.
        _warm=False
        try:_warm=bool(splash_home_is_warm and splash_home_is_warm(self.profile))
        except Exception:_warm=False
        if not _warm:
            try:self._start_category_prefetch()
            except Exception as exc:optional_failure("ui.category_prefetch_start",exc)
        elif str((self.profile or {}).get("source_type") or "").lower() in ("m3u","stalker",""):
            try:self._start_quiet_catalogue_refresh()
            except Exception as exc:optional_failure("ui.quiet_catalogue_refresh_start",exc)
        elif LOG is not None:
            LOG.info("R268 home category_prefetch skipped reason=splash_warm")
        # Lower cards were already committed before first paint.  Do not run a
        # second setList/art bind here: that redundant deferred rebuild was the
        # visible flash reported on Home.  Keep the exact resident snapshot.
        _recent_phase=time.monotonic()
        if not bool(getattr(self,"_recent_snapshot_ready",False)):
            try:
                self._load_recent_cards(initial=True)
                self._recent_snapshot_ready=True
            except Exception as exc:optional_failure("ui.home_recent_deferred",exc)
        if LOG is not None:LOG.info("POINT5 home recent_resident_keep elapsed_ms=%d",int((time.monotonic()-_recent_phase)*1000))

    def _pause_home_runtime_timers(self):
        self._home_runtime_visible=False
        # Home stays alive underneath child screens. Keep Hero maintenance asleep until Home is shown again.
        for timer in (getattr(self,"_hero_timer",None),):
            if timer is None:continue
            try:timer.stop()
            except Exception as exc:optional_failure("ui.home_runtime_timer_pause",exc)

    def _resume_home_runtime_timers(self):
        if getattr(self,"_screen_closed",False):return
        self._home_runtime_visible=True
        for timer,interval in ((getattr(self,"_hero_timer",None),60000),):
            if timer is None:continue
            try:
                timer.stop();timer.start(interval,False)
            except Exception as exc:optional_failure("ui.home_runtime_timer_resume",exc)

    def _cancel_recent_futures(self):
        futures=getattr(self,"_recent_futures",None)
        if not isinstance(futures,set):
            futures=set();self._recent_futures=futures
        for future in list(futures):
            if future is None or future.done():
                futures.discard(future);continue
            try:future.cancel()
            except Exception as exc:optional_failure("ui.home_recent_future_cancel",exc)
            if future.done():futures.discard(future)

    def _ui_diag_home_close(self):
        _mem34("home_close")
        try:_ui_diag("ui_close",screen="home",lifetime_ms=int(max(0.0,(time.monotonic()-self._ui_diag_open_mono)*1000.0)))
        except Exception as exc: diagnostic_failure("ui.home.failsoft", exc)

    def _stop_home_ui_hooks(self):
        for hook_name, callback in (
            ("onShown", self._home_shown),
            ("onHide", self._home_hidden_release),
            ("onLayoutFinish", self._layout_ready),
        ):
            try:
                hooks=getattr(self,hook_name,None)
                if hooks is not None and callback in hooks:hooks.remove(callback)
            except Exception as exc:
                optional_failure("ui.home_hook_cleanup",exc)
