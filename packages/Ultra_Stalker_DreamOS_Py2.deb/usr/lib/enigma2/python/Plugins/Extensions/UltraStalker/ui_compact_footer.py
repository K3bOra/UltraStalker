"""Approved Category premium material; action geometry stays native."""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str, int, round, zip, max, min, us_et_fromstring, us_et_tostring
import xml.etree.ElementTree as ET
from types import MethodType
from Components.Pixmap import Pixmap
from enigma import ePoint, eSize, getDesktop
from .log import optional_failure
from .ui_icon_menu import _us_fit_png

_ASSETS = '/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/'
_COLORS = ('red', 'green', 'yellow', 'blue')
_PARTS = ('left', 'fade_left', 'middle', 'fade_right', 'right')
_CAP = 24     # corner caps keep their exact radius
_FADE = 700   # sheen strips: stretched, never the corners
_GAP_BOTTOM = 1  # transparent row inside the bar PNG + 1 = 2 px between the bar and the screen edge


def compact_footer_skin(xml):
    root = us_et_fromstring(xml)
    if any(n.get('name') == 'compact_footer_left' for n in root):
        return xml
    labels = list(n for n in root if n.get('name') in _COLORS)
    if not labels:
        return xml
    for node in labels:
        node.set('zPosition', str(max(26, int(node.get('zPosition', '4')))))
    for node in root:
        name = node.get('name', '')
        if name in tuple(c + suffix for c in _COLORS for suffix in ('_bg', '_dash')) or 'player_keyline_' in node.get('pixmap', ''):
            node.set('zPosition', str(max(25, int(node.get('zPosition', '3')))))
    z = min(int(n.get('zPosition', '26')) for n in labels) - 2
    from .wqhd_layout import wh as _wqhd_wh
    cap_w, cap_h = _wqhd_wh(24, 64)
    mid_w, mid_h = _wqhd_wh(1, 64)
    for part in _PARTS:
        root.append(ET.Element('widget', {
            'name': 'compact_footer_' + part, 'position': '3000,0',
            'size': ('%d,%d' % (cap_w, cap_h)) if part in ('left', 'right') else ('%d,%d' % (mid_w, mid_h)),
            'pixmap': _ASSETS + 'premium_footer_caps_r5424/' + part + '.png',
            'alphatest': 'blend', 'scale': '1', 'transparent': '1',
            'zPosition': str(z),
        }))
    return us_et_tostring(root)


def _install_compact_footer(screen):
    if getattr(screen, '_compact_footer_installed', False):
        return
    screen._compact_footer_installed = True
    for part in _PARTS:
        screen['compact_footer_' + part] = Pixmap()
    hidden = set()
    last_signature = [None]
    measured = {}
    last_wh = {}

    def _update():
        bars = [screen['compact_footer_' + part] for part in _PARTS]
        if any(bar.instance is None for bar in bars):
            return
        if getattr(screen, '_category_footer_active', False):
            last_signature[0] = None
            for bar in bars:
                bar.hide()
            return
        size = getDesktop(0).size()
        sx, sy = size.width() / 1920.0, size.height() / 1080.0
        # The surface is bundled. Recalculate only after real content/geometry
        # changes, never after an identical Label update or screen show.
        states = []
        for color in _COLORS:
            try:
                label = screen[color]
                inst = label.instance
                if inst is not None:
                    pos, box = inst.position(), inst.size()
                    states.append((color, id(inst), str(label.getText() or ''),
                                   color in hidden, pos.x(), pos.y(), box.width(), box.height()))
            except KeyError:
                pass
        context = []
        for name in ('context_title', 'context_subtitle'):
            try: context.append(str(screen[name].getText() or ''))
            except KeyError: pass
        signature = (size.width(), size.height(), tuple(states), tuple(context),
                     getattr(screen, '_compact_footer_anchor', None))
        if signature == last_signature[0]:
            return
        rects = []
        for color in _COLORS:
            if color in hidden:
                continue
            try:
                label = screen[color]
            except KeyError:
                continue
            inst = label.instance
            if inst is None or not str(label.getText() or '').strip():
                continue
            pos, box = inst.position(), inst.size()
            if pos.x() >= size.width() or pos.y() < 990 * sy or box.width() <= 1:
                continue
            try:
                key = (id(inst), str(label.getText() or ''), box.width(), box.height())
                if measured.get(color, (None, None))[0] != key:
                    measured[color] = (key, min(box.width(), max(1, inst.calculateSize().width() + (8 if _us_env.IS_DREAMOS else 0))))
                width = measured[color][1]
            except Exception:
                width = box.width()
            dash_x = pos.x() - int(round(58 * sx))
            for suffix in ('_dash', '_bg'):
                try:
                    dash_name = ('free_' + color + '_dash') if getattr(screen, '_compact_footer_anchor', None) and suffix == '_dash' else color + suffix
                    dash = screen[dash_name].instance
                    if dash is not None and dash.position().x() < size.width():
                        dash_x = dash.position().x()
                        break
                except KeyError:
                    pass
            rects.append((dash_x, pos.y(), pos.x() + width))
        if not rects:
            for bar in bars:
                bar.hide()
            last_signature[0] = signature
            return
        left = max(0, min(r[0] for r in rects) - int(round(8 * sx)))
        right = min(size.width(), max(r[2] for r in rects) + int(round(12 * sx)))
        height = max(1, int(round(64 * sy)))
        top = max(0, min(min(r[1] for r in rects) - int(round(11 * sy)), size.height() - height - max(1, int(round(_GAP_BOTTOM * sy)))))
        anchor = getattr(screen, '_compact_footer_anchor', None)
        if anchor:
            right = min(size.width(), int(round(anchor[0] * sx)))
            top = min(size.height() - height - max(1, int(round(_GAP_BOTTOM * sy))), int(round(anchor[1] * sy)) - height)
        # Corner caps keep the approved radius. The two sheen strips (red top-left,
        # gold bottom-right) and the plain middle stretch, including narrow Local bars
        # and alternate desktop sizes.  Each stretched piece is pre-fitted to its exact
        # target (width, height) so DreamOS ePixmap (which preserves aspect ratio when
        # scale=1) never squashes the middle/fade strips vertically.
        span = max(1, right - left)
        cap = min(int(round(_CAP * sx)), max(1, span // 2))
        rest = max(0, span - 2 * cap)
        fade = min(int(round(_FADE * sx)), rest // 2)
        mid = rest - 2 * fade
        widths = (cap, fade, mid, fade, cap)
        x = left
        for part, bar, width in zip(_PARTS, bars, widths):
            if width <= 0:
                bar.hide()
                continue
            wh = (int(width), int(height))
            if last_wh.get(part) != wh:
                try:
                    fit_path = _us_fit_png(_ASSETS + 'premium_footer_caps_r5424/' + part + '.png', wh[0], wh[1], False)
                    if fit_path and _us_env.os.path.isfile(fit_path):
                        bar.instance.setPixmapFromFile(fit_path)
                        last_wh[part] = wh
                except Exception as exc:
                    optional_failure("ui.compact_footer.fit", exc)
            bar.instance.move(ePoint(x, top))
            bar.instance.resize(eSize(width, height))
            bar.show()
            x += width
        changed = getattr(screen, '_compact_footer_changed', None)
        if callable(changed):
            changed((left, top, right, height))
        last_signature[0] = signature

    failed = [False]

    def update():
        try:
            _update()
        except Exception as exc:
            if not failed[0]:
                optional_failure("ui.compact_footer.update", exc)
                failed[0] = True
            for part in _PARTS:
                try:
                    screen['compact_footer_' + part].hide()
                except Exception:
                    pass

    screen._compact_footer_refresh = update

    originals = []

    def watch(label, method, color):
        original = getattr(label, method)
        def wrapped(*args, **kwargs):
            before = (str(label.getText() or ''), color in hidden)
            result = original(*args, **kwargs)
            if method == 'hide':
                hidden.add(color)
            elif method == 'show':
                hidden.discard(color)
            after = (str(label.getText() or ''), color in hidden)
            if before != after:
                update()
            return result
        setattr(label, method, wrapped)
        originals.append((label, method, original))

    def restore():
        for label, method, original in originals:
            setattr(label, method, original)
        originals[:] = []

    bound = [False]

    def layout_ready(_screen):
        # Decoration hooks start only AFTER native widget layout completes.
        # The screen constructor and initial page paint use original Labels.
        if not bound[0]:
            try:
                for color in _COLORS:
                    try:
                        label = screen[color]
                    except KeyError:
                        continue
                    if not getattr(label, 'visible', True):
                        hidden.add(color)
                    for method in ('setText', 'show', 'hide'):
                        watch(label, method, color)
                bound[0] = True
            except Exception as exc:
                restore()
                optional_failure("ui.compact_footer.bind", exc)
                return
        update()

    # Some Enigma2 images treat non-bound callbacks as skin applet code and exec() them.
    # Register a real bound method, matching the screen lifecycle API.
    screen.onLayoutFinish.append(MethodType(layout_ready, screen))
    # Images differ in their show callback API; do not require one in __init__.
    for name in ('onShow', 'onShown'):
        callbacks = getattr(screen, name, None)
        if isinstance(callbacks, list):
            callbacks.append(update)
            break
    callbacks = getattr(screen, 'onClose', None)
    if isinstance(callbacks, list):
        callbacks.append(restore)


def install_compact_footer(screen):
    """Cosmetic decoration must never abort a screen constructor."""
    try:
        _install_compact_footer(screen)
    except Exception as exc:
        optional_failure("ui.compact_footer.install", exc)
