# -*- coding: utf-8 -*-
"""Check notices, footer group, profile view and card painting.

Methods moved verbatim out of ``PortalListScreen`` (ui_screens_portallist.py); behaviour is unchanged.
This module is imported by ui_screens_portallist.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, round, max, min
from .ui_screens_portallist import (
    PT_COLS,
    PT_TILES,
    _,
    _PT_STATUS_TONE,
    _PT_TONE_HEX,
    _asset_path,
    _lstrf,
    _portal_connection_badge,
    _pt_days_left,
    _pt_tone,
    ePoint,
    eSize,
    eTimer,
    getDesktop,
    parseColor,
    time,
    urllib,
)


class PortalListPaintMixin(object):
    """Check notices, footer group, profile view and card painting."""

    def _set_check_progress(self, text):
        """Set transient Check All text and keep the compact footer row aligned."""
        timer = getattr(self, "_pt_result_timer", None)
        if timer is not None:
            timer.stop()
        self._portal_check_progress_text = str(text or "")
        self["check_progress"].setText(self._portal_check_progress_text)
        self._position_footer_group()

    def _position_footer_group(self):
        """R5.69: page counter under the tile grid; Check All progress bottom-left."""
        try:
            self["status"].setText("")
            self["footer_connection"].setText("")
            desktop = getDesktop(0).size()
            sx = float(desktop.width()) / 1920.0
            sy = float(desktop.height()) / 1080.0
            inst = self["portal_page"].instance
            if inst is not None:
                inst.move(ePoint(int(round(66 * sx)), int(round(1027 * sy))))
                inst.resize(eSize(int(round(520 * sx)), int(round(40 * sy))))
            inst = self["check_progress"].instance
            if inst is not None:
                text = str(getattr(self, "_portal_check_progress_text", "") or "")
                inst.move(ePoint(int(round(1410 * sx)), int(round(1027 * sy))))
                inst.resize(eSize(int(round((436 if text else 1) * sx)), int(round(40 * sy))))
        except Exception as exc:
            optional_failure("ui.portal_footer_group", exc)

    def _pt_clear_result(self):
        self._set_check_progress("")

    def _pt_flash_result(self, text, seconds=4):
        self._set_check_progress(text)
        try:
            timer = getattr(self, "_pt_result_timer", None)
            if timer is None:
                timer = eTimer()
                self._pt_result_timer = timer
                try:
                    self._pt_result_conn = timer.timeout.connect(self._pt_clear_result)
                except Exception:
                    timer.callback.append(self._pt_clear_result)
            timer.stop()
            timer.start(int(seconds * 1000), True)
        except Exception as exc:
            optional_failure("ui.portal_result_timer", exc)

    def _hide_check_notice(self):
        self._check_notice_visible = False
        for widget_name in ("check_notice_panel", "check_notice_title", "check_notice_message", "check_notice_dash", "check_notice_ok"):
            try:self[widget_name].hide()
            except Exception as exc:optional_failure("ui.portal_check_notice_hide", exc)

    # ------------------------------------------------------------------
    # R5.69 premium tiles
    def _pt_set(self, name, text=None, color=None, visible=True, pixmap=None):
        st = self._pt_state.setdefault(name, {})
        try:
            widget = self[name]
        except Exception:
            return
        try:
            inst = widget.instance
            if color is not None and st.get("color") != color and inst is not None:
                inst.setForegroundColor(parseColor(color))
                st["color"] = color
                st["text"] = None  # force a repaint with the new colour
            if pixmap is not None and st.get("pixmap") != pixmap and inst is not None:
                inst.setPixmapFromFile(pixmap)
                st["pixmap"] = pixmap
            if text is not None and st.get("text") != text:
                widget.setText(text)
                st["text"] = text
            if st.get("visible") != bool(visible):
                (widget.show if visible else widget.hide)()
                st["visible"] = bool(visible)
        except Exception as exc:
            optional_failure("ui.portal_tile_widget", exc)

    def _pt_width(self, name, width, height):
        st = self._pt_state.setdefault(name, {})
        if st.get("w") == width:
            return
        try:
            desktop = getDesktop(0).size()
            sx = float(desktop.width()) / 1920.0
            sy = float(desktop.height()) / 1080.0
            inst = self[name].instance
            if inst is None:
                return  # DreamOS did not create this tiny widget (yet); retry next paint
            inst.resize(eSize(max(1, int(round(width * sx))), max(1, int(round(height * sy)))))
            st["w"] = width
        except Exception as exc:
            optional_failure("ui.portal_tile_width", exc)

    def _pt_profile_view(self, index):
        p = self.profiles[index] if 0 <= index < len(self.profiles) else {}
        is_m3u = str(p.get("source_type") or "").lower() == "m3u"
        name = p.get("name") or ((_("M3U Playlist %d") % (index + 1)) if is_m3u else (_("Portal Server %d") % (index + 1)))
        if getattr(self, "_portal_select_mode", False) and index in getattr(self, "_portal_selected", set()):
            name = "\u2713  " + str(name)
        identity = _("M3U playlist") if is_m3u else (str(p.get("mac") or "").strip() or _("Portal"))
        status = self._portal_status_text(p)
        _status, expiry = self._portal_display_parts(p)
        raw_exp = str(p.get("expiry") or "").strip() or (expiry if expiry != _("No expiry date") else "")
        days = _pt_days_left(raw_exp)
        return p, is_m3u, str(name), identity, status, raw_exp, days

    def _pt_paint(self, selected_idx, portal_count=None, m3u_count=None):
        total = len(self.profiles or [])
        if selected_idx is None or not total:
            selected_idx = -1
        page = max(0, selected_idx) // PT_TILES
        # header tabs (the active one follows the focused source type)
        if portal_count is None:
            portal_count = sum(1 for p in self.profiles if str((p or {}).get("source_type") or "").lower() != "m3u")
            m3u_count = total - portal_count
        cur_m3u = bool(selected_idx >= 0 and str(self.profiles[selected_idx].get("source_type") or "").lower() == "m3u")
        self._pt_set("pt_tab0", "%s  %d" % (_("Portal"), portal_count), "#a0a0a8" if cur_m3u else "#ffffff")
        self._pt_set("pt_tab1", "%s  %d" % ("M3U", m3u_count or 0), "#ffffff" if cur_m3u else "#a0a0a8")
        try:
            desktop = getDesktop(0).size()
            sx = float(desktop.width()) / 1920.0
            sy = float(desktop.height()) / 1080.0
            tab = "pt_tab1" if cur_m3u else "pt_tab0"
            label = self[tab].instance
            w = 120
            try:
                w = max(40, min(180, int(label.calculateSize().width() / max(0.1, sx))))
            except Exception:
                pass
            x = 540 if cur_m3u else 330
            self["pt_tab_line"].instance.move(ePoint(int(round(x * sx)), int(round(142 * sy))))
            self._pt_width("pt_tab_line", w, 3)
        except Exception:
            pass
        moving = bool(getattr(self, "_reorder_mode", False))
        for k in range(PT_TILES):
            index = page * PT_TILES + k
            if index >= total:
                for n in ("pt_num%d", "pt_name%d", "pt_id%d", "pt_status%d", "pt_days%d", "pt_dot%d", "pt_track%d", "pt_fill%d"):
                    self._pt_set(n % k, visible=False)
                continue
            p, is_m3u, name, identity, status, raw_exp, days = self._pt_profile_view(index)
            sel = index == selected_idx
            self._pt_set("pt_num%d" % k, "%02d" % (index + 1), "#ffffff" if sel else "#76767e")
            name_col = "#ff3045" if (moving and sel) else ("#ffffff" if sel else "#cdcdd4")
            self._pt_set("pt_name%d" % k, name, name_col)
            self._pt_set("pt_id%d" % k, identity, "#a0a0a8")
            tone = _PT_STATUS_TONE.get(status, "grey")
            self._pt_set("pt_dot%d" % k, pixmap=_asset_path("pt_dot_%s.png" % tone))
            st_txt = _(status.title()) if status else ""
            if status and st_txt == status.title():
                st_txt = _(status)
            self._pt_set("pt_status%d" % k, st_txt, "#a0a0a8")
            dtone = _pt_tone(days)
            if days is not None:
                dtext = _("Expired") if days < 0 else (_("%d days") % days)
                self._pt_set("pt_days%d" % k, dtext, _PT_TONE_HEX[dtone])
                self._pt_set("pt_track%d" % k, visible=True)
                frac = 0.0 if days <= 0 else min(1.0, days / 365.0)
                self._pt_set("pt_fill%d" % k, pixmap=_asset_path("pt_fill_%s_328x3.png" % dtone), visible=frac > 0)
                self._pt_width("pt_fill%d" % k, max(2, int(328 * frac)), 3)
            else:
                short = self._portal_card_expiry(raw_exp) if raw_exp else ""
                self._pt_set("pt_days%d" % k, short, "#a0a0a8")
                self._pt_set("pt_track%d" % k, visible=False)
                self._pt_set("pt_fill%d" % k, visible=False)
        # focus frame
        if 0 <= selected_idx < total:
            k = selected_idx - page * PT_TILES
            r, c = divmod(k, PT_COLS)
            try:
                desktop = getDesktop(0).size()
                sx = float(desktop.width()) / 1920.0
                sy = float(desktop.height()) / 1080.0
                self["pt_sel"].instance.move(ePoint(int(round((56 + c * 400) * sx)), int(round((195 + r * 163) * sy))))
            except Exception:
                pass
            self._pt_set("pt_sel", visible=True)
        else:
            self._pt_set("pt_sel", visible=False)
        self._pt_paint_card(selected_idx)

    def _position_connection_indicator(self):
        """Anchor the dot 8px before the actual right-aligned counter glyphs."""
        try:
            label = self["pt_card_connections"].instance
            dot = self["pt_card_connections_dot"].instance
            if label is None or dot is None:
                return
            sx = float(getDesktop(0).size().width()) / 1920.0
            pos, box = label.position(), label.size()
            right = int(round(1846 * sx))
            measured = max(1, label.calculateSize().width())
            width = max(int(round(160 * sx)), measured + int(round(8 * sx)))
            # Reserve the translated status before sizing the provider title.
            # Neither font shrinks; the right edge and 8px dot gap stay fixed.
            label.move(ePoint(right - width, pos.y()))
            label.resize(eSize(width, box.height()))
            title = self["pt_card_name"].instance
            if title is not None:
                available = right - width - int(round(34 * sx)) - title.position().x()
                title.resize(eSize(max(1, min(int(round(300 * sx)), available)), title.size().height()))
            x = right - measured - int(round(18 * sx))
            dot.move(ePoint(x, dot.position().y()))
        except Exception as exc:
            optional_failure("ui.portal_connection_position", exc)

    def _pt_paint_card(self, idx):
        if idx is None or not (0 <= idx < len(self.profiles or [])):
            self._pt_set("pt_card_name", _("No sources yet"))
            self._pt_set("pt_card_status", _("MENU  Portal Manager  •  add a Portal or M3U"), "#a0a0a8")
            self._pt_set("pt_card_dot", visible=False)
            self._pt_set("pt_card_connections", "", visible=False)
            self._pt_set("pt_card_connections_dot", visible=False)
            for k in range(3):
                self._pt_set("pt_card_lab%d" % k, "")
                self._pt_set("pt_card_val%d" % k, "")
            for n in ("pt_card_exp", "pt_card_days", "pt_card_track", "pt_card_fill"):
                self._pt_set(n, "" if n in ("pt_card_exp", "pt_card_days") else None, visible=False)
            return
        p, is_m3u, name, identity, status, raw_exp, days = self._pt_profile_view(idx)
        self._pt_set("pt_card_name", name)
        connection_badge = _portal_connection_badge(p)
        connection_text = connection_badge[1] if connection_badge else _("Unavailable")
        connection_dot = connection_badge[2] if connection_badge else _asset_path("pt_dot_grey.png")
        self._pt_set("pt_card_connections", connection_text, "#ffffff", visible=True)
        self._pt_set("pt_card_connections_dot", pixmap=connection_dot, visible=True)
        self._position_connection_indicator()
        tone = _PT_STATUS_TONE.get(status, "grey")
        self._pt_set("pt_card_dot", pixmap=_asset_path("pt_dot_%s.png" % tone), visible=True)
        st_card = _(status.title()) if status else ""
        if status and st_card == status.title():
            st_card = _(status)
        self._pt_set("pt_card_status", "%s  \u2022  %s" % (st_card, "M3U" if is_m3u else _("Portal")), "#a0a0a8")
        server = str(p.get("portal") or "").strip()
        if server and is_m3u:
            try:
                parts = urllib.parse.urlsplit(server)
                if parts.scheme and parts.netloc:
                    server = "%s://%s" % (parts.scheme, parts.netloc)
            except Exception:
                pass
        checked = ""
        try:
            # R5.70: newest of an explicit Check All and the last successful
            # connection (opening a portal or a single Check also counts).
            ts = max(int(p.get("check_all_checked_at") or 0), int(p.get("last_success") or 0), int(p.get("checked_at") or 0))
            if ts > 0:
                lt = time.localtime(ts)
                checked = (_("Today %s") % time.strftime("%H:%M", lt)) if time.strftime("%Y%m%d", lt) == time.strftime("%Y%m%d") else _lstrf("%d %b %Y  %H:%M", lt)
        except Exception:
            checked = ""
        rows = [(_("Server"), server[:44] or "-"),
                (_("Type") if is_m3u else "MAC", _("M3U playlist") if is_m3u else (str(p.get("mac") or "").strip() or "-")),
                (_("Last check"), checked or _("Not checked yet"))]
        for k, (lab, val) in enumerate(rows):
            self._pt_set("pt_card_lab%d" % k, lab, "#a0a0a8")
            self._pt_set("pt_card_val%d" % k, val, "#ffffff")
        dtone = _pt_tone(days)
        if raw_exp:
            self._pt_set("pt_card_exp", "%s  %s" % (_("Expires"), self._portal_card_expiry(raw_exp)), "#a0a0a8", visible=True)
        else:
            self._pt_set("pt_card_exp", _("No expiry date"), "#a0a0a8", visible=True)
        if days is not None:
            self._pt_set("pt_card_days", (_("Expired") if days < 0 else (_("%d days left") % days)), _PT_TONE_HEX[dtone], visible=True)
            frac = 0.0 if days <= 0 else min(1.0, days / 365.0)
            self._pt_set("pt_card_track", visible=True)
            self._pt_set("pt_card_fill", pixmap=_asset_path("pt_fill_%s_500x4.png" % dtone), visible=frac > 0)
            self._pt_width("pt_card_fill", max(2, int(500 * frac)), 4)
        else:
            self._pt_set("pt_card_days", "", visible=False)
            self._pt_set("pt_card_track", visible=False)
            self._pt_set("pt_card_fill", visible=False)
