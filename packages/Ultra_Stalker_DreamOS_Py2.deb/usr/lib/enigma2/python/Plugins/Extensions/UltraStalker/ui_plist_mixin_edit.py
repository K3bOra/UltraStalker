# -*- coding: utf-8 -*-
"""Rename, URL/MAC edit, disabled-portal handling, purge and permanent delete.

Methods moved verbatim out of ``PortalListScreen`` (ui_screens_portallist.py); behaviour is unchanged.
This module is imported by ui_screens_portallist.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str
from .ui_screens_portallist import (
    SettingsGlassChoiceScreen,
    SettingsGlassInputScreen,
    SettingsGlassNoticeScreen,
    _,
    _clear_profile_connections,
    show_notice,
)


class PortalListEditMixin(object):
    """Rename, URL/MAC edit, disabled-portal handling, purge and permanent delete."""

    def _portal_renamed(self,value):
        if value is None:return
        old=getattr(self,"_editing_profile",None) or {};new=dict(old);new["name"]=str(value or "").strip()[:80]
        try:replace_profile(old,new,session=self.session);self.profiles=load_profiles();self.refresh();self["status"].setText(_("Portal renamed"))
        except Exception as exc:self["status"].setText(_("Rename failed: %s")%exc)

    def _portal_edit_url(self,value):
        if not value:return
        self._edited_url=str(value).strip();old=getattr(self,"_editing_profile",{})
        self._edited_source_type="m3u" if _looks_like_m3u_url(self._edited_url) else "stalker"
        if requires_http_consent(self._edited_url):
            self.session.openWithCallback(self._portal_edit_http_confirmed,SettingsGlassNoticeScreen,_('HTTP security warning'),http_warning_for(self._edited_url),True)
            return
        if self._edited_source_type=="m3u":self._portal_edit_m3u_save()
        else:self.session.openWithCallback(self._portal_edit_mac,SettingsGlassInputScreen,title=_("MAC address"),text=str(old.get("mac") or "00:1A:79:"),maxSize=17)

    def _portal_edit_http_confirmed(self,answer):
        if not answer:
            self["status"].setText(_("HTTP portal update cancelled"))
            return
        old=getattr(self,"_editing_profile",{})
        if getattr(self,"_edited_source_type","stalker")=="m3u":self._portal_edit_m3u_save()
        else:self.session.openWithCallback(self._portal_edit_mac,SettingsGlassInputScreen,title=_("MAC address"),text=str(old.get("mac") or "00:1A:79:"),maxSize=17)

    def _portal_edit_m3u_save(self):
        old=getattr(self,"_editing_profile",None) or {};new=dict(old)
        new["portal"]=getattr(self,"_edited_url",old.get("portal"));new["source_type"]="m3u";new["mac"]="";new["account_state"]="M3U PLAYLIST";new["state"]="M3U • Not checked"
        _clear_profile_connections(new)
        new=mark_http_consent(new,True)
        try:
            _validate_profile_client(new);replace_profile(old,new,session=self.session)
            self.profiles=load_profiles();self.refresh();self["status"].setText(_("M3U source updated"))
        except Exception as exc:self.session.open(SettingsGlassNoticeScreen,_("Update failed"),_("Update failed: %s")%exc,False)

    def _portal_edit_mac(self,value):
        if not value:return
        old=getattr(self,"_editing_profile",None) or {};new=dict(old);new["portal"]=getattr(self,"_edited_url",old.get("portal"));new["mac"]=str(value).strip().upper();new["source_type"]="stalker"
        if (str(new.get("portal") or "").strip() != str(old.get("portal") or "").strip() or
                str(new.get("mac") or "").upper() != str(old.get("mac") or "").upper()):
            _clear_profile_connections(new)
        new=mark_http_consent(new,True)
        if str(new.get("portal") or "").strip() != str(old.get("portal") or "").strip():
            new["allow_http_fallback"]=False;new["http_fallback_accepted"]=False;new["tls_fallback_accepted"]=False
        try:
            _validate_profile_client(new);replace_profile(old,new,session=self.session);self.profiles=load_profiles();self.refresh();self["status"].setText(_("Portal updated"))
        except Exception as exc:self.session.open(SettingsGlassNoticeScreen,_("Update failed"),_("Update failed: %s")%exc,False)

    def _portal_duplicate_mac(self,value):
        if not value:return
        base=getattr(self,"_duplicating_profile",None) or {};clone=duplicate_profile(base);clone["mac"]=str(value).strip().upper();clone["state"]="Not checked";clone["health"]="unknown";_clear_profile_connections(clone)
        try:
            _validate_profile_client(clone);rows=load_profiles();rows.append(clone);save_profiles(rows);enable_profile(clone);self.profiles=load_profiles();self.refresh();self["status"].setText(_("Portal duplicated"))
        except Exception as exc:self.session.open(SettingsGlassNoticeScreen,_("Duplicate failed"),_("Duplicate failed: %s")%exc,False)

    def _choose_disabled_portal(self):
        rows=load_disabled_profiles()
        if not rows:show_notice(self.session, _("No disabled portals."), timeout=5, owner=self);return
        choices=[]
        for row in rows:
            label=(row.get("name") or row.get("portal") or "Portal")+"  •  "+str(row.get("mac") or "")
            choices.append((label,row))
        self.session.openWithCallback(
            self._disabled_portal_selected,
            SettingsGlassChoiceScreen,
            _("Re-enable portal"),
            choices,
            subtitle=_("Choose a disabled portal to enable")
        )

    def _disabled_portal_selected(self,choice):
        if not choice:return
        try:enable_profile(choice[1]);self.profiles=load_profiles();self.refresh();self["status"].setText(_("Portal enabled"))
        except Exception as exc:self["status"].setText(_("Enable failed: %s")%exc)

    def _purge_profile_confirmed(self,answer):
        if not answer:return
        try:
            cleanup=purge_profile_data(getattr(self,"_purge_profile",{}),session=self.session,remove_timers=True)
            errors=[str(v) for k,v in cleanup.items() if str(k).endswith("_error") and v]
            if errors:
                self["status"].setText(_("Portal data cleared with warnings: %s")%errors[0])
            else:
                self["status"].setText(_("Portal data cleared; portal profile kept"))
        except Exception as exc:self["status"].setText(_("Clear portal data failed: %s")%exc)

    def _permanent_delete_confirmed(self,answer):
        if not answer:return
        try:
            result=permanently_delete_profile(getattr(self,"_permanent_profile",{}),session=self.session,purge_related=True)
            self.profiles=load_profiles();self.refresh()
            cleanup=(result or {}).get("cleanup") or {};errors=[str(v) for k,v in cleanup.items() if str(k).endswith("_error") and v]
            self["status"].setText(_("Portal deleted with cleanup warning: %s")%errors[0] if errors else _("Portal and related plugin data permanently deleted"))
        except Exception as exc:self["status"].setText(_("Delete failed: %s")%exc)
