# -*- coding: utf-8 -*-
"""Fill in Pillow APIs the plugin uses that older receivers' PIL lacks.

DreamOS OE2.5 ships PIL 1.1.7.  The plugin (written against Pillow 8+)
uses newer calls; each one is added here only when the installed library
does not already have it, so a modern Pillow is left untouched.

  Image.Image.__enter__/__exit__/close   with Image.open(...) as im
  Image.Image.width / height
  Image.Image.getchannel()
  Image.alpha_composite()                function (Pillow 2.0)
  Image.Image.alpha_composite()          method, in place (Pillow 4.2)
  Image.LANCZOS / Image.Resampling
  ImageOps.exif_transpose()
  ImageFilter.GaussianBlur(radius)       PIL 1.1.7 ignored the radius
  ImageDraw rectangle/ellipse/arc(width=)
  ImageDraw.rounded_rectangle()
"""
from __future__ import absolute_import, division, print_function, unicode_literals
import sys as _sys
from .us_env import str, bytes, int, round, max, min, us_copy, int_from_bytes

_STATE = {"patched": [], "version": None, "webp": False}

_CORE_MODULES = (
    "Image", "ImageFile", "ImageDraw", "ImageOps", "ImageFilter",
    "ImageChops", "ImageColor", "ImageStat", "ImageEnhance",
    "ImageMath", "ImagePalette",
)
_STD_PLUGINS = (
    ("BmpImagePlugin", "BMP", "BmpImageFile", (".bmp",), "image/bmp"),
    ("GifImagePlugin", "GIF", "GifImageFile", (".gif",), "image/gif"),
    ("JpegImagePlugin", "JPEG", "JpegImageFile", (".jpg", ".jpeg", ".jpe", ".jfif"), "image/jpeg"),
    ("PngImagePlugin", "PNG", "PngImageFile", (".png",), "image/png"),
    ("PpmImagePlugin", "PPM", "PpmImageFile", (".pbm", ".pgm", ".ppm"), "image/x-portable-anymap"),
)


def _add(owner, name, value, label):
    if not hasattr(owner, name):
        setattr(owner, name, value)
        _STATE["patched"].append(label)


def _merge_image_registries(dst, src):
    if dst is None or src is None or dst is src:
        return
    try:
        for fmt in getattr(src, "ID", ()) or ():
            if fmt not in dst.ID:
                dst.ID.append(fmt)
        for attr in ("OPEN", "SAVE", "EXTENSION", "MIME"):
            smap = getattr(src, attr, None)
            dmap = getattr(dst, attr, None)
            if isinstance(smap, dict) and isinstance(dmap, dict):
                for k, v in smap.items():
                    dmap.setdefault(k, v)
    except Exception:
        pass


def _unify_pil_modules():
    """Ensure top-level ``Image`` (via PIL.pth on DreamOS) and ``PIL.Image`` are identical.

    In PIL 1.1.7, plugin modules execute ``import Image, ImageFile`` at top level.
    If ``PIL.Image`` and ``Image`` are separate module objects in ``sys.modules``,
    ``JpegImagePlugin`` registers JPEG into ``sys.modules['Image'].OPEN`` while
    ``PIL.Image.OPEN`` stays empty, causing every ``PIL.Image.open()`` call to
    raise ``IOError: cannot identify image file``.
    """
    try:
        import PIL
    except Exception:
        return None, None
    for name in _CORE_MODULES:
        pkg_name = "PIL." + name
        top_mod = _sys.modules.get(name)
        pkg_mod = _sys.modules.get(pkg_name)
        if top_mod is not None and pkg_mod is not None and top_mod is not pkg_mod:
            if name == "Image":
                _merge_image_registries(pkg_mod, top_mod)
                _merge_image_registries(top_mod, pkg_mod)
            _sys.modules[name] = pkg_mod
            setattr(PIL, name, pkg_mod)
            _STATE["patched"].append("unify:" + name)
        elif top_mod is not None and pkg_mod is None:
            _sys.modules[pkg_name] = top_mod
            setattr(PIL, name, top_mod)
        elif pkg_mod is not None and top_mod is None:
            _sys.modules[name] = pkg_mod
            setattr(PIL, name, pkg_mod)
    for name in ("Image", "ImageFile", "ImageDraw", "ImageOps", "ImageFilter", "ImageChops", "ImageColor"):
        pkg_name = "PIL." + name
        try:
            mod = __import__(pkg_name, fromlist=[str(name)])
            if _sys.modules.get(name) is not None and _sys.modules.get(name) is not mod:
                if name == "Image":
                    _merge_image_registries(mod, _sys.modules[name])
            _sys.modules[name] = mod
            _sys.modules[pkg_name] = mod
            setattr(PIL, name, mod)
        except Exception:
            pass
    return _sys.modules.get("PIL.Image"), _sys.modules.get("PIL.ImageDraw")


def _ensure_pil_plugins(Image, ImageFile):
    """Guarantee standard PIL format plugins are registered on ``PIL.Image``."""
    try:
        import PIL
    except Exception:
        PIL = None
    try:
        Image.preinit()
    except Exception:
        pass
    try:
        Image.init()
    except Exception:
        pass
    for mod_name, fmt, cls_name, exts, mime in _STD_PLUGINS:
        pkg_name = "PIL." + mod_name
        plugin_mod = _sys.modules.get(pkg_name) or _sys.modules.get(mod_name)
        if plugin_mod is None:
            for candidate in (pkg_name, mod_name):
                try:
                    plugin_mod = __import__(candidate, fromlist=[str(mod_name)])
                    break
                except Exception:
                    continue
        if plugin_mod is None:
            continue
        _sys.modules[mod_name] = plugin_mod
        _sys.modules[pkg_name] = plugin_mod
        if PIL is not None:
            setattr(PIL, mod_name, plugin_mod)
        try:
            other_img = getattr(plugin_mod, "Image", None)
            if other_img is not None and other_img is not Image:
                _merge_image_registries(Image, other_img)
                plugin_mod.Image = Image
            if ImageFile is not None and getattr(plugin_mod, "ImageFile", None) is not ImageFile:
                plugin_mod.ImageFile = ImageFile
        except Exception:
            pass
        try:
            cls = getattr(plugin_mod, cls_name, None)
            accept = getattr(plugin_mod, "_accept", None)
            save_fn = getattr(plugin_mod, "_save", None)
            if cls is not None and fmt not in getattr(Image, "OPEN", {}):
                Image.register_open(fmt, cls, accept)
                _STATE["patched"].append("register_open:" + fmt)
            if save_fn is not None and fmt not in getattr(Image, "SAVE", {}):
                Image.register_save(fmt, save_fn)
                _STATE["patched"].append("register_save:" + fmt)
            for ext in exts:
                if ext not in getattr(Image, "EXTENSION", {}):
                    Image.register_extension(fmt, ext)
            if mime and fmt not in getattr(Image, "MIME", {}):
                Image.register_mime(fmt, mime)
        except Exception:
            pass
    try:
        _STATE["webp"] = bool("WEBP" in getattr(Image, "OPEN", {}))
        _STATE["formats"] = sorted(list(getattr(Image, "OPEN", {}).keys()))
    except Exception:
        _STATE["webp"] = False


def supports_webp():
    if not _STATE.get("done"):
        install()
    return bool(_STATE.get("webp", False))


def install():
    if _STATE.get("done"):
        return _STATE
    Image, ImageDraw = _unify_pil_modules()
    if Image is None or ImageDraw is None:
        try:
            from PIL import Image, ImageDraw
        except Exception:
            return _STATE
    _STATE["done"] = True
    try:
        _STATE["version"] = getattr(Image, "__version__", None) or getattr(Image, "VERSION", None) or getattr(Image, "PILLOW_VERSION", None)
    except Exception:
        pass
    try:
        from PIL import ImageFile as _IF
        if getattr(_IF, "MAXBLOCK", 0) < 8 * 1024 * 1024:
            _IF.MAXBLOCK = 8 * 1024 * 1024
            _STATE["patched"].append("ImageFile.MAXBLOCK")
        if not getattr(_IF, "LOAD_TRUNCATED_IMAGES", False):
            _IF.LOAD_TRUNCATED_IMAGES = True
    except Exception:
        _IF = None
    try:
        _ensure_pil_plugins(Image, _IF)
    except Exception as exc:
        _STATE["patched"].append("plugins failed: %s" % (exc,))
    for step in (_patch_image, _patch_constants, _patch_ops, _patch_filters, _patch_draw):
        try:
            step(Image, ImageDraw)
        except Exception as exc:
            _STATE["patched"].append("%s failed: %s" % (step.__name__, exc))
    return _STATE


def _parse_jpeg_sof(fp):
    """Parse (width, height, components) from JPEG SOF marker when PIL 1.1.7's
    pure-Python marker loop chokes on 0x00 pad bytes between markers."""
    try:
        fp.seek(0)
        data = fp.read(65536)
        if len(data) < 4 or data[:3] != b"\xff\xd8\xff":
            return None
        n = len(data)
        i = 2
        while i < n - 8:
            if data[i:i + 1] != b"\xff":
                i += 1
                continue
            while i < n and data[i:i + 1] == b"\xff":
                i += 1
            if i >= n:
                break
            marker = bytearray(data[i:i + 1])[0]
            i += 1
            if marker in (0x00, 0x01, 0xD8) or (0xD0 <= marker <= 0xD7):
                continue
            if marker == 0xD9 or marker == 0xDA:
                break
            if i + 2 > n:
                break
            seglen = int_from_bytes(data[i:i + 2], "big")
            if seglen < 2 or i + seglen > n:
                break
            if marker in (0xC0, 0xC1, 0xC2, 0xC3, 0xC5, 0xC6, 0xC7, 0xC9, 0xCA, 0xCB, 0xCD, 0xCE, 0xCF):
                if seglen >= 7:
                    h = int_from_bytes(data[i + 3:i + 5], "big")
                    w = int_from_bytes(data[i + 5:i + 7], "big")
                    comp = bytearray(data[i + 7:i + 8])[0] if i + 8 <= n else 3
                    if w > 0 and h > 0:
                        return (w, h, comp)
                break
            i += seglen
    except Exception:
        pass
    return None


# --------------------------------------------------------------------------
# Image
# --------------------------------------------------------------------------
def _composite_over(Image, im1, im2):
    """Fast 'im2 over im1' for two RGBA images of the same size on PIL 1.1.7."""
    from PIL import ImageChops
    a2 = im2.split()[3]
    ex2 = a2.getextrema()
    if ex2[0] == 255:
        return us_copy(im2)
    if ex2[1] == 0:
        return us_copy(im1)
    a1 = im1.split()[3]
    ex1 = a1.getextrema()
    if ex1[1] == 0:
        return us_copy(im2)
    if ex1[0] == 255:
        out = Image.composite(im2, im1, a2)
        out.putalpha(a1)
        return out
    out_alpha = ImageChops.screen(a1, a2)
    out = Image.composite(im2, im1, a2)
    out.putalpha(out_alpha)
    return out


def _patch_image(Image, ImageDraw):
    cls = Image.Image

    if not getattr(Image, "_us_open_patched", False):
        orig_open = Image.open

        def safe_open(fp, mode="r", *args, **kwargs):
            if not getattr(Image, "OPEN", None) or "JPEG" not in getattr(Image, "OPEN", {}):
                try:
                    from PIL import ImageFile as _IF
                except Exception:
                    _IF = None
                _ensure_pil_plugins(Image, _IF)
            try:
                return orig_open(fp, mode, *args, **kwargs)
            except IOError:
                # Fallback for PIL 1.1.7 JpegImagePlugin marker-padding quirk:
                # if the stream is a valid JPEG with SOF dimensions, let C libjpeg decode it.
                handle = None
                exclusive = False
                try:
                    if hasattr(fp, "read") and hasattr(fp, "seek"):
                        handle = fp
                        filename = getattr(fp, "name", "") or ""
                    else:
                        import io as _io
                        filename = fp
                        handle = _io.open(fp, "rb")
                        exclusive = True
                    sof = _parse_jpeg_sof(handle)
                    if sof is not None:
                        w, h, comp = sof
                        handle.seek(0)
                        JpegPlugin = _sys.modules.get("PIL.JpegImagePlugin") or _sys.modules.get("JpegImagePlugin")
                        if JpegPlugin is not None and hasattr(JpegPlugin, "JpegImageFile"):
                            im = JpegPlugin.JpegImageFile.__new__(JpegPlugin.JpegImageFile)
                        else:
                            im = cls()
                        im.fp = handle
                        im.filename = filename
                        im._exclusive_fp = exclusive
                        im.format = "JPEG"
                        im.format_description = "JPEG (ISO 10918)"
                        im.mode = "L" if comp == 1 else ("CMYK" if comp == 4 else "RGB")
                        im.size = (w, h)
                        im.info = {}
                        im.category = getattr(Image, "NORMAL", 0)
                        im.readonly = 1
                        im.pyaccess = None
                        im.im = None
                        im.tile = [("jpeg", (0, 0, w, h), 0, (im.mode, ""))]
                        return im
                except Exception:
                    if exclusive and handle is not None:
                        try:
                            handle.close()
                        except Exception:
                            pass
                raise

        Image.open = safe_open
        Image._us_open_patched = True
        _STATE["patched"].append("Image.open(resilient)")

    if not hasattr(Image, "linear_gradient"):
        def linear_gradient(mode="L"):
            data = bytes(bytearray(y for y in range(256) for _x in range(256)))
            _fb = getattr(Image, "frombytes", None) or Image.fromstring
            im = _fb("L", (256, 256), data)
            return im if mode == "L" else im.convert(mode)
        Image.linear_gradient = linear_gradient
        _STATE["patched"].append("Image.linear_gradient")

    def close(self):
        fp = getattr(self, "fp", None)
        try:
            if fp is not None and getattr(self, "_exclusive_fp", True):
                fp.close()
        except Exception:
            pass
        self.fp = None

    _add(cls, "close", close, "Image.close")

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        try:
            self.close()
        except Exception:
            pass
        return False

    _add(cls, "__enter__", __enter__, "Image.__enter__")
    _add(cls, "__exit__", __exit__, "Image.__exit__")
    _add(cls, "width", property(lambda self: self.size[0]), "Image.width")
    _add(cls, "height", property(lambda self: self.size[1]), "Image.height")

    def getchannel(self, channel):
        bands = self.getbands()
        if not isinstance(channel, int):
            channel = list(bands).index(channel)
        return self.split()[channel]

    _add(cls, "getchannel", getchannel, "Image.getchannel")

    if not hasattr(Image, "alpha_composite"):
        def alpha_composite(im1, im2):
            if im1.mode != "RGBA" or im2.mode != "RGBA":
                raise ValueError("image has wrong mode")
            if im1.size != im2.size:
                raise ValueError("images do not match")
            return _composite_over(Image, im1, im2)

        Image.alpha_composite = alpha_composite
        _STATE["patched"].append("Image.alpha_composite()")

    def alpha_composite_method(self, im, dest=(0, 0), source=(0, 0)):
        """In place 'im over self' like Pillow >= 4.2."""
        dest = tuple(dest)
        source = tuple(source)
        if len(source) == 2:
            source = source + (im.size[0], im.size[1])
        overlay = im.crop(source) if source != (0, 0, im.size[0], im.size[1]) else im
        x, y = int(dest[0]), int(dest[1])
        w, h = overlay.size
        x0, y0 = max(0, x), max(0, y)
        x1, y1 = min(self.size[0], x + w), min(self.size[1], y + h)
        if x1 <= x0 or y1 <= y0:
            return None
        if (x0, y0, x1, y1) != (x, y, x + w, y + h):
            overlay = overlay.crop((x0 - x, y0 - y, x1 - x, y1 - y))
        region = self.crop((x0, y0, x1, y1))
        if region.mode != "RGBA":
            region = region.convert("RGBA")
        if overlay.mode != "RGBA":
            overlay = overlay.convert("RGBA")
        self.paste(Image.alpha_composite(region, overlay), (x0, y0))
        return None

    _add(cls, "alpha_composite", alpha_composite_method, "Image.alpha_composite")


def _patch_constants(Image, ImageDraw):
    if not hasattr(Image, "LANCZOS"):
        # On PIL 1.1.7 (DreamOS), software ANTIALIAS (1) is 6x slower than C BILINEAR (2)
        # and starves the Python 2.7 GIL during poster grid generation.
        Image.LANCZOS = getattr(Image, "BILINEAR", 2)
        Image.ANTIALIAS = getattr(Image, "BILINEAR", 2)
        _STATE["patched"].append("Image.LANCZOS(BILINEAR_FAST)")
    for name, fallback in (("NEAREST", 0), ("BILINEAR", 2), ("BICUBIC", 3)):
        if not hasattr(Image, name):
            setattr(Image, name, fallback)
    if not hasattr(Image, "HAMMING"):
        Image.HAMMING = Image.BILINEAR
    if not hasattr(Image, "BOX"):
        Image.BOX = Image.NEAREST
    for qname, qval in (("MEDIANCUT", 0), ("MAXCOVERAGE", 1), ("FASTOCTREE", 2)):
        if not hasattr(Image, qname):
            setattr(Image, qname, qval)
    if not hasattr(Image, "Resampling"):
        class Resampling(object):
            NEAREST = Image.NEAREST
            BOX = Image.BOX
            BILINEAR = Image.BILINEAR
            HAMMING = Image.HAMMING
            BICUBIC = Image.BICUBIC
            LANCZOS = Image.LANCZOS

        Image.Resampling = Resampling
        _STATE["patched"].append("Image.Resampling")


def _patch_ops(Image, ImageDraw):
    from PIL import ImageOps
    _add(ImageOps, "exif_transpose", lambda image, *a, **k: image, "ImageOps.exif_transpose")


def _patch_filters(Image, ImageDraw):
    from PIL import ImageFilter
    for name in ("GaussianBlur", "UnsharpMask"):
        original = getattr(ImageFilter, name, None)
        if original is None:
            continue
        try:
            broken = original(radius=7).radius != 7
        except Exception:
            broken = False
        if not broken:
            continue
        if name == "GaussianBlur":
            _blur_kernel = getattr(ImageFilter, "BLUR", original)

            class GaussianBlur(original):
                def __init__(self, radius=2):
                    self.radius = radius

                def filter(self, image):
                    try:
                        r = float(self.radius if self.radius is not None else 2)
                    except Exception:
                        r = 2.0
                    if r <= 0:
                        return image
                    # PIL 1.1.7 has no variable-radius C Gaussianblur; approximate
                    # large radii cleanly by downscaling + box-blur + upscaling,
                    # and small radii with 1-3 passes of the native 5x5 BLUR kernel.
                    try:
                        w, h = image.size
                    except Exception:
                        w, h = 0, 0
                    if r >= 6.0 and w >= 16 and h >= 16:
                        try:
                            scale = max(2, min(8, int(round(r / 2.5))))
                            sw, sh = max(1, w // scale), max(1, h // scale)
                            small = image.resize((sw, sh), getattr(Image, "BILINEAR", 2))
                            small = _blur_kernel().filter(small)
                            return small.resize((w, h), getattr(Image, "BICUBIC", 3)).im
                        except Exception:
                            pass
                    passes = max(1, min(3, int(round(r / 2.0))))
                    im = image
                    for _ in range(passes):
                        im = _blur_kernel().filter(im)
                    return im

            ImageFilter.GaussianBlur = GaussianBlur
        else:
            class UnsharpMask(original):
                def __init__(self, radius=2, percent=150, threshold=3):
                    self.radius = radius
                    self.percent = percent
                    self.threshold = threshold
                def filter(self, image):
                    return getattr(image, "im", image)
            ImageFilter.UnsharpMask = UnsharpMask
        _STATE["patched"].append("ImageFilter.%s(radius)" % name)


# --------------------------------------------------------------------------
# ImageDraw
# --------------------------------------------------------------------------
def _accepts(func, name):
    code = getattr(func, "__code__", None) or getattr(func, "func_code", None)
    if code is None:
        return True
    return name in code.co_varnames[:code.co_argcount]


def _box(xy):
    if len(xy) == 2 and not isinstance(xy[0], (int, float)):
        (x0, y0), (x1, y1) = xy
    else:
        x0, y0, x1, y1 = xy
    return int(round(x0)), int(round(y0)), int(round(x1)), int(round(y1))


def _core_colour(draw, colour):
    """Colour as the core image expects it for paste()."""
    mode = getattr(draw, "mode", None) or getattr(getattr(draw, "im", None), "mode", None) or "RGBA"
    if isinstance(colour, (str, type(u""))):
        from PIL import ImageColor
        return ImageColor.getcolor(colour, mode)
    if isinstance(colour, tuple) and mode == "RGBA" and len(colour) == 3:
        return colour + (255,)
    return colour


def _paste_mask(draw, box, mask, colour):
    """Set pixels under mask to colour (replace, like ImageDraw does)."""
    x0, y0 = box[0], box[1]
    w, h = mask.size
    target = draw.im
    # clip to the image
    tw, th = target.size
    cx0, cy0 = max(0, x0), max(0, y0)
    cx1, cy1 = min(tw, x0 + w), min(th, y0 + h)
    if cx1 <= cx0 or cy1 <= cy0:
        return
    if (cx0, cy0, cx1, cy1) != (x0, y0, x0 + w, y0 + h):
        mask = mask.crop((cx0 - x0, cy0 - y0, cx1 - x0, cy1 - y0))
    target.paste(_core_colour(draw, colour), (cx0, cy0, cx1, cy1), mask.im)


def _patch_draw(Image, ImageDraw):
    cls = ImageDraw.ImageDraw

    def filled_rounded(draw_fn_rect, draw_fn_ellipse, box, radius, fill, corners):
        x0, y0, x1, y1 = box
        if x1 < x0 or y1 < y0:
            return
        r = int(max(0, min(radius, (x1 - x0 + 1) // 2, (y1 - y0 + 1) // 2)))
        if r <= 0:
            draw_fn_rect((x0, y0, x1, y1), fill)
            return
        d = 2 * r
        tl, tr, br, bl = corners
        draw_fn_rect((x0 + r, y0, x1 - r, y1), fill)
        draw_fn_rect((x0, y0 + r, x0 + r, y1 - r), fill)
        draw_fn_rect((x1 - r, y0 + r, x1, y1 - r), fill)
        for enabled, ellipse, square in (
            (tl, (x0, y0, x0 + d, y0 + d), (x0, y0, x0 + r, y0 + r)),
            (tr, (x1 - d, y0, x1, y0 + d), (x1 - r, y0, x1, y0 + r)),
            (br, (x1 - d, y1 - d, x1, y1), (x1 - r, y1 - r, x1, y1)),
            (bl, (x0, y1 - d, x0 + d, y1), (x0, y1 - r, x0 + r, y1)),
        ):
            if enabled:
                draw_fn_ellipse(ellipse, fill)
            else:
                draw_fn_rect(square, fill)

    def mask_draw(mask):
        m = ImageDraw.ImageDraw(mask)
        rect = cls.rectangle
        ell = cls.ellipse
        return (lambda b, f: rect(m, b, fill=f)), (lambda b, f: ell(m, b, fill=f))

    # ---- width= for rectangle / ellipse / arc (PIL < Pillow 5.3)
    rect_orig = cls.rectangle
    if not _accepts(rect_orig, "width"):
        def rectangle(self, xy, fill=None, outline=None, width=1):
            x0, y0, x1, y1 = _box(xy)
            width = int(width or 0)
            if outline is None or width <= 1:
                return rect_orig(self, (x0, y0, x1, y1), fill=fill, outline=outline if width >= 1 else None)
            if fill is not None:
                rect_orig(self, (x0, y0, x1, y1), fill=fill)
            for i in range(width):
                if x0 + i > x1 - i or y0 + i > y1 - i:
                    break
                rect_orig(self, (x0 + i, y0 + i, x1 - i, y1 - i), outline=outline)
            return None

        cls.rectangle = rectangle
        _STATE["patched"].append("ImageDraw.rectangle(width)")

    ell_orig = cls.ellipse
    if not _accepts(ell_orig, "width"):
        def ellipse(self, xy, fill=None, outline=None, width=1):
            x0, y0, x1, y1 = _box(xy)
            width = int(width or 0)
            if outline is None or width <= 1:
                return ell_orig(self, (x0, y0, x1, y1), fill=fill, outline=outline if width >= 1 else None)
            if fill is not None:
                ell_orig(self, (x0, y0, x1, y1), fill=fill)
            w, h = x1 - x0 + 1, y1 - y0 + 1
            if w <= 0 or h <= 0:
                return None
            mask = Image.new("L", (w, h), 0)
            m = ImageDraw.ImageDraw(mask)
            ell_orig(m, (0, 0, w - 1, h - 1), fill=255)
            if w - 1 - width >= width and h - 1 - width >= width:
                ell_orig(m, (width, width, w - 1 - width, h - 1 - width), fill=0)
            _paste_mask(self, (x0, y0), mask, outline)
            return None

        cls.ellipse = ellipse
        _STATE["patched"].append("ImageDraw.ellipse(width)")

    arc_orig = cls.arc
    if not _accepts(arc_orig, "width"):
        def arc(self, xy, start, end, fill=None, width=1):
            x0, y0, x1, y1 = _box(xy)
            for i in range(max(1, int(width or 1))):
                if x0 + i > x1 - i or y0 + i > y1 - i:
                    break
                arc_orig(self, (x0 + i, y0 + i, x1 - i, y1 - i), start, end, fill=fill)
            return None

        cls.arc = arc
        _STATE["patched"].append("ImageDraw.arc(width)")

    # ---- rounded_rectangle (Pillow 8.2)
    if hasattr(cls, "rounded_rectangle"):
        return

    def rounded_rectangle(self, xy, radius=0, fill=None, outline=None, width=1, corners=None):
        box = _box(xy)
        corners = tuple(corners) if corners else (True, True, True, True)
        width = int(width or 0)
        rect_fn = lambda b, f: rect_orig(self, b, fill=f)
        ell_fn = lambda b, f: ell_orig(self, b, fill=f)
        if fill is not None:
            filled_rounded(rect_fn, ell_fn, box, radius, fill, corners)
        if outline is None or width <= 0:
            return None
        w = box[2] - box[0] + 1
        h = box[3] - box[1] + 1
        if w <= 0 or h <= 0:
            return None
        mask = Image.new("L", (w, h), 0)
        mrect, mell = mask_draw(mask)
        filled_rounded(mrect, mell, (0, 0, w - 1, h - 1), radius, 255, corners)
        if w - 1 - width >= width and h - 1 - width >= width:
            filled_rounded(mrect, mell, (width, width, w - 1 - width, h - 1 - width), max(0, radius - width), 0, corners)
        _paste_mask(self, (box[0], box[1]), mask, outline)
        return None

    cls.rounded_rectangle = rounded_rectangle
    _STATE["patched"].append("ImageDraw.rounded_rectangle")


def status():
    return dict((k, v) for k, v in _STATE.items() if k != "done")
