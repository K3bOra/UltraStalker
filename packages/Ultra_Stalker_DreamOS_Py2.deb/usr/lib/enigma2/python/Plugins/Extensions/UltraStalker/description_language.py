# -*- coding: utf-8 -*-
"""Conservative offline language evidence for untagged provider synopses.

Shared writing systems alone are not language evidence. Ambiguous text yields
to the explicitly localized TMDb result instead of overriding it.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str, max, us_casefold
re = _us_env.re

_WORDS = {
    'en': 'the and of to in is his her with for on as by an at from that who when after he she they their it are was must before young discovers family',
    'fr': 'le la les un une des du de et est dans son sa ses avec pour qui quand après avant jeune découvre famille doit mais',
    'it': 'il lo la gli le un una uno di del della e è nel nella suo sua suoi con per che quando dopo prima giovane scopre famiglia deve ma',
    'es': 'el la los las un una de del y es en su sus con para que quien cuando después antes joven descubre familia debe pero',
    'pt': 'o a os as um uma de do da dos das e é em seu sua seus suas com para que quem quando depois antes jovem descobre família deve mas',
    'de': 'der die das ein eine eines des und ist im in sein seine mit für von zu als er sie nach vor junge entdeckt familie muss aber',
    'tr': 'bir ve bu onun ile için olan sonra önce genç ailesini ailesi gizli keşfeder zorunda ancak',
    'nl': 'de het een en is zijn haar met voor van op die wanneer na jonge ontdekt familie moet maar',
    'pl': 'i w z na do nie jest jego jej który która po przed młody odkrywa rodziny musi ale',
    'cs': 'a v ve na do se jeho její který která po před mladý objeví rodinu musí ale',
    'sk': 'a v vo na do sa jeho jej ktorý ktorá po pred mladý objaví rodinu musí ale',
    'hu': 'a az egy és van hogy aki egy fiatal családját kell után előtt titkot fedez fel',
    'ro': 'un o și este în lui ei cu pentru care când după înainte tânăr descoperă familia trebuie dar',
    'hr': 'i u na je se s za koji koja njegov njezin nakon prije mladi otkriva obitelj mora ali',
    'sr': 'и у на је се за који која његов њена после пре млади открива породицу мора али',
    'ru': 'и в на не его её ее с для который которая когда после перед молодой обнаруживает семью должен но',
    'uk': 'і в на не його її з для який яка коли після перед молодий відкриває сім родину повинен але',
    'bg': 'и в на не неговият нейната с за който която когато след преди млад открива семейството трябва но',
    'sv': 'en ett och är i hans hennes med för som när efter före ung upptäcker familj måste men',
    'nb': 'en et og er i hans hennes med for som når etter før ung oppdager familie må men',
    'da': 'en et og er i hans hendes med for som når efter før ung opdager familie skal men',
    'fi': 'ja on hän hänen kanssa varten joka kun jälkeen ennen nuori löytää perheensä täytyy mutta',
    'id': 'seorang dan yang di ke dari adalah dengan untuk ketika setelah sebelum muda menemukan keluarga harus tetapi',
    'fa': 'یک و در از به است با برای که پس پیش جوان کشف خانواده باید اما می شود خود',
    'ar': 'في من إلى على عن مع الذي التي هو هي بعد قبل شاب يكتشف أسرته عائلته يجب لكن عندما يحاول',
}
_WORDS = {lang: frozenset(words.split()) for lang, words in _WORDS.items()}


def matches_language(text, wanted):
    base = str(wanted or 'en').lower().replace('_', '-').split('-')[0]
    text = str(text or '')
    if base == 'ko':
        return len(re.findall(r'[\uac00-\ud7af]', text)) >= 6
    if base == 'ja':
        return len(re.findall(r'[\u3040-\u30ff]', text)) >= 3 and not re.search(r'[\uac00-\ud7af]', text)
    if base == 'zh':
        return len(re.findall(r'[\u3400-\u9fff]', text)) >= 12 and not re.search(r'[\u3040-\u30ff\uac00-\ud7af]', text)
    scripts = {'el': r'[\u0370-\u03ff]', 'hi': r'[\u0900-\u097f]',
               'th': r'[\u0e00-\u0e7f]', 'he': r'[\u0590-\u05ff]'}
    if base in scripts:
        return len(re.findall(scripts[base], text)) >= 12
    words = re.findall(r'[^\W\d_]+', us_casefold(text), re.UNICODE)
    if len(words) < 3 or base not in _WORDS:
        return False
    scores = {lang: sum(w in vocabulary for w in words) for lang, vocabulary in _WORDS.items()}
    wanted_score = scores[base]
    other = max((score for lang, score in scores.items() if lang != base), default=0)
    return wanted_score >= 3 and wanted_score >= len(words) * 0.08 and wanted_score >= other + 2
