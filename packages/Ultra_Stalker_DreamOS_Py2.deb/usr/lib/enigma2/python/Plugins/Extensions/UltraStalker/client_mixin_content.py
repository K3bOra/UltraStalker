# -*- coding: utf-8 -*-
"""Content-cache generation and menu/content refresh.

Methods moved verbatim out of ``StalkerClient`` (client.py); behaviour is unchanged.
This module is imported by client.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, max
from .client import (
    DB,
    LOG,
    hashlib,
)


class ClientContentMixin(object):
    """Content-cache generation and menu/content refresh."""

    def _content_cache_state_key(self):
        raw = (self._state_host.rstrip("/").lower() + "|" + self.mac.upper()).encode("utf-8", "ignore")
        return "content_generation:" + hashlib.sha256(raw).hexdigest()

    def _load_content_cache_generation(self):
        try:
            state=DB.state_get(self._content_cache_state_key())
            return max(0,int((state or {}).get("generation") or 0))
        except Exception:
            return 0

    def _bump_content_cache_generation(self):
        generation=max(0,int(getattr(self,"_content_cache_generation",0) or 0))+1
        self._content_cache_generation=generation
        try:
            DB.state_put(self._content_cache_state_key(),{
                "portal":self._state_entry_url,
                "mac":self.mac,
                "generation":generation,
            })
        except Exception as exc:
            LOG.debug("Could not persist content refresh generation: %s",exc)
        return generation

    def refresh_content(self,cancel_event=None):
        """Invalidate only this Portal's catalogue cache and prime fresh categories.

        Artwork/TMDB/title-logo HDD caches are deliberately untouched. Old hashed
        API cache rows may remain physically in SQLite, but a per-source generation
        makes them unreachable after this explicit refresh, including after reboot.
        """
        self._bump_content_cache_generation()
        with self._series_hierarchy_lock:
            self._series_hierarchy_memory={}
            self._series_hierarchy_memory_at={}
        self.reset_failure_backoff()
        if not self.token:
            self.authorize(cancel_event=cancel_event)
        counts={}
        genre_rows={}
        for media_type in ("itv","vod","series"):
            if cancel_event is not None and getattr(cancel_event,"is_set",lambda:False)():
                break
            rows=self.genres(media_type,cancel_event=cancel_event) or []
            genre_rows[media_type]=[dict(row) if isinstance(row,dict) else row for row in rows]
            counts[media_type]=len(genre_rows[media_type])
        return {"ok":True,"source":"Portal","categories":counts,"genre_rows":genre_rows,"generation":self._content_cache_generation}

    def refresh_menus(self, cancel_event=None):
        """Fresh Live/Movies/Series menus only.

        This is the short open the portal needs: three category lists, not the
        whole catalogue, and it does not throw away pages already in memory.
        """
        if not self.token:
            self.authorize(cancel_event=cancel_event)
        genre_rows = {}
        actions = {"itv": "get_genres", "vod": "get_categories", "series": "get_categories"}
        for media_type, action in actions.items():
            if cancel_event is not None and getattr(cancel_event, "is_set", lambda: False)():
                break
            params = {"type": media_type, "action": action, "JsHttpRequest": "1-xml"}
            try:
                js = self._unwrap(self._get(params, use_cache=False, cancel_event=cancel_event))
                rows = list(row for row in self._as_list(js) if row)
            except Exception as exc:
                low = str(exc).lower()
                if any(marker in low for marker in ("http 469", "http 429", "rate limit")):
                    break
                continue
            genre_rows[media_type] = list(dict(row) if isinstance(row, dict) else row for row in rows)
        return {"ok": True, "source": "Portal", "genre_rows": genre_rows}

    def refresh_menu(self, media_type, cancel_event=None):
        """One fresh folder list. Used by the open splash, not a full catalogue."""
        media_type = str(media_type or "itv").lower()
        if media_type not in ("itv", "vod", "series"):
            return []
        action = "get_genres" if media_type == "itv" else "get_categories"
        if not self.token:
            self.authorize(cancel_event=cancel_event)
        params = {"type": media_type, "action": action, "JsHttpRequest": "1-xml"}
        js = self._unwrap(self._get(params, use_cache=False, cancel_event=cancel_event))
        rows = [row for row in self._as_list(js) if isinstance(row, dict)]
        if media_type == "itv" and not rows:
            rows = self.genres(media_type, cancel_event=cancel_event) or []
        self._menus_opened_fresh = True
        return rows
