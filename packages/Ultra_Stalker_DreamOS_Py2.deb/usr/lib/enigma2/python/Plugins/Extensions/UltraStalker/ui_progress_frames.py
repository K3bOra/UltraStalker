# -*- coding: utf-8 -*-
from __future__ import absolute_import, division
try:
    from . import us_env as _env
    os=_env.os;threading=_env.threading
except ImportError:
    import os,threading
from .persistent_cache import ensure_persistent_dirs,durable_view_path
from .log import optional_failure
try:
    from PIL import Image as _PILImage,ImageDraw as _ImageDraw
except Exception:
    _PILImage=None;_ImageDraw=None
def _cinematic_row_progress_frame(accent_hex, value, width=300):
    """Flat silver watch-progress bar for Cinematic / Episode rows (R5.175).

    Replaces the old laser + glowing head.  Rounded translucent track with a soft
    silver fill and a faint top highlight; no glow, no head dot.  The canvas keeps
    the old 34px height so row geometry is unchanged, and the track leaves a
    24px right margin like the old beam did (the percentage text sits there).
    Enigma2 MultiContent clips instead of scaling, so it is rendered at the row's
    real width (7% really is 7%).
    """
    if _PILImage is None or _ImageDraw is None:return ""
    try:
        value=max(0,min(100,int(value)))
        w=max(80,min(600,int(width or 300)));h=34
        target=durable_view_path("flat_%03d_%03d.png"%(value,w),"cinematic_row_progress_flat175")
        root=os.path.dirname(target)
        if not ensure_persistent_dirs(root):return ""
        if os.path.isfile(target) and os.path.getsize(target)>128:return target
        S=4;bar_h=7;track_w=w-24;y0=(h-bar_h)//2
        big=_PILImage.new("RGBA",(w*S,h*S),(0,0,0,0));d=_ImageDraw.Draw(big)
        r=bar_h*S//2
        x0=2*S;x1=(2+track_w)*S
        d.rounded_rectangle((x0,y0*S,x1,(y0+bar_h)*S-1),r,fill=(255,255,255,46))
        if value>0:
            fw=max(bar_h*S,int((x1-x0)*value/100.0))
            fill=_PILImage.new("RGBA",(fw,bar_h*S));fd=_ImageDraw.Draw(fill)
            for k in range(fw):
                t=k/float(max(1,fw-1));c=int(200+40*t);fd.line([(k,0),(k,bar_h*S)],fill=(c,c,min(255,c+10),240))
            mask=_PILImage.new("L",(fw,bar_h*S),0);_ImageDraw.Draw(mask).rounded_rectangle((0,0,fw-1,bar_h*S-1),r,fill=255)
            big.paste(fill,(x0,y0*S),mask)
            d.rounded_rectangle((x0+r//2,y0*S+S//2,x0+fw-r//2,y0*S+S+S//2),S//2,fill=(255,255,255,120))
        resample=getattr(getattr(_PILImage,"Resampling",_PILImage),"LANCZOS",1)
        img=big.resize((w,h),resample)
        temp=target+".tmp.%d.%d"%(os.getpid(),threading.get_ident());img.save(temp,"PNG");os.replace(temp,target);return target
    except Exception as exc:
        optional_failure("cinematic.row_progress_frame",exc);return ""
