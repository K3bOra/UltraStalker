# -*- coding: utf-8 -*-
"""Native Ultra Stalker playback screen.

Owns the Enigma2 service lifecycle, engine selection, resume flow, overlays,
and receiver-state handoff used by Ultra Stalker.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .. import us_env as _us_env
from ..us_env import str, int, open, round, max, min, OSError, FileNotFoundError, us_clear, us_func
from ..ui_floating_notice import show_notice
from ..wqhd_layout import scale_skin as _wqhd_scale_skin, wh as _wqhd_wh
from ..core.image_budget import image_budgeted
from .. import _
hashlib = _us_env.hashlib
json = _us_env.json
import gc
import ctypes
os = _us_env.os
import signal
time = _us_env.time
queue = _us_env.queue
re = _us_env.re
threading = _us_env.threading
urllib = _us_env.urllib
urllib = _us_env.urllib
try:
    from PIL import Image as _PILImage, ImageDraw as _ImageDraw, ImageFilter as _ImageFilter, ImageEnhance as _ImageEnhance
except Exception:
    _PILImage = None
    _ImageDraw = None
    _ImageFilter = None
from ..securefs import secure_private_dir
from ..persistent_cache import ROOT as PERSISTENT_CACHE_ROOT, GENERATED as PERSISTENT_GENERATED_DIR, persistent_write_gate
from ..storage import add_recently_played, touch_recently_played, load_settings, save_settings, load_profiles
from ..title_clean import display_title as _catalogue_title
from ..identity import content_digest
from . import track_prefs as _track_prefs
from .origin_language import work_language_label as _work_language_label
from ..ui_artwork_helpers import _fit_live_picon_canvas, _normalize_provider_image_url
from ..netsec import build_safe_media_opener, validate_remote_media_url
from ..ui_settings_inline_choice import SettingsInlineChoiceOverlay
from .subtitles_online import cached_subtitle, search_language, download_candidate, parse_srt, search_subsource_language, download_subsource_candidate, interface_subtitle_language_code, subtitle_language_name, is_supported_subtitle_language
from ..language_catalog import interface_language_choices
from ..core.recovery import runtime_interruption_action, smart_recovery_allowed
from ..core.runtime_log import breadcrumb as runtime_breadcrumb
from ..log import get_logger, optional_failure
from ..core.executor import LazyThreadPoolExecutor
from .player_runtime import _matching_external_player_pids, _descendant_pids, _all_external_player_pids
try:
    unquote = _us_env.urllib_parse.unquote
    urlparse = _us_env.urllib_parse.urlparse
except ImportError:
    unquote = _us_env.urllib.unquote
    from urlparse import urlparse
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.MenuList import MenuList
from Components.MultiContent import MultiContentEntryText, MultiContentEntryPixmapAlphaTest
try:
    from Components.MultiContent import MultiContentEntryPixmapAlphaBlend
except Exception:
    MultiContentEntryPixmapAlphaBlend = MultiContentEntryPixmapAlphaTest
try:
    from Components.ScrollLabel import ScrollLabel
except Exception:
    ScrollLabel = Label
from Components.Pixmap import Pixmap
from Components.ProgressBar import ProgressBar
from Components.ServiceEventTracker import ServiceEventTracker
try:
    from Components.ServiceEventTracker import InfoBarBase
except Exception:

    class InfoBarBase(object):

        def __init__(self, *args, **kwargs):
            pass
from enigma import ePicLoad, ePoint, eSize, getDesktop, eServiceReference, eTimer, iPlayableService, iServiceInformation, gFont, eListboxPythonMultiContent, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_HALIGN_CENTER, RT_VALIGN_CENTER, loadPNG
from skin import parseColor
try:
    from enigma import eDVBVolumecontrol
except Exception:
    eDVBVolumecontrol = None
from Screens.MessageBox import MessageBox
try:
    from Screens.SubtitleDisplay import SubtitleDisplay
except Exception:
    SubtitleDisplay = None
try:
    from Screens.ChoiceBox import ChoiceBox
except Exception:
    ChoiceBox = None
from Screens.Screen import Screen
from Tools.BoundFunction import boundFunction
LOG = get_logger()
from .player_visuals import _PROGRESS_FRAME_EXECUTOR, _PROGRESS_FRAME_PENDING, _PROGRESS_FRAME_LOCK
from .player_core import _PLAYER_BG_EXECUTOR, _process_rss_kb, _malloc_trim, force_session_silence, _optional_infobar, InfoBarAudioSelection, InfoBarMoviePlayerSummarySupport, eAVSwitch, InfoBarNotifications, InfoBarSeek, InfoBarSubtitleSupport, InfoBarSummarySupport, shutdown_player_workers, ENGINE_NAMES, _engine_label, _extension, _quality, _available_engines, normalize_dreamos_engine
from .player_artwork import _fallback_player_frames, _adaptive_player_frames, _progress_neon_frame, _schedule_progress_neon_frame, _asset, _laser_assets, _buffer_glass_asset, LASER_W, LASER_H, LASER_HEAD_TIP, LASER_X, LASER_Y, _adaptive_player_frames_memo, _image_value, _adaptive_info_frames, _cached_poster, _item_library_palette, _prepare_player_poster_fill, _prepare_live_picon, _player_title_logo_source, _prepare_player_title_logo_cache_path, _prepare_player_title_logo, _apply_player_font_scale
from .player_overlays import SUBTITLE_STYLE_COLORS, SUBTITLE_POSITION_PRESETS, _subtitle_color_name, _subtitle_position_name, _subtitle_glass_assets, SubtitleGlassList, PLAYER_INFO_SKIN, PlayerInformationOverlay, LIVE_ZAP_SKIN, _clean_live_name, _zap_palette, _zap_assets, _fit_zap_picon, UltraStalkerLiveZapList, UltraInfobarVisibility, NEXT_EPISODE_SKIN, UltraStalkerNextEpisodePrompt
from ..receiver_video import capture_aspect_mode, restore_aspect_mode, apply_aspect_mode, next_aspect_mode, aspect_mode_label
NEXT_EPISODE_AUTOPLAY_SESSION = True
_SUBTITLE_SESSION_STATE = {}
_SUBTITLE_SESSION_LOCK = threading.RLock()
_SUBTITLE_SESSION_MAX = 96
_SUBTITLE_SESSION_LOADED = False
_SUBTITLE_SESSION_DISK_STATE = None
_SUBTITLE_SESSION_REMOVED = {}
_SUBTITLE_SESSION_FILE = os.path.join(PERSISTENT_CACHE_ROOT, 'index', 'subtitle_sessions.json')
_US_SUBTITLE_API_REPORTED = set()
_US_TMP_POSTER_DIR = '/tmp/UltraStalker/player_posters'
_MAX_SANE_PTS = 8 * 3600 * 90000

def sane_play_pts(value, duration=0):
    """Return a 90 kHz position that is safe to display and to store.

    DreamOS servicemp3 reports success with an uninitialized uint32 PTS in
    the first seconds after evStart (4274813324 on the dm900 report). The
    counter then shows 13 hours and that value can be written as the resume
    bookmark. Values above 8 hours, or past a known duration, are not a
    position yet.
    """
    try:
        pts = int(value)
    except (TypeError, ValueError):
        return 0
    try:
        duration = int(duration or 0)
    except (TypeError, ValueError):
        duration = 0
    if duration < 0 or duration > _MAX_SANE_PTS:
        duration = 0
    if pts < 0 or pts > _MAX_SANE_PTS:
        return 0
    if duration and pts > duration + 5 * 90000:
        return 0
    return pts

def _us_subtitle_api_report(label, obj):
    """Write the subtitle-related API of this image to the debug log once."""
    if label in _US_SUBTITLE_API_REPORTED:
        return
    _US_SUBTITLE_API_REPORTED.add(label)

def _us_service_subtitle(service):
    """service.subtitle() where the image has it (OE-A); None otherwise."""
    if not service:
        return None
    getter = getattr(service, 'subtitle', None)
    if getter is None:
        _us_subtitle_api_report('service', service)
        tracks = getattr(service, 'subtitleTracks', None)
        if tracks is not None:
            try:
                obj = tracks()
                if obj is not None:
                    _us_subtitle_api_report('subtitleTracks', obj)
            except Exception:
                pass
        return None
    return getter()

def _dreamos_subtitle_tracks(service):
    """Return DreamOS iSubtitleTrackSelectionPtr when service.subtitle() is absent."""
    if not service:
        return None
    try:
        if getattr(service, 'subtitle', None) is not None and service.subtitle() is not None:
            return None
    except Exception:
        pass
    try:
        getter = getattr(service, 'subtitleTracks', None)
        return getter() if callable(getter) else None
    except Exception:
        return None

def _is_subtitle_selected(sel):
    """True when selected_subtitle represents an active track (OE-A tuple or DreamOS int>=0)."""
    if sel is None or sel is False:
        return False
    if isinstance(sel, int):
        return sel >= 0
    try:
        t = tuple(sel)
        if not t:
            return False
        if t[0] == 'dreamos_track':
            return len(t) > 1 and isinstance(t[1], int) and (t[1] >= 0)
        return t[:4] != (0, 0, 0, 0)
    except Exception:
        return False

def _subtitle_track_lang(service, entry):
    """Extract normalized language code from either an OE-A tuple or DreamOS track index."""
    if not _is_subtitle_selected(entry):
        return ''
    try:
        if isinstance(entry, int):
            st = _dreamos_subtitle_tracks(service)
            if st is not None:
                info = st.getSubtitleTrackInfo(int(entry))
                if info is not None:
                    lang = str(getattr(info, 'getLanguage', lambda: '')() or '').strip()
                    return _track_prefs.normalize_language(lang)
            return ''
        t = tuple(entry)
        if len(t) >= 3 and t[0] == 'dreamos_track':
            return _track_prefs.normalize_language(str(t[2] or ''))
        if len(t) > 4:
            return _track_prefs.normalize_language(t[4])
    except Exception:
        pass
    return ''

def _us_fetch_tmp_poster(url, trusted=()):
    """Download one poster into /tmp, cropped to the player's 250x375 card."""
    try:
        digest = hashlib.sha1(url.encode('utf-8', 'ignore')).hexdigest()
        target = os.path.join(_US_TMP_POSTER_DIR, digest + '_250x375.png')
        if os.path.isfile(target) and os.path.getsize(target) > 256:
            return target
        if _PILImage is None:
            return ''
        if not os.path.isdir(_US_TMP_POSTER_DIR):
            os.makedirs(_US_TMP_POSTER_DIR, 448)
        validate_remote_media_url(url, trusted_private_origins=trusted)
        opener = build_safe_media_opener(trusted_private_origins=trusted)
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0', 'Accept': 'image/*'})
        response = opener.open(req, timeout=10)
        try:
            data = response.read(4 * 1024 * 1024 + 1)
        finally:
            try:
                response.close()
            except Exception:
                pass
        if len(data) <= 256 or len(data) > 4 * 1024 * 1024:
            return ''
        import io as _io
        im = _PILImage.open(_io.BytesIO(data))
        im = im.convert('RGB')
        tw, th = (250, 375)
        sw, sh = im.size
        if sw <= 0 or sh <= 0:
            return ''
        scale = max(float(tw) / sw, float(th) / sh)
        nw, nh = (max(tw, int(round(sw * scale))), max(th, int(round(sh * scale))))
        resample = getattr(getattr(_PILImage, 'Resampling', _PILImage), 'LANCZOS', 1)
        im = im.resize((nw, nh), resample)
        left = (nw - tw) // 2
        top = (nh - th) // 2
        im = im.crop((left, top, left + tw, top + th))
        tmp = target + '.tmp.%d.%d' % (os.getpid(), threading.current_thread().ident)
        im.save(tmp, 'PNG')
        os.rename(tmp, target)
        try:
            files = sorted((os.path.join(_US_TMP_POSTER_DIR, n) for n in os.listdir(_US_TMP_POSTER_DIR)), key=os.path.getmtime)
            for old in files[:-40]:
                os.unlink(old)
        except Exception:
            pass
        return target
    except Exception as exc:
        optional_failure('player.poster_fallback_fetch', exc)
        return ''

def _subtitle_session_load_store_locked(allow_missing=False):
    global _SUBTITLE_SESSION_LOADED, _SUBTITLE_SESSION_DISK_STATE
    if _SUBTITLE_SESSION_LOADED:
        return True
    try:
        try:
            with open(_SUBTITLE_SESSION_FILE, 'r', encoding='utf-8') as fh:
                raw = fh.read(1048577)
            if len(raw) > 1048576:
                raise ValueError('subtitle state exceeds size limit')
            payload = json.loads(raw)
            rows = payload.get('items') if isinstance(payload, dict) else payload
            if not isinstance(rows, dict):
                raise ValueError('invalid subtitle state')
        except OSError as exc:
            if not isinstance(exc, FileNotFoundError):
                raise
            if not allow_missing:
                return False
            rows = {}
        valid = []
        now = time.time()
        for key, value in rows.items():
            if not isinstance(value, dict):
                continue
            try:
                saved_at = float(value.get('saved_at', 0.0) or 0.0)
            except Exception:
                saved_at = 0.0
            if not -float('inf') < saved_at < float('inf'):
                saved_at = 0.0
            if saved_at and now - saved_at > 15552000:
                continue
            value = dict(value)
            value['saved_at'] = saved_at
            valid.append((str(key), value))
        valid.sort(key=lambda kv: kv[1]['saved_at'], reverse=True)
        disk = dict(valid[:_SUBTITLE_SESSION_MAX])
        pending = sorted(_SUBTITLE_SESSION_STATE.items(), key=lambda kv: float((kv[1] or {}).get('saved_at', 0.0) or 0.0), reverse=True)[:_SUBTITLE_SESSION_MAX]
        merged = dict(pending)
        for key, value in disk.items():
            if key not in merged and key not in _SUBTITLE_SESSION_REMOVED and (len(merged) < _SUBTITLE_SESSION_MAX):
                merged[key] = dict(value)
        us_clear(_SUBTITLE_SESSION_STATE)
        _SUBTITLE_SESSION_STATE.update(merged)
        _SUBTITLE_SESSION_DISK_STATE = disk
        _SUBTITLE_SESSION_LOADED = True
        return True
    except Exception as exc:
        optional_failure('player.subtitle_session_store_load', exc)
        return False

def _subtitle_session_persist_store_locked():
    global _SUBTITLE_SESSION_DISK_STATE
    tmp = None
    try:
        if not persistent_write_gate(_SUBTITLE_SESSION_FILE):
            return False
        if not _subtitle_session_load_store_locked(allow_missing=True):
            return False
        ordered = sorted(_SUBTITLE_SESSION_STATE.items(), key=lambda kv: float((kv[1] or {}).get('saved_at', 0.0) or 0.0), reverse=True)[:_SUBTITLE_SESSION_MAX]
        current = dict(ordered)
        us_clear(_SUBTITLE_SESSION_STATE)
        _SUBTITLE_SESSION_STATE.update(current)
        if current == _SUBTITLE_SESSION_DISK_STATE:
            us_clear(_SUBTITLE_SESSION_REMOVED)
            return True
        parent = os.path.dirname(_SUBTITLE_SESSION_FILE)
        os.makedirs(parent, mode=448, exist_ok=True)
        payload = {'version': 1, 'items': current}
        tmp = _SUBTITLE_SESSION_FILE + '.tmp.%d.%d' % (os.getpid(), threading.get_ident())
        with open(tmp, 'w', encoding='utf-8') as fh:
            json.dump(payload, fh, ensure_ascii=False, separators=(',', ':'))
            fh.flush()
            os.fsync(fh.fileno())
        try:
            os.chmod(tmp, 384)
        except Exception:
            pass
        os.replace(tmp, _SUBTITLE_SESSION_FILE)
        _SUBTITLE_SESSION_DISK_STATE = {key: dict(value) for key, value in current.items()}
        us_clear(_SUBTITLE_SESSION_REMOVED)
        return True
    except Exception as exc:
        optional_failure('player.subtitle_session_store_save', exc)
        try:
            if tmp and os.path.exists(tmp):
                os.unlink(tmp)
        except Exception:
            pass
        return False

def _subtitle_session_remove_store_locked(key):
    _subtitle_session_load_store_locked()
    _SUBTITLE_SESSION_STATE.pop(key, None)
    _SUBTITLE_SESSION_REMOVED.pop(key, None)
    _SUBTITLE_SESSION_REMOVED[key] = None
    while len(_SUBTITLE_SESSION_REMOVED) > _SUBTITLE_SESSION_MAX:
        _SUBTITLE_SESSION_REMOVED.pop(next(iter(_SUBTITLE_SESSION_REMOVED)))
    return _subtitle_session_persist_store_locked()

class _ExternalSubtitleProviderBridge(object):
    """Ultra-owned adapter around the public SubsSupport / SubsSupportPro API.

    The external plugin owns search, download, rendering, timing, FPS and its
    own subtitle UI. Ultra Stalker only starts/stops the provider and forwards
    lifecycle hints such as seek/close. No subtitle files are copied, moved,
    parsed, cached or activated by Ultra while this bridge is active.
    """
    PROVIDERS = ('subssupport', 'subssupportpro')

    def __init__(self, player):
        self.player = player
        self.kind = ''
        self.owner = None
        self.status_screen_cls = None

    @staticmethod
    def _patch_subssupport_dreamos(sub_mod):
        """Guard SubsSupport/SubsSupportPro against DreamOS config.subtitles KeyError,
        None subtitle_window when embeddedSupport=False, and DreamOS iPlayableServicePtr
        lacking service.subtitle() (which crashes __subsMenuCB -> enableSubtitle)."""
        try:
            from ..receiver_guards import guard_dreamos_enigma
            guard_dreamos_enigma()
        except Exception:
            pass
        if sub_mod is None:
            return
        try:
            orig_font_cfg = getattr(sub_mod, 'getEmbeddedFontSizeCfg', None)
            if callable(orig_font_cfg) and (not getattr(orig_font_cfg, '_us_safe_font_cfg', False)):

                def _safe_font_cfg(*args, **kwargs):
                    try:
                        return orig_font_cfg(*args, **kwargs)
                    except Exception:
                        return None
                _safe_font_cfg._us_safe_font_cfg = True
                sub_mod.getEmbeddedFontSizeCfg = _safe_font_cfg
        except Exception:
            pass

        class _DummySubtitleWindow(object):
            instance = None

            def hide(self):
                pass

            def show(self):
                pass

            def setFont(self, *a, **k):
                pass

            def setForegroundColor(self, *a, **k):
                pass

            def setShadowColor(self, *a, **k):
                pass

            def setShadowOffset(self, *a, **k):
                pass
        for emb_name in ('SubsProSupportEmbedded', 'SubsSupportEmbedded'):
            emb_cls = getattr(sub_mod, emb_name, None)
            if emb_cls is None:
                continue
            orig_init = getattr(emb_cls, '__init__', None)
            if orig_init is not None and (not getattr(orig_init, '_us_safe_emb_init', False)):

                def _make_safe_emb_init(_orig):

                    def _safe_emb_init(self_emb, *args, **kwargs):
                        if getattr(self_emb, 'subtitle_window', None) is None:
                            self_emb.subtitle_window = _DummySubtitleWindow()
                        try:
                            _orig(self_emb, *args, **kwargs)
                        except Exception:
                            pass
                        if getattr(self_emb, 'subtitle_window', None) is None:
                            self_emb.subtitle_window = _DummySubtitleWindow()
                        for _trk_attr in ('_SubsProSupportEmbedded__subtitle_Tracks', '_SubsSupportEmbedded__subtitle_Tracks'):
                            if not hasattr(self_emb, _trk_attr):
                                setattr(self_emb, _trk_attr, [])
                        if not hasattr(self_emb, 'embeddedSubsEnabled'):
                            self_emb.embeddedSubsEnabled = False
                    _safe_emb_init._us_safe_emb_init = True
                    return _safe_emb_init
                try:
                    emb_cls.__init__ = _make_safe_emb_init(orig_init)
                except Exception:
                    pass

            def _safe_get_sub(self_emb, *args, **kwargs):
                try:
                    srv = self_emb.session.nav.getCurrentService()
                    getter = getattr(srv, 'subtitle', None)
                    return getter() if callable(getter) else None
                except Exception:
                    return None
            _safe_get_sub._us_safe_patched = True
            try:
                emb_cls.getCurrentServiceSubtitle = _safe_get_sub
            except Exception:
                pass
            for _mname, _fallback in (('enableSubtitle', None), ('disableSubtitle', None), ('getSubtitleList', []), ('exitEmbeddedSubs', None), ('setEmbeddedSubsStyle', None), ('refreshEmbeddedSubs', None)):
                _orig_m = getattr(emb_cls, _mname, None)
                if callable(_orig_m) and (not getattr(_orig_m, '_us_safe_patched', False)):

                    def _make_safe_emb_m(_fn, _fb, _name):

                        def _wrapped(self_emb, *a, **k):
                            if getattr(self_emb, 'subtitle_window', None) is None:
                                self_emb.subtitle_window = _DummySubtitleWindow()
                            if _name in ('enableSubtitle', 'disableSubtitle'):
                                try:
                                    srv = self_emb.session.nav.getCurrentService()
                                    if srv is None or not hasattr(srv, 'subtitle'):
                                        self_emb.embeddedSubsEnabled = False
                                        return _fb
                                except Exception:
                                    return _fb
                            try:
                                return _fn(self_emb, *a, **k)
                            except Exception:
                                return list(_fb) if isinstance(_fb, list) else _fb
                        _wrapped._us_safe_patched = True
                        return _wrapped
                    try:
                        setattr(emb_cls, _mname, _make_safe_emb_m(_orig_m, _fallback, _mname))
                    except Exception:
                        pass
        for main_name in ('SubsProSupport', 'SubsSupport'):
            main_cls = getattr(sub_mod, main_name, None)
            if main_cls is None:
                continue
            for _attr in list(dir(main_cls)):
                if _attr.endswith('__subsMenuCB') or _attr == 'subsMenuCB':
                    _orig_cb = getattr(main_cls, _attr, None)
                    if callable(_orig_cb) and (not getattr(_orig_cb, '_us_safe_patched', False)):

                        def _make_safe_cb(_fn):

                            def _wrapped_cb(self_sub, *a, **k):
                                try:
                                    res = _fn(self_sub, *a, **k)
                                except Exception as exc:
                                    optional_failure('player.subssupport_menu_cb', exc)
                                    res = None
                                try:
                                    bridge = getattr(self_sub, '_us_bridge_ref', None)
                                    if bridge is not None:
                                        bridge._on_menu_closed()
                                except Exception:
                                    pass
                                return res
                            _wrapped_cb._us_safe_patched = True
                            return _wrapped_cb
                        try:
                            setattr(main_cls, _attr, _make_safe_cb(_orig_cb))
                        except Exception:
                            pass
            for _mname, _fb in (('loadSubs', False), ('resumeSubs', None), ('pauseSubs', None), ('playAfterSeek', None), ('exitSubs', None), ('resetSubs', None)):
                _orig_m = getattr(main_cls, _mname, None)
                if callable(_orig_m) and (not getattr(_orig_m, '_us_safe_patched', False)):

                    def _make_safe_main_m(_fn, _default):

                        def _wrapped_m(self_sub, *a, **k):
                            try:
                                return _fn(self_sub, *a, **k)
                            except Exception as exc:
                                optional_failure('player.subssupport_method', exc)
                                return _default
                        _wrapped_m._us_safe_patched = True
                        return _wrapped_m
                    try:
                        setattr(main_cls, _mname, _make_safe_main_m(_orig_m, _fb))
                    except Exception:
                        pass

    def _load_classes(self, kind):
        kind = str(kind or '').strip().lower()
        if kind not in ('subssupport', 'subssupportpro'):
            raise ValueError('unsupported subtitle provider')
        order = ('subssupportpro', 'subssupport') if kind == 'subssupportpro' else ('subssupport', 'subssupportpro')
        last_exc = None
        for candidate in order:
            try:
                if candidate == 'subssupportpro':
                    from Plugins.Extensions.SubsSupportPro import SubsProSupport
                    from Plugins.Extensions.SubsSupportPro import subtitles as sub_mod
                    from Plugins.Extensions.SubsSupportPro.subtitles import SubsStatusScreen
                    self._patch_subssupport_dreamos(sub_mod)
                    return (SubsProSupport, SubsStatusScreen, 'subssupportpro')
                else:
                    from Plugins.Extensions.SubsSupport import SubsSupport
                    from Plugins.Extensions.SubsSupport import subtitles as sub_mod
                    from Plugins.Extensions.SubsSupport.subtitles import SubsStatusScreen
                    self._patch_subssupport_dreamos(sub_mod)
                    return (SubsSupport, SubsStatusScreen, 'subssupport')
            except ImportError as exc:
                last_exc = exc
                continue
        if last_exc is not None:
            raise last_exc
        raise ImportError('No module named SubsSupport')

    def _build_owner(self, kind):
        loaded = self._load_classes(kind)
        if len(loaded) == 3:
            owner_cls, status_cls, resolved_kind = loaded
        else:
            owner_cls, status_cls = loaded
            resolved_kind = kind
        kwargs = dict(session=self.player.session, autoLoad=False, showGUIInfoMessages=True, embeddedSupport=False, preferEmbedded=False, searchSupport=True)
        if resolved_kind == 'subssupportpro':
            kwargs['useSubclassKeymap'] = False
        owner = owner_cls(**kwargs)
        try:
            owner._us_bridge_ref = self
        except Exception:
            pass
        self.kind = resolved_kind
        self.owner = owner
        self.status_screen_cls = status_cls
        return owner

    def _on_menu_closed(self):
        player = getattr(self, 'player', None)
        if player is None or getattr(player, 'restored', False) or getattr(player, '_closing_playback', False):
            return
        try:
            player._external_subtitle_ui_hold_end()
        except Exception:
            pass
        if self.is_loaded():
            try:
                self.owner.resumeSubs()
                self.owner.playAfterSeek()
            except Exception:
                pass

    def ensure(self, kind):
        kind = str(kind or '').strip().lower()
        if kind not in self.PROVIDERS:
            return None
        if self.owner is not None and self.kind == kind:
            return self.owner
        self.close()
        return self._build_owner(kind)

    def open_menu(self, kind):
        owner = self.ensure(kind)
        if owner is None:
            return False
        owner.subsMenu()
        return True

    def is_loaded(self):
        owner = self.owner
        if owner is None:
            return False
        try:
            return bool(owner.isSubsLoaded())
        except Exception:
            return False

    def open_status(self):
        owner = self.owner
        status_cls = self.status_screen_cls
        if owner is None or status_cls is None:
            return False
        if not self.is_loaded():
            owner.subsMenu()
            return True
        self.player.session.open(status_cls, owner.setSubsDelay, owner.getSubsDelay, owner.subscribeOnSubsDelayChanged, owner.unsubscribeOnSubsDelayChanged, owner.setSubsDelayToNextSubtitle, owner.setSubsDelayToPrevSubtitle, owner.setSubsFps, owner.getSubsFps, 200, False)
        return True

    def after_seek(self):
        owner = self.owner
        if owner is None or not self.is_loaded():
            return
        try:
            owner.playAfterSeek()
        except Exception as exc:
            optional_failure('player.external_subtitle_seek', exc)

    def play_state(self, value):
        owner = self.owner
        if owner is None or not self.is_loaded():
            return
        try:
            value = str(value or '')
            if value == '||' or value.startswith('>>') or value.startswith('<<') or value.startswith('/'):
                owner.pauseSubs()
            elif value == '>':
                owner.resumeSubs()
                owner.playAfterSeek()
        except Exception as exc:
            optional_failure('player.external_subtitle_play_state', exc)

    def service_started(self):
        owner = self.owner
        if owner is None or not self.is_loaded():
            return
        try:
            owner.resumeSubs()
            owner.playAfterSeek()
        except Exception as exc:
            optional_failure('player.external_subtitle_service_started', exc)

    def snapshot(self):
        """Return provider-owned subtitle state without copying its file."""
        owner = self.owner
        if owner is None or not self.is_loaded():
            return None
        try:
            path = str(owner.getSubsPath() or '')
        except Exception:
            path = ''
        if not path or not os.path.isfile(path):
            return None
        try:
            delay = owner.getSubsDelay()
            delay = int(delay) if delay is not None else 0
        except Exception:
            delay = 0
        try:
            fps = owner.getSubsFps()
            fps = float(fps) if fps is not None else None
        except Exception:
            fps = None
        return {'source': self.kind, 'path': path, 'delay_ms': delay, 'fps': fps}

    def restore(self, state):
        """Restore one RAM-session subtitle through the provider public API."""
        state = state if isinstance(state, dict) else {}
        kind = str(state.get('source') or '').strip().lower()
        path = str(state.get('path') or '')
        if kind not in self.PROVIDERS or not path or (not os.path.isfile(path)):
            return False
        owner = self.ensure(kind)
        if owner is None or not owner.loadSubs(path, newService=True):
            return False
        try:
            delay = state.get('delay_ms')
            if delay is not None:
                owner.setSubsDelay(int(delay))
        except Exception as exc:
            optional_failure('player.external_subtitle_restore_delay', exc)
        try:
            fps = state.get('fps')
            if fps is not None:
                owner.setSubsFps(float(fps))
        except Exception as exc:
            optional_failure('player.external_subtitle_restore_fps', exc)
        try:
            owner.resumeSubs()
            owner.playAfterSeek()
        except Exception as exc:
            optional_failure('player.external_subtitle_restore_resume', exc)
        return True

    def close(self):
        owner = self.owner
        self.owner = None
        self.kind = ''
        self.status_screen_cls = None
        if owner is None:
            return
        try:
            owner.exitSubs()
        except Exception as exc:
            optional_failure('player.external_subtitle_close', exc)
        try:
            cleanup_embedded = getattr(owner, 'exitEmbeddedSubs', None)
            if callable(cleanup_embedded):
                cleanup_embedded()
        except Exception as exc:
            optional_failure('player.external_subtitle_embedded_close', exc)

def _short_portal_label(value, limit=10):
    """Portal name for the narrow slot on the progress-bar line."""
    text = str(value or '').strip()
    return text if len(text) <= limit else text[:limit - 1].rstrip() + '…'
_LB_CHIPS = ('q', 'ac', 'vc', 'fps', 'st', 'eng')
_LB_PIXMAPS = ('lb_bg', 'lb2_left', 'lb2_center', 'lb2_right', 'lb2_dock', 'lb2_eng', 'lb_poster_edge', 'lb_live_pill', 'lb_num_pill', 'lb_head') + tuple(('lb_cbg_' + _k for _k in _LB_CHIPS))
_LB_LABELS = ('lb_live', 'lb_num', 'lb_now_time', 'lb_now_title', 'lb_ep_name', 'lb_now_left', 'lb_next_time', 'lb_next_title', 'lb_next_dur', 'lb_langs') + tuple(('lb_c_' + _k for _k in _LB_CHIPS))
_LB_WIDGETS = _LB_PIXMAPS + _LB_LABELS + ('lb_prog', 'lb_buf')
_LB_VOD_TYPES = ('vod', 'series', 'episode', 'movie', 'catchup', 'trailer')
_LB_GEOM = {('new', 'live'): {'L': 332.0, 'R': 1572.0, 'top_cy': 838.0, 'top_big': 32, 'top_small': 24, 'prog': (332, 870, 1240), 'keys': (332.0, 1572.0, 1017.0), 'badge': (186.0, 1002.0), 'num_corner': None, 'status_w': 214}, ('new', 'vod'): {'L': 332.0, 'R': 1572.0, 'top_cy': 838.0, 'top_big': 32, 'top_small': 24, 'prog': (332, 870, 1240), 'keys': (332.0, 1572.0, 1017.0), 'badge': (186.0, 1002.0), 'num_corner': None, 'status_w': 214}, ('new2', 'live'): {'L': 424.0, 'R': 1444.0, 'top_cy': 814.0, 'top_big': 28, 'top_small': 20, 'prog': (424, 940, 1020), 'keys': (384.0, 1484.0, 1033.0), 'badge': (206.0, 957.0), 'num_corner': (44.0, 758.0), 'status_w': 280}, ('new2', 'vod'): {'L': 356.0, 'R': 1452.0, 'top_cy': 809.0, 'top_big': 32, 'top_small': 22, 'prog': (356, 896, 1096), 'keys': (316.0, 1488.0, 1033.0), 'badge': (186.0, 1002.0), 'num_corner': None, 'status_w': 280}}
_LB_LEGACY = ('adaptive_main', 'adaptive_keybar', 'adaptive_live_picon', 'adaptive_progress_track', 'live_epg_now', 'live_epg_next', 'category', 'quality', 'now', 'connection', 'buffer_pill', 'logo', 'poster_neon_halo', 'adaptive_poster', 'vod_title', 'title_logo', 'episode_marker', 'episode_name', 'chip_video_quality_bg', 'chip_audio_codec_bg', 'chip_video_codec_bg', 'chip_fps_bg', 'chip_stream_bg', 'chip_audio_bg', 'chip_engine_bg', 'chip_video_quality', 'chip_audio_codec', 'chip_video_codec', 'chip_fps', 'chip_stream', 'chip_audio', 'chip_engine', 'chip_subtitles', 'chipt_quality', 'chipt_audio_codec', 'chipt_video_codec', 'chipt_fps', 'chipt_stream', 'chipt_audio', 'chipt_engine', 'vod_quality_badge', 'audio_format_badge', 'video_quality', 'audio_codec', 'video_codec', 'extension', 'audio_tag', 'engine', 'subtitle_tag')
_LB_LEGACY_VOD = tuple((n for n in _LB_LEGACY if n != 'logo')) + ('live_picon', 'vod_progress', 'progress_neon', 'progress_head', 'buffer_glass', 'elapsed_time', 'total_time', 'remaining_time', 'skip_hint')
_LB2_PANEL_DROP = 12.0
_LB2_FIXED = ('lb2_dock', 'lb2_eng', 'lb_c_eng', 'logo', 'lb_poster_edge')
_LB_DY = {'new': 26.0, 'new2': 14.0}
_LB_FONT_FACTORS = {'normal': 1.0, 'large': 1.12, 'larger': 1.22, 'xlarge': 1.32}
_LB_LANG_NAMES = {'en': 'English', 'ar': 'Arabic', 'fr': 'French', 'de': 'German', 'es': 'Spanish', 'it': 'Italian', 'tr': 'Turkish', 'ru': 'Russian', 'hi': 'Hindi', 'ja': 'Japanese', 'ko': 'Korean', 'zh': 'Chinese', 'fa': 'Persian', 'pt': 'Portuguese', 'nl': 'Dutch', 'pl': 'Polish', 'he': 'Hebrew', 'ur': 'Urdu'}

def _lb_lang_name(code):
    """'ar' / 'AR' / 'PT_BR' -> 'Arabic' / 'Portuguese'; unknown codes show upper-case; '' when empty."""
    code = _track_prefs.normalize_language(code)
    if not code:
        return ''
    base = code
    name = _LB_LANG_NAMES.get(base)
    return _(name) if name else base.upper()

def _lb_pill_width(width, low, high, step=4):
    """Snap a measured width to one of the pre-rendered pill PNG widths."""
    try:
        width = int(width + 0.999)
    except Exception:
        width = low
    width = max(low, min(high, width))
    rem = (width - low) % step
    if rem:
        width = min(high, width + step - rem)
    return width
PLAYER_SKIN = '\n<screen name="UltraStalkerPlayer" position="0,0" size="1920,1080" backgroundColor="#ff000000" flags="wfNoBorder">\n    <widget name="resume_mask" position="0,0" size="1920,1080" font="Regular;1" foregroundColor="#000000" backgroundColor="#000000" transparent="0" zPosition="100" />\n\n    <widget name="adaptive_main" position="60,807" size="1800,200" alphatest="blend" transparent="1" zPosition="5" />\n\n    <!-- VOD/episode poster: separate oversized neon layer fixes Enigma2 clipping. -->\n    <widget name="logo" position="56,718" size="232,349" alphatest="blend" scale="1" backgroundColor="#07111d" transparent="0" zPosition="7" />\n    <widget name="poster_neon_halo" position="2000,0" size="1,1" alphatest="blend" transparent="1" zPosition="9" />\n    <widget name="adaptive_poster" position="48,710" size="248,365" alphatest="blend" scale="1" transparent="1" zPosition="10" />\n    <!-- Live-only 220x132 picon card, centered and aspect-safe. -->\n    <!-- Adaptive frame stays behind the actual picon. The picon is the lit foreground subject. -->\n    <widget name="adaptive_live_picon" position="85,831" size="240,152" alphatest="blend" transparent="1" zPosition="9" />\n    <widget name="live_picon" position="95,841" size="220,132" alphatest="blend" scale="1" transparent="1" zPosition="12" />\n\n    <!-- Live retains its original compact labels. VOD/episodes use the centered premium title area below. -->\n    <widget name="channel" position="350,812" size="1110,56" font="Regular;34" halign="center" valign="center" foregroundColor="#ffffff" backgroundColor="#000000" transparent="1" zPosition="6" noWrap="1" shadowColor="#000000" shadowOffset="1,1" />\n    <widget name="category" position="1480,823" size="120,32" font="Regular;18" foregroundColor="#ffffff" backgroundColor="#132633" halign="center" valign="center" transparent="1" zPosition="6" />\n    <widget name="quality" position="1615,823" size="110,32" font="Regular;18" foregroundColor="#d8e8ef" backgroundColor="#132633" halign="center" valign="center" transparent="1" zPosition="6" />\n    <widget name="retry_status" position="1470,823" size="245,32" font="Regular;17" foregroundColor="#f4d27a" backgroundColor="#000000" halign="right" valign="center" transparent="1" zPosition="20" noWrap="1" />\n    <widget name="episode_marker" position="370,823" size="170,28" font="Regular;22" halign="left" valign="center" foregroundColor="#dce8ed" backgroundColor="#000000" transparent="1" zPosition="8" noWrap="1" />\n    <widget name="vod_title" position="430,819" size="1220,72" font="Regular;52" halign="center" valign="center" foregroundColor="#ffffff" backgroundColor="#000000" transparent="1" zPosition="8" noWrap="1" />\n    <widget name="title_logo" position="430,819" size="1220,72" alphatest="blend" scale="1" transparent="1" zPosition="9" />\n\n    <!-- Clock/date live inside the main Player panel at its far right. -->\n    <widget name="server_name" position="1722,895" size="106,28" font="Regular;24" halign="right" valign="center" foregroundColor="#d7eef7" backgroundColor="#000000" transparent="1" zPosition="22" noWrap="1" shadowColor="#000000" shadowOffset="1,1" />\n    <widget source="global.CurrentTime" render="Label" position="1725,819" size="110,38" font="Regular;31" halign="right" valign="center" foregroundColor="#ffffff" backgroundColor="#000000" transparent="1" zPosition="10">\n        <convert type="ClockToText">Format:%%H:%%M</convert>\n    </widget>\n    <widget source="global.CurrentTime" render="Label" position="1705,859" size="130,22" font="Regular;14" halign="right" valign="center" foregroundColor="#d7dee2" backgroundColor="#000000" transparent="1" zPosition="10">\n        <convert type="ClockToText">Format:%%a %%d %%b %%Y</convert>\n    </widget>\n\n    <widget name="episode_name" position="370,851" size="560,28" font="Regular;21" halign="left" valign="center" foregroundColor="#e2be6e" backgroundColor="#000000" transparent="1" zPosition="8" noWrap="1" />\n    <widget name="skip_hint" position="370,879" size="265,24" font="Regular;16" foregroundColor="#a2e1c6" backgroundColor="#000000" transparent="1" zPosition="8" />\n    <widget name="now" position="650,865" size="525,28" font="Regular;18" foregroundColor="#d4dde3" backgroundColor="#000000" halign="center" transparent="1" zPosition="6" />\n    <widget name="buffer_pill" pixmap="%(bufpill)s" position="2000,0" size="1,1" alphatest="blend" scale="1" transparent="1" zPosition="7" />\n    <widget name="buffer_status" position="1290,865" size="390,28" font="Regular;16" foregroundColor="#a2e1c6" backgroundColor="#000000" halign="right" valign="center" transparent="1" zPosition="8" noWrap="1" shadowColor="#000000" shadowOffset="1,1" />\n    <widget name="connection" position="1140,865" size="440,28" font="Regular;16" foregroundColor="#e0eef2" backgroundColor="#000000" halign="right" transparent="1" zPosition="7" />\n\n    <widget name="vod_progress" position="370,905" size="1350,8" borderWidth="0" foregroundColor="#2b2d33" backgroundColor="#2b2d33" zPosition="5" />\n    <widget name="adaptive_progress_track" position="370,905" size="1350,8" alphatest="blend" transparent="1" zPosition="6" />\n    <widget name="buffer_glass" position="370,905" size="1350,8" alphatest="blend" transparent="1" zPosition="11" scale="0" />\n    <widget name="progress_neon" position="370,905" size="1350,8" alphatest="blend" transparent="1" zPosition="8" scale="0" />\n    <widget name="progress_head" position="370,905" size="8,8" alphatest="blend" transparent="1" zPosition="10" />\n    <widget name="elapsed_time" position="370,916" size="190,24" font="Regular;16" foregroundColor="#d8e0e5" backgroundColor="#000000" transparent="1" zPosition="6" noWrap="1"/>\n    <widget name="total_time" position="840,916" size="410,24" font="Regular;16" foregroundColor="#d8e0e5" backgroundColor="#000000" halign="center" transparent="1" zPosition="6" noWrap="1"/>\n    <widget name="remaining_time" position="1530,916" size="190,24" font="Regular;16" foregroundColor="#d8e0e5" backgroundColor="#000000" halign="right" transparent="1" zPosition="6" noWrap="1"/>\n    <!-- Live only: transparent Now/Next EPG text sits directly on the InfoBar. -->\n    <widget name="live_epg_now" position="350,874" size="1340,34" font="Regular;25" foregroundColor="#ffffff" backgroundColor="#000000" transparent="1" zPosition="12" noWrap="1" />\n    <widget name="live_epg_next" position="350,916" size="1340,27" font="Regular;18" foregroundColor="#a9bac5" backgroundColor="#000000" transparent="1" zPosition="12" noWrap="1" />\n\n    <!-- Adaptive bordered technical cards. -->\n    <widget name="chip_video_quality_bg" position="376,947" size="165,46" alphatest="blend" scale="1" transparent="1" zPosition="7"/>\n    <widget name="chip_video_quality" position="360,947" size="196,46" alphatest="blend" scale="1" transparent="1" zPosition="8"/>\n    <widget name="video_quality" position="376,947" size="196,46" font="Regular;19" foregroundColor="#ffffff" halign="center" valign="center" transparent="1" zPosition="6" noWrap="1" shadowColor="#000000" shadowOffset="1,1"/>\n    <!-- Movies/Series only: one-shot decoder quality badge.  The 134x42 slot\n         contains the existing 122x34 badge at native size with 6x4 px breathing room. -->\n    <widget name="vod_quality_badge" position="378,949" size="134,42" alphatest="blend" scale="1" transparent="1" zPosition="7"/>\n    <!-- Audio-format badge. It follows the same startup/live service metadata\n         path as the quality badge and selects one matching bundled audio icon. -->\n    <widget name="audio_format_badge" position="518,949" size="134,42" alphatest="blend" scale="1" transparent="1" zPosition="7"/>\n    <widget name="chip_video_codec_bg" position="776,947" size="185,46" alphatest="blend" scale="1" transparent="1" zPosition="7"/>\n    <widget name="chip_video_codec" position="769,947" size="199,46" alphatest="blend" scale="1" transparent="1" zPosition="8"/>\n    <widget name="video_codec" position="845,947" size="199,46" font="Regular;19" foregroundColor="#ffffff" halign="center" valign="center" transparent="1" zPosition="6" noWrap="1" shadowColor="#000000" shadowOffset="1,1"/>\n    <widget name="chip_audio_codec_bg" position="561,947" size="195,46" alphatest="blend" scale="1" transparent="1" zPosition="7"/>\n    <widget name="chip_audio_codec" position="558,947" size="201,46" alphatest="blend" scale="1" transparent="1" zPosition="8"/>\n    <widget name="audio_codec" position="608,947" size="201,46" font="Regular;19" foregroundColor="#ffffff" halign="center" valign="center" transparent="1" zPosition="6" noWrap="1" shadowColor="#000000" shadowOffset="1,1"/>\n    <widget name="chip_fps_bg" position="981,947" size="150,46" alphatest="blend" scale="1" transparent="1" zPosition="7"/>\n    <widget name="chip_fps" position="981,947" size="150,46" alphatest="blend" scale="1" transparent="1" zPosition="8"/>\n    <widget name="chip_stream_bg" position="1151,947" size="175,46" alphatest="blend" scale="1" transparent="1" zPosition="7"/>\n    <widget name="chip_stream" position="1141,947" size="194,46" alphatest="blend" scale="1" transparent="1" zPosition="8"/>\n    <widget name="extension" position="1080,947" size="194,46" font="Regular;19" foregroundColor="#ffffff" halign="center" valign="center" transparent="1" zPosition="6" noWrap="1" shadowColor="#000000" shadowOffset="1,1"/>\n    <widget name="chip_audio_bg" position="1346,947" size="170,46" alphatest="blend" scale="1" transparent="1" zPosition="7"/>\n    <widget name="chip_audio" position="1336,947" size="189,46" alphatest="blend" scale="1" transparent="1" zPosition="8"/>\n    <widget name="audio_tag" position="1308,947" size="189,46" font="Regular;19" foregroundColor="#ffffff" halign="center" valign="center" transparent="1" zPosition="6" noWrap="1" shadowColor="#000000" shadowOffset="1,1"/>\n    <widget name="chip_subtitles" position="1360,949" size="170,42" alphatest="blend" transparent="1" zPosition="5"/>\n    <widget name="subtitle_tag" position="1360,949" size="170,42" font="Regular;19" foregroundColor="#ffffff" halign="center" valign="center" transparent="1" zPosition="6" noWrap="1" shadowColor="#000000" shadowOffset="1,1"/>\n    <widget name="chip_engine_bg" position="1536,947" size="287,46" alphatest="blend" scale="1" transparent="1" zPosition="7"/>\n    <widget name="chip_engine" position="1536,947" size="287,46" alphatest="blend" scale="1" transparent="1" zPosition="8"/>\n    <widget name="engine" position="1534,947" size="287,46" font="Regular;18" foregroundColor="#ffffff" halign="center" valign="center" transparent="1" zPosition="6" noWrap="1" shadowColor="#000000" shadowOffset="1,1"/>\n\n    <widget name="chipt_quality" position="376,947" size="165,46" font="Regular;19" foregroundColor="#ffffff" halign="center" valign="center" transparent="1" zPosition="9" noWrap="1" shadowColor="#000000" shadowOffset="1,1"/>\n    <widget name="chipt_audio_codec" position="561,947" size="195,46" font="Regular;19" foregroundColor="#ffffff" halign="center" valign="center" transparent="1" zPosition="9" noWrap="1" shadowColor="#000000" shadowOffset="1,1"/>\n    <widget name="chipt_video_codec" position="776,947" size="185,46" font="Regular;19" foregroundColor="#ffffff" halign="center" valign="center" transparent="1" zPosition="9" noWrap="1" shadowColor="#000000" shadowOffset="1,1"/>\n    <widget name="chipt_fps" position="981,947" size="150,46" font="Regular;19" foregroundColor="#ffffff" halign="center" valign="center" transparent="1" zPosition="9" noWrap="1" shadowColor="#000000" shadowOffset="1,1"/>\n    <widget name="chipt_stream" position="1151,947" size="175,46" font="Regular;19" foregroundColor="#ffffff" halign="center" valign="center" transparent="1" zPosition="9" noWrap="1" shadowColor="#000000" shadowOffset="1,1"/>\n    <widget name="chipt_audio" position="1346,947" size="170,46" font="Regular;19" foregroundColor="#ffffff" halign="center" valign="center" transparent="1" zPosition="9" noWrap="1" shadowColor="#000000" shadowOffset="1,1"/>\n    <widget name="chipt_engine" position="1536,947" size="287,46" font="Regular;19" foregroundColor="#ffffff" halign="center" valign="center" transparent="1" zPosition="9" noWrap="1" shadowColor="#000000" shadowOffset="1,1"/>\n    <widget name="online_subtitle" position="170,805" size="1580,150" font="Regular;38" halign="center" valign="bottom" foregroundColor="#ffffff" shadowColor="#000000" shadowOffset="3,3" transparent="1" zPosition="4" />\n\n    <!-- Premium key bar aligns directly under the main Player panel; buttons only. -->\n    <widget name="adaptive_keybar" position="320,1017" size="1540,58" alphatest="blend" transparent="1" zPosition="5" />\n    <!-- V9.2.2-r6: every language uses the colour line + translated text (engraved English labels removed). -->\n    <widget name="key_dash_red" pixmap="%(dashred)s" position="328,1025" size="56,42" alphatest="blend" zPosition="7" />\n    <widget name="key_red" position="390,1025" size="228,42" font="Regular;22" halign="left" valign="center" foregroundColor="#ffffff" transparent="1" zPosition="8" noWrap="1" shadowColor="#000000" shadowOffset="1,1"/>\n    <widget name="key_dash_green" pixmap="%(dashgreen)s" position="708,1025" size="56,42" alphatest="blend" zPosition="7" />\n    <widget name="key_green" position="770,1025" size="228,42" font="Regular;22" halign="left" valign="center" foregroundColor="#ffffff" transparent="1" zPosition="8" noWrap="1" shadowColor="#000000" shadowOffset="1,1"/>\n    <widget name="key_dash_yellow" pixmap="%(dashyellow)s" position="1088,1025" size="56,42" alphatest="blend" zPosition="7" />\n    <widget name="key_yellow" position="1150,1025" size="228,42" font="Regular;22" halign="left" valign="center" foregroundColor="#ffffff" transparent="1" zPosition="8" noWrap="1" shadowColor="#000000" shadowOffset="1,1"/>\n    <widget name="key_dash_blue" pixmap="%(dashblue)s" position="1468,1025" size="56,42" alphatest="blend" zPosition="7" />\n    <widget name="key_blue" position="1530,1025" size="228,42" font="Regular;22" halign="left" valign="center" foregroundColor="#ffffff" transparent="1" zPosition="8" noWrap="1" shadowColor="#000000" shadowOffset="1,1"/>\n\n    <!-- R5.541 Live InfoBar, R5.542 also Movies/Series/Episodes (poster instead\n         of the picon card).  Every text box is measured and placed at runtime. -->\n    <widget name="lb_bg" pixmap="%(lbbar)s" position="40,800" size="1840,250" alphatest="blend" transparent="1" zPosition="4" />\n    <widget name="lb2_left" position="56,772" size="300,216" alphatest="blend" scale="1" transparent="1" zPosition="4" />\n    <widget name="lb2_center" position="384,772" size="1100,216" alphatest="blend" scale="1" transparent="1" zPosition="4" />\n    <widget name="lb2_right" position="1512,772" size="352,216" alphatest="blend" scale="1" transparent="1" zPosition="4" />\n    <widget name="lb2_dock" position="384,1004" size="1100,58" alphatest="blend" scale="1" transparent="1" zPosition="4" />\n    <widget name="lb2_eng" position="1512,1004" size="352,58" alphatest="blend" scale="1" transparent="1" zPosition="4" />\n    <widget name="lb_poster_edge" position="56,677" size="248,365" alphatest="blend" scale="1" transparent="1" zPosition="8" />\n    <widget name="lb_live_pill" position="130,1002" size="112,26" alphatest="blend" scale="1" transparent="1" zPosition="13" />\n    <widget name="lb_live" position="130,1002" size="112,26" font="Regular;15" halign="center" valign="center" foregroundColor="#ffffff" backgroundColor="#000000" transparent="1" zPosition="14" noWrap="1" />\n    <widget name="lb_num_pill" position="332,820" size="64,36" alphatest="blend" scale="1" transparent="1" zPosition="9" />\n    <widget name="lb_num" position="332,820" size="64,36" font="Regular;20" halign="center" valign="center" foregroundColor="#e2be6e" backgroundColor="#000000" transparent="1" zPosition="10" noWrap="1" />\n    <widget name="lb_cbg_q" position="900,821" size="104,34" alphatest="blend" scale="1" transparent="1" zPosition="9" />\n    <widget name="lb_cbg_ac" position="1010,821" size="64,34" alphatest="blend" scale="1" transparent="1" zPosition="9" />\n    <widget name="lb_cbg_vc" position="1080,821" size="80,34" alphatest="blend" scale="1" transparent="1" zPosition="9" />\n    <widget name="lb_cbg_fps" position="1166,821" size="80,34" alphatest="blend" scale="1" transparent="1" zPosition="9" />\n    <widget name="lb_cbg_st" position="1252,821" size="90,34" alphatest="blend" scale="1" transparent="1" zPosition="9" />\n    <widget name="lb_cbg_eng" position="1348,821" size="180,34" alphatest="blend" scale="1" transparent="1" zPosition="9" />\n    <widget name="lb_c_q" position="900,821" size="104,34" font="Regular;18" halign="center" valign="center" foregroundColor="#dee4e8" backgroundColor="#000000" transparent="1" zPosition="10" noWrap="1" />\n    <widget name="lb_c_ac" position="1010,821" size="64,34" font="Regular;18" halign="center" valign="center" foregroundColor="#dee4e8" backgroundColor="#000000" transparent="1" zPosition="10" noWrap="1" />\n    <widget name="lb_c_vc" position="1080,821" size="80,34" font="Regular;18" halign="center" valign="center" foregroundColor="#dee4e8" backgroundColor="#000000" transparent="1" zPosition="10" noWrap="1" />\n    <widget name="lb_c_fps" position="1166,821" size="80,34" font="Regular;18" halign="center" valign="center" foregroundColor="#dee4e8" backgroundColor="#000000" transparent="1" zPosition="10" noWrap="1" />\n    <widget name="lb_c_st" position="1252,821" size="90,34" font="Regular;18" halign="center" valign="center" foregroundColor="#dee4e8" backgroundColor="#000000" transparent="1" zPosition="10" noWrap="1" />\n    <widget name="lb_c_eng" position="1348,821" size="180,34" font="Regular;18" halign="center" valign="center" foregroundColor="#dee4e8" backgroundColor="#000000" transparent="1" zPosition="10" noWrap="1" />\n    <widget name="lb_langs" position="1616,990" size="220,22" font="Regular;15" halign="center" valign="center" foregroundColor="#b9c4cc" backgroundColor="#000000" transparent="1" zPosition="10" noWrap="1" />\n    <widget name="lb_buf" pixmap="%(lbbuf)s" position="332,870" size="1240,4" borderWidth="0" transparent="1" zPosition="8" scale="0" alphatest="blend" />\n    <widget name="lb_prog" pixmap="%(lbprog)s" position="332,870" size="1240,4" borderWidth="0" transparent="1" zPosition="9" scale="0" alphatest="blend" />\n    <widget name="lb_head" pixmap="%(lbhead)s" position="332,865" size="14,14" alphatest="blend" transparent="1" zPosition="10" scale="0" />\n    <widget name="lb_now_time" position="332,886" size="170,34" font="Regular;22" halign="left" valign="center" foregroundColor="#e2be6e" backgroundColor="#000000" transparent="1" zPosition="10" noWrap="1" />\n    <widget name="lb_now_title" position="512,884" size="900,40" font="Regular;28" halign="left" valign="center" foregroundColor="#ffffff" backgroundColor="#000000" transparent="1" zPosition="10" noWrap="1" />\n    <widget name="lb_ep_name" position="512,884" size="300,40" font="Regular;28" halign="left" valign="center" foregroundColor="#e2be6e" backgroundColor="#000000" transparent="1" zPosition="10" noWrap="1" />\n    <widget name="lb_now_left" position="1430,886" size="142,34" font="Regular;20" halign="right" valign="center" foregroundColor="#c8e6d6" backgroundColor="#000000" transparent="1" zPosition="10" noWrap="1" />\n    <widget name="lb_next_time" position="332,930" size="170,32" font="Regular;20" halign="left" valign="center" foregroundColor="#8c96a0" backgroundColor="#000000" transparent="1" zPosition="10" noWrap="1" />\n    <widget name="lb_next_title" position="512,928" size="900,36" font="Regular;24" halign="left" valign="center" foregroundColor="#a9b4be" backgroundColor="#000000" transparent="1" zPosition="10" noWrap="1" />\n    <widget name="lb_next_dur" position="1430,930" size="142,32" font="Regular;20" halign="right" valign="center" foregroundColor="#8c96a0" backgroundColor="#000000" transparent="1" zPosition="10" noWrap="1" />\n</screen>\n' % {'lbbar': _asset('livebar/bar_1840x250.png'), 'lbprog': _asset('livebar/progress_1240x4.png'), 'lbbuf': _asset('livebar/buffer_1240x4.png'), 'lbhead': _asset('livebar/head_14x14.png'), 'bufpill': _asset('grid3_badge_glass_128x30.png'), 'dashred': _asset('player_keyline_red_dash_56x42.png'), 'dashgreen': _asset('player_keyline_green_dash_56x42.png'), 'dashyellow': _asset('player_keyline_yellow_dash_56x42.png'), 'dashblue': _asset('player_keyline_blue_dash_56x42.png')}

def _player_skin_new2(xml, mode='live'):
    """Player New 2: the clock moves into the right panel (bigger, centred).

    The progress line, buffer line and head dot also start with their final
    position/size for the mode, so nothing has to be resized at runtime.
    """
    dy = int(_LB_DY.get('new2', 0) + _LB2_PANEL_DROP)
    pairs = (('position="1725,819" size="110,38" font="Regular;31" halign="right"', 'position="1540,%d" size="296,86" font="Regular;62" halign="center"' % (796 + dy)), ('position="1705,859" size="130,22" font="Regular;14" halign="right"', 'position="1540,%d" size="296,26" font="Regular;18" halign="center"' % (882 + dy)))
    for old, new in pairs:
        if old in xml:
            xml = xml.replace(old, new)
    xml = xml.replace('progress_1240x4.png', 'progress_1096x4.png').replace('buffer_1240x4.png', 'buffer_1096x4.png')
    px, py, pw = (424, 940 + dy, 1020) if mode == 'live' else (356, 896 + dy, 1096)
    for name in ('lb_buf', 'lb_prog'):
        old = 'position="332,870" size="1240,4"'
        marker = '<widget name="%s" ' % name
        i = xml.find(marker)
        if i >= 0:
            j = xml.find('/>', i)
            seg = xml[i:j]
            if old in seg:
                xml = xml[:i] + seg.replace(old, 'position="%d,%d" size="%d,4"' % (px, py, pw)) + xml[j:]
    xml = xml.replace('<widget name="lb_head" pixmap="', '<widget name="lb_head" pixmap="', 1)
    i = xml.find('<widget name="lb_head" ')
    if i >= 0:
        j = xml.find('/>', i)
        seg = xml[i:j]
        xml = xml[:i] + seg.replace('position="332,865"', 'position="%d,%d"' % (px - 7, py - 5)) + xml[j:]
    return xml

def _player_skin_new(xml):
    """Player New: the clock and date follow the bar down to the Old bar's bottom level."""
    dy = int(_LB_DY.get('new', 0))
    pairs = (('position="1725,819" size="110,38" font="Regular;31" halign="right"', 'position="1616,%d" size="220,38" font="Regular;31" halign="center"' % (819 + dy)), ('position="1705,859" size="130,22" font="Regular;14" halign="right"', 'position="1616,%d" size="220,22" font="Regular;14" halign="center"' % (859 + dy)))
    for old, new in pairs:
        if old in xml:
            xml = xml.replace(old, new)
    return xml

def _player_view_variant():
    """Settings > Media > Player View as 'old' / 'new' / 'new2'."""
    try:
        value = str((load_settings() or {}).get('player_view_mode') or 'old').strip().lower()
    except Exception:
        value = 'old'
    return value if value in ('new', 'new2') else 'old'
_PLAYER_SKIN_BASE = PLAYER_SKIN
_PLAYER_SKIN_NEW_BASE = _player_skin_new(_PLAYER_SKIN_BASE)
_PLAYER_SKIN_NEW2_BASE = _player_skin_new2(_PLAYER_SKIN_BASE, 'live')
_PLAYER_SKIN_NEW2_VOD_BASE = _player_skin_new2(_PLAYER_SKIN_BASE, 'vod')
PLAYER_SKIN = _wqhd_scale_skin(_apply_player_font_scale(_PLAYER_SKIN_BASE))
PLAYER_SKIN_NEW = _wqhd_scale_skin(_apply_player_font_scale(_PLAYER_SKIN_NEW_BASE))
PLAYER_SKIN_NEW2 = _wqhd_scale_skin(_apply_player_font_scale(_PLAYER_SKIN_NEW2_BASE))
PLAYER_SKIN_NEW2_VOD = _wqhd_scale_skin(_apply_player_font_scale(_PLAYER_SKIN_NEW2_VOD_BASE))

def _front_display_geometry():
    """Return the LCD/VFD desktop size without assuming one receiver model."""
    try:
        desktop = getDesktop(1)
        size = desktop.size() if desktop is not None else None
        width = int(size.width()) if size is not None else 0
        height = int(size.height()) if size is not None else 0
        if width > 0 and height > 0:
            return (width, height)
    except Exception as exc:
        optional_failure('player.front_display_geometry', exc)
    return (132, 64)

def _front_display_time(pts):
    """Format PTS as total minutes and seconds for the front display."""
    try:
        seconds = max(0, int(pts or 0) // 90000)
    except Exception:
        seconds = 0
    return '%d:%02d' % (seconds // 60, seconds % 60)
_FRONT_BOLD_FONT_NAME = None

def _front_display_bold_font():
    """Use a real bold system face when the receiver exposes one; otherwise stay compatible."""
    global _FRONT_BOLD_FONT_NAME
    if _FRONT_BOLD_FONT_NAME:
        return _FRONT_BOLD_FONT_NAME
    try:
        from enigma import addFont as _front_add_font
    except Exception:
        _front_add_font = None
    if _front_add_font is not None:
        for font_path in ('/usr/share/fonts/nmsbd.ttf', '/usr/share/fonts/nmsbd2.ttf', '/usr/share/fonts/DejaVuSans-Bold.ttf', '/usr/share/fonts/dejavu/DejaVuSans-Bold.ttf', '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'):
            if not os.path.isfile(font_path):
                continue
            try:
                _front_add_font(font_path, 'UltraFrontBold', 100, False)
                _FRONT_BOLD_FONT_NAME = 'UltraFrontBold'
                return _FRONT_BOLD_FONT_NAME
            except TypeError:
                try:
                    _front_add_font(font_path, 'UltraFrontBold', 100)
                    _FRONT_BOLD_FONT_NAME = 'UltraFrontBold'
                    return _FRONT_BOLD_FONT_NAME
                except Exception:
                    pass
            except Exception:
                pass
    _FRONT_BOLD_FONT_NAME = 'Regular'
    return _FRONT_BOLD_FONT_NAME

def _front_display_skin(width, height):
    """Build the front-panel layout. Large TFTs mirror the receiver layout the user approved."""
    width = max(96, int(width or 132))
    height = max(48, int(height or 64))
    if width >= 300 and height >= 180:
        margin = max(10, width // 26)
        content_w = max(40, width - 2 * margin)
        title_y = max(8, height // 28)
        title_h = max(58, min(90, height // 3))
        title_font = max(24, min(44, height // 7))
        progress_h = max(9, min(18, height // 20))
        progress_y = max(title_y + title_h + 10, int(height * 0.46))
        row_y = progress_y + progress_h + max(8, height // 40)
        row_h = max(42, min(56, height // 5))
        side_font = max(33, min(43, int(float(height) / 7.0) + 2))
        side_font_name = _front_display_bold_font()
        play_w = 48
        play_h = 48
        play_x = max(margin, (width - play_w) // 2)
        play_y = row_y + max(0, (row_h - play_h) // 2)
        side_gap = max(24, width // 18)
        left_x = margin
        left_w = max(100, play_x - side_gap - left_x)
        right_x = min(width - margin, play_x + play_w + side_gap)
        right_w = max(100, width - margin - right_x)
        clock_h = max(46, min(74, height // 4))
        clock_y = min(height - clock_h - max(8, height // 28), row_y + row_h + 2)
        clock_font = max(36, min(60, height // 5 - 2))
        clock_w = max(120, min(190, width // 2))
        clock_x = max(margin, (width - clock_w) // 2)
        return '<screen name="UltraStalkerFrontSummary" position="0,0" size="%(w)d,%(h)d" backgroundColor="#000000" flags="wfNoBorder">\n            <widget name="title" position="%(m)d,%(ty)d" size="%(cw)d,%(th)d" font="Regular;%(tf)d" halign="center" valign="center" foregroundColor="#FFFFFF" backgroundColor="#000000" transparent="0" noWrap="0" />\n            <widget name="progress" position="%(m)d,%(py)d" size="%(cw)d,%(ph)d" borderWidth="1" foregroundColor="#F2F2F2" backgroundColor="#303030" />\n            <widget name="elapsed" position="%(lx)d,%(ry)d" size="%(lw)d,%(rh)d" font="%(sff)s;%(sf)d" halign="left" valign="center" foregroundColor="#7CFF9B" backgroundColor="#000000" transparent="1" noWrap="1" />\n            <widget name="play" position="%(px)d,%(ply)d" size="%(pw)d,%(phh)d" alphatest="blend" scale="1" transparent="1" />\n            <widget name="remaining" position="%(rx)d,%(ry)d" size="%(rw)d,%(rh)d" font="%(sff)s;%(sf)d" halign="right" valign="center" foregroundColor="#FFB347" backgroundColor="#000000" transparent="1" noWrap="1" />\n            <widget name="time" position="%(cx)d,%(cy)d" size="%(cww)d,%(ch)d" font="%(sff)s;%(cf)d" halign="center" valign="center" foregroundColor="#FFFFFF" backgroundColor="#000000" transparent="1" noWrap="1" />\n        </screen>' % {'w': width, 'h': height, 'm': margin, 'cw': content_w, 'ty': title_y, 'th': title_h, 'tf': title_font, 'sff': side_font_name, 'py': progress_y, 'ph': progress_h, 'ry': row_y, 'rh': row_h, 'sf': side_font, 'lx': left_x, 'lw': left_w, 'px': play_x, 'ply': play_y, 'pw': play_w, 'phh': play_h, 'rx': right_x, 'rw': right_w, 'cx': clock_x, 'cww': clock_w, 'cy': clock_y, 'ch': clock_h, 'cf': clock_font}
    margin = 3
    title_h = max(18, min(25, height // 3))
    progress_h = max(5, min(9, height // 8))
    progress_y = min(height - progress_h - 18, title_h + 6)
    progress_y = max(title_h + 2, progress_y)
    time_y = progress_y + progress_h + 2
    time_h = max(14, height - time_y - 1)
    return '<screen name="UltraStalkerFrontSummary" position="0,0" size="%(w)d,%(h)d" backgroundColor="#000000" flags="wfNoBorder">\n        <widget name="title" position="%(m)d,1" size="%(cw)d,%(th)d" font="Regular;16" halign="center" valign="center" foregroundColor="#ffffff" backgroundColor="#000000" transparent="0" noWrap="1" />\n        <widget name="progress" position="%(m)d,%(py)d" size="%(cw)d,%(ph)d" borderWidth="1" foregroundColor="#ffffff" backgroundColor="#202020" />\n        <widget name="time" position="%(m)d,%(timy)d" size="%(cw)d,%(timh)d" font="Regular;13" halign="center" valign="center" foregroundColor="#ffffff" backgroundColor="#000000" transparent="0" noWrap="1" />\n        <widget name="elapsed" position="0,0" size="1,1" font="Regular;1" foregroundColor="#000000" backgroundColor="#000000" transparent="0" />\n        <widget name="play" position="0,0" size="1,1" alphatest="blend" scale="1" transparent="1" />\n        <widget name="remaining" position="0,0" size="1,1" font="Regular;1" foregroundColor="#000000" backgroundColor="#000000" transparent="0" />\n    </screen>' % {'w': width, 'h': height, 'm': margin, 'cw': max(20, width - 2 * margin), 'th': title_h, 'py': progress_y, 'ph': progress_h, 'timy': time_y, 'timh': time_h}

class UltraStalkerFrontSummary(Screen):
    """UltraStalker-owned front-panel summary for on-demand playback."""

    def __init__(self, session, parent):
        us_func(Screen.__init__)(self, session)
        self.parent = parent
        self._display_width, self._display_height = _front_display_geometry()
        self.skin = _front_display_skin(self._display_width, self._display_height)
        self['title'] = Label(str(getattr(parent, 'name', '') or 'Ultra Stalker'))
        self['elapsed'] = Label('')
        self['play'] = Pixmap()
        self['time'] = Label('')
        self['remaining'] = Label('')
        self['progress'] = ProgressBar()
        self['progress'].setRange((0, 100))
        self['progress'].setValue(0)
        self._front_colors = {}
        self._front_last_symbol = None
        self._front_timer = eTimer()
        self._front_timer_conn = None
        try:
            self._front_timer_conn = self._front_timer.timeout.connect(self._front_tick)
        except Exception:
            try:
                self._front_timer.callback.append(self._front_tick)
            except Exception as exc:
                optional_failure('player.front_display_timer_bind', exc)
        self.onShow.append(self._front_start)
        self.onHide.append(self._front_stop)
        self.onClose.append(self._front_close)
        self._front_tick()

    def _front_start(self):
        self._front_tick()
        try:
            self._front_timer.stop()
            self._front_timer.start(1000, False)
        except Exception as exc:
            optional_failure('player.front_display_timer_start', exc)

    def _front_stop(self):
        try:
            self._front_timer.stop()
        except Exception:
            pass

    def _front_close(self):
        self._front_stop()
        try:
            if self._front_timer_conn is not None:
                self._front_timer_conn.disconnect()
                self._front_timer_conn = None
        except Exception:
            pass
        try:
            if self._front_tick in self._front_timer.callback:
                self._front_timer.callback.remove(self._front_tick)
        except Exception:
            pass

    def _front_set_color(self, widget_name, color):
        """Apply an LCD colour only when it changes; never creates extra timers."""
        try:
            widget = self[widget_name]
            instance = getattr(widget, 'instance', None)
            if instance is None or self._front_colors.get(widget_name) == color:
                return
            instance.setForegroundColor(parseColor(color))
            if widget_name in ('elapsed', 'remaining'):
                try:
                    instance.setBorderWidth(1)
                    instance.setBorderColor(parseColor(color))
                except Exception:
                    pass
            self._front_colors[widget_name] = color
        except Exception as exc:
            optional_failure('player.front_display_color', exc)

    def _front_is_paused(self):
        """Read the Player's existing seek state; do not probe or pause the service."""
        try:
            value = str(getattr(self.parent, '_last_play_state_value', '') or '')
            if value == '||':
                return True
            state = getattr(self.parent, 'seekstate', None)
            pause_state = getattr(InfoBarSeek, 'SEEK_STATE_PAUSE', None)
            return pause_state is not None and state == pause_state
        except Exception:
            return False

    @staticmethod
    def _front_mix_color(start, end, amount):
        """Blend two #RRGGBB colours for the front-panel 25% gradients."""
        try:
            amount = max(0.0, min(1.0, float(amount)))
            start = str(start or '#FFFFFF').lstrip('#')
            end = str(end or '#FFFFFF').lstrip('#')
            rgb = []
            for index in (0, 2, 4):
                a = int(start[index:index + 2], 16)
                b = int(end[index:index + 2], 16)
                rgb.append(int(round(a + (b - a) * amount)))
            return '#%02X%02X%02X' % tuple(rgb)
        except Exception:
            return str(end or '#FFFFFF')

    @classmethod
    def _front_watched_color(cls, watched_percent):
        """Green -> light green -> white -> orange -> dark red, 25% per stage."""
        try:
            percent = max(0.0, min(100.0, float(watched_percent or 0.0)))
        except Exception:
            percent = 0.0
        anchors = ((0.0, '#00B84A'), (25.0, '#79E6A1'), (50.0, '#FFFFFF'), (75.0, '#FF9F1C'), (100.0, '#D71920'))
        for index in range(len(anchors) - 1):
            start_at, start_color = anchors[index]
            end_at, end_color = anchors[index + 1]
            if percent <= end_at:
                span = max(1.0, end_at - start_at)
                return cls._front_mix_color(start_color, end_color, (percent - start_at) / span)
        return anchors[-1][1]

    @classmethod
    def _front_remaining_time_color(cls, watched_percent):
        """Right counter follows playback: green -> white -> orange -> red."""
        return cls._front_watched_color(watched_percent)

    @classmethod
    def _front_elapsed_time_color(cls, watched_percent):
        """Left counter is the exact reverse: red -> orange -> white -> green."""
        try:
            inverse = 100.0 - float(watched_percent or 0.0)
        except Exception:
            inverse = 100.0
        return cls._front_watched_color(inverse)

    @classmethod
    def _front_progress_color(cls, watched_percent, remaining_pts=None, duration_pts=None):
        """Progress bar uses the same 25% colour journey as the right counter."""
        return cls._front_watched_color(watched_percent)

    def _front_tick(self):
        try:
            self['title'].setText(str(getattr(self.parent, 'name', '') or 'Ultra Stalker'))
        except Exception as exc:
            optional_failure('player.front_display_title', exc)
        position = 0
        duration = 0
        try:
            service = self.session.nav.getCurrentService()
            seekable = service.seek() if service is not None else None
            length = seekable.getLength() if seekable is not None else None
            current = seekable.getPlayPosition() if seekable is not None else None
            if length and (not length[0]):
                duration = max(0, abs(int(length[1] or 0)))
            if current and (not current[0]):
                position = max(0, abs(int(current[1] or 0)))
            if duration and position > duration:
                position = duration
        except Exception as exc:
            optional_failure('player.front_display_seek_probe', exc)
        remaining = max(0, duration - position) if duration else 0
        try:
            watched_percent = float(position) * 100.0 / float(duration) if duration > 0 else 0.0
            watched_percent = max(0.0, min(100.0, watched_percent))
            self['progress'].setValue(int(round(watched_percent)))
            self._front_set_color('progress', self._front_progress_color(watched_percent, remaining, duration))
        except Exception as exc:
            watched_percent = 0.0
            optional_failure('player.front_display_progress', exc)
        compact = self._display_width < 300 or self._display_height < 180
        try:
            if compact:
                elapsed = _front_display_time(position)
                total = _front_display_time(duration) if duration else '--:--'
                self['elapsed'].setText('')
                self['play'].hide()
                self['time'].setText('%s / %s' % (elapsed, total))
                self['remaining'].setText('')
            else:
                paused = self._front_is_paused()
                icon_key = 'pause' if paused else 'play'
                if icon_key != self._front_last_symbol:
                    try:
                        icon_path = _asset('frontpanel_pause_red_48.png' if paused else 'frontpanel_play_green_48.png')
                        inst = getattr(self['play'], 'instance', None)
                        if inst is not None and os.path.isfile(icon_path):
                            inst.setPixmapFromFile(icon_path)
                            self['play'].show()
                            self._front_last_symbol = icon_key
                    except Exception as exc:
                        optional_failure('player.front_display_transport_icon', exc)
                self._front_set_color('title', '#FFFFFF')
                self._front_set_color('elapsed', self._front_elapsed_time_color(watched_percent))
                self._front_set_color('remaining', self._front_remaining_time_color(watched_percent))
                self._front_set_color('time', '#FFFFFF')
                self['elapsed'].setText('-%s' % _front_display_time(position))
                self['time'].setText(time.strftime('%H:%M'))
                self['remaining'].setText('+%s' % _front_display_time(remaining) if duration else '+--:--')
        except Exception as exc:
            optional_failure('player.front_display_labels', exc)
from .player_mixin_layout import PlayerLayoutMixin
from .player_mixin_chips import PlayerChipsMixin
from .player_mixin_chrome import PlayerChromeMixin
from .player_mixin_livebar import PlayerLiveBarMixin
from .player_mixin_epg import PlayerEpgMixin
from .player_mixin_subtitles import PlayerSubtitleMixin
from .player_mixin_buffer import PlayerBufferMixin
from .player_mixin_playback import PlayerPlaybackMixin
from .player_mixin_search import PlayerServerSearchMixin
from .player_mixin_zap import PlayerZapMixin
from .player_mixin_progress import PlayerProgressSeekMixin
from .player_mixin_tracks import PlayerTrackPrefsMixin

class UltraStalkerPlayer(PlayerLayoutMixin, PlayerChipsMixin, PlayerChromeMixin, PlayerLiveBarMixin, PlayerEpgMixin, PlayerSubtitleMixin, PlayerBufferMixin, PlayerPlaybackMixin, PlayerServerSearchMixin, PlayerZapMixin, PlayerProgressSeekMixin, PlayerTrackPrefsMixin, InfoBarBase, UltraInfobarVisibility, InfoBarAudioSelection, InfoBarSeek, InfoBarNotifications, InfoBarSummarySupport, InfoBarSubtitleSupport, InfoBarMoviePlayerSummarySupport, Screen):
    """Full-screen Ultra Stalker live/VOD player and InfoBar controller."""
    skin = PLAYER_SKIN
    ALLOW_SUSPEND = True
    _lb_enabled = False
    _lb_variant = 'new'
    _lb_title_full = ''
    _lb_epg_now = None
    _lb_epg_next = None
    _lb_epg_now_text = ''
    _lb_epg_next_text = ''
    _lb_epg_state = 'none'
    _lb_epg_expired = 0
    _lb_prog_value = -1
    _lb_buf_value = -1
    _lb_sc = 1.0
    _lb_vod_pos = (0, 0)
    _lb_vod_meta_cache = None

    def doEofInternal(self, playing=True):
        """Prevent Enigma2 InfoBarSeek from opening its own EOF popup or stopping playback."""
        return

    def _InfoBarSeek__evEOF(self):
        """Prevent Enigma2 InfoBarSeek.__evEOF from setting SEEK_STATE_EOF and restarting the old service."""
        return

    def createSummary(self):
        """Use UltraStalker's own LCD summary for on-demand playback."""
        media_type = str(getattr(self, 'media_type', '') or '').lower()
        if media_type in ('vod', 'movie', 'series', 'episode', 'catchup', 'trailer'):
            return UltraStalkerFrontSummary
        if media_type in ('itv', 'live'):
            try:
                from ..frontpanel_live import UltraStalkerLiveFrontSummary
                return UltraStalkerLiveFrontSummary
            except Exception as exc:
                optional_failure('player.front_display_live_summary', exc)
        try:
            create = getattr(InfoBarSummarySupport, 'createSummary', None)
            if callable(create):
                return create(self)
        except Exception as exc:
            optional_failure('player.front_display_live_fallback', exc)
        return None

    def __init__(self, session, streamurl, name, media_type='itv', servicetype=4097, item=None, reuse_current=False):
        _variant = _player_view_variant()
        if _variant == 'new':
            self.skin = _wqhd_scale_skin(_apply_player_font_scale(_PLAYER_SKIN_NEW_BASE))
        elif _variant == 'new2':
            self.skin = _wqhd_scale_skin(_apply_player_font_scale(_PLAYER_SKIN_NEW2_BASE if str(media_type or 'itv').lower() in ('itv', 'live') else _PLAYER_SKIN_NEW2_VOD_BASE))
        else:
            self.skin = _wqhd_scale_skin(_apply_player_font_scale(_PLAYER_SKIN_BASE))
        us_func(Screen.__init__)(self, session)
        self.session = session
        self._return_aspect_ratio = capture_aspect_mode(switch_cls=eAVSwitch)
        self.streamurl = str(streamurl or '').strip()
        self.media_type = str(media_type or 'itv')
        self.item = item if isinstance(item, dict) else {}
        launch_timing = self.item.get('_launch_timing')
        if isinstance(launch_timing, dict):
            runtime_breadcrumb('recent_player_launch', media_type=self.media_type, link_ms=int(launch_timing.get('link_ms') or 0), payload_ms=int(launch_timing.get('payload_ms') or 0))
        self._cfg_clean_titles = bool(load_settings().get('clean_titles', True))
        _raw_name = str(self.item.get('_raw_name') or name or 'Ultra Stalker stream')
        if self.media_type in ('itv', 'live'):
            self.name = _clean_live_name(_raw_name, self._cfg_clean_titles)
        else:
            self.name = _catalogue_title(_raw_name) or _raw_name if self._cfg_clean_titles else _raw_name.strip()
        self._return_service_ref_string = str(self.item.get('_return_service_ref_string') or '')
        self._service_handoff_done = False
        self.reuse_current = bool(reuse_current and self.media_type in ('itv', 'live'))
        _zap_snapshot = list(self.item.get('_live_folder_channels') or []) if self.media_type in ('itv', 'live') else []
        self._zap_page_loader = self.item.get('_live_page_loader') if callable(self.item.get('_live_page_loader')) else None
        try:
            self._zap_page_size = max(1, int(self.item.get('_live_page_size') or len(_zap_snapshot) or 10))
        except Exception:
            self._zap_page_size = max(1, len(_zap_snapshot) or 10)
        try:
            self._zap_total = max(len(_zap_snapshot), int(self.item.get('_live_folder_total') or 0))
        except Exception:
            self._zap_total = len(_zap_snapshot)
        try:
            self._zap_index = max(0, int(self.item.get('_live_absolute_index') or 0))
        except Exception:
            self._zap_index = 0
        try:
            _zap_page = max(1, int(self.item.get('_live_folder_page') or self._zap_index // self._zap_page_size + 1))
        except Exception:
            _zap_page = max(1, self._zap_index // self._zap_page_size + 1)
        if self.media_type in ('itv', 'live') and self._zap_total:
            self._zap_channels = [None] * self._zap_total
            _zap_base = max(0, (_zap_page - 1) * self._zap_page_size)
            for _i, _row in enumerate(_zap_snapshot):
                _pos = _zap_base + _i
                if _pos < len(self._zap_channels) and isinstance(_row, dict):
                    self._zap_channels[_pos] = _row
        else:
            self._zap_channels = _zap_snapshot
        self._zap_title = str(self.item.get('_live_folder_title') or _('Live TV'))
        self._zap_category_id = str(self.item.get('_live_category_id') or self.item.get('category_id') or self.item.get('genre_id') or '')
        self._zap_categories = self._visible_live_categories(self.item.get('_live_categories') or [])
        self._zap_pending_drawer_context = None
        self._zap_switch_context = None
        self._zap_last_ok = 0.0
        self._zap_open = False
        self._zap_infobar_armed = False
        for mixin in (InfoBarBase, UltraInfobarVisibility, InfoBarAudioSelection, InfoBarSeek, InfoBarNotifications, InfoBarSummarySupport, InfoBarSubtitleSupport, InfoBarMoviePlayerSummarySupport):
            try:
                mixin.__init__(self)
            except Exception as exc:
                LOG.warning('Player mixin init failed (%s): %s', mixin, exc)
        cfg = load_settings()
        self._cfg_resume_behavior = str(cfg.get('resume_behavior', 'always') or 'always').lower()
        self._cfg_crash_safe_progress = bool(cfg.get('crash_safe_progress', True))
        self._cfg_progress_interval_ms = (int(cfg.get('progress_save_seconds', 10)) if self._cfg_crash_safe_progress else 10) * 1000
        self._cfg_next_episode_countdown = int(cfg.get('next_episode_countdown', 10) or 10)
        self._cfg_timeout = max(8.0, float(cfg.get('timeout', 10) or 10) + 5.0)
        self._cfg_diagnostic_logging = bool(cfg.get('diagnostic_logging', False))
        self._cfg_live_zap_direction = str(cfg.get('live_zap_direction') or 'up_down')
        self._cfg_smart_recovery = bool(cfg.get('smart_recovery', True))
        self._cfg_retry_limit = max(0, min(3, int(cfg.get('playback_retry_limit', 3))))
        self._cfg_completion_threshold = max(80, min(99, int(cfg.get('completion_threshold', 93)))) / 100.0
        self._cfg_completion_remaining_pts = max(30, min(900, int(cfg.get('completion_remaining_seconds', 180)))) * 90000
        self._cfg_auto_remove_completed = bool(cfg.get('auto_remove_completed', True))
        self._cfg_remember_tracks = bool(cfg.get('remember_track_language', True))
        self._history_profile = {'portal': self.item.get('_portal', ''), 'mac': self.item.get('_mac', '')}
        self._history_item = self.item.get('_history_item') if isinstance(self.item.get('_history_item'), dict) else self.item
        try:
            self._subtitle_session_key = content_digest(self._history_profile, self.media_type, self._history_item)
        except Exception:
            self._subtitle_session_key = ''
        self._subtitle_session_restore_done = False
        self._subtitle_session_restore_pending = False
        self._subtitle_session_restore_attempts = 0
        self._subtitle_session_restore_started_at = 0.0
        self._subtitle_session_post_refresh_pending = False
        self._subtitle_session_restoring = False
        self._recent_next_future = None
        self._recent_next_cancel = threading.Event()
        self._recent_next_started = False
        self._pending_live_recent_item = None
        if self.media_type == 'trailer':
            configured_engine = 4097
        else:
            try:
                configured_engine = int(cfg.get('service_type', servicetype))
            except Exception:
                configured_engine = int(servicetype or 4097)
        configured_engine = normalize_dreamos_engine(configured_engine, self.media_type, self.streamurl)
        self._cfg_service_type = configured_engine
        self.engines = [configured_engine]
        self.engine_index = 0
        self.servicetype = configured_engine
        self._engine_locked_to_settings = True
        self.reference = None
        self._owned_reference_string = ''
        self.started = False
        self.start_attempt = 0.0
        self.failed = False
        self.restored = False
        self.resume_prompted = False
        self._resume_target = 0
        self._resume_verify_attempts = 0
        self._resume_grace_until = 0.0
        self._watch_started_at = 0.0
        self._history_save_min_seconds = 10
        self._last_manual_seek_at = 0.0
        self._manual_seek_target_pts = None
        self._manual_seek_target_at = 0.0
        self._seek_display_target = None
        self._seek_display_origin = None
        self._seek_display_until = 0.0
        self._seek_pending_target = None
        self._seek_applied_at = 0.0
        self._early_eof_pending = False
        self._startup_guard_until = 0.0
        self._startup_guard_checks = 0
        self._startup_guard_last_position = -1
        self._startup_guard_reason = ''
        self._last_progress_position = 0
        self._last_progress_duration = 0
        self._hard_stop_attempts = 0
        self._hard_stop_pending_result = None
        self._hard_stop_closing = False
        self._closing_playback = False
        self._owned_external_pids = set()
        self._external_player_baseline = set(_all_external_player_pids())
        self._resume_seek_count = 0
        self._resume_verify_cycles = 0
        self._resume_prepared = False
        self._resume_prompt_open = False
        self._native_resume_started = False
        self._resume_audio_guard = False
        self._resume_was_muted = None
        self._resume_started_at = 0.0
        self._observed_quality = ''
        self._observed_width = 0
        self._observed_height = 0
        self._static_episode_marker = None
        self._video_guard_misses = 0
        self._video_guard_last_engine = None
        self._engine_video_confirmed = False
        self._next_episode_prompted = False
        self._next_episode_cancelled = False
        self._next_episode_transitioning = False
        self._next_episode_at_eof = False
        self._next_card_open = False
        self._next_card_dialog = None
        self._next_card_live = False
        self._subtitle_user_override = False
        self._subtitle_manual_override = False
        self._subtitle_disable_attempts = 0
        self._embedded_subtitle_probe_pending = False
        self._embedded_subtitle_probe_attempts = 0
        self._embedded_subtitle_probe_started = 0.0
        self._recovery_attempts = 0
        self._recovery_inflight = False
        self._recovery_queue = queue.Queue()
        self._recovery_cancel = threading.Event()
        self._recovery_thread = None
        self._recovery_client_lock = threading.RLock()
        self._recovery_client = None
        self._auto_retry_inflight = False
        self._auto_retry_future = None
        self._auto_retry_generation = 0
        self._auto_retry_reason = ''
        self._auto_retry_min_interval = 2.0
        self._auto_retry_next_allowed_at = 0.0
        self._auto_retry_deferred_reason = ''
        self._retry_visual_hold = False
        self._retry_visual_progress_last = -1
        self._retry_visual_progress_advances = 0
        self._live_epg_generation = 0
        self._live_epg_future = None
        self._live_epg_queue = queue.Queue()
        self._live_epg_last_channel = ''
        self._runtime_reconnects = 0
        self._last_network_activity = 0.0
        self._event_suppress_until = 0.0
        self._play_generation = 0
        self._memory_fuse_level = 0
        self._memory_fuse_last_rss = 0
        self._memory_fuse_emergency = False
        self._player_infobar_visible = True
        self._zap_switch_generation = 0
        self._zap_switch_queue = queue.Queue()
        self._zap_switch_inflight = False
        self._zap_switch_started_at = 0.0
        self._zap_switch_future = None
        self._aspect_cycle_cursor = None
        runtime_breadcrumb('player_open', media_type=self.media_type, engine=int(self.servicetype or 0))
        self['buffer_status'] = Label('')
        self['buffer_pill'] = Pixmap()
        self['buffer_pill'].hide()
        self._buffer_status_color = ''
        self['resume_mask'] = Label('')
        self['connection'] = Label(_('PREPARING STREAM'))
        _current_server_profile = self._server_search_current_profile()
        try:
            _item_source = self.item if isinstance(self.item, dict) else {}
            _local_source = bool(_item_source.get('_local_media')) or str(_item_source.get('source_type') or _item_source.get('_source_type') or '').strip().lower() == 'local' or str(_item_source.get('_server_name') or '').strip().lower() == 'local'
            if _local_source:
                self._active_server_name = 'Local'
            else:
                self._active_server_name = self._player_server_label(_current_server_profile, 0) if _current_server_profile.get('portal') else ''
        except Exception:
            self._active_server_name = ''
        self['server_name'] = Label(_short_portal_label(self._active_server_name))
        self['logo'] = Pixmap()
        self['live_picon'] = Pixmap()
        self['adaptive_main'] = Pixmap()
        self['poster_neon_halo'] = Pixmap()
        self['adaptive_poster'] = Pixmap()
        self['adaptive_live_picon'] = Pixmap()
        self['adaptive_progress_track'] = Pixmap()
        self['adaptive_keybar'] = Pixmap()
        self['chip_video_quality_bg'] = Pixmap()
        self['chip_video_codec_bg'] = Pixmap()
        self['chip_audio_codec_bg'] = Pixmap()
        self['chip_video_quality'] = Pixmap()
        self['chip_video_codec'] = Pixmap()
        self['chip_audio_codec'] = Pixmap()
        self['vod_quality_badge'] = Pixmap()
        self['audio_format_badge'] = Pixmap()
        self._audio_format_badge_key = ''
        self._audio_format_badge_path = ''
        self._audio_format_badge_active = False
        self._vod_audio_badge_locked = False
        self._vod_audio_probe_active = False
        self._vod_audio_probe_generation = 0
        self._vod_audio_probe_preplay = ()
        self._vod_audio_probe_started_at = 0.0
        self._vod_audio_probe_updated_event = False
        self._vod_audio_probe_candidate = ()
        self._vod_audio_probe_candidate_count = 0
        self._vod_audio_probe_candidate_since = 0.0
        self._vod_quality_badge_locked = False
        self._vod_quality_badge_path = ''
        self._vod_quality_badge_resolution = (0, 0)
        self._vod_quality_probe_active = False
        self._vod_quality_probe_generation = 0
        self._vod_quality_probe_preplay = (0, 0)
        self._vod_quality_probe_started_at = 0.0
        self._vod_quality_probe_size_event = False
        self._vod_quality_probe_size_event_at = 0.0
        self._vod_quality_probe_updated_event = False
        self._vod_quality_probe_candidate = (0, 0)
        self._vod_quality_probe_candidate_count = 0
        self._vod_quality_probe_candidate_since = 0.0
        self['chip_fps_bg'] = Pixmap()
        self['chip_fps'] = Pixmap()
        self._fps_cache = (0.0, 0)
        self['chip_stream_bg'] = Pixmap()
        self['chip_audio_bg'] = Pixmap()
        self['chip_engine_bg'] = Pixmap()
        for _tn in ('quality', 'audio_codec', 'video_codec', 'fps', 'stream', 'audio', 'engine'):
            self['chipt_%s' % _tn] = Label('')
        self._chip_text_cache = {}
        self['chip_stream'] = Pixmap()
        self['chip_audio'] = Pixmap()
        self['chip_subtitles'] = Pixmap()
        self['chip_engine'] = Pixmap()
        self._technical_glass_paths = {}
        self._typographic_chip_paths = {}
        try:
            self['chip_subtitles'].hide()
        except Exception:
            pass
        self['channel'] = Label(self.name[:120])
        self['vod_title'] = Label(self.name[:180])
        self['episode_marker'] = Label('')
        self['episode_name'] = Label('')
        self['title_logo'] = Pixmap()
        self._player_title_logo_token = 0
        self._player_title_logo_queue = queue.Queue()
        self._player_title_logo_pending = False
        self._player_title_logo_path = ''
        self._player_title_logo_future = None
        self['now'] = Label(self._now_text())
        self._static_quality = _quality(self.item, self.name)
        self['category'] = Label(self._category_label())
        self['engine'] = Label(_engine_label(self.servicetype))
        self['extension'] = Label(_('STREAM'))
        self['quality'] = Label(_('AUTO'))
        self['retry_status'] = Label('')
        self['live_epg_now'] = Label('')
        self['live_epg_next'] = Label('')
        self['video_quality'] = Label(_(self._static_quality))
        self['video_codec'] = Label(_('VIDEO'))
        self['audio_codec'] = Label(_('AUDIO'))
        self['skip_hint'] = Label('')
        self['vod_progress'] = ProgressBar()
        self['vod_progress'].setRange((0, 100))
        self['vod_progress'].setValue(0)
        self['progress_neon'] = Pixmap()
        self._adaptive_accent_neon = '#d6dae1'
        self._progress_neon_value = -1
        self._adaptive_neon_ready = True
        self['buffer_glass'] = Pixmap()
        self._buffer_glass_path = ''
        self._buffer_glass_end = -1
        self['progress_head'] = Pixmap()
        self._laser_beam_path = ''
        self._laser_head_path = ''
        self._laser_end = -1
        self._network_rx_paths = ()
        self._network_rx_paths_refresh_at = 0.0
        self._stream_info_text_cache = {}
        self['audio_tag'] = Label(_('AUDIO'))
        self['subtitle_tag'] = Label(_('SUBTITLES'))
        try:
            self['subtitle_tag'].hide()
        except Exception:
            pass
        try:
            self._sync_typographic_technical_row()
        except Exception:
            pass
        self['online_subtitle'] = Label('')
        self._online_subtitle_cues = []
        self._online_subtitle_active = False
        self._online_subtitle_index = 0
        self._online_subtitle_path = ''
        self._online_subtitle_searching = False
        self._online_subtitle_queue = queue.Queue()
        self._online_subtitle_generation = 0
        self._online_subtitle_cancel = threading.Event()
        self._online_subtitle_future = None
        self._online_subtitle_offset_ms = 0
        self._online_subtitle_scale = 1.0
        self._online_subtitle_overlay = None
        self._online_subtitle_display = None
        self._online_subtitle_current_text = ''
        self._external_subtitle_bridge = _ExternalSubtitleProviderBridge(self)
        self._external_subtitle_ui_hold = False
        self._external_subtitle_ui_seen_foreign = False
        self._external_subtitle_ui_resume_after = False
        self._external_subtitle_ui_hold_started = 0.0
        self._last_play_state_value = '>'
        self.external_subtitle_ui_timer = eTimer()
        self.external_subtitle_ui_timer_conn = None
        try:
            self.external_subtitle_ui_timer_conn = self.external_subtitle_ui_timer.timeout.connect(self._external_subtitle_ui_watch)
        except Exception:
            self.external_subtitle_ui_timer.callback.append(self._external_subtitle_ui_watch)
        _sub_cfg = cfg
        self._subtitle_style = {'color': str(_sub_cfg.get('subtitle_color') or '#FFFFFF'), 'background': bool(_sub_cfg.get('subtitle_background', False)), 'position': max(-260, min(260, int(_sub_cfg.get('subtitle_position', 0) or 0))), 'size': max(30, min(56, int(_sub_cfg.get('subtitle_size', 38) or 38)))}
        self._media_info_open = False
        self['key_red'] = Label(_('Buffer') if self.media_type in ('vod', 'series', 'episode', 'catchup') else _('Exit'))
        self['key_green'] = Label(_('Aspect Ratio'))
        self['key_yellow'] = Label(_('Subtitles'))
        self['key_blue'] = Label(_('Search'))
        for _kc in ('red', 'green', 'yellow', 'blue'):
            self['key_dash_%s' % _kc] = Pixmap()
        self['elapsed_time'] = Label('')
        self['total_time'] = Label('')
        self['remaining_time'] = Label('')
        self._lb_init()
        self._subtitle_inline_level = ''
        self._subtitle_inline_locked = False
        self._subtitle_native_selector_hold = False
        self._subtitle_player_keymaps_suspended = False
        self._subtitle_inline_overlay = SettingsInlineChoiceOverlay(self, 'subtitle_inline_list', 'subtitle_inline_actions', _asset, _, optional_failure, action_priority=-20000)
        self._server_search_mode_active = False
        self._server_search_locked = False
        self._server_search_generation = 0
        self._server_search_cancel = threading.Event()
        self._server_search_queue = queue.Queue()
        self._server_search_future = None
        self._server_search_results = []
        self._server_search_last_index = 0
        self._server_search_owned_client = None
        self._server_search_query = ''
        self._server_search_inline_overlay = SettingsInlineChoiceOverlay(self, 'server_search_inline_list', 'server_search_inline_actions', _asset, _, optional_failure, action_priority=-21000)
        self._buffer_menu_locked = False
        self._buffer_inline_overlay = SettingsInlineChoiceOverlay(self, 'buffer_inline_list', 'buffer_inline_actions', _asset, _, optional_failure, action_priority=-20500)
        self['player_actions'] = ActionMap(['UltraStalkerPlayerActions', 'OkCancelActions', 'ColorActions', 'InfobarActions', 'NumberActions'], {'cancel': self._exit_or_close_subtitle_overlay, 'stop': self._exit_or_close_subtitle_overlay, 'red': self._player_red, 'ok': self.OKButton, 'info': self.show_media_info, 'blue': self.serverSearch, 'switchPlayer': self.toggleStreamType, 'green': self.cycleDisplayAspect, 'yellow': self.subtitleSelection, '0': self.restartStream, '1': self.seekBack10, '3': self.seekForward10, '4': self.seekBack60, '6': self.seekForward60, '7': self.seekBack300, '9': self.seekForward300, 'seekBack10Bridge': self.seekBridgeBack10, 'seekForward10Bridge': self.seekBridgeForward10}, -2)
        self['live_channel_step_actions'] = ActionMap(['DirectionActions'], {'left': lambda: self._quickZap(-1), 'right': lambda: self._quickZap(1)} if self._cfg_live_zap_direction == 'left_right' else {'up': lambda: self._quickZap(-1), 'down': lambda: self._quickZap(1)}, -1500)
        try:
            self['live_channel_step_actions'].setEnabled(self.media_type in ('itv', 'live'))
        except Exception:
            pass
        self['hard_exit_actions'] = ActionMap(['UltraStalkerPlayerActions', 'OkCancelActions'], {'cancel': self._exit_or_close_subtitle_overlay, 'stop': self._exit_or_close_subtitle_overlay}, -10000)
        self['nova_yellow_actions'] = ActionMap(['ColorActions'], {'yellow': self.subtitleSelection}, -1000)
        self['online_subtitle_actions'] = ActionMap(['InfobarSubtitleSelectionActions'], {'subtitleSelection': self.subtitleSelection}, -1200)
        self['subtitle_volume_watch_actions'] = ActionMap(['VolumeActions'], {'volumeUp': self._subtitle_volume_osd_event, 'volumeDown': self._subtitle_volume_osd_event, 'volumeMute': self._subtitle_volume_osd_event}, -1100)
        eventmap = {iPlayableService.evStart: self._service_started}
        _ev_updated = getattr(iPlayableService, 'evUpdatedInfo', None)
        if _ev_updated is not None:
            eventmap[_ev_updated] = self._native_resume_updated
        _ev_video_size = getattr(iPlayableService, 'evVideoSizeChanged', None)
        if _ev_video_size is not None:
            eventmap[_ev_video_size] = self._vod_video_size_changed
        for event_name, callback in (('evTuneFailed', self._service_failed), ('evEOF', self._service_eof), ('evStopped', self._service_stopped)):
            event_value = getattr(iPlayableService, event_name, None)
            if event_value is not None:
                eventmap[event_value] = callback
        # Preserve DreamOS buffering readiness without the field-test event tracker.
        _ev_buffering = getattr(iPlayableService, 'evBuffering', None)
        if _ev_buffering is not None:
            eventmap[_ev_buffering] = self._us_buffering_event
        self.__event_tracker = ServiceEventTracker(screen=self, eventmap=eventmap)
        try:
            self.onLayoutFinish.append(self._apply_adaptive_player_chrome)
            self.onLayoutFinish.append(self._init_online_subtitle_display)
        except Exception as exc:
            optional_failure('player.optional_guard', exc)
        self.startup_timer = eTimer()
        try:
            self.startup_timer_conn = self.startup_timer.timeout.connect(self._startup_timeout)
        except Exception:
            self.startup_timer.callback.append(self._startup_timeout)
        self.resume_timer = eTimer()
        self.resume_timer_conn = None
        try:
            self.resume_timer_conn = self.resume_timer.timeout.connect(self._reference_resume)
        except Exception:
            self.resume_timer.callback.append(self._reference_resume)
        self.resume_verify_timer = eTimer()
        try:
            self.resume_verify_timer_conn = self.resume_verify_timer.timeout.connect(self._verify_resume_position)
        except Exception:
            self.resume_verify_timer.callback.append(self._verify_resume_position)
        self.subtitle_session_restore_timer = eTimer()
        self.subtitle_session_restore_timer_conn = None
        try:
            self.subtitle_session_restore_timer_conn = self.subtitle_session_restore_timer.timeout.connect(self._subtitle_session_restore_tick)
        except Exception:
            self.subtitle_session_restore_timer.callback.append(self._subtitle_session_restore_tick)
        self.subtitle_default_timer = eTimer()
        try:
            self.subtitle_default_timer_conn = self.subtitle_default_timer.timeout.connect(self._enforce_default_subtitles_off)
        except Exception:
            self.subtitle_default_timer.callback.append(self._enforce_default_subtitles_off)
        self.embedded_subtitle_probe_timer = eTimer()
        self.embedded_subtitle_probe_timer_conn = None
        try:
            self.embedded_subtitle_probe_timer_conn = self.embedded_subtitle_probe_timer.timeout.connect(self._embedded_subtitle_probe_tick)
        except Exception:
            self.embedded_subtitle_probe_timer.callback.append(self._embedded_subtitle_probe_tick)
        self.online_subtitle_timer = eTimer()
        try:
            self.online_subtitle_timer_conn = self.online_subtitle_timer.timeout.connect(self._online_subtitle_tick)
        except Exception:
            self.online_subtitle_timer.callback.append(self._online_subtitle_tick)
        self.online_subtitle_result_timer = eTimer()
        try:
            self.online_subtitle_result_timer_conn = self.online_subtitle_result_timer.timeout.connect(self._drain_online_subtitle_result)
        except Exception:
            self.online_subtitle_result_timer.callback.append(self._drain_online_subtitle_result)
        self.subtitle_volume_restore_timer = eTimer()
        self.subtitle_volume_restore_timer_conn = None
        try:
            self.subtitle_volume_restore_timer_conn = self.subtitle_volume_restore_timer.timeout.connect(self._restore_subtitle_after_volume_osd)
        except Exception:
            self.subtitle_volume_restore_timer.callback.append(self._restore_subtitle_after_volume_osd)
        self.server_search_timer = eTimer()
        self.server_search_timer_conn = None
        try:
            self.server_search_timer_conn = self.server_search_timer.timeout.connect(self._drain_server_search_result)
        except Exception:
            self.server_search_timer.callback.append(self._drain_server_search_result)
        self._next_episode_timer = None
        self._next_episode_timer_conn = None
        if self.media_type == 'episode':
            self._next_episode_timer = eTimer()
            try:
                self._next_episode_timer_conn = self._next_episode_timer.timeout.connect(self._next_episode_watch_tick)
            except Exception:
                self._next_episode_timer.callback.append(self._next_episode_watch_tick)
        self.progress_timer = eTimer()
        try:
            self.progress_timer_conn = self.progress_timer.timeout.connect(self._periodic_progress_save)
        except Exception:
            self.progress_timer.callback.append(self._periodic_progress_save)
        self.progress_visual_timer = eTimer()
        try:
            self.progress_visual_timer_conn = self.progress_visual_timer.timeout.connect(self._update_progress_visual)
        except Exception:
            self.progress_visual_timer.callback.append(self._update_progress_visual)
        self.hard_stop_timer = eTimer()
        try:
            self.hard_stop_timer_conn = self.hard_stop_timer.timeout.connect(self._verify_hard_stop)
        except Exception:
            self.hard_stop_timer.callback.append(self._verify_hard_stop)
        self.eof_guard_timer = eTimer()
        try:
            self.eof_guard_timer_conn = self.eof_guard_timer.timeout.connect(self._verify_early_eof)
        except Exception:
            self.eof_guard_timer.callback.append(self._verify_early_eof)
        self.recovery_timer = eTimer()
        try:
            self.recovery_timer_conn = self.recovery_timer.timeout.connect(self._drain_recovery_result)
        except Exception:
            self.recovery_timer.callback.append(self._drain_recovery_result)
        self.auto_retry_delay_timer = eTimer()
        try:
            self.auto_retry_delay_timer_conn = self.auto_retry_delay_timer.timeout.connect(self._run_deferred_auto_retry)
        except Exception:
            self.auto_retry_delay_timer.callback.append(self._run_deferred_auto_retry)
        self.seek_apply_timer = eTimer()
        try:
            self.seek_apply_timer_conn = self.seek_apply_timer.timeout.connect(self._apply_pending_seek)
        except Exception:
            self.seek_apply_timer.callback.append(self._apply_pending_seek)
        self.retry_visual_success_timer = eTimer()
        try:
            self.retry_visual_success_timer_conn = self.retry_visual_success_timer.timeout.connect(self._confirm_retry_visual_success)
        except Exception:
            self.retry_visual_success_timer.callback.append(self._confirm_retry_visual_success)
        self.live_epg_timer = eTimer()
        self.live_epg_timer_conn = None
        try:
            self.live_epg_timer_conn = self.live_epg_timer.timeout.connect(self._drain_live_epg_result)
        except Exception:
            self.live_epg_timer.callback.append(self._drain_live_epg_result)
        self.zap_switch_timer = eTimer()
        try:
            self.zap_switch_timer_conn = self.zap_switch_timer.timeout.connect(self._drain_zap_switch_result)
        except Exception:
            self.zap_switch_timer.callback.append(self._drain_zap_switch_result)
        self._live_picon_fetch_generation = 0
        self._live_picon_fetch_inflight = False
        self._live_picon_fetch_future = None
        self._live_picon_fetch_cancel = threading.Event()
        self._live_picon_fetch_queue = queue.Queue()
        self.stable_timer = eTimer()
        try:
            self.stable_timer_conn = self.stable_timer.timeout.connect(self._mark_stream_stable)
        except Exception:
            self.stable_timer.callback.append(self._mark_stream_stable)
        self.PicLoad = ePicLoad()
        self.PicLoad_conn = None
        self._poster_path = None
        try:
            self.PicLoad.PictureData.get().append(self._decode_poster)
        except Exception:
            try:
                self.PicLoad_conn = self.PicLoad.PictureData.connect(self._decode_poster)
            except Exception:
                self.PicLoad_conn = None
        self.stream_info_timer = eTimer()
        self.stream_info_timer_conn = None
        try:
            self.stream_info_timer_conn = self.stream_info_timer.timeout.connect(self._update_stream_info)
        except Exception:
            self.stream_info_timer.callback.append(self._update_stream_info)
        self.vod_quality_timer = eTimer()
        self.vod_quality_timer_conn = None
        try:
            self.vod_quality_timer_conn = self.vod_quality_timer.timeout.connect(self._vod_quality_probe_tick)
        except Exception:
            self.vod_quality_timer.callback.append(self._vod_quality_probe_tick)
        self.vod_audio_timer = eTimer()
        self.vod_audio_timer_conn = None
        try:
            self.vod_audio_timer_conn = self.vod_audio_timer.timeout.connect(self._vod_audio_probe_tick)
        except Exception:
            self.vod_audio_timer.callback.append(self._vod_audio_probe_tick)
        self.player_title_logo_timer = eTimer()
        self.player_title_logo_timer_conn = None
        try:
            self.player_title_logo_timer_conn = self.player_title_logo_timer.timeout.connect(self._drain_player_title_logo)
        except Exception:
            self.player_title_logo_timer.callback.append(self._drain_player_title_logo)
        self.memory_fuse_timer = eTimer()
        self.memory_fuse_timer_conn = None
        try:
            self.memory_fuse_timer_conn = self.memory_fuse_timer.timeout.connect(self._memory_fuse_tick)
        except Exception:
            self.memory_fuse_timer.callback.append(self._memory_fuse_tick)
        try:
            self.onPlayStateChanged.append(self._play_state_changed)
        except Exception as exc:
            optional_failure('player', exc)
        self.onLayoutFinish.append(self._layout_ready)
        try:
            self.onShow.append(self._restore_player_chrome_after_show)
        except Exception as exc:
            optional_failure('player.chrome_show_hook', exc)
        try:
            self.onShow.append(self._resume_hidden_visual_timers)
            self.onHide.append(self._pause_hidden_visual_timers)
        except Exception as exc:
            optional_failure('player.visual_timer_hooks', exc)
        self.onFirstExecBegin.append(self._begin_playback)
        self.onClose.append(self._cleanup)
        self._track_pref_wanted = {}
        self._track_pref_polls = 0
        self._track_pref_audio_done = True
        self._track_pref_sub_done = True
        self._track_pref_audio_before = ''
        self._track_pref_sub_before = None
        self.track_pref_timer = eTimer()
        self.track_pref_timer_conn = None
        try:
            self.track_pref_timer_conn = self.track_pref_timer.timeout.connect(self._track_pref_tick)
        except Exception:
            self.track_pref_timer.callback.append(self._track_pref_tick)
        self.onFirstExecBegin.append(self._track_pref_begin)
        self.onClose.append(self._track_pref_stop)

    @staticmethod
    def _player_fit_title(text):
        value = str(text or '').strip()
        if not value:
            return ('', 58)
        size = UltraStalkerPlayer._player_title_font_size(value)

        def units_of(v):
            return sum((1.32 if ord(ch) > 127 else 1.0 for ch in v))
        max_units = 1180.0 / (max(18, size) * 0.57)
        if units_of(value) <= max_units:
            return (value, size)
        out = []
        used = 0.0
        budget = max(1.0, max_units - 3.0)
        for ch in value:
            u = 1.32 if ord(ch) > 127 else 1.0
            if used + u > budget:
                break
            out.append(ch)
            used += u
        fitted = ''.join(out).rstrip() + '…' if out else value[:1]
        return (fitted, size)

    def _load_live_picon(self, path):
        self._front_live_picon_path = str(path or '')
        prepared = _prepare_live_picon(path, (220, 132))
        try:
            self['logo'].hide()
            self['poster_neon_halo'].hide()
            self['adaptive_poster'].hide()
            if prepared and os.path.isfile(prepared) and (self['live_picon'].instance is not None):
                self['live_picon'].instance.setPixmapFromFile(prepared)
                self['live_picon'].show()
        except Exception as exc:
            optional_failure('player.live_picon_apply', exc)

    def _resume_bookmark(self):
        try:
            duration = sane_play_pts(self.item.get('_resume_duration') or 0)
            position = sane_play_pts(self.item.get('_resume_position') or 0, duration)
        except Exception:
            position = 0
            duration = 0
        if position < 10 * 90000:
            return 0
        if duration and (position >= duration or max(0, duration - position) <= 10 * 90000):
            return 0
        return position

    def _begin_playback(self):
        """Initialize playback and defer bookmark seeking until the service is ready.

        Ultra Stalker owns the bookmark identity and resume state. Playback starts
        first; the resume path waits for the active service to expose a usable seek
        interface before applying the stored absolute position.
        """
        self._resume_target = 0
        self._resume_seek_count = 0
        self._resume_verify_attempts = 0
        self._resume_verify_cycles = 0
        self._resume_prepared = False
        self._resume_prompt_open = False
        self._native_resume_started = False
        self._resume_failed_bookmark = 0
        self._resume_retries = 0
        behavior = self._cfg_resume_behavior
        self.resume_prompted = bool(behavior == 'start')
        if self.reuse_current:
            try:
                current = self.session.nav.getCurrentlyPlayingServiceReference()
                if current is not None:
                    self.reference = current
                    try:
                        self._owned_reference_string = current.toString()
                    except Exception:
                        self._owned_reference_string = ''
                    self.started = True
                    self.failed = False
                    self._startup_confirmed = True
                    self._watch_started_at = time.monotonic()
                    self.start_attempt = time.monotonic()
                    self._last_network_activity = time.monotonic()
                    self._runtime_reconnects = 0
                    self._recovery_attempts = 0
                    self['connection'].setText('')
                    runtime_breadcrumb('player_adopt_current', media_type=self.media_type, engine=int(self.servicetype or 0))
                    try:
                        self.stable_timer.stop()
                        self.stable_timer.start(30000, True)
                    except Exception as exc:
                        optional_failure('player.optional_guard', exc)
                    if self.media_type in ('vod', 'series', 'episode'):
                        self._reset_vod_quality_probe()
                        self._arm_vod_quality_probe()
                    try:
                        self.stream_info_timer.start(700, True)
                    except Exception as exc:
                        optional_failure('player.optional_guard', exc)
                    return
            except Exception as exc:
                optional_failure('player.adopt_current', exc)
        self.playStream(self.servicetype, self.streamurl)

    def _set_resume_audio_guard(self, enabled):
        if eDVBVolumecontrol is None:
            return
        try:
            volume = eDVBVolumecontrol.getInstance()
            if volume is None:
                return
            if enabled:
                if not self._resume_audio_guard:
                    try:
                        self._resume_was_muted = bool(volume.isMuted())
                    except Exception:
                        self._resume_was_muted = False
                    if not self._resume_was_muted:
                        volume.setMuted(True)
                    self._resume_audio_guard = True
            elif self._resume_audio_guard:
                if self._resume_was_muted is False:
                    volume.setMuted(False)
                self._resume_audio_guard = False
        except Exception as exc:
            optional_failure('player.resume_audio_guard', exc)

    def _release_resume_shield(self):
        self._resume_prepared = False
        try:
            self['resume_mask'].hide()
        except Exception as exc:
            optional_failure('player.resume_mask_hide', exc)
        self._set_resume_audio_guard(False)

    def _connect_picload(self):
        self.PicLoad_conn = None
        try:
            self.PicLoad.PictureData.get().append(self._decode_poster)
        except Exception:
            try:
                self.PicLoad_conn = self.PicLoad.PictureData.connect(self._decode_poster)
            except Exception:
                self.PicLoad_conn = None

    def _load_poster(self, path):
        """Fill the poster card exactly, using a high-quality center crop."""
        prepared = _prepare_player_poster_fill(path, (232, 349))
        self._poster_path = prepared or path
        try:
            self['live_picon'].hide()
            self['adaptive_live_picon'].hide()
        except Exception as exc:
            optional_failure('player.optional_guard', exc)
        try:
            if prepared and os.path.isfile(prepared) and (self['logo'].instance is not None):
                self['logo'].instance.setPixmapFromFile(prepared)
                self['logo'].show()
                return None
        except Exception as exc:
            optional_failure('player.poster_direct', exc)
        try:
            pw, ph = _wqhd_wh(242, 330)
            self.PicLoad.setPara([pw, ph, 1, 1, 0, 1, 'FF000000'])
            result = self.PicLoad.startDecode(self._poster_path)
            if result:
                try:
                    callbacks = self.PicLoad.PictureData.get() if self.PicLoad is not None and hasattr(self.PicLoad.PictureData, 'get') else ()
                    if self._decode_poster in callbacks:
                        callbacks.remove(self._decode_poster)
                except Exception as exc:
                    optional_failure('player.optional_guard', exc)
                try:
                    if self.PicLoad_conn is not None:
                        self.PicLoad_conn.disconnect()
                except Exception as exc:
                    optional_failure('player.optional_guard', exc)
                self.PicLoad = ePicLoad()
                self._connect_picload()
                self.PicLoad.setPara([pw, ph, 1, 1, 0, 1, 'FF000000'])
                self.PicLoad.startDecode(self._poster_path)
        except Exception:
            try:
                self['logo'].instance.setPixmapFromFile(self._poster_path)
                self['logo'].show()
            except Exception as exc:
                optional_failure('player', exc)

    def _decode_poster(self, pic_info=None):
        try:
            ptr = self.PicLoad.getData()
            if ptr is not None and self['logo'].instance:
                self['logo'].instance.setPixmap(ptr)
                self['logo'].show()
        except Exception:
            try:
                if self._poster_path:
                    self['logo'].instance.setPixmapFromFile(self._poster_path)
                    self['logo'].show()
            except Exception as exc:
                optional_failure('player', exc)

    @staticmethod
    def _video_codec_text(info):
        for pathname in ('/proc/stb/vmpeg/0/codec', '/proc/stb/vmpeg/0/vcodec'):
            try:
                if os.path.exists(pathname):
                    with open(pathname, 'r') as handle:
                        raw = handle.read().strip()
                    if raw:
                        return raw.upper().replace('HEVC', 'H.265').replace('AVC', 'H.264')[:12]
            except Exception as exc:
                optional_failure('player', exc)
        value = UltraStalkerPlayer._info_number(info, 'sVideoType', None)
        return {0: 'MPEG2', 1: 'H.264', 2: 'H.263', 3: 'VC-1', 4: 'MPEG4', 5: 'VC-1', 6: 'MPEG1', 7: 'H.265', 8: 'VP8', 9: 'VP9', 10: 'XVID', 12: 'AVS', 13: 'AVS2', 16: 'AV1'}.get(value, 'VIDEO')

    @staticmethod
    def _quality_typo_asset(label):
        blob = str(label or '').upper()
        if '4K' in blob or 'UHD' in blob:
            name = 'player_typo_quality_4k_196x46.png'
        elif 'FULL' in blob or 'FHD' in blob:
            name = 'player_typo_quality_fullhd_196x46.png'
        elif 'HD' in blob:
            name = 'player_typo_quality_hd_196x46.png'
        elif 'SD' in blob:
            name = 'player_typo_quality_sd_196x46.png'
        else:
            name = ''
        path = UltraStalkerPlayer._tech_asset(name) if name else ''
        return path

    @staticmethod
    def _audio_typo_asset(key, fallback_text=''):
        mapping = {'atmos': 'player_typo_audio_atmos_201x46.png', 'truehd': 'player_typo_audio_truehd_201x46.png', 'ddplus': 'player_typo_audio_ddplus_201x46.png', 'dd': 'player_typo_audio_dd_201x46.png', 'dtshd': 'player_typo_audio_dtshd_201x46.png', 'dts': 'player_typo_audio_dts_201x46.png', 'aac': 'player_typo_audio_aac_201x46.png', 'pcm': 'player_typo_audio_pcm_201x46.png'}
        key = str(key or '').strip().lower()
        if not key and fallback_text:
            key = UltraStalkerPlayer._audio_signature_badge_key((str(fallback_text or ''),))
        return UltraStalkerPlayer._tech_asset(mapping.get(key, 'player_typo_audio_generic_201x46.png'))

    @staticmethod
    def _video_typo_asset(value):
        raw = str(value or '').upper().replace('.', '').replace('-', '')
        raw = re.sub('[^A-Z0-9]', '', raw)
        mapping = {'MPEG2': 'player_typo_video_mpeg2_199x46.png', 'MPEG4': 'player_typo_video_mpeg4_199x46.png', 'H264': 'player_typo_video_h264_199x46.png', 'AVC': 'player_typo_video_avc_199x46.png', 'H265': 'player_typo_video_h265_199x46.png', 'HEVC': 'player_typo_video_hevc_199x46.png', 'H263': 'player_typo_video_h263_199x46.png', 'VC1': 'player_typo_video_vc1_199x46.png', 'MPEG1': 'player_typo_video_mpeg1_199x46.png', 'VP8': 'player_typo_video_vp8_199x46.png', 'VP9': 'player_typo_video_vp9_199x46.png', 'XVID': 'player_typo_video_xvid_199x46.png', 'AVS': 'player_typo_video_avs_199x46.png', 'AVS2': 'player_typo_video_avs2_199x46.png', 'AV1': 'player_typo_video_av1_199x46.png'}
        return UltraStalkerPlayer._tech_asset(mapping.get(raw, 'player_typo_video_generic_199x46.png'))

    @staticmethod
    def _engine_typo_asset(value):
        blob = str(value or '').lower()
        if 'exteplayer3' in blob or '5002' in blob:
            name = 'player_typo_engine_exteplayer3_287x46.png'
        elif 'gstplayer' in blob or '5001' in blob:
            name = 'player_typo_engine_gstplayer_287x46.png'
        elif 'gstreamer' in blob or '4097' in blob:
            name = 'player_typo_engine_gstreamer_287x46.png'
        elif 'serviceapp' in blob or '8193' in blob:
            name = 'player_typo_engine_serviceapp_287x46.png'
        elif 'native' in blob or blob.strip() == '1':
            name = 'player_typo_engine_native_287x46.png'
        else:
            name = 'player_typo_engine_generic_287x46.png'
        return UltraStalkerPlayer._tech_asset(name)
    _FPS_STEPS = (5, 6, 8, 10, 12, 15, 20, 24, 25, 30, 48, 50, 60, 72, 100, 120)

    @staticmethod
    def _fps_snap(fps):
        try:
            fps = int(fps or 0)
        except Exception:
            return 0
        if fps <= 0:
            return 0
        return min(UltraStalkerPlayer._FPS_STEPS, key=lambda v: abs(v - fps))

    @staticmethod
    def _fps_typo_asset(fps):
        v = UltraStalkerPlayer._fps_snap(fps)
        return UltraStalkerPlayer._tech_asset('player_typo_fps_%d_150x46.png' % v) if v else ''

    @staticmethod
    def _fps_text(fps):
        v = UltraStalkerPlayer._fps_snap(fps)
        return '%d FPS' % v if v else ''

    def _player_red(self):
        if self.media_type in ('vod', 'series', 'episode', 'catchup'):
            return self._open_playback_buffer_menu()
        return self.back()

    def _service_eof(self):
        if self._fallback_from_buffer():
            return
        if self.restored or self._closing_playback or getattr(self, '_auto_retry_inflight', False) or getattr(self, '_external_subtitle_ui_hold', False):
            return
        if not self._event_matches_current_reference():
            return
        if self._resume_target and time.monotonic() < self._resume_grace_until:
            try:
                self.eof_guard_timer.stop()
                self.eof_guard_timer.start(1800, True)
            except Exception as exc:
                optional_failure('player', exc)
            return
        elapsed = time.monotonic() - self.start_attempt if self.start_attempt else 999
        if self.media_type in ('vod', 'series', 'episode', 'catchup') and elapsed < 8.0:
            if not getattr(self, '_retry_visual_hold', False):
                self['connection'].setText(_('PLAYING  •  stabilizing stream') if self.started else _('CONNECTING  •  stabilizing stream'))
            self._schedule_startup_guard('transient early EOF')
            return
        if not self.started:
            self._try_next_engine('stream ended before playback started')
            return
        if self.media_type == 'trailer':
            self._close_player(save_progress=False)
            return
        if self.media_type in ('itv', 'live'):
            if self._handle_runtime_interruption('stream ended during playback'):
                return
        if self.media_type in ('vod', 'series', 'episode', 'catchup'):
            try:
                position, duration = self._service_progress_snapshot()
                position = position or int(self._last_progress_position or 0)
                duration = duration or int(self._last_progress_duration or 0)
                completed = bool(duration and (position >= int(duration * self._cfg_completion_threshold) or max(0, duration - position) <= self._cfg_completion_remaining_pts))
                if self.media_type == 'episode':
                    completed = bool(duration and position >= duration - 10 * 90000)
            except Exception:
                position = duration = 0
                completed = False
            if duration > 0 and position > 0 and (not completed):
                if self._begin_smart_recovery('unexpected EOF during playback'):
                    return
                self._final_failure('unexpected EOF during playback')
                return
            try:
                self.progress_timer.stop()
            except Exception as exc:
                optional_failure('player', exc)
            if duration <= 0 and self.media_type in ('vod', 'series', 'episode'):
                if self._begin_smart_recovery('unexpected EOF during playback'):
                    return
                self._save_history_progress(force=True)
                self._close_player(save_progress=False)
                return
            next_item = self.item.get('_next_episode_item') if self.media_type == 'episode' else None
            if self.media_type == 'episode' and getattr(self, '_next_card_live', False) and getattr(self, '_next_card_open', False):
                self._finish_next_episode(next_item)
                return
            self._save_history_progress(force=True, completed_override=True)
            self._next_episode_at_eof = True
            global NEXT_EPISODE_AUTOPLAY_SESSION
            if isinstance(next_item, dict) and next_item and NEXT_EPISODE_AUTOPLAY_SESSION and (not getattr(self, '_next_episode_cancelled', False)):
                self._next_episode_prompted = True
                if self._show_next_episode_card(dict(next_item)):
                    return
                self._close_player({'next_episode': dict(next_item)}, save_progress=False)
                return
            self._close_player(save_progress=False)

    def _next_episode_clock(self, snapshot=None):
        """Native media time only: no wall-clock countdown during playback."""
        if self.restored or self._closing_playback:
            return 'owner_close'
        if not NEXT_EPISODE_AUTOPLAY_SESSION:
            return 'disabled'
        if not self.started or self._resume_target or getattr(self, '_auto_retry_inflight', False):
            return 'reset'
        position, duration = snapshot if snapshot is not None else self._service_progress_snapshot()
        if duration <= 0 or position <= 0:
            return None
        target = getattr(self, '_manual_seek_target_pts', None)
        if target is not None and time.monotonic() - float(getattr(self, '_manual_seek_target_at', 0.0) or 0.0) < 2.5 and (abs(position - int(target)) > 2 * 90000):
            return 'reset'
        remaining = max(0.0, float(duration - position) / 90000.0)
        if remaining > 10.0:
            return 'rewind'
        return {'remaining': remaining, 'paused': self._next_episode_paused()}

    def _next_episode_watch_tick(self):
        timer = getattr(self, '_next_episode_timer', None)
        if self.restored or self._closing_playback or self.media_type != 'episode' or (not NEXT_EPISODE_AUTOPLAY_SESSION) or getattr(self, '_next_episode_cancelled', False):
            if timer is not None:
                timer.stop()
            return
        if getattr(self, '_next_card_open', False) or getattr(self, '_next_episode_transitioning', False):
            return
        if timer is not None:
            timer.start(1000, True)
        next_item = self.item.get('_next_episode_item')
        loader = self.item.get('_next_episode_loader')
        if not next_item and callable(loader):
            if not self._recent_next_started:
                self._recent_next_started = True
                try:
                    self._recent_next_future = _PLAYER_BG_EXECUTOR.submit(loader, self._recent_next_cancel)
                except Exception as exc:
                    optional_failure('player.recent_next_start', exc)
            future = self._recent_next_future
            if future is not None and (not future.done()):
                return
            if future is not None:
                self._recent_next_future = None
                try:
                    next_item = future.result()
                except Exception as exc:
                    optional_failure('player.recent_next_result', exc)
                    next_item = None
                if isinstance(next_item, dict) and next_item:
                    self.item['_next_episode_item'] = dict(next_item)
        if not isinstance(next_item, dict) or not next_item:
            if timer is not None:
                timer.stop()
            return
        current = getattr(self.session, 'current_dialog', self)
        if current is not None and current is not self:
            return
        snapshot = self._service_progress_snapshot()
        position, duration = snapshot
        target = getattr(self, '_manual_seek_target_pts', None)
        if target is not None and time.monotonic() - float(getattr(self, '_manual_seek_target_at', 0.0) or 0.0) < 2.5 and (abs(position - int(target)) > 2 * 90000):
            if timer is not None:
                timer.start(250, True)
            return
        if duration > 0 and position > 0 and (duration - position > 10 * 90000):
            delay = min(5000, max(250, int((duration - position - 10 * 90000) / 90)))
            if timer is not None:
                timer.start(delay, True)
            return
        state = self._next_episode_clock(snapshot)
        if isinstance(state, dict) and state['remaining'] > 0:
            if self._show_next_episode_card(dict(next_item), live=True):
                if timer is not None:
                    timer.stop()
            elif timer is not None:
                timer.start(250, True)

    def _show_next_episode_card(self, next_item, live=False):
        """The same overlay stays over playing video; only its clock differs."""
        if getattr(self, '_next_card_open', False):
            return True
        if getattr(self, '_next_episode_cancelled', False):
            return False
        seconds = 10 if live else max(1, int(getattr(self, '_cfg_next_episode_countdown', 10) or 10))
        item = self.item if isinstance(self.item, dict) else {}
        series = ''
        for key in ('_series_title', 'series_title', 'series_name', '_raw_series_title'):
            series = str(item.get(key) or '').strip()
            if series:
                break
        poster = str(getattr(self, '_poster_path', '') or '')
        try:
            try:
                self.hideTimer.stop()
            except Exception:
                pass
            self._us_infobar_visible = False
            try:
                self.hide()
            except Exception as exc:
                optional_failure('player.next_card_hide_bar', exc)
            self._next_card_open = True
            self._next_card_live = bool(live)
            self._next_episode_prompted = True

            def done(result=None, _item=dict(next_item)):
                self._next_card_open = False
                self._next_card_live = False
                self._next_card_dialog = None
                if result in ('rewind', 'reset', 'owner_close'):
                    if result != 'owner_close' and (not self.restored) and (not self._closing_playback):
                        timer = getattr(self, '_next_episode_timer', None)
                        if timer is not None:
                            timer.start(250, True)
                    return
                if self.restored or self._closing_playback or self._next_episode_transitioning:
                    return
                global NEXT_EPISODE_AUTOPLAY_SESSION
                if result is True:
                    self._finish_next_episode(_item)
                    return
                if result == 'session_off':
                    NEXT_EPISODE_AUTOPLAY_SESSION = False
                self._next_episode_cancelled = True
                if not live or getattr(self, '_next_episode_at_eof', False):
                    self._close_player(save_progress=False)
                else:
                    try:
                        self.doShow()
                    except Exception:
                        pass
            controls = {}
            if live:
                controls = {'stop': lambda: self._close_player(save_progress=True), 'pauseService': lambda: self._set_transport_paused(True), 'playService': lambda: self._set_transport_paused(False), 'unPauseService': lambda: self._set_transport_paused(False), 'playpauseService': lambda: self._set_transport_paused(not self._next_episode_paused()), '1': self.seekBack10, '3': self.seekForward10, '4': self.seekBack60, '6': self.seekForward60, '7': self.seekBack300, '9': self.seekForward300, 'seekBack10Bridge': self.seekBridgeBack10, 'seekForward10Bridge': self.seekBridgeForward10, 'seekBack': self.seekBack10, 'seekFwd': self.seekForward10, 'seekBackManual': self.seekBack10, 'seekFwdManual': self.seekForward10, 'seekBackDef': self.seekBack10, 'seekFwdDef': self.seekForward10}
            dialog = self.session.openWithCallback(done, UltraStalkerNextEpisodePrompt, next_item, seconds, poster, series, self._next_episode_clock if live else None, controls)
            if self._next_card_open:
                self._next_card_dialog = dialog
            return True
        except Exception as exc:
            self._next_card_open = False
            self._next_card_live = False
            self._next_card_dialog = None
            optional_failure('player.next_episode_card', exc)
            return False
    _SEEK_UNAVAILABLE_TEXT = 'SEEK UNAVAILABLE'

    def _service_progress_snapshot(self, raw=False):
        """Read one sane 90kHz PTS snapshot from the active Enigma2 service."""
        try:
            service = self.session.nav.getCurrentService()
            seek = service.seek() if service else None
            pos_result = seek.getPlayPosition() if seek else None
            len_result = seek.getLength() if seek else None
            position = sane_play_pts(pos_result[1]) if pos_result and (not pos_result[0]) else 0
            duration = sane_play_pts(len_result[1]) if len_result and (not len_result[0]) else 0
            position = sane_play_pts(position, duration)
            position = max(0, position)
            duration = max(0, duration)
            if duration and position > duration + 5 * 90000:
                position = 0
            return (position, duration)
        except Exception as exc:
            try:
                if self._cfg_diagnostic_logging:
                    optional_failure('player.progress_snapshot', exc)
            except Exception as exc:
                optional_failure('player.optional_guard', exc)
            return (0, 0)

    def _save_export_native_progress(self, force=False, completed_override=None):
        """Persist exported VOD solely in Enigma2's own ResumePoints."""
        if not self.started or not self._watch_started_at:
            return
        key = str(self.item.get('_export_native_resume_key') or '')
        if not key:
            return
        now = time.monotonic()
        if not force and now - float(getattr(self, '_export_resume_saved_at', 0.0) or 0.0) < 45.0:
            return
        position, duration = self._service_progress_snapshot()
        if position <= 0:
            position = max(0, int(getattr(self, '_last_progress_position', 0) or 0))
        if duration <= 0:
            duration = max(0, int(getattr(self, '_last_progress_duration', 0) or 0))
        if position > 0:
            self._last_progress_position = position
        if duration > 0:
            self._last_progress_duration = duration
        completed = completed_override is True or bool(duration > 0 and position >= duration - 10 * 90000)
        if not completed and position < 10 * 90000:
            return
        try:
            from ..core.export_native_resume import save_export_resume
            if save_export_resume(key, position, duration, completed):
                self._export_resume_saved_at = now
        except Exception as exc:
            optional_failure('player.export_native_resume_save', exc)

    def _save_history_progress(self, force=False, completed_override=None):
        if self._resume_target or getattr(self, '_resume_failed_bookmark', 0):
            return
        if self.media_type not in ('vod', 'series', 'episode', 'catchup'):
            return
        if bool(self.item.get('_export_native_resume', False)):
            return self._save_export_native_progress(force, completed_override)
        try:
            if not self.started or not self._watch_started_at:
                return
            elapsed = time.monotonic() - float(self._watch_started_at)
            had_resume = int(self.item.get('_resume_position') or 0) >= 10 * 90000
            if not force and (not had_resume) and (elapsed < float(self._history_save_min_seconds)):
                return
        except Exception:
            if not force:
                return
        position, duration = self._service_progress_snapshot()
        last = int(getattr(self, '_last_progress_position', 0) or 0)
        now = time.monotonic()
        buffering = getattr(self, '_buffer_job', None) is not None or str(getattr(self, 'streamurl', '') or '').startswith('http://127.0.0.1')
        if position <= 0:
            position = last
        elif buffering:
            watched_at = float(getattr(self, '_buffer_watch_at', 0.0) or 0.0)
            if last > position + 15 * 90000 and watched_at and (now - watched_at < 20.0):
                position = last
        if position > 0:
            self._buffer_watch_position = int(position)
            if position + 2 * 90000 >= last:
                self._buffer_watch_at = now
            self._last_progress_position = position
        if duration > 0:
            self._last_progress_duration = duration
        position = position or int(self._last_progress_position or 0)
        duration = duration or int(self._last_progress_duration or 0)
        try:
            known = max(int(self.item.get('_resume_duration') or 0), int(self._last_progress_duration or 0))
            if known > 5 * 60 * 90000 and duration and (duration < int(known * 0.5)):
                duration = known
        except Exception:
            pass
        try:
            existing = max(0, int(self.item.get('_resume_position') or 0))
            elapsed = max(0.0, time.monotonic() - float(self._watch_started_at or time.monotonic()))
            if duration and existing >= 45 * 90000 and (elapsed < 75.0) and (position >= int(duration * 0.95)) and (existing < int(duration * 0.85)):
                position = existing
        except Exception as exc:
            optional_failure('player.progress_eof_guard', exc)
        minimum = int(self._history_save_min_seconds * 90000)
        if position < minimum and completed_override is not True:
            return
        if duration and position > duration + 5 * 90000:
            return
        try:
            profile = self._history_profile
            history_item = self._history_item
            threshold = self._cfg_completion_threshold
            remaining_limit = self._cfg_completion_remaining_pts
            completed_by_position = bool(duration and (position >= int(duration * threshold) or max(0, duration - position) <= remaining_limit))
            completed = bool(completed_override) if completed_override is not None else bool(self._cfg_auto_remove_completed and completed_by_position)
            add_recently_played(profile, self.media_type, history_item, position, duration, completed, force=bool(force))
        except Exception as exc:
            optional_failure('player', exc)

    def _complete_service_handoff(self, restore_service=True):
        """Finish playback ownership and optionally return to the captured service."""
        self._closing_playback = True
        self._cancel_smart_recovery()
        exit_timers = ('startup_timer', 'resume_timer', 'resume_verify_timer', 'subtitle_session_restore_timer', 'subtitle_default_timer', 'progress_timer', 'progress_visual_timer', 'seek_apply_timer', 'hard_stop_timer', 'eof_guard_timer', 'recovery_timer', 'auto_retry_delay_timer', 'retry_visual_success_timer', 'zap_switch_timer', 'stable_timer', 'stream_info_timer', 'vod_quality_timer', 'memory_fuse_timer', 'hideTimer', 'lb_langs_timer')
        for name in exit_timers:
            timer = getattr(self, name, None)
            if timer is None:
                continue
            try:
                timer.stop()
            except Exception as exc:
                optional_failure('player.silent_guard', exc)
        nav = getattr(getattr(self, 'session', None), 'nav', None)
        if nav is None:
            return False
        try:
            nav.stopService()
        except Exception as exc:
            optional_failure('player.service_handoff_stop', exc)
        if True:
            try:
                force_session_silence(self.session, self.streamurl, force=True, stop_native=True, exclude_pids=self._external_player_baseline, owned_pids=self._owned_external_pids)
            except Exception as exc:
                optional_failure('player.trailer_exit_silence', exc)
            targets = set(getattr(self, '_owned_external_pids', set()) or set())
            try:
                targets.update(set(_matching_external_player_pids(self.streamurl)) - set(self._external_player_baseline))
            except Exception as exc:
                optional_failure('player.trailer_exit_match', exc)
            for pid in list(targets):
                try:
                    os.kill(int(pid), signal.SIGKILL)
                except OSError:
                    pass
                except Exception as exc:
                    optional_failure('player.trailer_exit_kill', exc)
        service_restored = False
        return_ref = str(getattr(self, '_return_service_ref_string', '') or '')
        if restore_service and return_ref:
            try:
                nav.playService(eServiceReference(return_ref))
                service_restored = True
            except Exception as exc:
                optional_failure('player.service_handoff_restore', exc)
        if restore_service:
            restore_aspect_mode(getattr(self, '_return_aspect_ratio', None), switch_cls=eAVSwitch)
        self._service_handoff_done = True
        try:
            gc.collect()
            _malloc_trim()
        except Exception as exc:
            optional_failure('player.silent_guard', exc)
        return service_restored

    def _begin_hard_stop_close(self, result):
        self._hard_stop_pending_result = result
        self._hard_stop_closing = True
        skip_restore = bool(isinstance(result, dict) and result.get('next_episode'))
        restored = self._complete_service_handoff(restore_service=not skip_restore)
        if isinstance(result, dict):
            result['service_restored'] = bool(restored)
        self._finalize_player_close()

    def _verify_hard_stop(self):
        if self._hard_stop_closing:
            self._finalize_player_close()

    def _finalize_player_close(self):
        runtime_breadcrumb('player_close', media_type=self.media_type, engine=int(self.servicetype or 0), handoff=True)
        result = self._hard_stop_pending_result or {'engine': self.servicetype, 'started': self.started, 'failed': self.failed}
        self._hard_stop_pending_result = None
        self._hard_stop_closing = False
        self.reference = None
        self.close(result)

    def _close_player(self, extra=None, save_progress=True):
        if self.restored or self._hard_stop_closing:
            return
        self._next_episode_watch_cleanup()
        try:
            self._subtitle_session_capture()
        except Exception as exc:
            optional_failure('player.subtitle_session_close_capture', exc)
        self._closing_playback = True
        if save_progress and self.media_type in ('vod', 'series', 'episode', 'catchup'):
            try:
                self._save_history_progress(force=True)
            except Exception as exc:
                optional_failure('player.close_save', exc)
        try:
            from ..core.playback_buffer import stop_buffer
            stop_buffer(getattr(self, '_buffer_job', None), keep=True)
            self._buffer_job = None
            self._buffer_pending = None
            timer = getattr(self, '_buffer_timer', None)
            if timer is not None:
                timer.stop()
        except Exception:
            pass
        result = {'engine': self.servicetype, 'started': self.started, 'failed': self.failed}
        if isinstance(extra, dict):
            result.update(extra)
        self.restored = True
        self._suppress_service_events(2.5)
        self._begin_hard_stop_close(result)

    def _exit_or_close_subtitle_overlay(self):
        """EXIT closes Player-owned inline UI before leaving playback."""
        buffer_overlay = getattr(self, '_buffer_inline_overlay', None)
        try:
            if buffer_overlay is not None and buffer_overlay.active:
                return buffer_overlay.close()
        except Exception as exc:
            optional_failure('player.buffer_menu_exit', exc)
        search_overlay = getattr(self, '_server_search_inline_overlay', None)
        try:
            if search_overlay is not None and search_overlay.active:
                return search_overlay.close()
            if getattr(self, '_server_search_mode_active', False):
                self._server_search_end_hold(hide_infobar=True)
                return True
        except Exception as exc:
            optional_failure('player.server_search_exit', exc)
        overlay = getattr(self, '_subtitle_inline_overlay', None)
        try:
            if overlay is not None and overlay.active:
                return overlay.close()
        except Exception as exc:
            optional_failure('player.subtitle_exit', exc)
        return self._close_player(save_progress=True)

    def back(self):
        self._close_player(save_progress=True)

    def _cleanup(self):
        self._next_episode_watch_cleanup()
        try:
            self._live_picon_fetch_generation += 1
            self._live_picon_fetch_inflight = False
            self._live_picon_fetch_cancel.set()
        except Exception:
            pass
        runtime_breadcrumb('player_cleanup', media_type=self.media_type, engine=int(self.servicetype or 0))
        try:
            self._closing_playback = True
            from ..core.playback_buffer import stop_buffer
            job = getattr(self, '_buffer_job', None)
            self._buffer_job = None
            self._buffer_pending = None
            if job is not None:
                stop_buffer(job, keep=True)
        except Exception as exc:
            optional_failure('player.cleanup_buffer_stop', exc)
        try:
            buffer_timer = getattr(self, '_buffer_timer', None)
            if buffer_timer is not None:
                buffer_timer.stop()
                try:
                    if self._poll_playback_buffer in buffer_timer.callback:
                        buffer_timer.callback.remove(self._poll_playback_buffer)
                except Exception:
                    pass
            buffer_conn = getattr(self, '_buffer_timer_conn', None)
            if buffer_conn is not None:
                buffer_conn.disconnect()
            self._buffer_timer_conn = None
            self._buffer_timer = None
        except Exception as exc:
            optional_failure('player.cleanup_buffer_timer', exc)
        try:
            self._external_subtitle_ui_hold_end()
        except Exception:
            pass
        try:
            self._external_subtitle_stop()
        except Exception as exc:
            optional_failure('player.external_subtitle_cleanup', exc)
        try:
            self._player_title_logo_token += 1
            self._player_title_logo_pending = False
        except Exception:
            pass
        try:
            self._online_subtitle_generation += 1
            self._online_subtitle_cancel.set()
        except Exception:
            pass
        try:
            self._server_search_generation += 1
            self._server_search_cancel.set()
        except Exception:
            pass
        try:
            while True:
                self._live_picon_fetch_queue.get_nowait()
        except queue.Empty:
            pass
        except Exception:
            pass
        try:
            owned = getattr(self, '_server_search_owned_client', None)
            if owned is not None:
                owned.close()
            self._server_search_owned_client = None
        except Exception:
            pass
        try:
            self._zap_switch_generation += 1
            self._zap_switch_inflight = False
            self._zap_switch_started_at = 0.0
        except Exception:
            pass
        for future_name in ('_player_title_logo_future', '_live_picon_fetch_future', '_online_subtitle_future', '_zap_switch_future', '_auto_retry_future', '_live_epg_future', '_server_search_future'):
            future = getattr(self, future_name, None)
            if future is not None:
                try:
                    future.cancel()
                except Exception as exc:
                    optional_failure('player.future_cancel', exc)
            try:
                setattr(self, future_name, None)
            except Exception:
                pass
        try:
            pending = getattr(self, '_chrome_build_future', None)
            self._chrome_build_token = int(getattr(self, '_chrome_build_token', 0) or 0) + 1
            self._chrome_build_future = None
            if pending:
                pending[2].cancel()
        except Exception as exc:
            optional_failure('player.chrome_future_cancel', exc)
        try:
            self._release_resume_shield()
        except Exception as exc:
            optional_failure('player.resume_cleanup', exc)
        if not getattr(self, '_service_handoff_done', False):
            try:
                force_session_silence(self.session, self.streamurl, force=True, stop_native=True, exclude_pids=self._external_player_baseline, owned_pids=self._owned_external_pids)
            except Exception as exc:
                optional_failure('player.cleanup_hard_stop', exc)
        for timer_name in ('startup_timer', 'resume_timer', 'resume_verify_timer', 'subtitle_session_restore_timer', 'subtitle_default_timer', 'embedded_subtitle_probe_timer', 'online_subtitle_timer', 'online_subtitle_result_timer', 'subtitle_volume_restore_timer', 'external_subtitle_ui_timer', 'server_search_timer', 'progress_timer', 'progress_visual_timer', 'seek_apply_timer', 'hard_stop_timer', 'eof_guard_timer', 'recovery_timer', 'auto_retry_delay_timer', 'retry_visual_success_timer', 'live_epg_timer', 'zap_switch_timer', 'stable_timer', 'stream_info_timer', 'vod_quality_timer', 'vod_audio_timer', 'player_title_logo_timer', 'memory_fuse_timer', 'hideTimer', '_chrome_build_timer', 'lb_langs_timer', 'track_pref_timer', '_next_episode_timer'):
            timer = getattr(self, timer_name, None)
            if timer is not None:
                try:
                    timer.stop()
                except Exception as exc:
                    optional_failure('player', exc)
        for conn_name in ('startup_timer_conn', 'resume_timer_conn', 'resume_verify_timer_conn', 'subtitle_session_restore_timer_conn', 'subtitle_default_timer_conn', 'embedded_subtitle_probe_timer_conn', 'online_subtitle_timer_conn', 'online_subtitle_result_timer_conn', 'subtitle_volume_restore_timer_conn', 'external_subtitle_ui_timer_conn', 'server_search_timer_conn', 'progress_timer_conn', 'progress_visual_timer_conn', 'seek_apply_timer_conn', 'hard_stop_timer_conn', 'eof_guard_timer_conn', 'recovery_timer_conn', 'auto_retry_delay_timer_conn', 'retry_visual_success_timer_conn', 'live_epg_timer_conn', 'zap_switch_timer_conn', 'stable_timer_conn', 'stream_info_timer_conn', 'vod_quality_timer_conn', 'vod_audio_timer_conn', 'player_title_logo_timer_conn', 'memory_fuse_timer_conn', 'PicLoad_conn', 'hideTimer_conn', '_chrome_build_timer_conn', 'lb_langs_conn', 'track_pref_timer_conn', '_next_episode_timer_conn'):
            conn = getattr(self, conn_name, None)
            if conn is not None:
                try:
                    conn.disconnect()
                except Exception as exc:
                    optional_failure('player', exc)
                try:
                    setattr(self, conn_name, None)
                except Exception:
                    pass
        callback_map = (('startup_timer', self._startup_timeout), ('resume_timer', self._reference_resume), ('resume_verify_timer', self._verify_resume_position), ('subtitle_session_restore_timer', self._subtitle_session_restore_tick), ('subtitle_default_timer', self._enforce_default_subtitles_off), ('embedded_subtitle_probe_timer', self._embedded_subtitle_probe_tick), ('online_subtitle_timer', self._online_subtitle_tick), ('online_subtitle_result_timer', self._drain_online_subtitle_result), ('subtitle_volume_restore_timer', self._restore_subtitle_after_volume_osd), ('external_subtitle_ui_timer', self._external_subtitle_ui_watch), ('server_search_timer', self._drain_server_search_result), ('progress_timer', self._periodic_progress_save), ('progress_visual_timer', self._update_progress_visual), ('hard_stop_timer', self._verify_hard_stop), ('eof_guard_timer', self._verify_early_eof), ('recovery_timer', self._drain_recovery_result), ('auto_retry_delay_timer', self._run_deferred_auto_retry), ('retry_visual_success_timer', self._confirm_retry_visual_success), ('seek_apply_timer', self._apply_pending_seek), ('live_epg_timer', self._drain_live_epg_result), ('zap_switch_timer', self._drain_zap_switch_result), ('stable_timer', self._mark_stream_stable), ('stream_info_timer', self._update_stream_info), ('vod_quality_timer', self._vod_quality_probe_tick), ('vod_audio_timer', self._vod_audio_probe_tick), ('player_title_logo_timer', self._drain_player_title_logo), ('memory_fuse_timer', self._memory_fuse_tick), ('hideTimer', self.doTimerHide), ('_chrome_build_timer', self._poll_adaptive_player_chrome), ('lb_langs_timer', self._lb_langs_update), ('track_pref_timer', self._track_pref_tick), ('_next_episode_timer', self._next_episode_watch_tick))
        for timer_name, callback in callback_map:
            timer = getattr(self, timer_name, None)
            if timer is None:
                continue
            try:
                if callback in timer.callback:
                    timer.callback.remove(callback)
            except Exception as exc:
                optional_failure('player.timer_callback_remove', exc)
        try:
            callbacks = self.PicLoad.PictureData.get() if self.PicLoad is not None and hasattr(self.PicLoad.PictureData, 'get') else ()
            if self._decode_poster in callbacks:
                callbacks.remove(self._decode_poster)
            self.PicLoad = None
        except Exception as exc:
            optional_failure('player.picload_callback_remove', exc)
        try:
            if self._play_state_changed in self.onPlayStateChanged:
                self.onPlayStateChanged.remove(self._play_state_changed)
        except Exception as exc:
            optional_failure('player.playstate_callback_remove', exc)
        for hooks, callback, label in ((getattr(self, 'onShow', None), self._restore_player_chrome_after_show, 'player.show_chrome_hook_remove'), (getattr(self, 'onShow', None), self._resume_hidden_visual_timers, 'player.show_timer_hook_remove'), (getattr(self, 'onHide', None), self._pause_hidden_visual_timers, 'player.hide_timer_hook_remove')):
            try:
                if hooks is not None and callback in hooks:
                    hooks.remove(callback)
            except Exception as exc:
                optional_failure(label, exc)
        try:
            if self._online_subtitle_display is not None:
                self._online_subtitle_display.hideScreen()
                deleter = getattr(self.session, 'deleteDialog', None)
                if callable(deleter):
                    deleter(self._online_subtitle_display)
                self._online_subtitle_display = None
        except Exception as exc:
            optional_failure('player.native_online_subtitle_cleanup', exc)
        for widget_name in ('logo', 'live_picon', 'adaptive_main', 'adaptive_poster', 'adaptive_live_picon', 'title_logo', 'vod_quality_badge', 'audio_format_badge', 'progress_neon', 'progress_head', 'chip_video_quality_bg', 'chip_audio_codec_bg', 'chip_video_codec_bg', 'chip_fps_bg', 'chip_stream_bg', 'chip_audio_bg', 'chip_engine_bg', 'chip_video_quality', 'chip_audio_codec', 'chip_video_codec', 'chip_fps', 'chip_stream', 'chip_audio', 'chip_engine') + _LB_PIXMAPS:
            try:
                widget = self[widget_name]
                if widget.instance is not None:
                    widget.instance.setPixmap(None)
            except Exception as exc:
                optional_failure('player.optional_guard', exc)
    _BUFFER_GOOD = '#a2e1c6'
    _BUFFER_WARN = '#f4d27a'
    _BUFFER_BAD = '#ff9c9c'
    _BUFFER_IDLE = '#c9d4d2'

    def _service_stopped(self):
        """Recover when DreamOS gstplayer stops the pipeline during startup.

        evStopped is not evEOF. The dm900 report emitted it 0.5s after play
        with current_is_ours already true, then published a garbage PTS. If a
        picture or a sane clock shows up, the startup guard keeps this engine.
        If the pipeline stays dead, the same guard refreshes the link.
        """
        if self.restored or self._closing_playback or getattr(self, '_auto_retry_inflight', False):
            return
        if getattr(self, '_external_subtitle_ui_hold', False) or getattr(self, '_subtitle_native_selector_hold', False):
            return
        if not self._event_matches_current_reference():
            return
        elapsed = time.monotonic() - self.start_attempt if self.start_attempt else 999
        if elapsed < 8.0 or _us_env.IS_DREAMOS:
            self._schedule_startup_guard('playback stopped' if elapsed >= 8.0 else 'pipeline stopped during startup')
            return
        if self.started and self.media_type in ('itv', 'live', 'vod', 'series', 'episode', 'catchup'):
            self._handle_runtime_interruption('playback stopped')

    def _us_buffering_event(self):
        self._us_last_buffering = time.monotonic()

    def _us_poster_fallback(self, artwork):
        """No HDD poster cache (receiver without HDD): fetch the poster URL the
        catalogue already attached and keep a small copy in /tmp."""
        try:
            if artwork and os.path.isfile(str(artwork)) and (not os.path.basename(str(artwork)).startswith('grid_placeholder_')):
                return
            url = str(self.item.get('_player_poster_url') or '')
            if not url.lower().startswith(('http://', 'https://')):
                return
            trusted = []
            for base in (str(self.item.get('_art_base') or ''), str(self.item.get('_portal') or '')):
                try:
                    parts = urllib.parse.urlsplit(base)
                    if parts.scheme.lower() in ('http', 'https') and parts.hostname:
                        port = parts.port or (443 if parts.scheme.lower() == 'https' else 80)
                        trusted.append('%s://%s:%d' % (parts.scheme.lower(), parts.hostname, port))
                except Exception:
                    pass

            def worker():
                path = _us_fetch_tmp_poster(url, tuple(trusted))
                if path:
                    try:
                        from twisted.internet import reactor
                        reactor.callFromThread(self._us_poster_ready, path)
                    except Exception as exc:
                        optional_failure('player.poster_fallback_deliver', exc)
            thread = threading.Thread(target=worker, name='ultrastalker-player-poster')
            thread.daemon = True
            thread.start()
        except Exception as exc:
            optional_failure('player.poster_fallback', exc)

    def _us_poster_ready(self, path):
        if '_poster_path' not in self.__dict__ or self.restored:
            return
        current = str(self._poster_path or '')
        if current and os.path.isfile(current) and (not os.path.basename(current).startswith('grid_placeholder_')):
            return
        self._load_poster(path)
        try:
            self._live_bar_apply(force=True)
        except Exception as exc:
            optional_failure('player.poster_fallback_bar', exc)
