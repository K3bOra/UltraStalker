# -*- coding: utf-8 -*-
"""Category tools/manage menus, scrim and tool selection.

Methods moved verbatim out of ``PortalBrowserScreen`` (ui_screens_browser.py); behaviour is unchanged.
This module is imported by ui_screens_browser.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, max
from .ui_screens_browser import (
    LFT_ACTIONS,
    _,
    _profile_hidden_ids,
    lft_menu_choices,
    os,
)


class BrowserMenusMixin(object):
    """Category tools/manage menus, scrim and tool selection."""

    def _category_tools_choices(self):
        choices=[]
        if self.media_type=="itv":choices.append((_("Export current Live folder to TV"),"export_live_folder"))
        elif self.media_type=="vod":
            choices.append((_("Export current Movies folder to TV"),"export_media_folder"))
            choices.append((_("Add current Movies folder to a Bouquet"),"add_media_folder"))
        elif self.media_type=="series":
            choices.append((_("Export current Series folder to TV"),"export_media_folder"))
            choices.append((_("Add current Series folder to a Bouquet"),"add_media_folder"))
        if self.media_type in ("itv","vod","series"):
            choices.append((_("Export current category to M3U"),"export_category_m3u"))
            choices.append((_("Manage Categories"),"manage_categories"))
        if len(_profile_hidden_ids(load_settings(),self.profile,self.media_type)):
            choices.append((_("Show all categories"),"show_all_categories"))
        choices += [
            (_("Protect / unprotect category with PIN"),"protect_category"),
            (_("Hide / unhide current category"),"hide_category"),
            (_("Portal settings"),"settings"),
            (_("Favorites"),"favorites"),
        ]
        return choices

    def _category_manage_choices(self):
        return [
            (_("Select Categories"),"category_select_mode"),
            (_("Keep selected only"),"category_keep_selected"),
            (_("Hide selected"),"category_hide_selected"),
            (_("Show all categories"),"show_all_categories"),
            (_("Clear selection"),"category_clear_selection"),
            (_("Cancel category selection"),"category_cancel_selection"),
        ]

    def _category_menu_scrim_show(self):
        if str(getattr(self,"media_type","") or "").lower() not in ("itv","vod","series"):
            return
        try:
            path=asset("us88_focus_dim_scrim.png")
            if path and os.path.isfile(path) and self["category_menu_scrim"].instance is not None:
                self["category_menu_scrim"].instance.setPixmapFromFile(path)
            self["category_menu_scrim"].show()
        except Exception as exc:optional_failure("ui.category_menu_scrim_show",exc)

    def _category_menu_scrim_hide(self):
        try:self["category_menu_scrim"].hide()
        except Exception as exc:optional_failure("ui.category_menu_scrim_hide",exc)

    def _category_menu_show(self,choices,level="root",selection=0,parent=None):
        self._category_menu_active=True;self._category_menu_level=str(level or "root");self._category_menu_parent=parent;self._category_menu_choices=list(choices or [])
        media = str(getattr(self, "media_type", "") or "").lower()
        if media in ("itv","vod","series"):
            self._category_menu_scrim_show()
        if media in ("itv", "vod", "series"):
            self._category_menu_overlay.show(
                self._category_menu_choices,selection=selection,right=1868,region_top=80,region_h=900,
                on_accept=self._category_menu_choice_accepted,on_close=self._category_menu_back_from_overlay,
                min_card_w=320,max_card_w=760,padding=56,anchor_bottom=990,
                visual_style="text_only",row_h=66,max_visible=5)
        else:
            self._category_menu_overlay.show(
                self._category_menu_choices,selection=selection,right=1860,region_top=520,region_h=400,
                on_accept=self._category_menu_choice_accepted,on_close=self._category_menu_back_from_overlay,
                min_card_w=240,max_card_w=460,padding=44,anchor_bottom=1068)

    def _category_menu_close(self):
        self._category_menu_active=False;self._category_menu_level=None;self._category_menu_parent=None;self._category_menu_choices=[]
        try:self._category_menu_overlay.hide()
        except Exception as exc:optional_failure("ui.category_inline_menu_close",exc)
        self._category_menu_scrim_hide()

    def _category_menu_back_from_overlay(self):
        if not getattr(self,"_category_menu_active",False):return
        if self._category_menu_level=="manage" and self._category_menu_parent=="root":
            choices=self._category_tools_choices();idx=0
            for i,c in enumerate(choices):
                if len(c)>1 and c[1]=="manage_categories":idx=i;break
            self._category_menu_show(choices,"root",idx,None)
        else:
            self._category_menu_active=False;self._category_menu_level=None;self._category_menu_parent=None;self._category_menu_choices=[]
            self._category_menu_scrim_hide()

    def _category_menu_back(self):
        if not getattr(self,"_category_menu_active",False):return False
        try:self._category_menu_overlay.close()
        except Exception as exc:optional_failure("ui.category_inline_menu_back",exc)
        return True

    def _category_menu_choice_accepted(self,choice):
        if not choice:
            self._category_menu_active=False;self._category_menu_scrim_hide();return
        action=choice[1] if isinstance(choice,(tuple,list)) and len(choice)>1 else None
        if action=="manage_categories":
            self._category_menu_show(self._category_manage_choices(),"manage",0,"root");return
        self._category_menu_active=False
        self._category_menu_scrim_hide()
        if action=="category_select_mode":
            self._start_category_selection(reset=not bool(getattr(self,"_category_select_mode",False)));return
        self._tool_selected(choice)

    def _category_menu_accept(self):
        if not getattr(self,"_category_menu_active",False):return False
        try:return self._category_menu_overlay.accept()
        except Exception as exc:optional_failure("ui.category_inline_menu_accept",exc);return True

    def open_tools(self):
        if self.level=="items" and self.media_type=="itv" and getattr(self,"_bouquet_select_mode",False):
            choices=[
                (_("Add selected channels to Bouquet"),"bouquet_add_selected"),
                (_("Select all visible channels"),"bouquet_select_all"),
                (_("Clear channel selection"),"bouquet_clear_selection"),
                (_("Cancel channel selection"),"bouquet_cancel_selection"),
            ]
            self.session.openWithCallback(self._tool_selected,ChoiceBox,title=_("Bouquet channel selection"),list=choices);return
        if self.level=="genres":
            if getattr(self,"_category_menu_active",False):
                self._category_menu_close();return
            if getattr(self,"_category_select_mode",False):
                self._category_menu_show(self._category_manage_choices(),"manage",0,None);return
            self._category_menu_show(self._category_tools_choices(),"root",0,None);return
        if self.level == "items":
            choices = [(_("Global Search"), "global_search"), (_("EPG for selected channel"), "epg"), (_("Search current list"), "search")]
            if self.media_type in ("itv", "vod", "series"):
                choices += [((_('Send selected to Receiver') if self.media_type != "series" else _('Send selected Series to Receiver')), "send_receiver")]
            if self.media_type=="itv":
                choices += [
                    (_("Add this channel to Bouquet"),"bouquet_add_one"),
                    (_("Select channels for Bouquet"),"bouquet_select_mode"),
                ] + lft_menu_choices()
            if self.media_type == "vod" and self.content_items:
                try: current_state=self._content_state_cache.get(id(self.content_items[self["list"].getSelectedIndex()]),{})
                except Exception: current_state={}
                choices += [(_("Mark selected unwatched"), "mark_current_unwatched")] if current_state.get("completed") else [(_("Mark selected watched"), "mark_current_watched")]
            if self._home_entry and self.initial_action == "recent":
                choices += [(_("Mark selected watched"), "mark_watched"), (_("Mark selected unwatched"), "mark_unwatched"), (_("Remove selected from Continue Watching"), "remove_history"), (_("Clear Continue Watching"), "clear_history")]
            choices += [(_("Hide / unhide current category"), "hide_category"), (_("Audio tracks"), "audio"), (_("Subtitles"), "subtitles"), (_("Next page"), "next"), (_("Previous page"), "prev"), (_("Portal settings"), "settings"), (_("Favorites"), "favorites")]
        else:
            choices = [(_("Global Search"), "global_search"), (_("Portal settings"), "settings"), (_("Favorites"), "favorites"), (_("Recently played"), "recent")]
        self.session.openWithCallback(self._tool_selected, ChoiceBox, title=_("Portal tools"), list=choices)

    def _tool_selected(self, choice):
        if not choice:
            return
        action = choice[1]
        if action in LFT_ACTIONS: self._lft_dispatch(action)
        elif action == "global_search": self.open_global_search()
        elif action == "search": self.open_search()
        elif action == "export_live_folder": self.export_current_live_folder()
        elif action == "export_media_folder": self.export_current_media_folder()
        elif action == "add_media_folder": self.add_media_folder_to_bouquet()
        elif action == "export_category_m3u": self.export_current_category_m3u()
        elif action == "send_receiver": self.send_selected_to_receiver()
        elif action == "bouquet_add_one": self.add_current_channel_to_bouquet()
        elif action == "bouquet_select_mode": self._start_bouquet_channel_selection()
        elif action == "bouquet_add_selected": self.add_selected_channels_to_bouquet()
        elif action == "bouquet_select_all": self._select_all_visible_bouquet_channels()
        elif action == "bouquet_clear_selection": self._clear_bouquet_channel_selection()
        elif action == "bouquet_cancel_selection": self._cancel_bouquet_channel_selection()
        elif action == "pin_category": self.toggle_current_category_pinned()
        elif action == "protect_category": self.toggle_current_category_protected()
        elif action == "hide_category": self.toggle_current_category_hidden()
        elif action == "manage_categories": self._start_category_selection()
        elif action == "category_select_mode": self._start_category_selection(reset=not bool(getattr(self,"_category_select_mode",False)))
        elif action == "show_all_categories": self._show_all_categories()
        elif action == "category_keep_selected": self._keep_selected_categories_only()
        elif action == "category_hide_selected": self._hide_selected_categories()
        elif action == "category_select_all": self._select_all_visible_categories()
        elif action == "category_clear_selection": self._clear_category_selection()
        elif action == "category_cancel_selection": self._cancel_category_selection()
        elif action == "audio": self.open_audio()
        elif action == "subtitles": self.open_subtitles()
        elif action == "epg": self.show_selected_epg()
        elif action == "favorites": self._show_saved_entries(load_favorites(), "Favorites")
        elif action == "recent": self._show_saved_entries(load_continue_watching(), "Continue Watching")
        elif action == "next" and self.level == "items": self.load_items(self.media_type, self.genre, self.page + 1)
        elif action == "prev" and self.level == "items": self.load_items(self.media_type, self.genre, max(1, self.page - 1))
        elif action == "settings": self.open_playback_settings()
        elif action in ("mark_watched","mark_unwatched","remove_history"):
            self._history_action(action)
        elif action in ("mark_current_watched","mark_current_unwatched"):
            idx=self["list"].getSelectedIndex()
            if 0<=idx<len(self.content_items):
                item=self.content_items[idx];watched=action=="mark_current_watched";mark_watched(self.profile,self.media_type,item,watched);self._render_content_rows(keep_index=idx);self["status"].setText(_("Marked watched") if watched else _("Marked unwatched"))
        elif action == "clear_history":
            self.session.openWithCallback(self._clear_history_confirmed,MessageBox,_("Clear Continue Watching for this portal?"),MessageBox.TYPE_YESNO)
