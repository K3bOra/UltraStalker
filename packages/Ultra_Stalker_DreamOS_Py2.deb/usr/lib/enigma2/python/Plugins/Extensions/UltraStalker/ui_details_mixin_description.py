# -*- coding: utf-8 -*-
"""Poster decode and description paging, scrolling and source authority.

Methods moved verbatim out of ``ContentDetailsScreen`` (ui_screens_details.py); behaviour is unchanged.
This module is imported by ui_screens_details.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, us_func
from .ui_screens_details import (
    ImageLoaderMixin,
    _,
    _strip_arabic_tashkeel,
    _visual_source_fingerprint,
    diagnostic_failure,
    os,
    reactor,
    weakref,
)

from .log import optional_failure


class DetailsDescriptionMixin(object):
    """Poster decode and description paging, scrolling and source authority."""

    def _decode_picture(self, path):
        """Paint the canonical poster immediately; prepare the square-corner crop later.

        R180 called Pillow synchronously here, which could freeze Enigma2 for
        seconds on the first uncached Search result. R181 never does image
        resampling on the GUI thread.
        """
        source=str(path or "")
        if not source:
            return
        # A source that already has its finished 352x552 derivative is shown ONLY
        # through that derivative. Painting the raw source over it (and then the
        # derivative again) is what made the poster grow, shrink and grow again
        # every time a later event re-requested the same source.
        prepared_now=self._known_detail_cover(source)
        if prepared_now:
            self._show_detail_cover(prepared_now,source)
            return
        us_func(ImageLoaderMixin._decode_picture)(self,source)
        try:
            if not os.path.isfile(source) or source.endswith(".png") and "detailcover_" in os.path.basename(source):
                return
            self._poster_prepare_token=int(getattr(self,"_poster_prepare_token",0) or 0)+1
            token=self._poster_prepare_token;screen_ref=weakref.ref(self)
            def worker():
                owner=screen_ref()
                if owner is None or owner._screen_closed:return ""
                try:return str(_detail_cover_artwork(source,(352,552)) or "")
                except Exception as exc:
                    optional_failure("ui.detail_cover_async",exc);return ""
            future=_IMAGE_EXECUTOR.submit(worker)
            self._track_details_future(future)
            def done(_f):
                try:prepared=str(_f.result() or "")
                except Exception:prepared=""
                if not prepared or prepared==source:return
                owner=screen_ref()
                if owner is None:return
                try:reactor.callFromThread(owner._apply_prepared_poster,prepared,source,token)
                except Exception:pass
            try:future.add_done_callback(done)
            except Exception:pass
        except Exception as exc:
            optional_failure("ui.detail_cover_async_submit",exc)

    def _known_detail_cover(self, source):
        """Finished Details derivative of ``source`` (memo, then disk lookup) or ""."""
        try:
            if not source or not os.path.isfile(source):return ""
            if os.path.basename(source).startswith("detailcover_"):return ""
            memo=self.__dict__.setdefault("_detail_cover_memo",{})
            hit=memo.get(source)
            if hit and os.path.isfile(hit):return hit
            from .detail_poster import cached_cover_path
            found=cached_cover_path(source)
            if found:memo[source]=found
            return found
        except Exception as exc:
            optional_failure("ui.detail_cover_lookup",exc);return ""

    def _show_detail_cover(self, prepared, source):
        """Paint (or keep) the finished derivative; a no-op when it is already shown."""
        try:
            self._poster_prepare_token=int(getattr(self,"_poster_prepare_token",0) or 0)+1
            self._details_visual_state["poster"]=str(source)
            self._details_visual_state["detail_poster"]=str(prepared)
            self._details_visual_state["detail_poster_source_fp"]=_visual_source_fingerprint(source)
            self._persistent_detail_poster_locked=True
            us_func(ImageLoaderMixin._decode_picture)(self,str(prepared))
        except Exception as exc:optional_failure("ui.detail_cover_show",exc)

    def _apply_prepared_poster(self, prepared, source, token):
        try:
            if self._screen_closed or int(token)!=int(getattr(self,"_poster_prepare_token",0) or 0):return
            if not prepared or not os.path.isfile(str(prepared)):return
            current=str(getattr(self,"_image_displayed_path","") or getattr(self,"_image_pending_path","") or "")
            if current and current not in (str(source),str(prepared)):
                return
            # Persist the exact rectangular Details derivative, bound to its canonical
            # source fingerprint. Next open paints the finished poster immediately
            # with the same square corners and widget size after refresh.
            self._details_visual_state["poster"]=str(source)
            self._details_visual_state["detail_poster"]=str(prepared)
            self._details_visual_state["detail_poster_source_fp"]=_visual_source_fingerprint(source)
            self._persistent_detail_poster_locked=True
            self._persist_visual_bundle_async(self._details_visual_state,(getattr(self,"_tmdb_data",None) or getattr(self,"_local_detail_cache",None)))
            self.__dict__.setdefault("_detail_cover_memo",{})[str(source)]=str(prepared)
            us_func(ImageLoaderMixin._decode_picture)(self,str(prepared))
        except Exception as exc:optional_failure("ui.detail_cover_async_apply",exc)

    @staticmethod
    def _make_description_pages(text,limit=360):
        # release Details: keep every synopsis in the original compact Overview box; never page/scroll it.
        # No page cycling: adaptive font fitting uses the existing spare vertical room.
        value=str(text or "").replace("\r"," ").replace("\n"," ").strip()
        # Display-only cleanup: remove Arabic tashkeel from this description box
        # without changing TMDb/provider language choice or the persisted raw text.
        value=_strip_arabic_tashkeel(value)
        return [value]

    def _publish_visible_description_authority(self,text):
        """Stage 3 compatibility hook.

        The canonical raw TMDb ``overview`` is now the only description authority.
        Details no longer publishes a second provider/Arabic-preservation overlay.
        """
        return bool(str(text or "").strip())

    def _set_description_source(self,text):
        # Raw TMDb/provider language authority stays untouched.  The display page
        # may remove Arabic tashkeel only; it never changes locale, substitutes
        # English, or rewrites the persisted description source.
        incoming=str(text or "").strip()
        self._description_source=incoming;self._description_pages=self._make_description_pages(self._description_source);self._desc_page=0
        self["description"].setText(self._description_pages[0] if self._description_pages else self._description_source)
        try:self._fit_description_font()
        except Exception as exc:diagnostic_failure("ui.details.failsoft.385",exc)
        try:self._publish_visible_description_authority(self._description_source)
        except Exception as exc:optional_failure("ui.details_visible_overview_publish_call",exc)
        self._sync_detail_text_direction();self._schedule_description_scroll()
        try:self._desc_guard_timer.start(180,True)
        except Exception:self._ensure_description_visible()
        return True

    def _ensure_description_visible(self):
        try:
            _scr=(self.__dict__.get("_smooth_text_scrollers") or {}).get("description")
            if _scr is not None and _scr.active:return
            text=str(self["description"].getText() or "").strip()
            if not text:
                pages=getattr(self,"_description_pages",[]) or []
                fallback=(pages[0] if pages else getattr(self,"_description_source","")).strip()
                self["description"].setText(fallback or _("No description available."))
            self["description"].show()
        except Exception as exc:optional_failure("ui",exc)

    def _stop_description_scroll(self):
        try:self._desc_scroll_timer.stop()
        except Exception as exc:optional_failure("ui",exc)
        try:self._desc_guard_timer.stop()
        except Exception as exc:optional_failure("ui",exc)
        try:
            if self._desc_scroll_conn is not None:self._desc_scroll_conn.disconnect()
        except Exception as exc:optional_failure("ui",exc)
        try:
            if self._desc_guard_conn is not None:self._desc_guard_conn.disconnect()
        except Exception as exc:optional_failure("ui",exc)
        try:
            if self._auto_scroll_description in self._desc_scroll_timer.callback:self._desc_scroll_timer.callback.remove(self._auto_scroll_description)
        except Exception as exc:optional_failure("ui.desc_scroll_callback",exc)
        try:
            if self._ensure_description_visible in self._desc_guard_timer.callback:self._desc_guard_timer.callback.remove(self._ensure_description_visible)
        except Exception as exc:optional_failure("ui.desc_guard_callback",exc)

    def _schedule_description_scroll(self):
        try:self._desc_scroll_timer.stop()
        except Exception as exc:optional_failure("ui",exc)
        try:
            return
        except Exception as exc:optional_failure("ui",exc)

    def _show_description_page(self,index):
        pages=getattr(self,"_description_pages",[]) or [getattr(self,"_description_source","")]
        if not pages:return
        self._desc_page=index%len(pages);self["description"].setText(pages[self._desc_page]);self._sync_detail_text_direction()

    def _auto_scroll_description(self):
        pages=getattr(self,"_description_pages",[]) or []
        if len(pages)>1:self._show_description_page(getattr(self,"_desc_page",0)+1);self._schedule_description_scroll()

    def description_up(self):
        self._show_description_page(getattr(self,"_desc_page",0)-1);self._schedule_description_scroll()

    def description_down(self):
        self._show_description_page(getattr(self,"_desc_page",0)+1);self._schedule_description_scroll()
