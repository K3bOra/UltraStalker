# -*- coding: utf-8 -*-
"""TLS contexts, persisted transport/compat state and certificate pins.

Methods moved verbatim out of ``StalkerClient`` (client.py); behaviour is unchanged.
This module is imported by client.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int
from .client import (
    DB,
    LOG,
    PortalError,
    PortalSecurityConsentError,
    compatibility_state_key,
    hashlib,
    same_origin,
    ssl,
    urllib,
)


class ClientTlsMixin(object):
    """TLS contexts, persisted transport/compat state and certificate pins."""

    def _build_opener(self, verified=True):
        context = self._tls_context(verified=verified)
        return urllib.request.build_opener(
            urllib.request.HTTPCookieProcessor(self.cookies),
            urllib.request.HTTPSHandler(context=context),
        )

    @staticmethod
    def _is_certificate_error(reason):
        if isinstance(reason, (ssl.SSLCertVerificationError, ssl.CertificateError)):
            return True
        text = str(reason or "").lower()
        return "certificate_verify_failed" in text or "certificate verify failed" in text or "self signed certificate" in text

    def _enable_compatible_tls(self):
        # HARDENED BUILD: compatibility TLS is deliberately unavailable.
        raise PortalSecurityConsentError("TLS certificate verification failed; unverified TLS is disabled in this hardened build")

    def _pin_compatible_tls_peer(self, conn, hostname, port):
        if not self.used_unverified_tls and self.tls_mode != "compatible":
            return
        sock = getattr(conn, "sock", None)
        if sock is None:
            raise PortalError("Compatible TLS connection did not expose a peer certificate")
        cert = sock.getpeercert(binary_form=True)
        if not cert:
            raise PortalError("Compatible TLS peer did not provide a certificate")
        fingerprint = hashlib.sha256(cert).hexdigest()
        key = "%s:%s" % (str(hostname or "").lower(), int(port or 443))
        previous = self._compatible_tls_pins.get(key)
        if previous is not None and previous != fingerprint:
            self._close_transport_socket(conn)
            raise PortalSecurityConsentError("Portal TLS certificate changed during the session; connection blocked by hardened TLS policy")
        if previous is None:
            self._compatible_tls_pins[key] = fingerprint
            LOG.warning("Compatible TLS certificate pinned for %s sha256=%s", key, fingerprint[:16])
            self._persist_transport_state()

    def _transport_state_key(self):
        raw = (self._state_host.rstrip("/").lower() + "|" + self.mac.upper()).encode("utf-8", "ignore")
        return "transport:" + hashlib.sha256(raw).hexdigest()

    def _load_transport_state(self):
        """Reuse only non-secret transport discoveries from prior sessions."""
        try:
            state = DB.state_get(self._transport_state_key())
        except Exception:
            state = {}
        if not isinstance(state, dict):
            return
        endpoint = str(state.get("endpoint") or "").strip()
        if endpoint:
            try:
                ep = urllib.parse.urlsplit(endpoint)
                host = urllib.parse.urlsplit(self.host)
                same_origin = ep.netloc == host.netloc and ep.path.lower().endswith((".php", "/load.php"))
                approved_downgrade = ep.scheme == "http" and host.scheme == "https" and self.allow_http_fallback
                if same_origin and (ep.scheme == host.scheme or approved_downgrade):
                    if approved_downgrade:
                        self.host = "http://" + self.host[8:]
                        self.entry_url = "http://" + self.entry_url[8:]
                        self.referer = "http://" + self.referer[8:]
                        self.used_http_fallback = True
                        self.security_warning = "WARNING: HTTPS unavailable; using approved insecure HTTP"
                    self.endpoint = endpoint.rstrip("/")
                    self._persisted_endpoint = self.endpoint
            except Exception as exc:
                LOG.debug("Persisted transport endpoint could not be restored: %s", exc)
        profile = str(state.get("device_profile") or "").lower()
        if profile in self.DEVICE_PROFILES:
            self.resolved_device_profile = profile
            self._persisted_device_profile = profile
        pins = state.get("compatible_tls_pins")
        if isinstance(pins, dict):
            clean_pins = {}
            for key, fingerprint in pins.items():
                key = str(key or "").strip().lower()
                fingerprint = str(fingerprint or "").strip().lower()
                if key and len(fingerprint) == 64 and all(ch in "0123456789abcdef" for ch in fingerprint):
                    clean_pins[key] = fingerprint
            self._compatible_tls_pins.update(clean_pins)
            self._persisted_compatible_tls_pins = dict(clean_pins)

    def _persist_transport_state(self):
        endpoint = str(self.endpoint or "")
        profile = str(self.resolved_device_profile or "")
        pins = dict(self._compatible_tls_pins)
        if (endpoint == self._persisted_endpoint and profile == self._persisted_device_profile
                and pins == self._persisted_compatible_tls_pins):
            return
        payload = {
            "portal": self._state_entry_url,
            "mac": self.mac,
            "endpoint": endpoint,
            "device_profile": profile if profile in self.DEVICE_PROFILES else "",
            "compatible_tls_pins": pins,
        }
        try:
            DB.state_put(self._transport_state_key(), payload)
            self._persisted_endpoint = endpoint
            self._persisted_device_profile = payload["device_profile"]
            self._persisted_compatible_tls_pins = dict(pins)
        except Exception as exc:
            LOG.debug("Could not persist portal transport state: %s", exc)

    def _compat_state_key(self):
        return compatibility_state_key(self._state_entry_url)

    def _load_compat_state(self):
        """Load non-secret compatibility discoveries shared by one portal root."""
        try:
            state = DB.state_get(self._compat_state_key())
        except Exception:
            state = {}
        if not isinstance(state, dict):
            state = {}
        self._compat_state = dict(state)
        endpoint = str(state.get("endpoint") or "").strip()
        method = str(state.get("method") or "").strip().upper()
        profile_variant = str(state.get("profile_variant") or "").strip().lower()
        ua_variant = str(state.get("ua_variant") or "").strip().lower()
        if endpoint:
            try:
                ep = urllib.parse.urlsplit(endpoint)
                if same_origin(endpoint, self.entry_url) and ep.path.lower().endswith(".php"):
                    self._compat_cached_endpoint = endpoint.rstrip("/")
                    if method in ("GET", "POST"):
                        self._compat_cached_method = method
                        self._compat_endpoint_methods[self._compat_cached_endpoint] = method
            except Exception:
                self._compat_cached_endpoint = ""
        if profile_variant in (
            "random_upper", "random_lower", "random_upper_emulator", "random_lower_emulator"
        ):
            self._compat_cached_profile_variant = profile_variant
        if ua_variant == "emulator":
            self._compat_cached_ua_variant = "emulator"
            # A previously validated emulator identity is a portal-root learning
            # result, not merely metadata. Reapply it immediately on a new
            # client/session so the next handshake does not repeat a known-bad
            # primary UA before reaching the proven compatibility path.
            self._compat_use_emulator_ua = True

    def _persist_compat_state(self, endpoint=None, method=None, profile_variant=None, ua_variant=None):
        state = dict(self._compat_state or {})
        changed = False
        if endpoint is not None:
            value = str(endpoint or "").strip().rstrip("/")
            if value and same_origin(value, self.entry_url) and urllib.parse.urlsplit(value).path.lower().endswith(".php"):
                if state.get("endpoint") != value:
                    state["endpoint"] = value; changed = True
                self._compat_cached_endpoint = value
            elif not value and state.get("endpoint"):
                state.pop("endpoint", None); changed = True
                self._compat_cached_endpoint = ""
        if method is not None:
            value = str(method or "").strip().upper()
            if value in ("GET", "POST"):
                if state.get("method") != value:
                    state["method"] = value; changed = True
                self._compat_cached_method = value
            elif state.get("method"):
                state.pop("method", None); changed = True
                self._compat_cached_method = ""
        if profile_variant is not None:
            value = str(profile_variant or "").strip().lower()
            allowed = ("random_upper", "random_lower", "random_upper_emulator", "random_lower_emulator")
            if value in allowed:
                if state.get("profile_variant") != value:
                    state["profile_variant"] = value; changed = True
                self._compat_cached_profile_variant = value
            elif state.get("profile_variant"):
                state.pop("profile_variant", None); changed = True
                self._compat_cached_profile_variant = ""
        if ua_variant is not None:
            value = str(ua_variant or "").strip().lower()
            if value == "emulator":
                if state.get("ua_variant") != value:
                    state["ua_variant"] = value; changed = True
                self._compat_cached_ua_variant = value
            elif state.get("ua_variant"):
                state.pop("ua_variant", None); changed = True
                self._compat_cached_ua_variant = ""
        if not changed:
            return
        try:
            DB.state_put(self._compat_state_key(), state)
            self._compat_state = state
        except Exception as exc:
            LOG.debug("Portal compatibility state could not be persisted: %s", exc)

    def _invalidate_compat_endpoint(self, endpoint=""):
        value = str(endpoint or self._compat_cached_endpoint or "").rstrip("/")
        if value:
            self._compat_endpoint_methods.pop(value, None)
        if not value or value == str(self._compat_cached_endpoint or "").rstrip("/"):
            self._persist_compat_state(endpoint="", method="")

    @classmethod
    def clear_persisted_tls_pins(cls, portal, mac):
        """Forget compatible-TLS TOFU pins after an explicit security-mode change."""
        try:
            entry = cls._normalize_entry_url(portal)
            normalized_mac = cls._normalize_mac(mac)
            host, _prefix, _referer = cls._split_entry(entry)
            raw = (host.rstrip("/").lower() + "|" + normalized_mac.upper()).encode("utf-8", "ignore")
            key = "transport:" + hashlib.sha256(raw).hexdigest()
            state = DB.state_get(key)
            if not isinstance(state, dict):
                state = {}
            if state.get("compatible_tls_pins"):
                state["compatible_tls_pins"] = {}
                DB.state_put(key, state)
                LOG.warning("Compatible TLS certificate approval reset for %s", host)
            return True
        except Exception as exc:
            LOG.debug("Could not reset compatible TLS certificate approval: %s", exc)
            return False
