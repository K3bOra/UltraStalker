# -*- coding: utf-8 -*-
"""Back, colour keys, live picon caching, selection and item playback.

Methods moved verbatim out of ``PortalBrowserScreen`` (ui_screens_browser.py); behaviour is unchanged.
This module is imported by ui_screens_browser.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, max, min
from .ui_screens_browser import (
    _,
    call_compatible,
    diagnostic_failure,
    show_notice,
)


class BrowserActionsMixin(object):
    """Back, colour keys, live picon caching, selection and item playback."""

    def back(self):
        if self._busy and getattr(self,"_folder_export_active",False):
            self._folder_export_active=False
            self._cancel_active_async()
            self.close() if self._home_entry else self._show_root()
            return
        if self.level=="items" and getattr(self,"_bouquet_select_mode",False):
            self._cancel_bouquet_channel_selection();return
        if getattr(self,"_category_menu_active",False):
            self._category_menu_back();return
        if self.level=="genres" and getattr(self,"_category_select_mode",False):
            self._cancel_category_selection()
            return
        # Category loading is asynchronous, but the clean Categories skin hides
        # the normal status label.  Historically BACK was blocked by _busy here,
        # which made a slow/dead portal request look like a frozen receiver.
        # BACK must always be a hard escape from the loading-only Categories
        # surface: cancel only this screen request and return immediately.
        if self._busy and self.level == "genres_loading":
            self._cancel_active_async()
            self.close() if self._home_entry else self._show_root()
            return
        # Catch-up is network-heavy on some portals. BACK is a hard UI escape:
        # cancel the request immediately and never force the viewer to wait for
        # a portal timeout or a multi-page scan to finish.
        if self._busy and str(self.level).startswith("catchup"):
            self._cancel_active_async()
            if self.level in ("catchup_programs_loading","catchup_programs"):
                self.level="catchup_channels"
                if getattr(self,"_catchup_channels_cache",None):
                    valid=list(self._catchup_channels_cache)
                    self.content_items=valid; self.all_content_items=list(valid)
                    self._catchup_show_channels(valid,getattr(self,"_catchup_channel_index",0))
                    self["status"].setText(_("Ready"));self._selection_changed();return
            self.close() if self._home_entry else self._show_root()
            return
        if self._busy: self["status"].setText(_("Please wait")); return
        if self.level=="favorites_cards" and getattr(self,"_favorite_reorder_active",False):
            self._favorite_cancel_move();return
        if self.level=="favorites_cards" and getattr(self,"_favorite_folder_id",None):
            self._favorite_leave_folder();return
        if self.level in ("favorites_cards","favorites_live"):
            self._show_favorites_root();return
        if self.level=="favorites_root":
            if self._home_entry:self.close()
            else:
                self._hide_favorite_ui();self._show_root()
            return
        if self.level=="root": self.close()
        elif self.level=="catchup_programs":
            cache=list(getattr(self,"_catchup_channels_cache",None) or [])
            if cache:
                self.level="catchup_channels";self.content_items=cache;self.all_content_items=list(cache)
                self._catchup_show_channels(cache,getattr(self,"_catchup_channel_index",0))
                self["status"].setText(_("Ready"));self._selection_changed()
            else:self.load_catchup_channels()
        elif self.level=="catchup_channels":
            self.close() if self._home_entry else self._show_root()
        elif self.level=="items":
            if self._home_entry and self.initial_action in ("favorites", "recent"):
                self.close()
            else:
                self.load_genres(self.media_type)
        else:
            self.close() if self._home_entry else self._show_root()

    def _show_root(self):
        if getattr(self,"_category_menu_active",False):self._category_menu_close()
        self.level="root"; self.media_type=None; self.genre=None; self.content_items=[]
        self._set_root_rows(); self["section"].setText(self.profile.get("portal","")); self["counter"].setText(_("PORTAL HOME  •  Sections: %d") % len(self.MODES))
        self["info_title"].setText(_("Choose a section")); self["info"].setText(_("Live, Movies, Series, Favorites and Continue Watching"))
        self._decode_picture(asset("us80_section_live_530x382.png")); self["status"].setText(_("Ready"))

    def red_action(self):
        if self.level=="favorites_cards" and getattr(self,"_favorite_reorder_active",False):
            return self._favorite_cancel_move()
        if self.level=="favorites_cards" and self._favorite_is_folder_entry(self._favorite_selected_entry()):
            return self._favorite_delete_folder()
        if self.level=="genres" and self.media_type in ("itv","vod","series"):
            return self.open_search()
        return self.back()

    def green_action(self):
        if self.level=="favorites_cards":
            return self._favorite_unfavorite_selected()
        if self.level=="genres" and self.media_type in ("itv","vod","series"):
            return self._start_category_selection()
        return self.reauthorize()

    def yellow_action(self):
        if self.level=="favorites_cards":
            return self._favorite_begin_move()
        if self.level=="genres" and self.media_type in ("itv","vod","series"):
            return self.toggle_current_category_hidden()
        return self.refresh_current()

    def reauthorize(self):
        if self._busy: return
        self["status"].setText(_("Reauthorizing..."))
        def work(): self.client.token=None; return self.client.authorize()
        self._run_async(work,lambda _result:self["status"].setText(_("Authorized")),lambda e:self["status"].setText(str(e)))

    def refresh_current(self):
        if self.level=="catchup_programs" and self.catchup_channel: self.load_catchup_programs(self.catchup_channel)
        elif self.level=="catchup_channels": self.load_catchup_channels()
        elif self.level=="genres": self.load_genres(self.media_type, force_refresh=True)
        elif self.level=="items": self.load_items(self.media_type,self.genre)
        else: self._show_root()

    def blue_action(self):
        if self.level=="favorites_cards" and getattr(self,"_favorite_reorder_active",False):
            return
        if self.level=="favorites_cards" and str(getattr(self,"_favorites_bucket_type",None) or "").lower()=="itv" and not getattr(self,"_favorite_folder_id",None):
            if self._favorite_is_folder_entry(self._favorite_selected_entry()):return self._favorite_edit_folder()
            return self._favorite_create_folder()
        if self.level=="genres" and self.media_type=="itv":
            return self.cache_all_live_picons()
        if self.level=="genres" and self.media_type in ("vod","series"):
            return self.export_current_media_folder()
        return self.select()

    def cache_all_live_picons(self):
        """Background Live picon cache with persistent failed-only retry.

        First run scans the provider and uses downloader for missing picons.
        If failures remain, the next blue-button press retries ONLY that persistent
        failed queue; it does not enumerate all Live categories again.
        """
        if self._live_picon_cache_running:
            self["status"].setText(_("Picon cache is already running"))
            return
        self._live_picon_cache_running=True
        profile=dict(self.profile or {})
        progress=self._live_picon_cache_progress

        # Fast path: a previous completed pass left failures. Retry those only.
        retry_rows=_load_live_picon_failed_queue(profile)
        retry_only=bool(retry_rows)
        if retry_only:
            self["blue"].setText("0 / %d"%len(retry_rows))
            self["status"].setText(_("Retrying %d failed picons only")%len(retry_rows))
        else:
            self["blue"].setText(_("Scanning..."))
            self["status"].setText(_("Scanning Live categories..."))

        genres=list(self.content_items or [])

        def work():
            isolated=None
            try:
                if retry_only:
                    rows=list(retry_rows)
                    total=len(rows)
                    _live_restart_trace("bulk_cache_retry_failed_start",total=total)
                else:
                    _live_restart_trace("bulk_cache_start",genres=len(genres))
                    isolated=_new_isolated_source_client(profile,timeout=6)
                    seen_urls=set();rows=[];skipped=0
                    total_genres=max(1,len(genres))
                    for gi,genre in enumerate(genres,1):
                        try:progress.put(("scan",gi,total_genres))
                        except Exception as exc: diagnostic_failure("ui.browser.failsoft", exc)
                        gid=str(genre.get("id") or genre.get("genre_id") or genre.get("name") or "*")
                        try:
                            batch=call_compatible(
                                isolated.ordered_all,
                                ((("itv",gid), {"start_page":1,"max_pages":500,"max_items":20000,"cancel_event":None}),
                                 (("itv",gid,1,500,20000,None), {})),
                            ) or []
                        except Exception:
                            batch=[]
                        for item in batch:
                            if not isinstance(item,dict):
                                skipped+=1;continue
                            raw=str(_image_url(item) or "")
                            if not raw:
                                skipped+=1;continue
                            try:
                                resolved=_normalize_provider_image_url(_source_art_url(raw,profile,item))
                                parts=urllib.parse.urlsplit(resolved or "")
                                if parts.scheme not in ("http","https") or not parts.hostname:
                                    skipped+=1;continue
                            except Exception:
                                skipped+=1;continue
                            if resolved in seen_urls:continue
                            seen_urls.add(resolved)
                            rows.append((item,resolved))
                    total=len(rows)

                if not total:
                    _save_live_picon_failed_queue(profile,[])
                    progress.put(("done",0,0,0,0,0))
                    _live_restart_trace("bulk_cache_done",done=0,total=0,cached=0,downloaded=0,failed=0)
                    return

                # TRUE RESUME remains for a normal/full pass. On failed-only retry
                # the visible total is intentionally only the failed queue.
                missing=[];cached=0
                for item,resolved in rows:
                    existing=_cached_live_picon_path(resolved,profile,item,validate=True)
                    if existing:
                        cached+=1
                    else:
                        missing.append((item,resolved))

                done=cached;downloaded=0;failed=0
                try:progress.put(("cache",done,total,cached,downloaded,failed))
                except Exception as exc: diagnostic_failure("ui.browser.failsoft", exc)
                _live_restart_trace("bulk_cache_resume",done=done,total=total,cached=cached,missing=len(missing),retry_only=retry_only)

                if not missing:
                    _save_live_picon_failed_queue(profile,[])
                    progress.put(("done",done,total,cached,downloaded,failed))
                    _live_restart_trace("bulk_cache_done",done=done,total=total,cached=cached,downloaded=0,failed=0,retry_only=retry_only)
                    return

                # IMPORTANT: original downloader path remains unchanged.
                def one(pair):
                    item,resolved=pair
                    existing=_cached_live_picon_path(resolved,profile,item,validate=True)
                    if existing:return ("cached",existing,pair)
                    path=_download_live_portal_temp_picon(resolved,profile,isolated,item=item,timeout=3.5)
                    if not path:
                        path=_download_public_live_picon(resolved,profile,item=item,timeout=3.5)
                    return ("downloaded",path,pair) if path else ("failed",None,pair)

                failed_rows=[]
                pool=ThreadPoolExecutor(max_workers=6,thread_name_prefix="ultra-picon-cache")
                futures=list(pool.submit(one,pair) for pair in missing)
                try:
                    for future in as_completed(futures):
                        pair=None
                        try:
                            state,path,pair=future.result()
                        except Exception:
                            state="failed";path=None
                        if state=="cached":cached+=1
                        elif state=="downloaded":downloaded+=1
                        else:
                            failed+=1
                            if pair is not None: failed_rows.append(pair)
                        done+=1
                        try:progress.put(("cache",done,total,cached,downloaded,failed))
                        except Exception as exc: diagnostic_failure("ui.browser.failsoft", exc)
                        if done%100==0 or done==total:
                            _live_restart_trace("bulk_cache_progress",done=done,total=total,cached=cached,downloaded=downloaded,failed=failed,retry_only=retry_only)
                finally:
                    try:pool.shutdown(wait=True,cancel_futures=True)
                    except TypeError:pool.shutdown(wait=True)

                # Persist ONLY unresolved failures. Next press starts here directly.
                _save_live_picon_failed_queue(profile,failed_rows)
                progress.put(("done",done,total,cached,downloaded,failed))
                _live_restart_trace("bulk_cache_done",done=done,total=total,cached=cached,downloaded=downloaded,failed=failed,retry_only=retry_only)
            except Exception as exc:
                _live_restart_trace("bulk_cache_error",error=repr(exc),retry_only=retry_only)
                try:progress.put(("error",_friendly_error(exc)))
                except Exception as exc: diagnostic_failure("ui.browser.failsoft", exc)
            finally:
                if isolated is not None:
                    try:isolated.close()
                    except Exception as exc: diagnostic_failure("ui.browser.failsoft", exc)

        try:
            self._live_picon_cache_future=_PICON_CACHE_EXECUTOR.submit(work)
        except Exception as exc:
            self._live_picon_cache_running=False
            self["blue"].setText(_("Cache Picons"))
            self["status"].setText(_friendly_error(exc))

    def select(self):
        if getattr(self,"_category_menu_active",False):return self._category_menu_accept()
        if self._busy: return
        if self.level=="items" and self.media_type=="itv" and getattr(self,"_bouquet_select_mode",False):
            return self._toggle_bouquet_channel_selection()
        if self.level=="genres" and getattr(self,"_category_select_mode",False):
            return self._toggle_category_selection()
        if self.level=="favorites_root":
            return self._show_favorites_bucket(("itv","vod","series")[max(0,min(2,int(getattr(self,"_favorite_root_index",0) or 0)))])
        if self.level=="favorites_cards":
            if getattr(self,"_favorite_reorder_active",False):return self._favorite_commit_move()
            return self._open_favorite_card()
        if self.level=="favorites_live":
            idx=self["list"].getSelectedIndex()
            if 0<=idx<len(self.content_items):
                item=self.content_items[idx]
                old=self.media_type;self.media_type="itv";self.play_item(item);self.media_type=old
            return
        idx=self["list"].getSelectedIndex()
        if self.level=="root" and 0 <= idx < len(self.MODES):
            action = self.MODES[idx][1]
            if action in ("itv", "vod", "series"):
                self._open_media_with_parental(action)
            elif action == "catchup":
                self.load_catchup_channels()
            elif action == "favorites":
                self._show_saved_entries(load_favorites(), "Favorites")
            elif action == "recent":
                self._show_saved_entries(load_continue_watching(), "Continue Watching")
            elif action == "account":
                self.show_account_info()
            elif action == "search":
                self.open_global_search()
            elif action == "settings":
                self.open_playback_settings()
        elif self.level=="genres" and 0 <= idx < len(self.content_items):
            self._open_genre_with_parental(self.content_items[idx], idx)
        elif self.level=="catchup_channels" and 0 <= idx < len(self.content_items):
            self._catchup_channel_index=idx
            self.load_catchup_programs(self.content_items[idx])
        elif self.level=="catchup_programs" and 0 <= idx < len(self.content_items):
            self.play_catchup_program(self.content_items[idx])
        elif self.level=="items" and 0 <= idx < len(self.content_items):
            item=self.content_items[idx]
            selected_type = item.get("_saved_media_type") or self.media_type
            if selected_type=="itv":
                previous_type = self.media_type; self.media_type = selected_type
                self.play_item(item); self.media_type = previous_type
            else: self.session.openWithCallback(lambda result=None:self._restore_current_list_selection(),ContentDetailsScreen,self.profile,self.client,selected_type,item)

    def _restore_current_list_selection(self):
        """Keep the exact list row selected after returning from details."""
        try:self._selection_changed()
        except Exception as exc:optional_failure("ui",exc)

    def _grid_returned(self, result=None):
        """Keep the selected category after leaving its poster/live grid."""
        if getattr(self,"_live_direct_mode",False):
            self._live_direct_mode=False
            try:
                self.close()
                return
            except Exception as exc:
                optional_failure("ui.live_direct_close",exc)
        try:self._cat_pv_forget_current()
        except Exception as exc:optional_failure("ui.category_pv_forget",exc)
        try:self._selection_changed()
        except Exception as exc:optional_failure("ui",exc)
        # Initial grid loads that exhaust their bounded self-heal return here
        # instead of stranding the viewer on an empty child screen.
        try:
            if isinstance(result,(tuple,list)) and len(result)>=2 and result[0]=="content_load_error":
                self["status"].setText(str(result[1] or _("Content temporarily unavailable. Try again.")))
        except Exception as exc:optional_failure("ui.grid_return_error_status",exc)

    def open_audio(self):
        if AudioSelection is None: show_notice(self.session, _("Audio selection is not available in this image"), timeout=6, owner=self)
        else:
            try: self.session.open(AudioSelection, infobar=None)
            except Exception as exc: self.session.open(MessageBox,_("Audio selection failed: %s")%exc,MessageBox.TYPE_ERROR,timeout=6)

    def open_subtitles(self):
        try:
            from Screens.AudioSelection import SubtitleSelection
            self.session.open(SubtitleSelection, infobar=None)
        except Exception as exc: show_notice(self.session, _("Subtitle selection is unavailable: %s")%exc, timeout=6, owner=self)

    def _mode_name(self, media_type):
        for title,key,_icon in self.MODES:
            if key==media_type:return _(title)
        return str(media_type or _("Result"))

    def play_item(self,item):
        if not isinstance(item,dict) or self._busy:return
        command=item.get("cmd") or item.get("command") or item.get("url")
        if not command:self["status"].setText(_("No stream command"));return
        play_media_type=str(self.media_type or "itv")
        fav_live_channels=[]
        if play_media_type in ("itv","live") and getattr(self,"level","")=="favorites_cards":
            try:
                fav_live_channels=[dict(e.get("item")) for e in (getattr(self,"_favorite_entries",None) or []) if isinstance(e,dict) and str(e.get("media_type") or "") in ("itv","live") and isinstance(e.get("item"),dict)]
            except Exception:
                fav_live_channels=[]
        self["status"].setText(_("Creating stream link..."))
        def work(handle):
            # Playback URL first.  Provider picon I/O must never sit between a
            # successful create_link and the Enigma2 service handoff: temporary
            # Stalker links can be short-lived, and Player already reuses a
            # cached picon or fetches it asynchronously after opening.
            return self.client.create_link(item,play_media_type,cancel_event=handle.cancel_event)
        def ok(result):
            url=result if isinstance(result,str) else ""
            if not url.strip():
                from .ui_helpers import report_stream_link_failure
                report_stream_link_failure(self);return
            name=str(item.get("name") or item.get("title") or "Ultra Stalker stream")
            try:
                add_recently_played(self.profile, play_media_type, item)
                self["status"].setText(_("Opening player: %s") % name)
                def closed(result=None):
                    if not (isinstance(result,dict) and result.get("service_restored")):
                        try:force_session_silence(self.session,str(url).strip(),force=True)
                        except Exception as exc:optional_failure("ui.detail_return_stop",exc)
                    engine = result.get("engine") if isinstance(result, dict) else load_settings().get("service_type", 4097)
                    self["status"].setText(_("Player closed  •  engine %s") % engine)
                    if getattr(self,"level","")=="favorites_cards":
                        try:self._favorite_child_returned()
                        except Exception:pass
                engine=_configured_playback_engine()
                payload=_player_payload(item, self.profile, media_type=play_media_type)
                payload["_player_client_ref"]=self.client
                if play_media_type in ("itv","live"):
                    payload["_live_client_ref"]=self.client
                    if fav_live_channels:
                        payload["_live_folder_channels"]=fav_live_channels
                        payload["_live_folder_title"]=str(getattr(self,"_favorite_active_folder_name","") or _("Favorites"))
                        payload["_live_folder_total"]=len(fav_live_channels)
                        payload["_live_page_size"]=max(1,len(fav_live_channels))
                        payload["_live_folder_page"]=1
                        cur_idx=0
                        for idx_c,ch in enumerate(fav_live_channels):
                            if any(item.get(k) not in (None,"") and str(item.get(k))==str(ch.get(k)) for k in ("id","ch_id","stream_id","cmd")):
                                cur_idx=idx_c;break
                        payload["_live_absolute_index"]=cur_idx
                self.session.openWithCallback(closed, UltraStalkerPlayer, str(url).strip(), name, play_media_type, engine, payload)
            except Exception as exc:self["status"].setText(_("Player failed: %s")%exc)
        def link_failed(error):
            from .ui_helpers import report_stream_link_failure
            report_stream_link_failure(self,error)
        self._run_async(work,ok,link_failed)
