# -*- coding: utf-8 -*-
"""Local stream relay for images whose media player cannot send HTTP headers.

DreamOS's GStreamer source always identifies itself as
"GStreamer souphttpsrc libsoup/...", and many IPTV servers answer that with
401/403.  The relay listens on 127.0.0.1 only; the receiver plays
http://127.0.0.1:<port>/r/<token>/<original path> and the relay fetches the
real URL with a player User-Agent, passing Range requests through so seeking
works.  Relative URLs inside HLS playlists keep resolving through the relay
because the original path is mirrored after the token; absolute URLs in a
playlist are rewritten to relay URLs as well.

Only one upstream connection per stream is kept: when the player reconnects
(seek), the previous upstream transfer is stopped first, so providers with a
one-connection limit do not reject the new request.

In addition, Stalker/Ministra portals often mint single-use ``play_token``
parameters on ``play/movie.php`` and ``play/live.php`` that redirect (302) on
the first request and return ``HTTP 462`` on any subsequent request (such as
GStreamer's Matroska cue-reading Range probe or seek request).  The relay
caches resolved 302 redirect target URLs per stream and, when an upstream
returns HTTP 462/403/401/410/458 on a consumed token, transparently invokes
the registered stream link refresher (``client.create_link``) so GStreamer
receives the requested byte range without pipeline errors.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str, int, OSError, IOError
import binascii
os = _us_env.os
socket = _us_env.socket
threading = _us_env.threading
time = _us_env.time
urllib = _us_env.urllib
BaseHTTPRequestHandler = _us_env.http_server.BaseHTTPRequestHandler
ThreadingHTTPServer = _us_env.http_server.ThreadingHTTPServer
from .log import get_logger
LOG = get_logger()
HOST = '127.0.0.1'
_CHUNK = 64 * 1024
_CONNECT_TIMEOUT = 15.0
_UA_RETRY_CODES = (401, 403, 407, 451, 456, 460)
_TOKEN_REFRESH_CODES = (401, 403, 404, 410, 451, 456, 458, 459, 460, 462, 502, 503, 504)
_REDIRECT_TTL = 3600.0
USER_AGENTS = ('Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG250 stbapp ver: 2 rev: 250 Safari/533.3', 'Enigma2 HbbTV/1.1.1 (+PVR+RTSP+DL;OpenATV;;;)', 'VLC/3.0.20 LibVLC/3.0.20', 'Lavf/58.76.100')
_LOCK = threading.RLock()
_REFRESH_LOCK = threading.RLock()
_SERVER = None
_PORT = None
_TOKENS = {}
_BY_KEY = {}
_ACTIVE = {}
_ACTIVE_RESP = {}
_HOST_UA = {}
_REDIRECT_CACHE = {}
_FRESH_URLS = {}
_CONSUMED_TOKENS = set()
_REFRESHERS = {}
_STATS = {'requests': 0, 'ua_retries': 0, 'errors': 0, 'refreshes': 0, 'last_error': ''}

def _event(name, **fields):
    pass

def _has_single_use_play_token(url):
    low = str(url or '').lower()
    return 'play_token=' in low and ('/play/movie.php' in low or '/play/live.php' in low or '/play/' in low)

def _cached_redirect(url):
    with _LOCK:
        row = _REDIRECT_CACHE.get(url)
        if not row:
            return ''
        final_url, ts = row
        if time.time() - float(ts or 0.0) > _REDIRECT_TTL:
            _REDIRECT_CACHE.pop(url, None)
            return ''
        return str(final_url or '')

def _store_redirect(origins, final_url):
    final_url = str(final_url or '').strip()
    if not final_url.lower().startswith(('http://', 'https://')):
        return
    now = time.time()
    with _LOCK:
        for origin in origins:
            origin = str(origin or '').strip()
            if origin and origin != final_url:
                _REDIRECT_CACHE[origin] = (final_url, now)
        while len(_REDIRECT_CACHE) > 256:
            try:
                oldest = min(_REDIRECT_CACHE.items(), key=lambda kv: kv[1][1])[0]
                _REDIRECT_CACHE.pop(oldest, None)
            except Exception:
                _REDIRECT_CACHE.clear()
                break

def _evict_redirect(origins):
    with _LOCK:
        for origin in origins:
            _REDIRECT_CACHE.pop(str(origin or ''), None)

class _Handler(BaseHTTPRequestHandler):
    server_version = 'UltraStalkerRelay/1'
    sys_version = ''
    protocol_version = 'HTTP/1.0'

    def log_message(self, *args):
        return

    def do_HEAD(self):
        self._relay(head=True)

    def do_GET(self):
        self._relay(head=False)

    def _fail(self, code, text):
        try:
            body = text.encode('utf-8')
            self.send_response(code)
            self.send_header('Content-Type', 'text/plain')
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        except Exception:
            pass

    def _relay(self, head=False):
        client_host = self.client_address[0] if self.client_address else ''
        if client_host not in ('127.0.0.1', '::1', '::ffff:127.0.0.1'):
            self._fail(403, 'loopback only')
            return
        parts = self.path.split('/', 3)
        if len(parts) < 3 or parts[1] != 'r':
            self._fail(404, 'not found')
            return
        token = parts[2]
        rest = parts[3] if len(parts) > 3 else ''
        with _LOCK:
            entry = _TOKENS.get(token)
            previous = _ACTIVE.get(token) if not head else None
            prev_resp = _ACTIVE_RESP.get(token) if not head else None
            stop = threading.Event()
            if not head:
                _ACTIVE[token] = stop
            _STATS['requests'] += 1
        if entry is None:
            self._fail(404, 'unknown stream')
            return
        if previous is not None and (not previous.is_set()):
            previous.set()
            if prev_resp is not None:
                try:
                    prev_resp.close()
                except Exception:
                    pass
            time.sleep(0.15)
        upstream = entry['base'] + '/' + rest
        try:
            response = self._open(entry, upstream, head, token=token)
        except _UpstreamError as exc:
            _STATS['errors'] += 1
            _STATS['last_error'] = str(exc)
            _event('relay_error', status=exc.code, detail=str(exc)[:160])
            self._fail(exc.code or 502, 'upstream error')
            return
        if not head:
            with _LOCK:
                if _ACTIVE.get(token) is stop:
                    _ACTIVE_RESP[token] = response
        try:
            self._send(response, head, stop, entry)
        finally:
            try:
                response.close()
            except Exception:
                pass
            if not head:
                with _LOCK:
                    if _ACTIVE.get(token) is stop:
                        _ACTIVE.pop(token, None)
                        _ACTIVE_RESP.pop(token, None)

    def _open_single_url(self, entry, target_url, head):
        netloc = urllib.parse.urlsplit(target_url).netloc or urllib.parse.urlsplit(entry['base']).netloc
        first = _HOST_UA.get(netloc, 0)
        order = [first] + [i for i in range(len(USER_AGENTS)) if i != first]
        if entry['headers'].get('User-Agent'):
            order = [None] + order
        last = None
        for position, index in enumerate(order):
            headers = dict(entry['headers'])
            if index is not None:
                headers['User-Agent'] = USER_AGENTS[index]
            headers.setdefault('Accept', '*/*')
            headers['Connection'] = 'close'
            rng = self.headers.get('Range')
            if rng:
                headers['Range'] = rng
            request = urllib.request.Request(target_url, headers=headers)
            if head:
                request.get_method = lambda: 'HEAD'
            try:
                response = urllib.request.urlopen(request, timeout=_CONNECT_TIMEOUT)
                if index is not None and _HOST_UA.get(netloc) != index:
                    _HOST_UA[netloc] = index
                    _event('relay_user_agent', host=netloc, ua=USER_AGENTS[index][:40])
                return response
            except urllib.error.HTTPError as exc:
                last = _UpstreamError(exc.code, 'HTTP %s' % exc.code)
                try:
                    exc.close()
                except Exception:
                    pass
                if exc.code in _UA_RETRY_CODES:
                    if position + 1 < len(order):
                        _STATS['ua_retries'] += 1
                        time.sleep(0.15)
                        continue
                    break
                raise last
            except Exception as exc:
                raise _UpstreamError(502, '%s' % (exc,))
        raise last or _UpstreamError(502, 'no response')

    def _refresh_upstream(self, token, original_upstream, active_upstream):
        with _LOCK:
            refresher = _REFRESHERS.get(token)
        if not callable(refresher):
            return ''
        with _REFRESH_LOCK:
            try:
                fresh = str(refresher() or '').strip()
            except Exception as exc:
                LOG.debug('Stream relay link refresh failed: %s', exc)
                return ''
            if not fresh.lower().startswith(('http://', 'https://')):
                return ''
            if '#' in fresh:
                fresh = fresh.split('#', 1)[0]
            with _LOCK:
                _FRESH_URLS[original_upstream] = fresh
                _FRESH_URLS[active_upstream] = fresh
                _STATS['refreshes'] = int(_STATS.get('refreshes', 0)) + 1
            _event('relay_token_refresh', token=str(token or '')[:8])
            return fresh

    def _open(self, entry, upstream, head, token=None):
        with _LOCK:
            active_upstream = _FRESH_URLS.get(upstream, upstream)
        cached_final = _cached_redirect(active_upstream) or _cached_redirect(upstream)
        if cached_final and cached_final != active_upstream:
            try:
                response = self._open_single_url(entry, cached_final, head)
                final_url = response.geturl() or ''
                if final_url and final_url != cached_final:
                    _store_redirect((upstream, active_upstream), final_url)
                return response
            except _UpstreamError:
                _evict_redirect((upstream, active_upstream))
        with _LOCK:
            already_consumed = active_upstream in _CONSUMED_TOKENS
        if already_consumed and _has_single_use_play_token(active_upstream):
            refreshed = self._refresh_upstream(token, upstream, active_upstream)
            if refreshed:
                active_upstream = refreshed
        last_error = None
        for attempt in range(2):
            with _LOCK:
                if _has_single_use_play_token(active_upstream):
                    _CONSUMED_TOKENS.add(active_upstream)
                    while len(_CONSUMED_TOKENS) > 512:
                        try:
                            _CONSUMED_TOKENS.pop()
                        except Exception:
                            _CONSUMED_TOKENS.clear()
                            break
            try:
                response = self._open_single_url(entry, active_upstream, head)
                final_url = response.geturl() or ''
                if final_url and final_url != active_upstream:
                    _store_redirect((upstream, active_upstream), final_url)
                return response
            except _UpstreamError as exc:
                last_error = exc
                _evict_redirect((upstream, active_upstream))
                if attempt == 0 and exc.code in _TOKEN_REFRESH_CODES:
                    refreshed = self._refresh_upstream(token, upstream, active_upstream)
                    if refreshed and refreshed != active_upstream:
                        active_upstream = refreshed
                        continue
                break
        if last_error is not None and last_error.code in _UA_RETRY_CODES and (not getattr(self, '_us_retried', False)):
            self._us_retried = True
            time.sleep(1.0)
            return self._open(entry, upstream, head, token=token)
        raise last_error or _UpstreamError(502, 'no response')

    def _send(self, response, head, stop, entry):
        status = response.getcode() or 200
        info = response.info()
        ctype = info.get('Content-Type') or 'application/octet-stream'
        final_url = response.geturl() or ''
        if _is_playlist(final_url, ctype) and (not head):
            body = response.read(4 * 1024 * 1024)
            body = _rewrite_playlist(body, final_url, entry['headers'])
            self.send_response(200)
            self.send_header('Content-Type', ctype)
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return
        self.send_response(int(status))
        for name in ('Content-Type', 'Content-Length', 'Content-Range', 'Accept-Ranges', 'Last-Modified', 'ETag'):
            value = info.get(name)
            if value:
                self.send_header(name, value)
        self.end_headers()
        if head:
            return
        while not stop.is_set():
            try:
                chunk = response.read(_CHUNK)
            except Exception:
                break
            if not chunk:
                break
            try:
                self.wfile.write(chunk)
            except (socket.error, IOError, OSError, ValueError):
                break

class _UpstreamError(Exception):

    def __init__(self, code, text):
        Exception.__init__(self, text)
        self.code = code

class _Server(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def handle_error(self, request, client_address):
        return

def _is_playlist(url, ctype):
    low = (ctype or '').lower()
    if 'mpegurl' in low:
        return True
    path = urllib.parse.urlsplit(url).path.lower()
    return path.endswith('.m3u8') or path.endswith('.m3u')

def _rewrite_playlist(body, playlist_url, headers):
    try:
        text = body.decode('utf-8', 'replace')
    except Exception:
        return body
    out = []
    for line in text.splitlines():
        stripped = line.strip()
        if stripped and (not stripped.startswith('#')):
            absolute = urllib.parse.urljoin(playlist_url, stripped)
            if absolute.startswith(('http://', 'https://')):
                line = wrap(absolute, headers=headers, force=True)
        elif 'URI="' in line:
            head, _sep, tail = line.partition('URI="')
            uri, _q, after = tail.partition('"')
            absolute = urllib.parse.urljoin(playlist_url, uri)
            if absolute.startswith(('http://', 'https://')):
                line = head + 'URI="' + wrap(absolute, headers=headers, force=True) + '"' + after
        out.append(line)
    return ('\n'.join(out) + '\n').encode('utf-8')

def _ensure_server():
    global _SERVER, _PORT
    with _LOCK:
        if _SERVER is not None:
            return _PORT
        server = _Server((HOST, 0), _Handler)
        _PORT = server.server_address[1]
        thread = threading.Thread(target=server.serve_forever, name='ultrastalker-stream-relay')
        thread.daemon = True
        thread.start()
        _SERVER = server
        _event('relay_started', port=_PORT)
        return _PORT

def needed():
    """True on images whose media player cannot send a User-Agent."""
    try:
        from . import us_env
        return bool(us_env.IS_DREAMOS)
    except Exception:
        return False

def wrap(url, headers=None, force=False, refresher=None):
    """Return a relay URL for an http(s) stream, or the URL unchanged."""
    url = str(url or '')
    if not (force or needed()):
        return url
    if not url.lower().startswith(('http://', 'https://')):
        return url
    if _PORT and url.startswith('http://%s:%d/r/' % (HOST, _PORT)):
        if callable(refresher):
            register_refresher(url, refresher)
        return url
    if '#' in url:
        url = url.split('#', 1)[0]
    try:
        port = _ensure_server()
    except Exception as exc:
        LOG.warning('Stream relay unavailable: %s', exc)
        return url
    parts = urllib.parse.urlsplit(url)
    base = '%s://%s' % (parts.scheme, parts.netloc)
    hdrs = dict(headers or {})
    key = (base, tuple(sorted(hdrs.items())))
    with _LOCK:
        token = _BY_KEY.get(key)
        if token is None:
            token = binascii.hexlify(os.urandom(8)).decode('ascii')
            _BY_KEY[key] = token
            _TOKENS[token] = {'base': base, 'headers': hdrs}
        if callable(refresher):
            _REFRESHERS[token] = refresher
        _FRESH_URLS.pop(url, None)
    tail = parts.path.lstrip('/')
    if parts.query:
        tail += '?' + parts.query
    return 'http://%s:%d/r/%s/%s' % (HOST, port, token, tail)

def register_refresher(url, refresher):
    """Register or update a link-refresh callback for a stream URL or relay URL."""
    if not callable(refresher):
        return
    url = str(url or '')
    prefix = 'http://%s:' % HOST
    if url.startswith(prefix) and '/r/' in url:
        token = url.split('/r/', 1)[1].partition('/')[0]
        if token:
            with _LOCK:
                _REFRESHERS[token] = refresher
        return
    if not url.lower().startswith(('http://', 'https://')):
        return
    if '#' in url:
        url = url.split('#', 1)[0]
    parts = urllib.parse.urlsplit(url)
    base = '%s://%s' % (parts.scheme, parts.netloc)
    key = (base, ())
    with _LOCK:
        token = _BY_KEY.get(key)
        if token is None:
            token = binascii.hexlify(os.urandom(8)).decode('ascii')
            _BY_KEY[key] = token
            _TOKENS[token] = {'base': base, 'headers': {}}
        _REFRESHERS[token] = refresher
        _FRESH_URLS.pop(url, None)

def unwrap(url):
    """Original URL for a relay URL (for display/matching)."""
    url = str(url or '')
    prefix = 'http://%s:' % HOST
    if not url.startswith(prefix) or '/r/' not in url:
        return url
    token_and_rest = url.split('/r/', 1)[1]
    token, _sep, rest = token_and_rest.partition('/')
    entry = _TOKENS.get(token)
    if entry is None:
        return url
    return entry['base'] + '/' + rest

def status():
    return dict(_STATS, port=_PORT, streams=len(_TOKENS), hosts=dict(_HOST_UA))
