# -*- coding: utf-8 -*-
"""Recent refresh, prefetch and quiet catalogue refresh timers.

Methods moved verbatim out of ``PortalHomeScreen`` (ui_screens_home.py); behaviour is unchanged.
This module is imported by ui_screens_home.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import int, max
from .ui_screens_home import (
    LOG,
    _CATEGORY_PREFETCH_EXECUTOR,
    _category_cache_get,
    _category_cache_put,
    optional_failure,
    queue,
    time,
)


class HomeTimersMixin(object):
    """Recent refresh, prefetch and quiet catalogue refresh timers."""

    def _schedule_home_recent_refresh(self, delay_ms=120):
        if getattr(self,"_screen_closed",False):return
        try:
            self._home_recent_refresh_timer.stop()
            self._home_recent_refresh_timer.start(max(1,int(delay_ms or 1)),True)
        except Exception:
            self._home_recent_refresh_fire()

    def _home_recent_refresh_fire(self):
        try:self._home_recent_refresh_timer.stop()
        except Exception:pass
        if getattr(self,"_screen_closed",False) or not getattr(self,"_home_runtime_visible",True):return
        _phase=time.monotonic()
        try:self._load_recent_cards()
        except Exception as exc:optional_failure("ui.home_recent_deferred",exc)
        if LOG is not None:LOG.info("R129 home recent_deferred elapsed_ms=%d",int((time.monotonic()-_phase)*1000))

    def _home_prefetch_delay_fire(self):
        try:self._home_prefetch_delay_timer.stop()
        except Exception:pass
        if getattr(self,"_screen_closed",False) or not getattr(self,"_home_runtime_visible",True):return
        try:self._start_category_prefetch()
        except Exception as exc:optional_failure("ui.category_prefetch_start",exc)

    def _stop_home_speed_timers(self):
        # The post-return history re-check timer is created lazily in
        # _home_shown_body; it must be released with the other Home timers.
        _rc_timer=getattr(self,"_home_recent_recheck_timer",None)
        if _rc_timer is not None:
            try:_rc_timer.stop()
            except Exception:pass
            try:
                _rc_conn=getattr(self,"_home_recent_recheck_conn",None)
                if _rc_conn is not None:_rc_conn.disconnect()
            except Exception:pass
            try:
                if self._home_recent_recheck in _rc_timer.callback:_rc_timer.callback.remove(self._home_recent_recheck)
            except Exception:pass
        for timer in (getattr(self,"_home_recent_refresh_timer",None),getattr(self,"_home_prefetch_delay_timer",None)):
            if timer is None:continue
            try:timer.stop()
            except Exception:pass
        for timer,conn,callback in (
            (getattr(self,"_home_recent_refresh_timer",None),getattr(self,"_home_recent_refresh_conn",None),self._home_recent_refresh_fire),
            (getattr(self,"_home_prefetch_delay_timer",None),getattr(self,"_home_prefetch_delay_conn",None),self._home_prefetch_delay_fire),
        ):
            if timer is None:continue
            try:
                if conn is not None:conn.disconnect()
            except Exception:pass
            try:
                if callback in timer.callback:timer.callback.remove(callback)
            except Exception:pass

    def _start_category_prefetch(self):
        """Category screens load only the selected media family."""
        return False

    def _start_quiet_catalogue_refresh(self):
        """Fast reopen: Home is already up, then ask for anything new."""
        if getattr(self, "_quiet_catalogue_refresh_started", False):
            return
        self._quiet_catalogue_refresh_started = True
        try:
            from . import ui as runtime_ui
            if not runtime_ui.catalogue_quiet_due(self.profile):
                return
            runtime_ui.start_quiet_catalogue_refresh(self.profile)
        except Exception as exc:
            optional_failure("ui.quiet_catalogue_refresh_start", exc)

    def _stop_home_background_jobs(self):
        for client in list(getattr(self,"_recent_pending_clients",set())):
            try:client.close()
            except Exception:pass
        self._recent_pending_clients=set()
        self._cancel_recent_futures()
        # AsyncScreenMixin has already marked the Screen closed; discard any
        # artwork payloads that completed in the same event-loop turn.
        try:
            while True:self._home_jobs.get_nowait()
        except queue.Empty:
            pass
        except Exception as exc:optional_failure("ui.home_queue_drain",exc)
        self._hero_data=None
