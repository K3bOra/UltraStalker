# QR error correct levels
from __future__ import absolute_import, division, print_function, unicode_literals
ERROR_CORRECT_L = 1
ERROR_CORRECT_M = 0
ERROR_CORRECT_Q = 3
ERROR_CORRECT_H = 2
