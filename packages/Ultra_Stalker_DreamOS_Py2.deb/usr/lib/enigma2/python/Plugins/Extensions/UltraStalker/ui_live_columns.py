# -*- coding: utf-8 -*-
"""Live TV - three-column screen (R5.64).

Categories | 11 channel rows (NOW title + progress, or a quality badge when the
provider has no EPG) | preview + today's schedule (or channel info).

Built on PremiumLiveGridScreen, so preview, full screen, favourites, bouquet
MENU, picons and paging keep their proven behaviour.  This class only changes
layout, adds the categories column and the per-row EPG lane.

GUI rules: arrow keys only move widgets / set text.  Row EPG for the visible page
is fetched by one background job (selected row first) and kept in a small
module-level cache, including "this channel has no EPG", so a portal without
guide data is not asked again on every page.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str, int, round, max, min, us_clear, us_casefold, us_func
from .wqhd_layout import responsive_font as _ultra_rfont, factors as _ultra_factors

def _ultra_osd_scale():
    return _ultra_factors()[1]

os = _us_env.os
queue = _us_env.queue
threading = _us_env.threading
time = _us_env.time
OrderedDict = _us_env.collections.OrderedDict

from . import _
from .ui_grid_screens import PremiumLiveGridScreen, PremiumGridBase
from .ui_skin_templates import LIVE_COLUMNS_SKIN as _RAW_SKIN
from .log import optional_failure
from .ultra import quality_badges, epg_title, _timestamp, epg_summary
from .core.shared_executors import METADATA_EXECUTOR as _EPG_EXECUTOR
from .core.shared_executors import LIVE_PICON_RENDER_EXECUTOR as _PICON_FIT_EXECUTOR

from Components.Label import Label
from Components.Pixmap import Pixmap
from enigma import eTimer, ePoint, eSize
try:
    from enigma import gFont
except Exception:
    gFont = None

ROWS = 17
ROW_Y0, ROW_STEP = 30, 57
CAT_ROWS = 15
CAT_Y0, CAT_STEP = 86, 61
SCHED_ROWS = 5
SCHED_Y0, SCHED_STEP = 652, 56
STRACK_W = 560

_REMEMBER_LOCK = threading.Lock()
_REMEMBER_NONE = object()
_REMEMBER_STATE = {"value": _REMEMBER_NONE, "running": False}
_EPG_CACHE = OrderedDict()
_EPG_CACHE_LOCK = threading.Lock()
_EPG_CACHE_LIMIT = 800


_ALT_ID_KEYS = ("id", "ch_id", "channel_id", "stream_id", "epg_id", "tvg_id", "xmltv_id")


def _alt_epg_ids(item, primary):
    out = []
    pre = (item or {}).get("_receiver_epg_candidates")
    values = list(pre) if isinstance(pre, (list, tuple)) else []
    values += [(item or {}).get(k) for k in _ALT_ID_KEYS]
    for value in values:
        value = str(value or "").strip()
        if value and value != primary and value not in out:
            out.append(value)
    return out[:2]


def tiered_epg_many(client, cid_items, hours, cancel_event, on_each):
    """epg_many with the same alternative channel ids the receiver export uses.

    The export finds a guide for channels whose first id answers empty by trying
    ch_id / stream_id / epg ids; the on-screen fetch used only the first id, so
    the list showed fewer guides than the receiver. Results are stored under the
    row's primary id. Xtream/M3U clients resolve ids themselves: no extra tiers.
    """
    many = getattr(client, "epg_many", None)
    primaries = list(cid_items)
    if not primaries:
        return
    if "M3U" in type(client).__name__ or not callable(many):
        many(primaries, hours, cancel_event=cancel_event, on_each=on_each)
        return
    empty = []

    def first(cid, rows):
        if rows is None:
            on_each(cid, None)
        elif rows:
            on_each(cid, rows)
        else:
            empty.append(cid)

    many(primaries, hours, cancel_event=cancel_event, on_each=first)
    pending = list(empty)
    for tier in range(2):
        if not pending or (cancel_event is not None and cancel_event.is_set()):
            break
        lookup = {}
        for cid in pending:
            alts = _alt_epg_ids(cid_items.get(cid), cid)
            if tier < len(alts):
                lookup.setdefault(alts[tier], []).append(cid)
        if not lookup:
            break
        found = {}

        def alt_each(alt, rows):
            if rows:
                found[alt] = rows

        many(list(lookup), hours, cancel_event=cancel_event, on_each=alt_each)
        still = []
        for alt, cids in lookup.items():
            for cid in cids:
                if alt in found:
                    on_each(cid, found[alt])
                else:
                    still.append(cid)
        tried = set(x for v in lookup.values() for x in v)
        pending = [c for c in pending if c in still or c not in tried]
    if cancel_event is None or not cancel_event.is_set():
        for cid in pending:
            on_each(cid, [])
_TTL_EVENTS = 15 * 60
_TTL_NONE = 10 * 60


def _ui():
    from . import ui as _u
    return _u


def _prepared_skin():
    xml = _RAW_SKIN
    try:
        u = _ui()
        xml = u._bind_internal_skin_assets(xml)
        xml = u._prepare_runtime_skin(xml)
    except Exception as exc:
        optional_failure("live3.skin_prepare", exc)
    return xml


def _asset(name):
    try:
        return _ui().asset(name)
    except Exception:
        return os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets_fhd", name)


def _events_from_rows(rows):
    out = []
    for row in rows if isinstance(rows, list) else []:
        if not isinstance(row, dict):
            continue
        # Follow the MAG short EPG local-time pair.  A nonempty but unusable
        # timestamp must not hide the valid programme time/time_to fields.
        start = next((v for v in (_timestamp(row.get(k)) for k in ("time", "start_timestamp", "start")) if v > 0), 0)
        stop = next((v for v in (_timestamp(row.get(k)) for k in ("time_to", "stop_timestamp", "stop", "end")) if v > 0), 0)
        if not stop and start:
            try:
                dur = int(float(row.get("duration") or row.get("length") or 0))
                if dur > 0:
                    stop = start + dur
            except Exception:
                pass
        if stop and start and stop <= start:
            if stop < 86400:
                stop = start + stop
            elif start - stop < 24 * 3600:
                stop += 86400
            else:
                stop = 0
        title = epg_title(row)
        if start and title:
            out.append((int(start), int(stop or 0), title))
    out.sort(key=lambda e: e[0])
    # fill missing stops from the next start
    fixed = []
    for i, (s, e, t) in enumerate(out):
        if not e and i + 1 < len(out):
            e = out[i + 1][0]
        fixed.append((s, e, t))
    return fixed


def _cache_get(key):
    with _EPG_CACHE_LOCK:
        hit = _EPG_CACHE.get(key)
        if hit is None:
            return False, None
        expires, data = hit
        if time.monotonic() > expires:
            _EPG_CACHE.pop(key, None)
            return False, None
        if data and data.get("events"):
            last_stop = max((e[1] for e in data["events"]), default=0)
            if last_stop and time.time() >= last_stop:
                _EPG_CACHE.pop(key, None)
                return False, None
        return True, data


def _cache_put(key, data, ttl):
    with _EPG_CACHE_LOCK:
        _EPG_CACHE[key] = (time.monotonic() + ttl, data)
        _EPG_CACHE.move_to_end(key)
        while len(_EPG_CACHE) > _EPG_CACHE_LIMIT:
            _EPG_CACHE.popitem(last=False)


def _refresh_ready_epg(screen):
    """Invalidate visible negative answers when a background guide becomes ready.

    Called on the GUI heartbeat: RAM/cache operations only, never XML/network I/O.
    """
    revision = int(getattr(screen.client, '_epg_ready_revision', 0) or 0)
    if revision == getattr(screen, '_live_epg_ready_revision', 0):
        return
    screen._live_epg_ready_revision = revision
    portal = (getattr(screen, '_portal_id', None) or screen._em_portal)()
    channel_id = getattr(screen, '_cid', None) or screen._em_cid
    for item in screen.grid_items or []:
        cid = channel_id(item)
        hit, data = _cache_get((portal, cid))
        if hit and not data:
            _cache_put((portal, cid), None, -1)
    screen._l3_retry_after = {}
    screen._wl_retry_after = {}
    screen._em_retry_after = {}


def _now_state(data, now=None):
    """(current_index, percent) for an events dict, or (-1, 0)."""
    events = (data or {}).get("events") or []
    now = int(now or time.time())
    for i, (s, e, _t) in enumerate(events):
        if not e and i + 1 < len(events):
            e = events[i + 1][0]  # no stop time: the next programme's start ends this one
        if s <= now and (not e or now < e):
            pct = int((now - s) * 100.0 / (e - s)) if e and e > s else 0
            return i, max(0, min(100, pct))
    return -1, 0


class PremiumLiveColumnsScreen(PremiumLiveGridScreen):
    skin = ""
    page_size = ROWS
    card_positions = [(360, ROW_Y0 + r * ROW_STEP) for r in range(ROWS)]
    PREVIEW_RECT = (1080, 36, 800, 450)
    selection_asset = "live_clean_r376/selected_690x56.png"

    def __init__(self, session, profile, client, media_type, genre, category_title="", live_categories=None, initial_search=""):
        if not PremiumLiveColumnsScreen.skin:
            PremiumLiveColumnsScreen.skin = _prepared_skin()
        us_func(PremiumLiveGridScreen.__init__)(self, session, profile, client, media_type, genre, category_title, live_categories, initial_search)
        self["cat_head"] = Label(_("CATEGORIES"))
        self["cat_sel"] = Pixmap()
        for k in range(CAT_ROWS):
            self["cat_name%d" % k] = Label("")
        for r in range(ROWS):
            self["row_q%d" % r] = Label("")
            self["row_q_bg%d" % r] = Pixmap()
        for n in ("info_sub", "sched_head", "sched_now", "info_note"):
            self[n] = Label("")
        for n in ("info_logo", "sched_sel", "sched_track", "sched_fill"):
            self[n] = Pixmap()
        for k in range(SCHED_ROWS):
            self["sched_time%d" % k] = Label("")
            self["sched_title%d" % k] = Label("")
        for k in range(4):
            self["info_lab%d" % k] = Label("")
            self["info_val%d" % k] = Label("")
            self["info_line%d" % k] = Pixmap()
        # categories
        self._cat_rows = self._build_cat_rows()
        self._cat_current = self._cat_index_of(self.genre)
        self._cat_cursor = self._cat_current
        self._cat_focus = False
        # row EPG lane
        self._l3_gen = 0
        self._l3_jobs = queue.Queue()
        self._l3_cancel = None
        self._l3_row_layout = {}
        self._l3_info_logo = ""
        self._l3_focus_timer = eTimer()
        self._l3_focus_conn = None
        try:
            self._l3_focus_conn = self._l3_focus_timer.timeout.connect(self._l3_start_fetch)
        except Exception:
            self._l3_focus_timer.callback.append(self._l3_start_fetch)
        self._l3_info_timer = eTimer()
        self._l3_info_conn = None
        try:
            self._l3_info_conn = self._l3_info_timer.timeout.connect(self._l3_paint_info_now)
        except Exception:
            self._l3_info_timer.callback.append(self._l3_paint_info_now)
        self._l3_logo_timer = eTimer()
        self._l3_logo_conn = None
        try:
            self._l3_logo_conn = self._l3_logo_timer.timeout.connect(self._l3_paint_info_now)
        except Exception:
            self._l3_logo_timer.callback.append(self._l3_paint_info_now)
        self._l3_timer = eTimer()
        self._l3_timer_conn = None
        try:
            self._l3_timer_conn = self._l3_timer.timeout.connect(self._l3_drain)
        except Exception:
            self._l3_timer.callback.append(self._l3_drain)
        try:
            actions = self["actions"].actions
            actions["cancel"] = self._l3_cancel_key
        except Exception as exc:
            optional_failure("live3.cancel_bind", exc)
        self["yellow"].setText(_("Previous page"))
        self["blue"].setText(_("Next page"))
        self.onLayoutFinish.append(self._l3_layout_ready)
        self.onClose.append(self._l3_stop)

    # ---------------------------------------------------------------- basics
    def _sx(self):
        return float(getattr(self, "_grid_sx", 1.0) or 1.0), float(getattr(self, "_grid_sy", 1.0) or 1.0)

    def _move(self, name, x, y):
        sx, sy = self._sx()
        try:
            self[name].instance.move(ePoint(int(round(x * sx)), int(round(y * sy))))
        except Exception:
            pass

    def _show(self, name, visible):
        try:
            if visible:
                self[name].show()
            else:
                self[name].hide()
        except Exception:
            pass

    def _text(self, name, value):
        value = str(value or "")
        try:
            if str(self[name].getText() or "") != value:
                self[name].setText(value)
        except Exception:
            pass

    def _portal_id(self):
        p = self.profile or {}
        return "%s|%s" % (str(p.get("portal") or p.get("url") or "").rstrip("/").lower(), str(p.get("mac") or p.get("username") or ""))

    @staticmethod
    def _cid(item):
        return str((item or {}).get("id") or (item or {}).get("ch_id") or (item or {}).get("stream_id") or "")

    def _l3_layout_ready(self):
        self._paint_cats()
        for name in ("sched_sel", "sched_track", "sched_fill", "sched_now", "info_logo"):
            self._show(name, False)
        for r in range(ROWS):
            for n in ("row_q_bg%d", "row_q%d"):
                self._show(n % r, False)
        self._l3_timer.start(2000, False)
        self._l3_schedule_fetch()

    def _l3_stop(self):
        future = getattr(self, '_l3_logo_fit_future', None)
        if future is not None:
            future.cancel()
        try:
            if self._l3_cancel is not None:
                self._l3_cancel.set()
        except Exception:
            pass
        for _t in ("_l3_timer", "_l3_focus_timer", "_l3_info_timer", "_l3_logo_timer"):
            try:
                getattr(self, _t).stop()
            except Exception:
                pass
        for _c in ("_l3_focus_conn", "_l3_info_conn", "_l3_logo_conn"):
            try:
                conn = getattr(self, _c, None)
                if conn is not None:
                    conn.disconnect()
                setattr(self, _c, None)
            except Exception:
                pass
        try:
            if self._l3_timer_conn is not None:
                self._l3_timer_conn.disconnect()
        except Exception:
            pass
        self._l3_timer_conn = None
        for _tname, _cb in (
            ("_l3_timer", self._l3_drain),
            ("_l3_focus_timer", self._l3_start_fetch),
            ("_l3_info_timer", self._l3_paint_info_now),
            ("_l3_logo_timer", self._l3_paint_info_now),
        ):
            try:
                _tm = getattr(self, _tname, None)
                if _tm is not None and _cb in _tm.callback:
                    _tm.callback.remove(_cb)
            except Exception:
                pass

    # ----------------------------------------------------- inherited chrome
    def _apply_live_static_chrome(self):
        try:
            self._apply_live_chrome({
                "page": _asset("ultra_bg_clean_1920x1080.png"),
                "selected": _asset("live_clean_r376/selected_690x56.png"),
            })
            self._live_static_chrome_bound = True
        except Exception as exc:
            optional_failure("live3.static_chrome", exc)

    def _apply_live_action_footer_geometry(self):
        self._apply_shared_footer_geometry()

    def _refresh_live_epg(self):
        if getattr(self,"_screen_closed",False) or getattr(self,"_grid_images_suspended",False) or not self.grid_items:return
        for pos in range(min(ROWS,len(self.grid_items))):self._paint_row(pos)
        self._paint_info()
        self._l3_schedule_fetch()

    def _schedule_epg(self, item):
        # The row lane owns EPG on this screen (no duplicate per-focus request).
        return

    # ------------------------------------------------------------ categories
    def _build_cat_rows(self):
        rows = []
        try:
            clean = _ui()._clean_display_text
        except Exception:
            clean = lambda v, n=60: str(v or "")[:n]
        for g in getattr(self, "_live_categories", []) or []:
            gid = str(g.get("id") or g.get("genre_id") or g.get("category_id") or g.get("name") or g.get("title") or "")
            title = clean(g.get("title") or g.get("name") or g.get("category_name") or g.get("genre_name") or gid, 40)
            if gid:
                rows.append({"id": gid, "title": title or gid})
        if not any(r["id"] == str(self.genre) for r in rows):
            rows.insert(0, {"id": str(self.genre), "title": str(self.category_title or _("All channels"))[:40]})
        return rows

    def _cat_index_of(self, gid):
        for i, r in enumerate(self._cat_rows):
            if r["id"] == str(gid):
                return i
        return 0

    def _paint_cats(self):
        total = len(self._cat_rows)
        anchor = self._cat_cursor if self._cat_focus else self._cat_current
        top = (max(0, anchor) // CAT_ROWS) * CAT_ROWS
        for k in range(CAT_ROWS):
            idx = top + k
            self._text("cat_name%d" % k, self._cat_rows[idx]["title"] if idx < total else "")
        mark = anchor - top
        if 0 <= mark < CAT_ROWS and anchor < total:
            try:
                sel_path = _asset("live_clean_r376/cat_selected_276x56.png" if self._cat_focus else "live_clean_r376/cat_current_276x56.png")
                if getattr(self, "_l3_cat_sel_path", "") != sel_path:
                    self["cat_sel"].instance.setPixmapFromFile(sel_path)
                    self._l3_cat_sel_path = sel_path
            except Exception:
                pass
            self._move("cat_sel", 52, CAT_Y0 + mark * CAT_STEP)
            self._show("cat_sel", True)
        else:
            self._show("cat_sel", False)
        self._text("cat_head", (_("CATEGORIES") + ("  %d/%d" % (anchor + 1, total) if total > CAT_ROWS else "")))
        # channel focus marker is dimmed while the category column has focus
        self._show("selection", not self._cat_focus)
        if self._cat_focus and 0 <= anchor < total:
            self._paint_cat_info(anchor, total)

    def _paint_cat_info(self, idx, total):
        """While browsing categories the right panel names the focused one in full."""
        title = self._cat_rows[idx]["title"]
        info_key = (idx, total, title)
        if getattr(self, "_l3_cat_info_key", None) == info_key:
            return
        self._l3_cat_info_key = info_key
        self._text("channel_name", title)
        try:
            units = len(title)
            size = 28 if units <= 34 else (24 if units <= 42 else (21 if units <= 52 else 18))
            if gFont is not None and self["channel_name"].instance is not None:
                self["channel_name"].instance.setFont(_ultra_rfont("Regular", size))
        except Exception:
            pass
        self._text("info_sub", _("Category %d / %d  •  OK to open") % (idx + 1, total))
        self._show("info_logo", False)
        self._l3_info_logo = ""
        self._show("sched_head", False)
        for n in ("sched_sel", "sched_now", "sched_track", "sched_fill"):
            self._show(n, False)
        for k in range(SCHED_ROWS):
            self._show("sched_time%d" % k, False)
            self._show("sched_title%d" % k, False)
        for k in range(4):
            for n in ("info_lab%d", "info_val%d", "info_line%d"):
                self._show(n % k, False)
        self._text("info_note", _("UP/DOWN move  •  LEFT/RIGHT page  •  OK open  •  BACK exit"))

    def _leave_cat_focus(self):
        self._cat_focus = False
        self._cat_cursor = self._cat_current
        self._paint_cats()
        try:
            self._update_selection()
        except Exception as exc:
            optional_failure("live3.leave_cats", exc)

    def _cat_page(self, direction):
        total = len(self._cat_rows)
        if not total:
            return
        page = self._cat_cursor // CAT_ROWS
        last = (total - 1) // CAT_ROWS
        row = self._cat_cursor % CAT_ROWS
        if direction < 0:
            target = (page - 1) * CAT_ROWS + row if page > 0 else 0
        else:
            target = min(total - 1, (page + 1) * CAT_ROWS + row) if page < last else total - 1
        self._cat_cursor = max(0, min(total - 1, target))
        self._paint_cats()

    def _switch_category(self, idx):
        if not (0 <= idx < len(self._cat_rows)):
            return
        row = self._cat_rows[idx]
        self._cat_current = idx
        self._cat_cursor = idx
        if row["id"] == str(self.genre) and self.grid_items:
            self._leave_cat_focus()
            return
        self._cat_focus = False
        self._paint_cats()
        try:
            from . import ui as _u
            launch = _u.current_plugin_launch()
        except Exception:
            launch = None
        self.genre = row["id"]
        self.category_title = row["title"]
        # Invalidate every portal fetch that is still in flight for the old category.
        self._content_epoch = int(getattr(self, "_content_epoch", 0) or 0) + 1
        try:
            portal = str((self.profile or {}).get("portal") or "").rstrip("/").lower()
            self._nav_key = (portal, str(self.media_type), self.genre)
            self._session_nav_key = ((launch,) if launch is not None else tuple(self._session_nav_key[:1])) + tuple(self._nav_key)
        except Exception as exc:
            optional_failure("live3.nav_key", exc)
        try:
            us_clear(self._portal_page_cache)
        except Exception:
            pass
        self._portal_page_size = 0
        self._portal_total = 0
        try:
            with self._prepared_page_lock:
                us_clear(self._prepared_page_cache)
                us_clear(self._prepared_page_pending)
        except Exception:
            pass
        self.page = 1
        self.index = 0
        self._l3_remember_category(self.genre)
        self.load_page(1, 0)

    def _l3_remember_category(self, genre):
        """Persist the last Live category off the GUI thread (save_settings fsyncs).

        Only the newest value is written; unchanged values are skipped.
        """
        value = genre
        if getattr(self, "_l3_saved_genre", object()) == value:
            return
        self._l3_saved_genre = value
        with _REMEMBER_LOCK:
            _REMEMBER_STATE["value"] = value
            if _REMEMBER_STATE["running"]:
                return
            _REMEMBER_STATE["running"] = True

        def _worker():
            while True:
                with _REMEMBER_LOCK:
                    v = _REMEMBER_STATE["value"]
                    _REMEMBER_STATE["value"] = _REMEMBER_NONE
                    if v is _REMEMBER_NONE:
                        _REMEMBER_STATE["running"] = False
                        return
                try:
                    from .storage import save_settings as _ss
                    _ss({"live_last_category": v})
                except Exception as exc:
                    optional_failure("live3.remember_category", exc)

        try:
            threading.Thread(target=_worker, name="us-live-remember", daemon=True).start()
        except Exception as exc:
            with _REMEMBER_LOCK:
                _REMEMBER_STATE["running"] = False
            optional_failure("live3.remember_thread", exc)

    def _l3_cancel_key(self):
        """BACK: channels -> categories column; categories -> leave Live."""
        if getattr(self, "_live_menu_active", False):
            return
        if self._cat_focus:
            self.close()
            return
        self._cat_focus = True
        self._cat_cursor = self._cat_current
        self._paint_cats()

    # ------------------------------------------------------------ navigation
    # LEFT/RIGHT keep the classic page jump (previous / next page of channels).
    def move_left(self):
        if self._cat_focus:
            self._cat_page(-1)
            return
        us_func(PremiumLiveGridScreen.move_left)(self)

    def move_right(self):
        if self._cat_focus:
            self._cat_page(1)
            return
        us_func(PremiumLiveGridScreen.move_right)(self)

    def move_up(self):
        if self._cat_focus:
            if self._cat_rows:
                self._cat_cursor = (self._cat_cursor - 1) % len(self._cat_rows)
                self._paint_cats()
            return
        us_func(PremiumLiveGridScreen.move_up)(self)

    def move_down(self):
        if self._cat_focus:
            if self._cat_rows:
                self._cat_cursor = (self._cat_cursor + 1) % len(self._cat_rows)
                self._paint_cats()
            return
        us_func(PremiumLiveGridScreen.move_down)(self)

    def open_selected(self):
        if self._cat_focus:
            self._switch_category(self._cat_cursor)
            return
        us_func(PremiumLiveGridScreen.open_selected)(self)

    # --------------------------------------------------------------- rows
    def _render_grid(self):
        result = us_func(PremiumLiveGridScreen._render_grid)(self)
        try:
            for pos in range(ROWS):
                self._paint_row(pos)
        except Exception as exc:
            optional_failure("live3.render", exc)
        return result

    def _row_state(self, item):
        cid = self._cid(item)
        if not cid:
            return "none", None
        hit, data = _cache_get((self._portal_id(), cid))
        if not hit:
            return "pending", None
        if data and (data.get("events") or (data.get("summary") or {}).get("now")):
            return "events", data
        return "none", None

    def _paint_row(self, pos):
        if pos >= len(self.grid_items or []):
            self._show("row_q%d" % pos, False)
            self._show("row_q_bg%d" % pos, False)
            return
        q = self._quality_tag(self.grid_items[pos]) if (self._grid_settings or {}).get("show_quality_badges", True) else ""
        self._text("row_q%d" % pos, q)
        self._show("row_q%d" % pos, bool(q))
        self._show("row_q_bg%d" % pos, bool(q))

    @staticmethod
    def _quality_tag(item):
        raw = str((item or {}).get("name") or (item or {}).get("title") or "")
        try:
            q = str(quality_badges(raw) or "")
        except Exception:
            q = ""
        q = q.replace("\u2022", " ").split()
        if not q:
            return ""
        tag = q[0].upper()
        return tag if len(tag) <= 4 else ""

    # ------------------------------------------------------------ EPG lane
    # One visible-page request survives cursor moves and partial results.
    # The idle drain also checks expiry/recovery without remote-control input.
    def _l3_schedule_fetch(self):
        try:
            self._l3_focus_timer.stop()
            self._l3_focus_timer.start(300, True)
        except Exception:
            self._l3_start_fetch()

    def _l3_start_fetch(self):
        if (getattr(self, "_screen_closed", False)
                or getattr(self, "_grid_images_suspended", False) or not self.grid_items):
            return
        portal = self._portal_id()
        items = list(self.grid_items or [])
        sig = (portal, tuple(self._cid(item) for item in items))
        if sig != getattr(self, '_l3_retry_page', None):
            self._l3_retry_page = sig
            self._l3_retry_after = {}
        future = getattr(self, "_l3_fetch_future", None)
        if sig == getattr(self, "_l3_fetch_sig", None) and future is not None and not future.done():
            return
        if sig != getattr(self, '_l3_fetch_sig', None) and future is not None and not future.done():
            if self._l3_cancel is not None:self._l3_cancel.set()
            future.cancel()
            self._l3_gen += 1
            self._l3_fetch_future=None
            self._l3_fetch_sig=sig
        misses = []
        for pos, item in enumerate(items):
            cid = self._cid(item)
            retry=(getattr(self,"_l3_retry_after",{}) or {}).get(cid,0)
            if cid and time.monotonic()>=retry and not _cache_get((portal, cid))[0]:
                misses.append((pos, cid))
        if not misses:
            self._l3_timer.start(2000, False)
            return
        # Keep the page request running while the cursor moves. Restarting it
        # on every arrow is what left only the focused channel with a guide.
        self._l3_fetch_sig = sig
        self._l3_gen += 1
        gen = self._l3_gen
        try:
            if self._l3_cancel is not None:
                self._l3_cancel.set()
        except Exception:
            pass
        ev = threading.Event()
        self._l3_cancel = ev
        client = self.client
        jobs = self._l3_jobs
        many = getattr(client, "epg_many", None)

        def on_each(cid, rows):
            if ev.is_set():
                return
            if rows is not None:
                self._l3_store(portal, cid, rows)
            for pos, wanted in misses:
                if wanted == cid:
                    jobs.put((gen, pos))

        def worker():
            try:
                if not callable(many):
                    for pos, cid in misses:
                        if ev.is_set():
                            return
                        try:
                            rows = client.epg(cid, 10, cancel_event=ev) or []
                        except Exception:
                            jobs.put((gen, pos))
                            continue
                        on_each(cid, rows)
                    return
                tiered_epg_many(client, {cid: items[pos] for pos, cid in misses}, 10, ev, on_each)
            finally:
                jobs.put((gen, -1))

        try:
            self._l3_fetch_future=_EPG_EXECUTOR.submit(worker, _task_key="live3-epg:%x" % id(self), _replace_task_key=True)
            self._l3_timer.start(200, False)
        except Exception as exc:
            self._l3_fetch_future=None
            for _pos,cid in misses:self._l3_retry_after[cid]=time.monotonic()+15
            self._l3_timer.start(2000, False)
            optional_failure("live3.epg_submit", exc)

    def _em_start(self):
        # The 3-column screen already fetches the page guide (_l3_start_fetch);
        # only paint the marks from the shared cache here.
        self._em_paint()

    def _l3_store(self, portal, cid, rows):
        events = _events_from_rows(rows or [])
        if not events and rows:
            try:
                optional_failure("live3.epg_row_shape", Exception(repr(rows[0])[:400]))
            except Exception:
                pass
        summary = {}
        try:
            summary = epg_summary(rows or []) or {}
        except Exception:
            summary = {}
        if events or summary.get("now"):
            _cache_put((portal, cid), {"events": events[:24], "summary": summary}, _TTL_EVENTS)
            self._em_note(portal, cid, True)
        else:
            _cache_put((portal, cid), None, 45)
            self._em_note(portal, cid, False)

    def _l3_drain(self):
        if getattr(self, "_screen_closed", False):
            self._l3_stop()
            return
        done = False
        changed_selected = False
        while True:
            try:
                gen, pos = self._l3_jobs.get_nowait()
            except queue.Empty:
                break
            if gen != self._l3_gen:
                continue
            if pos < 0:
                done = True
                continue
            if 0<=pos<len(self.grid_items):
                cid=self._cid(self.grid_items[pos])
                if cid and not _cache_get((self._portal_id(),cid))[0]:
                    if not hasattr(self,"_l3_retry_after"):self._l3_retry_after={}
                    self._l3_retry_after[cid]=time.monotonic()+15
            if pos == int(self.index or 0):
                changed_selected = True
        if changed_selected:
            self._paint_info()
        try:
            self._em_paint()
        except Exception as exc:
            optional_failure("live3.epg_marks", exc)
        future=getattr(self,'_l3_fetch_future',None)
        if not done and future is not None and future.done() and self._l3_jobs.empty():
            done=True
        if done:
            self._l3_fetch_future=None
            # Errors may omit callbacks altogether. Back off unresolved rows,
            # then retry from the heartbeat rather than requiring an arrow key.
            retries = getattr(self, "_l3_retry_after", {})
            now = time.monotonic()
            for item in self.grid_items or []:
                cid = self._cid(item)
                if cid and not _cache_get((self._portal_id(), cid))[0]:
                    retries[cid] = now + 15
            self._l3_retry_after = retries
        if done or getattr(self,'_l3_fetch_future',None) is None or getattr(self,'_grid_images_suspended',False):
            self._l3_timer.start(2000, False)
        if not getattr(self, "_grid_images_suspended", False):
            _refresh_ready_epg(self)
            self._l3_start_fetch()

    def _update_selection(self):
        self._l3_cat_info_key = None  # channel selection repaints the info widgets
        us_func(PremiumLiveGridScreen._update_selection)(self)
        # Cursor + title are already moved.  The heavy right-panel repaint (logo
        # decode, schedule widgets) waits until the key repeat settles.
        try:
            self._l3_info_timer.stop()
            self._l3_info_timer.start(150, True)
            self._l3_schedule_fetch()
        except Exception as exc:
            optional_failure("live3.info", exc)

    def _l3_paint_info_now(self):
        if getattr(self, "_screen_closed", False):
            return
        try:
            self._paint_info()
        except Exception as exc:
            optional_failure("live3.info_paint", exc)

    def _l3_request_logo_fit(self, source, fit, cache_dir):
        if getattr(self, '_screen_closed', False):return False
        future=getattr(self, '_l3_logo_fit_future', None)
        key=(source,cache_dir)
        if key == getattr(self, '_l3_logo_fit_key', None) and future is not None:
            return not future.done()
        # Local image work must not queue behind provider EPG requests. One job
        # per source also prevents each 700ms poll from queuing another copy.
        self._l3_logo_fit_future=_PICON_FIT_EXECUTOR.submit(
            lambda: fit(source,cache_dir,(128,72)),
            _task_key='live3-logo:%x' % id(self),_replace_task_key=True)
        self._l3_logo_fit_key=key
        return True

    def _paint_info(self):
        if self._cat_focus or not self.grid_items:
            return
        idx = int(self.index or 0)
        if not (0 <= idx < len(self.grid_items)):
            return
        self._l3_cat_info_key = None
        item = self.grid_items[idx]
        # logo
        path = str((getattr(self, "_grid_slot_paths", {}) or {}).get(idx) or "")
        # Right-panel logo: exact 128x72 derivative of the ORIGINAL picon (the row
        # derivative is only 64x36 and would be stretched 2x = blocky).
        try:
            src = str((getattr(self, "_live_row_src", {}) or {}).get(idx) or "")
            if src and os.path.isfile(src):
                from .ui_artwork_helpers import _live_row_fit_cached
                u = _ui()
                big = _live_row_fit_cached(src, u.PERSISTENT_GENERATED_DIR, (128, 72))
                if big:
                    path = big
                else:
                    fit = u._fit_live_row_picon_canvas
                    cache_dir = u.PERSISTENT_GENERATED_DIR
                    if self._l3_request_logo_fit(src, fit, cache_dir):
                        self._l3_logo_timer.stop()
                        self._l3_logo_timer.start(700, True)
        except Exception as exc:
            optional_failure("live3.info_logo_fit", exc)
        if path and os.path.isfile(path) and "placeholder" not in os.path.basename(path):
            if path != self._l3_info_logo:
                try:
                    self["info_logo"].instance.setPixmapFromFile(path)
                    self._l3_info_logo = path
                except Exception:
                    pass
            self._show("info_logo", True)
        else:
            self._show("info_logo", False)
            self._l3_info_logo = ""
        number = max(1, (int(self.page or 1) - 1) * int(self.page_size or 1) + idx + 1)
        self._text("info_sub", "%s  •  %s" % (str(self.category_title or "")[:40], _("Channel %d") % number))
        state, data = self._row_state(item)
        cur, pct = _now_state(data) if state == "events" else (-1, 0)
        if state == "events":
            if not data.get("events"):
                summ = data.get("summary") or {}
                if summ.get("now"):
                    data = {"fake": True, "events": [(int(time.time()), 0, summ.get("now"))] + ([(0, 0, summ.get("next"))] if summ.get("next") else [])}
                    cur, pct = 0, int(summ.get("percent") or 0)
            self._paint_schedule(data, cur, pct)
        else:
            self._paint_channel_info(item, state)

    def _paint_schedule(self, data, cur, pct):
        for k in range(4):
            for n in ("info_lab%d", "info_val%d", "info_line%d"):
                self._show(n % k, False)
        self._text("info_note", "")
        self._text("sched_head", _("TODAY"))
        self._show("sched_head", True)
        events = data.get("events") or []
        start = max(0, (cur if cur >= 0 else 0) - 1)
        if cur >= 0 and len(events) - start < SCHED_ROWS:
            start = max(0, len(events) - SCHED_ROWS)
        now_row = -1
        for k in range(SCHED_ROWS):
            i = start + k
            if i < len(events):
                s, _e, t = events[i]
                self._text("sched_time%d" % k, time.strftime("%H:%M", time.localtime(s)) if s else "")
                self._text("sched_title%d" % k, t)
                self._show("sched_time%d" % k, True)
                self._show("sched_title%d" % k, True)
                if i == cur:
                    now_row = k
            else:
                self._text("sched_time%d" % k, "")
                self._text("sched_title%d" % k, "")
        if now_row >= 0:
            y = SCHED_Y0 + now_row * SCHED_STEP
            self._move("sched_sel", 1094, y - 6)
            self._move("sched_now", 1780, y)
            self._move("sched_track", 1196, y + 36)
            self._move("sched_fill", 1196, y + 36)
            self._text("sched_now", _("NOW"))
            sx, sy = self._sx()
            width = int(round(STRACK_W * pct / 100.0))
            if pct > 0:
                width = max(8, width)  # a just-started programme still shows a visible stub
            if width > 0:
                try:
                    inst = self["sched_fill"].instance
                    try:inst.setScale(1)
                    except Exception:pass
                    inst.resize(eSize(max(1, int(width * sx)), max(1, int(7 * sy))))
                except Exception:
                    pass
            for n in ("sched_sel", "sched_now"):
                self._show(n, True)
            self._show("sched_track", not data.get("fake"))
            self._show("sched_fill", width > 0)
        else:
            for n in ("sched_sel", "sched_now", "sched_track", "sched_fill"):
                self._show(n, False)

    def _paint_channel_info(self, item, state):
        self._show("sched_head", False)
        for n in ("sched_sel", "sched_now", "sched_track", "sched_fill"):
            self._show(n, False)
        for k in range(SCHED_ROWS):
            self._show("sched_time%d" % k, False)
            self._show("sched_title%d" % k, False)
        raw = str(item.get("name") or item.get("title") or "")
        try:
            quality = str(quality_badges(raw) or "")
        except Exception:
            quality = ""
        archive = bool(item.get("allow_archive") or item.get("tv_archive_duration") or item.get("archive") or item.get("tv_archive"))
        fav = False
        try:
            fav = bool(((getattr(self, "_grid_item_state", {}) or {}).get(id(item), {}) or {}).get("favorite"))
        except Exception:
            fav = False
        number = max(1, (int(self.page or 1) - 1) * int(self.page_size or 1) + int(self.index or 0) + 1)
        rows = ((_("Quality"), quality or _("Auto")),
                (_("Catch-up"), _("Available") if archive else _("Not available")),
                (_("Favorite"), _("Yes") if fav else _("No")),
                (_("Channel number"), str(number)))
        for k, (lab, val) in enumerate(rows):
            self._text("info_lab%d" % k, lab)
            self._text("info_val%d" % k, val)
            for n in ("info_lab%d", "info_val%d", "info_line%d"):
                self._show(n % k, True)
        if state == "pending":
            self._text("info_note", _("Loading programme guide…"))
        else:
            self._text("info_note", _("No programme guide from the provider for this channel"))


# ---------------------------------------------------------------------------
# R5.67: Home -> Live opens this screen directly (no Categories page at all).

def _cat_gid(e):
    return str(e.get("id") or e.get("genre_id") or e.get("category_id") or e.get("name") or e.get("title") or "*")


def filtered_live_categories(profile, rows):
    """Same visibility rules the Categories page applies (hidden / adult /
    empty / parental) so the left column never shows something it would hide."""
    from .storage import load_settings
    from .category_visibility import category_id, hidden_ids
    try:
        from .core.parental import is_unlocked
    except Exception:
        is_unlocked = lambda: False
    cfg = load_settings() or {}
    try:
        hidden = set(hidden_ids(cfg, profile, "itv") or [])
    except Exception:
        hidden = set()
    protected = set((cfg.get("protected_categories", {}) or {}).get("itv", []) or [])
    words = list(cfg.get("adult_keywords", []) or [])
    empty = set((cfg.get("empty_categories", {}) or {}).get("itv", []) or [])
    lock = bool(cfg.get("parental_lock"))
    mode = str(cfg.get("parental_mode", "pin"))
    pin_locked = lock and mode == "pin" and not is_unlocked()
    out = []
    for e in rows or []:
        if not isinstance(e, dict):
            continue
        try:
            gid = category_id(e)
        except Exception:
            gid = _cat_gid(e)
        text = us_casefold(str(e.get("name") or e.get("title") or ""))
        adult = any(us_casefold(str(w)) in text for w in words if w)
        sensitive = gid in protected or _cat_gid(e) in protected or adult
        if lock and mode == "hide" and sensitive:
            continue
        if (not lock) and cfg.get("hide_adult", True) and adult:
            continue
        if gid in hidden:
            continue
        if pin_locked and sensitive:
            continue
        out.append(dict(e))
    return out


_DIRECT_PENDING = []


def _open_with_rows(session, profile, client, rows):
    rows = filtered_live_categories(profile, rows)
    if not rows:
        return False
    from .storage import load_settings
    last = str((load_settings() or {}).get("live_last_category") or "")
    pick = 0
    if last:
        for i, e in enumerate(rows):
            if _cat_gid(e) == last:
                pick = i
                break
    entry = rows[pick]
    try:
        clean = _ui()._clean_display_text
    except Exception:
        clean = lambda v, n=100: str(v or "")[:n]
    title = clean(entry.get("title") or entry.get("name") or entry.get("category_name") or entry.get("genre_name") or _("Live TV"), 100) or _("Live TV")
    session.open(PremiumLiveColumnsScreen, profile, client, "itv", _cat_gid(entry), title, rows)
    return True


def open_live_direct(session, profile, client, fallback):
    """Open the 3-column Live screen straight from Home.

    Cached categories open instantly; otherwise they load in the background and
    the screen opens when ready.  Any failure falls back to the classic path."""
    try:
        cached = _ui()._category_cache_get(profile, "itv")
    except Exception:
        cached = None
    if cached:
        try:
            if _open_with_rows(session, profile, client, cached):
                return True
        except Exception as exc:
            optional_failure("live3.direct_cached", exc)
        fallback()
        return True

    result = {}

    def work():
        try:
            rows = client.genres("itv") or []
            rows = [dict(x) for x in rows if isinstance(x, dict)]
            if rows:
                try:
                    _ui()._category_cache_put(profile, "itv", rows)
                except Exception:
                    pass
            result["rows"] = rows
        except Exception as exc:
            result["error"] = exc

    timer = eTimer()
    holder = {"timer": timer, "conn": None, "ticks": 0}

    def poll():
        holder["ticks"] += 1
        if "rows" not in result and "error" not in result and holder["ticks"] < 150:
            return
        try:
            timer.stop()
        except Exception:
            pass
        try:
            if holder.get("conn") is not None:
                holder["conn"].disconnect()
                holder["conn"] = None
        except Exception:
            pass
        try:
            if poll in timer.callback:
                timer.callback.remove(poll)
        except Exception:
            pass
        try:
            _DIRECT_PENDING.remove(holder)
        except ValueError:
            pass
        try:
            if result.get("rows") and _open_with_rows(session, profile, client, result["rows"]):
                return
        except Exception as exc:
            optional_failure("live3.direct_loaded", exc)
        fallback()

    try:
        holder["conn"] = timer.timeout.connect(poll)
    except Exception:
        timer.callback.append(poll)
    _DIRECT_PENDING.append(holder)
    threading.Thread(target=work, name="ultrastalker-live-direct", daemon=True).start()
    timer.start(100, False)
    return True
