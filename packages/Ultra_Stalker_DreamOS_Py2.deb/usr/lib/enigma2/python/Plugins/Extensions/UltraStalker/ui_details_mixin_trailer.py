# -*- coding: utf-8 -*-
"""Trailer identity, cache, stream and playback.

Methods moved verbatim out of ``ContentDetailsScreen`` (ui_screens_details.py); behaviour is unchanged.
This module is imported by ui_screens_details.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, max, min
from .ui_screens_details import (
    TMDBClient,
    _,
    _details_is_arabic_work,
    os,
    reactor,
    resolve_youtube_trailer,
    threading,
    trailer_from_rows,
    weakref,
)


class DetailsTrailerMixin(object):
    """Trailer identity, cache, stream and playback."""

    def _verified_trailer_identity(self):
        """Return only the canonical TMDb identity already owned by Details."""
        rows=(getattr(self,"_tmdb_data",None),getattr(self,"_local_detail_cache",None))
        for row in rows:
            if not isinstance(row,dict):continue
            value=row.get("tmdb_id")
            if value not in (None,""):
                try:return int(value)
                except Exception:continue
        for row in (getattr(self,"item",None),getattr(self,"_portal_item",None)):
            if not isinstance(row,dict):continue
            for key in ("_locked_tmdb_id","_ultra_search_verified_tmdb_id"):
                value=row.get(key)
                if value not in (None,""):
                    try:return int(value)
                    except Exception:continue
            if row.get("identity_verified") or row.get("identity_pointer_verified"):
                value=row.get("tmdb_id")
                if value not in (None,""):
                    try:return int(value)
                    except Exception:continue
        return None

    def _trailer_language_policy(self):
        """Return the exact-id trailer language policy for this work.

        R126 changes only Arabic-origin works: Arabic is requested first.  All
        other titles keep the established English fallback policy so this does
        not perturb the working R124/R125 trailer resolver path.
        """
        rows=(getattr(self,"_tmdb_data",None),getattr(self,"_local_detail_cache",None),getattr(self,"item",None))
        merged={}
        for row in reversed(rows):
            if isinstance(row,dict):merged.update(row)
        original=str(merged.get("original_language") or "").strip().lower().replace("_","-")
        if original=="ar" or original.startswith("ar-"):
            return "ar-EG","ar"
        # Some provider rows omit original_language but retain origin country.
        try:
            if _details_is_arabic_work(merged,""):
                return "ar-EG","ar"
        except Exception:
            pass
        return "en-US","en"

    def _cached_trailer_state(self):
        rows=(getattr(self,"_tmdb_data",None),getattr(self,"_local_detail_cache",None),getattr(self,"item",None))
        trailer=trailer_from_rows(*rows)
        checked=False
        policy_checked=""
        for row in rows:
            if not isinstance(row,dict):continue
            if row.get("_trailer_checked"):checked=True
            value=str(row.get("trailer_policy_language") or "").strip().lower().split("-",1)[0]
            if value:policy_checked=value
        _locale,preferred=self._trailer_language_policy()
        # Existing R125 caches may contain a foreign trailer chosen by the old
        # English-biased policy.  Re-query exact TMDb /videos once for Arabic
        # works, then remember that the Arabic preference has been evaluated.
        if preferred=="ar" and policy_checked!="ar":
            if trailer:
                cached_lang=str(trailer.get("language") or "").strip().lower().split("-",1)[0]
                if cached_lang!="ar":
                    return {},False
            elif checked:
                # R125 may also have cached a negative English-policy lookup.
                # Give Arabic-origin works one exact-id Arabic-policy retry.
                return {},False
        return trailer,checked

    def _remember_trailer_session(self,trailer):
        if not isinstance(trailer,dict) or not trailer.get("key"):return
        _policy_locale,policy_language=self._trailer_language_policy()
        payload={
            "_trailer_checked":True,"trailer_site":"YouTube",
            "trailer_key":str(trailer.get("key") or ""),
            "trailer_name":str(trailer.get("name") or "Trailer"),
            "trailer_url":str(trailer.get("url") or ""),
            "trailer_official":bool(trailer.get("official")),
            "trailer_language":str(trailer.get("language") or ""),
            "trailer_policy_language":str(trailer.get("policy_language") or policy_language or ""),
        }
        for attr in ("_tmdb_data","_local_detail_cache"):
            row=getattr(self,attr,None)
            if isinstance(row,dict):row.update(payload)
        if isinstance(getattr(self,"item",None),dict):
            self.item.update(payload)

    def _open_trailer_stream(self,stream_url,trailer):
        stream_url=str(stream_url or "").strip()
        if not stream_url:return
        try:
            title=str(self["name"].getText() or self.item.get("name") or self.item.get("title") or "").strip()
        except Exception:
            title=str((self.item or {}).get("name") or (self.item or {}).get("title") or "").strip()
        trailer_title=(title+" • "+_("Trailer")) if title else str((trailer or {}).get("name") or _("Trailer"))
        def closed(result=None):
            try:self._restore_details_visual_state()
            except Exception as exc:optional_failure("ui.detail_trailer_restore",exc)
            try:
                if isinstance(result,dict) and result.get("state")=="failed":self["status"].setText(_("Trailer playback failed"))
                else:self["status"].setText("")
            except Exception:pass
        # R132: the working TMBD resolver still supplies the exact 1080/720
        # video+suburi stream, but UltraStalkerPlayer now owns playback.  This
        # gives Trailer the same STOP/EXIT/service-restore lifecycle as normal
        # plugin playback and prevents the last trailer frame sticking on TV.
        # R151: Trailer is playback-only, but its visual identity is always the
        # exact movie/series that launched it.  Build the handoff through the
        # normal VOD/Series artwork path for *every* source type (Portal, Xtream
        # and raw M3U), then strip resume/history state so the trailer itself can
        # never become Continue Watching/history.
        parent_media="series" if self.media_type in ("series","episode") else "vod"
        payload=_player_payload(self.item,self.profile,media_type=parent_media)
        for key in ("_resume_position","_resume_duration","_history_item","_quality_parent_item"):
            payload.pop(key,None)
        payload["_trailer_parent_media_type"]=parent_media
        payload["_player_client_ref"]=self.client
        try:
            _state=dict(getattr(self,"_details_visual_state",{}) or {})
            _player_palette_source=str(
                getattr(self,"_adaptive_source_local","") or
                getattr(self,"_adaptive_authoritative_source","") or
                getattr(self,"_poster_authoritative_source","") or
                _state.get("poster") or _state.get("detail_poster") or ""
            )
            if _player_palette_source and os.path.isfile(_player_palette_source):
                payload["_player_poster"]=_player_palette_source
                payload["_adaptive_source_local"]=_player_palette_source
                payload["_ultra_palette_source"]=_player_palette_source
                if getattr(self,"_entry_visible_poster_locked",False):
                    payload["_ultra_visible_poster_locked"]=True
                    if isinstance(self.item,dict) and self.item.get("_player_poster_identity"):
                        payload["_player_poster_identity"]=self.item.get("_player_poster_identity")
        except Exception as exc:optional_failure("ui.detail_trailer_palette_handoff",exc)

        # Details is the current visual authority.  Reinforce the exact poster
        # and verified TMDb id already on this work before opening the Player.
        # This is HDD/session handoff only: no title/year guessing is introduced.
        tmdb_data=getattr(self,"_tmdb_data",None)
        if isinstance(tmdb_data,dict):
            poster_local=str(tmdb_data.get("poster_local") or "")
            existing=str(payload.get("_player_poster") or "")
            if not (existing and os.path.isfile(existing)) and poster_local and os.path.isfile(poster_local):
                payload["_player_poster"]=poster_local
            if tmdb_data.get("poster_url") and not payload.get("_player_poster_url"):
                payload["_player_poster_url"]=str(tmdb_data.get("poster_url"))
            verified_id=tmdb_data.get("tmdb_id") or (self.item.get("_locked_tmdb_id") if isinstance(self.item,dict) else None)
            if verified_id not in (None,""):
                payload["_player_title_logo_tmdb_id"]=verified_id
                payload["_locked_tmdb_id"]=verified_id
                payload["tmdb_id"]=verified_id
            payload["_player_title_logo_title"]=str(getattr(self,"_server_display_name","") or title)
        self.session.openWithCallback(closed,UltraStalkerPlayer,stream_url,trailer_title,"trailer",4097,payload)

    def _cancel_trailer_request(self):
        try:self._trailer_cancel_event.set()
        except Exception:pass
        self._trailer_busy=False
        self._trailer_token=int(getattr(self,"_trailer_token",0) or 0)+1

    def _set_trailer_button_state(self,loading=False):
        try:self["red"].setText(_("Loading...") if loading else _("Trailer"))
        except Exception:pass

    def play_trailer(self):
        """Play the exact TMDb trailer on a dedicated worker lane.

        Trailer lookup must never be blocked by Details' general _busy flag.
        Provider metadata, artwork and late series-count jobs are unrelated to
        the red key and may legitimately still be running when the user presses it.
        """
        if getattr(self,"_trailer_busy",False):
            try:self["status"].setText(_("Loading trailer..."))
            except Exception:pass
            return
        tmdb_id=self._verified_trailer_identity()
        if tmdb_id in (None,""):
            try:
                self["status"].setText(_("Trailer information is still loading"))
                self._set_trailer_button_state(False)
            except Exception:pass
            return
        cached,checked=self._cached_trailer_state()
        if checked and not cached:
            try:self["status"].setText(_("No trailer available"))
            except Exception:pass
            return

        self._trailer_busy=True
        self._trailer_token=int(getattr(self,"_trailer_token",0) or 0)+1
        token=self._trailer_token
        try:
            old_event=getattr(self,"_trailer_cancel_event",None)
            if old_event is not None:old_event.set()
        except Exception:pass
        cancel_event=threading.Event();self._trailer_cancel_event=cancel_event
        self._set_trailer_button_state(True)
        try:self["status"].setText(_("Loading trailer..."))
        except Exception:pass

        media="tv" if self.media_type=="series" else "movie"
        cfg=load_settings() or {}
        credential=str(cfg.get("tmdb_credential") or "").strip()
        timeout=min(12,max(5,int(cfg.get("timeout",10) or 10)))
        trailer_locale,trailer_language=self._trailer_language_policy()
        owner_ref=weakref.ref(self)

        def worker():
            result={"state":"failed"}
            try:
                trailer=dict(cached or {})
                if cancel_event.is_set():return
                if not trailer:
                    if not credential or not cfg.get("tmdb_enabled",True):
                        result={"state":"missing"}
                    else:
                        client=TMDBClient(credential,trailer_locale,timeout)
                        payload=client._get("/%s/%s/videos"%(media,int(tmdb_id)),{"include_video_language":",".join(dict.fromkeys([str(trailer_locale or "en").split("-",1)[0].lower() or "en","en","null"]))}) or {}
                        from .details_authority import _pick_tmdb_youtube_trailer
                        picked=_pick_tmdb_youtube_trailer(payload,trailer_locale)
                        if not picked:
                            result={"state":"missing"}
                        else:
                            trailer={
                                "site":"YouTube","key":str(picked.get("trailer_key") or ""),
                                "name":str(picked.get("trailer_name") or "Trailer"),
                                "url":str(picked.get("trailer_url") or ""),
                                "official":bool(picked.get("trailer_official")),
                                "language":str(picked.get("trailer_language") or ""),
                                "policy_language":trailer_language,
                            }
                if result.get("state")=="failed" and trailer:
                    if not trailer.get("key"):
                        result={"state":"missing"}
                    else:
                        stream=resolve_youtube_trailer(trailer.get("key"),timeout=max(15,timeout+5),cancel_event=cancel_event)
                        if cancel_event.is_set():return
                        result={"state":"ready","trailer":trailer,"stream":stream} if stream else {"state":"resolver_unavailable","trailer":trailer}
            except Exception as exc:
                result={"state":"error","error":exc}
            if cancel_event.is_set():return
            def deliver():
                owner=owner_ref()
                if owner is None or getattr(owner,"_screen_closed",False):return
                if token!=int(getattr(owner,"_trailer_token",0) or 0):return
                owner._trailer_busy=False
                owner._set_trailer_button_state(False)
                state=str(result.get("state") or "")
                trailer=result.get("trailer") if isinstance(result.get("trailer"),dict) else {}
                if state=="missing":
                    for row in (getattr(owner,"_tmdb_data",None),getattr(owner,"_local_detail_cache",None),getattr(owner,"item",None)):
                        if isinstance(row,dict):
                            row["_trailer_checked"]=True
                            row["trailer_policy_language"]=trailer_language
                    try:owner["status"].setText(_("No trailer available"))
                    except Exception:pass
                    return
                if trailer:owner._remember_trailer_session(trailer)
                if state!="ready" or not result.get("stream"):
                    if state=="error":
                        try:optional_failure("ui.detail_trailer",result.get("error"))
                        except Exception:pass
                    try:owner["status"].setText(_("Trailer found, but no native 1080p/720p stream is available"))
                    except Exception:pass
                    return
                try:owner["status"].setText(_("Opening trailer..."))
                except Exception:pass
                try:owner._open_trailer_stream(result.get("stream"),trailer)
                except Exception as exc:
                    optional_failure("ui.detail_trailer_open",exc)
                    try:owner["status"].setText(_("Trailer playback failed"))
                    except Exception:pass
            try:reactor.callFromThread(deliver)
            except Exception:
                # This path should be rare, but keeping a GUI delivery fallback
                # prevents a dead-looking red key on images with a nonstandard reactor.
                try:deliver()
                except Exception:pass

        try:
            thread=threading.Thread(target=worker,name="UltraTrailerResolve")
            thread.daemon=True
            thread.start()
        except Exception as exc:
            self._trailer_busy=False
            self._set_trailer_button_state(False)
            optional_failure("ui.detail_trailer_thread",exc)
            try:self["status"].setText(_("Trailer playback failed"))
            except Exception:pass
