# -*- coding: utf-8 -*-
"""Trailer identity, cache, stream and playback."""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, max, min
from .ui_screens_details import (
    TMDBClient,
    _,
    _details_is_arabic_work,
    os,
    reactor,
    resolve_youtube_trailer,
    threading,
    trailer_from_rows,
    weakref,
)


class DetailsTrailerMixin(object):
    """Trailer identity, cache, stream and playback."""

    def _verified_trailer_identity(self):
        """Return the canonical TMDb identity already owned by Details or local cache."""
        rows=(
            getattr(self,"_tmdb_data",None),
            getattr(self,"_local_detail_cache",None),
            getattr(self,"series_item",None),
            getattr(self,"item",None),
            getattr(self,"_portal_item",None),
        )
        for row in rows:
            if not isinstance(row,dict):continue
            for key in ("_locked_tmdb_id","_ultra_search_verified_tmdb_id","tmdb_id","tmdbid","tmdb"):
                value=row.get(key)
                if value not in (None,""):
                    sval=str(value).strip()
                    if sval.isdigit():
                        try:return int(sval)
                        except Exception:continue
        try:
            target_item=getattr(self,"series_item",None) or getattr(self,"_portal_item",None) or getattr(self,"item",None) or {}
            if isinstance(target_item,dict):
                from .artwork_v2 import load_fast_local_poster, load_manifest
                for loader in (load_fast_local_poster, load_manifest):
                    snap=loader(self.profile,self.media_type,target_item) or {}
                    val=snap.get("tmdb_id") if isinstance(snap,dict) else None
                    if val not in (None,"") and str(val).strip().isdigit():
                        return int(str(val).strip())
        except Exception:
            pass
        return None

    def _trailer_language_policy(self):
        """Return the exact-id trailer language policy for this work."""
        rows=(getattr(self,"_tmdb_data",None),getattr(self,"_local_detail_cache",None),getattr(self,"series_item",None),getattr(self,"item",None))
        merged={}
        for row in reversed(rows):
            if isinstance(row,dict):merged.update(row)
        original=str(merged.get("original_language") or "").strip().lower().replace("_","-")
        if original=="ar" or original.startswith("ar-"):
            return "ar-EG","ar"
        try:
            if _details_is_arabic_work(merged,""):
                return "ar-EG","ar"
        except Exception:
            pass
        if original and len(original)>=2:
            short=original.split("-",1)[0]
            if short not in ("en","ar"):
                return original,short
        return "en-US","en"

    def _cached_trailer_state(self):
        rows=(getattr(self,"_tmdb_data",None),getattr(self,"_local_detail_cache",None),getattr(self,"series_item",None),getattr(self,"item",None))
        trailer=trailer_from_rows(*rows)
        checked=False
        policy_checked=""
        for row in rows:
            if not isinstance(row,dict):continue
            if row.get("_trailer_checked"):checked=True
            value=str(row.get("trailer_policy_language") or "").strip().lower().split("-",1)[0]
            if value:policy_checked=value
        _locale,preferred=self._trailer_language_policy()
        if preferred=="ar" and policy_checked!="ar":
            if trailer:
                cached_lang=str(trailer.get("language") or "").strip().lower().split("-",1)[0]
                if cached_lang!="ar":
                    return {},False
            elif checked:
                return {},False
        return trailer,checked

    def _remember_trailer_session(self,trailer):
        if not isinstance(trailer,dict) or not trailer.get("key"):return
        _policy_locale,policy_language=self._trailer_language_policy()
        payload={
            "_trailer_checked":True,"trailer_site":"YouTube",
            "trailer_key":str(trailer.get("key") or ""),
            "trailer_name":str(trailer.get("name") or "Trailer"),
            "trailer_url":str(trailer.get("url") or ""),
            "trailer_official":bool(trailer.get("official")),
            "trailer_language":str(trailer.get("language") or ""),
            "trailer_policy_language":str(trailer.get("policy_language") or policy_language or ""),
        }
        for attr in ("_tmdb_data","_local_detail_cache","series_item"):
            row=getattr(self,attr,None)
            if isinstance(row,dict):row.update(payload)
        if isinstance(getattr(self,"item",None),dict):
            self.item.update(payload)

    def _open_trailer_stream(self,stream_url,trailer,fallback_urls=None):
        stream_url=str(stream_url or "").strip()
        if not stream_url:return
        base_item=getattr(self,"series_item",None) if isinstance(getattr(self,"series_item",None),dict) else self.item
        try:
            title=str(self["name"].getText() or (base_item or {}).get("name") or (base_item or {}).get("title") or "").strip()
        except Exception:
            title=str((base_item or {}).get("name") or (base_item or {}).get("title") or "").strip()
        trailer_title=(title+" • "+_("Trailer")) if title else str((trailer or {}).get("name") or _("Trailer"))
        def closed(result=None):
            try:self._restore_details_visual_state()
            except Exception as exc:optional_failure("ui.detail_trailer_restore",exc)
            try:
                if isinstance(result,dict) and result.get("state")=="failed":self["status"].setText(_("Trailer playback failed"))
                else:self["status"].setText("")
            except Exception:pass
        parent_media="series" if self.media_type in ("series","episode") else "vod"
        payload=_player_payload(base_item,self.profile,media_type=parent_media)
        for key in ("_resume_position","_resume_duration","_history_item","_quality_parent_item"):
            payload.pop(key,None)
        payload["_trailer_parent_media_type"]=parent_media
        payload["_player_client_ref"]=self.client
        if fallback_urls:
            payload["_trailer_fallback_urls"]=[str(u) for u in fallback_urls if str(u or "").strip() and str(u)!=stream_url]
        try:
            _state=dict(getattr(self,"_details_visual_state",{}) or {})
            _player_palette_source=str(
                getattr(self,"_adaptive_source_local","") or
                getattr(self,"_adaptive_authoritative_source","") or
                getattr(self,"_poster_authoritative_source","") or
                _state.get("poster") or _state.get("detail_poster") or ""
            )
            if _player_palette_source and os.path.isfile(_player_palette_source):
                payload["_player_poster"]=_player_palette_source
                payload["_adaptive_source_local"]=_player_palette_source
                payload["_ultra_palette_source"]=_player_palette_source
                if getattr(self,"_entry_visible_poster_locked",False):
                    payload["_ultra_visible_poster_locked"]=True
                    if isinstance(base_item,dict) and base_item.get("_player_poster_identity"):
                        payload["_player_poster_identity"]=base_item.get("_player_poster_identity")
        except Exception as exc:optional_failure("ui.detail_trailer_palette_handoff",exc)

        tmdb_data=getattr(self,"_tmdb_data",None)
        if isinstance(tmdb_data,dict):
            poster_local=str(tmdb_data.get("poster_local") or "")
            existing=str(payload.get("_player_poster") or "")
            if not (existing and os.path.isfile(existing)) and poster_local and os.path.isfile(poster_local):
                payload["_player_poster"]=poster_local
            if tmdb_data.get("poster_url") and not payload.get("_player_poster_url"):
                payload["_player_poster_url"]=str(tmdb_data.get("poster_url"))
            verified_id=tmdb_data.get("tmdb_id") or (base_item.get("_locked_tmdb_id") if isinstance(base_item,dict) else None)
            if verified_id not in (None,""):
                payload["_player_title_logo_tmdb_id"]=verified_id
                payload["_locked_tmdb_id"]=verified_id
                payload["tmdb_id"]=verified_id
            payload["_player_title_logo_title"]=str(getattr(self,"_server_display_name","") or title)
        self.session.openWithCallback(closed,UltraStalkerPlayer,stream_url,trailer_title,"trailer",4097,payload)

    def _cancel_trailer_request(self):
        try:self._trailer_cancel_event.set()
        except Exception:pass
        self._trailer_busy=False
        self._trailer_token=int(getattr(self,"_trailer_token",0) or 0)+1

    def _set_trailer_button_state(self,loading=False):
        try:self["red"].setText(_("Loading...") if loading else _("Trailer"))
        except Exception:pass

    def play_trailer(self):
        """Play the exact TMDb trailer on a dedicated worker lane."""
        if getattr(self,"_trailer_busy",False):
            try:self["status"].setText(_("Loading trailer..."))
            except Exception:pass
            return
        tmdb_id=self._verified_trailer_identity()
        cached,checked=self._cached_trailer_state()

        self._trailer_busy=True
        self._trailer_token=int(getattr(self,"_trailer_token",0) or 0)+1
        token=self._trailer_token
        try:
            old_event=getattr(self,"_trailer_cancel_event",None)
            if old_event is not None:old_event.set()
        except Exception:pass
        cancel_event=threading.Event();self._trailer_cancel_event=cancel_event
        self._set_trailer_button_state(True)
        try:self["status"].setText(_("Loading trailer..."))
        except Exception:pass

        media="tv" if self.media_type in ("series","episode") else "movie"
        cfg=load_settings() or {}
        credential=str(cfg.get("tmdb_credential") or "").strip()
        timeout=min(12,max(5,int(cfg.get("timeout",10) or 10)))
        trailer_locale,trailer_language=self._trailer_language_policy()
        target_item=dict(getattr(self,"series_item",None) or getattr(self,"_portal_item",None) or getattr(self,"item",None) or {})
        profile_copy=dict(getattr(self,"profile",{}) or {})
        owner_ref=weakref.ref(self)

        def worker():
            result={"state":"failed"}
            resolved_tid=tmdb_id
            try:
                if cancel_event.is_set():return
                if resolved_tid in (None,"") and credential and cfg.get("tmdb_enabled",True):
                    try:
                        from .artwork_v2_impl import ArtworkV2 as _ArtworkV2Impl
                        resolver=_ArtworkV2Impl(credential,cfg.get("tmdb_language","ar-EG"),timeout)
                        _mt,rid,_conf,_src,_cand=resolver._resolve_identity("series" if media=="tv" else "vod",target_item,{})
                        if not rid:
                            _rmt,rid,_rconf,_rseed,_rtr=resolver._resolve_poster_rescue("series" if media=="tv" else "vod",target_item)
                        if rid:resolved_tid=int(rid)
                    except Exception:pass
                    if resolved_tid in (None,""):
                        try:
                            enr=TMDBClient(credential,cfg.get("tmdb_language","ar-EG"),timeout).enrich("series" if media=="tv" else "vod",target_item,artwork_mode="metadata") or {}
                            if enr.get("tmdb_id"):resolved_tid=int(enr.get("tmdb_id"))
                        except Exception:pass
                if resolved_tid in (None,"") and not cached:
                    result={"state":"missing"}
                else:
                    candidates=[]
                    if cached and cached.get("key"):
                        candidates.append({
                            "site":"YouTube","key":str(cached.get("key") or ""),
                            "name":str(cached.get("name") or "Trailer"),
                            "url":str(cached.get("url") or ""),
                            "official":bool(cached.get("official")),
                            "language":str(cached.get("language") or ""),
                            "policy_language":trailer_language,
                        })
                    if not candidates and credential and cfg.get("tmdb_enabled",True) and resolved_tid not in (None,""):
                        client=TMDBClient(credential,trailer_locale,timeout)
                        langs=[]
                        for lcode in (str(trailer_locale or "en").split("-",1)[0].lower(),str(cfg.get("tmdb_language","ar-EG")).split("-",1)[0].lower(),"ar","en","null"):
                            if lcode and lcode not in langs:langs.append(lcode)
                        payload=client._get("/%s/%s/videos"%(media,int(resolved_tid)),{"include_video_language":",".join(langs)}) or {}
                        from .details_authority import _pick_tmdb_youtube_trailers
                        picked_list=_pick_tmdb_youtube_trailers(payload,trailer_locale,limit=4)
                        if not picked_list:
                            payload_all=client._get("/%s/%s/videos"%(media,int(resolved_tid)),{}) or {}
                            picked_list=_pick_tmdb_youtube_trailers(payload_all,trailer_locale,limit=4)
                        existing_keys=set(c.get("key") for c in candidates)
                        for picked in (picked_list or []):
                            pkey=str(picked.get("trailer_key") or "")
                            if pkey and pkey not in existing_keys:
                                existing_keys.add(pkey)
                                candidates.append({
                                    "site":"YouTube","key":pkey,
                                    "name":str(picked.get("trailer_name") or "Trailer"),
                                    "url":str(picked.get("trailer_url") or ""),
                                    "official":bool(picked.get("trailer_official")),
                                    "language":str(picked.get("trailer_language") or ""),
                                    "policy_language":trailer_language,
                                })
                    if not candidates:
                        result={"state":"missing","tmdb_id":resolved_tid}
                    else:
                        from .trailer_runtime import resolve_youtube_trailer_candidates
                        chosen_trailer=candidates[0]
                        streams=[]
                        for cand in candidates:
                            if cancel_event.is_set():return
                            streams=resolve_youtube_trailer_candidates(cand.get("key"),timeout=max(14,timeout+4),cancel_event=cancel_event)
                            if streams:
                                chosen_trailer=cand
                                break
                        if cancel_event.is_set():return
                        if streams:
                            result={"state":"ready","trailer":chosen_trailer,"stream":streams[0],"fallbacks":streams[1:],"tmdb_id":resolved_tid}
                        else:
                            result={"state":"resolver_unavailable","trailer":chosen_trailer,"tmdb_id":resolved_tid}
            except Exception as exc:
                result={"state":"error","error":exc}
            if cancel_event.is_set():return
            def deliver():
                owner=owner_ref()
                if owner is None or getattr(owner,"_screen_closed",False):return
                if token!=int(getattr(owner,"_trailer_token",0) or 0):return
                owner._trailer_busy=False
                owner._set_trailer_button_state(False)
                if result.get("tmdb_id") not in (None,""):
                    for row in (getattr(owner,"_tmdb_data",None),getattr(owner,"_local_detail_cache",None),getattr(owner,"series_item",None),getattr(owner,"item",None)):
                        if isinstance(row,dict) and not row.get("tmdb_id"):
                            row["tmdb_id"]=result.get("tmdb_id")
                            row["_locked_tmdb_id"]=result.get("tmdb_id")
                state=str(result.get("state") or "")
                trailer=result.get("trailer") if isinstance(result.get("trailer"),dict) else {}
                if state=="missing":
                    for row in (getattr(owner,"_tmdb_data",None),getattr(owner,"_local_detail_cache",None),getattr(owner,"item",None)):
                        if isinstance(row,dict):
                            row["_trailer_checked"]=True
                            row["trailer_policy_language"]=trailer_language
                    try:owner["status"].setText(_("No trailer available"))
                    except Exception:pass
                    return
                if trailer:owner._remember_trailer_session(trailer)
                if state!="ready" or not result.get("stream"):
                    if state=="error":
                        try:optional_failure("ui.detail_trailer",result.get("error"))
                        except Exception:pass
                    try:owner["status"].setText(_("Trailer found, but no native 1080p/720p stream is available"))
                    except Exception:pass
                    return
                try:owner["status"].setText(_("Opening trailer..."))
                except Exception:pass
                try:owner._open_trailer_stream(result.get("stream"),trailer,result.get("fallbacks"))
                except Exception as exc:
                    optional_failure("ui.detail_trailer_open",exc)
                    try:owner["status"].setText(_("Trailer playback failed"))
                    except Exception:pass
            try:reactor.callFromThread(deliver)
            except Exception:
                try:deliver()
                except Exception:pass

        try:
            thread=threading.Thread(target=worker,name="UltraTrailerResolve")
            thread.daemon=True
            thread.start()
        except Exception as exc:
            self._trailer_busy=False
            self._set_trailer_button_state(False)
            optional_failure("ui.detail_trailer_thread",exc)
            try:self["status"].setText(_("Trailer playback failed"))
            except Exception:pass
