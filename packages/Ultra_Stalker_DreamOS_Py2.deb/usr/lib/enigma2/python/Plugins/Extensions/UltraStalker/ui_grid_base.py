# -*- coding: utf-8 -*-
"""Premium grid base extracted from ui.py without changing class behavior."""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str, int, round, max, min, us_casefold, us_func
from . import _
from .ui_floating_notice import show_notice
from .age_rating import display_certification, certification_from_tmdb, rating_endpoint
from Screens.Screen import Screen
from .ui_async import AsyncScreenMixin
from .ui_grid_artwork import GridArtworkMixin
from .adaptive_mode import adaptive_enabled
from .ui_fixed_adaptive import fixed_home_assets, cleanup_legacy_application_outputs
threading = _us_env.threading
os = _us_env.os
time = _us_env.time
json = _us_env.json
import tempfile
import gc
import logging
import weakref
from .core.shared_executors import CATALOGUE_EXECUTOR, CACHE_IO_EXECUTOR, VISIBLE_ARTWORK_EXECUTOR, METADATA_EXECUTOR
from .core.runtime_log import diagnostic_breadcrumb as _ui_diag
from .core.call_compat import call_compatible
from .log import diagnostic_failure, memory_snapshot as _mem34
from .persistent_cache import durable_view_path
from twisted.internet import reactor
from .localization import localized_strftime as _lstrf
try:
    from .artwork_v2 import load_fast_local_poster as _direct_fast_local_poster
except Exception:
    _direct_fast_local_poster = None

def configure_grid_base(**deps):
    globals().update(deps)
    for _mixin_module in _MIXIN_MODULES:
        _mixin_module.__dict__.update(deps)
_GRID_PAGE_WARM_EXECUTOR = CATALOGUE_EXECUTOR
_VISIBLE_POSTER_HDD_EXECUTOR = CACHE_IO_EXECUTOR
_VISIBLE_POSTER_EXECUTOR = VISIBLE_ARTWORK_EXECUTOR
_VISIBLE_TMDB_EXECUTOR = METADATA_EXECUTOR

def _page_backdrop_q60_path(url):
    """Exact persistent Q60 path used by the R242/R262 Cinematic lane."""
    try:
        _hashlib = _us_env.hashlib
        from .persistent_cache import BACKDROPS
        text = str(url or '').strip()
        if not (text.startswith('https://image.tmdb.org/t/p/original/') or text.startswith('http://image.tmdb.org/t/p/original/')):
            return ''
        digest = _hashlib.sha1(text.encode('utf-8', 'ignore')).hexdigest()[:32]
        return os.path.join(BACKDROPS, digest + '.jpg')
    except Exception:
        return ''

def _page_backdrop_q60_valid(path):
    """True only for the persistent URL-hash Q60 files used by all 3 views.

    Legacy ArtworkV2 w1280 files can live in the same BACKDROPS directory, so a
    size-only check is unsafe here: BLUE must never call one of those "already".
    """
    try:
        _re = _us_env.re
        from .persistent_cache import BACKDROPS
        path = str(path or '').strip()
        if not (path and os.path.isfile(path) and (os.path.getsize(path) > 4096)):
            return False
        real = os.path.realpath(path)
        root = os.path.realpath(str(BACKDROPS or ''))
        if not root or not (real == root or real.startswith(root + os.sep)):
            return False
        return bool(_re.match('^(?:[0-9a-f]{32}|(?:movie|tv)_\\d+|fallback_[0-9a-f]+)\\.jpg$', os.path.basename(real), _re.I))
    except Exception:
        return False

def _page_backdrop_original_url(value):
    """Normalize a TMDb file_path/URL to the exact ORIGINAL authority URL."""
    try:
        _re = _us_env.re
        text = str(value or '').strip()
        if not text:
            return ''
        if text.startswith('/'):
            return 'https://image.tmdb.org/t/p/original' + text
        if 'image.tmdb.org/t/p/' not in text:
            return ''
        text = _re.sub('(/t/p/)(?:original|w\\d+|h\\d+)(/)', '\\1original\\2', text, count=1, flags=_re.I)
        return text if text.startswith(('https://', 'http://')) else ''
    except Exception:
        return ''

def _page_backdrop_build_q60(raw_path, destination):
    """Build the same at-most-1920x1080 JPEG quality-60 file as Cinematic.

    This helper is button-only and imports Pillow lazily so plugin/Home startup
    stays untouched.  No crop, no upscale, no presentation derivative.
    """
    raw_path = str(raw_path or '').strip()
    destination = str(destination or '').strip()
    if not raw_path or not destination:
        return ''
    try:
        from PIL import Image as _Image
        from .persistent_cache import ensure_persistent_dirs
    except Exception:
        return ''
    if not (os.path.isfile(raw_path) and os.path.getsize(raw_path) > 1024):
        return ''
    if not ensure_persistent_dirs(os.path.dirname(destination)):
        return ''
    temp = destination + '.tmp.%s.%s' % (os.getpid(), threading.get_ident())
    try:
        with _Image.open(raw_path) as image:
            image = image.convert('RGB')
            w, h = image.size
            if w < 16 or h < 16:
                return ''
            scale = min(1.0, 1920.0 / float(w), 1080.0 / float(h))
            if scale < 0.999:
                res = getattr(getattr(_Image, 'Resampling', _Image), 'LANCZOS', 1)
                image = image.resize((max(1, int(round(w * scale))), max(1, int(round(h * scale)))), res)
            image.save(temp, 'JPEG', quality=60, subsampling=2, optimize=False, progressive=False)
        if not (os.path.isfile(temp) and os.path.getsize(temp) > 4096):
            return ''
        os.replace(temp, destination)
        return destination
    except Exception as exc:
        try:
            optional_failure('ui.page_backdrop_q60_build', exc)
        except Exception:
            pass
        return ''
    finally:
        try:
            if os.path.exists(temp):
                os.unlink(temp)
        except Exception:
            pass

def _page_backdrop_fetch_original_q60(url, destination, timeout=10, cancel_event=None, replace_existing=False):
    """BLUE/Cinematic/Grid share the same original-derived Full-HD HDD bytes."""
    if cancel_event is not None and cancel_event.is_set():
        return ''
    if not url or not destination:
        return ''
    try:
        from .shared_tmdb_cache import materialize_backdrop
        result = materialize_backdrop(url, destination, timeout, replace_existing=replace_existing) or ''
        if cancel_event is not None and cancel_event.is_set():
            return ''
        return result
    except Exception as exc:
        optional_failure('ui.shared_page_backdrop', exc)
        return ''

def _progressive_poster_item_detached(profile, media_type, item, cfg, client, cancel_event=None):
    """Resolve one visible poster without retaining a Grid Screen instance."""
    if media_type not in ('vod', 'series') or not isinstance(item, dict):
        return ('', {})
    if cancel_event is not None and cancel_event.is_set():
        return ('', {})
    cfg = dict(cfg or {})
    profile = dict(profile or {})
    credential = str(cfg.get('tmdb_credential') or '').strip()
    if not cfg.get('load_images', True):
        return ('', {})
    if not credential:
        return ('', {})
    if not cfg.get('tmdb_enabled', True):
        return ('', {})
    try:
        snap = load_artwork_v2_manifest(profile, media_type, item) or {}
        if not snap.get('tmdb_id') or not (snap.get('rating') or snap.get('vote_average')) or (not (snap.get('_age_rating_checked') or snap.get('certification') or snap.get('age_rating'))):
            try:
                from .details_authority import load_canonical as _da_load_canonical
                _canon = _da_load_canonical(profile, media_type, item) or {}
                for _ck, _cv in _canon.items():
                    if _cv not in (None, '', [], {}) and snap.get(_ck) in (None, '', [], {}):
                        snap[_ck] = _cv
            except Exception:
                pass
        poster = str(snap.get('poster_local') or '')
        _has_badge_meta = bool(snap.get('tmdb_id') and (snap.get('rating') or snap.get('vote_average')) and (snap.get('year') or snap.get('release_date') or snap.get('first_air_date')) and (snap.get('_age_rating_checked') or snap.get('certification') or snap.get('age_rating')))
        if poster and os.path.isfile(poster) and (os.path.getsize(poster) > 256) and _has_badge_meta:
            return (poster, snap)
    except Exception:
        snap = {}
    if cancel_event is not None and cancel_event.is_set():
        return ('', {})
    try:
        data = ArtworkV2(credential, cfg.get('tmdb_language', 'ar-EG'), min(5, max(3, int(cfg.get('timeout', 10) or 10)))).resolve(profile, media_type, item, full=False, cancel_event=cancel_event) or {}
        poster = str(data.get('poster_local') or '')
        if poster and os.path.isfile(poster) and (os.path.getsize(poster) > 256):
            return (poster, data)
        if data.get('poster_candidate_unavailable'):
            purl = str(item.get('_visible_provider_art_url') or item.get('_rescue_provider_art_url') or '').strip()
            if not purl:
                try:
                    purl = str(_image_url(item) or '').strip()
                except Exception:
                    purl = ''
            if purl and (not item.get('_generic_provider_art')):
                provider = _download_portal_artwork(purl, profile, client, False, 4.5, cancel_event, item=item) or ''
                if provider and os.path.isfile(provider):
                    try:
                        from .artwork_v2 import save_manual_rescue_art
                        saved = save_manual_rescue_art(profile, media_type, item, poster=provider, source='provider_auto_missing') or {}
                        rescued = str(saved.get('poster_local') or '')
                        if rescued and os.path.isfile(rescued):
                            return (rescued, saved)
                    except Exception as exc:
                        optional_failure('ui.grid_visible_provider_rescue_save', exc)
        return ('', data)
    except Exception as exc:
        optional_failure('ui.auto_visible_poster', exc)
        return ('', {})

def _catalogue_error_kind(exc):
    """Classify catalogue failures without changing provider/client behavior."""
    low = us_casefold(str(exc or ''))
    if any((marker in low for marker in ('http 429', 'http 469', 'rate limit'))):
        return 'rate_limit'
    hard = ('security consent', 'fallback is not approved', 'certificate verification', 'unapproved https', 'unsupported portal transport', 'invalid portal url')
    if any((marker in low for marker in hard)):
        return 'hard'
    transient = ('connection', 'timed out', 'timeout', 'non-json', 'invalid page', 'temporarily paused', 'remote end closed', 'connection reset', 'broken pipe', 'connection aborted', 'eof', 'http 502', 'http 503', 'http 504', 'bad gateway', 'service unavailable', 'gateway timeout', 'premature catalogue page')
    return 'transient' if any((marker in low for marker in transient)) else 'other'
from .ui_grid_mixin_cache import GridCacheMixin
from .ui_grid_mixin_lifecycle import GridLifecycleMixin
from .ui_grid_mixin_folder import GridFolderMixin
from .ui_grid_mixin_posters import GridPostersMixin
from .ui_grid_mixin_foldersearch import GridFolderSearchMixin
from .ui_grid_mixin_pageload import GridPageLoadMixin
from .ui_grid_mixin_prefetch import GridPrefetchMixin
from .ui_grid_mixin_render import GridRenderMixin
from .ui_grid_mixin_focus import GridFocusMixin
from .ui_grid_mixin_hud import GridHudMixin
from .ui_grid_mixin_nav import GridNavMixin
from .ui_grid_mixin_child import GridChildMixin
from .ui_grid_mixin_hero import GridHeroMixin
from .ui_grid_mixin_trailer import GridTrailerMixin
from .ui_grid_mixin_menu import GridMenuMixin
from .ui_grid_mixin_epg import GridEpgMixin
import sys as _split_sys
_MIXIN_MODULES = tuple((_split_sys.modules[_m.__module__] for _m in (GridCacheMixin, GridLifecycleMixin, GridFolderMixin, GridPostersMixin, GridFolderSearchMixin, GridPageLoadMixin, GridPrefetchMixin, GridRenderMixin, GridFocusMixin, GridHudMixin, GridNavMixin, GridChildMixin, GridHeroMixin, GridTrailerMixin, GridMenuMixin, GridEpgMixin)))

class PremiumGridBase(GridCacheMixin, GridLifecycleMixin, GridFolderMixin, GridPostersMixin, GridFolderSearchMixin, GridPageLoadMixin, GridPrefetchMixin, GridRenderMixin, GridFocusMixin, GridHudMixin, GridNavMixin, GridChildMixin, GridHeroMixin, GridTrailerMixin, GridMenuMixin, GridEpgMixin, Screen, AsyncScreenMixin, GridArtworkMixin):
    columns = 1
    page_size = 1
    card_positions = []
    image_size = (100, 100)
    placeholder = 'us168_live_placeholder_220x132.png'
    selection_asset = 'us205_live_selection_neutral.png'
    visible_card_rating_prefetch = False

    def __init__(self, session, profile, client, media_type, genre, category_title='', initial_search=''):
        us_func(Screen.__init__)(self, session)
        self._async_init()
        self.onClose.append(self._stop_async)
        self._ui_diag_open_mono = time.monotonic()
        self._ui_diag_page_request_mono = self._ui_diag_open_mono
        self._ui_diag_first_poster_logged = False
        _ui_diag('ui_open', screen='grid', media_type=media_type)
        self.profile = profile
        self.client = client
        self.media_type = media_type
        self.genre = str(genre or '*')
        self._grid_settings = load_settings()
        self.category_title = _clean_display_text(category_title, 70) or (_('Live TV') if media_type == 'itv' else _('Movies') if media_type == 'vod' else _('Series'))
        self._nav_key = (str(profile.get('portal') or '').rstrip('/').lower(), str(media_type), self.genre)
        self.page = 1
        self.grid_items = []
        self.index = 0
        self._grid_item_state = {}
        self._explicit_quality_cache = {}
        self._restore_page = 1
        self._restore_index = 0
        self._view_nav_id = (self.__class__.__name__, int(getattr(self, 'page_size', 1) or 1)) if media_type in ('vod', 'series') else None
        self._initial_grid_paint_done = False
        self._folder_catalog = None
        self._folder_catalog_loading = False
        self._folder_catalog_waiters = []
        self._search_query = ''
        self._open_search_term = one_line(initial_search or '', 60)
        self._section_search_started = False
        self._folder_search_rows = None
        self._sort_mode = 0
        self._view_items = None
        self._view_active = False
        self._folder_artwork_cache_running = False
        self._folder_artwork_cache_done = 0
        self._folder_artwork_cache_total = 0
        self._folder_artwork_progress = queue.Queue()
        self._folder_artwork_ui_finalized = False
        self._session_nav_key = (current_plugin_launch(),) + tuple(self._nav_key)
        if self._view_nav_id is not None:
            self._session_nav_key = self._session_nav_key + ('view',) + tuple(self._view_nav_id)
        try:
            _g = _GRID_NAV_STATE.get(self._session_nav_key, {})
            self._restore_page = max(1, int(_g.get('page', 1)))
            self._restore_index = max(0, int(_g.get('index', 0)))
        except Exception as exc:
            optional_failure('ui.silent_guard', exc)
        self._portal_page_cache = OrderedDict()
        self._portal_page_size = 0
        self._portal_total = 0
        self._portal_page_cache_limit = 6
        self._last_nav_at = 0.0
        self._nav_burst_until = 0.0
        self._prepared_page_cache = OrderedDict()
        self._prepared_page_lock = threading.RLock()
        self._prepared_page_pending = set()
        self._prepared_page_cache_limit = 4
        self._grid_page_warm_running = False
        self._grid_page_warm_token = 0
        self._page_visual_ram = OrderedDict()
        self._page_visual_ram_limit = 512
        self._visible_age_cache = OrderedDict()
        self._visible_age_cache_limit = 1024
        self._grid_visual_locks = {}
        try:
            _desk = getDesktop(0).size()
            self._grid_sx = float(_desk.width()) / 1920.0
            self._grid_sy = float(_desk.height()) / 1080.0
        except Exception:
            self._grid_sx = 1.0
            self._grid_sy = 1.0
        self._scaled_card_positions = [(int(x * self._grid_sx), int(y * self._grid_sy)) for x, y in self.card_positions]
        self._page_load_handle = None
        self._pending_page_request = None
        self._grid_page_nav_target = 0
        self._grid_page_nav_index = 0
        self._grid_page_nav_generation = 0
        self._grid_page_nav_timer = eTimer()
        self._grid_page_nav_conn = None
        try:
            self._grid_page_nav_conn = self._grid_page_nav_timer.timeout.connect(self._commit_grid_page_nav)
        except Exception:
            self._grid_page_nav_timer.callback.append(self._commit_grid_page_nav)
        self.onClose.append(self._stop_grid_page_nav)
        self._page_prefetch_futures = []
        self._page_prefetch_future_jobs = queue.Queue()
        self._quality_prefetch_jobs = queue.Queue()
        self._art_prefetch_jobs = queue.Queue()
        self._epg_cache = {}
        self._epg_jobs = queue.Queue()
        self._epg_pending = None
        self._epg_token = 0
        self._epg_future = None
        self._epg_cancel_event = threading.Event()
        self._epg_timer = eTimer()
        self._epg_timer_conn = None
        try:
            self._epg_timer_conn = self._epg_timer.timeout.connect(self._fetch_epg)
        except Exception:
            self._epg_timer.callback.append(self._fetch_epg)
        self._detail_prefetch_timer = eTimer()
        self._detail_prefetch_conn = None
        try:
            self._detail_prefetch_conn = self._detail_prefetch_timer.timeout.connect(self._prefetch_selected_details)
        except Exception:
            self._detail_prefetch_timer.callback.append(self._prefetch_selected_details)
        self._grid_focus_timer = eTimer()
        self._grid_focus_timer_conn = None
        try:
            self._grid_focus_timer_conn = self._grid_focus_timer.timeout.connect(self._apply_debounced_grid_focus)
        except Exception:
            self._grid_focus_timer.callback.append(self._apply_debounced_grid_focus)
        self._series_prefetch_timer = eTimer()
        self._series_prefetch_timer_conn = None
        try:
            self._series_prefetch_timer_conn = self._series_prefetch_timer.timeout.connect(self._prefetch_selected_series_hierarchy)
        except Exception:
            self._series_prefetch_timer.callback.append(self._prefetch_selected_series_hierarchy)
        self._series_hierarchy_prefetch_cancel = threading.Event()
        self._series_hierarchy_prefetch_token = 0
        self._grid_idle_warm_timer = eTimer()
        self._grid_idle_warm_conn = None
        self._grid_full_chrome_warm = False
        try:
            self._grid_idle_warm_conn = self._grid_idle_warm_timer.timeout.connect(self._warm_idle_grid_page)
        except Exception:
            self._grid_idle_warm_timer.callback.append(self._warm_idle_grid_page)
        self._mem34_timer = eTimer()
        self._mem34_timer_conn = None
        try:
            self._mem34_timer_conn = self._mem34_timer.timeout.connect(self._mem34_grid_settled)
        except Exception:
            self._mem34_timer.callback.append(self._mem34_grid_settled)
        self.onClose.append(self._mem34_stop_timer)
        self._visible_poster_watch_timer = eTimer()
        self._visible_poster_watch_conn = None
        try:
            self._visible_poster_watch_conn = self._visible_poster_watch_timer.timeout.connect(self._poll_visible_poster_cache)
        except Exception:
            self._visible_poster_watch_timer.callback.append(self._poll_visible_poster_cache)
        self._visible_rating_retry_timer = eTimer()
        self._visible_rating_retry_conn = None
        self._visible_rating_retry_queue = []
        try:
            self._visible_rating_retry_conn = self._visible_rating_retry_timer.timeout.connect(self._on_visible_rating_retry_timer)
        except Exception:
            self._visible_rating_retry_timer.callback.append(self._on_visible_rating_retry_timer)
        self._visible_rating_delayed_calls = []
        self.onClose.append(self._dispose_visible_rating_retry_timer)
        self._page_prefetch_seen = set()
        self._visible_tmdb_pending = set()
        self._visible_tmdb_rating_cache = {}
        self._page_quality_seen = set()
        self._page_art_retry_count = {}
        self._page_prefetch_lock = threading.RLock()
        self._page_prefetch_generation = 0
        self._page_prefetch_cancel = threading.Event()
        self._focus_art_cancel = threading.Event()
        self._focus_art_future = None
        self._focus_art_token = 0
        self._progressive_poster_cancel = threading.Event()
        self._progressive_poster_started = False
        self.onClose.append(self._stop_progressive_poster_prefetch)
        self.onClose.append(self._stop_focus_heavy_artwork)
        self.onClose.append(self._stop_visible_poster_watch)
        self.onClose.append(self._stop_grid_ui_hooks)
        self.onClose.append(self._grid_art_stop)
        self.onClose.append(self._stop_grid_epg)
        self.onClose.append(self._stop_detail_prefetch)
        self.onClose.append(self._stop_grid_focus_timer)
        self.onClose.append(self._stop_series_hierarchy_prefetch)
        self.onClose.append(self._stop_grid_idle_warm_timer)
        self.onClose.append(self._runtime_grid_close)
        self['brand'] = Label('')
        self['section'] = Label(str(self.category_title or ''))
        self['title'] = Label(self.category_title)
        self['clock'] = Label('')
        self._grid_clock = None
        self._grid_clock_conn = None
        if not getattr(self, 'disable_grid_clock', False):
            self['clock'].setText(time.strftime('%H:%M'))
            self._grid_clock = eTimer()
            try:
                self._grid_clock_conn = self._grid_clock.timeout.connect(self._update_grid_clock)
            except Exception:
                self._grid_clock.callback.append(self._update_grid_clock)
            try:
                self._grid_clock.start(30000, False)
            except Exception as exc:
                optional_failure('ui', exc)
            self.onClose.append(self._stop_grid_clock)
        self.onClose.append(self._ui_diag_grid_close)
        self['rating'] = Label('')
        self['meta1'] = Label('')
        self['meta2'] = Label('')
        self['status'] = Label(_('Loading...'))
        self['page_label'] = Label(_('Page 1'))
        self['red'] = Label(_('Search') if media_type in ('vod', 'series') else _('Back'))
        self['green'] = Label(_('Favorite'))
        self['yellow'] = Label(_('Default') if media_type in ('vod', 'series') else _('Previous page'))
        self['blue'] = Label(_('Check Artwork') if media_type in ('vod', 'series') else _('Next page'))
        self['selection'] = Pixmap()
        if media_type in ('vod', 'series'):
            self['selection_adaptive'] = Pixmap()
            self['page_adaptive_bg'] = Pixmap()
            self['poster_folder_bg'] = Pixmap()
            self['poster_title_bg'] = Pixmap()
            self['poster_clock_bg'] = Pixmap()
            self['poster_counter_bg'] = Pixmap()
            self['date_label'] = Label(_lstrf('%A, %d %B %Y'))
            self._poster_hud_last = {}
            self._poster_hud_source = ''
            self._poster_hud_pending = set()
            self._poster_hud_jobs = queue.Queue()
            self._grid_mood_jobs = queue.Queue()
            self._grid_mood_token = 0
            self._grid_mood_source = ''
            self._grid_mood_pending = ''
        slot_names = []
        for pos in range(self.page_size):
            name = 'art%d' % pos
            slot_names.append(name)
            self[name] = Pixmap()
            self['item_title%d' % pos] = Label('')
            self['item_meta%d' % pos] = Label('')
            if media_type in ('vod', 'series'):
                self['card_chrome%d' % pos] = Pixmap()
                self['item_pt%d' % pos] = Pixmap()
                self['item_pf%d' % pos] = Pixmap()
                self['item_age%d' % pos] = Label('')
                self['item_year%d' % pos] = Label('')
                self['item_star%d' % pos] = Pixmap()
                self['item_score%d' % pos] = Label('')
                if getattr(self, 'premium_v2_badges', False):
                    self['item_seasons%d' % pos] = Label('')
                    self['item_seasons_icon%d' % pos] = Pixmap()
                    self['item_seasons_bg%d' % pos] = Pixmap()
                    for key in ('seasons', 'seasons_icon', 'seasons_bg'):
                        try:
                            self['item_%s%d' % (key, pos)].hide()
                        except Exception:
                            pass
                self['item_year_bg%d' % pos] = Pixmap()
                self['item_score_bg%d' % pos] = Pixmap()
                self['item_age_bg%d' % pos] = Pixmap()
                for _bg in ('item_year_bg%d' % pos, 'item_score_bg%d' % pos, 'item_age_bg%d' % pos):
                    try:
                        self[_bg].hide()
                    except Exception:
                        pass
        self._grid_art_init(slot_names, self.image_size, profile, client)
        _red_action = self.open_folder_search if media_type in ('vod', 'series') else self.close
        _yellow_action = self.cycle_folder_sort if media_type in ('vod', 'series') else self.previous_page
        _blue_action = self.cache_folder_artwork if media_type in ('vod', 'series') else self.next_page
        self['actions'] = ActionMap(['OkCancelActions', 'ColorActions', 'DirectionActions', 'MenuActions', 'UltraStalkerMenuActions', 'InfoActions'], {'cancel': self.close, 'red': _red_action, 'ok': self.open_selected, 'left': self.move_left, 'right': self.move_right, 'up': self.move_up, 'down': self.move_down, 'green': self.toggle_selected_favorite, 'yellow': _yellow_action, 'blue': _blue_action, 'menu': self.open_menu, 'info': self.show_information}, -1)
        self.onLayoutFinish.append(self._grid_layout_ready)
        if getattr(self, 'shared_footer', False):
            self.onLayoutFinish.append(self._apply_shared_footer_geometry)
            self.onShown.append(self._apply_shared_footer_geometry)
        if media_type in ('vod', 'series'):
            self.onLayoutFinish.append(self._refresh_search_sort_controls)
        try:
            self.onHide.append(self._grid_hidden_release)
        except Exception as exc:
            optional_failure('ui.grid_hide_hook', exc)
        try:
            self.onShown.append(self._grid_shown_resume)
        except Exception as exc:
            optional_failure('ui.grid_show_hook', exc)
        _mem34('grid_init_done', mode=self.__class__.__name__, media=str(media_type or ''))
    _FOLDER_SORT_LABELS = ('Default', 'Top Rated', 'Newest', 'Oldest', 'A-Z', 'Z-A')
try:
    from .frontpanel_plugin import bind_plugin_front_summary as _bind_plugin_front_summary
    _bind_plugin_front_summary(PremiumGridBase)
except Exception:
    pass
