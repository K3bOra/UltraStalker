# -*- coding: utf-8 -*-
"""Portal home screen extracted from ui.py without changing class behavior."""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import int, us_func

from . import _
hashlib = _us_env.hashlib
json = _us_env.json
os = _us_env.os
queue = _us_env.queue
re = _us_env.re
import tempfile
threading = _us_env.threading
time = _us_env.time
from .core.runtime_log import diagnostic_breadcrumb as _ui_diag
from .log import diagnostic_failure, memory_snapshot as _mem34

try:
    from PIL import Image as _PILImage
except Exception:
    _PILImage = None

from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap
from enigma import eTimer, ePoint, eSize, eLabel, gFont, getDesktop, loadPNG
from skin import parseColor

from .ui_async import AsyncScreenMixin
from .ui_image_loader import ImageLoaderMixin
from .ui_transition import TransitionMixin
from .ui_fixed_adaptive import fixed_home_assets, cleanup_legacy_application_outputs
from .ui_helpers import content_refresh_feedback, content_refresh_failure, fit_label_to_box, fit_inline_label_row
from .ui_icon_menu import IconMenuList
from .title_clean import display_title as _home_display_title
from .localization import localized_strftime as _lstrf
from .version import PLUGIN_VERSION, PLUGIN_REVISION
from .home_status import expiry_date, updated_text

_HOME_CLOCK_FONT_READY = False

def _register_home_clock_font():
    """Register the bundled B clock/day font once; other labels stay native."""
    global _HOME_CLOCK_FONT_READY
    if _HOME_CLOCK_FONT_READY:return
    try:
        from enigma import addFont
        path=os.path.join(os.path.dirname(__file__),"fonts","home_status_b.ttf")
        addFont(path,"UltraHomeB",100,False)
        addFont(os.path.join(os.path.dirname(__file__),"fonts","home_clock_digits.ttf"),"UltraHomeClock",100,False)
    except Exception as exc:
        # An unusual image/font loader must not prevent Home from opening.
        PortalHomeScreen.skin=PortalHomeScreen.skin.replace("UltraHomeB;76","Regular;76").replace("UltraHomeB;32","Regular;32").replace("UltraHomeClock;76","Regular;76")
        if callable(optional_failure):optional_failure("ui.home_clock_font",exc)
    _HOME_CLOCK_FONT_READY=True


# Runtime dependencies are injected by ui.py after its shared helpers are ready.
HOME_SKIN = ""
BACKDROP_CACHE_DIR = ""
HOME_HERO_FILE = ""
HOME_HERO_SCHEMA = 0
HOME_HERO_TTL = 0
HOME_RUNTIME_DIR = ""
IMAGE_CACHE_DIR = ""
THUMB_CACHE_DIR = ""
LOG = None
PortalSession = None
TMDBClient = None
UltraStalkerPlayer = None
_CATEGORY_PREFETCH_EXECUTOR = None
_HOME_HERO_LOCK = None
_IMAGE_EXECUTOR = None
PERSISTENT_GENERATED_DIR = ""
_fit_live_picon_canvas = None
_build_home_adaptive_focus = None
_build_home_mood_assets = None
_cleanup_legacy_home_hero_storage = None
_category_cache_get = None
_category_cache_put = None
_invalidate_source_navigation_cache = None
_clean_display_text = None
_configured_playback_engine = None
_client_from_profile = None
_fsync_parent_dir = None
_home_prepare_art = None
_home_cached_art = None
_player_payload = None
_plugin_original_service_string = None
_valid_cache_file = None
add_recently_played = None
asset = None
current_plugin_launch = None
load_playback_progress = None
load_profiles = None
load_recently_played = None
history_revision = None
load_settings = None
_HOME_ENTRY_REFRESH_DONE = False
load_ui_state = None
optional_failure = None
premium_title = None
save_profiles = None
save_ui_state = None
home_boot_pixmap = None
splash_home_is_warm = None
splash_home_warm_state = None
splash_home_account_info = None
splash_home_recent_assets = None

# Forward screen references are filled after those classes are defined.
ContentDetailsScreen = None
NovaSettingsScreen = None
PortalBrowserScreen = None
PortalGlobalSearchScreen = None
LocalLibraryScreen = None

_RECENT_CACHE={"rev":None,"rows":None}

def _cached_recently_played():
    """load_recently_played() reused while storage.history_revision() is unchanged."""
    rev=None
    try:rev=int(history_revision()) if callable(history_revision) else None
    except Exception:rev=None
    if rev is not None and _RECENT_CACHE["rev"]==rev and _RECENT_CACHE["rows"] is not None:
        return list(_RECENT_CACHE["rows"])
    rows=load_recently_played() or []
    if rev is not None and isinstance(rows,list):
        _RECENT_CACHE["rev"]=rev;_RECENT_CACHE["rows"]=rows
        return list(rows)
    return rows

def configure_home_screen(**deps):
    globals().update(deps)
    for _mixin_module in _MIXIN_MODULES:
        _mixin_module.__dict__.update(deps)
    if "HOME_SKIN" in deps:
        PortalHomeScreen.skin = deps["HOME_SKIN"]

# Split: related method groups live in ui_home_mixin_*.py modules. They are imported here, after every module-level helper above exists,
# and listed BEFORE the other bases so they override them exactly like the methods that used to sit in this class body.
from .ui_home_mixin_lifecycle import HomeLifecycleMixin
from .ui_home_mixin_menu import HomeMenuMixin
from .ui_home_mixin_rebind import HomeRebindMixin
from .ui_home_mixin_layout import HomeLayoutMixin
from .ui_home_mixin_timers import HomeTimersMixin
from .ui_home_mixin_content import HomeContentMixin
from .ui_home_mixin_nav import HomeNavMixin
from .ui_home_mixin_shortcuts import HomeShortcutsMixin
from .ui_home_mixin_recent import HomeRecentMixin
from .ui_home_mixin_live import HomeLiveMixin
from .ui_home_mixin_hero import HomeHeroMixin
import sys as _split_sys
_MIXIN_MODULES = tuple(_split_sys.modules[_m.__module__] for _m in (HomeLifecycleMixin, HomeMenuMixin, HomeRebindMixin, HomeLayoutMixin, HomeTimersMixin, HomeContentMixin, HomeNavMixin, HomeShortcutsMixin, HomeRecentMixin, HomeLiveMixin, HomeHeroMixin,))


class PortalHomeScreen(
    HomeLifecycleMixin,
    HomeMenuMixin,
    HomeRebindMixin,
    HomeLayoutMixin,
    HomeTimersMixin,
    HomeContentMixin,
    HomeNavMixin,
    HomeShortcutsMixin,
    HomeRecentMixin,
    HomeLiveMixin,
    HomeHeroMixin,
    Screen,
    AsyncScreenMixin,
    ImageLoaderMixin,
    TransitionMixin,
):
    skin = HOME_SKIN
    # R54: eight logical destinations, seven resident Home widgets.  Local owns
    # the former Catch-up visible slot; Catch-up remains available by sliding
    # the same seven cards one position at the edge.  No second Home page and
    # no eighth resident card/widget are created.
    CARDS = (
        ("Live TV", "Watch live channels", "itv", "home_live_line.png"),
        ("Movies", "Browse movie library", "vod", "home_movies_line.png"),
        ("Series", "Explore TV series", "series", "home_series_line.png"),
        ("Local", "Play files from receiver storage", "local", "home_local_line.png"),
        ("Favorites", "Your saved content", "favorites", "home_favorites_line.png"),
        ("Search", "Find content quickly", "search", "home_search_line.png"),
        ("Settings", "Portal & player settings", "settings", "home_settings_line.png"),
        ("Catch-up", "Watch past programs", "catchup", "home_catchup_line.png"),
    )
    VISIBLE_CARD_COUNT=7
    CARD_X=(55,313,571,829,1087,1345,1603)
    RECENT_PANEL_X=(55,677,1299)
    RECENT_ROW_X=(285,907,1529)
    RECENT_ROW_Y=(786,884,982)

    def __init__(self,session,profile):
        _perf_t0=time.monotonic()
        if LOG is not None: LOG.info("PERF25 home init_enter mono_ms=%d",int(_perf_t0*1000))
        _register_home_clock_font()
        us_func(Screen.__init__)(self,session);self._async_init();self.onClose.append(self._stop_async);self.onClose.append(self._image_stop)
        self._ui_diag_open_mono=time.monotonic();_ui_diag("ui_open",screen="home")
        self.profile=profile
        _home_cfg=load_settings() or {}
        self._home_clean_titles=bool(_home_cfg.get("clean_titles",True))
        self.portal_session=PortalSession(profile,timeout=_home_cfg.get("timeout",10));self.client=self.portal_session.client
        # First-run language/Clean Names now completes on the existing Splash
        # before Portal List opens. Home owns no onboarding widgets or actions.
        try:
            _desk=getDesktop(0).size();self._home_sx=float(_desk.width())/1920.0;self._home_sy=float(_desk.height())/1080.0
        except Exception:
            self._home_sx=1.0;self._home_sy=1.0
        self.index=0;self._menu_window_start=0;self.recent_index=0;self.focus_row="menu"
        self._sc_mode=False;self._sc_edit=False;self._sc_index=0;self._sc_saved=None
        self._recent_entries=[None]*9;self._recent_art_paths=[None]*9;self._recent_progress_paths=[None]*9;self._recent_group_art_paths=[None]*3
        self._recent_focus_drawn=-1;self._recent_generation=0;self._recent_futures=set();self._home_jobs=queue.Queue();self._hero_data=None
        self._recent_render_revision=-1
        # Point 5: Recent/Home lower cards are a resident presentation surface,
        # just like the fixed menu cards above them.  Prepare them before the
        # first visible paint and never rebuild them again merely because the
        # deferred Hero pass runs.
        self._recent_snapshot_ready=False
        self._recent_lists_initialized=False
        self._home_has_shown_once=False;self._home_return_pending=False;self._home_runtime_visible=True
        self["brand"]=Label("")
        self["hero_kicker"]=Label("");self["hero_title"]=Label("");self["hero_subtitle"]=Label("");self["hero_rating"]=Label("")
        self["home_card_heading"]=Label("U L T R A  S T A L K E R")
        self["home_version"]=Label("V%s" % PLUGIN_VERSION)
        self["home_content_updated"]=Label("")
        self["home_update_caption"]=Label(_("Last Update"))
        self["portal_state"]=Label("●")
        self["portal_connected"]=Label(_("Connected"))
        self["portal_expiry_prefix"]=Label("")
        self["portal_expiry"]=Label("")
        # R5.369: native text on one bundled, immutable premium status card.
        self["home_clock"]=Label("");self["home_date"]=Label("");self["home_weekday"]=Label("")
        for _h,_t in enumerate((_("RECENT LIVE"),_("CONTINUE MOVIES"),_("CONTINUE SERIES"))):
            self["recent_head%d"%_h]=Label(_t)
        self._home_clock_timer=eTimer();self._home_clock_conn=None
        try:self._home_clock_conn=self._home_clock_timer.timeout.connect(self._home_clock_tick)
        except Exception:self._home_clock_timer.callback.append(self._home_clock_tick)
        self.onClose.append(self._home_clock_stop)
        self._set_home_account_line()
        self["selection"]=Pixmap();self["hero_backdrop"]=Pixmap();self["ambient_bg"]=Pixmap();self["continue_header"]=Label(_("CONTINUE / RECENT"))
        for i in range(7):self["menu_bg%d"%i]=Pixmap()
        for i in range(7):self["menu_icon%d"%i]=Pixmap()
        for i in range(3):
            self["recent_bg%d"%i]=Pixmap();self["recent_art%d"%i]=Pixmap()
            # R181: one native MultiContent list draws all three rows for this
            # panel. This replaces 12 resident widgets per panel.
            self["recent_list%d"%i]=IconMenuList([],width=305,item_height=98,icon_size=0,primary_font=22,secondary_font=13,row_style="home_recent")
        for i in range(self.VISIBLE_CARD_COUNT):self["card_title%d"%i]=Label("");self["card_sub%d"%i]=Label("")
        self._recent_row_normal_path=asset("fixed_master_r63/home_recent_row.png")
        self._recent_row_selected_path=asset("fixed_master_r63/home_recent_row_selected.png")
        self._recent_pbar_fill_path=asset("fixed_master_r63/home_recent_pbar_fill.png");self._home_icon_state={};self._home_focus_slot=-1
        self["status"]=Label(_("LEFT / RIGHT Navigate • DOWN Recent • OK Open • BACK Portals"))
        # Home reuses the exact Settings passive-notice master.  It lives only
        # in the Hero/backdrop lane, above the cards and Recent section.
        self["refresh_notice_panel"]=Pixmap();self["refresh_notice_title"]=Label("");self["refresh_notice_message"]=Label("")
        self._refresh_notice_visible=False;self._content_refresh_running=False
        for _name in ("refresh_notice_panel","refresh_notice_title","refresh_notice_message"):
            try:self[_name].hide()
            except Exception:pass
        self._image_init("hero_backdrop",(1920,1080),profile,self.client)
        self["actions"]=ActionMap(["OkCancelActions","DirectionActions","MenuActions","UltraStalkerMenuActions","InfoActions","ColorActions"],{
            "cancel":self._home_cancel,"left":self.move_left,"right":self.move_right,"up":self.move_up,"down":self.move_down,"ok":self.open_selected,"menu":self.open_settings,"info":self.open_account,"green":self.refresh_current_content,"yellow":self.open_search_shortcut,"blue":self.toggle_shortcuts},-1)
        self["refresh_notice_actions"]=ActionMap(["OkCancelActions","ColorActions"],{
            "ok":self._hide_refresh_notice,"cancel":self._hide_refresh_notice,"green":self._hide_refresh_notice},-1000)
        try:self["refresh_notice_actions"].setEnabled(False)
        except Exception:pass
        # Single-slot Hero: no rotation/fill timer and no automatic Home artwork jobs.
        self._hero_timer=None;self._hero_timer_conn=None;self._hero_fill_running=False
        self.onLayoutFinish.append(self._layout_ready)
        self._home_rebind_timer=eTimer();self._home_rebind_conn=None
        try:self._home_rebind_conn=self._home_rebind_timer.timeout.connect(self._home_delayed_rebind)
        except Exception:self._home_rebind_timer.callback.append(self._home_delayed_rebind)
        self.onClose.append(self._stop_home_rebind_timer)
        # PERF59: passive whole-plugin navigation/memory audit.  A short and a
        # later Home-return probe show whether child-screen memory/fds/threads
        # actually settle after close, without forcing GC or changing runtime
        # behaviour.  The probe is cancelled immediately if Home is hidden again.
        self._perf59_cycle=0;self._perf59_return_stage=0;self._perf59_return_action=""
        self._perf59_return_probe=eTimer();self._perf59_return_probe_conn=None
        try:self._perf59_return_probe_conn=self._perf59_return_probe.timeout.connect(self._perf59_return_probe_fire)
        except Exception:self._perf59_return_probe.callback.append(self._perf59_return_probe_fire)
        self.onClose.append(self._perf59_stop_return_probe)
        # PERF26: first paint must not wait for Hero/adaptive PNG decode.
        # Bind the Home shell immediately, then apply the persisted Hero one
        # event-loop turn later. The settled visual result is unchanged.
        self._startup_hero_timer=eTimer();self._startup_hero_conn=None
        try:self._startup_hero_conn=self._startup_hero_timer.timeout.connect(self._startup_hero_apply)
        except Exception:self._startup_hero_timer.callback.append(self._startup_hero_apply)
        self.onClose.append(self._stop_startup_hero_timer)
        # Remote focus state is persisted after a short quiet window instead of
        # rewriting the UI-state JSON on every LEFT/RIGHT keypress.
        self._home_focus_state_pending=None;self._home_focus_state_timer=eTimer();self._home_focus_state_conn=None
        try:self._home_focus_state_conn=self._home_focus_state_timer.timeout.connect(self._flush_home_focus_state)
        except Exception:self._home_focus_state_timer.callback.append(self._flush_home_focus_state)
        self.onClose.append(self._flush_home_focus_state);self.onClose.append(self._stop_home_focus_state_timer)
        # R129 SPEED: Home first paint must stay responsive while the heavy but
        # non-essential Recent/category warmers settle.  Defer those jobs to
        # separate one-shot timers instead of running them in the same UI turn
        # that binds the Hero.  Nothing visual is removed; only scheduling moves.
        self._home_recent_refresh_timer=eTimer();self._home_recent_refresh_conn=None
        try:self._home_recent_refresh_conn=self._home_recent_refresh_timer.timeout.connect(self._home_recent_refresh_fire)
        except Exception:self._home_recent_refresh_timer.callback.append(self._home_recent_refresh_fire)
        self._home_prefetch_delay_timer=eTimer();self._home_prefetch_delay_conn=None
        try:self._home_prefetch_delay_conn=self._home_prefetch_delay_timer.timeout.connect(self._home_prefetch_delay_fire)
        except Exception:self._home_prefetch_delay_timer.callback.append(self._home_prefetch_delay_fire)
        self.onClose.append(self._stop_home_speed_timers)
        self.onClose.append(self._stop_home_background_jobs)
        self.onClose.append(self._stop_home_ui_hooks)
        self.onClose.append(self._ui_diag_home_close)
        try:self.onShown.append(self._home_shown)
        except Exception as exc:optional_failure("ui",exc)
        try:self.onHide.append(self._home_hidden_release)
        except Exception as exc:optional_failure("ui.home_hide_hook",exc)
        if LOG is not None: LOG.info("PERF25 home init_done elapsed_ms=%d",int((time.monotonic()-_perf_t0)*1000))
        _mem34("home_init_done")


        # Recent rows/art remain bound and resident while child screens are open.
        # Do not clear, hide, or rebuild them merely because Home lost visibility.
        # A real playback/history mutation is handled once on return by revision.


    # ------------------------------------------------------------------
    # Home shortcuts (BLUE): the seven cards show a few settings; UP/DOWN (or
    # OK, then LEFT/RIGHT) change them without opening Settings.
    # ------------------------------------------------------------------
    _SC_VIEWS=(("poster_legacy","Poster Grid"),("poster","Poster Grid V2"),("poster3","Poster Grid 3"),("cinematic","Cinematic"),("backdrop","Backdrop Grid"),("backdrop2","Backdrop Grid 2"))


# R5.245: plugin-owned front-panel identity.
try:
    from .frontpanel_plugin import bind_plugin_front_summary as _bind_plugin_front_summary
    _bind_plugin_front_summary(PortalHomeScreen)
except Exception:
    pass

