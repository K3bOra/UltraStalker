# -*- coding: utf-8 -*-
"""Folder search menu, recent searches and sort cycling.

Methods moved verbatim out of ``PremiumGridBase`` (ui_grid_base.py); behaviour is unchanged.
This module is imported by ui_grid_base.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, bytes, int, us_text_callback, native_text
from .ui_grid_base import (
    _,
    _ui_diag,
    time,
)


class GridFolderSearchMixin(object):
    """Folder search menu, recent searches and sort cycling."""

    def _open_recent_folder_search_menu(self, keyboard):
        """Use the exact same persistent Recent Search store as Home Search."""
        try:
            recent=[str(x).strip() for x in (_load_recent_searches() or []) if str(x or "").strip()]
        except Exception:
            recent=[]
        if not recent or ChoiceBox is None:return
        choices=list((term,term) for term in recent[:10])
        def picked(choice):
            if not choice:return
            try:term=choice[1] if isinstance(choice,(tuple,list)) and len(choice)>1 else choice[0]
            except Exception:term=choice
            term=str(term or "").strip()
            if not term:return
            try:keyboard.close(term)
            except Exception as exc:optional_failure("ui.folder_search_recent_close",exc)
        try:
            owner_session=getattr(keyboard,"session",None) or getattr(self,"session",None)
            if owner_session is None:return
            owner_session.openWithCallback(picked,ChoiceBox,title=_("Recent searches"),list=choices)
        except Exception as exc:optional_failure("ui.folder_search_recent_menu",exc)

    def _attach_recent_folder_search_menu(self, keyboard):
        if keyboard is None:return
        try:
            amap=ActionMap(["MenuActions","UltraStalkerMenuActions"],{"menu":lambda:self._open_recent_folder_search_menu(keyboard)},-1000)
            keyboard["ultrastalker_recent_search_actions"]=amap
            try:amap.execBegin()
            except Exception as exc:optional_failure("ui.folder_search_recent_exec",exc)
        except Exception as exc:optional_failure("ui.folder_search_recent_action",exc)

    def open_folder_search(self):
        if self.media_type not in ("vod","series","itv"):return
        title=_("Search in %s")%self.category_title
        try:
            recent=[str(x).strip() for x in (_load_recent_searches() or []) if str(x or "").strip()]
        except Exception:
            recent=[]
        if recent:title+="  •  "+_("Recent: %s")%", ".join(recent[:3])
        try:
            from Screens.VirtualKeyBoard import VirtualKeyBoard as E2VirtualKeyBoard
        except Exception:
            E2VirtualKeyBoard=None
        if E2VirtualKeyBoard is not None:
            keyboard=self.session.openWithCallback(us_text_callback(self._folder_search_entered),E2VirtualKeyBoard,title=native_text(title),text=native_text(self._search_query))
            self._attach_recent_folder_search_menu(keyboard)
        else:
            self.session.openWithCallback(us_text_callback(self._folder_search_entered),InputBox,title=native_text(title),text=native_text(self._search_query),maxSize=60)

    def _folder_search_entered(self,term=None):
        if term is None:return
        # VirtualKeyBoard may return non-str text wrappers on some images. Keep
        # the callback fail-soft, then invalidate any older normal-page request
        # before the filtered view is painted. Without this guard a late page
        # callback can overwrite Search and make it look as if OK did nothing.
        try:
            if isinstance(term,bytes):term=term.decode("utf-8","ignore")
            elif isinstance(term,(list,tuple)) and len(term)==1:term=term[0]
        except Exception:pass
        self._search_query=one_line(term or "",60)
        self._folder_search_rows=None
        if self._search_query:
            try:_save_recent_search(self._search_query)
            except Exception as exc:optional_failure("ui.folder_search_recent_save",exc)
        try:
            pending=getattr(self,"_page_load_handle",None)
            if pending is not None:
                try:pending.cancel()
                except Exception:pass
            self._pending_page_request=None
            old_cancel=getattr(self,"_page_prefetch_cancel",None)
            if old_cancel is not None:old_cancel.set()
            self._page_prefetch_generation=int(getattr(self,"_page_prefetch_generation",0) or 0)+1
        except Exception as exc:optional_failure("ui.folder_search_cancel_stale_page",exc)
        self._refresh_search_sort_controls()

        # Empty input is a true reset. Do not build the full folder catalogue just
        # to get back to the provider page the user already had open.
        if not self._search_query:
            self._folder_search_rows=None
            try:self["status"].setText("")
            except Exception:pass
            # Preserve the user's current Sort mode exactly like the old search
            # flow. Default sort can jump straight back to native paging; a
            # non-default sort still requires the complete folder catalogue.
            if int(getattr(self,"_sort_mode",0) or 0):
                self._view_active=True
                def _sorted_ready(_rows):
                    try:self._load_folder_view_page(1,0)
                    except Exception as exc:optional_failure("ui.folder_search_reset_sorted",exc)
                self._ensure_folder_catalog(_sorted_ready)
            else:
                self._view_active=False;self._view_items=None
                try:self.load_page(1,0)
                except Exception as exc:optional_failure("ui.folder_search_reset",exc)
            return

        try:self["status"].setText(_("Searching..."))
        except Exception:pass

        # If Sort/BLUE already built the complete folder index, local search is
        # genuinely instant and remains authoritative. Otherwise use the same
        # bounded provider-native lane as Home Search FIRST instead of scanning up
        # to hundreds of category pages before the user sees anything.
        if isinstance(self._folder_catalog,list):
            started=time.monotonic();matches=self._build_folder_view()
            self._load_folder_view_page(1,0)
            try:_ui_diag("folder_search_fast",media_type=self.media_type,source="local",rows=len(matches),elapsed_ms=int((time.monotonic()-started)*1000))
            except Exception:pass
            return

        query=self._search_query
        started=time.monotonic()
        wide=str(getattr(self,"genre","") or "*") in ("*","")
        def provider_job(handle):
            # R78: Search from a grid means THIS FOLDER ONLY.  Home already owns
            # portal-wide search.  Ask the provider for a category-scoped native
            # search first; if it cannot do that, provider_ok() falls back to the
            # old complete-folder index so correctness is never traded for speed.
            fn=getattr(self.client,"search_category_fast",None)
            if not callable(fn):return []
            category=str(getattr(self,"genre","") or "*")
            try:
                rows=fn(query,media_type=self.media_type,category=category,limit=(48 if wide else 80),max_pages=(6 if wide else 8),
                        cancel_event=handle.cancel_event,time_budget=(3.5 if wide else 4)) or []
                # M3U/Xtream routing occasionally stores the visible category
                # title rather than the internal id. Retry that exact SAME folder
                # label only when the primary route produced nothing.
                if (not rows and self._grid_is_m3u_source() and str(getattr(self,"category_title","") or "").strip()
                        and str(getattr(self,"category_title","") or "").strip()!=category):
                    rows=fn(query,media_type=self.media_type,category=str(self.category_title).strip(),limit=120,max_pages=18,
                            cancel_event=handle.cancel_event,time_budget=5) or []
            except TypeError:
                rows=fn(query,self.media_type,category,120,18,handle.cancel_event,5) or []
            out=[];seen=set();needle=self._folder_search_norm(query)
            for row in rows:
                if handle.cancelled() or not isinstance(row,dict):continue
                hay=" ".join(self._folder_search_norm(row.get(k)) for k in ("name","title","original_name","original_title","_raw_name"))
                if needle and needle not in hay:continue
                item=dict(row);ident=self._folder_item_identity(item,len(out))
                if ident in seen:continue
                seen.add(ident);out.append(item)
            return out
        def _accurate_folder_fallback():
            # Native fast search should be the normal path. If a provider does
            # not support it (or returns an empty native result), fall back to
            # the old authoritative folder index instead of lying to the user
            # with an immediate empty screen. This preserves R75 correctness
            # while keeping the common path fast.
            try:self["status"].setText(_("Searching..."))
            except Exception:pass
            def ready(_rows):
                try:
                    self._folder_search_rows=None
                    self._view_active=True
                    matches=self._build_folder_view()
                    self._load_folder_view_page(1,0)
                    _ui_diag("folder_search_fast",media_type=self.media_type,source="folder_fallback",rows=len(matches),elapsed_ms=int((time.monotonic()-started)*1000))
                except Exception as exc:optional_failure("ui.folder_search_fallback_ready",exc)
            self._ensure_folder_catalog(ready)
        def provider_ok(rows):
            clean=[x for x in (rows or []) if isinstance(x,dict)]
            if not clean:
                try:_ui_diag("folder_search_fast",media_type=self.media_type,source="provider_empty_fallback",rows=0,elapsed_ms=int((time.monotonic()-started)*1000))
                except Exception:pass
                # A section-wide search must not walk every folder after the fast
                # pass. That second scan is what left the screen on Searching.
                if wide:
                    self._folder_search_rows=[]
                    self._view_active=True
                    self._busy=False
                    self._search_light_paint=True
                    self._load_folder_view_page(1,0)
                    try:self["status"].setText(_("No results"))
                    except Exception:pass
                    return
                _accurate_folder_fallback();return
            self._folder_search_rows=clean
            self._view_active=True
            self._busy=False
            self._search_light_paint=True
            self._load_folder_view_page(1,0)
            try:self["status"].setText(_("Ready • %d")%len(clean))
            except Exception:pass
            try:_ui_diag("folder_search_fast",media_type=self.media_type,source="category_provider",rows=len(self._folder_search_rows),elapsed_ms=int((time.monotonic()-started)*1000))
            except Exception:pass
        def provider_failed(error):
            try:_ui_diag("folder_search_fast",media_type=self.media_type,source="provider_error_fallback",rows=0,elapsed_ms=int((time.monotonic()-started)*1000))
            except Exception:pass
            # A section-wide search must not fall through into a full-catalogue
            # scan. That scan is what left the result screen frozen.
            if wide:
                self._folder_search_rows=[]
                self._view_active=True
                self._busy=False
                self._search_light_paint=True
                self._load_folder_view_page(1,0)
                try:self["status"].setText(_("Search failed"))
                except Exception:pass
                return
            _accurate_folder_fallback()
        self._run_async(provider_job,provider_ok,provider_failed)

    def cycle_folder_sort(self):
        if self.media_type not in ("vod","series"):return
        next_mode=(self._sort_mode+1)%len(self._FOLDER_SORT_LABELS)
        def ready(_rows):
            self._sort_mode=next_mode
            self._refresh_search_sort_controls()
            self._load_folder_view_page(1,0)
        self._ensure_folder_catalog(ready)
