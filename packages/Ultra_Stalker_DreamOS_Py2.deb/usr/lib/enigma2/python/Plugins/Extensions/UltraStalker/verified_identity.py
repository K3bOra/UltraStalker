"""Exact, already-verified TMDb identity outranks catalogue decorations."""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str, int
re = _us_env.re


def media_kind(value):
    value = str(value or '').strip().lower()
    if value in ('movie', 'movies', 'vod'):
        return 'movie'
    if value in ('tv', 'series', 'show', 'shows', 'episode'):
        return 'tv'
    return ''


def positive_id(value):
    text = str(value or '').strip()
    return str(int(text)) if re.fullmatch(r'\d{1,12}', text) and int(text) > 0 else ''


def verified_id(item):
    item = item if isinstance(item, dict) else {}
    value = item.get('_locked_tmdb_id') or item.get('_ultra_search_verified_tmdb_id')
    if not value and (item.get('identity_verified') or item.get('identity_pointer_verified')):
        value = item.get('tmdb_id') or item.get('tmdbid')
    return positive_id(value)


def exact_match(item, record):
    """True/False for a proven ID; None leaves title-based validation in charge.

    Raw provider IDs never prove themselves. Movie and TV IDs occupy separate
    namespaces, even if their numeric values happen to be identical.
    """
    item = item if isinstance(item, dict) else {}
    record = record if isinstance(record, dict) else {}
    ident = verified_id(item)
    if not ident:
        return None
    other = positive_id(record.get('tmdb_id'))
    if not other:
        return None
    left = media_kind(item.get('_locked_tmdb_type') or item.get('media_type') or item.get('_search_media_type'))
    right = media_kind(record.get('media_type'))
    return ident == other and not (left and right and left != right)
