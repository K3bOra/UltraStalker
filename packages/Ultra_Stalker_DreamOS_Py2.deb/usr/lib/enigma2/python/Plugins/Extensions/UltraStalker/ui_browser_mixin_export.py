# -*- coding: utf-8 -*-
"""Send to receiver, live-folder export, M3U export and media-folder bouquets.

Methods moved verbatim out of ``PortalBrowserScreen`` (ui_screens_browser.py); behaviour is unchanged.
This module is imported by ui_screens_browser.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str, int, open, max, min
from .ui_screens_browser import (
    _,
    _export_attach_posters,
    _series_poster_path,
    _stamp_episode_export,
    call_compatible,
    os,
    safe_m3u_filename,
    show_notice,
    write_m3u,
)


class BrowserExportMixin(object):
    """Send to receiver, live-folder export, M3U export and media-folder bouquets."""

    def _receiver_cached_art(self, media_type, item, client=None, allow_fetch=False):
        """Resolve receiver artwork, fetching only a single selected Live picon when needed."""
        try:
            if media_type == "itv":
                raw = _image_url(item)
                cached = _cached_live_picon_path(raw, self.profile, item) or ""
                if cached or not allow_fetch or not raw:
                    return cached
                try:
                    return _download_live_portal_temp_picon(raw, self.profile, client or self.client, item=item, timeout=4.5) or ""
                except Exception:
                    return _download_public_live_picon(raw, self.profile, item=item, timeout=4.0) or ""
            snap = load_detail_snapshot(self.profile, media_type, item) or {}
            bundle = _load_visual_bundle(self.profile, media_type, item, snap) or {}
            return str(bundle.get("poster") or snap.get("poster_local") or "")
        except Exception as exc:
            optional_failure("ui.receiver_cached_art", exc)
            return ""

    def send_selected_to_receiver(self):
        if self._busy or self.level != "items" or self.media_type not in ("itv", "vod", "series"):
            return
        idx = self["list"].getSelectedIndex()
        if not (0 <= idx < len(self.content_items)):
            return
        item = dict(self.content_items[idx] or {})
        media_type = self.media_type
        cfg = load_settings()
        keep_index = idx
        raw_title = item.get("name") or item.get("title") or _("Result")
        title = premium_title(raw_title, load_settings().get("clean_titles", True))
        from .export_progress import ExportProgress, start_poll
        progress = ExportProgress(_("Sending to Receiver: %s") % title)
        self["status"].setText(progress.text())
        stop_poll = start_poll(self, progress)

        def work(handle):
            isolated = _new_isolated_source_client(dict(self.profile or {}), timeout=min(6, int(cfg.get("timeout", 10) or 10)))
            try:
                if media_type in ("itv", "vod"):
                    progress.set(_("Details and bouquet: %s") % title, 0, 0)
                    row = dict(item)
                    row["_receiver_name"] = premium_title(row.get("name") or row.get("title") or _("Result"), cfg.get("clean_titles", True))
                    art = self._receiver_cached_art(media_type, row, client=isolated, allow_fetch=(media_type == "itv"))
                    if art:
                        row["_receiver_picon_local"] = art
                    result = export_receiver_items(
                        self.profile, [row], media_type,
                        _("Favorites") if media_type == "itv" else _("Movies"),
                        cfg.get("service_type", 4097),
                    )
                    return result

                # Series title itself is not a playable Enigma2 service. Export
                # its real episodes, keeping them grouped in one receiver bouquet.
                rows = []
                seasons = call_compatible(
                    isolated.series_seasons,
                    (((item,), {"cancel_event": handle.cancel_event}), ((item, handle.cancel_event), {}), ((item,), {})),
                ) or []
                series_name = _clean_display_text(item.get("name") or item.get("title") or "Series", 80)
                poster = self._receiver_cached_art("series", item)
                if not (poster and os.path.isfile(str(poster))):
                    poster = _series_poster_path(self.profile, item, isolated)
                season_groups = []
                progress.set(_("Seasons: %s") % title, 0, len(seasons[:120]))
                for season in seasons[:120]:
                    if handle.cancelled():
                        break
                    progress.tick()
                    episodes = call_compatible(
                        isolated.series_episodes,
                        (((item, season), {"cancel_event": handle.cancel_event}), ((item, season, handle.cancel_event), {}), ((item, season), {})),
                    ) or []
                    season_no = 0
                    try: season_no = int((season or {}).get("season") or (season or {}).get("season_number") or 0)
                    except Exception: season_no = 0
                    season_rows = []
                    for pos, episode in enumerate(episodes, 1):
                        if not isinstance(episode, dict):
                            continue
                        if not (episode.get("cmd") or episode.get("command") or episode.get("url")):
                            continue
                        row = dict(episode)
                        try: ep_no = int(row.get("episode_num") or row.get("episode") or row.get("number") or pos)
                        except Exception: ep_no = pos
                        try: s_no = int(row.get("season") or season_no or 0)
                        except Exception: s_no = season_no or 0
                        if not s_no:
                            s_no = len(season_groups) + 1
                        row["_receiver_name"] = "%s - S%02dE%02d" % (series_name, s_no, ep_no)
                        _stamp_episode_export(row, poster)
                        season_rows.append(row)
                        if len(season_rows) >= 800:
                            break
                    if season_rows:
                        label = "S%02d" % (season_no or (len(season_groups) + 1))
                        season_groups.append({"name": label, "episodes": season_rows})
                    if sum(len(s["episodes"]) for s in season_groups) >= 4000:
                        break
                if not season_groups:
                    raise RuntimeError(_("No playable episodes were found"))
                from .core.bouquets import export_series_category_bouquets
                progress.set(_("Details and bouquet: %s") % title, 0, 0)
                return export_series_category_bouquets(
                    self.profile,
                    [{"name": series_name, "poster": poster, "seasons": season_groups, "metadata":dict(item)}],
                    series_name,
                    "series:" + str(item.get("id") or item.get("series_id") or series_name),
                    cfg.get("service_type", 4097),
                )
            finally:
                try: isolated.close()
                except Exception: pass

        def ok(result):
            stop_poll()
            try: self["list"].moveToIndex(max(0, min(keep_index, len(self.content_items)-1)))
            except Exception: pass
            reload_bouquets()
            try:
                from .core.bouquets import _queue_receiver_epg_seed
                if media_type == "itv":
                    _queue_receiver_epg_seed((result or {}).get("epg_seed") or [])
            except Exception as exc:
                optional_failure("ui.send_receiver_epg_seed", exc)
            count = int((result or {}).get("items") or 0)
            self["status"].setText(_("Sent to Receiver • Items: %d") % count)
            show_notice(self.session, _("Sent to the receiver bouquet list.\n\n%s\nItems: %d") % (title, count), timeout=8, owner=self)

        def failed(exc):
            stop_poll()
            try: self["list"].moveToIndex(max(0, min(keep_index, len(self.content_items)-1)))
            except Exception: pass
            self["status"].setText(_("Send to Receiver failed: %s") % exc)

        if not self._run_async(work, ok, failed):
            stop_poll()

    def export_current_live_folder(self):
        """Export the selected Live category without disturbing category focus."""
        if self._busy or self.level != "genres" or self.media_type != "itv":
            return
        idx = self["list"].getSelectedIndex()
        if not (0 <= idx < len(self.content_items)):
            return
        category = dict(self.content_items[idx] or {})
        category_id = str(category.get("id") or category.get("genre_id") or category.get("name") or category.get("title") or "*")
        category_name = _clean_display_text(category.get("name") or category.get("title") or category_id or _("LIVE"), 80)
        keep_index = idx
        from .export_progress import ExportProgress, start_poll
        progress = ExportProgress(_("Exporting Live folder: %s") % category_name)
        self["status"].setText(progress.text())
        stop_poll = start_poll(self, progress)
        cfg = load_settings()

        def work(handle):
            isolated = _new_isolated_source_client(dict(self.profile or {}), timeout=cfg.get("timeout", 10))
            try:
                rows = call_compatible(
                    isolated.ordered_all,
                    ((("itv", category_id), {"start_page":1, "max_pages":500, "max_items":25000, "cancel_event":handle.cancel_event}),
                     (("itv", category_id, 1, 500, 25000, handle.cancel_event), {})),
                ) or []
                if handle.cancelled():
                    return {}
                prepared = []
                for row in rows:
                    if not isinstance(row, dict):
                        continue
                    if handle.cancelled():
                        return {}
                    # Use a cached logo first. Missing logos are fetched in a small
                    # parallel batch below, then published as receiver picons.
                    prepared.append(self._prepare_live_bouquet_row(row, False))
                missing = list(row for row in prepared if isinstance(row, dict) and not row.get("_receiver_picon_local"))
                if missing and not handle.cancelled():
                    ThreadPoolExecutor = _us_env.concurrent_futures.ThreadPoolExecutor; as_completed = _us_env.concurrent_futures.as_completed
                    def _fetch(row):
                        if handle.cancelled():
                            return row
                        try:
                            for key in ("stream_icon", "picon", "logo", "logo_url", "image", "img", "cover"):
                                value = row.get(key)
                                if not isinstance(value, str) or not value.strip():
                                    continue
                                local = _download_public_live_picon(value, self.profile, item=row, timeout=3.5)
                                if local and os.path.isfile(local):
                                    row["_receiver_picon_local"] = local
                                    row["_receiver_picon_source_local"] = local
                                    return row
                        except Exception:
                            pass
                        return row
                    batch = missing[:200]
                    progress.set(_("Channel logos: %s") % category_name, 0, len(batch))
                    pool = ThreadPoolExecutor(max_workers=min(6, len(batch)))
                    try:
                        futures = list(pool.submit(_fetch, row) for row in batch)
                        for future in as_completed(futures):
                            if handle.cancelled():
                                break
                            progress.tick()
                            try:
                                future.result()
                            except Exception:
                                pass
                    finally:
                        try:
                            pool.shutdown(wait=False, cancel_futures=True)
                        except TypeError:
                            pool.shutdown(wait=False)
                if handle.cancelled():return {}
                progress.set(_("Writing bouquet: %s") % category_name, 0, 0)
                return export_live_category_bouquet(self.profile, prepared, category_name, category_id, cfg.get("service_type", 4097))
            finally:
                try: isolated.close()
                except Exception: pass

        def ok(result):
            stop_poll()
            self._folder_export_active=False
            # Critical: do NOT call load_genres()/refresh_current() here.  That
            # old path reset the category rail to index 0 after export.
            try:
                self["list"].moveToIndex(max(0, min(keep_index, len(self.content_items)-1)))
            except Exception:
                pass
            reload_bouquets()
            try:
                from .core.bouquets import _queue_receiver_epg_seed
                _queue_receiver_epg_seed((result or {}).get("epg_seed") or [])
            except Exception as exc:
                optional_failure("ui.live_folder_epg_seed", exc)
            count = int((result or {}).get("channels") or 0)
            self["status"].setText(_("Live folder exported • Channels: %d") % count)
            show_notice(self.session, _("Live folder exported to the TV bouquet list.\n\n%s\nChannels: %d") % (category_name, count), timeout=10, owner=self)

        def failed(exc):
            stop_poll()
            self._folder_export_active=False
            try:
                self["list"].moveToIndex(max(0, min(keep_index, len(self.content_items)-1)))
            except Exception:
                pass
            self["status"].setText(_("Live folder export failed: %s") % exc)

        self._folder_export_active=True
        if not self._run_async(work, ok, failed):
            stop_poll()
            self._folder_export_active=False

    @staticmethod
    def _m3u_export_root():
        """Pick a persistent export folder, preferring HDD then USB."""
        candidates=("/media/hdd/UltraStalker/M3U", "/media/usb/UltraStalker/M3U", "/tmp/UltraStalker/M3U")
        for path in candidates:
            try:
                os.makedirs(path, exist_ok=True)
                probe=os.path.join(path,".write_test")
                with open(probe,"w") as handle:handle.write("1")
                os.unlink(probe)
                return path
            except Exception:
                continue
        raise RuntimeError(_("No writable storage was found for M3U export"))

    @staticmethod
    def _m3u_epg_id(item):
        row=item if isinstance(item,dict) else {}
        return str(row.get("xmltv_id") or row.get("epg_id") or row.get("tvg_id") or row.get("channel_id") or "").strip()

    def _m3u_export_entry(self, client, item, media_type, group_name, display_name=None, series_id=None, cancel_event=None):
        """Resolve one provider row into a portable M3U entry."""
        row=dict(item or {}) if isinstance(item,dict) else {}
        if cancel_event is not None and cancel_event.is_set():
            return None
        url=call_compatible(client.create_link,[
            ((row,media_type,series_id),{'cancel_event':cancel_event}),
            ((row,media_type,series_id),{}),((row,media_type),{})])
        url=str(url or "").strip()
        if not url:
            return None
        raw_name=display_name or row.get("name") or row.get("title") or row.get("id") or _("Stream")
        if media_type=="itv":
            name=_clean_live_channel_name(raw_name)
        else:
            name=premium_title(raw_name, load_settings().get("clean_titles",True))
        logo=""
        try:logo=str(_image_url(row) or "").strip()
        except Exception:pass
        return {
            "name":name,
            "tvg_name":name,
            "tvg_id":self._m3u_epg_id(row),
            "logo":logo,
            "group":group_name,
            "url":url,
        }

    def export_current_category_m3u(self):
        """Export the selected Live/Movies/Series category as a standalone M3U."""
        if self._busy or self.level!="genres" or self.media_type not in ("itv","vod","series"):
            return
        idx=self["list"].getSelectedIndex()
        if not (0<=idx<len(self.content_items)):
            return
        category=dict(self.content_items[idx] or {})
        category_id=str(category.get("id") or category.get("genre_id") or category.get("name") or category.get("title") or "*")
        category_name=_clean_display_text(category.get("name") or category.get("title") or category_id or _("Category"),80)
        media_type=self.media_type
        keep_index=idx
        cfg=load_settings()
        self["status"].setText(_("Exporting M3U: %s")%category_name)

        def work(handle):
            isolated=_new_isolated_source_client(dict(self.profile or {}),timeout=min(8,int(cfg.get("timeout",10) or 10)))
            try:
                items=call_compatible(
                    isolated.ordered_all,
                    (((media_type,category_id),{"start_page":1,"max_pages":500,"max_items":25000,"cancel_event":handle.cancel_event}),
                     ((media_type,category_id,1,500,25000,handle.cancel_event),{})),
                ) or []
                if handle.cancelled():return {}
                entries=[]
                if media_type in ("itv","vod"):
                    for item in items:
                        if handle.cancelled():break
                        if not isinstance(item,dict):continue
                        entry=self._m3u_export_entry(isolated,item,media_type,category_name,cancel_event=handle.cancel_event)
                        if entry:entries.append(entry)
                else:
                    # Series categories export playable episodes, not dead series headers.
                    for series in [dict(x) for x in items if isinstance(x,dict)]:
                        if handle.cancelled():break
                        series_name=premium_title(series.get("name") or series.get("title") or _("Series"),cfg.get("clean_titles",True))
                        series_id=series.get("id") or series.get("series_id")
                        try:
                            seasons=call_compatible(
                                isolated.series_seasons,
                                (((series,),{"cancel_event":handle.cancel_event}),((series,handle.cancel_event),{}),((series,),{})),
                            ) or []
                        except Exception:
                            seasons=[]
                        for season in seasons:
                            if handle.cancelled():break
                            try:
                                episodes=call_compatible(
                                    isolated.series_episodes,
                                    (((series,season),{"cancel_event":handle.cancel_event}),((series,season,handle.cancel_event),{}),((series,season),{})),
                                ) or []
                            except Exception:
                                episodes=[]
                            try:season_no=int((season or {}).get("season") or (season or {}).get("season_id") or 0)
                            except Exception:season_no=0
                            for pos,episode in enumerate(episodes,1):
                                if handle.cancelled():break
                                if not isinstance(episode,dict):continue
                                try:ep_no=int(episode.get("episode_num") or episode.get("episode") or episode.get("number") or pos)
                                except Exception:ep_no=pos
                                try:s_no=int(episode.get("season") or season_no or 0)
                                except Exception:s_no=season_no or 0
                                label="%s - S%02dE%02d"%(series_name,s_no,ep_no)
                                entry=self._m3u_export_entry(isolated,episode,"series",category_name,label,series_id,handle.cancel_event)
                                if entry:entries.append(entry)
                if handle.cancelled():return {}
                if not entries:
                    raise RuntimeError(_("No playable items were found in this category"))
                root=self._m3u_export_root()
                prefix={"itv":"Live","vod":"Movies","series":"Series"}.get(media_type,"Category")
                filename=safe_m3u_filename("%s - %s"%(prefix,category_name))+".m3u"
                path=os.path.join(root,filename)
                count=write_m3u(path,entries,category_name)
                if count<=0:raise RuntimeError(_("No playable items were written"))
                return {"path":path,"items":count}
            finally:
                try:isolated.close()
                except Exception:pass

        def ok(result):
            self._folder_export_active=False
            try:self["list"].moveToIndex(max(0,min(keep_index,len(self.content_items)-1)))
            except Exception:pass
            path=str((result or {}).get("path") or "")
            count=int((result or {}).get("items") or 0)
            if not path:return
            self["status"].setText(_("M3U exported • Items: %d")%count)
            show_notice(self.session, _("M3U export completed.\n\n%s\nItems: %d")%(path,count), timeout=10, owner=self)

        def failed(exc):
            self._folder_export_active=False
            try:self["list"].moveToIndex(max(0,min(keep_index,len(self.content_items)-1)))
            except Exception:pass
            self["status"].setText(_("M3U export failed: %s")%exc)

        # A large category resolves one stream link per item; BACK must be able
        # to cancel it (back() honours _folder_export_active) instead of showing
        # "Please wait" until the whole export finishes.
        self._folder_export_active=True
        if not self._run_async(work,ok,failed):
            self._folder_export_active=False

    def add_media_folder_to_bouquet(self):
        """Ask for an existing TV bouquet, then add the current Movies/Series folder to it."""
        if self._busy or self.level != "genres" or self.media_type not in ("vod", "series"):
            return
        try:
            bouquets = list_tv_bouquets() or []
        except Exception as exc:
            self["status"].setText(_("Could not read TV bouquets: %s") % exc)
            return
        if not bouquets:
            show_notice(self.session, _("No TV bouquets were found on the receiver."), timeout=7, owner=self)
            return
        choices = [(str(r.get("name") or r.get("filename")), str(r.get("filename"))) for r in bouquets]
        self.session.openWithCallback(self._media_bouquet_chosen, ChoiceBox, title=_("Choose target Bouquet"), list=choices)

    def _media_bouquet_chosen(self, choice):
        if not choice or self._busy:
            return
        filename = str(choice[1] if isinstance(choice, (tuple, list)) and len(choice) > 1 else "")
        label = str(choice[0] if isinstance(choice, (tuple, list)) and choice else filename)
        if filename:
            self.export_current_media_folder(target=(filename, label))

    def export_current_media_folder(self, target=None):
        """Export Movies quickly, or Series as one child bouquet per series.

        ``target=(filename, label)`` adds the folder to that existing bouquet instead.
        """
        if self._busy or self.level != "genres" or self.media_type not in ("vod", "series"):
            return
        idx = self["list"].getSelectedIndex()
        if not (0 <= idx < len(self.content_items)):
            return
        category = dict(self.content_items[idx] or {})
        category_id = str(category.get("id") or category.get("genre_id") or category.get("name") or category.get("title") or "*")
        category_name = _clean_display_text(category.get("name") or category.get("title") or category_id or _("Result"), 80)
        media_type = self.media_type
        keep_index = idx
        cfg = load_settings()
        from .export_progress import ExportProgress, start_poll
        progress = ExportProgress(_("Exporting %s folder: %s") % ((_("Movies") if media_type == "vod" else _("Series")), category_name))
        self["status"].setText(progress.text())
        stop_poll = start_poll(self, progress)
        EPISODE_CAP = 2000

        def _local_art_only(row):
            # Export must never scan detail snapshots or rebuild artwork. Only reuse
            # a path already present on the resolved row, otherwise skip the picon.
            for key in ("_receiver_picon_local", "poster_local", "cover_local", "image_local", "picon_local", "logo_local"):
                path = str((row or {}).get(key) or "")
                try:
                    if path and os.path.isfile(path):
                        return path
                except Exception:
                    pass
            return ""

        def work(handle):
            isolated = _new_isolated_source_client(dict(self.profile or {}), timeout=min(6, int(cfg.get("timeout", 10) or 10)))
            try:
                items = call_compatible(
                    isolated.ordered_all,
                    (((media_type, category_id), {"start_page":1, "max_pages":500, "max_items":25000, "cancel_event":handle.cancel_event}),
                     ((media_type, category_id, 1, 500, 25000, handle.cancel_event), {})),
                ) or []
                if handle.cancelled():
                    return {}
                progress.set(_("Reading folder: %s") % category_name, 0, 0)

                if media_type == "vod":
                    rows = []
                    for item in items:
                        if not isinstance(item, dict) or not (item.get("cmd") or item.get("command") or item.get("url")):
                            continue
                        row = dict(item)
                        row["_receiver_name"] = premium_title(row.get("name") or row.get("title") or "Movie", cfg.get("clean_titles", True))
                        art = _local_art_only(row)
                        if art:
                            row["_receiver_picon_local"] = art
                        rows.append(row)
                    if not rows:
                        raise RuntimeError(_("No playable movies were found"))
                    progress.set(_("Posters: %s") % category_name, 0, min(80, len(rows)))
                    _export_attach_posters(self.profile, isolated, rows, limit=80, progress=progress)
                    from .core.bouquets import export_vod_category_bouquet
                    if handle.cancelled():return {}
                    if target:
                        from .core.bouquets import append_receiver_items_to_bouquet
                        progress.set(_("Details: %s") % category_name, 0, len(rows))
                        return append_receiver_items_to_bouquet(self.profile, rows, "vod", target[0], cfg.get("service_type", 4097),
                                                                progress=lambda d, t: progress.set(done=d, total=t))
                    progress.set(_("Writing bouquet: %s") % category_name, 0, 0)
                    return export_vod_category_bouquet(self.profile, rows, category_name, category_id, cfg.get("service_type", 4097))

                # One worker per series (bounded). Each worker owns its client,
                # avoiding the old serial Series -> Season -> Episodes chain.
                series_items = list(dict(x) for x in items if isinstance(x, dict))
                if not series_items:
                    raise RuntimeError(_("No series were found"))

                def fetch_series(series):
                    client = _new_isolated_source_client(dict(self.profile or {}), timeout=min(6, int(cfg.get("timeout", 10) or 10)))
                    try:
                        series_name = premium_title(series.get("name") or series.get("title") or "Series", cfg.get("clean_titles", True))
                        poster = _series_poster_path(self.profile, series, client)
                        try:
                            seasons = call_compatible(
                                client.series_seasons,
                                (((series,), {"cancel_event":handle.cancel_event}), ((series, handle.cancel_event), {}), ((series,), {})),
                            ) or []
                        except Exception as exc:
                            return {"name": series_name, "poster": poster, "seasons": [], "error": str(exc)}
                        season_groups = []
                        for season in seasons[:120]:
                            if handle.cancelled():
                                break
                            try:
                                episodes = call_compatible(
                                    client.series_episodes,
                                    (((series, season), {"cancel_event":handle.cancel_event}), ((series, season, handle.cancel_event), {}), ((series, season), {})),
                                ) or []
                            except Exception:
                                episodes = []
                            try: season_no = int((season or {}).get("season") or (season or {}).get("season_number") or 0)
                            except Exception: season_no = 0
                            season_rows = []
                            for pos, episode in enumerate(episodes, 1):
                                if not isinstance(episode, dict) or not (episode.get("cmd") or episode.get("command") or episode.get("url")):
                                    continue
                                row = dict(episode)
                                try: ep_no = int(row.get("episode_num") or row.get("episode") or row.get("number") or pos)
                                except Exception: ep_no = pos
                                try: s_no = int(row.get("season") or season_no or 0)
                                except Exception: s_no = season_no or 0
                                if not s_no:
                                    s_no = len(season_groups) + 1
                                row["_receiver_name"] = "%s - S%02dE%02d" % (series_name, s_no, ep_no)
                                _stamp_episode_export(row, poster)
                                season_rows.append(row)
                                if len(season_rows) >= 800:
                                    break
                            if season_rows:
                                season_groups.append({"name": "S%02d" % (season_no or (len(season_groups) + 1)), "episodes": season_rows})
                            if sum(len(s["episodes"]) for s in season_groups) >= 4000:
                                break
                        if not season_groups:
                            return {"name": series_name, "poster": poster, "seasons": [], "error": "no episodes"}
                        return {"name": series_name, "poster": poster, "seasons": season_groups, "metadata":dict(series)}
                    finally:
                        try: client.close()
                        except Exception: pass

                groups = []
                skipped = []
                progress.set(_("Series: %s") % category_name, 0, len(series_items))
                workers = max(1, min(4, len(series_items)))
                pool = ThreadPoolExecutor(max_workers=workers, thread_name_prefix="ultrastalker-series-export")
                try:
                    futures = list(pool.submit(fetch_series, series) for series in series_items)
                    for future in as_completed(futures):
                        if handle.cancelled():
                            break
                        progress.tick()
                        try:
                            group = future.result()
                        except Exception as exc:
                            skipped.append(str(exc))
                            group = None
                        if isinstance(group, dict) and group.get("seasons"):
                            groups.append(group)
                        elif isinstance(group, dict):
                            skipped.append(str(group.get("name") or "Series"))
                finally:
                    try:
                        pool.shutdown(wait=False, cancel_futures=True)
                    except TypeError:
                        pool.shutdown(wait=False)
                if handle.cancelled():
                    return {}
                if not groups:
                    detail = ", ".join(skipped[:3])
                    raise RuntimeError(_("No playable episodes were found") + (("\n" + detail) if detail else ""))
                # Preserve the provider/category order rather than completion order.
                order = {premium_title(x.get("name") or x.get("title") or "Series", cfg.get("clean_titles", True)): n for n, x in enumerate(series_items)}
                groups.sort(key=lambda g: order.get(g.get("name"), 999999))
                from .core.bouquets import export_series_category_bouquets
                if handle.cancelled():return {}
                if target:
                    from .core.bouquets import append_receiver_items_to_bouquet, _prepare_export_metadata
                    flat = []
                    progress.set(_("Details: %s") % category_name, 0, len(groups))
                    for g_idx, g in enumerate(groups, 1):
                        if handle.cancelled():
                            return {}
                        seasons_list = g.get("seasons") or []
                        series_meta = _prepare_export_metadata(
                            self.profile,
                            g.get("metadata") or {"name": g.get("name")},
                            "series",
                            len(seasons_list),
                        )
                        progress.set(done=g_idx, total=len(groups))
                        for season in seasons_list:
                            for ep_row in (season.get("episodes") or []):
                                if isinstance(ep_row, dict):
                                    ep_copy = dict(ep_row)
                                    ep_copy["_receiver_metadata"] = series_meta
                                    flat.append(ep_copy)
                    truncated = max(0, len(flat) - EPISODE_CAP)
                    flat = flat[:EPISODE_CAP]
                    progress.set(_("Writing bouquet: %s") % category_name, 0, len(flat))
                    result = append_receiver_items_to_bouquet(self.profile, flat, "episode", target[0], cfg.get("service_type", 4097),
                                                              progress=lambda d, t: progress.set(done=d, total=t))
                    if isinstance(result, dict):
                        result["series"] = len(groups); result["skipped"] = len(skipped); result["truncated"] = truncated
                    return result
                progress.set(_("Writing bouquets: %s") % category_name, 0, 0)
                result = export_series_category_bouquets(self.profile, groups, category_name, category_id, cfg.get("service_type", 4097))
                if isinstance(result, dict):
                    result["skipped"] = len(skipped)
                    result["skipped_names"] = skipped[:8]
                return result
            finally:
                try: isolated.close()
                except Exception: pass

        def ok(result):
            stop_poll()
            self._folder_export_active=False
            try: self["list"].moveToIndex(max(0, min(keep_index, len(self.content_items)-1)))
            except Exception: pass
            reload_bouquets()
            count = int((result or {}).get("items") or 0)
            series_count = int((result or {}).get("series") or 0)
            if target:
                added = int((result or {}).get("added") or 0)
                self["status"].setText(_("Bouquet updated • New items: %d") % added)
                extra = (_("\nNot added (limit %d episodes): %d") % (EPISODE_CAP, int(result.get("truncated") or 0))) if int((result or {}).get("truncated") or 0) else ""
                show_notice(self.session, _("Added to Bouquet: %s\n\n%s\nNew items: %d%s") % (target[1], category_name, added, extra), timeout=10, owner=self)
                return
            if media_type == "series":
                skipped = int((result or {}).get("skipped") or 0)
                self["status"].setText(_("Series folder sent • Series: %d") % series_count)
                extra = _("\nSkipped: %d") % skipped if skipped else ""
                show_notice(self.session, _("Series folder exported.\n\n%s\nSeries: %d • Episodes: %d%s") % (category_name, series_count, count, extra), timeout=12, owner=self)
            else:
                self["status"].setText(_("Movies folder sent • Movies: %d") % count)
                show_notice(self.session, _("Movies folder exported.\n\n%s\nMovies: %d") % (category_name, count), timeout=10, owner=self)

        def failed(exc):
            stop_poll()
            self._folder_export_active=False
            try: self["list"].moveToIndex(max(0, min(keep_index, len(self.content_items)-1)))
            except Exception: pass
            self["status"].setText(_("Folder export failed: %s") % exc)

        self._folder_export_active=True
        if not self._run_async(work, ok, failed):
            stop_poll()
            self._folder_export_active=False
