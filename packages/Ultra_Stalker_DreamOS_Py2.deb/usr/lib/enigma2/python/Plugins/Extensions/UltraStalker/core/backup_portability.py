# -*- coding: utf-8 -*-
"""Portable backup settings, shared by Python 2.7 and Python 3 builds."""
from __future__ import absolute_import, unicode_literals
import json
import os


def available_services(is_dreamos=False, exists=None):
    """Use the same installed-engine checks as the playback service."""
    exists = exists or os.path.exists
    services = {1, 4097}
    if exists("/usr/bin/gstplayer"):
        services.add(5001)
    if exists("/usr/bin/exteplayer3"):
        services.add(5002)
    if is_dreamos or any(exists(path) for path in (
        "/usr/lib/enigma2/python/Plugins/SystemPlugins/ServiceApp",
        "/usr/lib/enigma2/python/Plugins/Extensions/ServiceApp",
        "/usr/lib/enigma2/python/Plugins/SystemPlugins/ServiceApp/serviceapp.so",
    )):
        services.add(8193)
    return services


def adapt_settings_file(path, is_dreamos=False):
    """Adapt only an unavailable engine in the staged, verified settings file.

    Every other preference stays as archived. This runs before the transactional
    restore commit, so a failed restore still rolls back the original settings.
    Archives without platform metadata are supported by probing the target.
    """
    if not os.path.isfile(path):
        return {}
    with open(path, "rb") as handle:
        settings = json.loads(handle.read().decode("utf-8", "strict"))
    if not isinstance(settings, dict):
        raise ValueError("Backup settings must be a JSON object")
    if "service_type" not in settings:
        return {}
    try:
        engine = int(settings["service_type"])
    except (ValueError, TypeError):
        engine = None
    if engine in available_services(is_dreamos):
        return {}
    fallback = 8193 if is_dreamos else 4097
    previous = settings["service_type"]
    settings["service_type"] = fallback
    payload = json.dumps(settings, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    with open(path, "wb") as handle:
        handle.write(payload)
    return {"service_type": {"from": previous, "to": fallback}}
