"""Bounded receiver evidence for cross-folder metadata, without credentials."""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str
hashlib = _us_env.hashlib
json = _us_env.json
os = _us_env.os
re = _us_env.re
threading = _us_env.threading
time = _us_env.time
from .securefs import secure_private_dir
from .version import BUILD_NAME

TRACE_PATH = '/tmp/ultrastalker/metadata_trace.jsonl'
_LOCK = threading.RLock()


def _hash(parts):
    return hashlib.sha256(json.dumps(parts,sort_keys=True,default=str).encode('utf-8')).hexdigest()[:16]


def trace_metadata(stage,profile,item,row,settings,overview=None,folder='',error=''):
    """Called from a metadata worker; titles/IDs and field presence only."""
    try:
        profile=profile if isinstance(profile,dict) else {}
        item=item if isinstance(item,dict) else {}
        row=row if isinstance(row,dict) else {}
        settings=settings if isinstance(settings,dict) else {}
        value=str(overview or '')
        data={
            'time':time.strftime('%Y-%m-%dT%H:%M:%S'), 'build':BUILD_NAME,
            'stage':str(stage)[:50], 'title':str(item.get('name') or item.get('title') or '')[:150],
            'folder':str(folder or '')[:120],
            'source':_hash(list(profile.get(k) for k in ('portal','mac','source_type'))),
            'item':_hash(list(item.get(k) for k in ('id','movie_id','series_id','cmd','url'))),
            'tmdb_id':str(row.get('tmdb_id') or ''), 'media_type':str(row.get('media_type') or ''),
            'verified':bool(row.get('identity_verified') or row.get('identity_pointer_verified')),
            'bridge':str(row.get('_details_identity_bridge') or ''),
            'country':str(row.get('countries') or row.get('production_countries') or row.get('origin_country') or row.get('country') or '')[:160],
            'original_language':str(row.get('original_language') or '')[:30],
            'year':str(row.get('year') or row.get('release_date') or '')[:20],
            'requested_language':str(settings.get('description_language') or '')[:30],
            'tmdb_enabled':bool(settings.get('tmdb_enabled',True)),
            'credential_present':bool(str(settings.get('tmdb_credential') or '').strip()),
            'metadata_language':str(row.get('_details_metadata_language') or '')[:30],
            'schema':row.get('_details_metadata_schema'), 'origin_checked':bool(row.get('_details_origin_checked')),
            'overview_chars':len(value), 'overview_has_arabic':bool(re.search(r'[\u0600-\u06ff]',value)),
            'provider_fields':list(row.get('_details_provider_fields') or ())[:20],
            'error':str(error)[:80],
        }
        with _LOCK:
            secure_private_dir(os.path.dirname(TRACE_PATH))
            if os.path.islink(TRACE_PATH):return
            if os.path.isfile(TRACE_PATH) and os.path.getsize(TRACE_PATH)>128*1024:
                os.replace(TRACE_PATH,TRACE_PATH+'.1')
            flags=os.O_WRONLY|os.O_CREAT|os.O_APPEND|getattr(os,'O_NOFOLLOW',0)
            fd=os.open(TRACE_PATH,flags,0o600)
            with os.fdopen(fd,'a',encoding='utf-8') as handle:
                handle.write(json.dumps(data,ensure_ascii=False,sort_keys=True)+'\n')
    except Exception:
        # A diagnostic failure must not change metadata or interrupt navigation.
        pass
