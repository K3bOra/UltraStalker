# -*- coding: utf-8 -*-
"""Receiver-side guards installed once per Enigma2 session.

1. OpenWebif screenshot guard.  On DreamOS, eConsoleAppContainer.execute()
   often returns the child pid (>0) when /usr/bin/grab actually started.
   OpenWebif treats any true value as failure and raises
   "failed to execute: /usr/bin/grab ..." from render().  Twisted logs that
   as an Unhandled Error, finishes the HTTP request, and the later grab
   callback writes into the finished request.  That RuntimeError is raised
   inside an Enigma2 C++ callback and aborts the whole GUI (seen on DreamOS
   OE2.5 / dm900).  Two guards cover it:
     - execute() is normalized to 0 when the process really is running, so
       OpenWebif follows its normal success path and the screenshot works.
     - render()/callbacks still cannot escape into C++ or Twisted if grab
       genuinely failed to start.


2. ePixmap.setPixmap(None) on DreamOS prints a warning plus a stack trace
   every time ("please use ePixmap.setPixmap(enigma.gPixmapPtr())").  An empty
   gPixmapPtr() is what DreamOS expects for "no picture".

3. Skin completion.  Screens that share one Python base with other layouts
   create widgets their own skin does not place; Enigma2 prints a
   "skin is missing element" warning for each.  complete_skin() adds an
   invisible 1x1 placeholder for exactly those widgets, which matches what
   Enigma2 already does for them (an unplaced widget) without the warnings.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str, int
re = _us_env.re
import sys
from . import us_env
_STATE = {'openwebif': 0, 'pixmap': 0, 'console_execute': 0}

def _log():
    try:
        from .log import get_logger
        return get_logger()
    except Exception:
        return None
_GRAB_CALLBACKS = ('grabFinished', 'grabData', 'dataAvail', 'appClosed', 'stdoutAvail', 'stderrAvail')

def dreamos_execute_result(result, running):
    """Map DreamOS execute() onto the contract OpenWebif was written for.

    OE-Alliance returns 0 when the child started. DreamOS often returns the
    pid (or True) instead, and OpenWebif then raises "failed to execute"
    even though grab is running. A positive/True result counts as success
    only while the container is actually running; a real spawn failure
    (nothing running) is left untouched.
    """
    if result in (0, None, False):
        return result
    alive = bool(running)
    if result is True:
        return 0 if alive else result
    try:
        number = int(result)
    except (TypeError, ValueError):
        return result
    if number > 0 and alive:
        return 0
    return result

def _container_running(container):
    if container is None:
        return False
    for name in ('running', 'getPID'):
        probe = getattr(container, name, None)
        if not callable(probe):
            continue
        try:
            value = probe()
        except Exception:
            continue
        try:
            if int(value or 0) > 0:
                return True
        except (TypeError, ValueError):
            if value:
                return True
    return False

def _guard_console_execute():
    """Normalize DreamOS execute() so a started child is not reported as failure."""
    if not getattr(us_env, 'IS_DREAMOS', False):
        return 0
    try:
        from enigma import eConsoleAppContainer
    except Exception:
        return 0
    original = getattr(eConsoleAppContainer, 'execute', None)
    if original is None or getattr(original, '_us_dreamos_execute', False):
        return 0

    def execute(self, *args, **kwargs):
        result = original(self, *args, **kwargs)
        try:
            return dreamos_execute_result(result, _container_running(self))
        except Exception:
            return result
    execute._us_dreamos_execute = True
    execute.__name__ = us_env.native_str('execute')
    try:
        eConsoleAppContainer.execute = execute
    except Exception:
        return 0
    _STATE['console_execute'] = 1
    return 1

def _grab_container(owner, request):
    for obj in (getattr(request, 'grab_in_progress', None), owner):
        if obj is None:
            continue
        container = getattr(obj, 'container', None)
        if container is not None:
            return container
    return None

def _guard_render(cls):
    original = cls.__dict__.get('render')
    if original is None or getattr(original, '_us_guard', False):
        return False

    def render(self, request, *args, **kwargs):
        try:
            return original(self, request, *args, **kwargs)
        except Exception as exc:
            text = str(exc or '')
            if 'failed to execute' not in text:
                raise
            log = _log()
            container = _grab_container(self, request)
            running = _container_running(container)
            if log is not None:
                log.warning('OpenWebif screenshot render contained: running=%s %s', running, exc)
            if running:
                try:
                    from twisted.web import server
                    return server.NOT_DONE_YET
                except Exception:
                    return b''
            try:
                request.setResponseCode(500)
                request.setHeader('Content-Type', 'text/plain')
            except Exception:
                pass
            return b'screenshot unavailable'
    render._us_guard = True
    render.__name__ = us_env.native_str('render')
    render.__doc__ = getattr(original, '__doc__', None)
    setattr(cls, 'render', render)
    return True

def _guard_method(cls, name):
    original = cls.__dict__.get(name)
    if original is None or getattr(original, '_us_guard', False):
        return False

    def guarded(self, *args, **kwargs):
        try:
            return original(self, *args, **kwargs)
        except RuntimeError as exc:
            log = _log()
            if log is not None:
                log.warning('OpenWebif screenshot callback ignored: %s', exc)
            return None
        except Exception as exc:
            log = _log()
            if log is not None:
                log.warning('OpenWebif screenshot callback failed: %s', exc)
            return None
    guarded._us_guard = True
    guarded.__name__ = getattr(original, '__name__', us_env.native_str(name))
    guarded.__doc__ = getattr(original, '__doc__', None)
    setattr(cls, name, guarded)
    return True

def _grab_modules():
    found = []
    for mod_name, module in list(sys.modules.items()):
        if module is None:
            continue
        if not (mod_name == 'grab' or mod_name.endswith('.grab')):
            continue
        path = str(getattr(module, '__file__', '') or '')
        if 'OpenWebif' in path:
            found.append(module)
    return found

def guard_openwebif_grab(import_if_present=True):
    """Patch OpenWebif's screenshot request class; safe to call repeatedly."""
    patched = 0
    try:
        patched += _guard_console_execute()
    except Exception:
        pass
    modules = _grab_modules()
    if not modules and import_if_present:
        os = _us_env.os
        path = '/usr/lib/enigma2/python/Plugins/Extensions/OpenWebif/controllers/models/grab.py'
        if os.path.exists(path) or os.path.exists(path + 'o') or os.path.exists(path + 'c'):
            try:
                __import__(us_env.native_str('Plugins.Extensions.OpenWebif.controllers.models.grab'))
            except Exception:
                pass
            modules = _grab_modules()
    for module in modules:
        for value in list(vars(module).values()):
            if not isinstance(value, type) and type(value).__name__ != 'classobj':
                continue
            if getattr(value, '__module__', None) != module.__name__:
                continue
            try:
                if _guard_render(value):
                    patched += 1
            except Exception:
                pass
            for name in _GRAB_CALLBACKS:
                if name in getattr(value, '__dict__', {}):
                    try:
                        if _guard_method(value, name):
                            patched += 1
                    except Exception:
                        pass
    _STATE['openwebif'] += patched
    return patched

def guard_empty_pixmaps():
    if not us_env.IS_DREAMOS or _STATE['pixmap']:
        return _STATE['pixmap']
    try:
        import enigma
    except Exception:
        return 0
    empty_factory = getattr(enigma, 'gPixmapPtr', None)
    if empty_factory is None:
        return 0
    patched = 0
    for name in dir(enigma):
        cls = getattr(enigma, name, None)
        if not isinstance(cls, type) and type(cls).__name__ != 'classobj':
            continue
        original = getattr(cls, '__dict__', {}).get('setPixmap')
        if original is None or not callable(original) or getattr(original, '_us_pixmap_guard', False):
            continue

        def make(orig):

            def set_pixmap(self, *args):
                if args and args[0] is None:
                    try:
                        args = (empty_factory(),) + tuple(args[1:])
                    except Exception:
                        pass
                return orig(self, *args)
            set_pixmap._us_pixmap_guard = True
            set_pixmap.__name__ = us_env.native_str('setPixmap')
            return set_pixmap
        try:
            setattr(cls, 'setPixmap', make(original))
            patched += 1
        except Exception:
            pass
    _STATE['pixmap'] = patched
    return patched

class SlotHandle(object):
    __slots__ = ('_slot',)

    def __init__(self, slot):
        self._slot = slot

    def disconnect(self):
        self._slot = None

    def __getattr__(self, name):
        slot = object.__getattribute__(self, '_slot')
        if slot is None:
            raise AttributeError(name)
        return getattr(slot, name)

def _wrap_connect(cls):
    original = getattr(cls, '__dict__', {}).get('connect')
    if original is None or not callable(original) or getattr(original, '_us_slot_handle', False):
        return False

    def connect(self, *args, **kwargs):
        result = original(self, *args, **kwargs)
        if result is None or hasattr(result, 'disconnect'):
            return result
        kind = type(result).__name__
        if not (kind.startswith('ePythonSlot') or kind.startswith('eConnection') or kind.startswith('ePySlot')):
            return result
        return SlotHandle(result)
    connect._us_slot_handle = True
    connect.__name__ = us_env.native_str('connect')
    connect.__doc__ = getattr(original, '__doc__', None)
    setattr(cls, 'connect', connect)
    return True

class _TimerCallbacks(object):
    """eTimer.callback for images that only have timeout.connect()."""

    def __init__(self, timer):
        self._timer = timer
        self._items = []

    def append(self, func):
        conn = self._timer.timeout.connect(func)
        self._items.append((func, conn))

    def remove(self, func):
        for index, (known, _conn) in enumerate(self._items):
            if known == func:
                del self._items[index]
                return
        raise ValueError('callback not connected')

    def __contains__(self, func):
        return any((known == func for known, _conn in self._items))

    def __iter__(self):
        return iter([known for known, _conn in self._items])

    def __len__(self):
        return len(self._items)

    def __bool__(self):
        return bool(self._items)
    __nonzero__ = __bool__
_TIMER_LISTS = {}

def _timer_callbacks(timer):
    try:
        existing = timer.__dict__.get('_us_callbacks')
        if existing is None:
            existing = _TimerCallbacks(timer)
            timer.__dict__['_us_callbacks'] = existing
        return existing
    except Exception:
        key = id(timer)
        existing = _TIMER_LISTS.get(key)
        if existing is None or existing._timer is not timer:
            existing = _TimerCallbacks(timer)
            _TIMER_LISTS[key] = existing
        return existing

def guard_dreamos_enigma():
    if not us_env.IS_DREAMOS or _STATE.get('dreamos'):
        return _STATE.get('dreamos')
    try:
        import enigma
    except Exception:
        return None
    done = []
    for name in dir(enigma):
        cls = getattr(enigma, name, None)
        if not (name.startswith('eSignal') or name.startswith('PSignal')):
            continue
        if (isinstance(cls, type) or type(cls).__name__ == 'classobj') and 'connect' in getattr(cls, '__dict__', {}):
            try:
                if _wrap_connect(cls):
                    done.append('connect:' + name)
            except Exception:
                pass
    timer_cls = getattr(enigma, 'eTimer', None)
    if timer_cls is not None:
        try:
            probe = timer_cls()
            signal_cls = type(probe.timeout)
            if _wrap_connect(signal_cls):
                done.append('connect:' + signal_cls.__name__)
            slot = probe.timeout.connect(lambda: None)
            raw = getattr(slot, '_slot', slot)
            slot_cls = type(raw)
            if not isinstance(slot, SlotHandle) and (not hasattr(slot_cls, 'disconnect')):
                try:
                    setattr(slot_cls, 'disconnect', lambda self: None)
                    done.append('disconnect:' + slot_cls.__name__)
                except Exception:
                    pass
            done.append('signal=%s slot=%s' % (signal_cls.__name__, slot_cls.__name__))
            del slot, raw, probe
        except Exception as exc:
            done.append('timer probe failed: %s' % (exc,))
        if not hasattr(timer_cls, 'callback'):
            try:
                timer_cls.callback = property(_timer_callbacks)
                done.append('eTimer.callback')
            except Exception as exc:
                done.append('eTimer.callback failed: %s' % (exc,))
    label_cls = getattr(enigma, 'eLabel', None)
    desktop = getattr(enigma, 'getDesktop', None)
    original = getattr(label_cls, '__dict__', {}).get('__init__') if label_cls is not None else None
    window_cls = getattr(enigma, 'eWindow', None)
    if original is not None and desktop is not None and (window_cls is not None) and (not getattr(original, '_us_parent', False)):
        holder = []

        def probe_parent():
            if not holder:
                window = window_cls(desktop(0), -100)
                holder.append(window)
            return holder[0].child()

        def __init__(self, *args, **kwargs):
            if not args and 'parent' not in kwargs:
                args = (probe_parent(),)
            return original(self, *args, **kwargs)
        __init__._us_parent = True
        __init__.__name__ = us_env.native_str('__init__')
        try:
            label_cls.__init__ = __init__
            done.append('eLabel.parent')
        except Exception:
            pass
    if label_cls is not None and (not hasattr(label_cls, 'setNoWrap')):
        try:
            label_cls.setNoWrap = lambda self, value=0: None
            done.append('eLabel.setNoWrap')
        except Exception:
            pass
    try:
        from Components.config import ConfigSubsection, ConfigElement
        orig_cs_getattr = getattr(ConfigSubsection, '__dict__', {}).get('__getattr__')
        if callable(orig_cs_getattr) and (not getattr(orig_cs_getattr, '_us_attr_key_guard', False)):

            class _ConfigAttrKeyError(AttributeError, KeyError):
                pass

            def _cs_getattr(self, name):
                try:
                    return orig_cs_getattr(self, name)
                except KeyError as exc:
                    raise _ConfigAttrKeyError(exc.args[0] if exc.args else name)
            _cs_getattr._us_attr_key_guard = True
            _cs_getattr.__name__ = us_env.native_str('__getattr__')
            ConfigSubsection.__getattr__ = _cs_getattr
            done.append('ConfigSubsection.__getattr__')
        orig_add_notifier = getattr(ConfigElement, '__dict__', {}).get('addNotifier')
        if callable(orig_add_notifier) and (not getattr(orig_add_notifier, '_us_notifier_guard', False)):

            def _safe_add_notifier(self, notifier, *args, **kwargs):
                try:
                    return orig_add_notifier(self, notifier, *args, **kwargs)
                except AttributeError:
                    try:
                        if not hasattr(notifier, '__func__'):
                            notifier.__func__ = notifier
                        if not hasattr(notifier, '__self__'):
                            notifier.__self__ = None
                    except Exception:
                        pass
                    return orig_add_notifier(self, notifier, *args, **kwargs)
            _safe_add_notifier._us_notifier_guard = True
            _safe_add_notifier.__name__ = us_env.native_str('addNotifier')
            ConfigElement.addNotifier = _safe_add_notifier
            done.append('ConfigElement.addNotifier')
    except Exception:
        pass
    _STATE['dreamos'] = done
    return done
_NAME_RE = re.compile('<(?:widget|ePixmap|eLabel)\\b[^>]*?\\bname="([^"]+)"')
_PLACEHOLDER = '<widget name="%s" position="0,0" size="1,1" zPosition="-10" transparent="1" />'

def complete_skin(screen):
    """Add invisible placeholders for widgets the screen's skin does not place."""
    try:
        from Components.GUIComponent import GUIComponent
    except Exception:
        return 0
    skin = getattr(screen, 'skin', None)
    if not skin or '</screen>' not in skin:
        return 0
    placed = set(_NAME_RE.findall(skin))
    placed_ids = set((id(screen[k]) for k in placed if k in screen))
    missing = []
    for key in list(screen.keys()):
        value = screen[key]
        if isinstance(value, GUIComponent) and key not in placed and (id(value) not in placed_ids):
            missing.append(key)
            placed_ids.add(id(value))
    if not missing:
        return 0
    extra = '\n'.join((_PLACEHOLDER % key for key in sorted(missing)))
    cut = skin.rfind('</screen>')
    screen.skin = skin[:cut] + extra + '\n' + skin[cut:]
    return len(missing)

def complete_skin_after_init(cls):
    """Wrap cls.__init__ so the skin is completed when the outermost
    constructor of the screen has finished adding its widgets."""
    original = cls.__dict__.get('__init__')
    if original is None or getattr(original, '_us_complete_skin', False):
        return cls

    def __init__(self, *args, **kwargs):
        depth = getattr(self, '_us_init_depth', 0)
        self._us_init_depth = depth + 1
        try:
            original(self, *args, **kwargs)
        finally:
            self._us_init_depth = depth
        if depth == 0:
            try:
                complete_skin(self)
            except Exception:
                pass
    __init__._us_complete_skin = True
    __init__.__name__ = us_env.native_str('__init__')
    __init__.__doc__ = getattr(original, '__doc__', None)
    cls.__init__ = __init__
    return cls

def complete_skins_for(base):
    """Apply complete_skin_after_init to base and every subclass of it."""
    seen = set()
    stack = [base]
    while stack:
        cls = stack.pop()
        if cls in seen:
            continue
        seen.add(cls)
        complete_skin_after_init(cls)
        try:
            stack.extend(cls.__subclasses__())
        except Exception:
            pass
    return len(seen)

def complete_plugin_screen_skins():
    """Wrap every Screen class defined by this plugin (idempotent)."""
    try:
        from Screens.Screen import Screen as _E2Screen
    except Exception:
        return 0
    prefix = __name__.rsplit('.', 1)[0] + '.'
    seen = set()
    count = 0
    stack = list(_E2Screen.__subclasses__())
    while stack:
        cls = stack.pop()
        if cls in seen:
            continue
        seen.add(cls)
        if str(getattr(cls, '__module__', '')).startswith(prefix):
            complete_skin_after_init(cls)
            count += 1
        try:
            stack.extend(cls.__subclasses__())
        except Exception:
            pass
    return count

def install_session_guards():
    try:
        guard_empty_pixmaps()
    except Exception:
        pass
    try:
        guard_dreamos_enigma()
    except Exception:
        pass
    try:
        guard_openwebif_grab()
    except Exception:
        pass
    return dict(_STATE)
