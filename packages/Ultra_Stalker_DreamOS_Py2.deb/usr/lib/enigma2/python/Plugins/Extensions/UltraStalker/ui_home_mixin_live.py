# -*- coding: utf-8 -*-
"""Live category context and opening a recent item.

Methods moved verbatim out of ``PortalHomeScreen`` (ui_screens_home.py); behaviour is unchanged.
This module is imported by ui_screens_home.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, max, min, us_casefold
from .ui_screens_home import (
    ContentDetailsScreen,
    UltraStalkerPlayer,
    _,
    _client_from_profile,
    _configured_playback_engine,
    _player_payload,
    _plugin_original_service_string,
    add_recently_played,
    load_settings,
    optional_failure,
    time,
)


class HomeLiveMixin(object):
    """Live category context and opening a recent item."""

    @staticmethod
    def _home_live_category_id(item):
        item=item if isinstance(item,dict) else {}
        for key in ("_live_category_id","tv_genre_id","genre_id","category_id","genre"):
            value=item.get(key)
            if value not in (None,""):
                return str(value)
        return ""

    @staticmethod
    def _home_live_same_channel(left,right):
        left=left if isinstance(left,dict) else {};right=right if isinstance(right,dict) else {}
        for key in ("id","ch_id","stream_id"):
            a=left.get(key);b=right.get(key)
            if a not in (None,"") and b not in (None,"") and str(a)==str(b):
                return True
        def command(row):
            value=str(row.get("cmd") or row.get("command") or row.get("url") or "").strip().strip('"').strip("'")
            low=value.lower()
            for prefix in ("ffmpeg ","auto "):
                if low.startswith(prefix):
                    value=value[len(prefix):].strip();low=value.lower()
            return value
        a=command(left);b=command(right)
        if a and b and a==b:return True
        an=us_casefold(str(left.get("name") or left.get("title") or "").strip())
        bn=us_casefold(str(right.get("name") or right.get("title") or "").strip())
        return bool(an and bn and an==bn)

    @staticmethod
    def _home_live_category_row_id(row):
        row=row if isinstance(row,dict) else {}
        for key in ("id","genre_id","category_id","genre"):
            value=row.get(key)
            if value not in (None,""):return str(value)
        return ""

    @staticmethod
    def _home_live_category_row_title(row):
        row=row if isinstance(row,dict) else {}
        return str(row.get("title") or row.get("name") or row.get("genre_name") or row.get("category_name") or "").strip()

    def _home_live_context(self,item,client=None):
        """Resolve the saved Home Live card back to its real provider folder.

        The player drawer needs the same folder snapshot/page metadata that the
        normal Live grid supplies.  History stores only the played row, so rebuild
        that context from the provider catalogue in the background.  No playback
        or OK/BACK behavior is changed here; this only restores the missing data.
        """
        target=dict(item or {})
        # A recent entry may belong to another saved portal: always scan the
        # client that will actually play it, never the Home screen's own portal.
        client=client if client is not None else self.client
        category_id=self._home_live_category_id(target)
        category_title=str(target.get("_live_folder_title") or target.get("tv_genre_name") or target.get("genre_name") or target.get("category_name") or "").strip()
        # Categories are intentionally lazy for normal Home reopen.  The Player
        # drawer already knows how to request them only when BACK is pressed, so
        # reopening a channel must not wait on an unrelated category request.
        categories=[]

        # Older history entries predate the saved folder marker.  A native Live
        # search is the cheap compatibility bridge and usually returns tv_genre_id.
        if not category_id:
            query=str(target.get("name") or target.get("title") or "").strip()
            if query:
                try:
                    matches=client.search_content_fast(query,media_types=("itv",),limit=24,max_pages=8,time_budget=4) or []
                except Exception:matches=[]
                for row in matches:
                    if self._home_live_same_channel(row,target):
                        category_id=self._home_live_category_id(row)
                        if category_id:
                            target.update(row);break

        def scan_folder(cid,deadline):
            page=1
            while page<=80 and time.monotonic()<deadline:
                try:payload=client.ordered_page("itv",cid,page) or {}
                except Exception:break
                rows=[dict(x) for x in (payload.get("items") or []) if isinstance(x,dict)]
                try:page_size=max(1,int(payload.get("page_size") or len(rows) or 1))
                except Exception:page_size=max(1,len(rows) or 1)
                try:total=max(len(rows),int(payload.get("total") or len(rows)))
                except Exception:total=len(rows)
                for idx,row in enumerate(rows):
                    if self._home_live_same_channel(row,target):
                        return {
                            "channels":rows,"absolute_index":(page-1)*page_size+idx,
                            "total":total,"page_size":page_size,"page":page,
                        }
                if not rows:break
                if total and page*page_size>=total:break
                if not total and len(rows)<page_size:break
                page+=1
            return None

        context=None
        if category_id:
            context=scan_folder(category_id,time.monotonic()+5.0)

        # Last compatibility bridge for very old rows whose provider search does
        # not expose a category marker.  Keep it bounded so Home never becomes a
        # portal-wide crawler merely to reopen one recent channel.
        if context is None and not category_id:
            try:categories=list(dict(x) for x in (client.genres("itv") or []) if isinstance(x,dict))
            except Exception:categories=[]
            deadline=time.monotonic()+5.0
            for cat in categories[:32]:
                if time.monotonic()>=deadline:break
                cid=self._home_live_category_row_id(cat)
                if not cid:continue
                found=scan_folder(cid,deadline)
                if found is not None:
                    category_id=cid;category_title=self._home_live_category_row_title(cat);context=found;break

        if context is None:
            context={"channels":[target],"absolute_index":0,"total":1,"page_size":1,"page":1}
        context["category_id"]=str(category_id or "")
        context["category_title"]=category_title or _("Live TV")
        context["categories"]=categories
        return context

    def _home_live_page_loader(self,category_id,client=None,page_size=1):
        client=client if client is not None else self.client;cid=str(category_id or "")
        if not cid:return None
        def loader(page):
            from .services.recent_context import live_folder_page
            return live_folder_page(client,cid,max(1,int(page or 1)),page_size)["items"]
        return loader

    def _open_recent(self,slot):
        if getattr(self,"_busy",False) or getattr(self,"_screen_closed",False):return
        packed=self._recent_entries[slot] if 0<=slot<len(self._recent_entries) else None
        if not packed:self["status"].setText(_("Nothing has been played in this section yet"));return
        entry,item,mtype=packed
        item=dict(item)
        source_profile=self._recent_source_profile(entry)
        if not isinstance(source_profile,dict):
            self["status"].setText(_("No stream command"));return
        source_owned=self._recent_profile_key(source_profile)!=self._recent_profile_key(self.profile)
        source_client=self.client
        if source_owned:
            try:
                source_client=_client_from_profile(source_profile,timeout=min(8,int(load_settings().get("timeout",10) or 10)))
            except Exception as exc:
                optional_failure("ui.home_recent_source_client",exc)
                self["status"].setText(_("No stream command"));return
        if source_owned:
            if not hasattr(self,"_recent_pending_clients"):self._recent_pending_clients=set()
            self._recent_pending_clients.add(source_client)
        def close_source_client():
            if source_owned and source_client is not None:
                self._recent_pending_clients.discard(source_client)
                try:source_client.close()
                except Exception:pass
        if mtype=="series":
            def series_closed(result=None):
                close_source_client();self._home_shown()
            try:
                self.session.openWithCallback(series_closed,ContentDetailsScreen,source_profile,source_client,"series",item)
                if source_owned:self._recent_pending_clients.discard(source_client)
            except Exception:
                close_source_client();raise
            return
        command=item.get("cmd") or item.get("command") or item.get("url")
        if not command:
            close_source_client();self["status"].setText(_("Saved item has no stream command"));return
        is_live=mtype in ("itv","live")
        self["status"].setText(_("Opening %s...")%(_("channel") if is_live else _("saved item")))
        episode_id=item.get("id") or item.get("episode_id") or item.get("series") or item.get("number")
        return_service_ref=_plugin_original_service_string()
        def work(handle):
            started=time.monotonic()
            if mtype=="episode":url=source_client.create_link(item,"series",episode_id,cancel_event=handle.cancel_event)
            else:url=source_client.create_link(item,"itv" if is_live else "vod",cancel_event=handle.cancel_event)
            link_ms=int((time.monotonic()-started)*1000)
            if handle.cancel_event.is_set():
                close_source_client();return {}
            # Local snapshots only. Slow HDD reads never block Enigma's GUI.
            payload_started=time.monotonic()
            payload=_player_payload(item,source_profile,None,"itv" if is_live else mtype,return_service_ref=return_service_ref)
            if handle.cancel_event.is_set():
                close_source_client();return {}
            return {"url":url,"payload":payload,"link_ms":link_ms,
                    "payload_ms":int((time.monotonic()-payload_started)*1000)}
        def _ok_impl(result):
            result=result if isinstance(result,dict) else {"url":result,"live_context":None}
            url=result.get("url") if isinstance(result.get("url"),str) else ""
            # Reuse saved folder/page markers immediately. The Player loads
            # missing rows lazily when the viewer actually opens its drawer.
            live_context=None
            if is_live:
                live_context={"channels":[item],"category_id":self._home_live_category_id(item),
                              "category_title":item.get("_live_folder_title") or _("Live TV"),
                              "absolute_index":int(item.get("_live_absolute_index") or 0),
                              "page":int(item.get("_live_folder_page") or 1),
                              "page_size":int(item.get("_live_page_size") or 1),
                              "total":int(item.get("_live_folder_total") or int(item.get("_live_absolute_index") or 0)+1)}
            if not str(url or "").strip():
                close_source_client();self["status"].setText(_("No stream command"));return
            name=str(item.get("name") or item.get("title") or item.get("episode_name") or _("Your saved content"))
            mt="itv" if is_live else mtype
            play_item=dict(item)
            if mt=="itv" and live_context:
                play_item["_live_category_id"]=str(live_context.get("category_id") or "")
                play_item["_live_folder_title"]=str(live_context.get("category_title") or _("Live TV"))
                play_item["_live_absolute_index"]=int(live_context.get("absolute_index") or 0)
                play_item["_live_folder_page"]=int(live_context.get("page") or 1)
                play_item["_live_page_size"]=int(live_context.get("page_size") or 1)
                play_item["_live_folder_total"]=int(live_context.get("total") or int(play_item["_live_absolute_index"])+1)
                add_recently_played(source_profile,"itv",play_item)
            engine=_configured_playback_engine()
            payload=dict(result.get("payload") or {})
            for key in ("_live_category_id","_live_folder_title","_live_absolute_index","_live_folder_page","_live_page_size","_live_folder_total"):
                if key in play_item:payload[key]=play_item[key]
            payload["_launch_timing"]={"link_ms":result.get("link_ms",0),"payload_ms":result.get("payload_ms",0)}
            payload["_player_client_ref"]=source_client
            if mt=="itv":payload["_live_client_ref"]=source_client
            if mt=="itv" and live_context:
                channels=list(dict(x) for x in (live_context.get("channels") or []) if isinstance(x,dict))
                relative=int(live_context.get("absolute_index") or 0)%max(1,int(live_context.get("page_size") or 1))
                payload["_live_folder_channels"]=[None]*relative+channels
                payload["_live_absolute_index"]=int(live_context.get("absolute_index") or 0)
                payload["_live_folder_total"]=int(live_context.get("total") or len(channels))
                payload["_live_page_size"]=max(1,int(live_context.get("page_size") or len(channels) or 1))
                payload["_live_folder_page"]=max(1,int(live_context.get("page") or 1))
                payload["_live_folder_title"]=str(live_context.get("category_title") or _("Live TV"))
                payload["_live_category_id"]=str(live_context.get("category_id") or "")
                payload["_live_categories"]=list(dict(x) for x in (live_context.get("categories") or []) if isinstance(x,dict))
                payload["_live_page_loader"]=self._home_live_page_loader(live_context.get("category_id"),source_client,payload["_live_page_size"])
                payload["_live_client_ref"]=source_client
            if mt=="episode":
                def next_loader(cancel_event):
                    from .services.recent_context import next_episode
                    return next_episode(source_client,item,cancel_event)
                payload["_next_episode_loader"]=next_loader
            elif mt=="itv":
                def context_loader(cancel_event):
                    from .services.recent_context import live_context
                    context_item=dict(item)
                    context_item["_live_category_id"]=payload["_live_category_id"]
                    return live_context(source_client,context_item,cancel_event)
                payload["_recent_live_context_loader"]=context_loader
            def closed(result=None):
                following=result.get("next_episode") if isinstance(result,dict) else None
                if isinstance(following,dict) and following:
                    # Release this launch's owned client and resolve the next
                    # episode through the same source profile.
                    self._recent_entries[slot]=(entry,dict(following),"episode")
                    close_source_client()
                    self._open_recent(slot)
                    return
                close_source_client()
                try:self._schedule_home_recent_refresh(150)
                except Exception:pass
            self.session.openWithCallback(closed,UltraStalkerPlayer,url.strip(),name,mt,engine,payload)
            if source_owned:self._recent_pending_clients.discard(source_client)
        def ok(result):
            # A failure while building the player payload must still release a
            # source-owned client and tell the viewer, never leave Home silent.
            try:_ok_impl(result)
            except Exception as exc:
                optional_failure("ui.home_recent_open",exc)
                close_source_client()
                try:self["status"].setText(_("Player failed: %s")%str(exc)[:80])
                except Exception:pass
        def fail(error):
            close_source_client();self["status"].setText(_("No stream command"))
        handle=self._run_async(work,ok,fail)
        if not handle:close_source_client()
        elif source_owned:
            # Registered after submit too: a fast worker may already have
            # completed, but a queued UI result still owns this resource.
            add_cancel=getattr(handle,"add_cancel_callback",None)
            if callable(add_cancel):add_cancel(close_source_client)
