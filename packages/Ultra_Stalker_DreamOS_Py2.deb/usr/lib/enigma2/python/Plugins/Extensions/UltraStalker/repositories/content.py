# -*- coding: utf-8 -*-
from __future__ import absolute_import, division, print_function, unicode_literals
from .. import us_env as _us_env
from ..us_env import str, int
__metaclass__ = type  # new-style classes on Python 2
hashlib = _us_env.hashlib; json = _us_env.json; time = _us_env.time
from .database import DB
from ..identity import stable_content_identity

def content_key(profile,media_type,item,legacy_episode=False):
    item=item if isinstance(item,dict) else {}
    portal=str((profile or {}).get('portal') or '').rstrip('/').lower()
    mac=str((profile or {}).get('mac') or '').upper()
    mtype=str(media_type or '').lower()
    identity=stable_content_identity(mtype,item,legacy_episode=legacy_episode)
    raw=json.dumps([portal,mac,mtype,identity],ensure_ascii=False,sort_keys=True,separators=(',',':'))
    return hashlib.sha256(raw.encode('utf-8')).hexdigest()

def _episode_signature(item):
    item=item if isinstance(item,dict) else {}
    episode_id=item.get('episode_id')
    series_ref=item.get('series_id') or item.get('_series_id') or item.get('series') or item.get('movie_id') or item.get('series_uid') or item.get('parent_id')
    season=item.get('season') or item.get('season_id') or item.get('season_number')
    episode=item.get('episode') or item.get('number') or item.get('episode_num') or item.get('episode_number')
    if episode_id not in (None,''):
        return ('episode_id',str(episode_id),str(series_ref or ''),str(season or ''),str(episode or ''))
    if series_ref not in (None,'') and (season not in (None,'') or episode not in (None,'')):
        return ('series_tuple',str(series_ref),str(season or ''),str(episode or ''))
    return None

_LEGACY_STATES_CACHE={'k':None,'t':0.0,'v':{}}

def _legacy_episode_states(profile, limit=5000):
    """Index old history payloads by structural episode identity.

    Us110 included the mutable episode title in its hash. If a portal changes
    translation at the same time as the upgrade, no hash-only fallback can find
    that bookmark. The stored SQLite payload still contains series/season/episode
    fields, so use them once as a migration bridge.
    """
    wanted_portal=str((profile or {}).get('portal') or '').rstrip('/').lower()
    wanted_mac=str((profile or {}).get('mac') or '').upper()
    # Playing an episode with no saved progress asks for this index every time;
    # parsing up to 5000 history payloads on each Play is wasted work, so the
    # index is kept for a short while per portal/MAC.
    cache=_LEGACY_STATES_CACHE
    now=time.monotonic()
    if cache['k']==(wanted_portal,wanted_mac,limit) and now-cache['t']<30.0:
        return cache['v']
    out={}
    try:rows=DB.list_history(limit=limit)
    except Exception:return out
    for payload in rows:
        if not isinstance(payload,dict) or str(payload.get('media_type') or '').lower()!='episode':continue
        if str(payload.get('portal') or '').rstrip('/').lower()!=wanted_portal:continue
        if str(payload.get('mac') or '').upper()!=wanted_mac:continue
        sig=_episode_signature(payload.get('item') or {})
        if not sig or sig in out:continue
        out[sig]={'position':int(payload.get('_position') or 0),'duration':int(payload.get('_duration') or 0),'completed':bool(payload.get('_completed')),'content_key':payload.get('_content_key')}
    cache['k']=(wanted_portal,wanted_mac,limit);cache['t']=now;cache['v']=out
    return out

_SERIES_RESUME_CACHE={'k':None,'t':0.0,'v':{}}
_SERIES_REF_FIELDS=('series_id','_series_id','series','movie_id','series_uid','parent_id')

def _series_resume_map(profile):
    """Latest unfinished episode per series (position/duration/season/episode).

    One bounded history read, cached for a few seconds, so a whole grid page of
    series cards costs a single query.  Only used to draw a progress bar.
    """
    portal=str((profile or {}).get('portal') or '').rstrip('/').lower()
    mac=str((profile or {}).get('mac') or '').upper()
    cache=_SERIES_RESUME_CACHE
    now=time.monotonic()
    if cache['k']==(portal,mac) and now-cache['t']<3.0:
        return cache['v']
    out={}
    try:rows=DB.list_history(limit=1200)
    except Exception:rows=[]
    seen=set()
    for entry in rows:
        try:
            if str(entry.get('media_type') or '').lower()!='episode':continue
            if str(entry.get('portal') or '').rstrip('/').lower()!=portal or str(entry.get('mac') or '').upper()!=mac:continue
            item=entry.get('item') if isinstance(entry.get('item'),dict) else {}
            refs=[str(item.get(f)) for f in _SERIES_REF_FIELDS if item.get(f) not in (None,'')]
            if not refs or refs[0] in seen:continue
            seen.add(refs[0])
            if entry.get('_completed'):continue
            pos=int(entry.get('_position') or 0);dur=int(entry.get('_duration') or 0)
            if pos<=0 or dur<=0:continue
            info={'position':pos,'duration':dur,'season':item.get('season') or item.get('_season_number') or item.get('season_number') or '','episode':item.get('episode_num') or item.get('episode') or item.get('number') or item.get('episode_number') or ''}
            for ref in refs:out.setdefault(ref,info)
        except Exception:continue
    cache['k']=(portal,mac);cache['t']=now;cache['v']=out
    return out

def _apply_series_resume(profile,items,out):
    resume=_series_resume_map(profile)
    if not resume:return
    for idx,item in enumerate(items):
        value=out[idx]
        if value.get('position') or value.get('completed') or not isinstance(item,dict):continue
        for field in ('series_id','id','series_uid','movie_id'):
            ref=item.get(field)
            info=resume.get(str(ref)) if ref not in (None,'') else None
            if info:
                value['position']=info['position'];value['duration']=info['duration']
                value['resume_season']=info.get('season');value['resume_episode']=info.get('episode')
                break

_FAV_REV=[0]
def favorites_revision():
    return _FAV_REV[0]

class FavoritesRepository:
    _cache={}
    def list(self,limit=500):
        # R5.199: favorites are read from SQLite once per revision; every later
        # call (tab moves, counts, previews) is served from memory. All writers
        # go through this class and bump _FAV_REV, which invalidates the cache.
        key=(_FAV_REV[0],int(limit or 0))
        hit=self._cache.get('v')
        if hit and hit[0]==key:return list(hit[1])
        rev=_FAV_REV[0]
        rows=DB.list_payloads('favorites',limit)
        if rev==_FAV_REV[0]:self._cache['v']=(key,rows)
        return list(rows)
    def toggle(self,profile,media_type,item):
        payload={'portal':profile.get('portal',''),'mac':profile.get('mac',''),'media_type':str(media_type or ''),'item':item}
        _FAV_REV[0]+=1
        try:return DB.toggle_favorite(content_key(profile,media_type,item),payload['portal'],payload['media_type'],payload)
        finally:_FAV_REV[0]+=1
    def contains(self,profile,media_type,item): return DB.is_favorite(content_key(profile,media_type,item))
    def remove_saved_entry(self,entry):
        _FAV_REV[0]+=1
        try:return DB.remove_favorite_payload(entry)
        finally:_FAV_REV[0]+=1
    def reorder(self,profile,media_type,items):
        keys=[content_key(profile,media_type,item) for item in list(items or []) if isinstance(item,dict)]
        _FAV_REV[0]+=1
        try:DB.reorder_favorites(keys)
        finally:_FAV_REV[0]+=1
    def states(self,profile,media_type,items):
        items=list(items or [])
        keys=list(content_key(profile,media_type,item) for item in items)
        legacy_sets=[]
        if str(media_type or '').lower()=='episode':
            legacy_sets=[list(content_key(profile,media_type,item,legacy_episode=variant) for item in items) for variant in ('us110',True)]
        all_keys=list(keys)
        for group in legacy_sets:all_keys.extend(group)
        states=DB.content_states(all_keys)
        structural=_legacy_episode_states(profile) if legacy_sets else {}
        out=[]
        for idx,key in enumerate(keys):
            value=dict(states.get(key,{'favorite':False,'position':0,'duration':0,'completed':0}))
            for group in legacy_sets:
                old=states.get(group[idx],{})
                if not value.get('favorite') and old.get('favorite'):value['favorite']=True
                if not value.get('position') and old.get('position'):
                    value['position']=old.get('position',0);value['duration']=old.get('duration',0);value['completed']=old.get('completed',0)
            if legacy_sets and not (value.get('position') or value.get('completed')):
                old=structural.get(_episode_signature(items[idx]),{})
                if old:
                    value['position']=old.get('position',0);value['duration']=old.get('duration',0);value['completed']=old.get('completed',0)
            out.append(value)
        if str(media_type or '').lower()=='series':
            try:_apply_series_resume(profile,items,out)
            except Exception:pass
        return out

class FavoriteFoldersRepository:
    def _scope(self,profile,media_type):
        profile=profile or {}
        return profile.get('portal',''),profile.get('mac',''),str(media_type or '').lower()
    def list(self,profile,media_type='itv'):
        portal,mac,mt=self._scope(profile,media_type)
        return DB.list_favorite_folders(portal,mac,mt)
    def create(self,profile,media_type,name):
        portal,mac,mt=self._scope(profile,media_type)
        return DB.create_favorite_folder(portal,mac,mt,name)
    def rename(self,profile,media_type,folder_id,name):
        portal,mac,mt=self._scope(profile,media_type)
        return DB.rename_favorite_folder(folder_id,portal,mac,mt,name)
    def delete(self,profile,media_type,folder_id):
        portal,mac,mt=self._scope(profile,media_type)
        return DB.delete_favorite_folder(folder_id,portal,mac,mt)
    def assign(self,profile,media_type,item,folder_id):
        portal,mac,mt=self._scope(profile,media_type)
        return DB.favorite_folder_assign(folder_id,portal,mac,mt,content_key(profile,mt,item))
    def remove_item(self,profile,media_type,item):
        portal,mac,mt=self._scope(profile,media_type)
        return DB.favorite_folder_remove_key(portal,mac,mt,content_key(profile,mt,item))
    def membership(self,profile,media_type):
        portal,mac,mt=self._scope(profile,media_type)
        return DB.favorite_folder_membership(portal,mac,mt)
    def keys(self,folder_id):
        return DB.favorite_folder_keys(folder_id)
    def reorder(self,profile,media_type,folder_id,items):
        mt=str(media_type or '').lower()
        keys=[content_key(profile,mt,item) for item in list(items or []) if isinstance(item,dict)]
        DB.reorder_favorite_folder(folder_id,keys)

class HistoryRepository:
    def list(self,limit=500): return DB.list_history(limit=limit)
    def continue_list(self,limit=500): return DB.list_history(limit=limit,continue_only=True)
    def incomplete_list(self,limit=500): return DB.list_history(limit=limit,include_completed=False)
    def save(self,profile,media_type,item,position=0,duration=0,completed=False,force=False):
        payload={'portal':profile.get('portal',''),'mac':profile.get('mac',''),'media_type':str(media_type or ''),'item':item}
        return DB.add_history(content_key(profile,media_type,item),payload['portal'],payload['media_type'],payload,position,duration,completed,force=force)
    def touch(self,profile,media_type,item):
        payload={'portal':profile.get('portal',''),'mac':profile.get('mac',''),'media_type':str(media_type or ''),'item':item}
        return DB.touch_history(content_key(profile,media_type,item),payload['portal'],payload['media_type'],payload)
    def progress(self,profile,media_type,item):
        key=content_key(profile,media_type,item);value=DB.progress(key)
        if str(media_type or '').lower()=='episode' and not (int(value.get('position') or 0) or int(value.get('completed') or 0)):
            for variant in ('us110',True):
                old_key=content_key(profile,media_type,item,legacy_episode=variant)
                if old_key==key:continue
                legacy=DB.progress(old_key)
                if int(legacy.get('position') or 0) or int(legacy.get('completed') or 0):
                    self.save(profile,media_type,item,legacy.get('position',0),legacy.get('duration',0),legacy.get('completed',False))
                    try:DB.remove_history(old_key)
                    except Exception:pass
                    return legacy
            # Last-resort us110 migration when the portal translated/renamed
            # the episode: compare the stored payload's structural IDs instead
            # of its obsolete title-bearing hash.
            structural=_legacy_episode_states(profile)
            legacy=structural.get(_episode_signature(item),{})
            if legacy and (int(legacy.get('position') or 0) or int(legacy.get('completed') or 0)):
                structural.pop(_episode_signature(item),None)  # migrated once; never offer it again
                self.save(profile,media_type,item,legacy.get('position',0),legacy.get('duration',0),legacy.get('completed',False))
                old_key=legacy.get('content_key')
                if old_key and old_key!=key:
                    try:DB.remove_history(old_key)
                    except Exception:pass
                return {'position':legacy.get('position',0),'duration':legacy.get('duration',0),'completed':int(bool(legacy.get('completed')))}
        return value
    def mark_watched(self,profile,media_type,item,watched=True):
        changed=self.touch(profile,media_type,item)
        DB.set_history_completed(content_key(profile,media_type,item),watched)
        return bool(changed)
    def remove(self,profile,media_type,item):
        _LEGACY_STATES_CACHE['k']=None
        return DB.remove_history(content_key(profile,media_type,item))
    def clear(self,profile=None):
        _LEGACY_STATES_CACHE['k']=None
        return DB.clear_history((profile or {}).get('portal') if profile else None,(profile or {}).get('mac') if profile else None)
FAVORITES=FavoritesRepository(); FAVORITE_FOLDERS=FavoriteFoldersRepository(); HISTORY=HistoryRepository()
