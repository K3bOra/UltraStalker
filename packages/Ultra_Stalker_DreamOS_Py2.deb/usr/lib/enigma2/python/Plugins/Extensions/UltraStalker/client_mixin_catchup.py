# -*- coding: utf-8 -*-
"""Catch-up channels, archive EPG, catch-up links and health snapshot.

Methods moved verbatim out of ``StalkerClient`` (client.py); behaviour is unchanged.
This module is imported by client.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, max, min
from .client import (
    LOG,
    PortalCancelledError,
    PortalError,
    time,
    urllib,
)


class ClientCatchupMixin(object):
    """Catch-up channels, archive EPG, catch-up links and health snapshot."""

    @staticmethod
    def _catchup_truthy(value):
        return str(value if value is not None else "").strip().lower() in ("1", "true", "yes", "y", "on")

    def catchup_channels(self, genre="*", page=1, max_pages=None, cancel_event=None):
        result = []
        # Catch-up discovery must never scan a huge portal catalogue for minutes.
        # Twenty native pages is a generous bounded discovery pass and remains
        # fully cancellable through cancel_event.
        max_pages = max(1, min(int(max_pages or 20), 20))
        rows = self.ordered_all("itv", genre, start_page=page, max_pages=max_pages, cancel_event=cancel_event)
        for row in rows:
            if not isinstance(row, dict):
                continue
            # IMPORTANT: use_http_tmp_link / allow_timeshift are playback policy,
            # not proof that the provider keeps a server-side TV archive.  Treating
            # them as archive flags made entire portals appear Catch-up capable,
            # then every channel opened to an empty programme list.
            try:
                duration = int(float(row.get("tv_archive_duration") or row.get("archive_duration") or 0))
            except Exception:
                duration = 0
            archive = bool(duration > 0 or any(self._catchup_truthy(row.get(key)) for key in (
                "allow_archive", "archive", "enable_tv_archive", "tv_archive",
                "has_archive", "catchup", "catch_up",
            )))
            if archive:
                result.append(row)
        try:
            # Diagnostics: show which archive-related fields this portal really sends.
            keys = sorted({k for r in rows[:50] if isinstance(r, dict) for k in r
                           if any(t in str(k).lower() for t in ("arch", "pvr", "shift", "tmp_link", "catch"))})
            sample = {k: rows[0].get(k) for k in keys} if rows and isinstance(rows[0], dict) else {}
            LOG.info("Catch-up scan: channels=%d archive=%d fields=%s sample=%s",
                     len(rows), len(result), keys, sample)
        except Exception:
            pass
        return result

    def _archive_epg_get(self, params, cancel_event=None):
        """Archive EPG request with one fresh-socket replay.

        Several MAG/Stalker panels close a long-lived catalogue keep-alive just
        before/while servicing get_simple_data_table.  Normal catalogue traffic
        should keep its fast persistent transport, but Catch-up gets one bounded
        replay on a fresh connection so a stale socket cannot turn every channel
        into an empty archive page.
        """
        try:
            return self._unwrap(self._get(params, use_cache=False, cancel_event=cancel_event))
        except PortalCancelledError:
            raise
        except PortalError as first_exc:
            LOG.info("Catch-up EPG fresh-socket replay after: %s", first_exc)
            try:
                self._drop_current_transport(close=True)
            except Exception:
                pass
            try:
                value = self._unwrap(self._get(
                    params, use_cache=False, extra_headers={"Connection": "close"},
                    cancel_event=cancel_event,
                ))
                # Do not leave a server-closed archive socket in the thread-local
                # keep-alive slot for the next date/page.
                try:
                    self._drop_current_transport(close=True)
                except Exception:
                    pass
                return value
            except PortalCancelledError:
                raise
            except PortalError:
                try:
                    self._drop_current_transport(close=True)
                except Exception:
                    pass
                raise

    def _archive_epg_table(self, channel_id, from_ts, now, cancel_event=None):
        """Ministra/Stalker archive EPG, using the MAG-compatible p=0 entry page first.

        A number of real Ministra/Stalker panels treat ``p=0`` specially for
        ``get_simple_data_table`` and may close the socket when clients jump
        straight to ``p=1``.  Start exactly like a MAG box, then walk bounded
        numbered pages while de-duplicating the page returned by p=0.
        """
        if not self.token:
            self.authorize(cancel_event=cancel_event)
        collected, seen = [], set()
        day = time.localtime(now)
        day_start = int(time.mktime((day.tm_year, day.tm_mon, day.tm_mday, 0, 0, 0, 0, 0, -1)))
        days = max(1, min(15, (now - int(from_ts)) // 86400 + 1))

        def add_rows(js):
            rows = [r for r in self._as_list(js) if isinstance(r, dict)]
            added = 0
            for row in rows:
                key = str(row.get("id") or "") + "|" + str(row.get("start_timestamp") or row.get("time") or "")
                if key in seen:
                    continue
                seen.add(key)
                collected.append(row)
                added += 1
            return rows, added

        for offset in range(days):
            if cancel_event is not None and getattr(cancel_event, "is_set", lambda: False)():
                break
            date = time.strftime("%Y-%m-%d", time.localtime(day_start - offset * 86400 + 43200))

            # MAG/Stalker reference clients open a date with p=0.  Keep the
            # request uncached because archive data is time-sensitive.
            first_js = None
            try:
                first_js = self._archive_epg_get({
                    "type": "epg", "action": "get_simple_data_table", "ch_id": channel_id,
                    "date": date, "p": 0, "JsHttpRequest": "1-xml",
                }, cancel_event=cancel_event)
            except PortalError as exc:
                LOG.info("Catch-up EPG p=0 unavailable (%s): %s", date, exc)
                # Compatibility fallback for panels that do not implement the
                # special p=0 page.  One bounded p=1 probe is enough here.
                try:
                    first_js = self._archive_epg_get({
                        "type": "epg", "action": "get_simple_data_table", "ch_id": channel_id,
                        "date": date, "p": 1, "JsHttpRequest": "1-xml",
                    }, cancel_event=cancel_event)
                except PortalError as fallback_exc:
                    LOG.info("Catch-up EPG table unavailable (%s): %s", date, fallback_exc)
                    # Do not throw away archive rows already collected from
                    # newer dates just because one older day is unavailable.
                    continue

            first_rows, _first_added = add_rows(first_js)
            meta = first_js if isinstance(first_js, dict) else {}
            total = max(0, self._int_value(meta.get("total_items") or meta.get("total"), 0))
            size = max(1, self._int_value(meta.get("max_page_items") or meta.get("page_size"), len(first_rows) or 10))
            if total:
                page_limit = min(10, max(1, (total + size - 1) // size))
            else:
                page_limit = 10

            # Numbered pages can repeat the p=0 payload.  De-duplication is
            # intentional, and a duplicate page is not used as an early-stop
            # signal because p=0 may have represented any current/anchor page.
            for page in range(1, page_limit + 1):
                if cancel_event is not None and getattr(cancel_event, "is_set", lambda: False)():
                    break
                try:
                    js = self._archive_epg_get({
                        "type": "epg", "action": "get_simple_data_table", "ch_id": channel_id,
                        "date": date, "p": page, "JsHttpRequest": "1-xml",
                    }, cancel_event=cancel_event)
                except PortalError as exc:
                    LOG.info("Catch-up EPG page unavailable (%s p=%s): %s", date, page, exc)
                    break
                rows, _added = add_rows(js)
                page_meta = js if isinstance(js, dict) else {}
                page_total = max(0, self._int_value(page_meta.get("total_items") or page_meta.get("total"), total))
                page_size = max(1, self._int_value(page_meta.get("max_page_items") or page_meta.get("page_size"), len(rows) or size))
                if not rows:
                    break
                if page_total and page * page_size >= page_total:
                    break
                if not page_total and len(rows) < page_size:
                    break
        return collected

    def catchup_programs(self, channel_id, hours=72, cancel_event=None):
        now = int(time.time())
        floor = now - max(1, int(hours)) * 3600
        rows = []
        try:
            rows = self._archive_epg_table(channel_id, floor, now, cancel_event=cancel_event)
        except Exception as exc:
            LOG.info("Catch-up archive table failed: %s", exc)
        source = "table"
        if not rows:
            source = "fallback"
            try:
                rows = self.full_epg(channel_id, floor, now, max_pages=120, cancel_event=cancel_event)
            except Exception as exc:
                # A provider may advertise archive on the channel while refusing
                # its EPG endpoint (or simply reset the EPG socket).  Catch-up
                # browsing must degrade to an empty list, never surface a raw
                # transport exception in the UI or kick the user out of the page.
                LOG.info("Catch-up fallback EPG unavailable: %s", exc)
                rows = []
        mark_field_present = any("mark_archive" in r for r in rows if isinstance(r, dict))
        marked_archive = any(
            self._catchup_truthy(r.get("mark_archive"))
            for r in rows if isinstance(r, dict) and "mark_archive" in r
        )
        # Some clone panels return mark_archive=0 on every EPG row even though
        # the channel itself advertises a valid archive.  Filtering merely
        # because the field exists turns a perfectly populated EPG into an empty
        # screen.  Only trust the marker when the payload proves it can be true.
        if mark_field_present and not marked_archive:
            LOG.info("Catch-up EPG mark_archive present but never true; keeping past EPG rows as candidates")
        out = []
        for row in rows:
            if not isinstance(row, dict):
                continue
            start = self._int_value(row.get("start_timestamp") or row.get("start") or 0, 0)
            if not start:
                raw_time = str(row.get("time") or row.get("start") or "").strip()[:19]
                for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M"):
                    try:
                        start = int(time.mktime(time.strptime(raw_time, fmt)))
                        break
                    except Exception:
                        pass
                if start:
                    row = dict(row)
                    row["start_timestamp"] = start
            if start and (start >= now or start < floor):
                continue
            if marked_archive and not self._catchup_truthy(row.get("mark_archive")):
                continue
            out.append(row)
        out.sort(key=lambda r: -self._int_value(r.get("start_timestamp") or 0, 0))
        LOG.info("Catch-up programmes: channel=%s source=%s rows=%d usable=%d mark_field=%s marked_archive=%s",
                 channel_id, source, len(rows), len(out), mark_field_present, marked_archive)
        return out

    def create_catchup_link(self, channel, program, cancel_event=None):
        channel = channel if isinstance(channel, dict) else {}
        program = program if isinstance(program, dict) else {}
        command = self._extract_command(channel)
        if not command:
            raise PortalError("Catch-up channel has no stream command")
        try:
            start = int(program.get("start_timestamp") or program.get("start") or program.get("time") or 0)
        except Exception:
            start = 0
        try:
            duration = int(program.get("duration") or program.get("length") or 0)
        except Exception:
            duration = 0
        if duration > 24 * 3600 and start:
            duration = max(1, duration - start)
        errors = []
        # Standard Ministra/Stalker archive link: type=tv_archive with the EPG item id.
        for pid in [program.get("id"), program.get("real_id")]:
            pid = str(pid or "").strip()
            if not pid:
                continue
            try:
                js = self._unwrap(self._get({
                    "type": "tv_archive", "action": "create_link", "cmd": "auto /media/%s.mpg" % pid,
                    "series": "", "forced_storage": "", "disable_ad": "0", "download": "0",
                    "JsHttpRequest": "1-xml",
                }, cancel_event=cancel_event))
                value = js.get("cmd") or js.get("url") or js.get("link") if isinstance(js, dict) else js
                clean = self._strip_player_wrapper(value)
                if clean and urllib.parse.urlsplit(clean).scheme.lower() in self._PLAYABLE_SCHEMES:
                    LOG.info("Catch-up link via tv_archive (id=%s)", pid)
                    return clean
            except PortalError as exc:
                errors.append(str(exc))
        for action in ("create_link", "create_archive_link"):
            params = {
                "type": "itv", "action": action, "cmd": command, "JsHttpRequest": "1-xml"
            }
            if start:
                params.update({"utc": start, "start": start})
            if duration:
                params["duration"] = duration
            try:
                js = self._unwrap(self._get(params, cancel_event=cancel_event))
                value = js.get("cmd") or js.get("url") or js.get("link") if isinstance(js, dict) else js
                clean = self._strip_player_wrapper(value)
                if urllib.parse.urlsplit(clean).scheme.lower() in self._PLAYABLE_SCHEMES:
                    return clean
            except PortalError as exc:
                errors.append(str(exc))
        raise PortalError(errors[-1] if errors else "Portal did not return a catch-up link")

    def health_snapshot(self):
        samples = self._latency_state.get(self._portal_key(), [])
        avg = int(sum(samples) / float(len(samples))) if samples else 0
        state = self._circuit_state.get(self._portal_key()) or {}
        failures = int(state.get("failures", 0) or 0)
        if failures >= self.CIRCUIT_FAILURE_LIMIT:
            health = "offline"
        elif avg and avg < 700:
            health = "excellent"
        elif avg and avg < 1500:
            health = "online"
        elif avg:
            health = "slow"
        else:
            health = "unknown"
        return {"health": health, "latency_ms": avg, "failures": failures,
                "tls_mode": self.tls_mode, "unverified_tls": bool(self.used_unverified_tls),
                "http_fallback": bool(self.used_http_fallback),
                "device_profile": self.resolved_device_profile or self.device_profile,
                "security_warning": self.security_warning}
