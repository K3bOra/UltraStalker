# -*- coding: utf-8 -*-
"""Visual material rebind, fast return, shown/hidden handling.

Methods moved verbatim out of ``PortalHomeScreen`` (ui_screens_home.py); behaviour is unchanged.
This module is imported by ui_screens_home.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, max
from .ui_screens_home import (
    LOG,
    _mem34,
    eTimer,
    history_revision,
    load_settings,
    optional_failure,
    os,
    time,
)


class HomeRebindMixin(object):
    """Visual material rebind, fast return, shown/hidden handling."""

    def _stop_home_rebind_timer(self):
        try:self._home_rebind_timer.stop()
        except Exception as exc:optional_failure("ui.home_rebind_timer_stop",exc)
        try:
            if self._home_rebind_conn is not None:self._home_rebind_conn.disconnect()
        except Exception as exc:optional_failure("ui.home_rebind_timer_disconnect",exc)
        try:
            if self._home_delayed_rebind in self._home_rebind_timer.callback:self._home_rebind_timer.callback.remove(self._home_delayed_rebind)
        except Exception as exc:optional_failure("ui.home_rebind_timer_callback",exc)

    def _home_hero_source(self,hero):
        if not isinstance(hero,dict):return None
        for key in ("prepared","display_backdrop_local","backdrop_local","display_poster_local","poster_local"):
            src=str(hero.get(key) or "")
            try:
                if src and os.path.isfile(src) and os.path.getsize(src)>4096:return src
            except Exception as exc:optional_failure("ui.home_source_check",exc)
        return None

    def _ensure_home_visual_materials(self,hero):
        """R171 Home fix: fixed green chrome is skin-owned, never rebuilt/rebound.

        Hero state remains artwork/content only.  The immutable Home ambient,
        menu/recent cards and focus surfaces are already bound by HOME_SKIN on
        the first frame, so touching them here would only create a black->green
        flash and unnecessary PNG work.
        """
        return hero

    def _rebind_home_materials(self,hero):
        """Compatibility hook; the fixed Home chrome is permanently skin-bound.

        Dynamic Hero artwork is handled by _apply_home_hero().  Do not reload
        ambient/menu/recent/focus PNGs here on child return or Hero refresh.
        """
        return

    def _force_home_visual_rebind(self):
        """Restore the exact pre-child Home hero, adaptive mood and 3D glass."""
        if getattr(self,"_screen_closed",False):return
        try:self._image_layout_ready()
        except Exception as exc:optional_failure("ui.home_rebind_layout",exc)

        hero=self._hero_data if isinstance(getattr(self,"_hero_data",None),dict) else None
        if not hero:
            try:hero=self._read_hero_cache()
            except Exception:hero=None
        if isinstance(hero,dict):
            hero=self._ensure_home_visual_materials(dict(hero))
            self._hero_data=hero
            try:self._apply_home_hero(hero)
            except Exception as exc:optional_failure("ui.home_rebind_apply",exc)
            try:self._rebind_home_materials(hero)
            except Exception as exc:optional_failure("ui.home_rebind_native",exc)
        else:
            try:self._load_home_hero(force=False)
            except Exception as exc:optional_failure("ui.home_rebind_fallback",exc)

        try:self._update_focus()
        except Exception as exc:optional_failure("ui.home_rebind_focus",exc)

    def _home_delayed_rebind(self):
        try:self._home_rebind_timer.stop()
        except Exception as exc:optional_failure("ui.home_rebind_timer",exc)
        if getattr(self,"_screen_closed",False):return
        try:self._home_fast_return()
        except Exception as exc:optional_failure("ui.home_delayed_pin_check",exc)
        try:self._force_home_visual_rebind()
        except Exception as exc:optional_failure("ui.home_delayed_rebind",exc)
        # While one explicit single-slot Hero is being prepared, poll only a
        # tiny /tmp marker.  No network/HDD scan/image work occurs here.
        try:
            marker=os.path.join("/tmp","ultrastalker_home_hero_pending")
            if os.path.isfile(marker):
                age=max(0.0,time.time()-os.path.getmtime(marker))
                # release could legitimately need a minute or two on receiver HDD/CPU.
                # Poll only this tiny /tmp marker; no network or image build runs here.
                if age<180.0:self._home_rebind_timer.start(1000,True)
        except Exception as exc:optional_failure("ui.home_single_pin_poll",exc)

    def _home_fast_return(self):
        """Child return: keep warm visuals, but honor a newly pinned Home Hero."""
        if getattr(self,"_screen_closed",False):return
        try:
            state=self._read_hero_state() or {}
            pinned=self._read_hero_cache()
            if pinned:
                pinned=self._ensure_home_visual_materials(dict(pinned))
                self._hero_data=pinned
                self._apply_home_hero(pinned)
                self._rebind_home_materials(pinned)
            elif not getattr(self, "_hero_data", None):
                self._apply_default_home_hero_backdrop()
        except Exception as exc:optional_failure("ui.home_fast_manual_pin",exc)
        try:self._update_focus()
        except Exception as exc:optional_failure("ui.home_fast_focus",exc)

    def _perf59_stop_return_probe(self):
        try:self._perf59_return_probe.stop()
        except Exception:pass
        try:
            if self._perf59_return_probe_conn is not None:self._perf59_return_probe_conn.disconnect()
        except Exception:pass
        try:
            if self._perf59_return_probe_fire in self._perf59_return_probe.callback:self._perf59_return_probe.callback.remove(self._perf59_return_probe_fire)
        except Exception:pass

    def _perf59_schedule_return_probe(self, action):
        self._perf59_return_action=str(action or "")
        self._perf59_return_stage=1
        try:
            self._perf59_return_probe.stop();self._perf59_return_probe.start(1500,True)
        except Exception:pass

    def _perf59_return_probe_fire(self):
        if getattr(self,"_screen_closed",False) or not getattr(self,"_home_runtime_visible",True):return
        stage=int(getattr(self,"_perf59_return_stage",0) or 0)
        if stage not in (1,2):return
        cycle=int(getattr(self,"_perf59_cycle",0) or 0);action=str(getattr(self,"_perf59_return_action","") or "")
        if LOG is not None:LOG.info("PERF59 home_return_settle cycle=%d action=%s stage=%d",cycle,action,stage)
        _mem34("home_return_settle",action=action,cycle=cycle,stage=stage)
        if stage==1:
            self._perf59_return_stage=2
            try:self._perf59_return_probe.start(4500,True)
            except Exception:pass
        else:
            self._perf59_return_stage=0

    def _home_shown(self):
        try:self._home_clock_tick()
        except Exception:pass
        return self._home_shown_body()

    def _home_shown_body(self):
        if getattr(self,"_screen_closed",False):return
        _perf59_return_t0=time.monotonic()
        try:self._home_clean_titles=bool((load_settings() or {}).get("clean_titles",True))
        except Exception:pass
        self._resume_home_runtime_timers()
        self._home_images_suspended=False
        returning=bool(getattr(self,"_home_return_pending",False) and getattr(self,"_home_has_shown_once",False))
        self._home_return_pending=False
        if not returning and not getattr(self,"_v913_highlights_checked",False):
            self._v913_highlights_checked=True
            try:
                from .updater import maybe_show_v913_highlights
                maybe_show_v913_highlights(self.session,delay_ms=850)
            except Exception as exc:
                optional_failure("ui.home_v913_highlights",exc)
        # Reassert resident Recent artwork geometry whenever Home becomes visible.
        # This is intentionally local-only: no artwork lookup, Pillow work or
        # network request.  It fixes the rare Live-card enlargement seen after
        # returning from fullscreen playback.
        for _g in range(3):
            try:self._set_recent_art_geometry(_g)
            except Exception as exc:optional_failure("ui.home_recent_geometry_restore",exc)
        try:
            _preferred=self.recent_index if self.focus_row=="recent" and self._recent_group(self.recent_index)==0 else 0
            self._bind_recent_group_art(0,_preferred)
        except Exception as exc:optional_failure("ui.home_recent_live_hard_rebind",exc)
        if returning:
            # Child screens leave all non-hero Home pixmaps bound. Repaint only
            # the hero released by _image_suspend(); a full rebind here was the
            # source of the heavy return-to-Home pause.
            try:self._home_rebind_timer.stop()
            except Exception as exc:optional_failure("ui.home_fast_timer_stop",exc)
            try:self._home_fast_return()
            except Exception as exc:optional_failure("ui.home_fast_return",exc)
            # Manual Home preparation runs off-thread and may finish a fraction
            # after Details closes. One delayed HDD-state check is cheap and lets
            # the ready composite appear without waiting for the 60s hero timer.
            try:
                self._home_rebind_timer.stop();self._home_rebind_timer.start(900,True)
            except Exception as exc:optional_failure("ui.home_pin_ready_recheck",exc)
        else:
            # PERF26: cold Home no longer performs a full Hero/adaptive rebind
            # synchronously in onShown. _layout_ready already armed the
            # startup-Hero timer, so the fallback shell becomes interactive
            # immediately and the exact same Hero is applied just after paint.
            pass
        self._home_has_shown_once=True
        _perf59_action=getattr(self,"_mem34_last_action","") if returning else ""
        _perf59_cycle=int(getattr(self,"_perf59_cycle",0) or 0)
        _mem34("home_return" if returning else "home_shown", action=_perf59_action, cycle=_perf59_cycle if returning else 0)
        # Recent stays resident underneath child screens.  Only rebuild after a
        # real history mutation (playback/progress/watch/remove), detected via the
        # in-process revision token.  Normal Home -> child -> Home navigation does
        # zero SQLite/artwork work and paints the exact same Recent state instantly.
        if returning:
            try:
                _history_rev=int(history_revision()) if callable(history_revision) else int(getattr(self,"_recent_render_revision",-1))
            except Exception:
                _history_rev=int(getattr(self,"_recent_render_revision",-1))
            if _history_rev!=int(getattr(self,"_recent_render_revision",-1)):
                self._schedule_home_recent_refresh(1)
            # R5.17: the Player saves the final resume point a moment AFTER it
            # closes, so re-check the history revision shortly after returning.
            try:
                self._home_recent_rechecks=3
                t=getattr(self,"_home_recent_recheck_timer",None)
                if t is None:
                    t=eTimer();self._home_recent_recheck_timer=t
                    try:self._home_recent_recheck_conn=t.timeout.connect(self._home_recent_recheck)
                    except Exception:t.callback.append(self._home_recent_recheck)
                t.stop();t.start(1200,True)
            except Exception as exc:optional_failure("ui.home_recent_recheck_arm",exc)
            if LOG is not None:LOG.info("PERF59 home_return_sync cycle=%d action=%s recent_dirty=%s elapsed_ms=%d",_perf59_cycle,str(_perf59_action or ""),str(_history_rev!=int(getattr(self,"_recent_render_revision",-1))),int((time.monotonic()-_perf59_return_t0)*1000))
            self._perf59_schedule_return_probe(_perf59_action)

    def _home_recent_recheck(self):
        try:
            if getattr(self,"_screen_closed",False):return
            rev=int(history_revision()) if callable(history_revision) else -1
            if rev>=0 and rev!=int(getattr(self,"_recent_render_revision",-1)):
                self._schedule_home_recent_refresh(1);return
            left=int(getattr(self,"_home_recent_rechecks",0) or 0)-1
            self._home_recent_rechecks=left
            if left>0:self._home_recent_recheck_timer.start(1500,True)
        except Exception as exc:optional_failure("ui.home_recent_recheck",exc)

    def _home_hidden_release(self):
        if getattr(self,"_screen_closed",False):return
        try:self._perf59_return_probe.stop()
        except Exception:pass
        self._perf59_return_stage=0
        _mem34("home_hidden", action=getattr(self,"_mem34_last_action","") or "", cycle=int(getattr(self,"_perf59_cycle",0) or 0))
        self._pause_home_runtime_timers()
        self._home_images_suspended=False
        self._home_return_pending=True
        # Keep the fully prepared hero + adaptive Home surfaces bound underneath
        # child screens. This makes Home return behave like a warm poster cache.
        # Pending UI-only warmers are cancelled so they cannot steal the event
        # loop while the child Browser is trying to paint its first frame.
        try:self._home_recent_recheck_timer.stop()
        except Exception:pass
        try:self._home_recent_refresh_timer.stop()
        except Exception:pass
        try:self._home_prefetch_delay_timer.stop()
        except Exception:pass
        try:self._home_rebind_timer.stop()
        except Exception as exc:optional_failure("ui.home_hide_timer",exc)
