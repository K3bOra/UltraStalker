"""Ordered, coalesced Details snapshots; GUI submissions never perform storage I/O."""
from __future__ import absolute_import, division, print_function, unicode_literals
from .. import us_env as _us_env
from ..us_env import str, int, max, min, OSError
__metaclass__ = type  # new-style classes on Python 2
import copy
hashlib = _us_env.hashlib
json = _us_env.json
threading = _us_env.threading
time = _us_env.time
OrderedDict = _us_env.collections.OrderedDict
from ..identity import content_digest
from ..manual_identity import original
from ..log import optional_failure


# Snapshot persistence needs identity and alias evidence, not an entire provider
# catalogue/season payload (nor live client/lock objects attached by a caller).
_IDENTITY_FIELDS=frozenset((
    'movie_id','id','video_id','stream_id','series_id','series_uid','episode_id',
    '_series_id','series','parent_id','season','season_id','season_number',
    'episode','number','episode_num','episode_number','episode_name','_series_title',
    'ch_id','channel_id','event_id','start_timestamp','cmd','command','url','name','title',
    'tmdb_id','imdb_id','original_name','original_title','year','release_year',
    'release_date','releasedate','first_air_date','category_id','category',
    '_raw_name','_provider_name','_xtream','country_code','origin_country',
    'production_countries','production_country','country','countries','region',
    'original_language','_origin_language','_manual_identity_revision',
    '_manual_tmdb_selection','_locked_tmdb_id','_locked_tmdb_type',
    '_ultra_search_verified_tmdb_id','identity_verified','identity_pointer_verified',
))

def _item_snapshot(item):
    item=item if isinstance(item,dict) else {}
    result=copy.deepcopy({key:value for key,value in item.items() if key in _IDENTITY_FIELDS})
    if isinstance(item.get('_manual_original'),dict):
        result['_manual_original']=copy.deepcopy({key:value for key,value in original(item).items() if key in _IDENTITY_FIELDS})
    return result


def _persist(profile,media_type,item,data):
    from ..manual_identity import allows_write
    from ..persistent_cache import save_detail_snapshot
    from ..media_library import load
    # A choice changed after enqueue: this obsolete presentation is complete,
    # but must not retry forever or publish a pointer for the superseded choice.
    if not allows_write(profile,media_type,item,data):return True
    latest=load(data.get('media_type') or media_type,data.get('tmdb_id')) or {}
    try:
        old_at=float(data.get('_details_metadata_fetched_at') or 0)
        new_at=float(latest.get('_details_metadata_fetched_at') or 0)
    except (TypeError,ValueError):old_at=new_at=0
    if new_at>old_at>0:return True
    return save_detail_snapshot(profile,media_type,item,data)


class SnapshotWriter:
    def __init__(self,writer=None,limit=128,retry_seconds=2.0):
        self.writer=writer or _persist;self.limit=max(1,int(limit))
        self.retry_seconds=max(.01,float(retry_seconds))
        self._condition=threading.Condition(threading.RLock())
        self._pending=OrderedDict();self._saved=OrderedDict();self._current=None
        self._thread=None;self._closed=False;self._failed={}

    def submit(self,profile,media_type,item,data):
        if not isinstance(data,dict) or not data.get('tmdb_id'):return False
        # Everything above the worker boundary is pure RAM work. Capture a deep
        # snapshot so later UI mutation cannot rewrite an already accepted job.
        profile=copy.deepcopy(profile or {});item=_item_snapshot(item);data=copy.deepcopy(data)
        revision=str(item.get('_manual_identity_revision') or '')
        key=content_digest(profile,media_type,original(item))+'|'+revision
        payload={k:v for k,v in data.items() if k not in ('updated_at','cache_schema')}
        signature=hashlib.sha256(json.dumps(payload,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode('utf-8')).hexdigest()
        row=(profile,media_type,item,data,signature,0.)
        with self._condition:
            if self._closed:return False
            pending=self._pending.get(key)
            if pending is not None and pending[4]==signature:return True
            if pending is None:
                if self._current is not None and self._current[0]==key and self._current[1][4]==signature:return True
                if (self._current is None or self._current[0]!=key) and self._saved.get(key)==signature:return True
                if key not in self._pending and len(self._pending)>=self.limit:return False
            self._pending[key]=row;self._pending.move_to_end(key)
            if self._thread is None:
                self._thread=threading.Thread(target=self._run,name='UltraStalkerSnapshotWriter',daemon=True)
                self._thread.start()
            self._condition.notify_all()
        return True

    def _run(self):
        while True:
            with self._condition:
                while True:
                    if not self._pending:
                        if self._closed:return
                        self._condition.wait();continue
                    now=time.monotonic()
                    ready=next((key for key,row in self._pending.items() if self._closed or row[5]<=now),None)
                    if ready is not None:break
                    delay=max(.01,min(row[5] for row in self._pending.values())-now)
                    self._condition.wait(delay)
                key=ready;row=self._pending.pop(key);self._current=(key,row)
            try:saved=bool(self.writer(*row[:4]))
            except Exception as exc:
                optional_failure('details.snapshot_writer',exc);saved=False
            with self._condition:
                self._current=None
                if saved:
                    self._saved[key]=row[4];self._saved.move_to_end(key)
                    self._failed.pop(key,None)
                    while len(self._saved)>self.limit*2:self._saved.popitem(last=False)
                elif key not in self._pending:
                    if self._closed:
                        self._failed[key]=row
                        optional_failure('details.snapshot_shutdown',OSError('Details snapshot remains unpublished'))
                    else:
                        self._pending[key]=row[:5]+(time.monotonic()+self.retry_seconds,)
                # A newer queued update owns this key after an older failure.
                self._condition.notify_all()

    def flush(self,timeout=2.0):
        end=time.monotonic()+max(0.,float(timeout))
        with self._condition:
            while self._pending or self._current is not None:
                remaining=end-time.monotonic()
                if remaining<=0:return False
                self._condition.wait(remaining)
            return not self._failed

    def shutdown(self,wait=False,timeout=1.5):
        with self._condition:
            self._closed=True;thread=self._thread;self._condition.notify_all()
        if wait and thread is not None:thread.join(max(0.,float(timeout)))
        with self._condition:
            return not (self._pending or self._current is not None or self._failed)


_WRITER=SnapshotWriter()

def queue_detail_snapshot(profile,media_type,item,data):
    try:
        accepted=_WRITER.submit(profile,media_type,item,data)
        if not accepted:optional_failure('details.snapshot_queue',RuntimeError('Details snapshot queue is full or closed'))
        return accepted
    except Exception as exc:
        optional_failure('details.snapshot_submit',exc);return False

def shutdown_snapshot_writer(wait=False,timeout=1.5):
    return _WRITER.shutdown(wait=wait,timeout=timeout)
