# -*- coding: utf-8 -*-
"""Portal page fetch, grid page preparation and rendering of prepared pages.

Methods moved verbatim out of ``PremiumGridBase`` (ui_grid_base.py); behaviour is unchanged.
This module is imported by ui_grid_base.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, zip, max, min, us_clear
from .ui_grid_base import _, _catalogue_error_kind, _direct_fast_local_poster, _mem34, _ui_diag, diagnostic_failure, os, reactor, threading, time

class GridPageLoadMixin(object):
    """Portal page fetch, grid page preparation and rendering of prepared pages."""

    def _portal_page(self, page, cancel_event=None):
        page = max(1, int(page))
        if cancel_event is not None and cancel_event.is_set():
            raise _ArtworkCancelled()
        cached_items = self._portal_page_cache.get(page)
        if cached_items is not None:
            try:
                self._portal_page_cache.move_to_end(page)
            except KeyError:
                pass
            return cached_items
        content_epoch = int(getattr(self, '_content_epoch', 0) or 0)
        result = self.client.ordered_page(self.media_type, self.genre, page, cancel_event=cancel_event)
        if cancel_event is not None and cancel_event.is_set():
            raise _ArtworkCancelled()
        if content_epoch != int(getattr(self, '_content_epoch', 0) or 0):
            raise _ArtworkCancelled()
        items = list((x for x in result.get('items', []) if isinstance(x, dict)))
        if not items and (self._grid_is_m3u_source() or (self.media_type == 'series' and page == 1 and (not int(result.get('total') or 0)))) and (self.media_type in ('vod', 'series')) and str(getattr(self, 'category_title', '') or '').strip() and (str(getattr(self, 'category_title', '') or '').strip() != str(self.genre or '').strip()):
            try:
                alt = self.client.ordered_page(self.media_type, str(self.category_title).strip(), page, cancel_event=cancel_event) or {}
                alt_items = list((x for x in alt.get('items', []) if isinstance(x, dict)))
                if alt_items:
                    result = alt
                    items = alt_items
            except Exception as exc:
                optional_failure('ui.category_title_retry', exc)
        if not self._portal_page_size:
            self._portal_page_size = max(1, int(result.get('page_size') or len(items) or self.page_size))
        self._portal_total = max(self._portal_total, int(result.get('total') or 0))
        native = max(1, int(self._portal_page_size or len(items) or self.page_size or 1))
        known_total = max(0, int(self._portal_total or 0))
        premature_empty = not items and known_total > 0 and ((page - 1) * native < known_total)
        if premature_empty:
            _runtime_endurance_log('grid_native_premature_empty', media_type=self.media_type, page=page, total=known_total, native_page_size=native)
            try:
                bump = getattr(self.client, '_bump_content_cache_generation', None)
                if callable(bump):
                    bump()
            except Exception as exc:
                optional_failure('ui.grid_native_empty_cache_generation', exc)
            try:
                retry = self.client.ordered_page(self.media_type, self.genre, page, cancel_event=cancel_event) or {}
                retry_items = list((x for x in retry.get('items', []) if isinstance(x, dict)))
                if retry_items:
                    result = retry
                    items = retry_items
                    self._portal_page_size = max(1, int(result.get('page_size') or self._portal_page_size or len(items) or 1))
                    self._portal_total = max(self._portal_total, int(result.get('total') or 0))
            except Exception as exc:
                optional_failure('ui.grid_native_empty_retry', exc)
        native = max(1, int(self._portal_page_size or len(items) or self.page_size or 1))
        known_total = max(0, int(self._portal_total or 0))
        expected_more = known_total > 0 and (page - 1) * native < known_total
        if content_epoch != int(getattr(self, '_content_epoch', 0) or 0):
            raise _ArtworkCancelled()
        if items or not expected_more:
            try:
                self._portal_page_cache[page] = items
                self._portal_page_cache.move_to_end(page)
                while len(self._portal_page_cache) > self._portal_page_cache_limit:
                    self._portal_page_cache.popitem(last=False)
            except KeyError:
                pass
        return items

    def _runtime_grid_close(self):
        _mem34('grid_close', mode=self.__class__.__name__, media=str(getattr(self, 'media_type', '') or ''), page=int(getattr(self, 'page', 0) or 0), items=len(getattr(self, 'grid_items', []) or []), visual_ram=len(getattr(self, '_page_visual_ram', {}) or {}))
        if getattr(self, 'media_type', None) == 'itv':
            _live_restart_trace('grid_close', page=int(getattr(self, 'page', 0) or 0), index=int(getattr(self, 'index', 0) or 0), generation=int(getattr(self, '_grid_generation', 0) or 0), inflight=len(getattr(self, '_grid_download_inflight', {}) or {}))
        try:
            cancel = getattr(self, '_page_prefetch_cancel', None)
            if cancel is not None:
                cancel.set()
        except Exception as exc:
            optional_failure('ui.silent_guard', exc)
        try:
            self._cancel_detached_page_prefetch_futures()
        except Exception as exc:
            optional_failure('ui.grid_detached_future_close', exc)
        _runtime_endurance_log('grid_close', media_type=self.media_type, page=getattr(self, 'page', 0), items=len(getattr(self, 'grid_items', []) or []))

    def _grid_page_data(self, target, cancel_event=None, keep_positions=False):
        target = max(1, int(target))
        if not self._portal_page_size:
            self._portal_page(1, cancel_event=cancel_event)
        native = max(1, self._portal_page_size)
        start = (target - 1) * self.page_size
        end = start + self.page_size
        if self._portal_total and start >= self._portal_total:
            return []
        first = start // native + 1
        last = max(start, end - 1) // native + 1
        merged = []
        for native_page in range(first, last + 1):
            if cancel_event is not None and cancel_event.is_set():
                raise _ArtworkCancelled()
            rows=self._portal_page(native_page,cancel_event=cancel_event)
            merged.extend(rows)
            if keep_positions and native_page<last:
                merged.extend([None]*max(0,native-len(rows)))
        base = (first - 1) * native
        return merged[max(0, start - base):max(0, end - base)]

    def _prepare_grid_page(self, target, cancel_event=None):
        """Fetch one page and return first-paint data with zero image generation.

        Test69 Lean contract: catalogue/state reads may happen here, but Pillow,
        adaptive chrome, thumbnail creation and visual-bundle writes never block
        the page becoming visible.  Any missing deterministic derivative is built
        only after the original poster has already painted.
        """
        data = self._grid_page_data(target, cancel_event)
        valid = list((x for x in data if isinstance(x, dict))) if isinstance(data, list) else []
        if self.media_type in ('vod', 'series'):
            from .manual_identity import apply_choice
            valid = list((apply_choice(self.profile, self.media_type, x) for x in valid))
        if self.media_type in ('vod', 'series'):
            prepared_valid = []
            for x in valid:
                if not isinstance(x, dict):
                    continue
                if x.get('_xtream'):
                    row = dict(x)
                    visible_provider = str(_image_url(row) or '').strip()
                else:
                    raw = dict(x)
                    visible_provider = str(raw.get('_visible_provider_art_url') or raw.get('_rescue_provider_art_url') or _image_url(raw) or '').strip()
                    visible_backdrop = ''
                    try:
                        from .ui_artwork_helpers import _backdrop_url as _visible_backdrop_url
                        visible_backdrop = str(raw.get('_visible_provider_backdrop_url') or raw.get('_rescue_provider_backdrop_url') or _visible_backdrop_url(raw) or '').strip()
                    except Exception:
                        visible_backdrop = str(raw.get('_visible_provider_backdrop_url') or raw.get('_rescue_provider_backdrop_url') or '').strip()
                    row = _strip_portal_artwork(raw)
                    if visible_provider:
                        row['_visible_provider_art_url'] = visible_provider
                    if visible_backdrop:
                        row['_visible_provider_backdrop_url'] = visible_backdrop
                prepared_valid.append(row)
            valid = prepared_valid
            try:
                art_counts = {}
                for row in valid:
                    value = str(row.get('_visible_provider_art_url') or _image_url(row) or '').strip()
                    if value:
                        art_counts[value] = art_counts.get(value, 0) + 1
                generic_urls = {url for url, count in art_counts.items() if count >= 3}
                for row in valid:
                    value = str(row.get('_visible_provider_art_url') or _image_url(row) or '').strip()
                    if value in generic_urls:
                        row['_generic_provider_art'] = True
                        row['_generic_provider_art_url'] = value
            except Exception as exc:
                optional_failure('ui.generic_provider_art_detect', exc)
        states = load_content_states(self.profile, self.media_type, valid) if valid else []
        qualities = load_content_qualities(self.profile, self.media_type, valid) if valid and self.media_type in ('vod', 'series') else list(('' for _ in valid))
        after_open = []
        state_rows = []
        cfg = self._grid_settings or {}
        prepared_titles = []
        prepared_fitted = []
        prepared_meta = []
        prepared_art = []
        _r50_cache_t0 = time.monotonic()
        _r50_cache_checks = 0
        _r50_cache_hits = 0
        _r52_fast_hits = 0
        _r52_fallbacks = 0
        _r81_bridge_hits = 0
        for pos, item in enumerate(valid):
            metadata_identity = None
            if self.media_type in ('vod', 'series'):
                try:
                    from .ui_grid_v2_premium import seed_badge_metadata
                    seed_badge_metadata(self, item)
                except Exception as exc:
                    optional_failure('ui.badge_seed_first_paint', exc)
                try:
                    self._age_cache_seed_item(item)
                except Exception as exc:
                    optional_failure('ui.age_cache_first_paint', exc)
            state = states[pos] if pos < len(states) else {}
            quality = qualities[pos] if pos < len(qualities) else ''
            row = dict(state or {})
            row['quality'] = quality or ''
            state_rows.append(row)
            raw = item.get('name') or item.get('title') or item.get('id') or _('Result')
            title = self._display_item_title(item, 'Item')
            prepared_titles.append(title)
            if self.media_type == 'itv':
                prepared_fitted.append((one_line(title, 36), None))
                prepared_meta.append(str((target - 1) * self.page_size + pos + 1))
            else:
                fitted_title, fitted_font = _grid_fit_card_title(title, 226)
                prepared_fitted.append((fitted_title, int(fitted_font)))
                bits = []
                explicit = self._explicit_item_quality(item)
                badges = explicit or str(row.get('quality') or '') or quality_badges(raw) if cfg.get('show_quality_badges', True) else ''
                if badges:
                    bits.append(badges)
                if item.get('year'):
                    bits.append(str(item.get('year'))[:4])
                if row.get('favorite'):
                    bits.append('★')
                if row.get('completed') and cfg.get('show_watched', True):
                    bits.append('WATCHED')
                elif row.get('position') and row.get('duration'):
                    bits.append('%d%%' % min(99, int(row['position'] * 100.0 / row['duration'])))
                prepared_meta.append('  •  '.join(bits)[:28])
            art_row = self._page_visual_get(item) if self.media_type in ('vod', 'series') else {}
            try:
                _cur_rating = float(self._folder_rating_value(item) or 0)
            except Exception:
                _cur_rating = 0.0
            _need_badge_snap = bool(self.media_type in ('vod', 'series') and (not art_row or not 0.0 < _cur_rating <= 10.0 or self._folder_year_value(item) <= 0 or (not item.get('certification') and (not item.get('age_rating')) and (not item.get('_age_rating_checked')))))
            if _need_badge_snap:
                try:
                    _r50_cache_checks += 1
                    _fast_loader = globals().get('load_artwork_v2_fast_local_poster') or _direct_fast_local_poster
                    if _fast_loader is None:
                        raise NameError('load_artwork_v2_fast_local_poster is not available')
                    snap = _fast_loader(self.profile, self.media_type, item) or {}
                    _fast_poster = str(snap.get('poster_local') or '')
                    if _fast_poster and os.path.isfile(_fast_poster) and (os.path.getsize(_fast_poster) > 256):
                        _r52_fast_hits += 1
                    metadata_identity = snap
                    if snap.get('_fast_bridge_source'):
                        _r81_bridge_hits += 1
                    for key in ('number_of_seasons', 'seasons_count', 'season_count'):
                        if snap.get(key) is not None:
                            item[key] = snap[key]
                    _tmdb_id = snap.get('tmdb_id')
                    if _tmdb_id:
                        item['_locked_tmdb_id'] = _tmdb_id
                        item['_locked_tmdb_type'] = snap.get('media_type') or ('tv' if self.media_type == 'series' else 'movie')
                    try:
                        _score = float(snap.get('rating') or snap.get('vote_average') or 0)
                    except Exception:
                        _score = 0.0
                    if 0.0 < _score <= 10.0:
                        item['_tmdb_rating'] = _score
                    try:
                        _cached_raw_age = str(snap.get('certification') or snap.get('age_rating') or '').strip()
                        _cached_age_checked = bool(snap.get('_age_rating_checked') or _cached_raw_age)
                        if _cached_age_checked:
                            item['_age_rating_checked'] = True
                            if _cached_raw_age:
                                item['certification'] = _cached_raw_age
                                item['age_rating'] = _cached_raw_age
                            self._age_cache_put(item, _cached_raw_age, True)
                    except Exception as exc:
                        optional_failure('ui.r226_age_manifest_seed', exc)
                    try:
                        if self._folder_year_value(item) <= 0:
                            _year = self._folder_year_value(snap)
                            if _year > 0:
                                item['year'] = _year
                    except Exception:
                        pass
                    try:
                        from .ui_grid_v2_premium import merge_badge_metadata
                        merge_badge_metadata(self, item, snap)
                    except Exception:
                        pass
                    if not art_row:
                        _poster = str(snap.get('poster_local') or '')
                        _backdrop = str(snap.get('backdrop_local') or '')
                        if _poster and os.path.isfile(_poster) and (os.path.getsize(_poster) > 256):
                            _display = _poster
                            try:
                                _thumb = self._grid_poster_thumb_path(_poster) or ''
                                if _thumb and os.path.isfile(_thumb) and (os.path.getsize(_thumb) > 100):
                                    _display = _thumb
                            except Exception:
                                pass
                            art_row = {'display': _display, 'poster': _poster, 'palette': _poster}
                            if _backdrop and os.path.isfile(_backdrop) and (os.path.getsize(_backdrop) > 1024):
                                art_row['backdrop'] = _backdrop
                            _r50_cache_hits += 1
                except Exception as exc:
                    optional_failure('ui.r50_cache_first_manifest', exc)
            if self.media_type in ('vod', 'series') and isinstance(metadata_identity, dict) and metadata_identity.get('tmdb_id'):
                after_open.append(('metadata', dict(item), dict(metadata_identity)))
            prepared_art.append(art_row)
        if self.media_type in ('vod', 'series'):
            try:
                import logging
                logging.getLogger('UltraStalker').info('PERF52 cache_first_fast media=%s mode=%s page=%d checks=%d fast_hits=%d bridge_hits=%d fallback=%d poster_hits=%d elapsed_ms=%d', str(self.media_type or ''), self.__class__.__name__, int(target or 0), int(_r50_cache_checks), int(_r52_fast_hits), int(_r81_bridge_hits), int(_r52_fallbacks), int(_r50_cache_hits), int((time.monotonic() - _r50_cache_t0) * 1000))
            except Exception:
                pass
        return {'items': valid, 'states': state_rows, 'titles': prepared_titles, 'fitted': prepared_fitted, 'meta': prepared_meta, 'art': prepared_art, '_after_open': after_open}

    def _cache_prepared_page(self, target, payload):
        if not isinstance(payload, dict):
            return
        with self._prepared_page_lock:
            self._prepared_page_cache[int(target)] = payload
            self._prepared_page_cache.move_to_end(int(target))
            while len(self._prepared_page_cache) > max(4, int(getattr(self, '_prepared_page_cache_limit', 4) or 4)):
                self._prepared_page_cache.popitem(last=False)
            self._prepared_page_pending.discard(int(target))

    def _apply_prepared_page(self, target, payload, restore_index=None):
        try:
            _nav_target = int(getattr(self, '_grid_page_nav_target', 0) or 0)
            if self.media_type in ('vod', 'series') and _nav_target and (int(target) != _nav_target):
                if isinstance(payload, dict):
                    self._cache_prepared_page(int(target), payload)
                return False
        except Exception as exc:
            optional_failure('ui.grid_page_nav_stale_result', exc)
        valid = list((payload or {}).get('items') or [])
        if not valid and target > 1:
            if not getattr(self, '_initial_grid_paint_done', False) and (not getattr(self, 'grid_items', None)):
                self._restore_page = 1
                self._restore_index = 0
                try:
                    _state = dict(_GRID_NAV_STATE.get(self._session_nav_key, {}) or {})
                    _state.update({'page': 1, 'index': 0})
                    _GRID_NAV_STATE[self._session_nav_key] = _state
                except Exception as exc:
                    optional_failure('ui.grid_initial_restore_reset', exc)
                self['status'].setText(_('Loading page %d...') % 1)
                self.load_page(1, 0)
                return False
            self['status'].setText(_('No more items'))
            if int(getattr(self, '_grid_page_nav_target', 0) or 0) == int(target):
                self._grid_page_nav_target = 0
                self._grid_page_nav_index = 0
            return False
        if not valid and target == 1:
            message = _('No content')
            self.page = 1
            self.grid_items = []
            self.index = 0
            self._prepared_titles_for_render = []
            self._prepared_fitted_for_render = []
            self._prepared_meta_for_render = []
            self._prepared_art_for_render = []
            try:
                self._render_grid()
            except Exception as exc:
                optional_failure('ui.grid_initial_empty_render', exc)
            for _n in ('selection', 'selection_adaptive'):
                try:
                    self[_n].hide()
                except Exception:
                    pass
            try:
                self['status'].setText(message)
                self['page_label'].setText(_('No content'))
            except Exception:
                pass
            if int(getattr(self, '_grid_page_nav_target', 0) or 0) == int(target):
                self._grid_page_nav_target = 0
                self._grid_page_nav_index = 0
            return False
        if valid:self._cache_prepared_page(target,payload)
        self.page = target
        self.grid_items = valid
        self._initial_grid_paint_done = True
        state_rows = list((payload or {}).get('states') or [])
        self._grid_item_state = {}
        for item, row in zip(self.grid_items, state_rows):
            self._grid_item_state[id(item)] = dict(row or {})
        self._prepared_titles_for_render = list((payload or {}).get('titles') or [])
        self._prepared_fitted_for_render = list((payload or {}).get('fitted') or [])
        self._prepared_meta_for_render = list((payload or {}).get('meta') or [])
        self._prepared_art_for_render = list((payload or {}).get('art') or [])
        self.index = max(0, min(int(restore_index or 0), len(valid) - 1)) if valid else 0
        self._grid_full_chrome_warm = False
        _perf49_render_t0 = time.monotonic()
        self._render_grid()
        self._remember_grid_state()
        try:
            self._schedule_page_maintenance(payload)
        except Exception as exc:
            optional_failure('ui.page_maintenance_schedule', exc)
        try:
            if self.media_type in ('vod', 'series') and int(getattr(self, '_grid_page_nav_target', 0) or 0) == int(target):
                self._grid_page_nav_target = 0
                self._grid_page_nav_index = 0
        except Exception:
            pass
        try:
            import logging
            logging.getLogger('UltraStalker').info('PERF49 grid_first_paint media=%s mode=%s page=%d items=%d render_ms=%d', str(self.media_type or ''), self.__class__.__name__, int(self.page or 0), len(self.grid_items), int((time.monotonic() - _perf49_render_t0) * 1000))
        except Exception:
            pass
        _mem34('grid_page_painted', mode=self.__class__.__name__, media=str(self.media_type or ''), page=int(self.page or 0), items=len(self.grid_items), visual_ram=len(getattr(self, '_page_visual_ram', {}) or {}))
        self._mem34_schedule_settled()
        try:
            from .folder_refresh import schedule as _refresh_selected_folder
            _refresh_selected_folder(self)
        except Exception as exc:optional_failure("ui.selected_folder_refresh",exc)
        try:
            _ui_diag('ui_page_ready', screen='grid', media_type=self.media_type, page=self.page, items=len(self.grid_items), elapsed_ms=int(max(0.0, (time.monotonic() - float(getattr(self, '_ui_diag_page_request_mono', time.monotonic()))) * 1000.0)))
        except Exception as exc:
            diagnostic_failure('ui.grid.failsoft.1171', exc)
        total = int(self._portal_total or 0)
        total_pages = max(1, (total + self.page_size - 1) // self.page_size) if total else max(1, self.page)
        absolute = min(total, (self.page - 1) * self.page_size + self.index + 1) if total else (self.page - 1) * self.page_size + self.index + 1
        kind = 'Channel' if self.media_type == 'itv' else 'Movie' if self.media_type == 'vod' else 'Series'
        self['status'].setText('')
        self['page_label'].setText(_('Page %d / %d  •  %s %d / %d') % (self.page, total_pages, kind, absolute, total or absolute))
        try:
            self._start_progressive_poster_prefetch()
        except Exception as exc:
            optional_failure('ui.auto_visible_page', exc)
        if bool(getattr(self, 'visible_card_rating_prefetch', False)) and self.media_type in ('vod', 'series'):
            try:
                self._schedule_visible_rating_sweeps()
            except Exception as exc:
                optional_failure('ui.visible_rating_page_schedule', exc)
        try:
            import logging
            logging.getLogger('UltraStalker').info('PERF50 page_background_started media=%s mode=%s page=%d rating_pass=%s rating_delay_ms=%d', str(self.media_type or ''), self.__class__.__name__, int(self.page or 0), bool(getattr(self, 'visible_card_rating_prefetch', False) and self.media_type in ('vod', 'series')), 150 if bool(getattr(self, 'visible_card_rating_prefetch', False) and self.media_type in ('vod', 'series')) else 0)
        except Exception:
            pass
        try:
            _warm_gen = int(getattr(self, '_page_prefetch_generation', 0) or 0)

            def _deferred_warm(gen=_warm_gen):
                if not getattr(self, '_screen_closed', False) and gen == int(getattr(self, '_page_prefetch_generation', 0) or 0):
                    try:
                        self._warm_poster_grid_catalogue_pages()
                    except Exception as _wexc:
                        optional_failure('ui.poster_grid_catalogue_warm_start', _wexc)
            reactor.callLater(1.8, _deferred_warm)
        except Exception as exc:
            optional_failure('ui.poster_grid_catalogue_warm_start', exc)
        return True

    def load_page(self, page, restore_index=None):
        if self.media_type == 'itv':
            _live_restart_trace('page_request', page=int(page or 1), current_page=int(getattr(self, 'page', 0) or 0), index=int(getattr(self, 'index', 0) or 0), generation=int(getattr(self, '_grid_generation', 0) or 0), inflight=len(getattr(self, '_grid_download_inflight', {}) or {}))
        if self.media_type in ('vod', 'series') and self._view_active and isinstance(self._view_items, list):
            self._load_folder_view_page(page, restore_index)
            return
        target = max(1, int(page))
        if self.media_type == 'series':
            self._stop_series_hierarchy_prefetch()
        self._ui_diag_page_request_mono = time.monotonic()
        self._ui_diag_page_target = target
        self._ui_diag_first_poster_logged = False
        with self._prepared_page_lock:
            prepared = self._prepared_page_cache.get(target)
            if prepared is not None:self._prepared_page_cache.move_to_end(target)
        if prepared is not None and target == 1 and (not list((prepared or {}).get('items') or [])):
            prepared = None
        if prepared is not None:
            # A warm page replaces an in-flight cold request immediately.
            old_handle=getattr(self,"_page_load_handle",None)
            if old_handle is not None:
                try:old_handle.cancel()
                except Exception:pass
            self._busy=False
            try:
                old_cancel = getattr(self, '_page_prefetch_cancel', None)
                if old_cancel is not None:
                    old_cancel.set()
            except Exception:
                pass
            self._cancel_detached_page_prefetch_futures()
            for future in list(getattr(self, '_page_prefetch_futures', []) or []):
                try:
                    future.cancel()
                except Exception:
                    pass
            self._page_prefetch_futures = []
            self._page_prefetch_cancel = threading.Event()
            try:
                self._page_prefetch_generation += 1
            except Exception:
                self._page_prefetch_generation = 1
            try:
                with self._page_prefetch_lock:
                    us_clear(self._page_prefetch_seen)
                    us_clear(self._visible_tmdb_pending)
                    us_clear(self._page_quality_seen)
                    us_clear(self._page_art_retry_count)
            except Exception:
                pass
            # Background hydration may have completed since this page was cached.
            _items=list(prepared.get("items") or [])
            _art=list(prepared.get("art") or [])
            while len(_art)<len(_items):_art.append({})
            for _pos,_item in enumerate(_items):
                if not (_art[_pos].get("display") or _art[_pos].get("poster")):
                    _visual=self._page_visual_get(_item) or {}
                    if not _visual.get("provider_locked"):_art[_pos]=dict(_visual)
            prepared["art"]=_art
            self._apply_prepared_page(target, prepared, restore_index)
            return
        try:
            self.client.reset_failure_backoff()
        except Exception as exc:
            optional_failure('ui.silent_guard', exc)
        if self._busy:
            self._pending_page_request = (target, restore_index)
            old = getattr(self, '_page_load_handle', None)
            if old is not None:
                try:
                    old.cancel()
                except Exception as exc:
                    optional_failure('ui.page_load_cancel', exc)
            self._busy = False
        self._pending_page_request = None
        if self.media_type in ('vod', 'series') and getattr(self, 'grid_items', None):
            self['status'].setText('')
        else:
            self['status'].setText(_('Loading page %d...') % target)
        try:
            old_cancel = getattr(self, '_page_prefetch_cancel', None)
            if old_cancel is not None:
                old_cancel.set()
        except Exception as exc:
            optional_failure('ui.silent_guard', exc)
        self._cancel_detached_page_prefetch_futures()
        for future in list(getattr(self, '_page_prefetch_futures', []) or []):
            try:
                future.cancel()
            except Exception as exc:
                optional_failure('ui.silent_guard', exc)
        self._page_prefetch_futures = []
        self._page_prefetch_cancel = threading.Event()
        try:
            self._page_prefetch_generation += 1
        except Exception:
            self._page_prefetch_generation = 1
        request_generation = self._page_prefetch_generation
        try:
            with self._page_prefetch_lock:
                us_clear(self._page_prefetch_seen)
                us_clear(self._visible_tmdb_pending)
                us_clear(self._page_quality_seen)
                us_clear(self._page_art_retry_count)
        except Exception as exc:
            optional_failure('ui.silent_guard', exc)
        _runtime_endurance_log('grid_page_request', media_type=self.media_type, page=target, prefetch_generation=request_generation)

        def ok(data):
            if request_generation != int(getattr(self, '_page_prefetch_generation', 0) or 0):
                return
            if not isinstance(data, dict):
                failed(ValueError('Invalid prepared page'))
                return
            self._apply_prepared_page(target, data, restore_index)
            _runtime_endurance_log('grid_page', media_type=self.media_type, page=self.page, items=len(self.grid_items), prefetch_generation=self._page_prefetch_generation)

        def failed(e):
            if request_generation == int(getattr(self, '_page_prefetch_generation', 0) or 0):
                kind = _catalogue_error_kind(e)
                if kind == 'transient' and getattr(self, 'grid_items', None):
                    self['status'].setText('')
                else:
                    message = _('Content temporarily unavailable. Try again.') if kind == 'transient' else _friendly_error(e)
                    self['status'].setText(message)
                    if not getattr(self, 'grid_items', None):
                        try:
                            self.grid_items = []
                            self.index = 0
                            self._prepared_titles_for_render = []
                            self._prepared_fitted_for_render = []
                            self._prepared_meta_for_render = []
                            self._prepared_art_for_render = []
                            self._render_grid()
                            for _n in ('selection', 'selection_adaptive'):
                                try:
                                    self[_n].hide()
                                except Exception:
                                    pass
                            self['page_label'].setText(_('Categories could not be loaded'))
                        except Exception as exc:
                            optional_failure('ui.grid_initial_error_hold', exc)
                if int(getattr(self, '_grid_page_nav_target', 0) or 0) == int(target):
                    self._grid_page_nav_target = 0
                    self._grid_page_nav_index = 0
                if int(getattr(self, '_cin_page_nav_target', 0) or 0) == int(target):
                    self._cin_page_nav_target = 0
                    self._cin_page_nav_row = 0
                _runtime_endurance_log('grid_page_error', media_type=self.media_type, page=target, error_kind=kind)
        self._page_load_handle = self._run_async(lambda handle: self._prepare_grid_page_resilient(target, handle.cancel_event), ok, failed)

    def _prepare_initial_page_isolated_rescue(self, target, cancel_event=None):
        """One final fresh-client rescue for an initial category open.

        The Browser and Grid normally share the authenticated client.  Some
        receivers/portals leave that transport in a transient loader state even
        though a fresh session succeeds immediately.  Fetch only the native
        pages needed for the first visible grid into this screen's RAM cache,
        then run the normal local preparation path.  The shared client is never
        replaced or cancelled.
        """
        if int(target or 1) != 1 or getattr(self, 'grid_items', None):
            return None
        isolated = None
        try:
            timeout = min(7, max(3, int((self._grid_settings or {}).get('timeout', 10) or 10)))
            isolated = _new_isolated_source_client(dict(self.profile or {}), timeout=timeout)

            def fetch_native(native_page):
                if cancel_event is not None and cancel_event.is_set():
                    raise _ArtworkCancelled()
                result = isolated.ordered_page(self.media_type, self.genre, native_page, cancel_event=cancel_event) or {}
                items = list((x for x in result.get('items', []) if isinstance(x, dict)))
                if not items and (self._grid_is_m3u_source() or (self.media_type == 'series' and native_page == 1 and (not int(result.get('total') or 0)))) and (self.media_type in ('vod', 'series')) and str(getattr(self, 'category_title', '') or '').strip() and (str(getattr(self, 'category_title', '') or '').strip() != str(self.genre or '').strip()):
                    try:
                        alt = isolated.ordered_page(self.media_type, str(self.category_title).strip(), native_page, cancel_event=cancel_event) or {}
                        alt_items = list((x for x in alt.get('items', []) if isinstance(x, dict)))
                        if alt_items:
                            result = alt
                            items = alt_items
                    except Exception as exc:
                        optional_failure('ui.grid_isolated_category_title_retry', exc)
                return (result, items)
            result, items = fetch_native(1)
            native = max(1, int(result.get('page_size') or len(items) or self.page_size or 1))
            total = max(0, int(result.get('total') or 0))
            if not items:
                return None
            us_clear(self._portal_page_cache)
            self._portal_page_size = native
            self._portal_total = total
            self._portal_page_cache[1] = items
            start = 0
            end = max(1, int(self.page_size or 1))
            last = max(start, end - 1) // native + 1
            for native_page in range(2, last + 1):
                result_n, items_n = fetch_native(native_page)
                self._portal_total = max(self._portal_total, int(result_n.get('total') or 0))
                if items_n:
                    self._portal_page_cache[native_page] = items_n
            payload = self._prepare_grid_page(1, cancel_event)
            if list((payload or {}).get('items') or []):
                _runtime_endurance_log('grid_initial_isolated_rescue', media_type=self.media_type, page=1, items=len((payload or {}).get('items') or []))
                return payload
        except _ArtworkCancelled:
            raise
        except Exception as exc:
            optional_failure('ui.grid_initial_isolated_rescue', exc)
        finally:
            if isolated is not None:
                try:
                    isolated.close()
                except Exception:
                    pass
        return None

    def _finish_prepared_page(self, payload, cancel_event=None):
        if cancel_event is not None and cancel_event.is_set():
            raise _ArtworkCancelled()
        if self._grid_is_m3u_source() and self.media_type in ('vod', 'series'):
            payload = self._refresh_prepared_m3u_art_from_hdd(payload)
        if cancel_event is not None and cancel_event.is_set():
            raise _ArtworkCancelled()
        return payload

    def _schedule_page_maintenance(self, payload=None):
        generation = int(getattr(self, '_page_prefetch_generation', 0) or 0)
        if payload is not None:
            operations = payload.pop('_after_open', []) if isinstance(payload, dict) else []
            if not operations:
                self._page_maintenance_state = None
                return
            state = {'generation': generation, 'operations': operations, 'index': 0, 'queued': False, 'running': False, 'cancel': getattr(self, '_page_prefetch_cancel', None)}
            self._page_maintenance_state = state
        else:
            state = getattr(self, '_page_maintenance_state', None)
            if not state or state['generation'] != generation:
                return
            operations = state['operations']
            if not getattr(self, '_grid_images_suspended', False):
                state['cancel'] = None
        if state['index'] >= len(operations) or state['queued'] or state['running']:
            return
        import weakref
        from .core.shared_executors import PAGE_MAINTENANCE_EXECUTOR
        owner_ref = weakref.ref(self)
        task_key = 'page-maintenance:%x' % id(self)
        profile = dict(self.profile or {})
        media_type = self.media_type

        def current():
            owner = owner_ref()
            return owner is not None and (not getattr(owner, '_screen_closed', True)) and (not getattr(owner, '_grid_images_suspended', False)) and (getattr(owner, '_page_maintenance_state', None) is state) and (generation == int(getattr(owner, '_page_prefetch_generation', 0) or 0)) and (not (state.get('cancel') is not None and state['cancel'].is_set()))

        def work():
            from .manual_identity import cache_token, selected
            try:
                while state['index'] < len(operations):
                    if not current():
                        return
                    operation = operations[state['index']]
                    kind, item, record = tuple(operation)[:3]
                    extra = tuple(operation)[3:]
                    try:
                        if cache_token(profile, media_type, item) != str(item.get('_manual_identity_revision') or ''):
                            continue
                        if selected(item):
                            continue
                        if kind == 'metadata':
                            from .details_authority import remember_catalogue_metadata
                            if record is None and (not item.get('_locked_tmdb_id')):
                                loader = globals().get('load_artwork_v2_fast_local_poster') or _direct_fast_local_poster
                                record = loader(profile, media_type, item) or {} if loader else {}
                                if not record:
                                    record = load_artwork_v2_manifest(profile, media_type, item) or {}
                            remember_catalogue_metadata(media_type, item, record)
                        elif kind == 'cin_alias':
                            owner = owner_ref()
                            if owner is not None:
                                owner._cin_publish_nav_alias(item, record, extra[0])
                    except Exception as exc:
                        optional_failure('ui.page_maintenance', exc)
                    finally:
                        state['index'] += 1
            finally:
                state['running'] = False
                if state['index'] >= len(operations):
                    state['operations'] = []
                elif current():
                    owner = owner_ref()
                    if owner is not None:
                        reactor.callFromThread(owner._schedule_page_maintenance)

        def finished(future):
            if future.cancelled() or future.exception() is not None:
                state['running'] = False

        def start():
            state['queued'] = False
            if not current():
                return
            state['running'] = True
            try:
                future = PAGE_MAINTENANCE_EXECUTOR.submit(work, priority=3, _task_key=task_key, _replace_task_key=True)
                future.add_done_callback(finished)
            except Exception as exc:
                state['running'] = False
                optional_failure('ui.page_maintenance_submit', exc)
        state['queued'] = True
        reactor.callLater(1.2, start)

    def _prepare_grid_page_resilient(self, target, cancel_event=None):
        """Retry only transient catalogue reads inside the same grid screen.

        This intentionally mirrors the user's successful manual second-arrow /
        BACK-and-enter recovery, but does it without repainting an error between
        attempts. Artwork/TMDB/player work is not retried here.
        """
        last_error = None
        delays = (0.0, 0.18, 0.42, 0.75)
        for attempt, delay in enumerate(delays):
            if cancel_event is not None and cancel_event.is_set():
                raise _ArtworkCancelled()
            if attempt:
                if cancel_event is not None and getattr(cancel_event, 'wait', lambda _x: False)(delay):
                    raise _ArtworkCancelled()
                try:
                    close_pending = getattr(self.client, 'cancel_pending_requests', None)
                    if callable(close_pending) and (not hasattr(self.client, '_xtream')):
                        close_pending()
                except Exception as exc:
                    optional_failure('ui.grid_retry_transport', exc)
                try:
                    reset = getattr(self.client, 'reset_failure_backoff', None)
                    if callable(reset):
                        reset()
                except Exception as exc:
                    optional_failure('ui.grid_retry_backoff', exc)
                if attempt == 2:
                    try:
                        authorize = getattr(self.client, 'authorize', None)
                        if callable(authorize):
                            try:
                                authorize(cancel_event=cancel_event)
                            except TypeError:
                                authorize()
                    except Exception as exc:
                        last_error = exc
                        optional_failure('ui.grid_retry_authorize', exc)
            try:
                payload = self._prepare_grid_page(target, cancel_event)
                page_items = list((payload or {}).get('items') or [])
                if target == 1 and (not page_items):
                    if attempt < len(delays) - 1:
                        try:
                            us_clear(self._portal_page_cache)
                        except Exception:
                            pass
                        self._portal_page_size = 0
                        self._portal_total = 0
                        if not getattr(self, '_grid_empty_generation_bumped', False):
                            try:
                                bump = getattr(self.client, '_bump_content_cache_generation', None)
                                if callable(bump):
                                    bump()
                            except Exception as bump_exc:
                                optional_failure('ui.grid_empty_cache_generation', bump_exc)
                            self._grid_empty_generation_bumped = True
                        last_error = Exception('Empty catalogue response')
                        _runtime_endurance_log('grid_page_empty_retry', media_type=self.media_type, page=target, attempt=attempt + 1)
                        continue
                    rescue = self._prepare_initial_page_isolated_rescue(target, cancel_event)
                    if rescue is not None:
                        return self._finish_prepared_page(rescue, cancel_event)
                total = max(0, int(self._portal_total or 0))
                start = max(0, (int(target) - 1) * int(self.page_size or 1))
                expected = min(int(self.page_size or 1), max(0, total - start)) if total > start else 0
                if expected > 0 and len(page_items) < expected:
                    try:
                        us_clear(self._portal_page_cache)
                    except Exception:
                        pass
                    last_error = Exception('Premature catalogue page: got %d of %d items' % (len(page_items), expected))
                    _runtime_endurance_log('grid_page_short_retry', media_type=self.media_type, page=target, attempt=attempt + 1, got=len(page_items), expected=expected, total=total)
                    if attempt < len(delays) - 1:
                        continue
                    raise last_error
                return self._finish_prepared_page(payload, cancel_event)
            except _ArtworkCancelled:
                raise
            except Exception as exc:
                last_error = exc
                kind = _catalogue_error_kind(exc)
                _runtime_endurance_log('grid_page_retry', media_type=self.media_type, page=target, attempt=attempt + 1, error_kind=kind)
                if kind != 'transient' or attempt >= len(delays) - 1:
                    if attempt >= len(delays) - 1 and target == 1 and (not getattr(self, 'grid_items', None)):
                        rescue = self._prepare_initial_page_isolated_rescue(target, cancel_event)
                        if rescue is not None:
                            return rescue
                    raise
        raise last_error or Exception('Catalogue request failed')
