"""Optional next-episode context for a directly opened Recent episode."""
from __future__ import absolute_import, division, print_function, unicode_literals
from ..us_env import str, int, max

def live_folder_page(client,category_id,page,page_size,cancel_event=None):
    """Read a saved Live folder page using its UI page size."""
    start=(page-1)*page_size
    data=client.ordered_page('itv',category_id,1,cancel_event=cancel_event) or {}
    rows=data.get('items') or []
    native_size=max(1,int(data.get('page_size') or len(rows) or 1))
    total=max(len(rows),int(data.get('total') or 0))
    if not rows or start>=total:
        return {'items':[],'total':total}
    end=min(start+page_size,total)
    first=start//native_size+1
    last=(end-1)//native_size+1
    result=[]
    for native_page in range(first,last+1):
        if cancel_event is not None and cancel_event.is_set():
            return {'items':[],'total':total}
        if native_page!=1:
            data=client.ordered_page('itv',category_id,native_page,cancel_event=cancel_event) or {}
            rows=data.get('items') or []
        base=(native_page-1)*native_size
        for offset in range(max(0,start-base),min(native_size,end-base)):
            result.append(rows[offset] if offset<len(rows) else None)
    return {'items':result,'total':total}


def live_context(client,item,cancel_event):
    """Fetch the saved page after tune, preserving real folder size for zapping."""
    cid=item.get('_live_category_id') or item.get('tv_genre_id') or item.get('category_id') or item.get('genre_id')
    if not cid or cancel_event.is_set():return None
    page=max(1,int(item.get('_live_folder_page') or 1))
    if item.get('_live_page_size'):
        size=max(1,int(item['_live_page_size']))
        data=live_folder_page(client,str(cid),page,size,cancel_event)
    else:
        data=client.ordered_page('itv',str(cid),page,cancel_event=cancel_event) or {}
        size=max(1,int(data.get('page_size') or len(data.get('items') or []) or 1))
    if cancel_event.is_set():return None
    rows=data.get('items') or []
    total=max(len(rows),int(data.get('total') or 0))
    for index,row in enumerate(rows):
        if not isinstance(row,dict):continue
        same=any(item.get(k) not in (None,'') and str(item[k])==str(row.get(k)) for k in ('id','ch_id','stream_id'))
        command=item.get('cmd') or item.get('command') or item.get('url')
        if same or (command and command==(row.get('cmd') or row.get('command') or row.get('url'))):
            return {'channels':rows,'page':page,'page_size':size,'total':total,
                    'absolute_index':(page-1)*size+index,'category_id':str(cid)}
    return None

def next_episode(client, item, cancel_event):
    if cancel_event.is_set():return None
    sid=item.get('_series_id') or item.get('series_id') or item.get('parent_id')
    if sid in (None,''):return None
    parent={'id':sid,'series_id':sid,'name':item.get('_series_title') or item.get('series_title') or ''}
    season=item.get('_season_number') or item.get('season_number') or item.get('season')
    seasons=client.series_seasons(parent,cancel_event=cancel_event) or []
    for row in seasons[:50]:
        if cancel_event.is_set():return None
        number=row.get('season_number') or row.get('season') or row.get('id')
        if season not in (None,'') and str(number)!=str(season):continue
        rows=client.series_episodes(parent,row,cancel_event=cancel_event) or []
        for index,current in enumerate(rows):
            same_id=any(item.get(key) not in (None,'') and str(item[key])==str(current.get(key)) for key in ('id','episode_id'))
            if not same_id:continue
            if index+1>=len(rows):return None
            following=dict(rows[index+1])
            following['_series_id']=sid
            following['_series_title']=parent['name']
            if item.get('_raw_series_title'):following['_raw_series_title']=item.get('_raw_series_title')
            for art_key in ('_player_poster','_adaptive_source_local','_ultra_palette_source','cover','screenshot_uri','poster'):
                if not following.get(art_key) and item.get(art_key):
                    following[art_key]=item.get(art_key)
            following['_season_number']=number
            following['_episode_number']=following.get('episode_number') or following.get('episode') or following.get('number') or index+2
            return following
    return None
