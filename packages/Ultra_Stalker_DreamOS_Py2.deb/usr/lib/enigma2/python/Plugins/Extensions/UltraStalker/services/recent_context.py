"""Optional next-episode context for a directly opened Recent episode."""
from __future__ import absolute_import, division, print_function, unicode_literals
from ..us_env import str, int, max

def live_context(client,item,cancel_event):
    """Fetch the saved page after tune, preserving real folder size for zapping."""
    cid=item.get('_live_category_id') or item.get('tv_genre_id') or item.get('category_id') or item.get('genre_id')
    if not cid or cancel_event.is_set():return None
    page=max(1,int(item.get('_live_folder_page') or 1))
    data=client.ordered_page('itv',str(cid),page,cancel_event=cancel_event) or {}
    if cancel_event.is_set():return None
    rows=list(dict(row) for row in data.get('items',[]) if isinstance(row,dict))
    size=max(1,int(data.get('page_size') or len(rows) or 1))
    total=max(len(rows),int(data.get('total') or len(rows)))
    for index,row in enumerate(rows):
        same=any(item.get(k) not in (None,'') and str(item[k])==str(row.get(k)) for k in ('id','ch_id','stream_id'))
        command=item.get('cmd') or item.get('command') or item.get('url')
        if same or (command and command==(row.get('cmd') or row.get('command') or row.get('url'))):
            return {'channels':rows,'page':page,'page_size':size,'total':total,
                    'absolute_index':(page-1)*size+index,'category_id':str(cid)}
    return None

def next_episode(client, item, cancel_event):
    if cancel_event.is_set():return None
    sid=item.get('_series_id') or item.get('series_id') or item.get('parent_id')
    if sid in (None,''):return None
    parent={'id':sid,'series_id':sid,'name':item.get('_series_title') or item.get('series_title') or ''}
    season=item.get('_season_number') or item.get('season_number') or item.get('season')
    seasons=client.series_seasons(parent,cancel_event=cancel_event) or []
    for row in seasons[:50]:
        if cancel_event.is_set():return None
        number=row.get('season_number') or row.get('season') or row.get('id')
        if season not in (None,'') and str(number)!=str(season):continue
        rows=client.series_episodes(parent,row,cancel_event=cancel_event) or []
        for index,current in enumerate(rows):
            same_id=any(item.get(key) not in (None,'') and str(item[key])==str(current.get(key)) for key in ('id','episode_id'))
            if not same_id:continue
            if index+1>=len(rows):return None
            following=dict(rows[index+1])
            following['_series_id']=sid
            following['_series_title']=parent['name']
            if item.get('_raw_series_title'):following['_raw_series_title']=item.get('_raw_series_title')
            for art_key in ('_player_poster','_adaptive_source_local','_ultra_palette_source','cover','screenshot_uri','poster'):
                if not following.get(art_key) and item.get(art_key):
                    following[art_key]=item.get(art_key)
            following['_season_number']=number
            following['_episode_number']=following.get('episode_number') or following.get('episode') or following.get('number') or index+2
            return following
    return None
