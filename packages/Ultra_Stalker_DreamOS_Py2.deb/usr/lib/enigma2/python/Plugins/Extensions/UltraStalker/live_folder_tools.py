# -*- coding: utf-8 -*-
"""Whole-folder Live tools for the Live screens (3 columns, logo wall, classic grid/list).

Before this, folder export (new Bouquet / M3U) lived only on the Categories page,
which the 3-column Live screen skips.  The three actions below work on the folder
that is currently open:

  * export it to the TV bouquet list as a NEW bouquet (same engine as the
    Categories page),
  * add ALL of its channels to an EXISTING receiver bouquet,
  * write it as an M3U file.

The screen needs: profile, genre, category_title, session, _run_async, _prepare_live_bouquet_row
and a ``["status"]`` widget; all Live screens and the Browser provide them.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str, int, min
import importlib
os = _us_env.os

from . import _
from .log import optional_failure

LFT_NEW = "lft_new_bouquet"
LFT_EXISTING = "lft_existing_bouquet"
LFT_M3U = "lft_m3u"
LFT_ACTIONS = (LFT_NEW, LFT_EXISTING, LFT_M3U)


def lft_menu_choices():
    """Menu rows (labels reuse strings that are already translated)."""
    return [
        (_("Export current Live folder to TV"), LFT_NEW),
        (_("Add current Live folder to a Bouquet"), LFT_EXISTING),
        (_("Export current category to M3U"), LFT_M3U),
    ]


class LiveFolderToolsMixin(object):
    @staticmethod
    def _m3u_epg_id(row):
        row = row if isinstance(row, dict) else {}
        return str(row.get("xmltv_id") or row.get("epg_id") or row.get("tvg_id") or row.get("channel_id") or "").strip()

    def _lft_b(self):
        try:
            from .ui import _load_screen_group
            _load_screen_group("browser")
        except Exception:
            pass
        return importlib.import_module(__package__ + ".ui_screens_browser")

    def _lft_category(self):
        b = self._lft_b()
        cid = str(getattr(self, "genre", "") or "*")
        name = b._clean_display_text(getattr(self, "category_title", "") or cid or _("LIVE"), 80)
        return cid, name

    def _lft_can_run(self):
        if bool(getattr(self, "_busy", False)) or bool(getattr(self, "_folder_export_active", False)):
            return False
        return str(getattr(self, "media_type", "") or "") == "itv"

    def _lft_dispatch(self, action):
        if action == LFT_NEW:
            return self.lft_export_new_bouquet()
        if action == LFT_EXISTING:
            return self.lft_add_to_existing_bouquet()
        if action == LFT_M3U:
            return self.lft_export_m3u()
        return None

    def _lft_status(self, text):
        try:
            self["status"].setText(text)
        except Exception:
            pass

    def _lft_fetch(self, isolated, handle, cid):
        b = self._lft_b()
        return b.call_compatible(
            isolated.ordered_all,
            ((("itv", cid), {"start_page": 1, "max_pages": 500, "max_items": 25000, "cancel_event": handle.cancel_event}),
             (("itv", cid, 1, 500, 25000, handle.cancel_event), {})),
        ) or []

    def _lft_progress_begin(self, label):
        from .export_progress import ExportProgress, start_poll
        progress = ExportProgress(label)
        self._lft_progress = progress
        self._lft_stop_poll = start_poll(self, progress)
        return progress

    def _lft_progress_end(self):
        stop = getattr(self, "_lft_stop_poll", None)
        self._lft_stop_poll = None
        if stop:
            try:
                stop()
            except Exception:
                pass

    def _lft_prepare(self, rows, handle):
        """Cached logos first, then fetch the missing ones in a small parallel batch."""
        b = self._lft_b()
        prepared = []
        for row in rows:
            if not isinstance(row, dict):
                continue
            if handle.cancelled():
                return []
            prepared.append(self._prepare_live_bouquet_row(row, False))
        missing = list(r for r in prepared if isinstance(r, dict) and not r.get("_receiver_picon_local"))
        if missing and not handle.cancelled():
            ThreadPoolExecutor = _us_env.concurrent_futures.ThreadPoolExecutor; as_completed = _us_env.concurrent_futures.as_completed

            def _fetch(row):
                if handle.cancelled():
                    return row
                try:
                    for key in ("stream_icon", "picon", "logo", "logo_url", "image", "img", "cover"):
                        value = row.get(key)
                        if not isinstance(value, str) or not value.strip():
                            continue
                        local = b._download_public_live_picon(value, self.profile, item=row, timeout=3.5)
                        if local and os.path.isfile(local):
                            row["_receiver_picon_local"] = local
                            row["_receiver_picon_source_local"] = local
                            return row
                except Exception:
                    pass
                return row

            batch = missing[:200]
            progress = getattr(self, "_lft_progress", None)
            if progress is not None:
                progress.set(_("Channel logos"), 0, len(batch))
            pool = ThreadPoolExecutor(max_workers=min(6, len(batch)))
            try:
                futures = list(pool.submit(_fetch, r) for r in batch)
                for future in as_completed(futures):
                    if handle.cancelled():
                        break
                    if progress is not None:
                        progress.tick()
                    try:
                        future.result()
                    except Exception:
                        pass
            finally:
                try:
                    pool.shutdown(wait=False, cancel_futures=True)
                except TypeError:
                    pool.shutdown(wait=False)
        return prepared

    # ------------------------------------------------------------ new bouquet
    def lft_export_new_bouquet(self):
        if not self._lft_can_run():
            return
        b = self._lft_b()
        cid, name = self._lft_category()
        cfg = b.load_settings()
        self._lft_progress_begin(_("Exporting Live folder: %s") % name)

        def work(handle):
            isolated = b._new_isolated_source_client(dict(self.profile or {}), timeout=cfg.get("timeout", 10))
            try:
                rows = self._lft_fetch(isolated, handle, cid)
                if handle.cancelled():
                    return {}
                prepared = self._lft_prepare(rows, handle)
                if handle.cancelled() or not prepared:
                    return {}
                return b.export_live_category_bouquet(self.profile, prepared, name, cid, cfg.get("service_type", 4097))
            finally:
                try:
                    isolated.close()
                except Exception:
                    pass

        def ok(result):
            self._lft_progress_end()
            self._folder_export_active = False
            b.reload_bouquets()
            try:
                from .core.bouquets import _queue_receiver_epg_seed
                _queue_receiver_epg_seed((result or {}).get("epg_seed") or [])
            except Exception as exc:
                optional_failure("ui.live_folder_epg_seed", exc)
            count = int((result or {}).get("channels") or 0)
            if count <= 0:
                # Empty folder / nothing prepared: never announce a successful export.
                self._lft_status(_("No playable items were found in this category"))
                return
            self._lft_status(_("Live folder exported • Channels: %d") % count)
            b.show_notice(self.session, _("Live folder exported to the TV bouquet list.\n\n%s\nChannels: %d") % (name, count), timeout=10, owner=self)

        def failed(exc):
            self._lft_progress_end()
            self._folder_export_active = False
            self._lft_status(_("Live folder export failed: %s") % exc)

        self._folder_export_active = True
        if not self._run_async(work, ok, failed):
            self._lft_progress_end()
            self._folder_export_active = False

    # --------------------------------------------------- existing bouquet
    def lft_add_to_existing_bouquet(self):
        if not self._lft_can_run():
            return
        b = self._lft_b()
        try:
            bouquets = b.list_tv_bouquets() or []
        except Exception as exc:
            self._lft_status(_("Could not read TV bouquets: %s") % exc)
            return
        if not bouquets:
            b.show_notice(self.session, _("No TV bouquets were found on the receiver."), timeout=7, owner=self)
            return
        try:
            from Screens.ChoiceBox import ChoiceBox
        except Exception:
            return
        choices = [(str(r.get("name") or r.get("filename")), str(r.get("filename"))) for r in bouquets]
        self.session.openWithCallback(self._lft_bouquet_chosen, ChoiceBox, title=_("Choose target Bouquet"), list=choices)

    def _lft_bouquet_chosen(self, choice):
        if not choice or not self._lft_can_run():
            return
        b = self._lft_b()
        filename = str(choice[1] if isinstance(choice, (tuple, list)) and len(choice) > 1 else "")
        label = str(choice[0] if isinstance(choice, (tuple, list)) and choice else filename)
        if not filename:
            return
        cid, name = self._lft_category()
        cfg = b.load_settings()
        self._lft_progress_begin(_("Adding to %s") % label)

        def work(handle):
            isolated = b._new_isolated_source_client(dict(self.profile or {}), timeout=cfg.get("timeout", 10))
            try:
                rows = self._lft_fetch(isolated, handle, cid)
                if handle.cancelled():
                    return {}
                prepared = self._lft_prepare(rows, handle)
                if handle.cancelled() or not prepared:
                    return {}
                return b.append_receiver_items_to_bouquet(self.profile, prepared, "itv", filename, cfg.get("service_type", 4097))
            finally:
                try:
                    isolated.close()
                except Exception:
                    pass

        def ok(result):
            self._lft_progress_end()
            self._folder_export_active = False
            b.reload_bouquets()
            try:
                from .core.bouquets import _queue_receiver_epg_seed
                _queue_receiver_epg_seed((result or {}).get("epg_seed") or [])
            except Exception as exc:
                optional_failure("ui.live_folder_existing_epg_seed", exc)
            added = int((result or {}).get("added") or 0)
            self._lft_status(_("Bouquet updated • New channels: %d") % added)
            b.show_notice(self.session, _("Added to Bouquet: %s\n\nNew channels: %d") % (label, added), timeout=7, owner=self)

        def failed(exc):
            self._lft_progress_end()
            self._folder_export_active = False
            self._lft_status(_("Bouquet update failed: %s") % exc)

        self._folder_export_active = True
        if not self._run_async(work, ok, failed):
            self._lft_progress_end()
            self._folder_export_active = False

    # ------------------------------------------------------------------ M3U
    def lft_export_m3u(self):
        if not self._lft_can_run():
            return
        b = self._lft_b()
        cid, name = self._lft_category()
        cfg = b.load_settings()
        self._lft_status(_("Exporting M3U: %s") % name)
        browser_cls = getattr(b, "PortalBrowserScreen")

        def work(handle):
            isolated = b._new_isolated_source_client(dict(self.profile or {}), timeout=min(8, int(cfg.get("timeout", 10) or 10)))
            try:
                items = self._lft_fetch(isolated, handle, cid)
                if handle.cancelled():
                    return {}
                entries = []
                for item in items:
                    if handle.cancelled():
                        break
                    if not isinstance(item, dict):
                        continue
                    entry = browser_cls._m3u_export_entry(self, isolated, item, "itv", name, cancel_event=handle.cancel_event)
                    if entry:
                        entries.append(entry)
                if handle.cancelled():
                    return {}
                if not entries:
                    raise RuntimeError(_("No playable items were found in this category"))
                root = browser_cls._m3u_export_root()
                filename = b.safe_m3u_filename("%s - %s" % ("Live", name)) + ".m3u"
                path = os.path.join(root, filename)
                count = b.write_m3u(path, entries, name)
                if count <= 0:
                    raise RuntimeError(_("No playable items were written"))
                return {"path": path, "items": count}
            finally:
                try:
                    isolated.close()
                except Exception:
                    pass

        def ok(result):
            self._folder_export_active = False
            path = str((result or {}).get("path") or "")
            count = int((result or {}).get("items") or 0)
            if not path:
                return
            self._lft_status(_("M3U exported • Items: %d") % count)
            b.show_notice(self.session, _("M3U export completed.\n\n%s\nItems: %d") % (path, count), timeout=10, owner=self)

        def failed(exc):
            self._folder_export_active = False
            self._lft_status(_("M3U export failed: %s") % exc)

        # Same re-entrancy guard as the bouquet exports: a second press while the
        # first export is still running must not start a parallel full-folder walk.
        self._folder_export_active = True
        if not self._run_async(work, ok, failed):
            self._folder_export_active = False
