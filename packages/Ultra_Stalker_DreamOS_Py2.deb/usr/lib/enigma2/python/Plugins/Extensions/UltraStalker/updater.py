# -*- coding: utf-8 -*-
"""Ultra Stalker safe online updater.

Manifest schema (JSON):
{
  "version": "9.3",
  "name": "Ultra Stalker V9.3",
  "ipk": "https://github.com/K3bOra/UltraStalker/releases/download/v9.3/Ultra_Stalker_Final.ipk",
  "sha256": "<64 hex>",
  "notes": "Bug fixes and performance improvements",
  "notes_i18n": {"ar": "...", "el": "..."}
}

The official manifest URL may be compiled into DEFAULT_MANIFEST_URL for public
releases. During staging it can be supplied in api_keys.conf as:
UPDATE_MANIFEST_URL=https://raw.githubusercontent.com/.../update.json
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str, bytes, int, open, max, min, OSError, us_func

hashlib = _us_env.hashlib
json = _us_env.json
os = _us_env.os
re = _us_env.re
import subprocess
threading = _us_env.threading
time = _us_env.time

try:
    Request = _us_env.urllib_request.Request; urlopen = _us_env.urllib_request.urlopen
except Exception:  # pragma: no cover - diagnosed by preflight
    Request = None
    urlopen = None

from .version import PLUGIN_VERSION, PLUGIN_REVISION
from . import _
from .localization import current_language
from .wqhd_layout import scale_skin as _update_scale_skin, font_size as _update_font_size

# Release-driven model (same approach as Ultra Audio): the manifest is read from
# the latest published GitHub release, and an update IPK is accepted as long as it
# is an official Ultra Stalker release asset in the official repository.
OFFICIAL_UPDATE_REPO = "https://github.com/K3bOra/UltraStalker"
DEFAULT_MANIFEST_URL = "https://github.com/K3bOra/UltraStalker/releases/latest/download/update.json"
DREAMOS_MANIFEST_URL = "https://github.com/K3bOra/UltraStalker/releases/latest/download/update-dreamos-py2.json"
APPROVED_IPK_RE = re.compile(
    r"^https://github\.com/K3bOra/UltraStalker/releases/download/[^/]+/Ultra_?Stalker[-_A-Za-z0-9.]*\.ipk$",
    re.I,
)


def _is_approved_ipk(url):
    extension = "deb" if _us_env.IS_DREAMOS else "ipk"
    pattern = r"^https://github\.com/K3bOra/UltraStalker/releases/download/[^/]+/Ultra_?Stalker[-_A-Za-z0-9.]*\." + extension + r"$"
    return bool(re.match(pattern, str(url or ""), re.I))
TMP_IPK = "/tmp/UltraStalker_online_update.deb" if _us_env.IS_DREAMOS else "/tmp/UltraStalker_online_update.ipk"
MAX_MANIFEST_BYTES = 128 * 1024
MAX_IPK_BYTES = 64 * 1024 * 1024

V913_RELEASE_NOTES = '• Player New and Player New 2: new glass info bars for Live, Movies and Series (Settings › Media › Player View) with a Sub/Audio line, real picture size and a clearer buffer line\n• Next Episode card with countdown, Play now and Autoplay off\n• Episode names and runtimes in the Series list and Player, filled from TMDB\n• Info Bar Timeout setting, from 3 seconds to Always On\n• Export a Live, Movies or Series folder, or add it to a Bouquet, with a progress bar\n• Hidden categories stay hidden everywhere; the All row is kept\n• Home: press BLUE for quick settings\n• Premium web cards for Movies, Series, Live, Local and Search, with glowing Details pages\n• Arabic description: the longest Arabic text from Portal, Xtream or TMDB comes first\n• Web Browse keeps loading after a failed page; web navigation and download fixes'
V913_RELEASE_NOTES_I18N = {'en': '• Player New and Player New 2: new glass info bars for Live, Movies and Series (Settings › Media › Player View) with a Sub/Audio line, real picture size and a clearer buffer line\n• Next Episode card with countdown, Play now and Autoplay off\n• Episode names and runtimes in the Series list and Player, filled from TMDB\n• Info Bar Timeout setting, from 3 seconds to Always On\n• Export a Live, Movies or Series folder, or add it to a Bouquet, with a progress bar\n• Hidden categories stay hidden everywhere; the All row is kept\n• Home: press BLUE for quick settings\n• Premium web cards for Movies, Series, Live, Local and Search, with glowing Details pages\n• Arabic description: the longest Arabic text from Portal, Xtream or TMDB comes first\n• Web Browse keeps loading after a failed page; web navigation and download fixes', 'ar': '• Player New وPlayer New 2: أشرطة معلومات زجاجية جديدة للبث المباشر والأفلام والمسلسلات (الإعدادات › الوسائط › عرض المشغل) مع سطر لغة الترجمة والصوت وحجم الصورة الحقيقي وخط بافر أوضح\n• كارت الحلقة التالية مع عد تنازلي وتشغيل الآن وإيقاف التشغيل التلقائي\n• أسماء الحلقات ومدتها في قائمة المسلسلات والمشغل، تُكمَّل من TMDB\n• إعداد مهلة شريط المعلومات من 3 ثوانٍ إلى دائم\n• تصدير فولدر لايف أو أفلام أو مسلسلات أو إضافته إلى باقة مع شريط تقدم\n• الفئات المخفية تبقى مخفية في كل مكان مع الاحتفاظ بصف All\n• الرئيسية: زر الأزرق للإعدادات السريعة\n• كروت ويب فاخرة للأفلام والمسلسلات واللايف واللوكال والبحث مع صفحات تفاصيل متوهجة\n• الوصف العربي: أطول وصف عربي من البورتال أو الإكستريم أو TMDB يظهر أولاً\n• تصفح الويب يكمل التحميل بعد أي صفحة فاشلة، مع إصلاحات التنقل والتنزيل في الويب', 'de': '• Player New und Player New 2: neue Glas-Infoleisten für Live, Filme und Serien (Einstellungen › Medien › Player-Ansicht) mit Untertitel-/Audiozeile, echter Bildgröße und deutlicherer Pufferlinie\n• Karte „Nächste Folge“ mit Countdown, Jetzt abspielen und Autoplay aus\n• Folgennamen und Laufzeiten in der Serienliste und im Player, ergänzt aus TMDB\n• Einstellung Infoleisten-Dauer: von 3 Sekunden bis Immer an\n• Live-, Film- oder Serienordner exportieren oder zu einem Bouquet hinzufügen, mit Fortschrittsbalken\n• Ausgeblendete Kategorien bleiben überall ausgeblendet; die Zeile „Alle“ bleibt erhalten\n• Startseite: BLAU-Taste für Schnelleinstellungen\n• Premium-Webkarten für Filme, Serien, Live, Lokal und Suche mit leuchtenden Detailseiten\n• Arabische Beschreibung: Der längste arabische Text von Portal, Xtream oder TMDB steht zuerst\n• Web-Browsen lädt nach einer fehlgeschlagenen Seite weiter; Korrekturen bei Web-Navigation und Downloads', 'fr': "• Player New et Player New 2 : nouvelles barres d'infos en verre pour Live, Films et Séries (Réglages › Médias › Vue du lecteur) avec ligne Sous-titres/Audio, taille réelle de l'image et ligne de tampon plus claire\n• Carte « Épisode suivant » avec compte à rebours, Lire maintenant et Lecture auto désactivée\n• Noms et durées des épisodes dans la liste des séries et le lecteur, complétés depuis TMDB\n• Réglage de la durée de la barre d'infos : de 3 secondes à Toujours affichée\n• Exporter un dossier Live, Films ou Séries, ou l'ajouter à un bouquet, avec barre de progression\n• Les catégories masquées restent masquées partout ; la ligne Tout est conservée\n• Accueil : touche BLEUE pour les réglages rapides\n• Cartes web premium pour Films, Séries, Live, Local et Recherche, avec pages de détails lumineuses\n• Description arabe : le texte arabe le plus long du Portal, de Xtream ou de TMDB passe en premier\n• La navigation web continue de charger après une page en échec ; correctifs de navigation et de téléchargement web", 'tr': "• Player New ve Player New 2: Canlı, Filmler ve Diziler için yeni cam bilgi çubukları (Ayarlar › Medya › Oynatıcı Görünümü); Altyazı/Ses satırı, gerçek görüntü boyutu ve daha net tampon çizgisi\n• Geri sayımlı Sonraki Bölüm kartı, Şimdi oynat ve Otomatik oynatmayı kapat\n• Dizi listesinde ve oynatıcıda bölüm adları ile süreleri, TMDB'den tamamlanır\n• Bilgi çubuğu süresi ayarı: 3 saniyeden Her Zaman Açık'a\n• Canlı, Film veya Dizi klasörünü dışa aktarın ya da bir buketeye ekleyin, ilerleme çubuğuyla\n• Gizlenen kategoriler her yerde gizli kalır; Tümü satırı korunur\n• Ana sayfa: hızlı ayarlar için MAVİ tuş\n• Filmler, Diziler, Canlı, Yerel ve Arama için premium web kartları ve parlayan Ayrıntı sayfaları\n• Arapça açıklama: Portal, Xtream veya TMDB'den en uzun Arapça metin önce gösterilir\n• Web Gezinme, başarısız bir sayfadan sonra yüklemeye devam eder; web gezinme ve indirme düzeltmeleri", 'es': '• Player New y Player New 2: nuevas barras de información de cristal para Live, Películas y Series (Ajustes › Medios › Vista del reproductor) con línea de subtítulos/audio, tamaño real de imagen y línea de búfer más clara\n• Tarjeta de Siguiente episodio con cuenta atrás, Reproducir ahora y Desactivar reproducción automática\n• Nombres y duraciones de episodios en la lista de series y el reproductor, completados desde TMDB\n• Ajuste de duración de la barra de información: de 3 segundos a Siempre visible\n• Exporta una carpeta de Live, Películas o Series, o añádela a un Bouquet, con barra de progreso\n• Las categorías ocultas siguen ocultas en todas partes; se mantiene la fila Todo\n• Inicio: tecla AZUL para ajustes rápidos\n• Tarjetas web premium para Películas, Series, Live, Local y Búsqueda, con páginas de detalles luminosas\n• Descripción en árabe: primero el texto árabe más largo de Portal, Xtream o TMDB\n• La navegación web sigue cargando tras una página fallida; correcciones de navegación y descargas web', 'it': "• Player New e Player New 2: nuove barre informative in vetro per Live, Film e Serie (Impostazioni › Media › Vista Player) con riga Sottotitoli/Audio, dimensione reale dell'immagine e linea del buffer più chiara\n• Scheda Episodio successivo con conto alla rovescia, Riproduci ora e Riproduzione automatica off\n• Nomi e durate degli episodi nell'elenco Serie e nel Player, completati da TMDB\n• Impostazione della durata della barra info: da 3 secondi a Sempre attiva\n• Esporta una cartella Live, Film o Serie, o aggiungila a un Bouquet, con barra di avanzamento\n• Le categorie nascoste restano nascoste ovunque; la riga Tutti viene mantenuta\n• Home: tasto BLU per le impostazioni rapide\n• Schede web premium per Film, Serie, Live, Locale e Ricerca, con pagine di dettaglio luminose\n• Descrizione in arabo: il testo arabo più lungo da Portal, Xtream o TMDB viene mostrato per primo\n• La navigazione web continua a caricare dopo una pagina fallita; correzioni di navigazione e download web", 'pt': '• Player New e Player New 2: novas barras de informação em vidro para Live, Filmes e Séries (Definições › Multimédia › Vista do Player) com linha de Legenda/Áudio, tamanho real da imagem e linha de buffer mais clara\n• Cartão Próximo Episódio com contagem decrescente, Reproduzir agora e Desativar reprodução automática\n• Nomes e durações dos episódios na lista de Séries e no Player, completados pelo TMDB\n• Definição do tempo da barra de informação: de 3 segundos a Sempre ligada\n• Exporte uma pasta de Live, Filmes ou Séries, ou adicione-a a um Bouquet, com barra de progresso\n• As categorias ocultas continuam ocultas em todo o lado; a linha Todos é mantida\n• Início: tecla AZUL para definições rápidas\n• Cartões web premium para Filmes, Séries, Live, Local e Pesquisa, com páginas de detalhes luminosas\n• Descrição em árabe: o texto árabe mais longo do Portal, Xtream ou TMDB aparece primeiro\n• A navegação web continua a carregar após uma página falhada; correções de navegação e transferências na web', 'pt-br': '• Player New e Player New 2: novas barras de informação em vidro para Live, Filmes e Séries (Configurações › Mídia › Visualização do Player) com linha de Legenda/Áudio, tamanho real da imagem e linha de buffer mais clara\n• Cartão Próximo Episódio com contagem regressiva, Reproduzir agora e Desativar reprodução automática\n• Nomes e durações dos episódios na lista de Séries e no Player, completados pelo TMDB\n• Ajuste do tempo da barra de informações: de 3 segundos a Sempre ligada\n• Exporte uma pasta de Live, Filmes ou Séries, ou adicione-a a um Bouquet, com barra de progresso\n• Categorias ocultas continuam ocultas em todo lugar; a linha Todos é mantida\n• Início: tecla AZUL para ajustes rápidos\n• Cartões web premium para Filmes, Séries, Live, Local e Busca, com páginas de detalhes luminosas\n• Descrição em árabe: o texto árabe mais longo do Portal, Xtream ou TMDB aparece primeiro\n• A navegação web continua carregando após uma página com falha; correções de navegação e download na web', 'nl': "• Player New en Player New 2: nieuwe glazen infobalken voor Live, Films en Series (Instellingen › Media › Playerweergave) met ondertitel-/audioregel, echte beeldgrootte en een duidelijkere bufferlijn\n• Kaart Volgende aflevering met aftelling, Nu afspelen en Automatisch afspelen uit\n• Afleveringsnamen en speelduur in de serielijst en de Player, aangevuld vanuit TMDB\n• Instelling voor duur van de infobalk: van 3 seconden tot Altijd aan\n• Exporteer een map met Live, Films of Series, of voeg die toe aan een Bouquet, met voortgangsbalk\n• Verborgen categorieën blijven overal verborgen; de rij Alles blijft behouden\n• Start: BLAUWE toets voor snelle instellingen\n• Premium webkaarten voor Films, Series, Live, Lokaal en Zoeken, met gloeiende detailpagina's\n• Arabische beschrijving: de langste Arabische tekst van Portal, Xtream of TMDB komt eerst\n• Web Browse blijft laden na een mislukte pagina; verbeteringen voor webnavigatie en downloads", 'pl': '• Player New i Player New 2: nowe szklane paski informacji dla Live, Filmów i Seriali (Ustawienia › Media › Widok odtwarzacza) z linią napisów/audio, rzeczywistym rozmiarem obrazu i wyraźniejszą linią bufora\n• Karta Następny odcinek z odliczaniem, Odtwórz teraz i Wyłącz autoodtwarzanie\n• Nazwy i czas trwania odcinków na liście seriali i w odtwarzaczu, uzupełniane z TMDB\n• Ustawienie czasu paska informacji: od 3 sekund do Zawsze włączony\n• Eksport folderu Live, Filmów lub Seriali albo dodanie go do Bouquetu, z paskiem postępu\n• Ukryte kategorie pozostają ukryte wszędzie; wiersz Wszystkie zostaje\n• Ekran główny: przycisk NIEBIESKI dla szybkich ustawień\n• Premium karty webowe dla Filmów, Seriali, Live, Lokalnych i Wyszukiwania ze świecącymi stronami szczegółów\n• Opis arabski: najdłuższy arabski tekst z Portal, Xtream lub TMDB wyświetlany jest jako pierwszy\n• Przeglądanie w sieci dalej ładuje po nieudanej stronie; poprawki nawigacji i pobierania w sieci', 'ru': '• Player New и Player New 2: новые стеклянные инфо-панели для Live, фильмов и сериалов (Настройки › Медиа › Вид плеера) со строкой субтитров/аудио, реальным размером картинки и более чёткой линией буфера\n• Карточка «Следующая серия» с обратным отсчётом, «Смотреть сейчас» и «Выключить автовоспроизведение»\n• Названия и длительность серий в списке сериалов и в плеере, дополняются из TMDB\n• Настройка времени показа инфо-панели: от 3 секунд до «Всегда включена»\n• Экспорт папки Live, фильмов или сериалов либо добавление её в букет, с индикатором прогресса\n• Скрытые категории остаются скрытыми везде; строка «Все» сохраняется\n• Главный экран: СИНЯЯ кнопка для быстрых настроек\n• Премиальные веб-карточки для фильмов, сериалов, Live, Local и поиска со светящимися страницами описания\n• Арабское описание: сначала самый длинный арабский текст из Portal, Xtream или TMDB\n• Веб-просмотр продолжает загрузку после неудачной страницы; исправления веб-навигации и загрузок', 'el': '• Player New και Player New 2: νέες γυάλινες μπάρες πληροφοριών για Live, Ταινίες και Σειρές (Ρυθμίσεις › Πολυμέσα › Προβολή Player) με γραμμή υποτίτλων/ήχου, πραγματικό μέγεθος εικόνας και πιο ευδιάκριτη γραμμή buffer\n• Κάρτα Επόμενου επεισοδίου με αντίστροφη μέτρηση, Αναπαραγωγή τώρα και Απενεργοποίηση αυτόματης αναπαραγωγής\n• Ονόματα και διάρκειες επεισοδίων στη λίστα σειρών και στο Player, συμπληρωμένα από το TMDB\n• Ρύθμιση διάρκειας μπάρας πληροφοριών: από 3 δευτερόλεπτα έως Πάντα ενεργή\n• Εξαγωγή φακέλου Live, Ταινιών ή Σειρών ή προσθήκη σε Bouquet, με μπάρα προόδου\n• Οι κρυφές κατηγορίες παραμένουν κρυφές παντού· η γραμμή Όλα διατηρείται\n• Αρχική: ΜΠΛΕ πλήκτρο για γρήγορες ρυθμίσεις\n• Premium κάρτες web για Ταινίες, Σειρές, Live, Τοπικά και Αναζήτηση, με φωτεινές σελίδες λεπτομερειών\n• Αραβική περιγραφή: το μεγαλύτερο αραβικό κείμενο από Portal, Xtream ή TMDB εμφανίζεται πρώτο\n• Η περιήγηση web συνεχίζει τη φόρτωση μετά από αποτυχημένη σελίδα· διορθώσεις πλοήγησης και λήψεων web', 'cs': '• Player New a Player New 2: nové skleněné informační lišty pro Live, Filmy a Seriály (Nastavení › Média › Zobrazení přehrávače) s řádkem titulků/zvuku, skutečnou velikostí obrazu a výraznější čarou bufferu\n• Karta Další epizoda s odpočtem, Přehrát nyní a Vypnout automatické přehrávání\n• Názvy a délky epizod v seznamu seriálů a v přehrávači, doplněné z TMDB\n• Nastavení doby zobrazení informační lišty: od 3 sekund po Vždy zapnuto\n• Export složky Live, Filmů nebo Seriálů či přidání do Bouquetu s ukazatelem průběhu\n• Skryté kategorie zůstávají skryté všude; řádek Vše se zachová\n• Domů: MODRÉ tlačítko pro rychlá nastavení\n• Prémiové webové karty pro Filmy, Seriály, Live, Místní a Hledání se zářícími stránkami podrobností\n• Arabský popis: jako první se zobrazí nejdelší arabský text z Portal, Xtream nebo TMDB\n• Webové procházení pokračuje v načítání po neúspěšné stránce; opravy webové navigace a stahování', 'sk': '• Player New a Player New 2: nové sklenené informačné lišty pre Live, Filmy a Seriály (Nastavenia › Médiá › Zobrazenie prehrávača) s riadkom titulkov/zvuku, skutočnou veľkosťou obrazu a výraznejšou čiarou bufferu\n• Karta Ďalšia epizóda s odpočtom, Prehrať teraz a Vypnúť automatické prehrávanie\n• Názvy a dĺžky epizód v zozname seriálov a v prehrávači, doplnené z TMDB\n• Nastavenie doby zobrazenia informačnej lišty: od 3 sekúnd po Vždy zapnuté\n• Export priečinka Live, Filmov alebo Seriálov alebo pridanie do Bouquetu s ukazovateľom priebehu\n• Skryté kategórie zostávajú skryté všade; riadok Všetko sa zachová\n• Domov: MODRÉ tlačidlo pre rýchle nastavenia\n• Prémiové webové karty pre Filmy, Seriály, Live, Miestne a Hľadanie so žiariacimi stránkami podrobností\n• Arabský popis: ako prvý sa zobrazí najdlhší arabský text z Portal, Xtream alebo TMDB\n• Webové prehliadanie pokračuje v načítaní po neúspešnej stránke; opravy webovej navigácie a sťahovania', 'hu': '• Player New és Player New 2: új üveghatású információs sávok Élő, Filmek és Sorozatok nézethez (Beállítások › Média › Lejátszó nézet) felirat/hang sorral, valós képmérettel és jobban látható pufferpróbával\n• Következő epizód kártya visszaszámlálással, Lejátszás most és Automatikus lejátszás kikapcsolása\n• Epizódnevek és játékidők a sorozatlistában és a lejátszóban, a TMDB-ből kiegészítve\n• Információs sáv időtartamának beállítása: 3 másodperctől Mindig bekapcsolva értékig\n• Live, Filmek vagy Sorozatok mappa exportálása vagy Bouquethez adása folyamatjelzővel\n• A rejtett kategóriák mindenhol rejtve maradnak; a Mind sor megmarad\n• Főoldal: KÉK gomb a gyorsbeállításokhoz\n• Prémium webkártyák Filmekhez, Sorozatokhoz, Élőhöz, Helyihez és Kereséshez, ragyogó részletes oldalakkal\n• Arab leírás: a Portal, Xtream vagy TMDB leghosszabb arab szövege jelenik meg először\n• A webes böngészés egy sikertelen oldal után is tovább tölt; webes navigációs és letöltési javítások', 'ro': '• Player New și Player New 2: bare de informații noi din sticlă pentru Live, Filme și Seriale (Setări › Media › Vizualizare Player) cu linie de subtitrare/audio, dimensiunea reală a imaginii și linie de buffer mai clară\n• Cardul Episodul următor cu numărătoare inversă, Redă acum și Oprește redarea automată\n• Numele și durata episoadelor în lista de seriale și în Player, completate din TMDB\n• Setarea duratei barei de informații: de la 3 secunde la Mereu pornită\n• Exportă un folder Live, Filme sau Seriale ori adaugă-l la un Bouquet, cu bară de progres\n• Categoriile ascunse rămân ascunse peste tot; rândul Toate este păstrat\n• Acasă: tasta ALBASTRĂ pentru setări rapide\n• Carduri web premium pentru Filme, Seriale, Live, Local și Căutare, cu pagini de detalii luminoase\n• Descriere în arabă: cel mai lung text arab din Portal, Xtream sau TMDB apare primul\n• Navigarea web continuă încărcarea după o pagină eșuată; corecții pentru navigarea și descărcările web', 'sr': '• Player New и Player New 2: нове стаклене инфо траке за Live, филмове и серије (Подешавања › Медији › Приказ плејера) са линијом титлова/звука, стварном величином слике и јаснијом линијом бафера\n• Картица Следећа епизода са одбројавањем, Пусти одмах и Искључи аутоматску репродукцију\n• Називи и трајање епизода у листи серија и у плејеру, допуњени из TMDB-а\n• Подешавање трајања инфо траке: од 3 секунде до Увек укључена\n• Извезите Live, филмове или серије фолдер или га додајте у Bouquet, уз траку напретка\n• Сакривене категорије остају сакривене свуда; ред Све се задржава\n• Почетна: ПЛАВО дугме за брза подешавања\n• Премијум веб картице за филмове, серије, Live, локално и претрагу са светлећим страницама детаља\n• Арапски опис: најдужи арапски текст из Portal-а, Xtream-а или TMDB-а приказује се први\n• Веб преглед наставља учитавање после неуспеле странице; исправке веб навигације и преузимања', 'hr': '• Player New i Player New 2: nove staklene info trake za Live, Filmove i Serije (Postavke › Mediji › Prikaz playera) s retkom titlova/zvuka, stvarnom veličinom slike i jasnijom linijom međuspremnika\n• Kartica Sljedeća epizoda s odbrojavanjem, Reproduciraj sada i Isključi automatsku reprodukciju\n• Nazivi i trajanje epizoda u popisu serija i u playeru, nadopunjeni iz TMDB-a\n• Postavka trajanja info trake: od 3 sekunde do Uvijek uključena\n• Izvezite Live, Filmove ili Serije mapu ili je dodajte u Bouquet, uz traku napretka\n• Skrivene kategorije ostaju skrivene posvuda; redak Sve ostaje\n• Početna: PLAVA tipka za brze postavke\n• Premium web kartice za Filmove, Serije, Live, Lokalno i Pretraživanje sa sjajnim stranicama detalja\n• Arapski opis: najdulji arapski tekst iz Portala, Xtreama ili TMDB-a prikazuje se prvi\n• Web pregled nastavlja učitavati nakon neuspjele stranice; ispravci web navigacije i preuzimanja', 'bg': '• Player New и Player New 2: нови стъклени информационни ленти за Live, Филми и Сериали (Настройки › Медия › Изглед на плейъра) с ред за субтитри/аудио, реален размер на картината и по-ясна линия на буфера\n• Карта „Следващ епизод“ с обратно броене, Пусни сега и Изключи автоматичното пускане\n• Имена и продължителност на епизодите в списъка със сериали и в плейъра, допълвани от TMDB\n• Настройка за времето на информационната лента: от 3 секунди до Винаги включена\n• Експортирайте папка Live, Филми или Сериали или я добавете към Bouquet, с лента за напредъка\n• Скритите категории остават скрити навсякъде; редът „Всички“ се запазва\n• Начало: СИНИЯТ бутон за бързи настройки\n• Премиум уеб карти за Филми, Сериали, Live, Local и Търсене със светещи страници с подробности\n• Арабско описание: първо се показва най-дългият арабски текст от Portal, Xtream или TMDB\n• Уеб прегледът продължава да зарежда след неуспешна страница; корекции на уеб навигацията и изтеглянията', 'uk': '• Player New і Player New 2: нові скляні інфопанелі для Live, фільмів і серіалів (Налаштування › Медіа › Вигляд плеєра) із рядком субтитрів/аудіо, реальним розміром зображення та чіткішою лінією буфера\n• Картка «Наступна серія» зі зворотним відліком, «Дивитися зараз» і «Вимкнути автовідтворення»\n• Назви й тривалість серій у списку серіалів і в плеєрі, доповнюються з TMDB\n• Налаштування часу показу інфопанелі: від 3 секунд до «Завжди ввімкнено»\n• Експорт папки Live, фільмів чи серіалів або додавання її до букета, з індикатором прогресу\n• Приховані категорії залишаються прихованими всюди; рядок «Усі» зберігається\n• Головна: СИНЯ кнопка для швидких налаштувань\n• Преміальні веб-картки для фільмів, серіалів, Live, Local і пошуку зі світними сторінками деталей\n• Арабський опис: першим показується найдовший арабський текст із Portal, Xtream або TMDB\n• Веб-перегляд продовжує завантаження після невдалої сторінки; виправлення веб-навігації та завантажень', 'sv': '• Player New och Player New 2: nya glasinfofält för Live, Filmer och Serier (Inställningar › Media › Spelarvy) med rad för undertext/ljud, verklig bildstorlek och tydligare bufferlinje\n• Kort för Nästa avsnitt med nedräkning, Spela nu och Stäng av automatisk uppspelning\n• Avsnittsnamn och speltider i serielistan och spelaren, kompletterade från TMDB\n• Inställning för infofältets visningstid: från 3 sekunder till Alltid på\n• Exportera en Live-, Film- eller Serie-mapp eller lägg till den i ett Bouquet, med förloppsindikator\n• Dolda kategorier förblir dolda överallt; raden Alla behålls\n• Startsida: BLÅ knapp för snabbinställningar\n• Premium-webbkort för Filmer, Serier, Live, Lokalt och Sök, med glödande detaljsidor\n• Arabisk beskrivning: den längsta arabiska texten från Portal, Xtream eller TMDB visas först\n• Webbläsning fortsätter ladda efter en misslyckad sida; korrigeringar för webbnavigering och nedladdning', 'no': '• Player New og Player New 2: nye glassinfolinjer for Live, Filmer og Serier (Innstillinger › Media › Spillervisning) med linje for undertekst/lyd, faktisk bildestørrelse og tydeligere bufferlinje\n• Kort for Neste episode med nedtelling, Spill nå og Slå av automatisk avspilling\n• Episodenavn og spilletider i serielisten og spilleren, supplert fra TMDB\n• Innstilling for infolinjens visningstid: fra 3 sekunder til Alltid på\n• Eksporter en Live-, Film- eller Serie-mappe eller legg den til i et Bouquet, med fremdriftslinje\n• Skjulte kategorier forblir skjulte overalt; raden Alle beholdes\n• Startside: BLÅ knapp for hurtiginnstillinger\n• Premium-nettkort for Filmer, Serier, Live, Lokalt og Søk, med glødende detaljsider\n• Arabisk beskrivelse: den lengste arabiske teksten fra Portal, Xtream eller TMDB vises først\n• Nettsurfing fortsetter å laste etter en mislykket side; rettelser for webnavigasjon og nedlastinger', 'da': '• Player New og Player New 2: nye glasinfobjælker til Live, Film og Serier (Indstillinger › Medier › Afspillervisning) med linje for undertekst/lyd, den reelle billedstørrelse og en tydeligere bufferlinje\n• Kort for Næste afsnit med nedtælling, Afspil nu og Slå automatisk afspilning fra\n• Afsnitsnavne og spilletider i serielisten og afspilleren, suppleret fra TMDB\n• Indstilling af infobjælkens visningstid: fra 3 sekunder til Altid tændt\n• Eksportér en Live-, Film- eller Serie-mappe eller føj den til et Bouquet, med statuslinje\n• Skjulte kategorier forbliver skjulte overalt; rækken Alle bevares\n• Startskærm: BLÅ knap til hurtige indstillinger\n• Premium-webkort til Film, Serier, Live, Lokalt og Søg med glødende detaljesider\n• Arabisk beskrivelse: den længste arabiske tekst fra Portal, Xtream eller TMDB vises først\n• Webbrowsing bliver ved med at indlæse efter en mislykket side; rettelser til webnavigation og downloads', 'fi': '• Player New ja Player New 2: uudet lasiset tietopalkit Live-, Elokuva- ja Sarjanäkymiin (Asetukset › Media › Soittimen näkymä) tekstitys-/äänirivillä, todellisella kuvakoolla ja selkeämmällä puskurilinjalla\n• Seuraava jakso -kortti lähtölaskennalla, Toista nyt ja Poista automaattinen toisto\n• Jaksojen nimet ja kestot sarjaluettelossa ja soittimessa, täydennettynä TMDB:stä\n• Tietopalkin näyttöajan asetus: 3 sekunnista Aina päällä -tilaan\n• Vie Live-, Elokuva- tai Sarjakansio tai lisää se Bouquetiin edistymispalkin kanssa\n• Piilotetut kategoriat pysyvät piilossa kaikkialla; Kaikki-rivi säilyy\n• Koti: SININEN näppäin pika-asetuksiin\n• Premium-verkkokortit Elokuville, Sarjoille, Livelle, Paikalliselle ja Haulle hehkuvilla tietosivuilla\n• Arabialainen kuvaus: pisin arabiankielinen teksti Portalista, Xtreamista tai TMDB:stä näytetään ensin\n• Verkkoselaus jatkaa latausta epäonnistuneen sivun jälkeen; verkkonavigoinnin ja latausten korjauksia', 'zh-cn': '• Player New 和 Player New 2：适用于直播、电影和剧集的全新玻璃质感信息栏（设置 › 媒体 › 播放器视图），带字幕/音频行、真实画面尺寸和更清晰的缓冲线\n• 下一集卡片，带倒计时、立即播放和关闭自动播放\n• 剧集列表和播放器中显示剧集名称和时长，由 TMDB 补全\n• 信息栏显示时间设置：从 3 秒到常开\n• 导出直播、电影或剧集文件夹，或将其添加到 Bouquet，并显示进度条\n• 隐藏的分类在所有位置保持隐藏；保留“全部”行\n• 主页：按蓝色键进入快速设置\n• 电影、剧集、直播、本地和搜索的高级网页卡片，详情页带发光效果\n• 阿拉伯语简介：优先显示 Portal、Xtream 或 TMDB 中最长的阿拉伯语文本\n• 网页浏览在页面加载失败后继续加载；修复网页导航和下载问题', 'zh-tw': '• Player New 與 Player New 2：適用於直播、電影和影集的全新玻璃質感資訊列（設定 › 媒體 › 播放器檢視），含字幕/音訊列、真實畫面尺寸和更清楚的緩衝線\n• 下一集卡片，附倒數計時、立即播放和關閉自動播放\n• 影集清單與播放器顯示集名和片長，由 TMDB 補齊\n• 資訊列顯示時間設定：從 3 秒到常開\n• 匯出直播、電影或影集資料夾，或將其加入 Bouquet，並顯示進度列\n• 隱藏的分類在所有位置維持隱藏；保留「全部」列\n• 首頁：按藍色鍵進入快速設定\n• 電影、影集、直播、本機與搜尋的高級網頁卡片，詳情頁帶發光效果\n• 阿拉伯語簡介：優先顯示 Portal、Xtream 或 TMDB 中最長的阿拉伯語文字\n• 網頁瀏覽在頁面載入失敗後繼續載入；修正網頁導覽與下載問題', 'ja': '• Player New と Player New 2：ライブ、映画、シリーズ向けの新しいガラス調インフォバー（設定 › メディア › プレーヤー表示）。字幕/音声の行、実際の映像サイズ、見やすくなったバッファ線付き\n• カウントダウン付きの「次のエピソード」カード、今すぐ再生、自動再生オフ\n• シリーズ一覧とプレーヤーにエピソード名と再生時間を表示（TMDB から補完）\n• インフォバーの表示時間設定：3 秒から常時表示まで\n• ライブ、映画、シリーズのフォルダをエクスポート、または Bouquet に追加（進行バー付き）\n• 非表示にしたカテゴリはどこでも非表示のまま。「すべて」行は維持\n• ホーム：青ボタンでクイック設定\n• 映画、シリーズ、ライブ、ローカル、検索のプレミアム Web カードと、光る詳細ページ\n• アラビア語の説明：Portal、Xtream、TMDB の中で最も長いアラビア語テキストを優先表示\n• Web ブラウズは失敗したページの後も読み込みを継続。Web ナビゲーションとダウンロードの修正', 'ko': "• Player New 및 Player New 2: 라이브, 영화, 시리즈용 새 글라스 정보 바(설정 › 미디어 › 플레이어 보기). 자막/오디오 줄, 실제 화면 크기, 더 선명한 버퍼 선 포함\n• 카운트다운이 있는 다음 에피소드 카드, 지금 재생, 자동 재생 끄기\n• 시리즈 목록과 플레이어에 에피소드 이름과 재생 시간 표시(TMDB에서 보완)\n• 정보 바 표시 시간 설정: 3초부터 항상 켜짐까지\n• 라이브, 영화 또는 시리즈 폴더를 내보내거나 Bouquet에 추가(진행 표시줄 포함)\n• 숨긴 카테고리는 모든 곳에서 숨김 상태 유지, '전체' 행은 유지\n• 홈: 파란색 버튼으로 빠른 설정\n• 영화, 시리즈, 라이브, 로컬, 검색용 프리미엄 웹 카드와 빛나는 상세 페이지\n• 아랍어 설명: Portal, Xtream 또는 TMDB에서 가장 긴 아랍어 텍스트를 먼저 표시\n• 웹 탐색은 실패한 페이지 이후에도 계속 로드, 웹 탐색 및 다운로드 수정", 'id': '• Player New dan Player New 2: bilah info kaca baru untuk Live, Film, dan Serial (Pengaturan › Media › Tampilan Player) dengan baris Subtitel/Audio, ukuran gambar asli, dan garis buffer yang lebih jelas\n• Kartu Episode Berikutnya dengan hitung mundur, Putar sekarang, dan Matikan putar otomatis\n• Nama dan durasi episode di daftar Serial dan Player, dilengkapi dari TMDB\n• Pengaturan durasi bilah info: dari 3 detik hingga Selalu Aktif\n• Ekspor folder Live, Film, atau Serial, atau tambahkan ke Bouquet, dengan bilah kemajuan\n• Kategori tersembunyi tetap tersembunyi di mana saja; baris Semua tetap ada\n• Beranda: tombol BIRU untuk pengaturan cepat\n• Kartu web premium untuk Film, Serial, Live, Lokal, dan Pencarian, dengan halaman detail yang bercahaya\n• Deskripsi Arab: teks Arab terpanjang dari Portal, Xtream, atau TMDB tampil lebih dulu\n• Penelusuran Web terus memuat setelah halaman gagal; perbaikan navigasi dan unduhan web', 'fa': '• Player New و Player New 2: نوارهای اطلاعات شیشه\u200cای جدید برای زنده، فیلم\u200cها و سریال\u200cها (تنظیمات › رسانه › نمای پخش\u200cکننده) با خط زیرنویس/صدا، اندازهٔ واقعی تصویر و خط بافر واضح\u200cتر\n• کارت قسمت بعدی با شمارش معکوس، پخش فوری و خاموش کردن پخش خودکار\n• نام و مدت قسمت\u200cها در فهرست سریال\u200cها و پخش\u200cکننده، تکمیل\u200cشده از TMDB\n• تنظیم مدت نمایش نوار اطلاعات: از ۳ ثانیه تا همیشه روشن\n• خروجی گرفتن از پوشهٔ زنده، فیلم یا سریال یا افزودن آن به Bouquet، با نوار پیشرفت\n• دسته\u200cهای پنهان\u200cشده در همه\u200cجا پنهان می\u200cمانند؛ ردیف همه حفظ می\u200cشود\n• صفحهٔ اصلی: دکمهٔ آبی برای تنظیمات سریع\n• کارت\u200cهای وب ممتاز برای فیلم\u200cها، سریال\u200cها، زنده، محلی و جستجو با صفحه\u200cهای جزئیات درخشان\n• توضیحات عربی: طولانی\u200cترین متن عربی از Portal، Xtream یا TMDB اول نمایش داده می\u200cشود\n• مرور وب پس از یک صفحهٔ ناموفق همچنان بارگذاری می\u200cکند؛ رفع مشکلات ناوبری و دانلود وب'}


def _v913_release_notes():
    try:
        arabic = str(current_language() or "en").lower().startswith("ar")
    except Exception:
        arabic = False
    if arabic:
        return "V9.3\nتحسينات الأداء والكاش وعرض FHD/WQHD.\nتوحيد بيانات الإصدار وتحسين واجهة التحديث."
    return "V9.3\nPerformance, cache and FHD/WQHD improvements.\nConsistent release information and improved update presentation."



V913_UPGRADE_MARKER = "/etc/enigma2/ultrastalker/.upgrade_v9_3_detected"
V913_HIGHLIGHTS_SEEN_MARKER = "/etc/enigma2/ultrastalker/.upgrade_v9_3_highlights_seen"


def _localized_notes(version, manifest_notes=""):
    if manifest_notes not in (None, ""):
        return str(manifest_notes)
    if version_label(version) in ("9.2.1", "9.2.2"):
        return _v913_release_notes()
    return str(_("New fixes • Better performance • Improvements"))


def _log(message):
    try:
        from .log import get_logger
        get_logger().info("Updater: %s", message)
    except Exception:
        pass


def _manifest_url():
    return DREAMOS_MANIFEST_URL if _us_env.IS_DREAMOS else DEFAULT_MANIFEST_URL


def configured():
    return bool(_manifest_url())


def _version_tuple(value):
    match=re.fullmatch(r"(\d+(?:\.\d+){1,3})(?:-r5\.(\d+))?",str(value or "").strip())
    if not match:raise ValueError("Invalid version in update manifest")
    nums=[int(x) for x in match.group(1).split('.')]
    nums.extend([0]*(4-len(nums)))
    return tuple(nums+[int(match.group(2) or 0)])


def version_label(value):
    """Public release label (no internal -r5.N build suffix), e.g. '9.2.2'."""
    text=str(value or "").strip().split("-r5.",1)[0]
    return text


def is_newer(remote, current=None):
    installed="%s-r5.%d"%(PLUGIN_VERSION,PLUGIN_REVISION) if current is None else current
    return _version_tuple(remote)>_version_tuple(installed)

def _manifest_version(data):
    version=str(data.get("version") or "").strip()
    parsed=_version_tuple(version)
    revision=data.get("revision",data.get("plugin_revision"))
    if revision is None:return version
    if isinstance(revision,bool) or not re.fullmatch(r"\d+",str(revision)):
        raise ValueError("Invalid revision in update manifest")
    revision=int(revision)
    if "-r5." in version and revision!=parsed[-1]:
        raise ValueError("Conflicting revisions in update manifest")
    if data.get("revision") is not None and data.get("plugin_revision") is not None and str(data["revision"])!=str(data["plugin_revision"]):
        raise ValueError("Conflicting revisions in update manifest")
    return "%s-r5.%d"%(version.split("-r5.",1)[0],revision)


def _https_url(url):
    text = str(url or "").strip()
    if not text.lower().startswith("https://"):
        raise ValueError("Update source must use HTTPS")
    return text


def _read_url(url, max_bytes, timeout=12):
    if urlopen is None:
        raise RuntimeError("HTTPS client unavailable")
    req = Request(_https_url(url), headers={
        "User-Agent": "UltraStalker/%s" % PLUGIN_VERSION,
        "Accept": "application/json, application/octet-stream, */*",
        "Cache-Control": "no-cache",
    })
    response = urlopen(req, timeout=max(4, int(timeout or 12)))
    try:
        length = response.headers.get("Content-Length")
        if length and int(length) > int(max_bytes):
            raise ValueError("Update payload is too large")
        chunks = []
        total = 0
        while True:
            block = response.read(64 * 1024)
            if not block:
                break
            total += len(block)
            if total > int(max_bytes):
                raise ValueError("Update payload exceeded safety limit")
            chunks.append(block)
        return b"".join(chunks)
    finally:
        try:
            response.close()
        except Exception:
            pass


def check_for_update(timeout=10):
    url = _manifest_url()
    if not url:
        return {"ok": False, "configured": False, "error": "Update source is not configured"}
    try:
        raw = _read_url(url, MAX_MANIFEST_BYTES, timeout=timeout)
        data = json.loads(raw.decode("utf-8"))
        if not isinstance(data, dict):
            raise ValueError("Invalid update manifest")
        version = _manifest_version(data)
        ipk = _https_url((data.get("deb") or data.get("ipk")) if _us_env.IS_DREAMOS else (data.get("ipk") or data.get("deb")))
        if not _is_approved_ipk(ipk):
            raise ValueError("Update manifest points to an unapproved package location")
        sha = str(data.get("sha256") or "").strip().lower()
        if not re.match(r"^[0-9a-f]{64}$", sha):
            raise ValueError("Invalid SHA256 in update manifest")
        notes_value = data.get("notes")
        notes_i18n = data.get("notes_i18n")
        if isinstance(notes_i18n, dict):
            try:
                code = str(current_language() or "en").strip().lower().replace("_", "-")
            except Exception:
                code = "en"
            localized = notes_i18n.get(code) or notes_i18n.get(code.split("-", 1)[0]) or notes_i18n.get("en")
            if localized not in (None, ""):
                notes_value = localized
        result = {
            "ok": True,
            "configured": True,
            "available": is_newer(version),
            "version": version,
            "current": "%s-r5.%d"%(PLUGIN_VERSION,PLUGIN_REVISION),
            "version_label": version_label(version),
            "current_label": version_label(PLUGIN_VERSION),
            "name": str(data.get("name") or ("Ultra Stalker V%s" % version))[:80],
            "ipk": ipk,
            "sha256": sha,
            "notes": str(notes_value or "New fixes and improvements")[:1200],
            "manifest": url,
        }
        return result
    except Exception as exc:
        _log("check failed: %s" % exc)
        return {"ok": False, "configured": True, "error": str(exc)}


def _sha256_file(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        while True:
            block = handle.read(1024 * 1024)
            if not block:
                break
            digest.update(block)
    return digest.hexdigest().lower()


def download_update(info, progress=None, timeout=20):
    info = dict(info or {})
    url = _https_url(info.get("ipk"))
    if not _is_approved_ipk(url):
        raise ValueError("Update package does not match this receiver")
    expected = str(info.get("sha256") or "").strip().lower()
    if not re.match(r"^[0-9a-f]{64}$", expected):
        raise ValueError("Missing update checksum")
    if urlopen is None:
        raise RuntimeError("HTTPS client unavailable")
    req = Request(url, headers={"User-Agent": "UltraStalker/%s" % PLUGIN_VERSION, "Accept": "application/octet-stream"})
    response = urlopen(req, timeout=max(8, int(timeout or 20)))
    tmp = TMP_IPK + ".part"
    total = 0
    try:
        length = response.headers.get("Content-Length")
        expected_size = int(length) if length and str(length).isdigit() else 0
        if expected_size > MAX_IPK_BYTES:
            raise ValueError("Update package is too large")
        with open(tmp, "wb") as handle:
            while True:
                block = response.read(128 * 1024)
                if not block:
                    break
                total += len(block)
                if total > MAX_IPK_BYTES:
                    raise ValueError("Update package exceeded safety limit")
                handle.write(block)
                if callable(progress):
                    try:
                        pct = int((total * 100) / expected_size) if expected_size else 0
                        progress(max(0, min(99, pct)), total, expected_size)
                    except Exception:
                        pass
            handle.flush()
            os.fsync(handle.fileno())
        actual = _sha256_file(tmp)
        if actual != expected:
            raise ValueError("Downloaded update failed SHA256 verification")
        os.replace(tmp, TMP_IPK)
        if callable(progress):
            try:
                progress(100, total, expected_size)
            except Exception:
                pass
        return TMP_IPK
    finally:
        try:
            response.close()
        except Exception:
            pass
        if os.path.exists(tmp):
            try:
                os.unlink(tmp)
            except Exception:
                pass


def _repair_legacy_opkg_list():
    """Remove only invalid root ownership entries left by older packages.

    This must run before opkg starts solving the local IPK; a package preinst is
    too late on affected receivers because opkg computes obsolete files first.
    """
    info = "/usr/lib/opkg/info/enigma2-plugin-extensions-ultrastalker.list"
    try:
        if not os.path.isfile(info):
            return
        with open(info, "r", encoding="utf-8", errors="replace") as handle:
            lines = handle.readlines()
        cleaned = [line for line in lines if line.strip() not in ("", "/", "./")]
        if cleaned == lines:
            return
        tmp = info + ".ultrastalker-clean"
        with open(tmp, "w", encoding="utf-8") as handle:
            handle.writelines(cleaned)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(tmp, info)
    except Exception as exc:
        _log("legacy opkg list repair skipped: %s" % exc)


def _run_opkg_install(args):
    # A regular output file avoids the Python 2 communicate(timeout=...) gap
    # and bounds the text retained for the UI even when a package is noisy.
    import tempfile
    with tempfile.TemporaryFile(mode="w+b") as output:
        proc = subprocess.Popen(args, stdout=output, stderr=subprocess.STDOUT)
        deadline = time.monotonic() + 600.0
        timed_out = False
        while proc.poll() is None:
            if time.monotonic() >= deadline:
                timed_out = True
                try:
                    proc.kill()
                except Exception:
                    pass
                break
            time.sleep(0.1)
        output.seek(0, 2)
        output.seek(max(0, output.tell() - 6000))
        raw = output.read(6000)
        text = raw.decode("utf-8", "replace") if isinstance(raw, bytes) else str(raw or "")
        if timed_out:
            return 124, "Package installation timed out after 600 seconds. " + text
        return int(proc.returncode or 0), text


def install_ipk(path=TMP_IPK):
    path = str(path or TMP_IPK)
    if not (os.path.isfile(path) and os.path.getsize(path) > 1024):
        return {"ok": False, "code": -1, "output": "Downloaded package is missing"}
    if _us_env.IS_DREAMOS:
        if not path.endswith(".deb"):
            return {"ok": False, "code": -1, "output": "DreamOS requires a .deb package"}
        code, text = _run_opkg_install(["dpkg", "--install", path])
        return {"ok": code == 0, "code": int(code), "output": text[-6000:]}
    _repair_legacy_opkg_list()
    code, text = _run_opkg_install(["opkg", "install", path])
    # Some OpenBH/opkg solver builds report 'No candidates to install' when
    # the same package revision is already registered. A verified local IPK
    # may be safely force-reinstalled in that narrow case.
    if code != 0 and "no candidates to install" in text.lower():
        code2, text2 = _run_opkg_install(["opkg", "install", "--force-reinstall", path])
        text = text + "\n[UltraStalker retry --force-reinstall]\n" + text2
        code = code2
    return {"ok": code == 0, "code": int(code), "output": text[-6000:]}


def _cleanup_update_temp_files():
    for candidate in (TMP_IPK, TMP_IPK + ".part"):
        try:
            if os.path.exists(candidate):
                os.unlink(candidate)
        except OSError:
            pass


def install_update(info, progress=None):
    path = download_update(info, progress=progress)
    result = install_ipk(path)
    result["path"] = path
    # Cleanup only after opkg reports success. Restart is user-controlled from
    # the update screen, so the success UI remains visible and deterministic.
    if result.get("ok"):
        _cleanup_update_temp_files()
    return result


# ---------- Premium Enigma2 update UI ----------

def _asset(name):
    return os.path.join(os.path.dirname(__file__), "assets_fhd", name)




def make_update_screen_class():
    from Screens.Screen import Screen
    from Components.Label import Label
    from Components.ActionMap import ActionMap
    from enigma import eTimer
    from .wqhd_layout import responsive_font as gFont

    class _UpdateNoticeScreen(Screen):
        skin = '<screen name="UltraStalkerUpdateNotice" position="0,0" size="1920,1080" backgroundColor="#03070d" flags="wfNoBorder">\n          <ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/ultra_bg_flag_1920x1080.png" alphatest="off" zPosition="0" />\n          <ePixmap position="525,278" size="870,520" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/update_notice_hl_870x520.png" alphatest="blend" scale="1" zPosition="2" />\n          <ePixmap position="590,318" size="220,70" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/brand_header_full.png" alphatest="blend" scale="1" zPosition="4" />\n\n          <widget name="title" position="575,332" size="770,48" font="Regular;35" foregroundColor="#ffffff" halign="right" valign="center" transparent="1" zPosition="5" />\n          <widget name="version" position="575,392" size="770,38" font="Regular;24" foregroundColor="#bfeaff" halign="center" valign="center" transparent="1" zPosition="5" />\n          <widget name="notes" position="615,438" size="690,206" font="Regular;24" foregroundColor="#e4eef5" halign="center" valign="center" noWrap="0" transparent="1" zPosition="5" />\n          <widget name="status" position="585,650" size="750,34" font="Regular;19" foregroundColor="#a9c1d0" halign="center" valign="center" transparent="1" zPosition="5" />\n\n          \n<ePixmap position="685,719" size="56,42" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/player_keyline_green_dash_56x42.png" alphatest="blend" scale="1" zPosition="4" />\n<widget name="green" position="743,719" size="192,42" font="Regular;22" halign="left" valign="center" foregroundColor="#ffffff" transparent="1" zPosition="5" noWrap="1" shadowColor="#000000" shadowOffset="1,1" />\n<ePixmap position="985,719" size="56,42" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/player_keyline_red_dash_56x42.png" alphatest="blend" scale="1" zPosition="4" />\n<widget name="red" position="1043,719" size="192,42" font="Regular;22" halign="left" valign="center" foregroundColor="#ffffff" transparent="1" zPosition="5" noWrap="1" shadowColor="#000000" shadowOffset="1,1" />\n          \n          \n          \n        </screen>'

        def __init__(self, session, info):
            us_func(Screen.__init__)(self, session)
            self.info = dict(info or {})
            self._busy = False
            self._finished = False
            self._result = None
            self._restart_ready = False
            self._timer = eTimer()
            self._timer_conn = None
            self["title"] = Label(_("Ultra Stalker Update"))
            self["version"] = Label(_("Version %s is ready to install") % str(self.info.get("version_label") or version_label(self.info.get("version"))))
            self["notes"] = Label(_localized_notes(self.info.get("version"), self.info.get("notes")))
            self["status"] = Label(_("Verified package • Your current version stays safe until installation completes"))
            self["green"] = Label(_("Update"))
            self["red"] = Label(_("Back"))
            self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {
                "ok": self._primary,
                "green": self._primary,
                "cancel": self._later,
                "red": self._later,
            }, -1)
            self.onLayoutFinish.append(self._fit_notes)
            self.onClose.append(self._stop_timer)

        def _stop_timer(self):
            try:
                self._timer.stop()
            except Exception:
                pass
            try:
                if self._timer_conn is not None:
                    self._timer_conn.disconnect()
                    self._timer_conn = None
            except Exception:
                pass
            try:
                del self._timer.callback[:]
            except Exception:
                pass

        def _fit_notes(self):
            try:
                inst = self["notes"].instance
                if inst is None:
                    return
                try:
                    inst.setNoWrap(0)
                except Exception:
                    pass
                for size in range(24, 12, -1):
                    inst.setFont(gFont("Regular", size))
                    try:
                        measured = inst.calculateSize()
                        if int(measured.height()) <= _update_font_size(200):
                            break
                    except Exception:
                        if size <= 17:
                            break
            except Exception as exc:
                _log("update notes fit failed: %s" % exc)

        def _set_status(self, text):
            try:
                self["status"].setText(str(text or ""))
            except Exception:
                pass

        def _later(self):
            if self._busy:
                return
            self.close(False)

        def _primary(self):
            if self._busy:
                return
            if self._restart_ready:
                self.close(True)
                return
            self._busy = True
            self["green"].setText(_("Updating…"))
            self["red"].setText("")
            self._set_status(_("Downloading and verifying the package…"))

            def progress(pct, done, total):
                if total:
                    self._pending_status = _("Downloading update… %d%%") % int(pct or 0)
                else:
                    self._pending_status = _("Downloading update…")

            def worker():
                try:
                    result = install_update(self.info, progress=progress)
                except Exception as exc:
                    result = {"ok": False, "output": str(exc)}
                self._result = result
                self._finished = True

            self._finished = False
            self._pending_status = ""
            threading.Thread(target=worker, name="UltraStalkerUpdater", daemon=True).start()

            def tick():
                try:
                    if self._pending_status:
                        self._set_status(self._pending_status)
                    if not self._finished:
                        self._timer.start(250, True)
                        return
                    result = dict(self._result or {})
                    self._busy = False
                    if result.get("ok"):
                        self._restart_ready = True
                        self["title"].setText(_("Update completed successfully"))
                        self["version"].setText(_("Ultra Stalker V%s installed") % str(self.info.get("version_label") or version_label(self.info.get("version"))))
                        self["notes"].setText(_("Update completed successfully"))
                        self._set_status(_("Verified package installed • Temporary update files cleaned"))
                        self["green"].setText(_("Close"))
                        self["red"].setText(_("Close"))
                    else:
                        self._restart_ready = False
                        self["title"].setText(_("Update couldn’t be installed"))
                        self["version"].setText(_("Installation did not complete"))
                        self["notes"].setText(_("Please retry installation. Recovery details are shown in the installation log."))
                        self._set_status(str(result.get("output") or _("Please try again later"))[:120])
                        self["green"].setText(_("Retry"))
                        self["red"].setText(_("Back"))
                except Exception:
                    self._busy = False
            try:
                if self._timer_conn is not None:
                    self._timer_conn.disconnect()
                    self._timer_conn = None
            except Exception:
                pass
            try:
                self._timer_conn = self._timer.timeout.connect(tick)
            except Exception:
                try:
                    self._timer.callback[:] = [tick]
                except Exception:
                    self._timer.callback.append(tick)
            self._timer.start(250, True)

    _UpdateNoticeScreen.skin = _update_scale_skin(_UpdateNoticeScreen.skin)
    return _UpdateNoticeScreen


def _mark_v913_highlights_seen():
    try:
        directory = os.path.dirname(V913_HIGHLIGHTS_SEEN_MARKER)
        if directory and not os.path.isdir(directory):
            os.makedirs(directory)
        with open(V913_HIGHLIGHTS_SEEN_MARKER, "w", encoding="utf-8") as handle:
            handle.write("Ultra Stalker Final V%s highlights seen\n" % PLUGIN_VERSION)
            handle.flush()
            os.fsync(handle.fileno())
        return True
    except Exception as exc:
        _log("Release highlights marker failed: %s" % exc)
        return False


def make_release_highlights_screen_class():
    from Screens.Screen import Screen
    from Components.Label import Label
    from Components.ActionMap import ActionMap
    from .wqhd_layout import responsive_font as gFont

    class _ReleaseHighlightsScreen(Screen):
        skin = '<screen name="UltraStalkerReleaseHighlights" position="0,0" size="1920,1080" backgroundColor="#03070d" flags="wfNoBorder">\n          <ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/ultra_bg_clean_1920x1080.png" alphatest="off" zPosition="0" />\n          <ePixmap position="525,278" size="870,520" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/update_notice_hl_870x520.png" alphatest="blend" scale="1" zPosition="2" />\n          <ePixmap position="590,318" size="220,70" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/brand_header_full.png" alphatest="blend" scale="1" zPosition="4" />\n          <widget name="title" position="575,332" size="770,48" font="Regular;35" foregroundColor="#ffffff" halign="right" valign="center" transparent="1" zPosition="5" />\n          <widget name="version" position="575,392" size="770,38" font="Regular;24" foregroundColor="#bfeaff" halign="center" valign="center" transparent="1" zPosition="5" />\n          <widget name="notes" position="600,438" size="720,230" font="Regular;21" foregroundColor="#e4eef5" halign="center" valign="center" noWrap="0" transparent="1" zPosition="5" />\n          \n<ePixmap position="835,719" size="56,42" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker/assets_fhd/player_keyline_green_dash_56x42.png" alphatest="blend" scale="1" zPosition="4" />\n<widget name="green" position="893,719" size="192,42" font="Regular;22" halign="left" valign="center" foregroundColor="#ffffff" transparent="1" zPosition="5" noWrap="1" shadowColor="#000000" shadowOffset="1,1" />\n          \n        </screen>'

        def __init__(self, session):
            us_func(Screen.__init__)(self, session)
            self["title"] = Label(_("Ultra Stalker Update"))
            self["version"] = Label("V%s" % PLUGIN_VERSION)
            self["notes"] = Label(_v913_release_notes())
            self["green"] = Label(_("Continue"))
            self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {
                "ok": self._done, "green": self._done, "cancel": self._done, "red": self._done,
            }, -1)
            self.onLayoutFinish.append(self._fit_notes)

        def _fit_notes(self):
            try:
                inst = self["notes"].instance
                if inst is None:
                    return
                try:
                    inst.setNoWrap(0)
                except Exception:
                    pass
                for size in range(21, 12, -1):
                    inst.setFont(gFont("Regular", size))
                    try:
                        measured = inst.calculateSize()
                        if int(measured.height()) <= _update_font_size(224):
                            break
                    except Exception:
                        if size <= 17:
                            break
            except Exception as exc:
                _log("Release highlights fit failed: %s" % exc)

        def _done(self):
            _mark_v913_highlights_seen()
            self.close(True)

    _ReleaseHighlightsScreen.skin = _update_scale_skin(_ReleaseHighlightsScreen.skin)
    return _ReleaseHighlightsScreen


def maybe_show_v913_highlights(session, delay_ms=700):
    """Show the localized V9.1.3 highlights once after an actual upgrade.

    Fresh installs do not get the upgrade marker, and this never resets existing
    onboarding/settings/cache state. Markers are append-only: nothing is deleted.
    """
    if not os.path.isfile(V913_UPGRADE_MARKER) or os.path.isfile(V913_HIGHLIGHTS_SEEN_MARKER):
        return None
    if getattr(session, "_ultrastalker_v913_highlights_scheduled", False):
        return None
    setattr(session, "_ultrastalker_v913_highlights_scheduled", True)
    try:
        from enigma import eTimer
        timer = eTimer()
        def show():
            try:
                timer.stop()
            except Exception:
                pass
            if os.path.isfile(V913_HIGHLIGHTS_SEEN_MARKER):
                return
            try:
                session.open(make_release_highlights_screen_class())
            except Exception as exc:
                _log("Release highlights screen failed: %s" % exc)
        try:
            conn = timer.timeout.connect(show)
        except Exception:
            timer.callback.append(show); conn = None
        holder = getattr(session, "_ultrastalker_update_timers", None)
        if not isinstance(holder, list):
            holder = []; setattr(session, "_ultrastalker_update_timers", holder)
        holder.append(timer)
        if conn is not None:
            holder.append(conn)
        timer.start(max(250, int(delay_ms or 700)), True)
        return timer
    except Exception as exc:
        _log("Release highlights scheduling failed: %s" % exc)
        return None


def show_update_notice(session, info):
    cls = make_update_screen_class()
    def _after_update(restart=False):
        if restart:
            try:
                from Screens.Standby import TryQuitMainloop
                session.open(TryQuitMainloop, 3)
                return
            except Exception as exc:
                _log("TryQuitMainloop restart failed: %s" % exc)
            if _us_env.IS_DREAMOS:
                try:
                    subprocess.Popen(["systemctl", "restart", "enigma2"])
                except Exception:
                    pass
    try:
        return session.openWithCallback(_after_update, cls, info)
    except Exception:
        return session.open(cls, info)


def deferred_auto_check(session, delay_ms=12000):
    """Check once after plugin paint. Silent when current/offline/unconfigured."""
    if not configured():
        return None
    try:
        from enigma import eTimer
    except Exception:
        return None
    timer = eTimer()
    state = {"done": False, "result": None}

    def launch_check():
        def worker():
            state["result"] = check_for_update(timeout=8)
            state["done"] = True
        threading.Thread(target=worker, name="UltraStalkerUpdateCheck", daemon=True).start()
        poll.start(300, True)

    poll = eTimer()
    def finish_check():
        if not state["done"]:
            poll.start(300, True)
            return
        info = dict(state.get("result") or {})
        if info.get("ok") and info.get("available"):
            try:
                show_update_notice(session, info)
            except Exception as exc:
                _log("notice failed: %s" % exc)
    timer_conn = None
    poll_conn = None
    try:
        timer_conn = timer.timeout.connect(launch_check)
        poll_conn = poll.timeout.connect(finish_check)
    except Exception:
        timer.callback.append(launch_check)
        poll.callback.append(finish_check)
    holder = getattr(session, "_ultrastalker_update_timers", None)
    if not isinstance(holder, list):
        holder = []
        setattr(session, "_ultrastalker_update_timers", holder)
    holder.extend([timer, poll])
    if timer_conn is not None:
        holder.append(timer_conn)
    if poll_conn is not None:
        holder.append(poll_conn)
    timer.start(max(1000, int(delay_ms or 12000)), True)
    return timer
