# -*- coding: utf-8 -*-
"""Grid clock and live EPG.

Methods moved verbatim out of ``PremiumGridBase`` (ui_grid_base.py); behaviour is unchanged.
This module is imported by ui_grid_base.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int
from .ui_grid_base import (
    _lstrf,
    threading,
    time,
    weakref,
)


class GridEpgMixin(object):
    """Grid clock and live EPG."""

    def _update_grid_clock(self):
        try:self["clock"].setText(time.strftime("%H:%M"))
        except Exception as exc:optional_failure("ui",exc)
        if self.media_type=="itv":
            try:self._refresh_live_epg()
            except Exception as exc:optional_failure("ui.live_epg_tick",exc)
        if self.media_type in ("vod","series"):
            try:self["date_label"].setText(_lstrf("%A, %d %B %Y"))
            except Exception as exc:optional_failure("ui.poster_grid_date",exc)

    def _stop_grid_clock(self):
        try:self._grid_clock.stop()
        except Exception as exc:optional_failure("ui",exc)
        try:
            if self._grid_clock_conn is not None:self._grid_clock_conn.disconnect()
        except Exception as exc:optional_failure("ui",exc)
        try:
            if self._update_grid_clock in self._grid_clock.callback:self._grid_clock.callback.remove(self._update_grid_clock)
        except Exception as exc:optional_failure("ui",exc)

    def _refresh_live_epg(self):
        """Thirty-second GUI tick: reuse rows, fetch only an expired summary."""
        if self._screen_closed or getattr(self,"_grid_images_suspended",False) or not self.grid_items:return
        item=self.grid_items[self.index]
        cid=str(item.get("id") or item.get("ch_id") or "")
        cached=self._epg_cache.get(cid) or {}
        if "_rows" in cached:
            cached.update(epg_summary(cached["_rows"]))
            if cached["_rows"] and not cached.get("now"):cached["_expires_mono"]=0
            self._update_header(item)
            return  # Header owns scheduling; do not arm the same timer twice.
        self._schedule_epg(item)

    def _schedule_epg(self,item):
        if self.media_type!="itv":return
        cid=str(item.get("id") or item.get("ch_id") or "")
        if not cid:return
        cached=self._epg_cache.get(cid) or {}
        if time.monotonic()<float(cached.get("_expires_mono",0)):return
        retry=getattr(self,"_epg_retry_after",{}) or {}
        if time.monotonic()<float(retry.get(cid,0)):return
        pending=getattr(self,"_epg_pending",None)
        future=getattr(self,"_epg_future",None)
        if pending and len(pending)>1 and pending[1]==cid and future is not None and not future.done():return
        self._epg_token=int(getattr(self,"_epg_token",0) or 0)+1
        token=self._epg_token
        self._epg_pending=(token,cid)
        old_cancel=getattr(self,"_epg_cancel_event",None)
        if old_cancel is not None:
            try:old_cancel.set()
            except Exception:pass
        old_future=getattr(self,"_epg_future",None)
        if old_future is not None and not old_future.done():
            try:old_future.cancel()
            except Exception:pass
        self._epg_future=None
        self._epg_cancel_event=threading.Event()
        try:self._epg_timer.stop();self._epg_timer.start(350,True)
        except Exception as exc:optional_failure("ui",exc)

    def _fetch_epg(self):
        pending=getattr(self,"_epg_pending",None)
        if not pending:return
        if isinstance(pending,(tuple,list)) and len(pending)>=2:
            token,cid=int(pending[0]),str(pending[1])
        else:
            token,cid=int(getattr(self,"_epg_token",0) or 0),str(pending)
        cancel_event=getattr(self,"_epg_cancel_event",None) or threading.Event()
        client=self.client;jobs=self._epg_jobs;screen_ref=weakref.ref(self)
        def work():
            if cancel_event.is_set():return (token,cid,None,None,True)
            try:
                rows=client.epg(cid,4,cancel_event=cancel_event) or []
                summary=epg_summary(rows)
                summary["_rows"]=rows
                summary["_expires_mono"]=time.monotonic()+(300 if summary.get("now") else 45)
                return (token,cid,summary,None,bool(cancel_event.is_set()))
            except Exception as exc:
                return (token,cid,None,exc,bool(cancel_event.is_set()))
        def done(fut,ref=screen_ref,result_queue=jobs,request_token=token):
            screen=ref()
            if screen is None or getattr(screen,"_screen_closed",False):return
            try:payload=fut.result()
            except Exception:return
            if int(getattr(screen,"_epg_token",0) or 0)!=int(request_token):return
            try:result_queue.put(payload)
            except Exception:return
            if getattr(screen,"_epg_future",None) is fut:screen._epg_future=None
        try:
            future=_GRID_EPG_EXECUTOR.submit(work)
            self._epg_future=future
            future.add_done_callback(done)
        except Exception as exc:
            self._epg_future=None
            optional_failure("ui.grid_epg_submit",exc)

    def _drain_grid_epg(self):
        while True:
            try:token,cid,summary,error,cancelled=self._epg_jobs.get_nowait()
            except queue.Empty:break
            except Exception:break
            if cancelled or int(token)!=int(getattr(self,"_epg_token",0) or 0):continue
            if error:
                if not hasattr(self,"_epg_retry_after"):self._epg_retry_after={}
                self._epg_retry_after[cid]=time.monotonic()+15
            if not error and summary:
                self._epg_cache[cid]=summary
                while len(self._epg_cache)>128:
                    oldest=next((key for key in self._epg_cache if key!=cid),None)
                    if oldest is None:break
                    self._epg_cache.pop(oldest,None)
                if self.grid_items and str(self.grid_items[self.index].get("id") or self.grid_items[self.index].get("ch_id") or "")==cid:self._update_header(self.grid_items[self.index])

    def _stop_grid_epg(self):
        cancel_event=getattr(self,"_epg_cancel_event",None)
        if cancel_event is not None:
            try:cancel_event.set()
            except Exception:pass
        future=getattr(self,"_epg_future",None)
        if future is not None and not future.done():
            try:future.cancel()
            except Exception:pass
        self._epg_future=None;self._epg_pending=None
        try:self._epg_timer.stop()
        except Exception as exc:optional_failure("ui",exc)
        try:
            if self._epg_timer_conn is not None:self._epg_timer_conn.disconnect()
        except Exception as exc:optional_failure("ui",exc)
        self._epg_timer_conn=None
        try:
            if self._fetch_epg in self._epg_timer.callback:self._epg_timer.callback.remove(self._fetch_epg)
        except Exception as exc:optional_failure("ui.grid_epg_callback",exc)
        try:
            while True:self._epg_jobs.get_nowait()
        except queue.Empty:pass
        except Exception:pass
