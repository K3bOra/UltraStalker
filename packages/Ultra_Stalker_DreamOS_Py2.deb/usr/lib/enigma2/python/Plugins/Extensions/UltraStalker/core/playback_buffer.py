"""Bounded disk prefetch proxy for movie/episode playback.

The player reads the loopback URL. Each HTTP Range keeps the upstream range
intact and uses a fixed-size ring file; consumed slots are reused. Native
Enigma2 resume remains authoritative, rather than interpreting a ring file as
an already downloaded movie.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .. import us_env as _us_env
from ..us_env import str, int, open, max, min, OSError, FileNotFoundError, PermissionError, ConnectionResetError, BrokenPipeError, ProcessLookupError, us_clear, us_acquire
__metaclass__ = type  # new-style classes on Python 2
import bisect
hashlib = _us_env.hashlib
os = _us_env.os
queue = _us_env.queue
re = _us_env.re
secrets = _us_env.secrets
socket = _us_env.socket
threading = _us_env.threading
time = _us_env.time
urllib = _us_env.urllib
urllib = _us_env.urllib
urllib = _us_env.urllib
BaseHTTPRequestHandler = _us_env.http_server.BaseHTTPRequestHandler; ThreadingHTTPServer = _us_env.http_server.ThreadingHTTPServer

from ..netsec import build_safe_media_opener, validate_http_url
from .download_guard import ensure_capacity, reserve_bytes, CHECK_INTERVAL_BYTES

_LOCK = threading.RLock()
_JOBS = {}
_SERVER = None
_PORT = 0
_CHUNK = 64 * 1024
_MAX_REQUESTS = 2
_CONNECT_TIMEOUT = 10
_READ_TIMEOUT = 30
# Upstream hiccups (reset, timeout, early EOF, 5xx) are retried at the current
# byte with a Range request before the job is declared failed; the player keeps
# draining what is already buffered meanwhile.
_RECONNECT_DELAYS = (0.3, 0.8, 1.6, 3.0)
_NON_TRANSIENT_HTTP = (400, 401, 403, 404, 405, 410, 416)


def hide_visible_buffer_folder():
    """Retire only old generated buffer files; preserve other HDD contents."""
    old = "/media/hdd/ultrastalker"
    def work():
        try:
            for name in os.listdir(old):
                if re.fullmatch(r"[0-9a-f]{24}\.bin(?:\.origin)?", name):
                    path = os.path.join(old, name)
                    if not os.path.islink(path):
                        try: os.unlink(path)
                        except OSError: pass
            try: os.rmdir(old)
            except OSError: pass
        except OSError:
            pass
    if os.path.isdir(old):
        threading.Thread(target=work, name="ultrastalker-buffer-retire", daemon=True).start()


def _ring_owner_alive(pid):
    """Is the process that created a ring file still the one running it?

    kill(pid, 0) alone is not enough: after a reboot the old Enigma2 PID is usually
    handed to some other process, so rings left on the HDD looked "owned" forever."""
    if pid == os.getpid():
        return True
    try:
        os.kill(pid, 0)
    except OSError as exc:
        if not isinstance(exc, ProcessLookupError): raise
        return False
    except (PermissionError, OSError):
        return True
    try:
        with open('/proc/%d/cmdline' % pid, 'rb') as handle:
            return b'enigma2' in handle.read(4096)
    except OSError as exc:
        if not isinstance(exc, FileNotFoundError): raise
        return False
    except OSError:
        return True


def _buffer_dir():
    from ..persistent_cache import hdd_read_ready, ROOT, persistent_write_gate
    if hdd_read_ready(force=True):
        root = os.path.join(ROOT, ".buffer")
        if not persistent_write_gate(root):
            raise OSError("Playback buffer HDD is unavailable")
    else:
        root = "/tmp/ultrastalker-buffer"
        os.makedirs(root, mode=0o700, exist_ok=True)
    # A receiver restart can leave an interrupted ring behind. Remove only
    # generated rings belonging to a process which no longer exists.
    for name in os.listdir(root):
        match=re.fullmatch(r'[0-9a-f]{24}-(\d+)-[A-Za-z0-9_-]+\.ring\.(?:\d+|cache)\.bin',name)
        if not match:continue
        if not _ring_owner_alive(int(match.group(1))):
            try:os.unlink(os.path.join(root,name))
            except OSError:pass
    return root


def _write_ready(job, incoming=0):
    if not job.path.startswith("/tmp/"):
        from ..persistent_cache import persistent_write_gate
        if not persistent_write_gate(job.path):
            raise OSError("Playback buffer HDD disappeared")
    ensure_capacity(job.path, incoming_bytes=incoming, reserve=job.reserve)


class _Job(object):
    def __init__(self, url, limit_bytes, trusted_private_origins=()):
        self.url = str(url or "")
        self.limit = max(_CHUNK * _MAX_REQUESTS, int(limit_bytes or 0))
        self.ready = threading.Event()
        self.finished = threading.Event()
        self.stop = threading.Event()
        self.released = threading.Event(); self.released.set()
        self.failed = ""
        self.reconnects = 0
        self.reconnecting = False
        self.reconnect_attempt = 0
        self.direct_only = False
        self._cleanup_started = False
        self.size = 0
        self.bytes_served = 0
        self.prefetch_enabled = True
        self.requested_limit = self.limit
        self.storage_ready = False
        self.storage_done = threading.Event()
        self._storage_lock = threading.Lock()
        self.key = ''
        self.reserve = None
        self.origin = 0
        self.read_offset = 0
        self.content_length = 0
        self.play_ratio = 0.0
        self.path = ""
        self.local_url = ""
        self.token = secrets.token_urlsafe(24)
        self._opener = build_safe_media_opener(trusted_private_origins=trusted_private_origins)
        self._write_lock = threading.RLock()
        self._responses = set()
        self._response_sockets = {}
        self._connections = set()
        self._paths = set()
        self._slots = threading.BoundedSemaphore(_MAX_REQUESTS)
        self._next_request = 0
        self._active = 0
        self._requests = {}
        self._metric_request = None
        self.window_start = 0
        self.window_end = 0
        self.content_type = 'application/octet-stream'
        self._last_window_update = 0.0
        self._cache_lock = threading.RLock()
        self._cache_records = {}
        self._cache_starts = []
        self._cache_index = {}


class _Server(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True


class _Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *args):
        return

    def setup(self):
        super(_Handler, self).setup()
        self.connection.settimeout(30)

    def do_HEAD(self):
        self._serve(True)

    def do_GET(self):
        self._serve(False)

    def _serve(self, head_only):
        parts = urllib.parse.urlsplit(self.path).path.strip('/').split('/')
        with _LOCK:
            job = _JOBS.get(parts[0] if parts else '')
        if job is None or job.stop.is_set():
            self.send_error(404); return
        raw_range = str(self.headers.get('Range') or '')
        if raw_range and not re.fullmatch(r'bytes=(?:\d+-\d*|-\d+)', raw_range):
            self.send_error(416); return
        # Keep the playing GET alive when a decoder opens an index/subtitle
        # read. Only one request owns the ring; secondary reads pass through.
        request_id, cancelled = _begin_request(job, self.connection, head_only)
        auxiliary=_request_is_auxiliary(job,request_id)
        acquired = False
        response = None
        ring = None
        try:
            acquired = us_acquire(job._slots, 0.75)
            if not acquired:
                self.send_error(503, 'Playback reader busy')
                return
            if cancelled.is_set(): return
            # Storage is warming in parallel. Open the origin first so a slow
            # mount does not serialize disk discovery and the network handshake.
            if job.stop.is_set() or cancelled.is_set(): return
            if job.direct_only:
                self.send_error(502, 'Use direct playback'); return
            total = int(job.content_length or 0)
            cached_start = 0; cached_end = total - 1
            if raw_range and total:
                first,last = raw_range[6:].split('-')
                if first:
                    cached_start=int(first)
                    if last:cached_end=min(cached_end,int(last))
                else:cached_start=max(0,total-int(last))
            with job._cache_lock:
                reusable = not auxiliary and total > 0 and cached_end >= cached_start and _cache_lookup(job,cached_start) is not None
            if reusable:
                self.send_response(206 if raw_range else 200)
                self.send_header('Content-Type',job.content_type)
                self.send_header('Content-Length',str(cached_end-cached_start+1))
                self.send_header('Accept-Ranges','bytes')
                if raw_range:self.send_header('Content-Range','bytes %d-%d/%d'%(cached_start,cached_end,total))
                self.send_header('Cache-Control','no-store');self.send_header('Connection','close');self.end_headers()
                if not head_only:
                    ring=job.path+'.cache.bin'
                    with job._write_lock:job._paths.add(ring)
                    self._stream_ring(job,None,ring,cached_start,cached_end-cached_start+1,b'',request_id,cancelled)
                return
            headers = {'User-Agent': 'VLC/3.0.20 LibVLC/3.0.20', 'Accept-Encoding': 'identity'}
            if raw_range: headers['Range'] = raw_range
            req = urllib.request.Request(job.url, headers=headers, method='HEAD' if head_only else 'GET')
            try:
                response = job._opener.open(req, timeout=_CONNECT_TIMEOUT)
                upstream_socket = _response_socket(response)
                if upstream_socket is not None: upstream_socket.settimeout(_READ_TIMEOUT)
            except urllib.error.HTTPError as exc:
                if exc.code != 416 and not head_only and not _request_is_auxiliary(job,request_id) and not cancelled.is_set():
                    job.failed = 'Upstream HTTP %d' % exc.code
                self.send_response(exc.code)
                if exc.headers.get('Content-Range'):
                    self.send_header('Content-Range', exc.headers['Content-Range'])
                self.send_header('Content-Length', '0'); self.send_header('Connection', 'close')
                self.end_headers(); exc.close(); return
            with job._write_lock:
                job._responses.add(response)
                # HTTPResponse.close() clears fp before waiting for its reader.
                # Keep the socket now so stop can still interrupt that reader.
                job._response_sockets[response] = _response_socket(response)
                job._requests[request_id]['response'] = response
            if job.stop.is_set() or cancelled.is_set(): return
            status = int(getattr(response, 'status', 200) or 200)
            content_range = str(response.headers.get('Content-Range') or '')
            match = re.fullmatch(r'bytes (\d+)-(\d+)/(\d+|\*)', content_range)
            start = int(match.group(1)) if match else 0
            total = int(match.group(3)) if match and match.group(3).isdigit() else 0
            length = int(response.headers.get('Content-Length') or 0)
            if raw_range and not head_only:
                first, last = raw_range[6:].split('-')
                valid = status == 206 and match is not None
                if valid:
                    valid = int(match.group(2)) >= start and length == int(match.group(2)) - start + 1
                    if total: valid = valid and int(match.group(2)) < total
                if valid and first:
                    valid = start == int(first) and (not last or int(match.group(2)) <= int(last))
                elif valid and total:
                    valid = start == max(0, total - int(last))
                if not valid:
                    # A server ignoring Range must not silently feed bytes from
                    # zero as if they belonged to the requested seek position.
                    if not _request_is_auxiliary(job,request_id):job.direct_only = True
                    self.send_error(502, 'Use direct playback')
                    return
            mime = str(response.headers.get('Content-Type') or '').split(';',1)[0].strip().lower()
            hls = mime in ('application/vnd.apple.mpegurl','application/x-mpegurl',
                           'audio/mpegurl','audio/x-mpegurl')
            initial = b''
            if not head_only and not hls:
                initial = _read_available(response,min(512,length) if length else 512)
                prefix=initial.lstrip(b'\xef\xbb\xbf \r\n\t')
                while initial and len(initial)<32 and (not prefix or b'#EXTM3U'.startswith(prefix)) and len(prefix)<7:
                    extra=_read_available(response,7-len(prefix))
                    if not extra:break
                    initial+=extra;prefix=initial.lstrip(b'\xef\xbb\xbf \r\n\t')
                # Some panels return HLS through play.php with an octet-stream
                # MIME type. Keep segment/key resolution on the real origin.
                hls = initial.lstrip(b'\xef\xbb\xbf \r\n\t').startswith(b'#EXTM3U')
            if hls:
                if not _request_is_auxiliary(job,request_id):
                    job.direct_only = True
                    job.content_length = 0; job.size = 0
                self.send_error(502, 'Use direct playback')
                return
            if job.stop.is_set() or cancelled.is_set(): return
            auxiliary=_request_is_auxiliary(job,request_id)
            if not head_only and not auxiliary:
                # A sleeping or wedged HDD must not hold the decoder hostage.
                # Storage warms independently; this title falls back to direct
                # playback if it cannot become ready within a short grace.
                if not job.storage_done.wait(0.25) or not job.storage_ready:
                    job.direct_only = True
                    self.send_error(502, 'Use direct playback'); return
            if not total and status == 200: total = length
            if not auxiliary:
                if total: job.content_length = total
                job.content_type = str(response.headers.get('Content-Type') or 'application/octet-stream')
            self.send_response(status)
            for name in ('Content-Type', 'Content-Length', 'Content-Range', 'Accept-Ranges'):
                value = response.headers.get(name)
                if value is not None: self.send_header(name, value)
            self.send_header('Cache-Control', 'no-store')
            self.send_header('Connection', 'close')
            self.end_headers()
            if head_only: return
            if auxiliary:
                # No ring/cache mutation or read-ahead: the secondary consumer
                # controls backpressure, with one bounded in-memory chunk.
                remaining=length
                cursor=start
                chunk=initial
                while not cancelled.is_set() and not job.stop.is_set():
                    if not _request_is_auxiliary(job,request_id):
                        # The old playing GET ended during this read. Keep its
                        # successor alive and begin buffering at the next byte
                        # still owed to this consumer, including unread prefix.
                        if total:job.content_length=total
                        job.content_type=str(response.headers.get('Content-Type') or 'application/octet-stream')
                        if not job.storage_done.wait(0.25) or not job.storage_ready:
                            job.direct_only=True
                            return
                        ring=job.path+'.cache.bin'
                        with job._write_lock:job._paths.add(ring)
                        _write_ready(job,_CHUNK)
                        self._stream_ring(job,response,ring,cursor,remaining,chunk,request_id,cancelled)
                        return
                    if chunk:
                        self.wfile.write(chunk);self.wfile.flush()
                        cursor+=len(chunk)
                        if length:remaining-=len(chunk)
                    if length and remaining<=0:break
                    chunk=_read_available(response,min(_CHUNK,remaining) if length else _CHUNK)
                    if not chunk:break
                return
            # Only the primary reader owns the configured disk allowance.
            ring = job.path + '.cache.bin'
            with job._write_lock: job._paths.add(ring)
            _write_ready(job, _CHUNK)
            self._stream_ring(job, response, ring, start, length, initial, request_id, cancelled)
        except socket.timeout:
            if not _request_is_auxiliary(job,request_id) and not cancelled.is_set() and not job.stop.is_set():
                job.failed = 'Playback upstream timed out'
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception as exc:
            if not _request_is_auxiliary(job,request_id) and not job.stop.is_set() and not cancelled.is_set(): job.failed = str(exc)[:220]
        finally:
            if response is not None:
                with job._write_lock:
                    job._responses.discard(response)
                    job._response_sockets.pop(response,None)
                try: response.close()
                except Exception: pass
            with job._write_lock:
                job._connections.discard(self.connection)
                state = job._requests.pop(request_id, None)
                if state is not None: state['completed'].set()
                _promote_reader_locked(job)
                job._active -= 1
                if not job._active: job.released.set()
            if acquired: job._slots.release()
            self.close_connection = True

    def _stream_ring(self, job, response, path, start, expected, initial=b'', request_id=None, cancelled=None):
        pending = queue.Queue()
        cancelled = cancelled if cancelled is not None else threading.Event()
        slots = _RingSlots()
        written = [0]; consumed = [0]
        def close_pack(state):
            if state is not None:
                with slots.condition:
                    state['closed']=True;slots.condition.notify_all()
        with job._cache_lock:
            ring = open(path, 'r+b' if os.path.isfile(path) else 'w+b', buffering=0)
        reader = [response]; source_at = [start]; prefix = [initial]

        def upstream(cursor, amount):
            if reader[0] is None or source_at[0] != cursor:
                old = reader[0]
                if old is not None:
                    with job._write_lock:
                        job._responses.discard(old);job._response_sockets.pop(old, None)
                    try:old.close()
                    except Exception:pass
                headers = {'User-Agent':'VLC/3.0.20 LibVLC/3.0.20','Accept-Encoding':'identity'}
                if cursor or start or expected:
                    headers['Range'] = 'bytes=%d-%s' % (cursor, str(start+expected-1) if expected else '')
                value = job._opener.open(urllib.request.Request(job.url, headers=headers), timeout=30)
                if cursor:
                    match = re.fullmatch(r'bytes (\d+)-(\d+)/(\d+|\*)', str(value.headers.get('Content-Range') or ''))
                    if int(getattr(value,'status',200)) != 206 or not match or int(match.group(1)) != cursor:
                        value.close();job.direct_only=True
                        raise OSError('Server cannot deliver the requested movie position')
                reader[0]=value;source_at[0]=cursor;prefix[0]=b''
                with job._write_lock:
                    job._responses.add(value);job._response_sockets[value]=_response_socket(value)
                    state=job._requests.get(request_id)
                    if state is not None:state['response']=value
            if prefix[0]:
                data=prefix[0][:amount];prefix[0]=prefix[0][len(data):]
            else:
                data=_read_available(reader[0], amount)
            source_at[0]+=len(data)
            return data

        def fetch(cursor,amount):
            """upstream() with transparent reconnect-at-offset on transient errors."""
            attempt=0
            while True:
                try:
                    data=upstream(cursor,amount)
                    if not data and expected and written[0]<expected:
                        raise OSError('Incomplete playback buffer response')
                    if attempt:
                        job.reconnecting=False;job.reconnect_attempt=0
                    return data
                except Exception as exc:
                    if (cancelled.is_set() or job.stop.is_set() or job.direct_only
                            or (isinstance(exc,urllib.error.HTTPError) and exc.code in _NON_TRANSIENT_HTTP)
                            or attempt>=len(_RECONNECT_DELAYS)):
                        job.reconnecting=False;raise
                    delay=_RECONNECT_DELAYS[attempt];attempt+=1
                    job.reconnecting=True;job.reconnect_attempt=attempt;job.reconnects+=1
                    old=reader[0];reader[0]=None
                    if old is not None:
                        with job._write_lock:
                            job._responses.discard(old);job._response_sockets.pop(old,None)
                        _abort_response_transport(old)
                        try:old.close()
                        except Exception:pass
                    if cancelled.wait(delay) or job.stop.is_set():raise

        def produce():
            checked=0
            pack_slot=None; pack_start=0; pack_length=0; pack_state=None
            try:
                while not cancelled.is_set() and not job.stop.is_set():
                    if expected and written[0]>=expected:
                        if request_id==job._metric_request:job.finished.set()
                        break
                    allowance=max(_CHUNK,int(job.limit)-_retain_bytes(job.limit))
                    if written[0]-consumed[0]>=allowance:
                        cancelled.wait(.02);continue
                    cursor=start+written[0]
                    capacity=max(1,int(job.limit)//_CHUNK)
                    with job._cache_lock:
                        found=_cache_lookup(job,cursor)
                    if found is not None:
                        if pack_slot is not None:
                            close_pack(pack_state)
                            slots.release(pack_slot);pack_slot=None;pack_state=None
                        absolute,slot,length=found
                        if not slots.acquire_specific(slot,cancelled,job.stop):continue
                        offset=cursor-absolute
                        size=min(length-offset,expected-written[0]) if expected else length-offset
                        written[0]+=size
                        _note_window(job,request_id,start,written[0],consumed[0])
                        pending.put({'slot':slot,'offset':offset,'end':offset+size,'closed':True})
                        continue
                    # Hold one partial slot across network reads. Each fragment
                    # is available immediately while still sharing the same
                    # physical 64 KiB slot, so latency and capacity are independent.
                    if pack_slot is not None and pack_slot>=capacity:
                        close_pack(pack_state)
                        slots.release(pack_slot);pack_slot=None;pack_state=None
                    if pack_slot is None:
                        pack_slot=slots.acquire_cached(capacity,job,cursor,cancelled,job.stop)
                        if pack_slot is None:continue
                        pack_start=cursor;pack_length=0;pack_state=None
                    amount=_CHUNK-pack_length
                    if expected:amount=min(amount,expected-written[0])
                    data=fetch(cursor,amount)
                    if cancelled.is_set() or job.stop.is_set():break
                    if not data:
                        if request_id==job._metric_request:job.finished.set()
                        break
                    if written[0]-checked>=CHECK_INTERVAL_BYTES:
                        _write_ready(job,len(data));checked=written[0]
                    offset=pack_length
                    with job._cache_lock:
                        # A replaced owner may still be unwinding a blocked
                        # read/write check. Fence it before touching shared slots.
                        if cancelled.is_set() or job.stop.is_set():break
                        ring.seek(pack_slot*_CHUNK+offset);ring.write(data)
                        pack_length+=len(data)
                        _cache_store(job,pack_slot,pack_start,pack_length)
                    written[0]+=len(data)
                    _note_window(job,request_id,start,written[0],consumed[0])
                    # One notification per physical slot. The consumer can
                    # drain newly written fragments while the producer fills it.
                    # Both owners pin the slot; small packets do not create an
                    # unbounded queue or reduce the configured byte capacity.
                    if pack_state is None:
                        pack_state={'slot':pack_slot,'offset':0,'end':pack_length,'closed':False}
                        slots.retain(pack_slot)
                        pending.put(pack_state)
                    else:
                        with slots.condition:
                            pack_state['end']=pack_length;slots.condition.notify_all()
                    if pack_length==_CHUNK:
                        close_pack(pack_state)
                        slots.release(pack_slot);pack_slot=None;pack_state=None
            except Exception as exc:
                if not cancelled.is_set() and not job.stop.is_set():job.failed=str(exc)[:220]
            finally:
                if pack_slot is not None:
                    close_pack(pack_state);slots.release(pack_slot)
                pending.put(None)

        producer=threading.Thread(target=produce,name='ultrastalker-buffer-prefetch',daemon=True)
        producer.start()
        try:
            while not job.stop.is_set() and not cancelled.is_set():
                try:item=pending.get(timeout=.1)
                except queue.Empty:continue
                if item is None:break
                slot=item['slot'];offset=item['offset']
                try:
                    while not job.stop.is_set() and not cancelled.is_set():
                        with slots.condition:
                            end=item['end'];closed=item['closed']
                            if offset>=end and not closed:
                                slots.condition.wait(.1);continue
                        if offset>=end:break
                        size=end-offset
                        with job._cache_lock:
                            ring.seek(slot*_CHUNK+offset);data=ring.read(size)
                        if len(data)!=size:raise OSError('Cached playback bytes are incomplete')
                        self.wfile.write(data);self.wfile.flush()
                        offset+=len(data)
                        consumed[0]+=len(data);job.bytes_served+=len(data)
                        _note_window(job,request_id,start,written[0],consumed[0])
                finally:slots.release(slot)
                capacity=max(1,int(job.limit)//_CHUNK)
                with slots.condition:
                    with job._cache_lock:
                        for cached_slot in list(job._cache_records):
                            if cached_slot>=capacity and cached_slot not in slots.busy:
                                _cache_remove(job,cached_slot)
                        extent=max(capacity,max(slots.busy,default=-1)+1)*_CHUNK
                        if os.fstat(ring.fileno()).st_size>extent:ring.truncate(extent)
        finally:
            cancelled.set()
            value=reader[0]
            if value is not None:
                _abort_response_transport(value,job._response_sockets.get(value))
                try:value.close()
                except Exception:pass
                with job._write_lock:
                    job._responses.discard(value);job._response_sockets.pop(value,None)
            producer.join(1.0)
            if not producer.is_alive():ring.close()
            else:
                def close_later():producer.join();ring.close()
                threading.Thread(target=close_later,daemon=True).start()


def _retain_bytes(limit):
    """Ring share kept behind the playhead for short seeks (quarter, max 32 MB)."""
    limit=int(limit or 0)
    return min(32*1024*1024,(limit//4)//_CHUNK*_CHUNK)


def _request_is_auxiliary(job,request_id):
    with job._write_lock:
        state=job._requests.get(request_id)
        return bool(state is None or state.get('auxiliary',False))


def _promote_reader_locked(job):
    readers=list((request_id,state) for request_id,state in job._requests.items()
             if not state['head'] and not state['cancelled'].is_set()
             and not state['completed'].is_set())
    owner=next(((request_id,state) for request_id,state in readers
                if not state.get('auxiliary',False)),None)
    if owner is None and readers:
        owner=min(readers,key=lambda pair:pair[0])
        owner[1]['auxiliary']=False
        job._metric_request=owner[0]
        us_clear(job.finished)
    if owner is None:job._metric_request=None
    return owner[0] if owner is not None else None


def _begin_request(job, connection, head_only):
    obsolete = []
    with job._write_lock:
        request_id = job._next_request
        job._next_request += 1
        owner=_promote_reader_locked(job)
        readers=list(state for state in job._requests.values() if not state['head'])
        auxiliary=bool(not head_only and owner is not None)
        # Decoder seeks can replace an earlier auxiliary read, but must never
        # destroy the main playback GET merely to inspect another file range.
        if auxiliary:
            for state in readers:
                if state.get('auxiliary',False):
                    state['cancelled'].set()
                    obsolete.append((state['connection'],state.get('response'),state['completed']))
        elif not head_only:
            job._metric_request=request_id
            us_clear(job.finished);job.failed=''
        cancelled = threading.Event()
        job._requests[request_id] = {'head':head_only,'auxiliary':auxiliary,
                                    'cancelled':cancelled,'connection':connection,
                                    'response':None,'completed':threading.Event()}
        job._active += 1
        us_clear(job.released)
        job._connections.add(connection)
    for old_connection,response,completed in obsolete:
        try:old_connection.shutdown(socket.SHUT_RDWR)
        except OSError:pass
        if response is not None:
            _abort_response_transport(response,job._response_sockets.get(response))
    # The semaphore bounds concurrent transports. No GUI wait and no poisoning
    # of the entire movie if an old auxiliary socket needs time to close.
    return request_id,cancelled


def _note_window(job, request_id, start, written, consumed):
    now=time.monotonic()
    if (written != consumed and written and
            now - job._last_window_update < 0.1): return
    job._last_window_update=now
    with job._cache_lock:
        cursor=start+consumed
        end=_cache_end(job,cursor)
    with job._write_lock:
        if request_id is not None and request_id!=job._metric_request:return
        job.origin=job.read_offset=cursor
        job.size=max(0,end-cursor)
        job.window_start=cursor
        job.window_end=end


def _ensure_server():
    global _SERVER, _PORT
    with _LOCK:
        if _SERVER is None:
            _SERVER = _Server(('127.0.0.1', 0), _Handler)
            _PORT = int(_SERVER.server_address[1])
            threading.Thread(target=_SERVER.serve_forever, name='ultrastalker-buffer', daemon=True).start()
        return _PORT


def note_playhead(job, stream_byte, seek=False):
    # Actual seeks arrive as HTTP Range requests. Do not retarget/truncate a
    # file by approximating byte offsets from time, which breaks MP4 indexes.
    if job is not None and job.content_length:
        job.play_ratio = max(0.0, min(1.0, float(stream_byte or 0) / job.content_length))


def start_buffer(url, megabytes, key='', trusted_private_origins=()):
    validate_http_url(url)
    limit=max(1,min(512,int(megabytes or 0)))*1024*1024
    job=_Job(url,limit,trusted_private_origins)
    job.key=str(key or url)
    suffix=os.path.splitext(urllib.parse.urlsplit(url).path)[1].lower()
    if suffix not in ('.mp4','.mkv','.avi','.ts','.m2ts','.mov','.webm'):suffix='.bin'
    job.local_url='http://127.0.0.1:%d/%s/media%s'%(_ensure_server(),job.token,suffix)
    with _LOCK:_JOBS[job.token]=job
    def warm_storage():
        try: _prepare_storage(job)
        except Exception:
            if not job.stop.is_set(): job.direct_only=True
        finally:job.storage_done.set()
    threading.Thread(target=warm_storage,name='ultrastalker-buffer-storage',daemon=True).start()
    job.ready.set()
    return job


def resize_buffer(job,megabytes):
    if job is None or job.stop.is_set():return False
    mb=max(0,min(512,int(megabytes or 0)))
    limit=max(_CHUNK*_MAX_REQUESTS,mb*1024*1024)
    with job._write_lock:
        job.prefetch_enabled=bool(mb)
        job.requested_limit=limit
        job.limit=min(limit,64*1024*1024) if job.path.startswith('/tmp/') else limit
    return True


def _prepare_storage(job):
    if job.storage_ready:return
    with job._storage_lock:
        if job.storage_ready:return
        if job.stop.is_set():raise OSError('Playback buffer stopped')
        root=_buffer_dir()
        if job.stop.is_set():raise OSError('Playback buffer stopped')
        stem=hashlib.sha1(job.key.encode('utf-8','ignore')).hexdigest()[:24]
        job.path=os.path.join(root,stem+'-'+str(os.getpid())+'-'+job.token+'.ring')
        if root.startswith('/tmp/'):
            job.limit=min(job.requested_limit,64*1024*1024)
            job.reserve=64*1024*1024
        else:
            from ..storage import load_settings
            job.reserve=reserve_bytes(load_settings())
        # The configured size is an upper limit, not an allocation or a minimum
        # download. Check only the next write; grow in the background as needed.
        _write_ready(job,_CHUNK)
        job.storage_ready=True


def _read_available(response,amount):
    reader=getattr(response,'read1',None)
    return reader(amount) if callable(reader) else response.read(amount)


class _RingSlots:
    def __init__(self):
        self.condition=threading.Condition()
        self.busy=set()
        self.references={}
        self.hint=0
    def acquire(self,capacity,cancelled,stop):
        with self.condition:
            if cancelled.is_set() or stop.is_set():return None
            if len(self.busy)>=capacity:
                self.condition.wait(.05);return None
            for offset in range(capacity):
                slot=(self.hint+offset)%capacity
                if slot not in self.busy:
                    self.busy.add(slot);self.references[slot]=1;self.hint=(slot+1)%capacity
                    return slot
        return None
    def retain(self,slot):
        with self.condition:
            if slot not in self.busy:raise RuntimeError('Buffer slot is not reserved')
            self.references[slot]=self.references.get(slot,1)+1

    def release(self,slot):
        with self.condition:
            count=self.references.get(slot,1)-1
            if count>0:self.references[slot]=count
            else:
                self.references.pop(slot,None);self.busy.discard(slot)
            self.condition.notify_all()

    def acquire_specific(self,slot,cancelled,stop):
        with self.condition:
            if cancelled.is_set() or stop.is_set():return False
            if slot in self.busy:
                self.condition.wait(.05);return False
            self.busy.add(slot);self.references[slot]=1;return True

    def acquire_cached(self,capacity,job,cursor,cancelled,stop):
        with self.condition:
            if cancelled.is_set() or stop.is_set():return None
            if len(self.busy)>=capacity:
                self.condition.wait(.05);return None
            with job._cache_lock:
                slot=None
                for offset in range(capacity):
                    candidate=(self.hint+offset)%capacity
                    if candidate in self.busy: continue
                    record=job._cache_records.get(candidate)
                    if record is None or record[0]+record[1] <= cursor:
                        slot=candidate; break
                if slot is None:
                    free=list(n for n in range(capacity) if n not in self.busy)
                    slot=max(free,key=lambda n:job._cache_records.get(n,(0,0))[0])
                self.hint=(slot+1)%capacity
            self.busy.add(slot);self.references[slot]=1;return slot


def _response_socket(response):
    stream = getattr(response,'fp',None)
    raw = getattr(getattr(stream,'fp',stream),'raw',None)
    return getattr(raw,'_sock',None) or getattr(stream,'_sock',None)  # py2: socket._fileobject


def _abort_response_transport(response,sock=None):
    # Interrupt socket reads without waiting on BufferedReader.close()'s lock.
    sock = sock if sock is not None else _response_socket(response)
    if sock is not None:
        try: sock.shutdown(socket.SHUT_RDWR)
        except OSError: pass


def stop_buffer(job, keep=False):
    if job is None: return
    job.stop.set()
    with _LOCK:
        if _JOBS.get(job.token) is job: _JOBS.pop(job.token, None)
    with job._write_lock:
        if job._cleanup_started: return
        job._cleanup_started = True
    def cleanup():
        with job._write_lock:
            responses=list((response,job._response_sockets.get(response)) for response in job._responses)
            connections=list(job._connections)
        for connection in connections:
            try: connection.shutdown(socket.SHUT_RDWR)
            except OSError: pass
        for response,sock in responses:
            _abort_response_transport(response,sock)
        for response,sock in responses:
            try: response.close()
            except Exception: pass
        # Cleanup waits belong to a worker, never the receiver's GUI thread.
        # A wedged upstream used to leave the ring file (up to 512 MB on the HDD,
        # 64 MB of RAM under /tmp) behind until the receiver rebooted, because the
        # file was only removed when every handler had finished within 2 seconds.
        # The worker is a daemon thread, so it can afford to wait much longer, and
        # it removes the file even if a handler is still stuck (Linux frees the
        # space as soon as that handler closes its descriptor).
        def remove_rings():
            with job._write_lock: paths=list(job._paths)
            for path in paths:
                try: os.unlink(path)
                except OSError: pass
        if job.released.wait(2.0):
            remove_rings()
        else:
            job.released.wait(28.0)
            remove_rings()
            if not job.released.is_set():
                job.released.wait(60.0)
                remove_rings()
    threading.Thread(target=cleanup,name='ultrastalker-buffer-close',daemon=True).start()

def _cache_lookup(job, cursor):
    index=bisect.bisect_right(job._cache_starts,cursor)-1
    if index<0:return None
    absolute=job._cache_starts[index]
    slot,length=job._cache_index[absolute]
    return (absolute,slot,length) if cursor<absolute+length else None

def _cache_remove(job,slot):
    previous=job._cache_records.pop(slot,None)
    if previous is None:return
    absolute,length=previous
    job._cache_index.pop(absolute,None)
    index=bisect.bisect_left(job._cache_starts,absolute)
    if index<len(job._cache_starts) and job._cache_starts[index]==absolute:
        job._cache_starts.pop(index)

def _cache_store(job,slot,absolute,length):
    _cache_remove(job,slot)
    if absolute in job._cache_index:
        _cache_remove(job,job._cache_index[absolute][0])
    job._cache_records[slot]=(absolute,length)
    job._cache_index[absolute]=(slot,length)
    bisect.insort(job._cache_starts,absolute)

def _cache_end(job,cursor):
    found=_cache_lookup(job,cursor)
    if found is None:return cursor
    end=found[0]+found[2]
    index=bisect.bisect_right(job._cache_starts,found[0])
    while index<len(job._cache_starts):
        absolute=job._cache_starts[index]
        if absolute>end:break
        end=max(end,absolute+job._cache_index[absolute][1]);index+=1
    return end

