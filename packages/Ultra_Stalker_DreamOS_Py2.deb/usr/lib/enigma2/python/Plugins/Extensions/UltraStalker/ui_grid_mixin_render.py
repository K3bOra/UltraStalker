# -*- coding: utf-8 -*-
"""Grid card rendering, ratings layout and selection updates.

Methods moved verbatim out of ``PremiumGridBase`` (ui_grid_base.py); behaviour is unchanged.
This module is imported by ui_grid_base.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, round, max, min
from .ui_grid_base import (
    _,
    adaptive_enabled,
    diagnostic_failure,
    display_certification,
    os,
    time,
)


class GridRenderMixin(object):
    """Grid card rendering, ratings layout and selection updates."""

    def _render_grid(self):
        self._apply_shared_footer_geometry()
        if self.media_type=="itv":
            _live_restart_trace("render_begin",page=int(getattr(self,"page",0) or 0),index=int(getattr(self,"index",0) or 0),
                                generation=int(getattr(self,"_grid_generation",0) or 0),
                                items=len(getattr(self,"grid_items",[]) or []),inflight=len(getattr(self,"_grid_download_inflight",{}) or {}))
        self._card_prog_shown={}
        self._grid_cancel_queued_downloads()
        self._grid_generation+=1;self._grid_decode_queue=[];self._grid_waiting={};self._grid_queued=set();self._grid_slot_paths={};self._grid_slot_identities={};self._grid_palette_sources={};self._grid_card_paths={};self._grid_display_titles={};self._grid_visual_locks={};self._grid_canonical_poster_slots={}
        cfg=self._grid_settings or {}
        self._grid_prepared_art={pos:row for pos,row in enumerate(getattr(self,"_prepared_art_for_render",[]) or [])}
        for pos in range(self.page_size):
            title_widget=self["item_title%d"%pos];meta_widget=self["item_meta%d"%pos];art=self["art%d"%pos]
            if pos>=len(self.grid_items):
                title_widget.setText("");meta_widget.setText("")
                widgets=[art,title_widget,meta_widget]
                if self.media_type in ("vod","series"):
                    for _n in ("item_age%d"%pos,"item_year%d"%pos,"item_star%d"%pos,"item_score%d"%pos,"item_age_bg%d"%pos,"item_year_bg%d"%pos,"item_score_bg%d"%pos):
                        try:widgets.append(self[_n])
                        except Exception:pass
                try:widgets.append(self["card_chrome%d"%pos])
                except KeyError:pass  # skin has fewer chrome widgets than cells
                except Exception as exc:optional_failure("ui.silent_guard",exc)
                for widget in widgets:
                    try:widget.hide()
                    except Exception as exc:optional_failure("ui",exc)
                continue
            item=self.grid_items[pos];raw=item.get("name") or item.get("title") or item.get("id") or _("Result")
            prepared_titles=getattr(self,"_prepared_titles_for_render",[]) or []
            title=prepared_titles[pos] if pos<len(prepared_titles) else self._display_item_title(item,"Item")
            self._grid_display_titles[pos]=title
            prepared_fitted=getattr(self,"_prepared_fitted_for_render",[]) or []
            fitted_row=prepared_fitted[pos] if pos<len(prepared_fitted) else None
            if self.media_type=="itv":
                title_widget.setText((fitted_row[0] if fitted_row else one_line(title,36)))
            else:
                if fitted_row:
                    fitted_title,fitted_font=fitted_row
                else:
                    fitted_title,fitted_font=_grid_fit_card_title(title,226)
                title_widget.setText(fitted_title)
                try:
                    if title_widget.instance is not None:
                        title_widget.instance.setFont(_ultra_rfont("Regular",int(fitted_font)))
                except Exception as exc:optional_failure("ui.grid_title_autofit",exc)
            prepared_meta=getattr(self,"_prepared_meta_for_render",[]) or []
            _meta_text=prepared_meta[pos] if pos<len(prepared_meta) else self._card_meta(item,pos)
            meta_widget.setText(_meta_text)
            if self.media_type in ("vod","series"):
                self._card_rating_layout(item,pos,_meta_text)
            if self.media_type in ("vod","series"):
                try:
                    chrome=self["card_chrome%d"%pos]
                    if chrome.instance is not None:chrome.instance.setPixmapFromFile(self._grid_fixed_card_path())
                    chrome.show()
                except Exception as exc:optional_failure("ui.grid_neutral_card",exc)
            for widget in (art,title_widget):
                try:widget.show()
                except Exception as exc:optional_failure("ui",exc)
            if self.media_type not in ("vod","series"):
                try:meta_widget.show()
                except Exception as exc:optional_failure("ui",exc)
        visible_art=[]
        selected_row, selected_col = divmod(self.index, self.columns)
        light=bool(getattr(self,"_search_light_paint",False))
        if light:self._search_light_paint=False
        for pos,item in enumerate(self.grid_items[:self.page_size]):
            row, col = divmod(pos, self.columns)
            distance = abs(row - selected_row) + abs(col - selected_col)
            visible_art.append((distance, pos, item))
        visible_art.sort(key=lambda pair: (pair[0], pair[1]))
        if not light:
            for _distance,pos,item in visible_art:
                self._grid_request_art(pos,item,self.placeholder)
            if self.media_type in ("vod","series"):
                try:self._poll_visible_poster_cache_staged()
                except Exception as exc:optional_failure("ui.perflab9_cached_page_repaint",exc)
        self._update_selection()
        self._nav_burst_until=0.0
        if self.media_type in ("vod","series") and not light:
            try:self._grid_apply_current_selector(allow_build=True)
            except Exception as exc:optional_failure("ui.grid_initial_adaptive",exc)
        elif light:
            self._schedule_search_art()
        if self.media_type=="itv":
            _live_restart_trace("render_end",page=int(getattr(self,"page",0) or 0),index=int(getattr(self,"index",0) or 0),
                                generation=int(getattr(self,"_grid_generation",0) or 0),
                                slots=len(getattr(self,"_grid_slot_paths",{}) or {}),inflight=len(getattr(self,"_grid_download_inflight",{}) or {}))
        try:self._apply_card_progress()
        except Exception as exc:optional_failure("ui.card_progress_render",exc)
        self._prepared_titles_for_render=[];self._prepared_fitted_for_render=[];self._prepared_meta_for_render=[];self._prepared_art_for_render=[]

    def _schedule_search_art(self):
        """Let the remote work before posters and the side panel start."""
        timer=getattr(self,"_search_art_timer",None)
        if timer is None:
            timer=self._search_art_timer=eTimer()
            try:self._search_art_conn=timer.timeout.connect(self._run_deferred_search_art)
            except Exception:timer.callback.append(self._run_deferred_search_art)
        try:
            timer.stop();timer.start(60,True)
        except Exception:
            self._run_deferred_search_art()

    def _run_deferred_search_art(self):
        if getattr(self,"_screen_closed",False) or not self.grid_items:return
        selected_row,selected_col=divmod(int(getattr(self,"index",0) or 0),self.columns)
        order=[]
        for pos,item in enumerate(self.grid_items[:self.page_size]):
            row,col=divmod(pos,self.columns)
            order.append((abs(row-selected_row)+abs(col-selected_col),pos,item))
        order.sort()
        for _distance,pos,item in order:
            try:self._grid_request_art(pos,item,self.placeholder)
            except Exception:pass
        if self.media_type in ("vod","series"):
            try:self._poll_visible_poster_cache_staged()
            except Exception:pass
            try:self._grid_apply_current_selector(allow_build=True)
            except Exception:pass

    def _grid_fixed_card_path(self):
        """Card shown under every poster.  Adaptive OFF: the ONE bundled black card of
        the exact grid geometry (never replaced); ON: the neutral card shown until
        the poster's adaptive card arrives."""
        try:
            geom=getattr(self,"card_chrome_geometry",None)
            # R5.457: use the bundled unified shell immediately in both modes.
            # Adaptive replaces its tint only, never its shape or construction.
            if geom and tuple(geom) in ((236,418,354),(240,424,362)):
                path=asset("poster_card_fixed_%dx%d.png"%(int(geom[0]),int(geom[1])))
                if os.path.isfile(path):return path
            if not adaptive_enabled():
                geom=getattr(self,"card_chrome_geometry",None)
                if geom:
                    path=asset("poster_card_fixed_%dx%d.png"%(int(geom[0]),int(geom[1])))
                    if os.path.isfile(path):return path
                path=asset("poster_card_fixed_206x382.png")
                if os.path.isfile(path):return path
        except Exception as exc:optional_failure("ui.grid_fixed_card",exc)
        return asset(getattr(self,"_poster_neutral_card_asset","poster_card_full_neutral.png"))

    def _grid_compatible_card(self,path):
        """Reject pre-R5.457/other-grid shells retained in artwork bundles."""
        path=str(path or "")
        geom=getattr(self,"card_chrome_geometry",None)
        if geom and tuple(geom) in ((236,418,354),(240,424,362)):
            name=os.path.basename(path)
            tag="%dx%d"%(int(geom[0]),int(geom[1]))
            if name != "poster_card_fixed_%s.png"%tag and ("_%s_v9premium_"%tag) not in name:
                return ""
        return path

    def _card_rating_layout(self,item,pos,meta_text=None):
        """Render YEAR + packaged gold star + score without touching artwork/network.

        The three widgets are screen-resident, so navigation only changes text/visibility;
        the star pixmap itself is loaded once by the skin and stays stable like a label.
        """
        if self.media_type not in ("vod","series"):
            return False
        from .ui_grid_v2_premium import seed_badge_metadata
        seed_badge_metadata(self, item)
        try:
            year=int(self._folder_year_value(item) or 0)
            score=float(self._folder_rating_value(item))
        except Exception:
            year=0;score=-1.0
        try:
            meta=self["item_meta%d"%pos];aw=self["item_age%d"%pos];yw=self["item_year%d"%pos];sw=self["item_star%d"%pos];rw=self["item_score%d"%pos]
        except Exception:
            return False
        # Always reset both rendering paths before painting.  This prevents stale
        # Enigma2 surfaces from stacking after returning from Details/Player.
        try:meta.hide()
        except Exception:pass
        for w in (aw,yw,sw,rw):
            try:w.hide()
            except Exception:pass
        try:aw.setText("");yw.setText("");rw.setText("")
        except Exception:pass
        bgs={}
        for _k in ("age","year","score"):
            try:
                bgs[_k]=self["item_%s_bg%d"%(_k,pos)];bgs[_k].hide()
            except Exception:
                bgs[_k]=None
        age=display_certification(item.get("certification") or item.get("age_rating"))
        has_age=bool(age)
        has_year=year>0
        has_score=score>0.0
        if has_score and score>10.0:score=10.0
        if has_age:
            try:
                aw.setText(age);aw.show()
                if bgs.get("age") is not None:bgs["age"].show()
            except Exception:pass
        if has_year:
            try:
                yw.setText(str(year));yw.show()
                if bgs.get("year") is not None:bgs["year"].show()
            except Exception:pass
        if has_score:
            try:
                rw.setText("%.1f"%score);sw.show();rw.show()
                if bgs.get("score") is not None:bgs["score"].show()
            except Exception:pass
        if has_age or has_year or has_score:
            return True
        if meta_text is not None:
            try:meta.setText(meta_text)
            except Exception:pass
        try:meta.show()
        except Exception:pass
        return False

    def _refresh_favorite_button(self,item=None,state=None):
        """Reflect the selected item's cached favorite state on the green key.

        Navigation must stay RAM-only, so this deliberately uses _grid_item_state
        populated with the page instead of querying SQLite on every arrow press.
        """
        try:
            if item is None:
                if not self.grid_items:return
                item=self.grid_items[max(0,min(int(self.index),len(self.grid_items)-1))]
            if state is None:
                state=(getattr(self,"_grid_item_state",{}) or {}).get(id(item),{})
            favorite=bool((state or {}).get("favorite")) if isinstance(state,dict) else bool(state)
            self["green"].setText(_("Unfavorite") if favorite else _("Favorite"))
        except Exception as exc:
            optional_failure("ui.favorite_button_state",exc)

    def _card_meta(self,item,pos):
        bits=[]
        if self.media_type=="itv":
            absolute=max(1,(int(self.page or 1)-1)*int(self.page_size or 1)+int(pos)+1)
            return str(absolute)
        raw=item.get("name") or item.get("title") or ""
        state=self._grid_item_state.get(id(item),{})
        explicit=self._explicit_item_quality(item)
        cached=str(state.get("quality") or "")
        badges=(explicit or cached or quality_badges(raw)) if (self._grid_settings or {}).get("show_quality_badges", True) else ""
        if badges:bits.append(badges)
        if item.get("year"):bits.append(str(item.get("year"))[:4])
        if state.get("favorite"):bits.append("★")
        if state.get("completed") and (self._grid_settings or {}).get("show_watched",True):bits.append("WATCHED")
        elif state.get("position") and state.get("duration"):bits.append("%d%%"%min(99,int(state["position"]*100.0/state["duration"])))
        return "  •  ".join(bits)[:28]

    def _apply_card_progress(self):
        """Show/hide the per-card watch-progress bars from RAM state (no I/O)."""
        if self.media_type not in ("vod","series"):return
        shown=getattr(self,"_card_prog_shown",None)
        if not isinstance(shown,dict):
            shown={};self._card_prog_shown=shown
        show_watched=bool((self._grid_settings or {}).get("show_watched",True))
        for pos in range(int(self.page_size or 0)):
            frac=0.0
            if pos<len(self.grid_items):
                st=(getattr(self,"_grid_item_state",{}) or {}).get(id(self.grid_items[pos]),{}) or {}
                try:
                    if int(st.get("completed") or 0):
                        frac=1.0 if show_watched and self.media_type=="vod" else 0.0
                    elif st.get("position") and st.get("duration"):
                        frac=max(0.0,min(1.0,float(st["position"])/float(st["duration"])))
                except Exception:frac=0.0
            if 0.0<frac<0.02:frac=0.02
            key=int(round(frac*100))
            if shown.get(pos)==key:continue
            try:
                track=self["item_pt%d"%pos];fill=self["item_pf%d"%pos]
                if track.instance is None or fill.instance is None:continue
                if frac<=0.0:
                    track.hide();fill.hide();shown[pos]=key;continue
                size=track.instance.size()
                fill.instance.resize(eSize(max(2,int(size.width()*frac)),int(size.height())))
                track.show();fill.show();shown[pos]=key
            except Exception as exc:optional_failure("ui.card_progress",exc)

    def _update_selection(self):
        if not self.grid_items:return
        if not getattr(self,"_card_prog_shown",None):
            try:self._apply_card_progress()
            except Exception as exc:optional_failure("ui.card_progress_sel",exc)
        self.index=max(0,min(self.index,len(self.grid_items)-1))
        if self.media_type in ("vod","series"):
            try:self._reset_focus_heavy_artwork()
            except Exception as exc:optional_failure("ui.focus_heavy_nav_reset",exc)
        # Zero-work navigation rule: never touch poster/chrome pixmaps here.
        # Remember the old focused slot and restore it only after focus settles.
        try:
            prev_slot=int(getattr(self,"_grid_focus_chrome_slot",-1))
            if prev_slot>=0 and prev_slot!=self.index:self._grid_pending_prev_focus=prev_slot
        except Exception as exc:diagnostic_failure("ui.grid.failsoft.1344",exc)
        try:
            # Native coordinates were calculated once when the grid screen opened.
            # No getDesktop(), floating-point scale or geometry calculation per key.
            px,py=self._scaled_card_positions[self.index]
            self["selection"].instance.move(ePoint(px,py))
            self["selection"].show()
            if self.media_type in ("vod","series"):
                self["selection_adaptive"].instance.move(ePoint(px,py))
        except Exception as exc:optional_failure("ui",exc)
        self._remember_grid_state()
        self._update_header(self.grid_items[self.index])
        self._refresh_favorite_button(self.grid_items[self.index])
        if self.media_type in ("vod","series"):
            # if this title was already queued as a normal visible job,
            # promote that exact queued job to selected priority instead of
            # submitting duplicate TMDB work. This is RAM-only.
            try:
                selected_key=self._page_visual_key(self.grid_items[self.index])
                if selected_key:_FAST_POSTER_EXECUTOR.reprioritize("hydrate:%s"%selected_key,0)
            except Exception as exc:optional_failure("ui.selected_reprioritize",exc)
            # Selection colour follows the newly focused poster immediately.
            # This is cache-only on a warm card; a miss schedules one background
            # overlay build while leaving the previous overlay visible.
            try:self._grid_apply_current_selector()
            except Exception as exc:optional_failure("ui.grid_selector_immediate",exc)
            # Keep the cursor/header synchronous and cheap.  The adaptive
            # background/laser and selected-detail nudge are intentionally
            # delayed so a fast LEFT/RIGHT/UP/DOWN run does not spawn work for
            # every card crossed on the way.
            try:
                self._nav_burst_until=time.monotonic()+0.36
                self._grid_focus_timer.stop();self._grid_focus_timer.start(360,True)
                # Test69 Lean: no speculative Series hierarchy network call.
            except Exception:
                self._apply_debounced_grid_focus()
            try:self._detail_prefetch_timer.stop()
            except Exception as exc:optional_failure("ui",exc)
from .wqhd_layout import responsive_font as _ultra_rfont, factors as _ultra_factors

def _ultra_osd_scale():
    return _ultra_factors()[1]
