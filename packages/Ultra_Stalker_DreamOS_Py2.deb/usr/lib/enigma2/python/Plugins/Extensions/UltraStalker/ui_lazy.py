# -*- coding: utf-8 -*-
"""Load and configure each screen family once, preserving references to entry points."""
from __future__ import absolute_import
import threading
class ScreenRegistry(object):
    def __init__(self,namespace,payloads,dependencies):
        self.namespace=namespace;self.payloads=payloads;self.dependencies=dependencies
        self.loaded=set();self.loading=set();self.lock=threading.RLock();self.entrypoints={}
    def load(self,group):
        with self.lock:
            if group in self.loaded:return
            if group in self.loading:raise RuntimeError('Circular screen configuration: '+group)
            self.loading.add(group)
            try:
                for dependency in self.dependencies.get(group,()):self.load(dependency)
                code=compile(self.payloads[group],'<UltraStalker lazy '+group+'>','exec')
                eval(code,self.namespace,self.namespace)
                self.loaded.add(group)
            except BaseException:
                for name,entry in self.entrypoints.get(group,{}).items():self.namespace[name]=entry
                raise
            finally:self.loading.discard(group)
    def screen(self,group,name):
        def open_screen(session,*args,**kwargs):
            self.load(group)
            return self.namespace[name](session,*args,**kwargs)
        open_screen.__name__=str(name)
        open_screen.__doc__='Load '+name+' on first use.'
        self.entrypoints.setdefault(group,{})[name]=open_screen
        return open_screen
