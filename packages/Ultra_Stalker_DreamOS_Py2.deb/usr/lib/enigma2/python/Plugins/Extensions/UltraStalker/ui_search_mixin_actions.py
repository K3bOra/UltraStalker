# -*- coding: utf-8 -*-
"""Colour and direction key actions.

Methods moved verbatim out of ``PortalGlobalSearchScreen`` (ui_screens_search.py); behaviour is unchanged.
This module is imported by ui_screens_search.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals


class SearchActionsMixin(object):
    """Colour and direction key actions."""

    def _cancel_action(self):
        if self._source_picker_active:
            self._source_picker_back(); return
        if self._history_visible:
            try:self._history_overlay.close()
            except Exception:self._history_hide()
            return
        # Back from a Movies/Series bucket returns to the two Search cards,
        # preserving the query and the already-collected federated result set.
        if self.query and not getattr(self, "_search_gateway", False) and getattr(self, "_search_result_type", None):
            self._show_search_gateway()
            return
        self.close()

    def _green_action(self):
        if self._source_picker_active: return
        if self._history_visible:
            try:self._history_overlay.close()
            except Exception:self._history_hide()
        self.prompt()

    def _ok_action(self):
        if self._source_picker_active:
            self._source_picker_accept(); return
        if self._history_pick():return
        if getattr(self, "_search_gateway", False):
            self._open_search_gateway_bucket()
            return
        self.select()

    def _left_action(self):
        if self._source_picker_active:
            self._source_picker_step(-8); return
        if self._history_visible:return
        if getattr(self, "_search_gateway", False):
            self._move_search_gateway(-1);return
        self.move_left()

    def _right_action(self):
        if self._source_picker_active:
            self._source_picker_step(8); return
        if self._history_visible:return
        if getattr(self, "_search_gateway", False):
            self._move_search_gateway(1);return
        self.move_right()

    def _up_action(self):
        if self._source_picker_active:
            self._source_picker_step(-1); return
        if self._history_move(-1):return
        if getattr(self, "_search_gateway", False):
            self._move_search_gateway(-1);return
        self.page_left()

    def _down_action(self):
        if self._source_picker_active:
            self._source_picker_step(1); return
        if self._history_move(1):return
        if getattr(self, "_search_gateway", False):
            self._move_search_gateway(1);return
        self.page_right()
