# -*- coding: utf-8 -*-
"""Fast backdrop pipeline.

Methods moved verbatim out of ``PremiumGlobalCinematicScreen`` (ui_cinematic_global.py); behaviour is unchanged.
This module is imported by ui_cinematic_global.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, round, max, min
from .ui_cinematic_global import ArtworkV2, TMDBClient, _FAST_BACKDROP_META_EXECUTOR, _PILImage, _R242_FULLHD_EXECUTOR, _R242_FULLHD_LOCK, _R242_FULLHD_PENDING, _R242_FULLHD_ROOT, _catalogue_title, _shared_backdrop_path, _shared_cached_backdrop, _shared_fetch_backdrop, adaptive_enabled, deque, ensure_persistent_dirs, hdd_ready, load_settings, logging, optional_failure, os, re, tempfile, threading, time, weakref

class CineFastBdMixin(object):
    """Fast backdrop pipeline."""

    def _fast_bd_current_sig(self):
        try:
            if not self.grid_items:
                return ''
            return self._page_visual_key(self.grid_items[self.index])
        except Exception:
            return ''

    def _fast_bd_cancel(self, clear_file=False):
        deferred = getattr(self, '_fast_bd_deferred', None)
        if deferred is not None:
            try:
                if not getattr(deferred, 'called', False):
                    deferred.cancel()
            except Exception:
                pass
        self._fast_bd_deferred = None
        self._fast_bd_inflight = False
        if clear_file:
            path = str(getattr(self, '_fast_bd_path', '') or '')
            self._fast_bd_path = ''
            try:
                if path and path.startswith('/tmp/') and os.path.isfile(path):
                    os.unlink(path)
            except Exception:
                pass

    @staticmethod
    def _fast_bd_original_cache_path(url):
        """Shared Full-HD target, compatible with the existing Cinematic cache."""
        return _shared_backdrop_path(url)

    @staticmethod
    def _fast_bd_build_fullhd(raw_path, destination):
        """Recompress one downloaded ORIGINAL to at-most 1920x1080 JPEG q60.

        No crop, no artwork re-selection, no presentation overlay.  Aspect ratio is
        preserved and smaller originals are never upscaled.  This runs only in the
        dedicated R242 worker after native first paint has already won the screen.
        """
        raw_path = str(raw_path or '').strip()
        destination = str(destination or '').strip()
        if _PILImage is None or not raw_path or (not destination):
            return ''
        if not (os.path.isfile(raw_path) and os.path.getsize(raw_path) > 1024):
            return ''
        if not ensure_persistent_dirs(os.path.dirname(destination)):
            return ''
        temp = destination + '.tmp.%s.%s' % (os.getpid(), threading.get_ident())
        try:
            with _PILImage.open(raw_path) as image:
                try:
                    image.draft('RGB', (1920, 1080))
                except Exception:
                    pass
                image = image.convert('RGB')
                w, h = image.size
                if w < 16 or h < 16:
                    return ''
                scale = min(1.0, 1920.0 / float(w), 1080.0 / float(h))
                if scale < 0.999:
                    res = getattr(getattr(_PILImage, 'Resampling', _PILImage), 'LANCZOS', 1)
                    image = image.resize((max(1, int(round(w * scale))), max(1, int(round(h * scale)))), res)
                image.save(temp, 'JPEG', quality=60, subsampling=2, optimize=False, progressive=False)
            if not (os.path.isfile(temp) and os.path.getsize(temp) > 4096):
                return ''
            os.replace(temp, destination)
            return destination
        except Exception as exc:
            optional_failure('cinematic.r242_fullhd_build', exc)
            return ''
        finally:
            try:
                if os.path.exists(temp):
                    os.unlink(temp)
            except Exception:
                pass

    def _fast_bd_schedule_fullhd_store(self, raw_path, destination):
        """Persist after first paint and wait for remote navigation to go quiet."""
        raw_path = str(raw_path or '').strip()
        destination = str(destination or '').strip()
        if not raw_path or not destination:
            return
        if not (os.path.isfile(raw_path) and os.path.getsize(raw_path) > 1024):
            return
        with _R242_FULLHD_LOCK:
            if destination in _R242_FULLHD_PENDING:
                return
            _R242_FULLHD_PENDING.add(destination)
        owner = weakref.ref(self)

        def worker():
            try:
                deadline = time.monotonic() + 4.0
                while time.monotonic() < deadline:
                    screen = owner()
                    if screen is None:
                        break
                    try:
                        quiet = time.monotonic() - float(getattr(screen, '_cin_last_nav_at', 0.0) or 0.0) >= 0.85
                    except Exception:
                        quiet = True
                    if quiet:
                        break
                    time.sleep(0.2)
                CineFastBdMixin._fast_bd_build_fullhd(raw_path, destination)
            except Exception as exc:
                optional_failure('cinematic.r242_fullhd_store', exc)
            finally:
                with _R242_FULLHD_LOCK:
                    _R242_FULLHD_PENDING.discard(destination)
        try:
            _R242_FULLHD_EXECUTOR.submit(worker)
        except Exception:
            with _R242_FULLHD_LOCK:
                _R242_FULLHD_PENDING.discard(destination)

    @staticmethod
    def _fast_bd_local_full_quality(path):
        """Accept only a genuinely full-screen local source for direct paint.

        Legacy ArtworkV2 files may be w1280. R196 must not stretch those
        to 1920 anymore. A file in the dedicated ORIGINAL cache is trusted even
        when a rare TMDb original is itself narrower than 1920; otherwise inspect
        only the image header and require near-full-HD width.
        """
        path = str(path or '').strip()
        try:
            if not (path and os.path.isfile(path) and (os.path.getsize(path) > 1024)):
                return False
            root = os.path.abspath(_R242_FULLHD_ROOT) + os.sep
            absolute = os.path.abspath(path)
            if absolute.startswith(root) and re.match('^(?:[0-9a-f]{32}|(?:movie|tv)_\\d+)\\.jpg$', os.path.basename(absolute), re.I):
                return True
            if _PILImage is None:
                return False
            with _PILImage.open(path) as image:
                w, h = image.size
            return int(w) >= 1200 and int(h) >= 600
        except Exception:
            return False

    @classmethod
    def _fast_bd_clean_local_from_row(cls, row):
        """Return a sealed Clean Official local only when it is full quality."""
        row = row if isinstance(row, dict) else {}
        try:
            if int(row.get('clean_backdrop_selector_version') or 0) < 3:
                return ''
        except Exception:
            return ''
        path = str(row.get('backdrop_local') or '').strip()
        return path if cls._fast_bd_local_full_quality(path) else ''

    @staticmethod
    def _fast_bd_url_from_row(row):
        """Return only the sealed Clean Official TMDb ORIGINAL URL.

        Never paint a stored w1280 URL in Cinematic. If the manifest contains a
        TMDb file_path, rebuild the URL as ORIGINAL; otherwise rewrite a sealed
        image.tmdb.org URL in-place.
        """
        row = row if isinstance(row, dict) else {}
        try:
            if int(row.get('clean_backdrop_selector_version') or 0) < 3:
                return ''
        except Exception:
            return ''
        fp = str((row.get('manual_hq_backdrop_path') if row.get('manual_hq_backdrop_locked') else '') or row.get('backdrop_path') or '').strip()
        if fp.startswith('/'):
            try:
                return str(TMDBClient.image_url(fp, 'original') or '')
            except Exception:
                return ''
        if 'image.tmdb.org/t/p/' in fp:
            fp = re.sub('(/t/p/)(?:original|w\\d+|h\\d+)(/)', '\\1original\\2', fp, count=1, flags=re.I)
            if fp.startswith(('http://', 'https://')):
                return fp
        url_keys = ('manual_hq_backdrop_url', 'backdrop_url', '_backdrop_url', 'tmdb_backdrop_url') if row.get('manual_hq_backdrop_locked') else ('backdrop_url', '_backdrop_url', 'tmdb_backdrop_url')
        for key in url_keys:
            value = str(row.get(key) or '').strip()
            if 'image.tmdb.org/t/p/' not in value:
                continue
            value = re.sub('(/t/p/)(?:original|w\\d+|h\\d+)(/)', '\\1original\\2', value, count=1, flags=re.I)
            if value.startswith(('http://', 'https://')):
                return value
        return ''

    def _fast_bd_cached_original(self, url):
        return _shared_cached_backdrop(url)

    def _fast_bd_focus_stable(self, quiet_window=0.8):
        """True only after remote navigation has been quiet long enough.

        R197: adaptive/HDD colour work is forbidden during key-repeat.  The rail,
        title logo and fast backdrop may still move immediately, but the current
        adaptive remains held until focus settles.
        """
        try:
            return time.monotonic() - float(getattr(self, '_cin_last_nav_at', 0.0) or 0.0) >= float(quiet_window)
        except Exception:
            return False

    def _fast_bd_bind_local(self, path, sig, req_id=None, source='local'):
        """Direct native bind. No shared cache, Pillow, manifest or adaptive work."""
        try:
            if not self._fast_bd_enabled or self._screen_closed:
                return False
            if sig != self._fast_bd_current_sig():
                return False
            if req_id is not None and int(req_id) != int(self._fast_bd_req_id):
                return False
            path = str(path or '')
            if not (path and os.path.isfile(path) and (os.path.getsize(path) > 1024)):
                return False
            inst = self['cin_backdrop'].instance
            if inst is None:
                return False
            old = str(getattr(self, '_fast_bd_path', '') or '')
            inst.setPixmapFromFile(path)
            self['cin_backdrop'].show()
            self._cin_pixmap_paths['cin_backdrop'] = path
            self._fast_bd_path = path
            self._fast_bd_sig = sig
            self._fast_bd_locked_sig = sig
            self._fast_bd_locked_path = path
            elapsed = int((time.monotonic() - float(getattr(self, '_fast_bd_started_at', 0.0) or time.monotonic())) * 1000)
            logging.getLogger('UltraStalker').info('FAST_BACKDROP PAINT sig=%s source=%s elapsed_ms=%d path=%s', sig, source, elapsed, path)
            try:
                self._fast_bd_fast_store(sig, backdrop=path)
            except Exception as exc:
                optional_failure('cinematic.r199_fast_store_backdrop', exc)
            try:
                current = self.grid_items[self.index] if self.grid_items else {}
                if isinstance(current, dict):
                    current['_backdrop_source_local'] = path
                    current['_cin_provider_backdrop_local'] = path
                    current['_details_clean_backdrop_source'] = path
                    current['_details_clean_backdrop_locked'] = True
                    if adaptive_enabled() and self._fast_bd_focus_stable(0.55):
                        row = (getattr(self, '_cin_page_records', {}) or {}).get(int(self.index), {}) or self._record(current) or {}
                        self._cin_schedule_visuals(current, row)
            except Exception as exc:
                optional_failure('cinematic.r199_details_backdrop_handoff', exc)
            return True
        except Exception as exc:
            optional_failure('cinematic.fast_bd_bind', exc)
            return False

    def _fast_bd_fast_store(self, sig, backdrop=None):
        if not sig:
            return
        cache = getattr(self, '_fast_bd_fast_cache', None)
        order = getattr(self, '_fast_bd_fast_order', None)
        if not isinstance(cache, dict) or order is None:
            return
        entry = cache.get(sig) if isinstance(cache.get(sig), dict) else {}
        if backdrop and os.path.isfile(str(backdrop)):
            entry['backdrop'] = str(backdrop)
        cache[sig] = entry
        try:
            while sig in order:
                order.remove(sig)
            order.append(sig)
            limit = max(4, int(getattr(self, '_fast_bd_fast_limit', 12) or 12))
            while len(order) > limit:
                old = order.popleft()
                old_entry = cache.pop(old, None) or {}
                old_path = str(old_entry.get('backdrop') or '')
                if old_path.startswith('/tmp/us_r243_original_') and old_path != str(getattr(self, '_fast_bd_path', '') or ''):
                    try:
                        if os.path.isfile(old_path):
                            os.unlink(old_path)
                    except Exception:
                        pass
        except Exception:
            pass

    def _fast_bd_fast_cleanup(self):
        try:
            for entry in list((getattr(self, '_fast_bd_fast_cache', {}) or {}).values()):
                path = str((entry or {}).get('backdrop') or '')
                if path.startswith(('/tmp/us_r188_fast_bd_', '/tmp/us_r243_original_')):
                    try:
                        if os.path.isfile(path):
                            os.unlink(path)
                    except Exception:
                        pass
        finally:
            self._fast_bd_fast_cache = {}
            self._fast_bd_fast_order = deque()

    def _fast_bd_try_fast_warm(self, item, row=None):
        """Restore only the already-won clean backdrop for a revisited title."""
        try:
            sig = self._page_visual_key(item)
            entry = (getattr(self, '_fast_bd_fast_cache', {}) or {}).get(sig) or {}
            backdrop = str(entry.get('backdrop') or '')
            if not (backdrop and os.path.isfile(backdrop)):
                return False
            self._fast_bd_cancel(clear_file=False)
            self._fast_bd_req_id += 1
            self._fast_bd_started_at = time.monotonic()
            if not self._fast_bd_bind_local(backdrop, sig, req_id=self._fast_bd_req_id, source='r199-warm'):
                return False
            return True
        except Exception as exc:
            optional_failure('cinematic.r199_warm', exc)
            return False

    def _fast_bd_body_ready(self, body, req_id, sig, url):
        if not self._fast_bd_enabled:
            return None
        if int(req_id) != int(self._fast_bd_req_id) or sig != self._fast_bd_current_sig():
            return None
        self._fast_bd_inflight = False
        destination = self._fast_bd_original_cache_path(url)
        local_path = ''
        try:
            tail = str(url or '').split('?', 1)[0].lower()
            suffix = '.png' if tail.endswith('.png') else '.jpg'
            fd, local_path = tempfile.mkstemp(prefix='us_r243_original_', suffix=suffix, dir='/tmp')
            with os.fdopen(fd, 'wb') as handle:
                handle.write(body)
            painted = self._fast_bd_bind_local(local_path, sig, req_id=req_id, source='twisted-original-first-paint')
            if painted and destination and hdd_ready():
                self._fast_bd_schedule_fullhd_store(local_path, destination)
            if local_path != getattr(self, '_fast_bd_path', '') and local_path.startswith('/tmp/') and os.path.isfile(local_path):
                os.unlink(local_path)
        except Exception as exc:
            optional_failure('cinematic.fast_backdrop_body', exc)
            try:
                if local_path and local_path.startswith('/tmp/') and os.path.isfile(local_path):
                    os.unlink(local_path)
            except Exception:
                pass
        return None

    def _fast_bd_http_status(self, code, req_id, sig, url):
        if int(req_id) == int(self._fast_bd_req_id):
            self._fast_bd_inflight = False
        return None

    def _fast_bd_download_error(self, failure, req_id, sig, url):
        if int(req_id) == int(self._fast_bd_req_id):
            self._fast_bd_inflight = False
            self._fast_bd_deferred = None
        try:
            optional_failure('cinematic.fast_backdrop_download', failure)
        except Exception:
            pass
        return None

    def _fast_bd_start_url(self, url, sig):
        if not self._fast_bd_enabled or not url or sig != self._fast_bd_current_sig():
            return False
        cached = self._fast_bd_cached_original(url)
        if cached:
            self._fast_bd_cancel(clear_file=False)
            self._fast_bd_req_id += 1
            self._fast_bd_started_at = time.monotonic()
            return self._fast_bd_bind_local(cached, sig, req_id=self._fast_bd_req_id, source='local-cache')
        self._fast_bd_cancel(clear_file=False)
        self._fast_bd_req_id += 1
        req_id = int(self._fast_bd_req_id)
        self._fast_bd_sig = sig
        self._fast_bd_started_at = time.monotonic()
        self._fast_bd_inflight = True
        try:
            from twisted.internet.threads import deferToThread

            def _fetch_and_link():
                path = _shared_fetch_backdrop(url, 10)
                if path and os.path.isfile(path):
                    try:
                        cur_row = (getattr(self, '_cin_page_records', {}) or {}).get(int(self.index), {}) or {}
                        tid = cur_row.get('tmdb_id')
                        mt = str(cur_row.get('media_type') or ('tv' if str(self.media_type).lower() in ('series', 'tv') else 'movie'))
                        if tid:
                            from .media_library import item_paths as _ml_paths, save as _ml_save
                            c_bd = (_ml_paths(mt, tid) or {}).get('backdrop')
                            if c_bd and os.path.abspath(c_bd) != os.path.abspath(path):
                                if not (os.path.isfile(c_bd) and os.path.getsize(c_bd) > 4096):
                                    from .shared_tmdb_cache import materialize_backdrop
                                    materialize_backdrop(url, c_bd, 10)
                                _ml_save(mt, tid, {'backdrop_local': c_bd if os.path.isfile(c_bd) else path, 'backdrop_url': url, 'clean_backdrop_selector_version': 3})
                            if os.path.isfile(str(c_bd or '')) and os.path.getsize(str(c_bd)) > 4096:
                                return str(c_bd)
                    except Exception:
                        pass
                return path
            deferred = deferToThread(_fetch_and_link)
            self._fast_bd_deferred = deferred

            def ready(path):
                if not self._fast_bd_enabled or int(req_id) != int(self._fast_bd_req_id) or sig != self._fast_bd_current_sig():
                    return None
                self._fast_bd_inflight = False
                self._fast_bd_deferred = None
                if path:
                    self._fast_bd_bind_local(path, sig, req_id=req_id, source='shared-original-fullhd')
                return None
            deferred.addCallback(ready)
            deferred.addErrback(self._fast_bd_download_error, req_id, sig, url)
            return True
        except Exception as exc:
            self._fast_bd_deferred = None
            self._fast_bd_inflight = False
            optional_failure('cinematic.shared_backdrop_start', exc)
            return False

    def _fast_bd_meta_fallback(self, item, row, sig):
        """Resolve ONLY the Clean Official TMDb primary backdrop for first paint.

        If a verified TMDb id is already known, skip title search completely.
        Otherwise do the same tiny search needed to establish identity, then ask
        the title Details endpoint once. TMDb primary is the visible authority;
        Gallery is fallback-only when Details has no primary backdrop.
        """
        now = time.monotonic()
        retry_at = getattr(self, '_fast_bd_meta_retry_until', None)
        if retry_at is None:
            retry_at = {}
            self._fast_bd_meta_retry_until = retry_at
        if now < retry_at.get(sig, 0):
            return
        if len(retry_at) > 48:
            for old_key in list(retry_at):
                if retry_at.get(old_key, 0) <= now:
                    retry_at.pop(old_key, None)
            while len(retry_at) > 48:
                retry_at.pop(next(iter(retry_at)))
        if sig == str(getattr(self, '_fast_bd_meta_latest_sig', '') or ''):
            return
        self._fast_bd_meta_latest_sig = sig
        self._fast_bd_meta_pending.add(sig)
        item_copy = dict(item or {})
        row_copy = dict(row or {})
        media_type = self.media_type
        settings = getattr(self, '_grid_settings', None) or load_settings() or {}
        credential = str(settings.get('tmdb_credential') or '').strip()
        language = str(settings.get('tmdb_language') or 'en-US').strip() or 'en-US'
        timeout = min(7, max(3, int(settings.get('timeout', 7) or 7)))
        raw_title = self._rail_title(item_copy, row_copy) or str(row_copy.get('title') or row_copy.get('name') or item_copy.get('name') or item_copy.get('title') or '')
        title = _catalogue_title(raw_title) or str(raw_title or '').strip()
        year = None
        for value in (row_copy.get('year'), item_copy.get('year'), row_copy.get('release_date'), item_copy.get('release_date'), row_copy.get('first_air_date'), item_copy.get('first_air_date')):
            m = re.search('(?:19|20)\\d{2}', str(value or ''))
            if m:
                year = int(m.group(0))
                break

        def worker():
            found = dict(row_copy)

            def stale():
                if sig == self._fast_bd_current_sig():
                    return False
                self._fast_bd_meta_pending.discard(sig)
                if sig == str(getattr(self, '_fast_bd_meta_latest_sig', '') or ''):
                    self._fast_bd_meta_latest_sig = ''
                return True
            if stale():
                return
            try:
                if not credential:
                    self._fast_bd_meta_retry_until[sig] = time.monotonic() + 300
                    if not stale():
                        try:
                            self._cin_jobs.put({'kind': 'fast_backdrop_meta', 'sig': sig, 'row': found})
                        except Exception:
                            pass
                    return
                client = TMDBClient(credential, language, timeout)
                mt = 'tv' if str(media_type or '').lower() in ('series', 'tv') else 'movie'
                tid = None
                verified_row_id = row_copy.get('tmdb_id') if row_copy.get('identity_verified') or row_copy.get('identity_pointer_verified') else None
                for value in (verified_row_id, item_copy.get('_locked_tmdb_id'), item_copy.get('_ultra_search_verified_tmdb_id')):
                    try:
                        if value not in (None, ''):
                            tid = int(value)
                            break
                    except Exception:
                        pass
                _seed = {}
                if not tid:
                    resolver = ArtworkV2(credential, language, timeout)
                    _rmt, _rid, _conf, _source, _seed = resolver._resolve_identity(media_type, item_copy, hot=row_copy)
                    if _rid:
                        mt = str(_rmt or mt)
                        tid = int(_rid)
                    if stale():
                        return
                if not tid:
                    self._fast_bd_meta_retry_until[sig] = time.monotonic() + 300
                    if not stale():
                        try:
                            self._cin_jobs.put({'kind': 'fast_backdrop_meta', 'sig': sig, 'row': found})
                        except Exception:
                            pass
                    return
                fp = str((_seed if isinstance(_seed, dict) else {}).get('backdrop_path') or row_copy.get('backdrop_path') or '').strip()
                details = {}
                if not fp:
                    details = client._get('/%s/%s' % (mt, tid), {'append_to_response': 'images', 'include_image_language': 'null,en,%s' % str(language or 'en').split('-')[0]}) or {}
                    fp = str((details or {}).get('backdrop_path') or '').strip()
                choice = 'tmdb_primary' if fp else ''
                iso = ''
                images = details.get('images') if isinstance(details.get('images'), dict) else {}
                if not fp:
                    try:
                        from .backdrop_clean_runtime import rank_clean_backdrops
                        ranked = rank_clean_backdrops(images.get('backdrops') or [], language, 16)
                    except Exception:
                        ranked = []
                    if ranked:
                        pick = ranked[0]
                        fp = str(pick.get('file_path') or '')
                        iso = str(pick.get('iso_639_1') or '')
                        choice = 'gallery_fallback'
                if not fp:
                    self._fast_bd_meta_retry_until[sig] = time.monotonic() + 300
                if fp:
                    found['tmdb_id'] = tid
                    found['media_type'] = mt
                    found['backdrop_path'] = fp
                    found['backdrop_url'] = TMDBClient.image_url(fp, 'original')
                    found['clean_backdrop_selector_version'] = 3
                    found['clean_backdrop_choice'] = choice
                    found['clean_backdrop_iso'] = iso
                    found['identity_verified'] = True
                    try:
                        from .artwork_v2 import save_manifest as _fast_bd_save_manifest
                        _fast_bd_save_manifest(self.profile, media_type, item_copy, found)
                    except Exception:
                        pass
            except Exception as exc:
                self._fast_bd_meta_retry_until[sig] = time.monotonic() + 60
                optional_failure('cinematic.r193_clean_identity', exc)
            if stale():
                return
            try:
                self._cin_jobs.put({'kind': 'fast_backdrop_meta', 'sig': sig, 'row': found})
            except Exception:
                pass
        try:
            getattr(self, '_cin_fast_meta_executor', _FAST_BACKDROP_META_EXECUTOR).submit(worker, _task_key='cin-r193-meta:%x' % id(self), _replace_task_key=True)
            self._cin_kick_poll()
        except Exception as exc:
            self._fast_bd_meta_pending.discard(sig)
            if sig == str(getattr(self, '_fast_bd_meta_latest_sig', '') or ''):
                self._fast_bd_meta_latest_sig = ''
            optional_failure('cinematic.r193_clean_meta_submit', exc)

    def _fast_bd_schedule(self, item, row, resolved=None):
        if not self._fast_bd_enabled or self._screen_closed:
            return
        sig = self._page_visual_key(item)
        if not sig or sig != self._fast_bd_current_sig():
            return
        if self._fast_bd_try_fast_warm(item, row):
            return
        if str(getattr(self, '_fast_bd_locked_sig', '') or '') == sig:
            locked = str(getattr(self, '_fast_bd_locked_path', '') or '')
            if locked and os.path.isfile(locked):
                return
        merged = dict(row or {})
        if isinstance(resolved, dict):
            for k, v in resolved.items():
                if v not in (None, '', [], {}):
                    merged[k] = v
        local = self._fast_bd_clean_local_from_row(merged)
        if local:
            if str(getattr(self, '_fast_bd_sig', '') or '') == sig and str(getattr(self, '_fast_bd_path', '') or '') == local:
                return
            self._fast_bd_started_at = time.monotonic()
            self._fast_bd_req_id += 1
            self._fast_bd_bind_local(local, sig, req_id=self._fast_bd_req_id, source='clean-canonical')
            return
        url = self._fast_bd_url_from_row(merged)
        if url:
            if str(getattr(self, '_fast_bd_sig', '') or '') == sig:
                if bool(getattr(self, '_fast_bd_inflight', False)):
                    return
                current_path = str(getattr(self, '_fast_bd_path', '') or '')
                if current_path and os.path.isfile(current_path):
                    return
            self._fast_bd_start_url(url, sig)
            return
        self._fast_bd_meta_fallback(item, merged, sig)
