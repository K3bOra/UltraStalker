# -*- coding: utf-8 -*-
"""Progressive poster prefetch, TMDb metadata prefetch and catalogue warming.

Methods moved verbatim out of ``PremiumGridBase`` (ui_grid_base.py); behaviour is unchanged.
This module is imported by ui_grid_base.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, max, min
from .ui_grid_base import (
    _GRID_PAGE_WARM_EXECUTOR,
    _VISIBLE_TMDB_EXECUTOR,
    certification_from_tmdb,
    display_certification,
    os,
    rating_endpoint,
    reactor,
    threading,
    time,
)


class GridPrefetchMixin(object):
    """Progressive poster prefetch, TMDb metadata prefetch and catalogue warming."""

    def _stop_visible_rating_retry_timer(self):
        try:
            self._visible_rating_retry_queue = []
            timer = getattr(self, "_visible_rating_retry_timer", None)
            if timer is not None:
                timer.stop()
        except Exception as exc:
            optional_failure("ui.visible_rating_retry_stop", exc)
        for call in list(getattr(self, "_visible_rating_delayed_calls", []) or []):
            try:
                if call.active():
                    call.cancel()
            except Exception:
                pass
        self._visible_rating_delayed_calls = []

    def _dispose_visible_rating_retry_timer(self):
        self._stop_visible_rating_retry_timer()
        try:
            if getattr(self, "_visible_rating_retry_conn", None) is not None:
                self._visible_rating_retry_conn.disconnect()
                self._visible_rating_retry_conn = None
        except Exception:
            pass
        try:
            timer = getattr(self, "_visible_rating_retry_timer", None)
            if timer is not None and self._on_visible_rating_retry_timer in timer.callback:
                timer.callback.remove(self._on_visible_rating_retry_timer)
        except Exception:
            pass

    def _on_visible_rating_retry_timer(self):
        if getattr(self, "_screen_closed", False) or getattr(self, "_grid_images_suspended", False):
            return
        if self.media_type not in ("vod", "series") or not self.grid_items:
            return
        try:
            self._drain_visible_poster_results(4)
        except Exception:
            pass
        try:
            self._prefetch_visible_tmdb_metadata()
        except Exception as exc:
            optional_failure("ui.visible_rating_retry_tick", exc)
        try:
            self._async_set_poll_interval(120)
        except Exception:
            pass
        queue_delays = list(getattr(self, "_visible_rating_retry_queue", []) or [])
        if queue_delays:
            next_delay = int(queue_delays.pop(0) or 1000)
            self._visible_rating_retry_queue = queue_delays
            try:
                self._visible_rating_retry_timer.stop()
                self._visible_rating_retry_timer.start(max(100, next_delay), True)
            except Exception:
                pass

    def _schedule_visible_rating_sweeps(self):
        self._stop_visible_rating_retry_timer()
        if getattr(self, "_screen_closed", False) or getattr(self, "_grid_images_suspended", False) or self.media_type not in ("vod", "series") or not self.grid_items:
            return
        if not bool(getattr(self, "visible_card_rating_prefetch", False)):
            return
        try:
            # Delay metadata rating sweeps until initial visible posters have been decoded by ePicLoad
            self._visible_rating_retry_queue = [2200]
            timer = getattr(self, "_visible_rating_retry_timer", None)
            if timer is not None:
                timer.stop()
                timer.start(850, True)
        except Exception as exc:
            optional_failure("ui.visible_rating_etimer_schedule", exc)

    def _stop_progressive_poster_prefetch(self):
        try:self._progressive_poster_cancel.set()
        except Exception as exc:optional_failure("ui.progressive_poster_stop",exc)
        self._progressive_poster_started=False

    def _stop_focus_heavy_artwork(self):
        """Cancel only the selected title full-artwork job.

        Visible poster page hydration uses its own bounded lane and is deliberately
        left alone so the 14 on-screen cards can keep filling while navigation
        remains responsive.
        """
        try:self._focus_art_cancel.set()
        except Exception:pass
        try:
            future=getattr(self,"_focus_art_future",None)
            if future is not None:future.cancel()
        except Exception:pass
        self._focus_art_future=None

    def _reset_focus_heavy_artwork(self):
        self._stop_focus_heavy_artwork()
        try:self._focus_art_token=int(getattr(self,"_focus_art_token",0) or 0)+1
        except Exception:self._focus_art_token=1
        self._focus_art_cancel=threading.Event()

    def _start_progressive_poster_prefetch(self):
        """Start lazy hydration for the current visible page only."""
        if self._screen_closed or getattr(self,"_grid_images_suspended",False) or self.media_type not in ("vod","series") or not self.grid_items:
            return
        self._progressive_poster_started=True
        # PERFLAB12: hydrate every visible poster through the existing bounded
        # 3-worker lane, but do NOT start page-wide TMDb metadata/background
        # full-artwork work. Heavy metadata/backdrop belongs to stable focus only.
        try:self._prefetch_visible_page_details(priority_index=self.index,max_items=self.page_size)
        except Exception as exc:optional_failure("ui.auto_visible_page_start",exc)

    def _prefetch_visible_tmdb_metadata(self):
        """Fill missing visible-card TMDb ratings and age certifications automatically.

        Uses the same fast Details Authority metadata lane as stable focus so every
        visible card on the page displays its rating, year, age rating, and seasons
        without requiring the user to stand on each card.
        """
        if self._screen_closed or getattr(self,"_grid_images_suspended",False) or self.media_type not in ("vod","series") or not self.grid_items:
            return
        generation=int(getattr(self,"_page_prefetch_generation",0) or 0)
        cancel_event=getattr(self,"_page_prefetch_cancel",None)
        if cancel_event is not None and cancel_event.is_set():
            self._page_prefetch_cancel = cancel_event = threading.Event()
        profile=dict(self.profile or {})
        media_type=str(self.media_type or "")
        cfg=dict(self._grid_settings or {})
        credential=str(cfg.get("tmdb_credential") or "").strip()
        tmdb_enabled=bool(cfg.get("tmdb_enabled",True) and credential)
        client=getattr(self,"client",None)
        result_q=self._art_prefetch_jobs
        pending_set=self._visible_tmdb_pending
        pending_lock=self._page_prefetch_lock
        with pending_lock:
            in_flight=sum(1 for key in pending_set if key[0]==generation)
        if in_flight>=3:return
        batch_budget=3-in_flight
        attempts=getattr(self,"_visible_tmdb_attempts",None)
        if attempts is None:attempts={};self._visible_tmdb_attempts=attempts
        if len(attempts)>max(64,self.page_size*4):
            attempts={key:value for key,value in attempts.items() if key[0]==generation}
            self._visible_tmdb_attempts=attempts
        rating_cache=self._visible_tmdb_rating_cache
        need_age=bool(getattr(self,"visible_card_age_prefetch",True))

        selected=[]
        center=max(0,min(int(getattr(self,"index",0) or 0),len(self.grid_items)-1))
        rows=list(enumerate(self.grid_items[:self.page_size]))
        rows.sort(key=lambda pair:(abs(pair[0]-center),pair[0]))
        for pos,item in rows:
            if not isinstance(item,dict):
                continue
            key=self._page_visual_key(item)
            if not key:
                continue
            try:
                from .ui_grid_v2_premium import seed_badge_metadata
                seed_badge_metadata(self,item)
            except Exception:
                pass
            try:
                self._age_cache_seed_item(item)
            except Exception as exc:
                optional_failure("ui.age_cache_prefetch_seed",exc)
            try:
                existing=float(item.get("_tmdb_rating") or 0)
            except Exception:
                existing=0.0
            if not (0.0 < existing <= 10.0):
                try:
                    existing=float(rating_cache.get(key) or 0)
                    if 0.0 < existing <= 10.0:
                        item["_tmdb_rating"]=existing
                except Exception:
                    existing=0.0
            if not (0.0 < existing <= 10.0):
                try:
                    _fallback_r=float(self._folder_rating_value(item) or 0)
                    if 0.0 < _fallback_r <= 10.0:
                        existing=_fallback_r
                except Exception:
                    pass
            try:
                existing_year=int(self._folder_year_value(item) or 0)
            except Exception:
                existing_year=0
            existing_age=str(item.get("certification") or item.get("age_rating") or "").strip()
            age_ready=bool(display_certification(existing_age) or (not existing_age and item.get("_age_rating_checked")))
            seasons_ready=not (getattr(self,"premium_v2_badges",False) and self.media_type=="series") or any(item.get(k) is not None for k in ("number_of_seasons","seasons_count","season_count"))
            if existing > 0.0 or existing_year > 0 or age_ready or (self.media_type=="series" and seasons_ready):
                try:
                    self._card_rating_layout(item,pos,self._card_meta(item,pos))
                except Exception:
                    pass
            try:
                tmdb_score_ready = 0.0 < float(item.get("_tmdb_rating") or 0) <= 10.0
            except Exception:
                tmdb_score_ready = False
            if tmdb_score_ready and existing_year > 0 and (not need_age or age_ready) and seasons_ready:
                continue
            pending_key=(generation,key)
            if attempts.get(pending_key,0)>=2:continue
            try:
                with pending_lock:
                    if pending_key in pending_set:
                        continue
                    pending_set.add(pending_key)
            except Exception:
                continue
            selected.append((pos,dict(item),key,pending_key))

        if not selected:
            return
        with pending_lock:
            for unused_pos,unused_item,unused_key,pk in selected[batch_budget:]:pending_set.discard(pk)
        selected=selected[:batch_budget]
        for unused_pos,unused_item,unused_key,pk in selected:attempts[pk]=attempts.get(pk,0)+1
        def continue_visible_batch():
            if self._screen_closed or getattr(self,"_grid_images_suspended",False):return
            if generation!=int(getattr(self,"_page_prefetch_generation",0) or 0):return
            try:self._drain_visible_poster_results(limit=1)
            except Exception:pass
            self._prefetch_visible_tmdb_metadata()
        def batch_completed(done):
            try:reactor.callFromThread(continue_visible_batch)
            except Exception:pass
        try:
            import logging
            logging.getLogger("UltraStalker").info(
                "PERF49 rating_page_begin media=%s mode=%s page=%d missing=%d visible=%d",
                media_type,self.__class__.__name__,int(getattr(self,"page",0) or 0),len(selected),len(rows)
            )
        except Exception:
            pass

        for pos,it,key,pending_key in selected:
            def worker(it=dict(it), k=key, gen=generation, cancel=cancel_event, pk=pending_key, slot=pos):
                t0=time.monotonic()
                ok=False
                source="none"
                age_lookup_checked=False
                published = []
                def _score_of(d):
                    if not isinstance(d, dict):
                        return None
                    for _sk in ("_tmdb_rating", "vote_average", "rating", "rating_imdb", "imdb_rating"):
                        _sv = d.get(_sk)
                        if _sv not in (None, "", 0, "0", False, True):
                            try:
                                import re as _re
                                _m = _re.search(r"\d+(?:\.\d+)?", str(_sv))
                                if _m:
                                    _fv = float(_m.group(0))
                                    if 0.0 < _fv <= 10.0:
                                        return _fv
                            except Exception:
                                pass
                    return None
                def publish_ready(data):
                    # Publish independent fields before optional age/seasons HTTP reads.
                    if cancel is not None and cancel.is_set():
                        return
                    data = data or {}
                    age = str(data.get("certification") or data.get("age_rating") or "").strip()
                    score_val = _score_of(data)
                    meta = {
                        "tmdb_id": data.get("tmdb_id"),
                        "identity_verified": bool(data.get("identity_verified") or data.get("identity_pointer_verified") or data.get("matched") or data.get("tmdb_id")),
                        "media_type": data.get("media_type") or ("tv" if media_type=="series" else "movie"),
                        "rating": score_val if score_val is not None else (data.get("rating") or data.get("vote_average")),
                        "year": data.get("year") or data.get("release_date") or data.get("first_air_date"),
                        "release_date": data.get("release_date") or data.get("first_air_date") or "",
                        "certification": age, "age_rating": age,
                        "_age_rating_checked": bool(data.get("_age_rating_checked") or display_certification(age)),
                        "number_of_seasons": next((data[k] for k in ("number_of_seasons","seasons_count","season_count") if data.get(k) is not None),None),
                    }
                    signature = tuple(str(meta.get(f) or "") for f in sorted(meta))
                    if (meta.get("rating") or meta.get("year") or display_certification(age) or meta.get("_age_rating_checked") or meta.get("number_of_seasons") is not None) and signature not in published:
                        published.append(signature)
                        result_q.put((gen,k,"",meta))
                try:
                    if cancel is not None and cancel.is_set():
                        return False
                    resolver=None
                    data={}
                    try:
                        local=load_artwork_v2_manifest(profile,media_type,it) or {}
                        if isinstance(local,dict) and local:
                            data=dict(local)
                            if data.get("tmdb_id"):
                                source="local"
                    except Exception:
                        data={}
                    try:
                        from .details_authority import load_canonical as _da_load_canonical
                        canon=_da_load_canonical(profile,media_type,it) or {}
                        if isinstance(canon,dict) and canon:
                            merged_local=dict(data)
                            for _ck,_cv in canon.items():
                                if _cv not in (None,"",[],{}):
                                    merged_local[_ck]=_cv
                            data=merged_local
                            if data.get("tmdb_id") and source=="none":
                                source="canonical_local"
                    except Exception:
                        pass
                    if data:
                        publish_ready(data)

                    def _needs_more(d):
                        d = d or {}
                        _sc = _score_of(d) or 0.0
                        try:
                            _yr = bool(self._folder_year_value(d) > 0)
                        except Exception:
                            _yr = False
                        _ag = str(d.get("certification") or d.get("age_rating") or "").strip()
                        _ag_ok = bool(not need_age or display_certification(_ag) or (not _ag and d.get("_age_rating_checked")))
                        _se_ok = bool(media_type != "series" or any(d.get(_sk) is not None for _sk in ("number_of_seasons","seasons_count","season_count")))
                        return not (0.0 < _sc <= 10.0 and _yr and _ag_ok and _se_ok)

                    # Fast Details Authority lane (exact same resolver used by Spotlight / Details when standing on a card)
                    if _needs_more(data) and not (cancel is not None and cancel.is_set()):
                        try:
                            from .details_authority import resolve_metadata_fast as _da_resolve_fast
                            fast_row=_da_resolve_fast(
                                profile,media_type,dict(it),current=dict(data or {}),
                                cancel_event=cancel,settings=cfg,provider_client=client
                            ) or {}
                            if isinstance(fast_row,dict) and fast_row:
                                merged=dict(data)
                                for _fk,_fv in fast_row.items():
                                    if _fv not in (None,"",[],{}):
                                        merged[_fk]=_fv
                                if fast_row.get("_age_rating_checked"):
                                    merged["_age_rating_checked"]=True
                                    age_lookup_checked=True
                                data=merged
                                source="details_authority_fast"
                                publish_ready(data)
                        except Exception as exc:
                            optional_failure("ui.visible_details_authority_fast",exc)

                    if not data.get("tmdb_id") and tmdb_enabled and not getattr(self, "_progressive_poster_started", False) and not (cancel is not None and cancel.is_set()):
                        try:
                            resolver=ArtworkV2(
                                credential,
                                cfg.get("tmdb_language","ar-EG"),
                                min(5,max(3,int(cfg.get("timeout",10) or 10)))
                            )
                            resolved=resolver.resolve(profile,media_type,it,full=False,cancel_event=cancel) or {}
                            if isinstance(resolved,dict) and resolved:
                                merged=dict(data)
                                for _rk,_rv in resolved.items():
                                    if _rv not in (None,""):
                                        merged[_rk]=_rv
                                data=merged
                                source="artwork_v2"
                                publish_ready(data)
                        except Exception as exc:
                            optional_failure("ui.visible_tmdb_metadata",exc)
                    _score = _score_of(data) or 0.0
                    try:
                        _year_ok=bool(self._folder_year_value(data)>0)
                    except Exception:
                        _year_ok=False
                    _cur_age=str(data.get("certification") or data.get("age_rating") or "").strip()
                    _age_ok=bool(not need_age or display_certification(_cur_age) or (not _cur_age and data.get("_age_rating_checked")))
                    _seasons_ok=bool(media_type!="series" or any(data.get(_sk) is not None for _sk in ("number_of_seasons","seasons_count","season_count")))
                    if tmdb_enabled and data.get("tmdb_id") and (not (0.0 < _score <= 10.0) or not _year_ok or not _age_ok or not _seasons_ok):
                        try:
                            _mt=str(data.get("media_type") or ("tv" if media_type=="series" else "movie"))
                            _tmdb_client=resolver.tmdb if resolver is not None else None
                            if _tmdb_client is None:
                                from .tmdb import TMDBClient as _DirectTMDBClient
                                _tmdb_client=_DirectTMDBClient(credential,cfg.get("tmdb_language","ar-EG"),min(5,max(3,int(cfg.get("timeout",10) or 10))))
                            _append="content_ratings" if _mt=="tv" else "release_dates"
                            details=_tmdb_client._get("/%s/%s"%(_mt,data.get("tmdb_id")),{"language":cfg.get("tmdb_language","ar-EG"),"append_to_response":_append}) or {}
                            if isinstance(details,dict) and details:
                                merged=dict(data)
                                _date=details.get("first_air_date") if _mt=="tv" else details.get("release_date")
                                if details.get("number_of_seasons") is not None:
                                    merged["number_of_seasons"]=details["number_of_seasons"]
                                if details.get("vote_average") not in (None,""):
                                    merged["rating"]=details.get("vote_average")
                                if details.get("vote_count") not in (None,""):
                                    merged["vote_count"]=details.get("vote_count")
                                if _date:
                                    merged["release_date"]=_date
                                    merged["year"]=_date
                                if "release_dates" in details or "content_ratings" in details:
                                    _cert_raw=certification_from_tmdb(details,_mt) or ""
                                    merged["certification"]=_cert_raw
                                    merged["age_rating"]=_cert_raw
                                    merged["_age_rating_checked"]=True
                                    age_lookup_checked=True
                                data=merged
                                source="tmdb_id"
                                try:
                                    from .artwork_v2 import save_manifest as _r60_save_manifest
                                    _r60_save_manifest(profile,media_type,it,data)
                                except Exception as _save_exc:
                                    optional_failure("ui.r60_metadata_manifest",_save_exc)
                        except Exception as exc:
                            optional_failure("ui.visible_tmdb_details_by_id",exc)
                    publish_ready(data)
                    _r61_score = _score_of(data) or 0.0
                    try:
                        _r61_year=bool(self._folder_year_value(data or {})>0)
                    except Exception:
                        _r61_year=False
                    _r61_age=str((data or {}).get("certification") or (data or {}).get("age_rating") or "").strip()
                    _r61_age_ready=bool(display_certification(_r61_age) or (not _r61_age and (data or {}).get("_age_rating_checked")))

                    if tmdb_enabled and need_age and not _r61_age_ready and (data or {}).get("tmdb_id"):
                        try:
                            _age_mt=str((data or {}).get("media_type") or ("tv" if media_type=="series" else "movie"))
                            _age_id=int((data or {}).get("tmdb_id"))
                            _age_client=None
                            try:_age_client=resolver.tmdb
                            except Exception:_age_client=None
                            if _age_client is None:
                                from .tmdb import TMDBClient as _AgeTMDBClient
                                _age_client=_AgeTMDBClient(credential,cfg.get("tmdb_language","ar-EG"),min(5,max(3,int(cfg.get("timeout",10) or 10))))
                            _age_payload=_age_client._get(rating_endpoint(_age_mt,_age_id)) or {}
                            _age_raw=certification_from_tmdb(data or {},_age_mt,supplemental=_age_payload)
                            age_lookup_checked=True
                            merged=dict(data or {})
                            if _age_raw:
                                merged["certification"]=_age_raw;merged["age_rating"]=_age_raw
                            else:
                                merged["certification"]="";merged["age_rating"]=""
                            merged["_age_rating_checked"]=True
                            data=merged
                            _r61_age=str(_age_raw or "")
                            _r61_age_ready=bool(display_certification(_r61_age) or not _r61_age)
                            source="tmdb_age_exact"
                        except Exception as exc:
                            optional_failure("ui.visible_tmdb_age_exact",exc)
                    if tmdb_enabled and not (0.0 < _r61_score <= 10.0 and _r61_year and (not need_age or _r61_age_ready)):
                        try:
                            from .tmdb import TMDBClient
                            fallback=TMDBClient(
                                credential,
                                cfg.get("tmdb_language","ar-EG"),
                                min(5,max(3,int(cfg.get("timeout",10) or 10)))
                            ).enrich(media_type,it,artwork_mode="metadata") or {}
                            if isinstance(fallback,dict) and fallback:
                                merged=dict(data or {})
                                for _fk,_fv in fallback.items():
                                    if _fv not in (None,""):
                                        merged[_fk]=_fv
                                data=merged
                                source="tmdb"
                                if need_age and (fallback.get("tmdb_id") or fallback.get("matched")):
                                    age_lookup_checked=True
                                if data.get("tmdb_id"):
                                    try:
                                        from .artwork_v2 import save_manifest as _fb_save_manifest
                                        _fb_save_manifest(profile,media_type,it,data)
                                    except Exception:
                                        pass
                        except Exception as exc:
                            optional_failure("ui.visible_tmdb_metadata_fallback",exc)
                    if cancel is not None and cancel.is_set():
                        return False
                    # Final provider-level fallback for score/year/age if TMDb left them blank
                    if not _score_of(data):
                        _prov_score = _score_of(it)
                        if _prov_score:
                            data = dict(data or {})
                            data["rating"] = _prov_score
                    if not self._folder_year_value(data or {}):
                        _prov_year = self._folder_year_value(it)
                        if _prov_year > 0:
                            data = dict(data or {})
                            data["year"] = _prov_year
                    if not (data or {}).get("certification") and not (data or {}).get("age_rating"):
                        _prov_age = str(it.get("certification") or it.get("age_rating") or "").strip()
                        if display_certification(_prov_age):
                            data = dict(data or {})
                            data["certification"] = _prov_age
                            data["age_rating"] = _prov_age
                    _meta_age=str(data.get("certification") or data.get("age_rating") or "").strip()
                    _meta_age_display=display_certification(_meta_age)
                    if need_age and not _meta_age_display and age_lookup_checked:
                        _meta_age=""
                    _meta_age_checked=bool(
                        _meta_age_display or
                        (not _meta_age and (age_lookup_checked or data.get("_age_rating_checked")))
                    )
                    publish_ready(data)
                    if getattr(self,"premium_v2_badges",False) and media_type=="series":
                        cached_detail={}
                        try:
                            from .persistent_cache import load_detail_snapshot
                            cached_detail=load_detail_snapshot(profile,media_type,it) or {}
                            known=str(data.get("tmdb_id") or it.get("_locked_tmdb_id") or "")
                            cached_id=str(cached_detail.get("tmdb_id") or "")
                            if not (known and cached_id and known!=cached_id):
                                count=cached_detail.get("number_of_seasons") or cached_detail.get("seasons_count") or cached_detail.get("season_count")
                                if count is not None:data["number_of_seasons"]=count
                        except Exception:pass
                        if tmdb_enabled and data.get("number_of_seasons") is None and data.get("tmdb_id") and not (cancel is not None and cancel.is_set()):
                            try:
                                from .tmdb import TMDBClient
                                from .media_library import save as save_metadata
                                details=TMDBClient(credential,cfg.get("tmdb_language","ar-EG"),3)._get("/tv/%s"%data["tmdb_id"],{"language":cfg.get("tmdb_language","ar-EG")}) or {}
                                if details.get("number_of_seasons") is not None:
                                    data["number_of_seasons"]=details["number_of_seasons"]
                                    save_metadata("tv",data["tmdb_id"],{"number_of_seasons":data["number_of_seasons"]})
                            except Exception:pass
                    if data.get("tmdb_id") and not (cancel is not None and cancel.is_set()):
                        try:
                            from .media_library import save as _save_global_meta
                            _g_mt = str(data.get("media_type") or ("tv" if media_type=="series" else "movie"))
                            _g_update = {}
                            for _gk in ("rating","vote_average","vote_count","year","release_date","first_air_date","certification","age_rating","_age_rating_checked","number_of_seasons","seasons_count","season_count"):
                                if data.get(_gk) not in (None,"",[],{}):
                                    _g_update[_gk] = data.get(_gk)
                            if _meta_age_checked:
                                _g_update["_age_rating_checked"] = True
                                if _meta_age:
                                    _g_update["certification"] = _meta_age
                                    _g_update["age_rating"] = _meta_age
                            if _g_update:
                                _g_update["identity_verified"] = True
                                _save_global_meta(_g_mt, data.get("tmdb_id"), _g_update)
                        except Exception:
                            pass
                    final_score = _score_of(data)
                    meta={
                        "tmdb_id":data.get("tmdb_id"),
                        "identity_verified":bool(data.get("identity_verified") or data.get("identity_pointer_verified") or data.get("matched") or data.get("tmdb_id")),
                        "media_type":data.get("media_type") or ("tv" if media_type=="series" else "movie"),
                        "rating":final_score if final_score is not None else (data.get("rating") or data.get("vote_average")),
                        "year":data.get("year") or data.get("release_date") or data.get("first_air_date"),
                        "release_date":data.get("release_date") or data.get("first_air_date") or "",
                        "certification":_meta_age,
                        "age_rating":_meta_age,
                        "_age_rating_checked":_meta_age_checked,
                        "number_of_seasons":next((data[k] for k in ("number_of_seasons","seasons_count","season_count") if data.get(k) is not None),None),
                        "palette_source":"",
                    }
                    if meta.get("tmdb_id") or meta.get("rating") or meta.get("year") or meta.get("certification") or meta.get("_age_rating_checked") or meta.get("number_of_seasons") is not None:
                        result_q.put((gen,k,"",meta))
                        ok=True
                        return True
                    return False
                finally:
                    try:
                        with pending_lock:
                            pending_set.discard(pk)
                    except Exception:
                        pass
                    try:
                        import logging
                        logging.getLogger("UltraStalker").info(
                            "PERF52 rating_item_done media=%s page=%d slot=%d ok=%s source=%s elapsed_ms=%d",
                            media_type,int(getattr(self,"page",0) or 0),int(slot),bool(ok),str(source),int((time.monotonic()-t0)*1000)
                        )
                    except Exception:
                        pass

            try:
                future=_VISIBLE_TMDB_EXECUTOR.submit(worker,priority=(0 if pos==center else 1),_task_key="grid-tmdb:%x:%s:%s"%(id(self),generation,key))
                self._page_prefetch_futures.append(future)
                def release_unstarted(done, pk=pending_key):
                    if done.cancelled() or done.exception() is not None:
                        with pending_lock:
                            pending_set.discard(pk)
                future.add_done_callback(release_unstarted)
                future.add_done_callback(batch_completed)
            except Exception as exc:
                try:
                    with pending_lock:
                        pending_set.discard(pending_key)
                except Exception:
                    pass
                optional_failure("ui.visible_tmdb_metadata_submit",exc)
        try:
            self._async_set_poll_interval(120)
        except Exception:
            pass

    def _prefetch_focused_artwork(self):
        """Hydrate poster + real backdrop for the stable focused title only."""
        if self._screen_closed or getattr(self,"_grid_images_suspended",False) or self.media_type not in ("vod","series") or not self.grid_items:
            return
        try:item=self.grid_items[max(0,min(self.index,len(self.grid_items)-1))]
        except Exception:return
        if not isinstance(item,dict):return
        cfg=self._grid_settings or {};credential=str(cfg.get("tmdb_credential") or "").strip()
        if not cfg.get("load_images",True):return
        key=self._page_visual_key(item)
        generation=int(getattr(self,"_page_prefetch_generation",0) or 0)
        token=int(getattr(self,"_focus_art_token",0) or 0)
        cancel_event=getattr(self,"_focus_art_cancel",None)
        profile=dict(self.profile or {});media_type=str(self.media_type or "")
        result_q=self._art_prefetch_jobs
        def hydrate_focus(it=dict(item),k=key,gen=generation,focus_token=token,cancel=cancel_event):
            if cancel is not None and cancel.is_set():return False
            try:
                if not credential:
                    return False
                for _wait_step in range(12):
                    if self._screen_closed or (cancel is not None and cancel.is_set()) or focus_token!=int(getattr(self,"_focus_art_token",0) or 0):
                        return False
                    if not getattr(self,"_visible_poster_in_flight",None):
                        break
                    time.sleep(0.05)
                if cfg.get("tmdb_enabled",True):
                    data=ArtworkV2(credential,cfg.get("tmdb_language","ar-EG"),min(6,max(3,int(cfg.get("timeout",10) or 10)))).resolve(
                        profile,media_type,it,full=True,cancel_event=cancel) or {}
                else:
                    return False
                if cancel is not None and cancel.is_set():return False
                if focus_token!=int(getattr(self,"_focus_art_token",0) or 0):return False
                poster=str(data.get("poster_local") or "")
                if (poster and os.path.isfile(poster) or data.get("tmdb_id") or data.get("rating") or data.get("vote_average") or data.get("certification")) and gen==int(getattr(self,"_page_prefetch_generation",0) or 0):
                    result_q.put((gen,k,poster if poster and os.path.isfile(poster) else "",{
                        "tmdb_id":data.get("tmdb_id"),
                        "media_type":data.get("media_type") or ("tv" if media_type=="series" else "movie"),
                        "rating":data.get("rating") or data.get("vote_average"),
                        "year":data.get("year") or data.get("release_date") or data.get("first_air_date"),
                        "release_date":data.get("release_date") or data.get("first_air_date") or "",
                        "certification":data.get("certification") or data.get("age_rating") or "",
                        "age_rating":data.get("age_rating") or data.get("certification") or "",
                        "_age_rating_checked":bool(data.get("_age_rating_checked") or data.get("certification") or data.get("age_rating")),
                        "number_of_seasons":data.get("number_of_seasons"),
                        "backdrop_local":data.get("backdrop_local"),
                        "provider_locked":bool(data.get("provider_locked") or data.get("provider_bootstrap")),
                        "palette_source":poster if poster and os.path.isfile(poster) else "",
                    }))
                return bool(data.get("poster_local") or data.get("backdrop_local"))
            except Exception as exc:
                if not (cancel is not None and cancel.is_set()):optional_failure("ui.auto_focused_artwork",exc)
                return False
        try:
            future=_DETAIL_PREFETCH_EXECUTOR.submit(hydrate_focus,priority=0,_task_key="focus-art:%x:%s"%(id(self),token))
            self._focus_art_future=future
        except Exception as exc:optional_failure("ui.auto_focused_art_submit",exc)

    def _refresh_prepared_m3u_art_from_hdd(self,payload):
        """Refresh a prepared M3U page from HDD only, never network."""
        if not self._grid_is_m3u_source() or self.media_type not in ("vod","series") or not isinstance(payload,dict):
            return payload
        items=list(payload.get("items") or [])
        art=list(payload.get("art") or [])
        while len(art)<len(items):art.append({})
        for pos,item in enumerate(items):
            if not isinstance(item,dict):continue
            row=dict(art[pos] or {})
            if row.get("display") or row.get("poster"):
                row["visual_locked"]=True;art[pos]=row;continue
            try:
                snap=(load_shared_detail_snapshot(self.profile,self.media_type,item)
                      if item.get("_xtream") else load_detail_snapshot(self.profile,self.media_type,item))
                bundle=_load_visual_bundle(self.profile,self.media_type,item,snap) or {}
                display=str(bundle.get("grid_thumb") or bundle.get("poster") or "")
                poster=str(bundle.get("poster") or "")
                if display and os.path.isfile(display):
                    row["display"]=display;row["palette"]=poster or display;row["visual_locked"]=True
                    card=str(bundle.get("grid_card") or "")
                    if card and os.path.isfile(card):row["card"]=card
                elif poster and os.path.isfile(poster):
                    row["poster"]=poster;row["visual_locked"]=True
            except Exception as exc:optional_failure("ui.m3u_prepared_hdd_refresh",exc)
            art[pos]=row
        payload=dict(payload);payload["art"]=art
        return payload

    def _warm_poster_grid_catalogue_pages(self):
        if getattr(self,"_screen_closed",False) or getattr(self,"_grid_images_suspended",False):return
        token=(str(self.media_type),str(self.genre),int(self.page))
        if getattr(self,"_catalogue_idle_pending",None)==token:return
        self._catalogue_idle_pending=token
        def settled():
            if getattr(self,"_catalogue_idle_pending",None)!=token:return
            self._catalogue_idle_pending=None
            if getattr(self,"_screen_closed",False) or getattr(self,"_grid_images_suspended",False) or getattr(self,"_busy",False):return
            if token!=(str(self.media_type),str(self.genre),int(self.page)):return
            self._warm_poster_grid_catalogue_pages_now()
        reactor.callLater(1.25,settled)

    def _warm_poster_grid_catalogue_pages_now(self):
        """Warm neighbouring Poster Grid pages like Cinematic, without artwork work.

        Only VOD/Series provider catalogue + persisted state are prepared.  No
        poster/backdrop downloads, TMDB calls, Pillow generation or adaptive
        chrome is started here.  The next/previous page therefore enters through
        _prepared_page_cache immediately while card artwork remains cache-first.
        """
        if getattr(self,"_screen_closed",False) or self.media_type not in ("vod","series"):
            return
        if getattr(self,"_view_active",False):
            return
        total=int(self._active_total() or 0)
        if total<=int(self.page_size or 1):
            return
        total_pages=max(1,(total+int(self.page_size or 1)-1)//int(self.page_size or 1))
        current=max(1,min(int(self.page or 1),total_pages))
        # Prioritise the direction users normally browse: next page first, then
        # previous page second. Two prepared pages keep navigation hot without
        # turning provider catalogue work into background contention without turning a large catalogue into a RAM scan.
        targets=[]
        for target in (current+1,current-1):
            if target<1 or target>total_pages or target==current or target in targets:
                continue
            targets.append(target)
        if not targets:
            return
        self._grid_page_warm_token=int(getattr(self,"_grid_page_warm_token",0) or 0)+1
        token=self._grid_page_warm_token
        def worker():
            try:
                for target in targets:
                    if getattr(self,"_screen_closed",False) or getattr(self,"_grid_images_suspended",False) or token!=int(getattr(self,"_grid_page_warm_token",0) or 0):
                        break
                    with self._prepared_page_lock:
                        if target in self._prepared_page_cache or target in self._prepared_page_pending:
                            continue
                        self._prepared_page_pending.add(target)
                    try:
                        payload=self._prepare_grid_page_resilient(target,getattr(self,"_page_prefetch_cancel",None))
                        if payload and token==int(getattr(self,"_grid_page_warm_token",0) or 0):
                            self._cache_prepared_page(target,payload)
                        else:
                            with self._prepared_page_lock:self._prepared_page_pending.discard(target)
                    except Exception as exc:
                        with self._prepared_page_lock:self._prepared_page_pending.discard(target)
                        optional_failure("ui.poster_grid_catalogue_warm",exc)
            finally:
                # Only one warm worker runs at a time (the guard below returns
                # while one is active), so releasing the flag is always correct.
                # Leaving it set when a newer page plan superseded this one
                # disabled neighbour-page warming for the rest of the screen's
                # life; instead hand the newer plan to the GUI thread to start.
                self._grid_page_warm_running=False
                if token!=int(getattr(self,"_grid_page_warm_token",0) or 0) and not getattr(self,"_screen_closed",False):
                    try:reactor.callFromThread(self._warm_poster_grid_catalogue_pages)
                    except Exception:pass
        # A newer page transition supersedes an older neighbour plan.  We do not
        # cancel the provider call mid-socket; the token simply prevents stale
        # payloads from taking over the active warm set.
        if getattr(self,"_grid_page_warm_running",False):
            return
        self._grid_page_warm_running=True
        try:_GRID_PAGE_WARM_EXECUTOR.submit(worker)
        except Exception as exc:
            self._grid_page_warm_running=False;optional_failure("ui.poster_grid_catalogue_warm_submit",exc)
