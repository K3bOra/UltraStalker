# -*- coding: utf-8 -*-
"""Title logo signature, display and caching.

Methods moved verbatim out of ``PremiumGlobalCinematicScreen`` (ui_cinematic_global.py); behaviour is unchanged.
This module is imported by ui_cinematic_global.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, round, max, min, us_casefold
from .ui_cinematic_global import (
    _CIN_HYBRID_EXECUTOR,
    _PILImage,
    durable_view_path,
    hashlib,
    load_settings,
    optional_failure,
    os,
    threading,
    ultra_title_logo_cached,
)


class CineLogoMixin(object):
    """Title logo signature, display and caching."""

    # R81 title-logo authority: fixed 420x144 slot above the lightweight rail.
    # It resolves only after stable focus; arrow navigation never touches it.
    def _cin_title_logo_signature(self,item,row):
        """Current-item request key + PGV2 shared-cache lookup, HDD only.

        The old Cinematic path refused to schedule logo discovery until tmdb_id
        was already hydrated.  Poster Grid V2 does not have that dependency: the
        worker discovers canonical identity itself.  Keep the request key bound
        to the selected catalogue item so it survives that hydration step.
        """
        try:
            row=row if isinstance(row,dict) else {}
            title=self._rail_title(item,row) or str(row.get("title") or row.get("name") or "")
            key=str(self._page_visual_key(item) or "")
            if not key:
                basis="%s|%s"%(self.media_type,us_casefold(str(title or "").strip()))
                key=hashlib.sha1(basis.encode("utf-8","ignore")).hexdigest()
            cached=ultra_title_logo_cached(self.media_type,item,row,(420,144),title) or ""
            # R67 Local title-logo adoption: Details may already have resolved and
            # cached the exact logo under the canonical TMDb id while the Local
            # catalogue row still contains only path/name identity.  Reuse that
            # HDD-only canonical row before scheduling another resolver pass.
            if not cached and isinstance(item,dict) and (item.get("_local_media") or str(item.get("source_type") or item.get("_source_type") or "").lower()=="local"):
                try:
                    from .details_authority import load_canonical
                    canonical=load_canonical(self.profile,self.media_type,item) or {}
                    if canonical:
                        merged=dict(row);merged.update(canonical)
                        cached=ultra_title_logo_cached(self.media_type,item,merged,(420,144),title) or ""
                except Exception as exc:
                    optional_failure("cinematic.local_title_logo_adopt",exc)
            return ("%s:item:%s"%(self.media_type,key),str(cached or ""))
        except Exception:return ("","")

    def _cin_existing_title_logo_source(self,item,row):
        """Return an HDD-only title-logo source already proven by another view.

        Details uses a 432x210 canvas while Cinematic uses 420x144.  A stale
        PGV2 negative seal used to hide a perfectly valid Details logo because
        the exact Cinematic variant had not been prepared yet.  Probe the
        shared Ultra title-logo cache by canonical TMDb id before respecting a
        negative seal.  No network, TMDb query, or image decode happens here.
        """
        fresh=dict(row or {}) if isinstance(row,dict) else {}
        try:
            from .details_authority import load_canonical
            canonical=load_canonical(self.profile,self.media_type,item) or {}
            if isinstance(canonical,dict):
                for key,value in canonical.items():
                    if value not in (None,"",[],{}):fresh[key]=value
        except Exception as exc:
            optional_failure("cinematic.title_logo_details_cache_row",exc)
        tmdb_id=None
        for obj,key in ((fresh,"_locked_tmdb_id"),(item if isinstance(item,dict) else {},"_locked_tmdb_id"),
                        (fresh,"_ultra_search_verified_tmdb_id"),(item if isinstance(item,dict) else {},"_ultra_search_verified_tmdb_id"),
                        (fresh,"tmdb_id"),(item if isinstance(item,dict) else {},"tmdb_id")):
            try:
                value=obj.get(key)
            except Exception:
                value=None
            if value not in (None,""):
                tmdb_id=value;break
        if tmdb_id in (None,""):
            return "",fresh
        try:
            from .title_logo_runtime import ultra_title_logo_cache_path,valid_ultra_title_logo,title_logo_policy_languages
            languages=[]
            try:languages.extend(list(title_logo_policy_languages(item if isinstance(item,dict) else {},fresh) or ()))
            except Exception:pass
            for lang in ("en","ar","any","00"):
                if lang not in languages:languages.append(lang)
            # Exact Cinematic target first, then canvases written by Details,
            # shared master, Poster Grid and Player/Home.  The worker below
            # converts a non-420x144 hit using the existing fitted-logo helper.
            sizes=((420,144),(432,210),(900,210),(900,125),(1220,72))
            for lang in languages:
                for size in sizes:
                    path=ultra_title_logo_cache_path(self.media_type,tmdb_id,lang,size)
                    if valid_ultra_title_logo(path):
                        return str(path),fresh
        except Exception as exc:
            optional_failure("cinematic.title_logo_details_cache_probe",exc)
        return "",fresh

    def _cin_title_logo_display_target(self,source):
        """Return the Cinematic fitted-logo cache path without decoding artwork."""
        try:
            source=str(source or "")
            if not source or not os.path.isfile(source) or os.path.getsize(source)<=256:return ""
            st=os.stat(source)
            stamp="%s|%s"%(int(getattr(st,"st_mtime_ns",int(st.st_mtime*1000000000))),int(st.st_size))
            digest=hashlib.sha1((source+"|"+stamp+"|cinematic-title-logo-420x144-v1").encode("utf-8","ignore")).hexdigest()[:20]
            return durable_view_path("cinematic_%s_420x144_v1.png"%digest,"title_logos",source=source)
        except Exception:return ""

    def _cin_prepare_title_logo_display(self,source):
        """Build the fitted 420x144 Cinematic logo on the background worker only."""
        try:
            source=str(source or "");target=self._cin_title_logo_display_target(source)
            if _PILImage is None or not target:return ""
            if os.path.isfile(target) and os.path.getsize(target)>256:return target
            os.makedirs(os.path.dirname(target),mode=0o700,exist_ok=True)
            with _PILImage.open(source) as src:
                im=src.convert("RGBA")
                try:
                    bbox=im.getchannel("A").getbbox()
                    if bbox:im=im.crop(bbox)
                except Exception:pass
                if im.width<2 or im.height<2:return ""
                max_w,max_h=404,132
                scale=min(float(max_w)/float(im.width),float(max_h)/float(im.height),1.35)
                nw=max(1,int(round(im.width*scale)));nh=max(1,int(round(im.height*scale)))
                if (nw,nh)!=im.size:
                    res=getattr(getattr(_PILImage,"Resampling",_PILImage),"LANCZOS",1)
                    im=im.resize((nw,nh),res)
                canvas=_PILImage.new("RGBA",(420,144),(0,0,0,0))
                canvas.alpha_composite(im,((420-nw)//2,max(0,(144-nh)//2)))
                tmp=target+".tmp.%s.%s"%(os.getpid(),threading.get_ident())
                try:
                    canvas.save(tmp,"PNG",compress_level=1);os.replace(tmp,target)
                finally:
                    try:
                        if os.path.exists(tmp):os.unlink(tmp)
                    except Exception:pass
            return target if os.path.isfile(target) and os.path.getsize(target)>256 else ""
        except Exception as exc:
            optional_failure("cinematic.title_logo_display_prepare",exc);return ""

    def _cin_show_title_logo(self,item,row):
        """Hold last-good while pending; hide it only when CURRENT is logo-less."""
        sig,path=self._cin_title_logo_signature(item,row)
        try:
            if sig and sig!=str(getattr(self,"_cin_logo_active_sig","") or ""):
                old=getattr(self,"_cin_logo_cancel",None)
                if old is not None:old.set()
                self._cin_logo_cancel=threading.Event();self._cin_logo_active_sig=sig
            if path and os.path.isfile(path) and os.path.getsize(path)>256 and self["title_logo"].instance is not None:
                if self._cin_logo_path!=path:self["title_logo"].instance.setPixmapFromFile(path);self._cin_logo_path=path
                self["title_logo"].show();return

            from .ui_grid_screens import _pgv2_logo_seal_state_detached,_pgv2_title_logo_probe_missing_detached
            seal_state,_seal_path,_seal=_pgv2_logo_seal_state_detached(self.profile,self.media_type,item,row)
            probe_missing=(_pgv2_title_logo_probe_missing_detached(item,row) if seal_state!="logo" else False)
            if seal_state=="missing" or probe_missing:
                # R69 Local parity with the official Portal Cinematic path:
                # a historical negative presentation seal must never outrank a
                # real logo already written by Native Details into the shared HDD
                # title-logo cache.  Local catalogue rows can reach Cinematic
                # before canonical TMDb identity is hydrated, so an early cold
                # focus may legitimately have written a negative seal.  Hide any
                # stale presentation now, but let the background worker continue
                # and adopt the proven Details logo.  Online/provider behaviour
                # remains unchanged.
                self["title_logo"].hide();self._cin_logo_path=""
                is_local=bool(isinstance(item,dict) and (item.get("_local_media") or str(item.get("source_type") or item.get("_source_type") or "").lower()=="local"))
                if seal_state=="missing" and not is_local:return
            else:
                held=str(getattr(self,"_cin_logo_path","") or "")
                if held and os.path.isfile(held) and os.path.getsize(held)>256:self["title_logo"].show()
                else:self["title_logo"].hide();self._cin_logo_path=""
        except Exception:pass
        if not sig or sig in self._cin_logo_pending:return
        if getattr(self,"_cin_logo_cancel",None) is None:
            self._cin_logo_cancel=threading.Event();self._cin_logo_active_sig=sig
        ev=self._cin_logo_cancel
        self._cin_logo_pending.add(sig);item_copy=dict(item or {});row_copy=dict(row or {})
        def _logo_worker():
            result="";logo_state="pending";resolved_row=dict(row_copy or {})
            try:
                from .ui_grid_screens import (
                    _pgv2_bridge_logo_from_seal_detached,_pgv2_authoritative_logo_row_detached,
                    _pgv2_resolve_title_logo_detached,_pgv2_write_logo_seal_detached
                )
                # R68 Details-parity hot path: a Details logo is stronger than a
                # stale negative PGV2 seal.  Adopt it from the shared HDD cache
                # and prepare only the Cinematic presentation canvas locally.
                existing,resolved_row=self._cin_existing_title_logo_source(item_copy,resolved_row)
                if ev is not None and ev.is_set():return
                if existing:
                    result=self._cin_prepare_title_logo_display(existing) or existing
                    logo_state="logo" if result and os.path.isfile(result) else "pending"
                    if logo_state=="logo":
                        _pgv2_write_logo_seal_detached(self.profile,self.media_type,item_copy,resolved_row,result)
                if logo_state!="logo":
                    state,bridged,_seal=_pgv2_bridge_logo_from_seal_detached(
                        self.profile,self.media_type,item_copy,resolved_row,(420,144),cancel_event=ev
                    )
                    if ev is not None and ev.is_set():return
                    if state=="missing":logo_state="missing"
                    elif state=="logo" and bridged:
                        result=bridged;logo_state="logo"
                    else:
                        settings=(getattr(self,"_grid_settings",None) or load_settings() or {})
                        resolved_row=_pgv2_authoritative_logo_row_detached(
                            self.profile,self.media_type,item_copy,resolved_row,cancel_event=ev,settings=settings
                        )
                        if ev is not None and ev.is_set():return
                        result,resolved_row=_pgv2_resolve_title_logo_detached(
                            self.profile,self.media_type,item_copy,resolved_row,cancel_event=ev,settings=settings,canvas_size=(420,144)
                        )
                        if ev is not None and ev.is_set():return
                        logo_state="logo" if result and os.path.isfile(result) else "missing"
                        _pgv2_write_logo_seal_detached(self.profile,self.media_type,item_copy,resolved_row,result)
            except Exception as exc:optional_failure("cinematic.title_logo_prepare",exc)
            try:self._cin_jobs.put({"kind":"title_logo","sig":sig,"path":result,"missing":(logo_state=="missing")})
            except Exception:pass
        def worker():
            try:_logo_worker()
            finally:
                # A cancelled worker returns without posting a result, so nothing
                # would ever release this signature.  Without this the same title
                # could never resolve its logo again after BACK from a child screen.
                try:
                    if ev is not None and ev.is_set():self._cin_logo_pending.discard(sig)
                except Exception:pass
        try:
            ex=getattr(self,"_cin_logo_executor",None) or getattr(self,"_cin_hybrid_executor",_CIN_HYBRID_EXECUTOR)
            future=ex.submit(worker,_task_key="cin-logo:%x"%id(self),_replace_task_key=True)
            def _logo_done(done,_sig=sig):
                if done.cancelled():self._cin_logo_pending.discard(_sig)
            future.add_done_callback(_logo_done);self._cin_kick_poll()
        except Exception:self._cin_logo_pending.discard(sig)
