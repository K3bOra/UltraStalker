"""R5.459 byte-identical bundled asset aliases; one file per material.

Only packaged assets are redirected. Persistent/HDD artwork is untouched.
On WQHD (2560x1440), pre-sized static surfaces in assets_wqhd/ are automatically
preferred when present so Enigma2 can hardware-blit them 1:1 without software
blitScale overhead; on FHD (1920x1080) assets_fhd/ is always used untouched.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str
os = _us_env.os
from .wqhd_layout import factors as _wqhd_factors

_PLUGIN_ROOT = os.path.dirname(os.path.abspath(__file__))
ASSET_ROOT = os.path.join(_PLUGIN_ROOT, "assets_fhd")
WQHD_ASSET_ROOT = os.path.join(_PLUGIN_ROOT, "assets_wqhd")
ASSET_ALIASES = {'fixed_green_details/runtime.png': 'fixed_green_details/quality.png', 'fixed_master_r63/downloads/downloads_row_1090x72.png': 'fixed_master_r63/downloads/downloads_overlay_row_1090x72.png', 'fixed_master_r63/settings_notice_560x260.png': 'settings_clean_r5390/panel_560x260.png', 'fixed_master_r63/surfaces/bd_quality_150x50.png': 'fixed_green_details/quality.png', 'fixed_master_r63/surfaces/bd_runtime_150x50.png': 'fixed_green_details/quality.png', 'fixed_master_r63/surfaces/bd_year_130x50.png': 'fixed_green_details/year.png', 'fixed_master_r63/surfaces/cin_cast_detail_1318x50.png': 'fixed_green_details/cast_detail.png', 'fixed_master_r63/surfaces/cin_country_160x50.png': 'fixed_green_details/country.png', 'fixed_master_r63/surfaces/cin_genre_detail_680x50.png': 'fixed_green_details/genre_detail.png', 'fixed_master_r63/surfaces/cin_overview_detail_1318x170.png': 'fixed_green_details/overview_detail.png', 'fixed_master_r63/surfaces/cin_quality_150x50.png': 'fixed_green_details/quality.png', 'fixed_master_r63/surfaces/cin_runtime_150x50.png': 'fixed_green_details/quality.png', 'fixed_master_r63/surfaces/cin_year_130x50.png': 'fixed_green_details/year.png', 'fixed_master_r63/surfaces/live_zap_footer_page_126x42.png': 'fixed_master_r63/surfaces/live_zap_footer_play_126x42.png', 'flags_iso/bv.png': 'flags_iso/no.png', 'flags_iso/hm.png': 'flags_iso/au.png', 'flags_iso/mf.png': 'flags_iso/fr.png', 'flags_iso/sj.png': 'flags_iso/no.png', 'flags_iso/um.png': 'flags_iso/us.png', 'home129_menu_fallback.png': 'fixed_master_r63/home_menu.png', 'home129_menu_focus.png': 'fixed_master_r63/home_menu_focus.png', 'us66_neutral_pill_quality.png': 'fixed_green_details/quality.png', 'us66_neutral_pill_runtime.png': 'fixed_green_details/quality.png', 'us66_neutral_pill_year.png': 'fixed_green_details/year.png'}

_WQHD_EXISTS_CACHE = {}


def asset_path(name):
    name = str(name or "")
    rel = ASSET_ALIASES.get(name, name)
    try:
        if _wqhd_factors()[0] != 1.0:
            hit = _WQHD_EXISTS_CACHE.get(rel)
            if hit is None:
                candidate = os.path.join(WQHD_ASSET_ROOT, rel)
                hit = candidate if os.path.isfile(candidate) else ""
                _WQHD_EXISTS_CACHE[rel] = hit
            if hit:
                return hit
    except Exception:
        pass
    return os.path.join(ASSET_ROOT, rel)


def canonical_asset(path):
    path = str(path or "")
    for root in (ASSET_ROOT, WQHD_ASSET_ROOT):
        prefix = root + os.sep
        if path.startswith(prefix):
            return asset_path(path[len(prefix):])
    return path
