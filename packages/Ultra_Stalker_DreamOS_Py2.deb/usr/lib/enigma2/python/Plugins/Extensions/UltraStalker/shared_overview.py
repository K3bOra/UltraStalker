# -*- coding: utf-8 -*-
"""Arabic synopsis shared between portals, keyed by the TMDb id.

One film has one TMDb id, but every portal brings its own synopsis text. When a portal
supplies a real Arabic synopsis for a verified TMDb id, that text is remembered here so
the same title shows the same Arabic text under every other portal, whose own text may be
English or empty and whose TMDb record may have no Arabic translation.

Only a clean, real Arabic synopsis is stored (the caller strips adverts and checks the
length), one small JSON file per title under the persistent index. Nothing here is ever
written into the TMDb snapshot itself, so a provider can still never overwrite TMDb data.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str, int

os = _us_env.os
time = _us_env.time
from .persistent_cache import INDEX
from .core.shared_record_store import SharedRecordStore, PendingWriteLimitError
from .log import optional_failure
from .verified_identity import media_kind, positive_id

def _merge_saved(old, new):
    return old if len(str(old.get('ar') or '')) >= len(str(new.get('ar') or '')) else new


_STORE = SharedRecordStore(os.path.join(INDEX, "shared_overviews"), merge=_merge_saved)
_MAX_CHARS = 4000


def _key(kind, ident):
    kind = media_kind(kind)
    ident = positive_id(ident)
    return "%s_%s" % (kind, ident) if kind and ident else ""


def load_shared_arabic(media_type, tmdb_id):
    key = _key(media_type, tmdb_id)
    return str(_STORE.get(key).get("ar") or "").strip() if key else ""


def save_shared_arabic(media_type, tmdb_id, text):
    key = _key(media_type, tmdb_id)
    text = str(text or "").strip()[:_MAX_CHARS]
    if not key or not text:
        return False
    with _STORE.lock:
        previous = _STORE.get(key)
        old = str(previous.get("ar") or "")
        # The fullest known same-ID provider synopsis is shared everywhere.
        if len(old) >= len(text):
            text = old
        row = previous if old == text else {"ar": text, "updated_at": int(time.time())}
        try:return _STORE.put(key, row)
        except PendingWriteLimitError as exc:
            # The caller receives a failure; no existing accepted record is lost.
            optional_failure("shared_metadata.capacity",exc)
            return False
