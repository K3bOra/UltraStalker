# -*- coding: utf-8 -*-
"""Explicit BLUE text/logo warming; never resolve poster/backdrop bytes here."""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int


_SCREEN_LOGO_CANVASES = (
    (466, 180),  # Poster Grid 3 (Spotlight)
    (432, 210),  # Backdrop Grid 1/2 & Details
    (420, 144),  # Cinematic & Player
    (900, 125),  # Poster Grid 2
)


def _warm_logo_canvases(profile, media_type, item, fresh, master_path):
    from .title_logo_ultra import (
        MASTER_CANVAS,
        _logo_language_order,
        _variant_from_master,
        ultra_title_logo_cache_path,
        ultra_title_logo_cached,
    )
    from .title_logo_runtime import valid_ultra_title_logo
    tmdb_id = (fresh or {}).get("tmdb_id")
    if not tmdb_id:
        return
    chosen_lang = ""
    chosen_master = ""
    langs = list(_logo_language_order(item, fresh)) + ["ar", "en", "any"]
    seen = set()
    for lang in langs:
        if lang in seen:
            continue
        seen.add(lang)
        cand = ultra_title_logo_cache_path(media_type, tmdb_id, lang, MASTER_CANVAS)
        if valid_ultra_title_logo(cand):
            chosen_lang = lang
            chosen_master = cand
            break
    if not chosen_master and valid_ultra_title_logo(master_path):
        chosen_master = master_path
        chosen_lang = langs[0] if langs else "en"
    if not chosen_master:
        return
    for canvas in _SCREEN_LOGO_CANVASES:
        try:
            target = ultra_title_logo_cache_path(media_type, tmdb_id, chosen_lang, canvas)
            if target and not valid_ultra_title_logo(target):
                _variant_from_master(chosen_master, target, canvas)
        except Exception:
            pass
    try:
        from .ui_grid_screens import _pgv2_logo_seal_state_detached, _pgv2_write_logo_seal_detached
        s_state, s_path, _s_dict = _pgv2_logo_seal_state_detached(profile, media_type, item, fresh)
        if s_state != "logo" or not s_path:
            seal_logo = ultra_title_logo_cache_path(media_type, tmdb_id, chosen_lang, (900, 125))
            if not valid_ultra_title_logo(seal_logo):
                seal_logo = chosen_master
            _pgv2_write_logo_seal_detached(profile, media_type, item, fresh, seal_logo)
    except Exception:
        pass


def cache_blue_extras(profile, media_type, item, row, settings, cancel_event=None, provider_client=None):
    from .details_authority import load_canonical, resolve_metadata_fast, metadata_language_ready
    from .title_logo_ultra import (
        MASTER_CANVAS,
        resolve_ultra_title_logo,
        ultra_title_logo_cached,
        ultra_title_logo_checked,
    )
    from .log import optional_failure
    fresh=dict(row or {})
    result={"details_ready":False,"logo_ready":False,"row":fresh}
    def stopped():return bool(cancel_event is not None and cancel_event.is_set())
    if stopped():return result
    try:
        if metadata_language_ready(fresh,settings):
            result["details_ready"]=True
        else:
            canon=load_canonical(profile,media_type,item) or {}
            if canon:
                for k,v in canon.items():
                    if v not in (None,"",[],{}) and fresh.get(k) in (None,"",[],{}):
                        fresh[k]=v
            if metadata_language_ready(fresh,settings):
                result["details_ready"]=True
            else:
                resolved=resolve_metadata_fast(profile,media_type,item,current=fresh,
                    settings=settings,cancel_event=cancel_event,provider_client=None) or {}
                if isinstance(resolved,dict) and resolved:
                    for k,v in resolved.items():
                        if v not in (None,"",[],{}):
                            fresh[k]=v
                result["details_ready"]=bool(
                    metadata_language_ready(fresh,settings)
                    or fresh.get("_details_authority_ready")
                    or fresh.get("overview")
                    or fresh.get("genres")
                    or (fresh.get("tmdb_id") and (fresh.get("rating") or fresh.get("year")))
                )
    except Exception as exc:optional_failure("ui.blue_details",exc)
    result["row"]=fresh
    if stopped():return result
    has_verified_id = bool(
        fresh.get("tmdb_id") and (
            fresh.get("identity_verified")
            or fresh.get("identity_pointer_verified")
            or fresh.get("_details_authority_ready")
        )
    )
    try:
        cached_logo=ultra_title_logo_cached(media_type,item,fresh,MASTER_CANVAS)
        if cached_logo:
            _warm_logo_canvases(profile,media_type,item,fresh,cached_logo)
            result["logo_ready"]=True
        elif has_verified_id or not ultra_title_logo_checked(media_type,item,fresh,MASTER_CANVAS):
            path,logo_row=resolve_ultra_title_logo(profile,media_type,item,fresh,
                canvas_size=MASTER_CANVAS,cancel_event=cancel_event,settings=settings)
            if isinstance(logo_row,dict) and logo_row:
                for k,v in logo_row.items():
                    if v not in (None,"",[],{}):
                        fresh[k]=v
                result["row"]=fresh
                if not result["details_ready"] and fresh.get("tmdb_id"):
                    try:
                        resolved2=resolve_metadata_fast(profile,media_type,item,current=fresh,
                            settings=settings,cancel_event=cancel_event,provider_client=None) or {}
                        if isinstance(resolved2,dict) and resolved2:
                            for k,v in resolved2.items():
                                if v not in (None,"",[],{}):
                                    fresh[k]=v
                            result["row"]=fresh
                            result["details_ready"]=bool(
                                metadata_language_ready(fresh,settings)
                                or fresh.get("_details_authority_ready")
                                or fresh.get("overview")
                            )
                    except Exception:
                        pass
            if path:
                _warm_logo_canvases(profile,media_type,item,fresh,path)
                result["logo_ready"]=True
            else:
                try:
                    from .ui_grid_screens import _pgv2_write_logo_seal_detached
                    if fresh.get("tmdb_id"):
                        _pgv2_write_logo_seal_detached(profile,media_type,item,fresh,"")
                except Exception:
                    pass
    except Exception as exc:optional_failure("ui.blue_logo",exc)
    return result
