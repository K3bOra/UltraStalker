# -*- coding: utf-8 -*-
"""Explicit BLUE text/logo warming; never resolve poster/backdrop bytes here."""
from __future__ import absolute_import


def cache_blue_extras(profile, media_type, item, row, settings, cancel_event=None, provider_client=None):
    from .details_authority import load_canonical, resolve_metadata_fast, metadata_language_ready
    from .title_logo_ultra import (
        MASTER_CANVAS,
        resolve_ultra_title_logo,
        ultra_title_logo_cached,
        ultra_title_logo_checked,
    )
    from .log import optional_failure
    fresh=dict(row or {})
    result={"details_ready":False,"logo_ready":False}
    def stopped():return bool(cancel_event is not None and cancel_event.is_set())
    if stopped():return result
    try:
        if metadata_language_ready(fresh,settings):
            result["details_ready"]=True
        else:
            canon=load_canonical(profile,media_type,item) or {}
            if canon:
                for k,v in canon.items():
                    if v not in (None,"",[],{}) and fresh.get(k) in (None,"",[],{}):
                        fresh[k]=v
            if metadata_language_ready(fresh,settings):
                result["details_ready"]=True
            else:
                # Never pass provider_client here: BLUE extras must not make slow
                # synchronous portal get_vod_info/get_series_info requests per item.
                fresh=resolve_metadata_fast(profile,media_type,item,current=fresh,
                    settings=settings,cancel_event=cancel_event,provider_client=None) or fresh
                result["details_ready"]=bool(metadata_language_ready(fresh,settings))
    except Exception as exc:optional_failure("ui.blue_details",exc)
    if stopped():return result
    if fresh.get("tmdb_id") and (fresh.get("identity_verified") or fresh.get("identity_pointer_verified")):
        try:
            cached_logo=ultra_title_logo_cached(media_type,item,fresh,MASTER_CANVAS)
            if cached_logo:
                result["logo_ready"]=True
            elif not ultra_title_logo_checked(media_type,item,fresh,MASTER_CANVAS):
                path,unused=resolve_ultra_title_logo(profile,media_type,item,fresh,
                    canvas_size=MASTER_CANVAS,cancel_event=cancel_event,settings=settings)
                result["logo_ready"]=bool(path)
        except Exception as exc:optional_failure("ui.blue_logo",exc)
    return result
