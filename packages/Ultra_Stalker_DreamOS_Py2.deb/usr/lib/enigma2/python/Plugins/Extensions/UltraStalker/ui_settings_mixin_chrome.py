# -*- coding: utf-8 -*-
"""Toggle saving, materials, layout readiness and job draining.

Methods moved verbatim out of ``NovaSettingsScreen`` (ui_screens_settings.py); behaviour is unchanged.
This module is imported by ui_screens_settings.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, max, us_func
from .ui_screens_settings import (
    AsyncScreenMixin,
    Input,
    SettingsGlassInputScreen,
    _authorize_parental_change,
    _mem34,
    _settings_category_backdrop,
    cleanup_legacy_application_outputs,
    fixed_settings_rows,
    fixed_value_color,
    gFont,
    parseColor,
)


class SettingsChromeMixin(object):
    """Toggle saving, materials, layout readiness and job draining."""

    def _save_toggle_choice(self,action,key,choice,_pin_authorized=False):
        if not choice:return
        value=bool(choice[1]);cfg=load_settings()
        if not _pin_authorized and (action=="parental" or (key=="hide_adult" and not value)):
            _authorize_parental_change(self,lambda:self._save_toggle_choice(action,key,choice,True),SettingsGlassInputScreen)
            return
        if action=="parental":
            if value and parental_pin_is_default(cfg):
                # Enabling parental control with the factory PIN used to be a dead end:
                # Settings refused the toggle and left the user on OFF.  Turn that into
                # one atomic flow: collect a real PIN, save it securely, then enable.
                self.session.openWithCallback(
                    self._save_parental_pin_and_enable,
                    SettingsGlassInputScreen,
                    title=_("Set parental PIN to enable lock (4-8 digits)"),
                    text="",
                    maxSize=8,
                    type=Input.PIN,
                )
                return
            save_settings({"parental_lock":value})
            # Never carry a previously unlocked parental session across an ON/OFF
            # state change.  The next protected category must reflect the new state.
            parental_lock_now()
            self.refresh()
            self["status"].setText(_("Parental lock enabled") if value else _("Parental lock disabled"))
            return
        save_settings({key:value});self.refresh();self["status"].setText(_("Setting updated"))

    def _settings_hero_visuals(self):
        """Return the bundled Settings background without reading Home hero state.

        Settings keeps its adaptive glass look, but the source artwork is now
        deterministic and local.  Opening Settings therefore never waits on or
        parses Home hero metadata.
        """
        prepared=_settings_category_backdrop()
        if not (prepared and os.path.isfile(prepared)):
            prepared=asset("ultra_bg_flag_1920x1080.png")
        menu=asset("fixed_master_r63/home_menu.png")
        focus_menu=asset("fixed_master_r63/home_menu_focus.png")
        return prepared,"",menu,focus_menu

    def _apply_settings_list_materials(self):
        try:cleanup_legacy_application_outputs()
        except Exception as exc:optional_failure("ui.fixed_adaptive_cleanup_settings",exc)
        prepared,ambient,_menu,_focus=self._settings_hero_visuals()
        try:
            if ambient:
                self["ambient_bg"].instance.setPixmapFromFile(ambient);self["ambient_bg"].show()
            else:self["ambient_bg"].hide()
        except Exception as exc:optional_failure("ui.settings_list_ambient",exc)
        try:
            if prepared and os.path.isfile(prepared):
                self["hero_backdrop"].instance.setPixmapFromFile(prepared);self["hero_backdrop"].show()
        except Exception as exc:optional_failure("ui.settings_list_backdrop",exc)

        # R63: one persistent utility-row pair copied from the approved frozen
        # application adaptive.  Settings only binds ready-made files; entering
        # and leaving the screen never rebuilds palette/chrome.
        try:
            chrome=fixed_settings_rows() or {}
            normal=str(chrome.get("normal") or "")
            selected=str(chrome.get("selected") or "")
            if normal and os.path.isfile(normal):self._settings_row_asset=normal
            if selected and os.path.isfile(selected):self._settings_row_selected_asset=selected
            self._settings_value_color=int(chrome.get("value_color") or fixed_value_color(self._settings_value_color))
            _accent=parseColor("#%06x" % (int(self._settings_value_color)&0xFFFFFF))
            for _name,_size in (("context_subtitle",19),("context_hint",18),("status",19)):
                try:
                    _inst=self[_name].instance
                    if _inst is not None:
                        _inst.setForegroundColor(_accent);_inst.setFont(_ultra_rfont("Regular",_size))
                except Exception:pass
        except Exception as exc:optional_failure("ui.settings_episode_material",exc)

        try:
            if self["list"].instance is not None:self["list"].instance.setSelectionEnable(0)
            if self["opt_list"].instance is not None:self["opt_list"].instance.setSelectionEnable(0)
        except Exception as exc:optional_failure("ui.settings_episode_selection",exc)

    def _grid_text_px(self,text,size):
        text=str(text or "")
        try:
            return int(_settings_text_width_px(text,int(size)))
        except Exception:
            # Conservative fallback for images where the native Enigma2 font
            # measurement helper is unavailable during early layout.
            return int(len(text)*max(1,int(size))*0.58)

    def _layout_ready(self):
        _mem34("settings_layout_begin", section=str(getattr(self,"_settings_section","") or "root"))
        # Backdrop stays untouched; only the left episode-style Settings rail is
        # rendered over it. No right column and no visible scrollbar.
        self._apply_settings_list_materials()
        self._settings_bind_static_assets()
        self._level_applied=None;self._pv_shown=None
        self._render_settings_rows(getattr(self,"_settings_last_idx",0))
        self._selection_changed()
        self._context_hide_widgets()
        _mem34("settings_layout_done", section=str(getattr(self,"_settings_section","") or "root"), rows=len(getattr(self,"entries",[]) or []))

    def _drain_jobs(self):
        us_func(AsyncScreenMixin._drain_jobs)(self)
        if not self._screen_closed:
            self._drain_image_jobs()
            self._drain_global_artwork_progress()

from .wqhd_layout import responsive_font as _ultra_rfont, factors as _ultra_factors

def _ultra_osd_scale():
    return _ultra_factors()[1]
