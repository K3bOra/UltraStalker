# -*- coding: utf-8 -*-
"""Receiver video-mode helpers owned by Ultra Stalker.

This module keeps receiver aspect handling in one place so UI and Player do not
carry duplicate platform-specific logic.  It talks only to Enigma2 receiver
interfaces and procfs fallbacks exposed by the image.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import int, open

os = _us_env.os


_ASPECT_CHOICES = (
    (0, "4:3 Letterbox"),
    (1, "4:3 PanScan"),
    (2, "16:9"),
    (3, "16:9 Always"),
    (4, "16:10 Letterbox"),
    (5, "16:10 PanScan"),
    (6, "16:9 Letterbox"),
)
_ASPECT_LABELS = dict(_ASPECT_CHOICES)
_ASPECT_ORDER = tuple(code for code, _label in _ASPECT_CHOICES)

# Procfs values are strings, while Enigma2's setter/getter uses integer mode
# identifiers.  Keep the translation data declarative and independent from
# player/UI state.
_PROC_MODE_TO_CODE = {
    ("4:3", "letterbox"): 0,
    ("4:3", "panscan"): 1,
    ("16:9", "default"): 2,
    ("16:9", "panscan"): 3,
    ("16:10", "letterbox"): 4,
    ("16:10", "panscan"): 5,
    ("16:9", "letterbox"): 6,
    ("any", "bestfit"): 2,
    ("any", "default"): 2,
    ("any", "non"): 2,
}


def _switch_class(explicit=None):
    if explicit is not None:
        return explicit
    try:
        from enigma import eAVSwitch
        return eAVSwitch
    except Exception:
        try:
            from enigma import eAVControl
            return eAVControl
        except Exception:
            return None


def _read_proc_text(path):
    try:
        with open(path, "r") as handle:
            return handle.read().strip()
    except Exception:
        return ""


def _proc_aspect_code():
    aspect = _read_proc_text("/proc/stb/video/aspect")
    if not aspect:
        return None
    policy = _read_proc_text("/proc/stb/video/policy").lower()
    if aspect == "16:9" and policy not in ("letterbox", "panscan"):
        policy = "default"
    return _PROC_MODE_TO_CODE.get((aspect, policy))


def capture_aspect_mode(switch_cls=None):
    """Return the active Enigma2 aspect-mode code, or ``None`` if unknown.

    Prefer procfs when the image exposes it because that is the receiver's
    concrete current policy.  Fall back to the Enigma2 AV switch getter only
    when procfs cannot describe the active mode.
    """
    proc_value = _proc_aspect_code()
    if proc_value in _ASPECT_LABELS:
        return proc_value

    cls = _switch_class(switch_cls)
    if cls is not None:
        try:
            inst = cls.getInstance()
            getter = getattr(inst, "getAspectRatio", None)
            if callable(getter):
                value = int(getter())
                if value in _ASPECT_LABELS:
                    return value
        except Exception:
            pass
    return None


# Same table the Enigma2 C++ eAVSwitch::setAspectRatio writes to procfs.
_CODE_TO_PROC = {
    0: ("4:3", "letterbox"),
    1: ("4:3", "panscan"),
    2: ("any", "bestfit"),
    3: ("16:9", "panscan"),
    4: ("16:10", "letterbox"),
    5: ("16:10", "panscan"),
    6: ("16:9", "letterbox"),
}


def _write_proc_text(path, value):
    try:
        with open(path, "w") as handle:
            handle.write(value)
        return True
    except Exception:
        return False


def _proc_choices(path):
    text = _read_proc_text(path)
    return text.split() if text else []


def _apply_aspect_proc(code):
    """Write aspect/policy directly. Used on images (DreamOS among them) where
    eAVSwitch has no setAspectRatio or the call does not reach the driver."""
    pair = _CODE_TO_PROC.get(code)
    if pair is None or not os.path.exists("/proc/stb/video/aspect"):
        return False
    aspect, policy = pair
    choices = _proc_choices("/proc/stb/video/aspect_choices")
    if choices and aspect not in choices:
        aspect = "16:9" if aspect == "any" and "16:9" in choices else aspect
    wrote = _write_proc_text("/proc/stb/video/aspect", aspect)
    policies = _proc_choices("/proc/stb/video/policy_choices")
    if not policies or policy in policies:
        wrote = _write_proc_text("/proc/stb/video/policy", policy) or wrote
    elif policy == "bestfit" and "non" in policies:
        wrote = _write_proc_text("/proc/stb/video/policy", "non") or wrote
    # 4:3 content shown on a 16:9 screen follows policy2 on newer drivers.
    policies2 = _proc_choices("/proc/stb/video/policy2_choices")
    if policies2 and policy in policies2 and aspect in ("16:9", "any", "16:10"):
        _write_proc_text("/proc/stb/video/policy2", policy)
    return wrote


def _proc_matches(code):
    pair = _CODE_TO_PROC.get(code)
    if pair is None or not os.path.exists("/proc/stb/video/policy"):
        return None
    current = _read_proc_text("/proc/stb/video/policy").lower()
    return current == pair[1]


def apply_aspect_mode(value, switch_cls=None):
    """Apply one validated aspect-mode code: receiver API first, procfs if the
    API is missing, fails, or leaves the driver policy unchanged."""
    try:
        code = int(value)
    except (TypeError, ValueError):
        return False
    if code not in _ASPECT_LABELS:
        return False
    api_ok = False
    cls = _switch_class(switch_cls)
    if cls is not None:
        try:
            setter = getattr(cls.getInstance(), "setAspectRatio", None)
            if callable(setter):
                setter(code)
                api_ok = True
        except Exception:
            api_ok = False
    if not api_ok:
        try:
            from Components.AVSwitch import AVSwitch as _AVSwitch
            _AVSwitch().setAspectRatio(code)
            api_ok = True
        except Exception:
            api_ok = False
    if api_ok and _proc_matches(code) is not False:
        return True
    return _apply_aspect_proc(code) or api_ok


def restore_aspect_mode(value, switch_cls=None):
    if value is None:
        return False
    return apply_aspect_mode(value, switch_cls=switch_cls)


def next_aspect_mode(previous=None):
    """Return the next mode in Ultra Stalker's explicit display-mode cycle."""
    if previous not in _ASPECT_ORDER:
        return _ASPECT_ORDER[0]
    index = _ASPECT_ORDER.index(previous) + 1
    return _ASPECT_ORDER[index % len(_ASPECT_ORDER)]


def aspect_mode_label(value, default="Auto"):
    try:
        return _ASPECT_LABELS.get(int(value), default)
    except (TypeError, ValueError):
        return default

