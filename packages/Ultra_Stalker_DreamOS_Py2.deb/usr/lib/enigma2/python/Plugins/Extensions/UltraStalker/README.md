# Ultra Stalker

Ultra Stalker is an Enigma2 plugin (Python) for browsing Stalker/portal-style IPTV services on a set-top box. It provides home, category, grid and details screens with artwork (TMDb/IMDb/fanart), live, movies and series, a local media library, downloads, bouquet export, an optional web interface and a localized UI.

Current version: 9.2.6 (build 990, revision 574; package 9.2.6-r8).

## Requirements

- DreamOS OE2.5 with Python 2.7; install the DreamOS DEB package.
- Network access to the configured portal; optional TMDb access for artwork.
- Writable cache location (an HDD/USB under `/media/hdd` is preferred; flash is avoided for volatile caches).

## Install

Install the `.deb` with dpkg (for example `dpkg -i <file>.deb`) and restart the GUI. The package maintainer scripts (preinst/postinst/postrm) handle setup and cleanup. The plugin installs to:

`/usr/lib/enigma2/python/Plugins/Extensions/UltraStalker`

## Folder layout

- `plugin.py`, `ui*.py`, `ui_parts/`, `ui_screens_*.py` - plugin entry point and screens.
- `core/` - runtime services (cache, executors, session, security, diagnostics, bouquets, backup).
- `services/`, `repositories/` - portal/content access layers. The player screen is `services/player_native.py` (skins, `__init__`, close/cleanup and the next-episode core) plus `services/player_mixin_*.py`: layout, chips, chrome, livebar, epg, subtitles, buffer, playback, search, zap, progress (resume/seek) and tracks. Each mixin holds methods moved verbatim from the old single class and is imported by `player_native.py` after its module-level helpers exist; never import a mixin module directly.
- `client.py`, `netsec.py`, `securefs.py` - portal client, URL/network guard, safe file handling. `client.py` keeps `StalkerClient.__init__` and the module helpers; its methods live in `client_mixin_*.py`.
- Large screen classes follow the same pattern: each keeps `__init__` and anything that rebinds module globals or names its own class in its main module, and the other methods sit in topic modules named `<screen>_mixin_<topic>.py` (`ui_browser_mixin_*`, `ui_grid_mixin_*`, `ui_details_mixin_*`, `ui_cine_mixin_*`, `ui_plist_mixin_*`, `ui_pmgr_mixin_*`, `ui_home_mixin_*`, `ui_search_mixin_*`, `ui_settings_mixin_*`; `m3u_mixin_*` for `M3UClient`). Mixin modules are imported only by their main module; never import one directly.
- `tmdb*.py`, `imdb.py`, `fanart.py`, `artwork_*.py`, `title_logo_*.py` - metadata and artwork.
- `web/`, `webqr/`, `webbrowse.py`, `webcleaner.py` - optional web interface.
- `localization.py`, `language_catalog.py`, `locale/`, `locale_packs/` - localization.
- `assets_fhd/`, `plugin*.png`, `keymap.xml` - graphics and key bindings.
- `version.py` - version constants. `COPYRIGHT.txt`, `THIRD_PARTY_NOTICES.txt`, `FONT_AWESOME_FREE_LICENSE.txt` - licensing.

README.md and CHANGELOG.md are documentation only; the code never reads them.

## Tests

From the repository tooling directory:

    python3 /home/claude/tests/run_tests.py

All tests must pass. A compile check is also expected: `python3 -m compileall -q <plugin dir>`.

## Locale pack format

Packs live in `locale_packs/<language-code>.json` (UTF-8 JSON), for example `pt-br.json`:

    {"_meta": {"schema": 1, "code": "es", "complete": true},
     "translations": {"Settings": "Ajustes"}}

A pack is selectable only when marked `complete` and valid. Keys are the English source strings. Provider titles and content are never translated; Description Language is a separate setting. Bundled packs: 28 languages (see the directory).

## Build notes

The `.ipk` is an ar archive of `debian-binary`, `control.tar.*` (control, preinst, postinst, postrm) and `data.tar.*` (this tree under `usr/lib/enigma2/python/Plugins/Extensions/`). Remove `__pycache__` directories before packaging. Bump `version.py` (PLUGIN_REVISION) and the control file Version/Description for each release.
