# -*- coding: utf-8 -*-
"""Poster generation, UI hook teardown and job draining.

Methods moved verbatim out of ``PortalGlobalSearchScreen`` (ui_screens_search.py); behaviour is unchanged.
This module is imported by ui_screens_search.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, us_clear, us_func
from .ui_screens_search import (
    AsyncScreenMixin,
    OrderedDict,
    SearchPosterFlights,
    _mem34,
    _valid,
    queue,
    threading,
)


class SearchHooksMixin(object):
    """Poster generation, UI hook teardown and job draining."""

    def _advance_poster_generation(self):
        old_event=getattr(self,"_poster_cancel_event",None)
        if old_event is not None:
            try:old_event.set()
            except Exception:pass
        futures=getattr(self,"_poster_futures",None)
        if not isinstance(futures,set):
            futures=set();self._poster_futures=futures
        for future in list(futures):
            if future is None or future.done():
                futures.discard(future);continue
            try:future.cancel()
            except Exception as exc:optional_failure("ui.search_poster_cancel",exc)
            if future.done():futures.discard(future)
        self._poster_generation += 1
        self._poster_cancel_event = threading.Event()
        self._search_poster_flights = SearchPosterFlights()
        try:
            while True:self._poster_jobs.get_nowait()
        except queue.Empty:
            pass
        except Exception as exc:optional_failure("ui.search_poster_queue_drain",exc)
        return self._poster_generation,self._poster_cancel_event

    def _poster_ready_get(self, ident):
        cache=getattr(self,"_poster_ready_cache",None)
        if not isinstance(cache,OrderedDict):return ""
        path=str(cache.get(str(ident)) or "")
        if path and _valid(path):
            try:cache.move_to_end(str(ident))
            except Exception:pass
            return path
        cache.pop(str(ident),None)
        return ""

    def _poster_ready_put(self, ident, path):
        path=str(path or "")
        if not path or not _valid(path):return
        cache=getattr(self,"_poster_ready_cache",None)
        if not isinstance(cache,OrderedDict):
            cache=OrderedDict();self._poster_ready_cache=cache
        key=str(ident);cache[key]=path
        try:cache.move_to_end(key)
        except Exception:pass
        while len(cache)>56:
            try:cache.popitem(last=False)
            except Exception:break

    def _stop_search_hooks(self):
        _mem34("search_close", results=len(getattr(self,"results",[]) or []), ready_posters=len(getattr(self,"_poster_ready_cache",{}) or {}))
        self._cancel_xtream_warm()
        self._advance_poster_generation()
        for q in (self._search_partial_jobs, self._poster_jobs):
            try:
                while True:
                    q.get_nowait()
            except Exception:
                pass
        for i in range(self.PAGE_SIZE):
            try:
                art = self["result_art%d" % i]
                if art.instance is not None:
                    art.instance.setPixmap(None)
            except Exception:
                pass
        # PERF35: closed Search screens can stay referenced by Enigma2 for an
        # event-loop turn. Drop screen-local result/copy dictionaries now so a
        # large multi-portal result set is not retained during that grace period.
        try:self.results=[]
        except Exception:pass
        try:self._search_bucket_rows={"vod": [], "series": []}
        except Exception:pass
        try:us_clear(self._search_groups)
        except Exception:pass
        try:us_clear(self._search_seen)
        except Exception:pass
        try:self._search_errors=[]
        except Exception:pass
        try:us_clear(self._poster_ready_cache)
        except Exception:pass
        try:self._search_settings={}
        except Exception:pass
        self._render_signature=()
        self._render_slot_signatures=[None]*self.PAGE_SIZE
        self._render_art_identities=[None]*self.PAGE_SIZE
        self._render_art_start=None

    def _drain_jobs(self):
        us_func(AsyncScreenMixin._drain_jobs)(self)
        if self._screen_closed:
            return
        self._drain_search_partials()
        self._drain_poster_jobs()
