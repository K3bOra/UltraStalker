# -*- coding: utf-8 -*-
"""Remembered audio/subtitle language, audio menu and media info.

Methods moved verbatim out of ``UltraStalkerPlayer`` (player_native.py); behaviour is unchanged.
This module is imported by player_native.py once its module-level helpers exist, so the
names below are taken from that module (partially initialised at this point) on purpose.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from ..us_env import str, int
from .player_native import (
    InfoBarAudioSelection,
    LOG,
    PlayerInformationOverlay,
    _,
    _is_subtitle_selected,
    _subtitle_track_lang,
    _track_prefs,
    optional_failure,
)


class PlayerTrackPrefsMixin(object):
    """Remembered audio/subtitle language, audio menu and media info."""

    # ------------------------------------------------------------------
    # R5.145: remembered audio / embedded-subtitle LANGUAGE per movie / series.
    # One-shot: the language is applied once inside a short window after playback
    # starts and never again.  Any manual audio/subtitle action cancels it.
    def _track_pref_key(self):
        try:
            if self.media_type not in ("vod","episode","series"):return ""
            item=self._history_item if isinstance(self._history_item,dict) else (self.item if isinstance(self.item,dict) else {})
            src=self.item if isinstance(self.item,dict) else {}
            if self.media_type in ("episode","series"):
                sid=item.get("_series_id") or item.get("series_id") or src.get("_series_id") or src.get("series_id") or ""
                if not sid and self.media_type=="series":sid=item.get("id") or ""
                return _track_prefs.series_key(self._history_profile,sid)
            return str(getattr(self,"_subtitle_session_key","") or "")
        except Exception as exc:
            optional_failure("player.track_pref_key",exc)
            return ""

    def _track_pref_begin(self):
        self._track_pref_polls=0
        self._track_pref_audio_done=True
        self._track_pref_sub_done=True
        if not getattr(self,"_cfg_remember_tracks",True):return
        key=self._track_pref_key()
        pref=_track_prefs.get(key) if key else {}
        if not pref:return
        want_audio=str(pref.get("audio") or "")
        want_sub=""  # Subtitle restoration has one owner: _subtitle_saved_choice().
        if want_sub=="off":want_sub=""
        if not want_audio and not want_sub:return
        self._track_pref_wanted={"audio":want_audio,"sub":want_sub}
        self._track_pref_audio_done=not want_audio
        self._track_pref_sub_done=not want_sub
        try:self.track_pref_timer.start(1500,True)
        except Exception as exc:optional_failure("player.track_pref_timer",exc)

    def _track_pref_stop(self):
        self._track_pref_audio_done=True
        self._track_pref_sub_done=True
        try:self.track_pref_timer.stop()
        except Exception:pass
        try:
            if self.track_pref_timer_conn is not None:
                self.track_pref_timer_conn.disconnect()
                self.track_pref_timer_conn=None
        except Exception:pass
        try:
            if self._track_pref_tick in self.track_pref_timer.callback:
                self.track_pref_timer.callback.remove(self._track_pref_tick)
        except Exception:pass

    def _track_pref_tick(self):
        if self.restored or self._closing_playback or (self._track_pref_audio_done and self._track_pref_sub_done):
            return
        self._track_pref_polls+=1
        final=self._track_pref_polls>=10          # about 15 s after playback start
        try:
            service=self.session.nav.getCurrentService()
        except Exception:
            service=None
        if service is not None:
            if getattr(self,"_subtitle_manual_override",False):
                self._track_pref_audio_done=True
            if not self._track_pref_audio_done:
                state=self._track_pref_apply_audio(service,self._track_pref_wanted.get("audio",""))
                if state is True or (state is False and final):self._track_pref_audio_done=True
            if not self._track_pref_sub_done:
                if self._subtitle_user_override:
                    self._track_pref_sub_done=True      # the user already took over
                else:
                    state=self._track_pref_apply_subtitle(self._track_pref_wanted.get("sub",""))
                    if state is True or (state is False and final):self._track_pref_sub_done=True
        if final:
            self._track_pref_audio_done=True;self._track_pref_sub_done=True
        if not (self._track_pref_audio_done and self._track_pref_sub_done):
            try:self.track_pref_timer.start(1500,True)
            except Exception:pass

    def _track_pref_apply_audio(self,service,lang):
        """True = applied/already right, False = no such track yet, None = tracks not published."""
        try:
            tracks=service.audioTracks()
            if tracks is None:return None
            count=int(tracks.getNumberOfTracks() or 0)
            if count<=0:return None
            try:current=int(tracks.getCurrentTrack())
            except Exception:current=-1
            for index in range(count):
                info=tracks.getTrackInfo(index)
                code=_track_prefs.track_language(info)
                if code==lang:
                    if index!=current:tracks.selectTrack(index)
                    return True
            return False
        except Exception as exc:
            optional_failure("player.track_pref_audio",exc)
            return None

    def _track_pref_apply_subtitle(self,lang):
        try:
            entries=self._native_subtitle_track_list()
            if not entries:return None if entries is not None else False
            for entry in entries:
                try:code=_track_prefs.normalize_language(entry[4]) if len(entry)>4 else ""
                except Exception:code=""
                if code==lang:
                    self._subtitle_user_override=True
                    try:self.subtitle_default_timer.stop()
                    except Exception:pass
                    self.enableSubtitle(entry)
                    try:self["connection"].setText(_("PLAYING  •  SUBTITLES ON"))
                    except Exception:pass
                    return True
            return False
        except Exception as exc:
            optional_failure("player.track_pref_subtitle",exc)
            return None

    def _track_pref_current_audio_lang(self):
        try:
            service=self.session.nav.getCurrentService()
            tracks=service.audioTracks() if service else None
            if tracks is None:return ""
            count=int(tracks.getNumberOfTracks() or 0)
            current=int(tracks.getCurrentTrack())
            if current < 0 or current >= count:return ""
            info=tracks.getTrackInfo(current)
            return _track_prefs.track_language(info)
        except Exception:
            return ""

    def audioSelection(self,*args,**kwargs):
        # The user takes over: no remembered language is applied after this.
        self._track_pref_audio_done=True
        self._track_pref_audio_before=self._track_pref_current_audio_lang()
        parent=getattr(InfoBarAudioSelection,"audioSelection",None)
        if callable(parent):
            return parent(self,*args,**kwargs)

    def audioSelected(self,ret=None):
        parent=getattr(InfoBarAudioSelection,"audioSelected",None)
        try:
            if callable(parent):parent(self,ret)
        except Exception as exc:optional_failure("player.audio_selected_parent",exc)
        try:
            if getattr(self,"_cfg_remember_tracks",True):
                key=self._track_pref_key()
                lang=self._track_pref_current_audio_lang()
                if key and lang and lang!=self._track_pref_audio_before:
                    _track_prefs.put(key,audio=lang)
        except Exception as exc:optional_failure("player.track_pref_audio_capture",exc)
        try:
            if self._lb_active():self._lb_langs_update(force=True)
        except Exception:pass

    def _track_pref_capture_subtitle(self):
        """After the native subtitle screen: remember the chosen embedded language."""
        try:
            if not getattr(self,"_cfg_remember_tracks",True):return
            key=self._track_pref_key()
            sel=getattr(self,"selected_subtitle",None)
            if not key:return
            if not _is_subtitle_selected(sel):
                _track_prefs.put(key,sub="off");return
            try:service=self.session.nav.getCurrentService()
            except Exception:service=None
            code=_subtitle_track_lang(service,sel)
            if code:_track_prefs.put(key,sub=code)
        except Exception as exc:optional_failure("player.track_pref_sub_capture",exc)

    def show_media_info(self):
        meta="%s   •   %s   •   %s   •   %s"%(self._category_label(),self["video_quality"].getText(),self["video_codec"].getText(),self["audio_codec"].getText())
        self._media_info_open=True
        try:
            if self._online_subtitle_overlay is not None:self._online_subtitle_overlay.hide()
        except Exception:pass
        try:
            self._set_infobar_visuals(False)
        except Exception as exc:optional_failure("player",exc)
        try:self.session.openWithCallback(self._media_info_closed,PlayerInformationOverlay,self.name,self.item,self.media_type,meta,self._poster_path)
        except Exception as exc:
            LOG.warning("Nova media information overlay failed: %s", exc)
            try:self["connection"].setText(_("MEDIA INFO UNAVAILABLE"))
            except Exception as exc:optional_failure("player",exc)

    def _media_info_closed(self,*args):
        self._media_info_open=False
        try:self.doShow()
        except Exception:
            try:self.show()
            except Exception as exc:optional_failure("player",exc)
