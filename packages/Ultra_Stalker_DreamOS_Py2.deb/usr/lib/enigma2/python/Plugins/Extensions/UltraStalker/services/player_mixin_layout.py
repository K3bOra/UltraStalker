# -*- coding: utf-8 -*-
"""Localised key/technical layout, title fitting and VOD title area.

Methods moved verbatim out of ``UltraStalkerPlayer`` (player_native.py); behaviour is unchanged.
This module is imported by player_native.py once its module-level helpers exist, so the
names below are taken from that module (partially initialised at this point) on purpose.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from ..us_env import str, int, round, zip, max, min
from .player_native import (
    _,
    _PLAYER_BG_EXECUTOR,
    _cached_poster,
    _catalogue_title,
    _clean_live_name,
    _player_title_logo_source,
    _prepare_player_title_logo,
    _prepare_player_title_logo_cache_path,
    ePoint,
    eSize,
    gFont,
    getDesktop,
    load_settings,
    optional_failure,
    os,
    queue,
    re,
    time,
)


class PlayerLayoutMixin(object):
    """Localised key/technical layout, title fitting and VOD title area."""

    @staticmethod
    def _live_channel_font_size(text):
        """Large centered Live title that shrinks only when the name needs it."""
        value=str(text or "").strip()
        units=max(1.0,sum(1.32 if ord(ch)>127 else 1.0 for ch in value))
        if units<=22:return 34
        if units<=30:return 32
        if units<=38:return 30
        if units<=48:return 27
        if units<=60:return 24
        return max(18,min(22,int(1060.0/(units*0.58))))

    def _apply_live_channel_title(self):
        if self.media_type not in ("itv","live"):
            return
        title=_clean_live_name(str(self.name or "Live channel"),self._cfg_clean_titles)
        # R5.541: the Live bar measures and fits the name next to the chips.
        self._lb_title_full=title[:180]
        if self._lb_active():
            try:
                self["channel"].setText(title[:180])
                self._lb_layout_top()
                self["channel"].show()
                return
            except Exception as exc:
                optional_failure("player.live_bar_title_apply",exc)
        size=self._live_channel_font_size(title)
        try:
            self["channel"].setText(title[:180])
            if self["channel"].instance is not None:
                self["channel"].instance.setFont(_ultra_rfont("Regular",size))
            self["channel"].show()
        except Exception as exc:
            optional_failure("player.live_title_fit",exc)

    @staticmethod
    def _balanced_button_lines(text):
        """Return a balanced two-line label without changing translated wording."""
        value=" ".join(str(text or "").replace("\n"," ").split()).strip()
        parts=value.split(" ")
        if len(parts)<2:
            return value
        best=None
        for idx in range(1,len(parts)):
            left=" ".join(parts[:idx]);right=" ".join(parts[idx:])
            score=max(len(left),len(right))*4+abs(len(left)-len(right))
            if best is None or score<best[0]:
                best=(score,left,right)
        return (best[1]+"\n"+best[2]) if best else value

    def _localized_player_scale(self):
        try:return max(0.25,float(getDesktop(0).size().width())/1920.0)
        except Exception:return 1.0

    def _localized_player_measure(self, name, text, scale):
        widget=self[name];inst=widget.instance
        if inst is None:return None
        widget.setText(str(text or ""))
        inst.setFont(gFont("Regular",max(1,int(round(20*scale)))))
        inst.setNoWrap(1)
        size=inst.calculateSize()
        width=int(size.width())
        try:
            heights=getattr(self,"_localized_text_heights",None)
            if heights is None:heights={};self._localized_text_heights=heights
            heights[name]=max(1,int(size.height()))
        except Exception:pass
        return max(1,width)

    @staticmethod
    def _label_align_center(inst):
        # eLabel uses its own enum (alignLeft/alignCenter/alignRight...), not the
        # RT_* list flags; passing RT_* values gives wrong/top alignment.
        try:
            from enigma import eLabel as _eLabel
            inst.setHAlign(getattr(_eLabel,"alignCenter",1));inst.setVAlign(getattr(_eLabel,"alignCenter",1))
        except Exception as exc:optional_failure("player.label_align",exc)

    @staticmethod
    def _localized_player_widths(desired, budget, weights):
        # Share spare width; reserve each measured translation before decorating.
        budget=int(budget);desired=list(max(1,int(v)) for v in desired)
        total=sum(desired)
        if total>budget:
            values=list(max(1,int(v*budget/float(total))) for v in desired)
        else:
            spare=budget-total;weight_sum=float(sum(weights))
            values=list(v+int(spare*w/weight_sum) for v,w in zip(desired,weights))
        for i in range(budget-sum(values)):values[i%len(values)]+=1
        return values

    def _localized_player_rect(self, name, x, y, width, height):
        inst=self[name].instance
        if inst is not None:
            inst.move(ePoint(int(round(x)),int(round(y))))
            inst.resize(eSize(max(1,int(round(width))),max(1,int(round(height)))))

    def _layout_localized_player_keys(self):
        scale=self._localized_player_scale()
        colours=("red","green","yellow","blue")
        labels=(_("Buffer") if self.media_type in ("vod","series","episode","catchup") else _("Exit"),
                _("Aspect Ratio"),_("Subtitles"),_("Search"))
        measured=list(self._localized_player_measure("key_"+c,text,scale) for c,text in zip(colours,labels))
        if any(v is None for v in measured):return
        gap=int(round(32*scale));icon=int(round(56*scale));join=int(round(4*scale));pad=int(round(16*scale))
        budget=int(round(1540*scale))-3*gap
        widths=self._localized_player_widths(list(v+icon+join+pad for v in measured),budget,(1,1,1,1))
        x=int(round(320*scale))
        for colour,text,text_width,width in zip(colours,labels,measured,widths):
            room=width-icon-join
            # Keep each icon and its text together, centered as a single group.
            lead=max(0,(width-(icon+join+text_width+pad))//2)
            self._localized_player_rect("key_dash_"+colour,x+lead,1025*scale,icon,42*scale)
            label=self["key_"+colour];inst=label.instance
            # Size the label to the measured text so RTL/LTR text sits exactly
            # next to its colour line and the pair is centred in the slot.
            fits=text_width+pad<=room-lead
            lw=(text_width+pad) if fits else (room-lead)
            th=getattr(self,"_localized_text_heights",{}).get("key_"+colour,int(round(28*scale)))
            lh=(th+int(round(6*scale))) if fits else int(round(52*scale))
            self._localized_player_rect("key_"+colour,x+lead+icon+join,1046*scale-lh/2.0,lw,lh)
            self._label_align_center(inst)
            inst.setNoWrap(1 if fits else 0)
            x+=width+gap

    def _layout_localized_technical_cards(self, texts, force=False):
        scale=self._localized_player_scale()
        signature=(scale,tuple(texts))
        if not force and getattr(self,"_localized_technical_layout_signature",None)==signature:return
        measured=list(self._localized_player_measure(name,text,scale) for name,text in texts)
        if any(v is None for v in measured):return
        base=(165,195,185,150,175,170,287)
        gap=int(round(20*scale));padding=int(round(24*scale))
        budget=int(round(1447*scale))-6*gap
        widths=self._localized_player_widths(list(max(int(round(64*scale)),v+padding) for v in measured),budget,base)
        frames=("chip_video_quality_bg","chip_audio_codec_bg","chip_video_codec_bg","chip_fps_bg","chip_stream_bg","chip_audio_bg","chip_engine_bg")
        x=int(round(376*scale))
        height=56 if any(v+padding>w for v,w in zip(measured,widths)) else 46
        from ..ui_icon_menu import _us_fit_png
        glass_paths=getattr(self,"_technical_glass_paths",None) or {}
        for (name,text),frame,width,text_width in zip(texts,frames,widths,measured):
            try:
                bpath=glass_paths.get(frame)
                finst=self[frame].instance
                if bpath and os.path.isfile(bpath) and finst is not None:
                    fpath=_us_fit_png(bpath,max(1,int(round(width))),max(1,int(round(height*scale))),True)
                    if fpath and os.path.isfile(fpath):
                        finst.setPixmapFromFile(fpath)
            except Exception as exc:
                optional_failure("player.localized_chip_fit",exc)
            self._localized_player_rect(frame,x,947*scale,width,height*scale)
            inst=self[name].instance
            fits=text_width+padding<=width
            if fits:
                # Exact text box centred inside the chip (independent of text direction).
                th=getattr(self,"_localized_text_heights",{}).get(name,int(round(26*scale)))
                lw=min(width-4*scale,text_width+int(round(14*scale)));lh=th+int(round(4*scale))
                self._localized_player_rect(name,x+(width-lw)/2.0,947*scale+(height*scale-lh)/2.0,lw,lh)
            else:
                self._localized_player_rect(name,x+padding//2,947*scale+2*scale,width-padding,(height-4)*scale)
            self._label_align_center(inst)
            inst.setNoWrap(1 if fits else 0)
            x+=width+gap
        self._localized_technical_layout_signature=signature

    def _restore_english_technical_geometry(self):
        if getattr(self,"_localized_technical_layout_signature",None) is None:return
        scale=self._localized_player_scale()
        glass_paths=getattr(self,"_technical_glass_paths",None) or {}
        for name,x,width in (("quality",376,165),("audio_codec",561,195),("video_codec",776,185),("fps",981,150),("stream",1151,175),("audio",1346,170),("engine",1536,287)):
            frame="chip_video_quality_bg" if name=="quality" else ("chip_video_codec_bg" if name=="video_codec" else "chip_"+name+"_bg")
            try:
                bpath=glass_paths.get(frame)
                finst=self[frame].instance
                if bpath and os.path.isfile(bpath) and finst is not None:
                    finst.setPixmapFromFile(bpath)
            except Exception:
                pass
            self._localized_player_rect(frame,x*scale,947*scale,width*scale,46*scale)
        self._localized_technical_layout_signature=None

    def _fit_player_keybar_labels(self):
        # V9.2.2-r6: every interface language (English included) shows the colour
        # line with the translated text.  The engraved English artwork was removed.
        if self._lb_active():
            # R5.541: Live keys live inside the Live bar (line + text, every language).
            self._lb_layout_keys()
            return
        for _kc in ("red","green","yellow","blue"):
            try:
                self["key_dash_%s"%_kc].show();self["key_%s"%_kc].show()
            except Exception as exc:optional_failure("player.keybar_mode",exc)
        buffer_key=self.media_type in ("vod","series","episode","catchup")
        try:
            if buffer_key:
                self["key_red"].setText(_("Buffer"))
        except Exception as exc:optional_failure("player.buffer_key_text",exc)
        self._layout_localized_player_keys()

    def _layout_ready(self):
        if getattr(self,"media_type",None)=="trailer":
            return self._trailer922__layout_ready()
        try:
            if not self._resume_prepared:
                self["resume_mask"].hide()
        except Exception as exc:
            optional_failure("player.resume_mask_layout", exc)
        if self.media_type in ("itv","live"):
            try:self["vod_title"].hide();self["title_logo"].hide();self["episode_marker"].hide();self["episode_name"].hide()
            except Exception:pass
            self._apply_live_channel_title()
            self._bind_current_live_picon()
            self._apply_live_infobar_layout()
            self._refresh_live_epg()
        else:
            if not self._lb_active():self._lb_hide()
            self._configure_vod_title_area()
            artwork = _cached_poster(self.item, self.name, self.media_type)
            self._load_poster(artwork)
            self._us_poster_fallback(artwork)
            # R5.542: Movies/Series use the same bar, poster on its left corner.
            self._live_bar_apply(force=True)
        self._fit_player_keybar_labels()
        try:self._apply_technical_row_layout(bool(getattr(self,"_audio_format_badge_active",False)))
        except Exception as exc:optional_failure("player.technical_row_layout_ready",exc)
        self._update_stream_info()

    @staticmethod
    def _player_fallback_title(item, name, media_type, clean_titles=True):
        """Clean text used only when the persistent Player title logo is absent.

        Prefer catalogue metadata (and a parent-series title for episodes), then
        remove filename-style separators, episode tokens and common stream tags.
        Playback identity and title-logo lookup remain untouched.
        """
        data=item if isinstance(item,dict) else {}
        mt=str(media_type or "").lower()
        candidates=[]
        if mt in ("series","episode","tv"):
            candidates.extend((data.get("_series_title"),data.get("series_title"),data.get("series_name")))
        candidates.extend((data.get("title"),data.get("name"),name))
        raw=""
        for value in candidates:
            text=str(value or "").strip()
            if text and text.lower() not in ("none","null"):
                raw=text;break
        if not raw:return str(name or "").strip()
        if not clean_titles:
            return raw
        text=re.sub(r"\.(?:mkv|mp4|avi|mov|ts|m2ts|wmv|flv|webm)$","",raw,flags=re.I)
        text=re.sub(r"(?i)(?:^|[._\-\s])S\d{1,2}E\d{1,3}(?=$|[._\-\s])"," ",text)
        text=re.sub(r"(?i)(?:^|[._\-\s])\d{1,2}x\d{1,3}(?=$|[._\-\s])"," ",text)
        text=re.sub(r"(?i)(?:^|[._\-\s])Season[._\-\s]*\d{1,2}[._\-\s]*Episode[._\-\s]*\d{1,3}(?=$|[._\-\s])"," ",text)
        text=re.sub(r"[._]+"," ",text)
        # Player-only filename noise. Keep this deliberately narrow so real title
        # words survive while common release/stream tags do not leak on-screen.
        text=re.sub(r"(?i)(?:^|\s)(?:2160p|1080p|720p|576p|480p|4k|uhd|hdr10\+?|hdr|dv|dolby[ ._-]*vision|web[ ._-]*dl|webrip|bluray|blu[ ._-]*ray|brrip|bdremux|remux|hdtv|x264|x265|h\.?264|h\.?265|hevc|av1|aac(?:2\.?0|5\.?1)?|ddp?5\.?1|eac3|ac3|dts(?:[ ._-]*hd)?)(?=$|\s)"," ",text)
        text=re.sub(r"\s+"," ",text).strip(" -_|:.")
        cleaned=_catalogue_title(text) or text
        cleaned=re.sub(r"\s+"," ",str(cleaned or "")).strip(" -_|:.")
        return cleaned or str(name or "").strip()

    @staticmethod
    def _player_title_font_size(text):
        value=str(text or "").strip()
        units=max(1.0,sum(1.32 if ord(ch)>127 else 1.0 for ch in value))
        if units<=16:return 58
        if units<=28:return 52
        if units<=40:return 44
        if units<=54:return 36
        if units<=70:return 30
        # 1220px title area: continue shrinking instead of freezing at 26px.
        return max(18,min(26,int(1180.0/(units*0.57))))

    @staticmethod
    def _episode_display_number(item):
        item=item if isinstance(item,dict) else {}
        for key in ("_episode_number","episode_number","episode","number","episode_num","episode_id"):
            value=item.get(key)
            text=str(value or "").strip()
            if not text or text.lower() in ("none","null"):
                continue
            match=re.search(r"\d+", text)
            if not match:
                continue
            try:return str(int(match.group(0)))
            except Exception:return match.group(0)
        return ""

    def _episode_marker_text(self):
        cached=getattr(self,"_static_episode_marker",None)
        if cached is not None:return cached
        if self.media_type not in ("series","episode"):
            self._static_episode_marker="";return ""
        number=self._episode_display_number(self.item)
        self._static_episode_marker=(_("Episode %s") % number) if number else ""
        return self._static_episode_marker

    def _episode_name_apply(self):
        """V9.2.2-r6: real episode name under the "Episode N" marker (classic bar).

        Hidden when the episode has no real name (portals that only send "01",
        "Episode 1"...).  When the series title is plain text instead of a logo,
        the name lane is shortened so it never runs into the centred title.
        """
        try:
            widget=self["episode_name"]
            if self.media_type not in ("series","episode") or self._lb_active():
                widget.hide();return
            name=""
            if self._episode_marker_text():
                from ..episode_labels import episode_name
                name=episode_name(self.item)
            if not name:
                widget.hide();return
            from ..wqhd_layout import factors
            sx,sy=factors()
            width=int(round(560*sx))
            try:
                title=self["vod_title"]
                if title.instance is not None and getattr(title,"visible",False):
                    left=int(round(1040*sx))-int(title.instance.calculateSize().width())//2
                    width=max(int(round(120*sx)),min(int(round(560*sx)),left-int(round(394*sx))))
            except Exception:width=int(round(560*sx))
            if widget.instance is not None:
                widget.instance.resize(eSize(int(width),int(round(28*sy))))
            widget.setText(name);widget.show()
        except Exception as exc:
            optional_failure("player.episode_name",exc)

    def _configure_vod_title_area(self):
        if getattr(self,"media_type",None)=="trailer":
            return self._trailer922__configure_vod_title_area()
        """VOD/episode Player: Cinematic authority -> local Player presentation.

        The Player never resolves a separate Player-logo identity.  It consumes
        the current screen/Cinematic 420x144 Ultra authority.  When that
        authority is missing, one background job resolves the *Cinematic*
        variant for the current locked item, then derives the 1220x72 Player
        canvas locally from that exact file.
        """
        if self._lb_mode()=="vod":
            # R5.542: the bar shows the clean title as measured text next to the
            # chips (no 1220px title-logo canvas, no background logo job).
            try:
                self._player_title_logo_token+=1
                self._player_title_logo_pending=False;self._player_title_logo_path=""
                title=self._player_fallback_title(self.item,self.name,self.media_type,self._cfg_clean_titles)
                self._lb_title_full=str(title or "")[:180]
                self["vod_title"].setText(self._lb_title_full)
                self._lb_vod_meta_cache=None
                self._lb_sig.pop("top",None);self._lb_sig.pop("vod",None)
                self._lb_suppress_legacy()
                self._lb_layout_top();self._lb_layout_vod_rows(True)
            except Exception as exc:optional_failure("player.live_bar_vod_title",exc)
            return
        try:
            for name in ("channel","category","quality","connection","now"):
                try:self[name].hide()
                except Exception:pass
            title=self._player_fallback_title(self.item,self.name,self.media_type,self._cfg_clean_titles)
            title,title_font=self._player_fit_title(title)

            # New-title boundary: invalidate every previous async/logo surface, not
            # merely hide it. A hidden Pixmap can be shown again by an InfoBar
            # restore path, which is how an old title logo leaked onto logo-less
            # films. The fallback title is authoritative until this title resolves.
            self._player_title_logo_token+=1
            token=self._player_title_logo_token
            future=getattr(self,"_player_title_logo_future",None)
            if future is not None:
                try:future.cancel()
                except Exception:pass
            self._player_title_logo_future=None
            self._player_title_logo_pending=False
            self._player_title_logo_path=""
            try:
                while True:self._player_title_logo_queue.get_nowait()
            except queue.Empty:
                pass
            try:
                if self["title_logo"].instance is not None:self["title_logo"].instance.setPixmap(None)
                self["title_logo"].hide()
            except Exception:pass
            try:
                if self["vod_title"].instance is not None:self["vod_title"].instance.setFont(_ultra_rfont("Regular",title_font))
            except Exception:pass
            marker=self._episode_marker_text()
            if marker:
                try:self["episode_marker"].setText(marker);self["episode_marker"].show()
                except Exception:pass
            else:
                try:self["episode_marker"].hide()
                except Exception:pass
            self["vod_title"].setText(title[:180]);self["vod_title"].show();self["title_logo"].hide();self._player_title_logo_path=""
            self._episode_name_apply()

            logo_item=(self.item.get("_quality_parent_item") if self.media_type=="episode" and isinstance(self.item,dict) and isinstance(self.item.get("_quality_parent_item"),dict) else self.item) if isinstance(self.item,dict) else {}
            if not isinstance(logo_item,dict):logo_item={}
            # R151: Trailer keeps its own playback lifecycle, but visual lookup
            # must use the movie/series identity that launched it.  Without this
            # bridge a cache miss was queried as media_type=trailer, so Portal
            # trailers could show an empty poster frame and plain text title.
            logo_media_type=self.media_type
            if self.media_type=="trailer" and isinstance(self.item,dict):
                parent=str(self.item.get("_trailer_parent_media_type") or "").strip().lower()
                if parent in ("vod","movie"):logo_media_type="vod"
                elif parent in ("series","episode","tv"):logo_media_type="series"
            # Preserve the Player handoff/locked identity on the actual logo owner.
            for key in ("_player_title_logo_tmdb_id","_locked_tmdb_id"):
                value=(self.item.get(key) if isinstance(self.item,dict) else None)
                if value not in (None,""):logo_item[key]=value
            authority=_player_title_logo_source(self.item if isinstance(self.item,dict) else logo_item,title,logo_media_type)
            if not authority:
                authority=_player_title_logo_source(logo_item,title,logo_media_type)
            # If this exact authority already has a prepared Player canvas, paint
            # it immediately without any Pillow work on the GUI thread.
            prepared=""
            try:
                target=_prepare_player_title_logo_cache_path(authority,(1220,72)) if authority else ""
                if target and os.path.isfile(target) and os.path.getsize(target)>256:prepared=target
            except Exception:prepared=""
            if prepared:
                if self["title_logo"].instance is not None:
                    self["title_logo"].instance.setPixmap(None);self["title_logo"].instance.setPixmapFromFile(prepared)
                self["title_logo"].show();self["vod_title"].hide();self._player_title_logo_path=prepared;self._episode_name_apply();return

            if self._player_title_logo_pending:return
            self._player_title_logo_pending=True
            result_queue=self._player_title_logo_queue
            media_copy=str(logo_media_type or self.media_type or "")
            profile_copy=dict(getattr(self,"_history_profile",{}) or {})
            logo_copy=dict(logo_item)
            authority_copy=str(authority or "")
            def worker():
                path="";source=authority_copy;resolved={}
                try:
                    # Missing Cinematic authority: resolve exactly the same
                    # 420x144 Ultra pipeline Cinematic uses, for this locked item.
                    if not (source and os.path.isfile(source) and os.path.getsize(source)>256):
                        from ..title_logo_ultra import resolve_ultra_title_logo
                        source,resolved=resolve_ultra_title_logo(profile_copy,media_copy,logo_copy,logo_copy,canvas_size=(420,144),visible_title=title,settings=load_settings() or {})
                    if source and os.path.isfile(source) and os.path.getsize(source)>256:
                        # Recent can be the first consumer of a freshly created
                        # Cinematic authority. Give the local Player derivative a
                        # few background-only retries so first open paints it; the
                        # user must never need to close/reopen the title.
                        for _attempt in range(3):
                            path=_prepare_player_title_logo(source,(1220,72)) or ""
                            if path:break
                            time.sleep(0.10)
                except Exception:pass
                try:result_queue.put((token,path,source,dict(resolved or {})))
                except Exception:pass
            try:
                self._player_title_logo_future=_PLAYER_BG_EXECUTOR.submit(worker)
                self.player_title_logo_timer.start(90,True)
            except Exception:
                self._player_title_logo_pending=False
                future=getattr(self,"_player_title_logo_future",None)
                if future is not None:
                    try:future.cancel()
                    except Exception:pass
                self._player_title_logo_future=None
        except Exception as exc:optional_failure("player.vod_title_area",exc)

    def _drain_player_title_logo(self):
        try:self.player_title_logo_timer.stop()
        except Exception:pass
        applied=False
        while True:
            try:job=self._player_title_logo_queue.get_nowait()
            except queue.Empty:break
            try:
                token,path=job[0],job[1];source=job[2] if len(job)>2 else "";resolved=job[3] if len(job)>3 and isinstance(job[3],dict) else {}
            except Exception:continue
            if token!=self._player_title_logo_token or self.restored or self._closing_playback:
                continue
            self._player_title_logo_pending=False
            self._player_title_logo_future=None
            try:
                if source and os.path.isfile(source) and os.path.getsize(source)>256:
                    tmdb_id=resolved.get("tmdb_id") or (self.item or {}).get("_player_title_logo_tmdb_id") or (self.item or {}).get("_locked_tmdb_id")
                    for obj in (self.item,self._history_item):
                        if not isinstance(obj,dict):continue
                        obj["_player_title_logo_cinematic_source"]=source
                        if tmdb_id not in (None,""):
                            obj["_player_title_logo_tmdb_id"]=tmdb_id;obj["_locked_tmdb_id"]=tmdb_id
                        for key in ("original_language","origin_country","countries","production_countries","original_title","original_name","logo_url","logo_language"):
                            value=resolved.get(key)
                            if value not in (None,"",[],{}):obj[key]=value
                if path and os.path.isfile(path) and os.path.getsize(path)>256 and self["title_logo"].instance is not None:
                    self["title_logo"].instance.setPixmap(None);self["title_logo"].instance.setPixmapFromFile(path);self["title_logo"].show();self["vod_title"].hide();self._player_title_logo_path=path;applied=True;self._episode_name_apply()
                else:
                    # A confirmed logo-less current title must explicitly clear the
                    # old GPU/Pixmap buffer and reveal its own text title.
                    if self["title_logo"].instance is not None:self["title_logo"].instance.setPixmap(None)
                    self["title_logo"].hide();self._player_title_logo_path="";self["vod_title"].show()
            except Exception as exc:optional_failure("player.title_logo_apply",exc)
        if self._player_title_logo_pending and not applied:
            try:self.player_title_logo_timer.start(90,True)
            except Exception:pass

from ..wqhd_layout import responsive_font as _ultra_rfont, factors as _ultra_factors

def _ultra_osd_scale():
    return _ultra_factors()[1]
