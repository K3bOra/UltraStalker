# -*- coding: utf-8 -*-
"""Provider artwork enrichment and series hierarchy.

Methods moved verbatim out of ``M3UClient`` (m3u_adapter.py); behaviour is unchanged.
This module is imported by m3u_adapter.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, us_casefold
from .m3u_adapter import (
    _portal_clean_title,
    _safe_int,
    diagnostic_failure,
    time,
)


class M3USeriesMixin(object):
    """Provider artwork enrichment and series hierarchy."""

    def enrich_provider_artwork(self, item, media_type, cancel_event=None, force=False):
        """Fetch authoritative Xtream metadata for M3U/Xtream catalogue rows.

        ``force`` is used after a list-level artwork URL failed. This matters on
        panels where get_vod_streams/get_series carries an empty/stale icon while
        get_vod_info/get_series_info contains the working cover/backdrop.
        """
        self._ensure(cancel_event)
        if not isinstance(item,dict) or not self._xtream:
            return item
        typ=str(media_type or item.get("_xtream_kind") or "").lower()
        if typ in ("itv","live"):
            return item
        # A catalogue poster is not a provider-info response. Always consult
        # the per-id info cache; the caller decides when TMDb has first refusal.
        sid=""
        if typ=="series":
            raw_sid=str(item.get("series_id") or "").strip()
            if raw_sid.isdigit():
                sid=raw_sid
            else:
                key=us_casefold(_portal_clean_title(item.get("name") or item.get("title") or "")).strip()
                src=self._ensure_xtream_series_name_index(cancel_event).get(key) or {}
                sid=str(src.get("series_id") or "").strip()
                if sid:
                    item["series_id"]=sid
                    self._merge_xtream_provider_info(item,{"info":src},"series")
        else:
            sid=str(item.get("stream_id") or "").strip()
        if not sid:
            return item
        item["_xtream"]=True;item["_xtream_kind"]=("series" if typ=="series" else "vod");item["_art_base"]=self._xtream.get("base","")
        cache_key=("series" if typ=="series" else "vod",sid)
        payload=self._xtream_info_cache.get(cache_key)
        failed_at=getattr(self,"_xtream_info_failed_at",{})
        if payload=={} and time.monotonic()-float(failed_at.get(cache_key,0))>=60:
            payload=None
        if payload is None:
            action="get_series_info" if typ=="series" else "get_vod_info"
            extra={"series_id":sid} if typ=="series" else {"vod_id":sid}
            payload=self._xtream_request(action,extra,timeout=self.full_timeout,cancel_event=cancel_event)
            if not isinstance(payload,dict): payload={}
            self._xtream_info_cache[cache_key]=payload
            if not payload:
                failed_at[cache_key]=time.monotonic();self._xtream_info_failed_at=failed_at
            else:failed_at.pop(cache_key,None)
        return self._merge_xtream_provider_info(item,payload,"series" if typ=="series" else "vod")

    def _series_index_keys(self, series_item):
        if not isinstance(series_item,dict):return []
        keys=[]
        for value in (series_item.get("id"),series_item.get("series_id"),series_item.get("xtream_series_id"),series_item.get("stream_id")):
            text=str(value or "").strip()
            if text and text not in keys:keys.append(text)
        return keys

    def _series_index_lookup(self, series_item):
        keys=self._series_index_keys(series_item)
        for key in keys:
            data=self._series_index.get(key)
            if isinstance(data,dict):
                return key,data
        return (keys[0] if keys else ""),{}

    def prefetch_series_hierarchy(self, series_item, cancel_event=None):
        """Warm one focused M3U/Xtream series before the user presses OK."""
        if not isinstance(series_item,dict):return False
        self._ensure(cancel_event)
        if not series_item.get("_xtream"):
            return True
        self._ensure_xtream_series_info(series_item,cancel_event)
        return True

    def _ensure_xtream_series_info(self, series_item, cancel_event=None):
        self._ensure(cancel_event)
        if not isinstance(series_item,dict) or not series_item.get("_xtream"):
            return
        sid_key,data=self._series_index_lookup(series_item)
        if data.get("seasons"):
            return
        real_sid=str(data.get("xtream_series_id") or series_item.get("series_id") or "").strip()
        if not real_sid:
            # Recover a missing/decoration-changed series_id from the Xtream name index.
            key=us_casefold(_portal_clean_title(series_item.get("name") or series_item.get("title") or "")).strip()
            try:src=self._ensure_xtream_series_name_index(cancel_event).get(key) or {}
            except Exception:src={}
            real_sid=str(src.get("series_id") or "").strip()
            if real_sid:series_item["series_id"]=real_sid
        if not real_sid:
            return
        cache_key=("series",real_sid)
        info=self._xtream_info_cache.get(cache_key)
        if info is None:
            info=self._xtream_request("get_series_info",{"series_id":real_sid},
                                      timeout=self.full_timeout,cancel_event=cancel_event)
            if not isinstance(info,dict):info={}
            self._xtream_info_cache[cache_key]=info
        self._merge_xtream_provider_info(series_item,info,"series")
        if isinstance(data.get("item"),dict):
            self._merge_xtream_provider_info(data["item"],info,"series")
        episodes_by_season={}
        episodes=(info.get("episodes") if isinstance(info,dict) else {}) or {}
        for season_no,rows in episodes.items() if isinstance(episodes,dict) else []:
            bucket=[]
            for row in rows if isinstance(rows,list) else []:
                if not isinstance(row,dict):continue
                eid=row.get("id") or row.get("episode_id")
                epnum=row.get("episode_num") or row.get("episode") or len(bucket)+1
                ext=row.get("container_extension") or "mp4"
                title=str(row.get("title") or row.get("name") or ("Episode %s"%epnum))
                url=self._xtream_stream_url("series",eid,ext)
                bucket.append({
                    "id":"xt-ep-%s"%eid,"episode_id":str(eid),"episode":_safe_int(epnum,0),"number":_safe_int(epnum,0),
                    "season":_safe_int(season_no,1) or 1,"season_id":str(season_no or 1),
                    "movie_id":real_sid,"series_id":real_sid,
                    "name":title,"title":title,"cmd":url,"url":url,
                    "container_extension":ext,
                    "_xtream":True,"_xtream_kind":"series_episode",
                })
            episodes_by_season[str(season_no)]=bucket
        data=dict(data or {})
        data["seasons"]=episodes_by_season
        data["xtream_series_id"]=real_sid
        # Alias every known identity to the same hierarchy. This prevents a rich
        # provider merge or decorated list id from making one series "disappear".
        alias_keys=self._series_index_keys(series_item)
        if sid_key and sid_key not in alias_keys:alias_keys.append(sid_key)
        if real_sid not in alias_keys:alias_keys.append(real_sid)
        for key in alias_keys:
            self._series_index[key]=data
        # Do not hold the seasons callback behind a full catalogue disk write.
        try:self._schedule_series_persist()
        except Exception as exc:diagnostic_failure("m3u.series_async_persist",exc)

    def series_seasons(self,series_item,cancel_event=None):
        self._ensure(cancel_event)
        if isinstance(series_item,dict) and series_item.get("_xtream"):
            self._ensure_xtream_series_info(series_item,cancel_event)
        sid,data=self._series_index_lookup(series_item)
        out=[]
        for season_no,episodes in sorted((data.get("seasons") or {}).items(),key=lambda x:(_safe_int(x[0],0),str(x[0]))):
            out.append({"id":season_no,"season_id":season_no,"season":_safe_int(season_no,0),"name":"Season %s"%season_no,"episodes":episodes,"series":episodes,"parent_series_id":sid})
        return out

    def series_episodes(self,series_item,season_item,cancel_event=None):
        embedded=(season_item or {}).get("episodes") or (season_item or {}).get("series")
        if isinstance(embedded,list):return list(dict(x) for x in embedded)
        if isinstance(series_item,dict) and series_item.get("_xtream"):
            self._ensure_xtream_series_info(series_item,cancel_event)
        sid,data=self._series_index_lookup(series_item)
        season=str((season_item or {}).get("season") or (season_item or {}).get("season_id") or "1")
        return list(dict(x) for x in ((data or {}).get("seasons") or {}).get(season,[]))
