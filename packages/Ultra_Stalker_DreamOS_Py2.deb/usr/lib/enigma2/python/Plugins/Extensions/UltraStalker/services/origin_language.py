# -*- coding: utf-8 -*-
"""User-selected country-to-language display policy; never selects audio tracks."""
from __future__ import absolute_import, division, print_function, unicode_literals
from .. import us_env as _us_env
from ..us_env import str, chr, min, us_casefold
re = _us_env.re
import unicodedata

ORIGIN_FIELDS = ("country_code", "country", "origin_country", "countries",
                 "production_country", "production_countries", "original_language")

_COUNTRIES = {}


def _norm(value):
    value = us_casefold(unicodedata.normalize("NFKC", str(value or "")))
    return " ".join(re.sub(r"[^\w]+", " ", value).replace("_", " ").split())


def _register(label, values):
    for value in values:
        _COUNTRIES[_norm(value)] = label


_register("Arabic", (
    "EG", "EGY", "Egypt", "مصر", "Egyptian", "LB", "Lebanon", "لبنان",
    "SA", "Saudi Arabia", "السعودية", "AE", "United Arab Emirates", "UAE", "الإمارات", "الامارات",
    "KW", "Kuwait", "الكويت", "QA", "Qatar", "قطر", "BH", "Bahrain", "البحرين",
    "OM", "Oman", "عمان", "JO", "Jordan", "الأردن", "الاردن", "SY", "Syria", "سوريا",
    "IQ", "Iraq", "العراق", "PS", "Palestine", "فلسطين", "YE", "Yemen", "اليمن",
    "MA", "Morocco", "المغرب", "DZ", "Algeria", "الجزائر", "TN", "Tunisia", "تونس",
    "LY", "Libya", "ليبيا", "SD", "Sudan", "السودان", "MR", "Mauritania", "موريتانيا",
    "SO", "Somalia", "الصومال", "DJ", "Djibouti", "جيبوتي", "KM", "Comoros", "جزر القمر"))
_register("Korean", ("KR", "KOR", "KP", "South Korea", "North Korea", "Korea", "Republic of Korea", "Korea Republic of", "Korean", "كوريا", "كوريا الجنوبية", "كوريا الشمالية", "대한민국"))
_register("Turkish", ("TR", "TUR", "Turkey", "Türkiye", "Turkiye", "Turkish", "تركيا"))
_register("Hindi", ("IN", "IND", "India", "Indian", "الهند"))
_register("Japanese", ("JP", "JPN", "Japan", "Japanese", "اليابان", "日本"))
_register("Chinese", ("CN", "CHN", "TW", "TWN", "HK", "HKG", "MO", "China", "Taiwan", "Hong Kong", "Macao", "Macau", "Chinese", "الصين", "تايوان", "هونغ كونغ", "中国"))
_register("Thai", ("TH", "THA", "Thailand", "Thai", "تايلاند"))
_register("Vietnamese", ("VN", "VNM", "Vietnam", "Viet Nam", "فيتنام"))
_register("Indonesian", ("ID", "IDN", "Indonesia", "إندونيسيا", "اندونيسيا"))
_register("Malay", ("MY", "MYS", "Malaysia", "ماليزيا", "BN", "Brunei"))
_register("Filipino", ("PH", "PHL", "Philippines", "الفلبين"))
_register("Persian", ("IR", "IRN", "Iran", "إيران", "ايران"))
_register("Urdu", ("PK", "PAK", "Pakistan", "باكستان"))
_register("Bengali", ("BD", "BGD", "Bangladesh", "بنغلاديش"))
_register("Nepali", ("NP", "NPL", "Nepal", "نيبال"))
_register("Sinhala", ("LK", "LKA", "Sri Lanka", "سريلانكا"))
_register("Burmese", ("MM", "MMR", "Myanmar", "Burma", "ميانمار"))
_register("Khmer", ("KH", "KHM", "Cambodia", "كمبوديا"))
_register("Lao", ("LA", "LAO", "Laos", "لاوس"))
_register("Mongolian", ("MN", "MNG", "Mongolia", "منغوليا"))
_register("Russian", ("RU", "RUS", "Russia", "Russian Federation", "روسيا"))
_register("Hebrew", ("IL", "ISR", "Israel", "إسرائيل", "اسرائيل"))
_register("French", ("FR", "FRA", "France", "French", "فرنسا"))
_register("Italian", ("IT", "ITA", "Italy", "Italian", "إيطاليا", "ايطاليا"))
_register("German", ("DE", "DEU", "Germany", "German", "Deutschland", "ألمانيا", "المانيا"))
_register("English", ("US", "USA", "United States", "United States of America", "GB", "UK", "United Kingdom", "CA", "Canada", "AU", "Australia", "NZ", "New Zealand", "IE", "Ireland", "SG", "Singapore"))

_LANGUAGES = {
    "fr": "French", "fra": "French", "fre": "French", "it": "Italian", "ita": "Italian",
    "de": "German", "deu": "German", "ger": "German",
    "ar": "Arabic", "ara": "Arabic", "ko": "Korean", "kor": "Korean",
    "tr": "Turkish", "tur": "Turkish", "hi": "Hindi", "hin": "Hindi",
    "ja": "Japanese", "jpn": "Japanese", "zh": "Chinese", "zho": "Chinese", "chi": "Chinese",
    "yue": "Cantonese", "th": "Thai", "tha": "Thai", "vi": "Vietnamese", "vie": "Vietnamese",
    "id": "Indonesian", "ind": "Indonesian", "ms": "Malay", "msa": "Malay",
    "tl": "Filipino", "fil": "Filipino", "fa": "Persian", "fas": "Persian", "per": "Persian",
    "ur": "Urdu", "urd": "Urdu", "bn": "Bengali", "ben": "Bengali",
    "ta": "Tamil", "tam": "Tamil", "te": "Telugu", "tel": "Telugu", "ml": "Malayalam", "mal": "Malayalam",
    "pa": "Punjabi", "pan": "Punjabi", "mr": "Marathi", "mar": "Marathi", "kn": "Kannada", "kan": "Kannada",
    "ru": "Russian", "rus": "Russian", "he": "Hebrew", "heb": "Hebrew",
}


def _rows(*items):
    seen, out = set(), []
    def visit(item, depth=0):
        if not isinstance(item, dict) or id(item) in seen or depth > 4:
            return
        seen.add(id(item))
        visit(item.get("_player_origin_metadata"), depth + 1)
        out.append(item)
        for key in ("_quality_parent_item", "_ultra_detail_snapshot", "_search_seed_snapshot", "item_overlay"):
            visit(item.get(key), depth + 1)
    for item in items:
        visit(item)
    return out


def work_origin_metadata(*items):
    result = {}
    for row in _rows(*items):
        for field in ORIGIN_FIELDS:
            value = row.get(field)
            if field not in result and value not in (None, "", [], {}):
                result[field] = value
    return result


def _country(value):
    if isinstance(value, dict):
        for key in ("iso_3166_1", "country_code", "code", "name"):
            if value.get(key):
                return _country(value[key])
        return ""
    if isinstance(value, (list, tuple)):
        for entry in value:
            label = _country(entry)
            if label:
                return label
        return ""
    raw = str(value or "").strip()
    flag = re.search(r"[\U0001f1e6-\U0001f1ff]{2}", raw)
    if flag:
        _units = flag.group(0)
        _cps = []
        _i = 0
        while _i < len(_units):
            _c = ord(_units[_i])
            if 0xD800 <= _c <= 0xDBFF and _i + 1 < len(_units):
                _c = 0x10000 + ((_c - 0xD800) << 10) + (ord(_units[_i + 1]) - 0xDC00)
                _i += 1
            _cps.append(_c)
            _i += 1
        raw = "".join(chr(_c - 0x1f1e6 + ord("A")) for _c in _cps)
    text = _norm(raw)
    if text in ("", "none", "null", "unknown", "n a", "0"):
        return ""
    if text in _COUNTRIES:
        return _COUNTRIES[text]
    # Accommodate provider strings such as "['KR']", "KR / South Korea", and
    # serialized country dictionaries, without evaluating provider-supplied code.
    hits = []
    for alias, label in _COUNTRIES.items():
        match = re.search(r"(?<!\w)" + re.escape(alias) + r"(?!\w)", text)
        if match:
            hits.append((match.start(), -len(alias), label))
    return min(hits)[2] if hits else "English"


def work_language_label(*items):
    """English display names per the requested origin policy, without network IO."""
    rows = _rows(*items)
    for row in rows:
        for field in ORIGIN_FIELDS[:-1]:
            label = _country(row.get(field))
            if label:
                return label
    # Country missing: reuse the work's original language, never a track codec.
    for row in rows:
        raw = str(row.get("original_language") or "").lower().replace("_", "-").split("-", 1)[0]
        if raw in _LANGUAGES:
            return _LANGUAGES[raw]
    return "English"
