# -*- coding: utf-8 -*-
"""Grid art hooks, surface release/restore around child screens, details handoff and page preparation.

Methods moved verbatim out of ``PremiumGlobalCinematicScreen`` (ui_cinematic_global.py); behaviour is unchanged.
This module is imported by ui_cinematic_global.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, min, us_clear, us_func
from .ui_cinematic_global import (
    PremiumGridBase,
    _catalogue_title,
    optional_failure,
    os,
    queue,
    threading,
)


class CineSurfacesMixin(object):
    """Grid art hooks, surface release/restore around child screens, details handoff and page preparation."""

    # Cinematic is a vertical Settings/Episodes list, not a poster grid.  The
    # inherited PremiumGridBase constructor calls self._grid_art_init(), so an
    # override here prevents the hidden 1x1 GridArtwork ePicLoad from ever being
    # constructed.  This is intentionally done before PremiumGridBase.__init__
    # runs; stopping it later is too late because OpenBH has already allocated
    # the native decoder/surface.
    def _grid_art_init(self, slot_names, image_size, profile, client):
        self._grid_slot_names=[]
        self._grid_image_size=(0,0)
        self._grid_profile=profile
        self._grid_client=client
        self._grid_generation=0
        self._grid_download_jobs=queue.Queue()
        self._grid_decode_queue=[]
        self._grid_decode_busy=False
        self._grid_decode_active=None
        self._grid_closed=False
        self._grid_decode_cache={}
        self._grid_decode_cache_limit=0
        self._grid_waiting={}
        self._grid_queued=set()
        self._grid_slot_paths={}
        self._grid_palette_sources={}
        self._grid_accent_jobs=queue.Queue()
        self._grid_accent_pending=set()
        self._grid_download_inflight={}
        self._grid_download_futures={}
        self._grid_poster_thumb_pending=set()
        self._grid_download_lock=threading.Lock()
        self._grid_picload=None
        self._grid_pic_connection=None

    def _grid_art_layout_ready(self):
        # No hidden GridArtwork decoder exists in Cinematic.
        return

    def _grid_layout_ready(self):
        # Preserve PremiumGridBase catalogue/navigation startup while skipping
        # its selector/grid-art setup.  This is the only page bootstrap the
        # Cinematic screen needs.
        try:self._update_grid_clock()
        except Exception:pass
        term=str(getattr(self,"_open_search_term","") or "")
        if term:
            self._open_search_term=""
            self._section_search_started=True
            self._folder_search_entered(term)
            return
        self.load_page(self._restore_page,self._restore_index)

    def _grid_hidden_release(self):
        self._grid_images_suspended=True

    def _cin_release_surfaces_for_child(self):
        """Release only rendered/native Cinematic surfaces before a child opens.

        Canonical poster/backdrop files stay on HDD and their paths are retained.
        This is a gAccel surface-budget handoff, not an artwork/cache eviction.
        Releasing here happens *before* Details is instantiated, which gives the
        receiver room for the child's 1620x620/backdrop/glass allocations.
        """
        saved={}
        try:
            for base in ("cin_backdrop",):
                active=self._cin_active_pixmap.get(base,base)
                path=str(self._cin_pixmap_paths.get(active) or "")
                if path and os.path.isfile(path):saved[base]=path
        except Exception as exc:optional_failure("cinematic.surface_budget_capture",exc)
        # Preserve lightweight chrome paths too, but drop their native gPixmaps.
        try:
            for name,path in dict(getattr(self,"_cin_widget_paths",{}) or {}).items():
                if path and os.path.isfile(str(path)):saved["widget:"+str(name)]=str(path)
        except Exception as exc:optional_failure("cinematic.surface_budget_capture_chrome",exc)
        self._cin_suspended_visual_paths=saved

        # The large backdrop/panel surfaces are the important wins. Small labels
        # remain untouched; only native image surfaces are released.
        heavy=(
            "cin_backdrop","cin_backdrop_stage",
            "panel_bg","overview_bg","quality_pill_bg","year_pill_bg",
            "runtime_pill_bg","country_pill_bg","genre_pill_bg",
            "quality_logo","runtime_icon","country_flag"
        )
        for name in heavy:
            try:_release_pixmap_widget(self,name)
            except Exception as exc:optional_failure("cinematic.surface_budget_release",exc)
        us_clear(self._cin_pixmap_paths);us_clear(self._cin_widget_paths)
        self._cin_active_pixmap={"cin_backdrop":"cin_backdrop"}
        try:_native_image_pressure_relief(force=True)
        except Exception as exc:optional_failure("cinematic.surface_budget_relief",exc)

    def _cin_restore_surfaces_after_child(self):
        """HDD-only rebind of the exact visuals released for the child."""
        saved=dict(getattr(self,"_cin_suspended_visual_paths",{}) or {})
        if not saved:return
        try:
            for base in ("cin_backdrop",):
                path=str(saved.get(base) or "")
                if path and os.path.isfile(path) and self[base].instance is not None:
                    self[base].instance.setPixmapFromFile(path);self[base].show()
                    self._cin_pixmap_paths[base]=path;self._cin_active_pixmap[base]=base
            for key,path in saved.items():
                if not str(key).startswith("widget:"):continue
                name=str(key)[7:]
                if not path or not os.path.isfile(path):continue
                try:
                    if self[name].instance is not None:
                        self[name].instance.setPixmapFromFile(path);self[name].show();self._cin_widget_paths[name]=path
                except Exception as exc:optional_failure("cinematic.surface_budget_restore_widget",exc)
        except Exception as exc:optional_failure("cinematic.surface_budget_restore",exc)
        self._cin_suspended_visual_paths={}

    def _cin_force_cached_visual_rebind(self):
        """Rebind only already-cached cinematic pixmaps after Player returns.

        OpenBH can keep the Python path markers while dropping the native gPixmap
        surfaces during video playback.  Clear + bind the exact same HDD files;
        never rebuild artwork, hit TMDb, or change the selected item.
        """
        try:
            for base in ("cin_backdrop",):
                active=self._cin_active_pixmap.get(base,base)
                path=str(self._cin_pixmap_paths.get(active) or "")
                if path and os.path.isfile(path) and self[active].instance is not None:
                    try:self[active].instance.setPixmap(None)
                    except Exception:pass
                    self[active].instance.setPixmapFromFile(path);self[active].show()
            for name,path in dict(getattr(self,"_cin_widget_paths",{}) or {}).items():
                path=str(path or "")
                if not path or not os.path.isfile(path):continue
                try:
                    if self[name].instance is not None:
                        self[name].instance.setPixmap(None)
                        self[name].instance.setPixmapFromFile(path);self[name].show()
                except Exception as exc:optional_failure("cinematic.player_return_rebind_widget",exc)
            logo=str(getattr(self,"_cin_logo_path","") or "")
            if logo and os.path.isfile(logo) and self["title_logo"].instance is not None:
                try:self["title_logo"].instance.setPixmap(None)
                except Exception:pass
                self["title_logo"].instance.setPixmapFromFile(logo);self["title_logo"].show()
        except Exception as exc:optional_failure("cinematic.player_return_rebind",exc)

    def _details_handoff_snapshot(self,item):
        """Return the selected canonical record already resident in RAM."""
        try:
            row=(getattr(self,"_cin_page_records",{}) or {}).get(int(self.index)) or {}
            return dict(row) if isinstance(row,dict) else {}
        except Exception:return {}

    def _details_handoff_bundle(self,item,index=None):
        """Minimal first-frame Details bundle from already prepared Cinematic state."""
        try:
            pos=int(self.index if index is None else index)
            row=(getattr(self,"_cin_page_records",{}) or {}).get(pos) or {}
            prepared=(getattr(self,"_prepared_art_for_render",[]) or [])
            art=prepared[pos] if pos<len(prepared) and isinstance(prepared[pos],dict) else {}
            out={}
            poster=str((row or {}).get("poster_local") or art.get("poster") or "")
            backdrop=str((row or {}).get("backdrop_local") or art.get("backdrop") or "")
            if poster and os.path.isfile(poster):out["poster"]=poster
            if backdrop and os.path.isfile(backdrop):out["backdrop"]=backdrop
            return out
        except Exception:return {}

    def _pause_grid_background_for_child(self):
        # Keep the accepted Fast-Navigation cancellations, then free only native
        # rendered surfaces. No poster/backdrop file is deleted or re-downloaded.
        try:us_func(PremiumGridBase._pause_grid_background_for_child)(self)
        except Exception as exc:optional_failure("cinematic.child_pause_base",exc)
        self._cin_cancel_focus(enqueue=False);self._cin_cancel_background()
        self._cin_release_surfaces_for_child()

    def _prepare_grid_page(self,target,cancel_event=None):
        """Catalogue-only page preparation for Cinematic.

        PremiumGridBase prepares poster-grid thumbnails/card chrome while it
        builds a page.  On this screen image_size is intentionally 1x1, which
        created gridposter_*_1x1 files and native gSurfaces even though no grid
        exists.  Keep only catalogue/state/text preparation here; all visual
        ownership belongs to the explicit Cinematic pipeline.
        """
        data=self._grid_page_data(target,cancel_event)
        valid=list(x for x in data if isinstance(x,dict)) if isinstance(data,list) else []
        from .manual_identity import apply_choice
        valid=list(apply_choice(self.profile,self.media_type,x) for x in valid)
        if self.media_type in ("vod","series"):
            # Preserve only the direct provider artwork URLs in private fields
            # before the structural Stalker artwork strip. Cinematic may hydrate
            # the *focused* title from these URLs, but the catalogue itself stays
            # clean and no page-wide image engine is re-enabled.
            originals=list(dict(x) for x in valid)
            poster_counts={};backdrop_counts={}
            for src in originals:
                try:
                    pv=str(_image_url(src) or "").strip();bv=str(_backdrop_url(src) or "").strip()
                    if pv:poster_counts[pv]=poster_counts.get(pv,0)+1
                    if bv:backdrop_counts[bv]=backdrop_counts.get(bv,0)+1
                except Exception:pass
            rebuilt=[]
            for src in originals:
                try:
                    pv=str(_image_url(src) or "").strip();bv=str(_backdrop_url(src) or "").strip()
                    clean=dict(src) if src.get("_xtream") else _strip_portal_artwork(src)
                    # Repeated page-wide artwork is almost always a provider
                    # placeholder. Do not promote it into a title identity.
                    if pv and poster_counts.get(pv,0)<3:clean["_cin_provider_poster_url"]=pv
                    if bv and backdrop_counts.get(bv,0)<4:clean["_cin_provider_backdrop_url"]=bv
                    rebuilt.append(clean)
                except Exception:
                    rebuilt.append(dict(src))
            valid=rebuilt
        try:states=load_content_states(self.profile,self.media_type,valid) if valid else []
        except Exception:states=list({} for _ in valid)
        try:qualities=load_content_qualities(self.profile,self.media_type,valid) if valid and self.media_type in ("vod","series") else list("" for _ in valid)
        except Exception:qualities=list("" for _ in valid)
        cfg=self._grid_settings or {};state_rows=[];titles=[];fitted=[];meta=[];art=[];after_open=[]
        for pos,item in enumerate(valid):
            state=states[pos] if pos<len(states) else {};quality=qualities[pos] if pos<len(qualities) else ""
            row=dict(state or {});row["quality"]=quality or "";state_rows.append(row)
            clean_titles=bool(cfg.get("clean_titles",True))
            raw=item.get("_raw_name") or item.get("name") or item.get("title") or item.get("id") or "Item"
            title=(_catalogue_title(raw) if clean_titles else str(raw or "").strip());titles.append(title);fitted.append((title,None))
            bits=[]
            try:
                explicit=self._explicit_item_quality(item);badges=explicit or str(row.get("quality") or "") or quality_badges(raw)
                if badges:bits.append(badges)
            except Exception:pass
            if item.get("year"):bits.append(str(item.get("year"))[:4])
            if row.get("favorite"):bits.append("★")
            if row.get("completed") and cfg.get("show_watched",True):bits.append("WATCHED")
            elif row.get("position") and row.get("duration"):
                try:bits.append("%d%%"%min(99,int(row["position"]*100.0/row["duration"])))
                except Exception:pass
            meta.append("  •  ".join(bits)[:28])

            # R99 maintenance: prepare every HDD-only Cinematic index while this
            # page is already running on the async page worker.  The GUI paint
            # path later consumes this RAM row directly and never opens nav alias,
            # BLUE lock, metadata snapshot or package JSON on the Enigma2 thread.
            idx={"_cin_index_ready":True}
            try:
                record=self._record(item) or {}
            except Exception:
                record={}
            idx["cin_record"]=record
            try:
                poster=str(record.get("poster_local") or "")
                backdrop=str(record.get("backdrop_local") or "")
                if poster and os.path.isfile(poster):
                    idx["poster"]=poster;idx["palette"]=poster
                if backdrop and os.path.isfile(backdrop):idx["backdrop"]=backdrop
            except Exception:pass
            chosen=""
            try:
                alias=self._cin_load_nav_alias(item) or {}
                alias_bd=str(alias.get("backdrop") or "")
                if alias_bd and os.path.isfile(alias_bd):chosen=alias_bd
            except Exception as exc:optional_failure("cinematic.prepare_nav_alias",exc)
            has_local_record=bool(record.get("tmdb_id") or record.get("backdrop_local") or record.get("poster_local"))
            if has_local_record and not chosen:
                try:
                    blue=self._cin_read_blue_lock(item) or {};blue_bd=str(blue.get("backdrop_fast") or "")
                    if blue_bd and os.path.isfile(blue_bd) and os.path.getsize(blue_bd)>4096:chosen=blue_bd
                except Exception as exc:optional_failure("cinematic.prepare_blue_lock",exc)
            if has_local_record:
                try:
                    pkg=self._cin_load_canonical_package_fast(item,record) or {}
                    if pkg:
                        idx["cin_package"]=pkg
                        pkg_bd=str(pkg.get("backdrop_fast") or pkg.get("backdrop") or "")
                        if pkg_bd and os.path.isfile(pkg_bd):
                            chosen=pkg_bd
                            after_open.append(('cin_alias',dict(item),dict(record),dict(pkg)))
                except Exception as exc:optional_failure("cinematic.prepare_package",exc)
            if chosen:idx["cin_backdrop"]=chosen
            art.append(idx)
        return {"items":valid,"states":state_rows,"titles":titles,"fitted":fitted,"meta":meta,"art":art,"_after_open":after_open}

    # Grid-only background engines must never wake inside Cinematic.  Focused
    # artwork/cache policy is owned exclusively by the _cin_* pipeline below.
    def _poll_visible_poster_cache(self, positions=None, refresh=False):return

    def _start_visible_poster_watch(self):return

    def _start_progressive_poster_prefetch(self):return

    def _prefetch_selected_details(self):return

    def _prefetch_selected_series_hierarchy(self):return

    def _warm_idle_grid_page(self):return
