# -*- coding: utf-8 -*-
"""Adding portals/M3U sources, MAC entry and deletion.

Methods moved verbatim out of ``PortalListScreen`` (ui_screens_portallist.py); behaviour is unchanged.
This module is imported by ui_screens_portallist.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, min, us_casefold, us_text_callback, native_text
from .ui_screens_portallist import (
    InputBox,
    MessageBox,
    _,
    diagnostic_failure,
)


class PortalListSourcesMixin(object):
    """Adding portals/M3U sources, MAC entry and deletion."""

    @staticmethod
    def _portal_hub_group(profile):
        kind = portal_category_kind(profile)
        return "xtream" if kind == "m3u" else kind

    def _active_category(self):
        return self._categories[self._active_cat_idx]

    def _active_category_title(self):
        if self._active_category() == "xtream":
            return _("Xtream") + " / M3U"
        return _("Stalker")

    def _sync_profiles_from_disk(self, preferred_cat=None, focus_profile=None):
        self._all_profiles = list(load_profiles())
        if preferred_cat == "m3u":
            preferred_cat = "xtream"
        if preferred_cat in self._categories:
            self._active_cat_idx = self._categories.index(preferred_cat)
        active_cat = self._active_category()
        self.profiles = [prof for prof in self._all_profiles if self._portal_hub_group(prof) == active_cat]
        if focus_profile and isinstance(focus_profile, dict):
            want_portal = str(focus_profile.get("portal") or "").rstrip("/").lower()
            want_mac = str(focus_profile.get("mac") or "").strip().upper()
            for idx, row in enumerate(self.profiles):
                if str(row.get("portal") or "").rstrip("/").lower() == want_portal and (not want_mac or str(row.get("mac") or "").strip().upper() == want_mac):
                    return idx
        return 0

    def _save_active_category_profiles(self, subset=None):
        if subset is None:
            subset = list(self.profiles or [])
        else:
            subset = list(subset)
        active_cat = self._active_category()
        all_p = list(getattr(self, "_all_profiles", None) or load_profiles())
        merged = []
        inserted_active = False
        for prof in all_p:
            if self._portal_hub_group(prof) == active_cat:
                if not inserted_active:
                    merged.extend(subset)
                    inserted_active = True
            else:
                merged.append(prof)
        if not inserted_active and subset:
            merged.extend(subset)
        save_profiles(merged)
        self._all_profiles = list(load_profiles())
        self.profiles = [prof for prof in self._all_profiles if self._portal_hub_group(prof) == active_cat]

    def _switch_to_category(self, category_kind, focus_profile=None, enter_grid=False):
        target_idx = self._sync_profiles_from_disk(preferred_cat=category_kind, focus_profile=focus_profile)
        self._tab_focus = (not bool(enter_grid)) if self.profiles else True
        self._portal_visual_index = target_idx
        self._render_portal_rows(target_idx)
        if self.profiles:
            try:
                self["list"].moveToIndex(target_idx)
            except Exception:
                pass
        self._selection_changed()

    def _switch_category_step(self, step):
        self._active_cat_idx = (self._active_cat_idx + step) % len(self._categories)
        self._tab_focus = True
        self._sync_profiles_from_disk()
        self._portal_visual_index = 0
        self._render_portal_rows(0)
        if self.profiles:
            try:
                self["list"].moveToIndex(0)
            except Exception:
                pass
        self._selection_changed()

    def _enter_category_grid(self):
        if not self.profiles:
            self._pt_flash_result(_("No %s sources yet • Press MENU to add") % self._active_category_title(), seconds=4)
            return
        self._tab_focus = False
        idx = self._index()
        if idx is None:
            idx = 0
        self._render_portal_rows(idx)
        try:
            self["list"].moveToIndex(idx)
        except Exception:
            pass
        self._selection_changed()

    def refresh(self):
        current = self._index()
        if current is None:
            current = getattr(self, "_portal_visual_index", 0)
        self._render_portal_rows(current)
        self._selection_changed()

    def _index(self):
        if not self.profiles:
            return None
        i = self["list"].getSelectedIndex()
        return i if 0 <= i < len(self.profiles) else None

    def reload_text_file(self):
        self._sync_profiles_from_disk(); self.refresh(); self["status"].setText(_("Profiles reloaded"))

    def add_portal(self):
        if not self._busy:
            self.session.openWithCallback(us_text_callback(self._got_portal), InputBox, title=native_text(_("Portal / M3U URL")), text=native_text("https://"))

    def _got_portal(self, portal):
        if portal:
            self._new_portal = str(portal).strip()
            if requires_http_consent(self._new_portal):
                self.session.openWithCallback(self._got_portal_http_confirmed,MessageBox,http_warning_for(self._new_portal),MessageBox.TYPE_YESNO)
                return
            self._route_new_source()

    def _got_portal_http_confirmed(self,answer):
        if answer:
            self._route_new_source()
        else:
            self["status"].setText(_("HTTP source was not added"))

    def _route_new_source(self):
        raw=str(getattr(self,"_new_portal","") or "").strip()
        if not raw:return
        if _looks_like_m3u_url(raw):
            self._new_source_type="m3u"
            self._save_m3u_profile()
            return
        self._new_source_type="detecting"
        self["status"].setText(_("Checking source type…"))
        def work(handle):
            return _probe_m3u_url(raw,timeout=min(int(load_settings().get("timeout",10) or 10),8),
                                  cancel_event=getattr(handle,"cancel_event",None))
        def ok(is_m3u):
            if is_m3u:
                self._new_source_type="m3u";self._save_m3u_profile()
            else:
                self._new_source_type="stalker"
                self["status"].setText(_("Stalker portal detected"))
                self.session.openWithCallback(us_text_callback(self._got_mac),InputBox,title=native_text(_("MAC address")),text=native_text("00:1A:79:"))
        def failed(exc):
            # A Stalker endpoint commonly rejects a playlist-style probe.  Do
            # not treat that as an add failure; continue with the normal MAC flow.
            self._new_source_type="stalker"
            self["status"].setText(_("Enter MAC for Stalker portal"))
            self.session.openWithCallback(us_text_callback(self._got_mac),InputBox,title=native_text(_("MAC address")),text=native_text("00:1A:79:"))
        if not self._run_async(work,ok,failed):
            failed(RuntimeError(_("Source probe unavailable")))

    def _save_m3u_profile(self):
        try:
            raw_portal=str(getattr(self,"_new_portal","") or "").strip()
            new_profile={"portal":raw_portal,"mac":"","source_type":"m3u","state":"M3U • READY",
                         "account_state":"M3U PLAYLIST","health":"unknown","source":"saved",
                         "allow_http_fallback":False,"http_fallback_accepted":False,
                         "tls_fallback_accepted":False,"tls_mode":"strict","device_profile":"auto"}
            new_profile=mark_http_consent(new_profile,True)
            _validate_profile_client(new_profile)

            rows=load_profiles()
            wanted=us_casefold(raw_portal.rstrip("/"))
            replaced=False
            for idx,row in enumerate(rows):
                if (us_casefold(str(row.get("portal") or "").rstrip("/"))==wanted and
                    str(row.get("source_type") or "").lower()=="m3u"):
                    rows[idx]=new_profile;replaced=True;break
            if not replaced:rows.append(new_profile)

            enable_profile(new_profile)
            save_profiles(rows)

            loaded=load_profiles()
            found=None
            for row in loaded:
                if str(row.get("source_type") or "").lower()!="m3u":continue
                saved_url=us_casefold(str(row.get("portal") or "").rstrip("/"))
                if saved_url==wanted or saved_url.endswith(wanted):
                    found=row;break
            if found is None:
                raise RuntimeError(_("Playlist was written but did not survive profile reload"))

            cat_kind = portal_category_kind(found)
            idx = self._sync_profiles_from_disk(preferred_cat=cat_kind, focus_profile=found)
            self._tab_focus = False
            self.refresh()
            try:
                self["list"].moveToIndex(idx)
                self._portal_visual_index=idx
                self._selection_changed()
            except Exception as exc: diagnostic_failure("ui.portallist.failsoft", exc)
            self["status"].setText(_("Xtream server added") if cat_kind == "xtream" else _("M3U playlist added"))
        except Exception as exc:
            self._sync_profiles_from_disk()
            self.refresh()
            self.session.open(MessageBox,_("M3U add failed: %s")%exc,MessageBox.TYPE_ERROR,timeout=8)

    def _got_mac(self, mac):
        if not mac:
            return
        try:
            raw_portal = self._new_portal.strip()
            allow_fallback = not raw_portal.lower().startswith(("http://", "https://"))
            _validate_profile_client({"portal": raw_portal, "mac": mac.strip().upper(), "allow_http_fallback": False, "http_fallback_accepted": False})
            new_profile = {"portal": raw_portal, "mac": mac.strip().upper(), "source_type":"stalker", "state": "Not checked",
                           "allow_http_fallback": False, "http_fallback_accepted": False,
                           "tls_fallback_accepted": False, "tls_mode": "auto", "device_profile": "auto"}
            new_profile = mark_http_consent(new_profile, True)
            enable_profile(new_profile)
            all_rows = list(load_profiles())
            before = sum(1 for _r in all_rows if portal_category_kind(_r) == "stalker") + 1
            all_rows.append(new_profile)
            try:
                save_profiles(all_rows)
            except Exception as exc:
                self.session.open(MessageBox, _("Save failed: %s") % exc, MessageBox.TYPE_ERROR, timeout=7)
                return
            idx = self._sync_profiles_from_disk(preferred_cat="stalker", focus_profile=new_profile)
            self._tab_focus = False
            self.refresh()
            try:
                self["list"].moveToIndex(idx)
                self._portal_visual_index = idx
                self._selection_changed()
            except Exception:
                pass
            if len(self.profiles) < before:
                self["status"].setText(_("This portal and MAC already exist"))
        except Exception as exc:
            self.session.open(MessageBox, str(exc), MessageBox.TYPE_ERROR, timeout=6)

    def delete_portal(self):
        idx = self._index()
        if idx is None or self._busy:
            return
        self._delete_index = idx
        self.session.openWithCallback(
            self._delete_confirmed,
            MessageBox,
            _("Permanently delete selected portal?\n\nIt will be removed from saved profiles, all portal import files, cached sessions and plugin-owned data."),
            MessageBox.TYPE_YESNO
        )

    def _delete_confirmed(self, answer):
        if not answer:
            return
        idx = getattr(self, "_delete_index", None)
        if idx is not None and 0 <= idx < len(self.profiles):
            old = self.profiles[idx]
            try:
                result = permanently_delete_profile(old, session=self.session, purge_related=True)
                self._sync_profiles_from_disk()
                if not self.profiles:
                    self._tab_focus = True
                self["status"].setText(_("Portal permanently deleted") if result.get("deleted") else _("Portal delete failed"))
            except Exception as exc:
                self["status"].setText(_("Delete failed: %s") % exc)
            self.refresh()
