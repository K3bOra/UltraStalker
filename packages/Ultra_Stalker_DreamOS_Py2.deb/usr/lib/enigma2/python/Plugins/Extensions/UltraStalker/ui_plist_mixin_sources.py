# -*- coding: utf-8 -*-
"""Adding portals/M3U sources, MAC entry and deletion.

Methods moved verbatim out of ``PortalListScreen`` (ui_screens_portallist.py); behaviour is unchanged.
This module is imported by ui_screens_portallist.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, min, us_casefold, us_text_callback, native_text
from .ui_screens_portallist import (
    InputBox,
    MessageBox,
    _,
    diagnostic_failure,
)


class PortalListSourcesMixin(object):
    """Adding portals/M3U sources, MAC entry and deletion."""

    def refresh(self):
        current = self._index()
        if current is None:
            current = getattr(self, "_portal_visual_index", 0)
        self._render_portal_rows(current)
        self._selection_changed()

    def _index(self):
        if not self.profiles:
            return None
        i = self["list"].getSelectedIndex()
        return i if 0 <= i < len(self.profiles) else None

    def reload_text_file(self):
        self.profiles = load_profiles(); self.refresh(); self["status"].setText(_("Profiles reloaded"))

    def add_portal(self):
        if not self._busy:
            self.session.openWithCallback(us_text_callback(self._got_portal), InputBox, title=native_text(_("Portal / M3U URL")), text=native_text("https://"))

    def _got_portal(self, portal):
        if portal:
            self._new_portal = str(portal).strip()
            if requires_http_consent(self._new_portal):
                self.session.openWithCallback(self._got_portal_http_confirmed,MessageBox,http_warning_for(self._new_portal),MessageBox.TYPE_YESNO)
                return
            self._route_new_source()

    def _got_portal_http_confirmed(self,answer):
        if answer:
            self._route_new_source()
        else:
            self["status"].setText(_("HTTP source was not added"))

    def _route_new_source(self):
        raw=str(getattr(self,"_new_portal","") or "").strip()
        if not raw:return
        if _looks_like_m3u_url(raw):
            self._new_source_type="m3u"
            self._save_m3u_profile()
            return
        self._new_source_type="detecting"
        self["status"].setText(_("Checking source type…"))
        def work(handle):
            return _probe_m3u_url(raw,timeout=min(int(load_settings().get("timeout",10) or 10),8),
                                  cancel_event=getattr(handle,"cancel_event",None))
        def ok(is_m3u):
            if is_m3u:
                self._new_source_type="m3u";self._save_m3u_profile()
            else:
                self._new_source_type="stalker"
                self["status"].setText(_("Stalker portal detected"))
                self.session.openWithCallback(us_text_callback(self._got_mac),InputBox,title=native_text(_("MAC address")),text=native_text("00:1A:79:"))
        def failed(exc):
            # A Stalker endpoint commonly rejects a playlist-style probe.  Do
            # not treat that as an add failure; continue with the normal MAC flow.
            self._new_source_type="stalker"
            self["status"].setText(_("Enter MAC for Stalker portal"))
            self.session.openWithCallback(us_text_callback(self._got_mac),InputBox,title=native_text(_("MAC address")),text=native_text("00:1A:79:"))
        if not self._run_async(work,ok,failed):
            failed(RuntimeError(_("Source probe unavailable")))

    def _save_m3u_profile(self):
        try:
            raw_portal=str(getattr(self,"_new_portal","") or "").strip()
            new_profile={"portal":raw_portal,"mac":"","source_type":"m3u","state":"M3U • READY",
                         "account_state":"M3U PLAYLIST","health":"unknown","source":"saved",
                         "allow_http_fallback":False,"http_fallback_accepted":False,
                         "tls_fallback_accepted":False,"tls_mode":"strict","device_profile":"auto"}
            new_profile=mark_http_consent(new_profile,True)
            _validate_profile_client(new_profile)

            rows=load_profiles()
            wanted=us_casefold(raw_portal.rstrip("/"))
            replaced=False
            for idx,row in enumerate(rows):
                if (us_casefold(str(row.get("portal") or "").rstrip("/"))==wanted and
                    str(row.get("source_type") or "").lower()=="m3u"):
                    rows[idx]=new_profile;replaced=True;break
            if not replaced:rows.append(new_profile)

            enable_profile(new_profile)
            save_profiles(rows)

            loaded=load_profiles()
            found=None
            for row in loaded:
                if str(row.get("source_type") or "").lower()!="m3u":continue
                saved_url=us_casefold(str(row.get("portal") or "").rstrip("/"))
                if saved_url==wanted or saved_url.endswith(wanted):
                    found=row;break
            if found is None:
                raise RuntimeError(_("Playlist was written but did not survive profile reload"))

            self.profiles=loaded;self.refresh()
            try:
                idx=self.profiles.index(found)
                self["list"].moveToIndex(idx)
                self._portal_visual_index=idx
                self._selection_changed()
            except Exception as exc: diagnostic_failure("ui.portallist.failsoft", exc)
            self["status"].setText(_("M3U playlist added"))
        except Exception as exc:
            self.profiles=load_profiles()
            self.refresh()
            self.session.open(MessageBox,_("M3U add failed: %s")%exc,MessageBox.TYPE_ERROR,timeout=8)

    def _got_mac(self, mac):
        if not mac:
            return
        try:
            raw_portal = self._new_portal.strip()
            allow_fallback = not raw_portal.lower().startswith(("http://", "https://"))
            _validate_profile_client({"portal": raw_portal, "mac": mac.strip().upper(), "allow_http_fallback": False, "http_fallback_accepted": False})
            new_profile = {"portal": raw_portal, "mac": mac.strip().upper(), "source_type":"stalker", "state": "Not checked",
                           "allow_http_fallback": False, "http_fallback_accepted": False,
                           "tls_fallback_accepted": False, "tls_mode": "auto", "device_profile": "auto"}
            new_profile = mark_http_consent(new_profile, True)
            enable_profile(new_profile)
            self.profiles.append(new_profile)
            try:
                save_profiles(self.profiles)
            except Exception as exc:
                self.profiles.pop()
                self.session.open(MessageBox, _("Save failed: %s") % exc, MessageBox.TYPE_ERROR, timeout=7)
                return
            # Show what was really stored: the list is normalised on save (scheme
            # added, MAC canonicalised, same portal+MAC merged), so keeping the raw
            # row would show a duplicate or an unnormalised address until the next
            # reload.
            before = len(self.profiles)
            self.profiles = load_profiles()
            self.refresh()
            if len(self.profiles) < before:
                self["status"].setText(_("This portal and MAC already exist"))
        except Exception as exc:
            self.session.open(MessageBox, str(exc), MessageBox.TYPE_ERROR, timeout=6)

    def delete_portal(self):
        idx = self._index()
        if idx is None or self._busy:
            return
        self._delete_index = idx
        self.session.openWithCallback(
            self._delete_confirmed,
            MessageBox,
            _("Permanently delete selected portal?\n\nIt will be removed from saved profiles, all portal import files, cached sessions and plugin-owned data."),
            MessageBox.TYPE_YESNO
        )

    def _delete_confirmed(self, answer):
        if not answer:
            return
        idx = getattr(self, "_delete_index", None)
        if idx is not None and 0 <= idx < len(self.profiles):
            old = self.profiles[idx]
            try:
                result = permanently_delete_profile(old, session=self.session, purge_related=True)
                self.profiles = load_profiles()
                self["status"].setText(_("Portal permanently deleted") if result.get("deleted") else _("Portal delete failed"))
            except Exception as exc:
                self["status"].setText(_("Delete failed: %s") % exc)
            self.refresh()
