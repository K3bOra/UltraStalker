# -*- coding: utf-8 -*-
"""Focus scheduling, blue lock and folder artwork hooks.

Methods moved verbatim out of ``PremiumGlobalCinematicScreen`` (ui_cinematic_global.py); behaviour is unchanged.
This module is imported by ui_cinematic_global.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, open, max, us_func
from .ui_cinematic_global import (
    AsyncScreenMixin,
    BLUE_CACHE,
    PremiumGridBase,
    _CIN_HYBRID_EXECUTOR,
    _prepare_shared_cinematic_backdrop,
    ensure_persistent_dirs,
    json,
    load_settings,
    optional_failure,
    os,
    threading,
    time,
    ultra_title_logo_cached,
)


class CineBlueMixin(object):
    """Focus scheduling, blue lock and folder artwork hooks."""

    def _cin_schedule_focus(self,item):
        if self._folder_artwork_cache_running:return
        sig=self._page_visual_key(item)
        if not sig:return
        if self._cin_focus_sig==sig and self._cin_focus_future is not None and not self._cin_focus_future.done():return
        self._cin_cancel_background();self._cin_cancel_focus(enqueue=False)
        ev=threading.Event();self._cin_focus_cancel=ev;self._cin_focus_sig=sig
        def worker():
            try:
                row,package=self._cin_resolve_and_package(dict(item),ev)
                if not ev.is_set():self._cin_jobs.put({"kind":"focus","sig":sig,"row":row,"package":package})
            except Exception as exc:optional_failure("cinematic.hybrid_focus",exc)
        self._cin_focus_future=getattr(self,"_cin_hybrid_executor",_CIN_HYBRID_EXECUTOR).submit(worker);self._cin_kick_poll()

    def _cache_title_logo_for_blue(self,item,row,cancel_event=None):
        if cancel_event is not None and cancel_event.is_set():return ""
        try:
            # Use Poster Grid V2's exact receiver-proven identity gate and logo
            # resolver.  Only the Cinematic presentation canvas stays different.
            from .ui import _load_screen_group
            _load_screen_group('grids')
            from .ui_grid_screens import _pgv2_authoritative_logo_row_detached,_pgv2_resolve_title_logo_detached
            settings=(getattr(self,"_grid_settings",None) or load_settings() or {})
            fresh=_pgv2_authoritative_logo_row_detached(
                self.profile,self.media_type,dict(item or {}),dict(row or {}),
                cancel_event=cancel_event,settings=settings
            )
            if cancel_event is not None and cancel_event.is_set():return ""
            path,_resolved=_pgv2_resolve_title_logo_detached(
                self.profile,self.media_type,dict(item or {}),fresh,
                cancel_event=cancel_event,settings=settings,canvas_size=(420,144)
            )
            return path
        except Exception as exc:
            optional_failure("cinematic.blue_title_logo",exc);return ""

    def _cin_blue_lock_path(self,item,row=None):
        """Persistent completed-vault marker for explicit BLUE Cache Artwork.

        When a verified TMDB ID is known, the seal is keyed by TMDB ID so any
        portal copy of the same movie/series reuses the completed seal.
        """
        try:
            r = row if isinstance(row, dict) else {}
            it = item if isinstance(item, dict) else {}
            tid = r.get("tmdb_id") or it.get("_locked_tmdb_id") or it.get("_ultra_search_verified_tmdb_id")
            if not tid and (it.get("identity_verified") or it.get("identity_pointer_verified")):
                tid = it.get("tmdb_id")
            if tid:
                mt = "tv" if str(r.get("media_type") or self.media_type or "").lower() in ("series","tv","episode") else "movie"
                return os.path.join(BLUE_CACHE,"cinematic_ready","cinematic_blue_ready_tmdb_%s_%s.json"%(mt,int(tid)))
            safe=self._cin_safe_key(self._page_visual_key(item))
            return os.path.join(BLUE_CACHE,"cinematic_ready","cinematic_blue_ready_%s.json"%safe) if safe else ""
        except Exception:return ""

    @staticmethod
    def _cin_blue_lock_files_valid(files):
        if not isinstance(files,(list,tuple)) or not files:return False
        for path in files:
            try:
                path=str(path or "")
                if not path or not os.path.isfile(path) or os.path.getsize(path)<=256:return False
            except Exception:return False
        return True

    def _cin_read_blue_lock(self,item,row=None):
        candidates=[]
        p1=self._cin_blue_lock_path(item,row=row)
        if p1:candidates.append(p1)
        p2=self._cin_blue_lock_path(item,row=None)
        if p2 and p2 not in candidates:candidates.append(p2)
        for path in candidates:
            if not path or not os.path.isfile(path):continue
            try:
                with open(path,"r",encoding="utf-8") as h:data=json.load(h)
                if not isinstance(data,dict) or int(data.get("schema") or 0) not in (1,2,3,4,5):continue
                if not self._cin_blue_lock_files_valid(data.get("files")):continue
                return data
            except Exception:continue
        return {}

    def _cin_write_blue_lock(self,item,row,poster=None,backdrop=None,package=None):
        """Persist BLUE completion only after the final Cinematic backdrop exists.

        V7.0.38 keeps Details Authority as the only metadata resolver, then lets
        BLUE build the already-resolved Cinematic presentation once, sequentially,
        while the user explicitly waits for Cache Artwork.  This moves the costly
        first-focus backdrop conversion into BLUE without reintroducing any
        independent Cinematic metadata search.  Older schema-1/2 locks stay
        readable, but a V7.0.38 BLUE pass upgrades them to schema 3.
        """
        try:
            p=str(poster or (row or {}).get("poster_local") or "")
            b=str(backdrop or (row or {}).get("backdrop_local") or "")
            package=dict(package or {}) if isinstance(package,dict) else {}
            final_bd=""
            if b and os.path.isfile(b):
                final_bd=_prepare_shared_cinematic_backdrop(b,self._record_key(row,item),row,build=True,accent_hint=str(package.get("accent") or row.get("adaptive_accent") or row.get("adaptive_primary") or "")) or ""
            adaptive=self._cin_load_final_adaptive(item,row)
            adaptive_files=[str(adaptive.get(k) or "") for k in ("panel_detail","overview_detail","cast_detail","quality","year","runtime","country","genre_detail")] if adaptive else []
            required=[p,b,final_bd]+adaptive_files
            if not adaptive or not self._cin_blue_lock_files_valid(required):return False
            path=self._cin_blue_lock_path(item,row=row)
            if not path or not ensure_persistent_dirs(os.path.dirname(path)):return False
            payload={
                "schema":5,
                "visual_key":self._page_visual_key(item),
                "files":required,
                "backdrop_fast":final_bd,
                "tmdb_id":str((row or {}).get("tmdb_id") or ""),
                "cinematic_key":str(package.get("key") or ""),
                "backdrop_source_sig":self._cin_file_sig(b),
                "clean_backdrop_selector_version":int((row or {}).get("clean_backdrop_selector_version") or 0),
                "sealed_at":int(time.time()),
            }
            temp=path+".tmp.%d.%d"%(os.getpid(),threading.get_ident())
            with open(temp,"w",encoding="utf-8") as h:
                json.dump(payload,h,ensure_ascii=False,separators=(",",":"))  # rebuildable readiness seal
            os.replace(temp,path);return True
        except Exception as exc:
            optional_failure("cinematic.blue_ready_lock_write",exc)
            try:
                if 'temp' in locals() and os.path.exists(temp):os.unlink(temp)
            except Exception:pass
            return False

    def _folder_artwork_ready_hook(self,item,data):
        """Incremental BLUE readiness: fill only physically missing components.

        R171 never restarts a completed title.  Existing poster/backdrop masters,
        canonical metadata, persistent final adaptive, shared fast backdrop,
        three-view chrome and title-logo cache are reused independently.  Only a
        component that is genuinely absent is built/resolved.
        """
        row=dict(data or {}) if isinstance(data,dict) else {}
        poster=str(row.get("poster_local") or "")
        backdrop=str(row.get("backdrop_local") or "")
        try:
            from .artwork_v2 import _valid_backdrop
            art_ready=bool(poster and os.path.isfile(poster) and os.path.getsize(poster)>512 and _valid_backdrop(backdrop))
        except Exception:
            art_ready=False
        if not art_ready:return False

        # Completed BLUE seal: disk-only verification, zero metadata/artwork work.
        try:
            lock=self._cin_read_blue_lock(item,row=row) or {}
            fast=str(lock.get("backdrop_fast") or "")
            adaptive=self._cin_load_final_adaptive(item,row)
            if adaptive and fast and os.path.isfile(fast) and os.path.getsize(fast)>4096:
                if int(row.get("clean_backdrop_selector_version") or 0)>=3:
                    current_sig=self._cin_file_sig(backdrop)
                    if current_sig and str(lock.get("backdrop_source_sig") or "")==current_sig:return True
                else:return True
        except Exception:pass

        try:
            from .details_authority import load_canonical, metadata_language_ready, resolve_canonical
            canonical=load_canonical(self.profile,self.media_type,item) or {}
            if not metadata_language_ready(canonical,(self._grid_settings or {})):
                canonical=resolve_canonical(
                    self.profile,self.media_type,item,cancel_event=None,
                    settings=(self._grid_settings or {}),provider_client=self.client,provider_downloader=_download_portal_artwork
                ) or canonical
            if not metadata_language_ready(canonical,(self._grid_settings or {})):return False
            merged=dict(row);merged.update(canonical)
            # Never let metadata overwrite physically known canonical artwork.
            if poster and os.path.isfile(poster):merged["poster_local"]=poster
            if backdrop and os.path.isfile(backdrop):merged["backdrop_local"]=backdrop
            key=self._record_key(merged,item)

            # Shared decoder-ready backdrop: lookup first, build only on a true miss.
            final_bd=_prepare_shared_cinematic_backdrop(backdrop,key,merged,build=False)
            if not final_bd:
                final_bd=_prepare_shared_cinematic_backdrop(
                    backdrop,key,merged,build=True,
                    accent_hint=str(merged.get("adaptive_accent") or merged.get("adaptive_primary") or "")
                )
            if not (final_bd and os.path.isfile(final_bd) and os.path.getsize(final_bd)>256):return False

            # Final Details-family adaptive is now persistent across restarts.
            adaptive=self._cin_load_final_adaptive(item,merged)
            if not adaptive:
                adaptive=self._cin_ensure_final_adaptive(item,merged,cancel_event=None,build=True)
            if not adaptive:return False

            # Title Logo is also missing-only. Absence is allowed for titles that
            # genuinely have no usable logo, but a cached one is never re-resolved.
            try:
                visible=self._rail_title(item,merged) or str(merged.get("title") or merged.get("name") or "")
                logo=ultra_title_logo_cached(self.media_type,item,merged,(420,144),visible)
                if not logo:self._cache_title_logo_for_blue(item,merged,None)
            except Exception as exc:optional_failure("cinematic.r171_blue_logo_missing_only",exc)

            # Seal using already-hot components. _cin_write_blue_lock only validates
            # the same persistent files and cannot re-download poster/backdrop.
            self._cin_write_blue_lock(item,merged,poster,backdrop,package={"accent":str(merged.get("adaptive_accent") or merged.get("adaptive_primary") or "")})
            return True
        except Exception as exc:
            optional_failure("cinematic.r171_blue_incremental",exc)
        return False

    def _folder_artwork_finalize_hook(self,item,poster,backdrop,payload,data,cancel_event=None):
        """After artwork rescue, preload the same canonical Details record."""
        if cancel_event is not None and cancel_event.is_set():return False
        row=dict(data or {}) if isinstance(data,dict) else {}
        if poster and os.path.isfile(str(poster)):row["poster_local"]=str(poster)
        if backdrop and os.path.isfile(str(backdrop)):row["backdrop_local"]=str(backdrop)
        # Reuse the exact readiness path so both already-cached and newly rescued
        # titles obey one contract: BLUE completes only after Details metadata is
        # persistent. The Cinematic package is built only after Details metadata is canonical; no independent metadata lookup is allowed.
        return bool(self._folder_artwork_ready_hook(item,row))

    def _cin_leave_cache_exclusive(self):
        self._folder_artwork_fast_art_only=False
        self._cin_cache_exclusive=False
        if self._screen_closed:return
        # Cinematic poll is normally only a queue-delivery heartbeat. Restore it
        # after BLUE exits, then refresh exactly the currently focused title once.
        try:self._cin_set_poll_interval(120,force=True)
        except Exception:pass
        try:
            if self.grid_items:
                self._grid_focus_timer.stop();self._grid_focus_timer.start(120,True)
        except Exception:pass

    def _drain_jobs(self):
        if getattr(self,"_cin_cache_exclusive",False):
            # Cache-exclusive GUI pump: only the async completion queue and BLUE
            # progress queue are serviced. No poster/adaptive/EPG/cast/page drains.
            if time.monotonic() < float(getattr(self,"_nav_burst_until",0.0) or 0.0):
                return
            us_func(AsyncScreenMixin._drain_jobs)(self)
            if not self._screen_closed:
                try:self._drain_folder_artwork_progress()
                except Exception as exc:optional_failure("cinematic.blue_progress_only",exc)
            return
        return us_func(PremiumGridBase._drain_jobs)(self)

    def _cin_blue_preflight_ready(self,item):
        """Read-only full-title BLUE readiness check. Never repairs/builds."""
        try:
            row=self._record(item) or {}
            poster=str(row.get("poster_local") or "");backdrop=str(row.get("backdrop_local") or "")
            if not (poster and os.path.isfile(poster) and os.path.getsize(poster)>512):return False
            try:
                from .artwork_v2 import _valid_backdrop
                if not _valid_backdrop(backdrop):return False
            except Exception:return False
            adaptive=self._cin_load_final_adaptive(item,row)
            if not adaptive:return False
            key=self._record_key(row,item)
            shared=_prepare_shared_cinematic_backdrop(backdrop,key,row,build=False)
            if not (shared and os.path.isfile(shared) and os.path.getsize(shared)>4096):return False
            try:
                from .details_authority import load_canonical, metadata_language_ready
                canonical=load_canonical(self.profile,self.media_type,item) or {}
                if not metadata_language_ready(canonical,(self._grid_settings or {})):return False
            except Exception:return False
            return True
        except Exception as exc:
            optional_failure("cinematic.blue_preflight",exc);return False

    def _cache_folder_artwork_worker(self, rows, cancel_event=None):
        # R171 incremental preflight: the visible heavy counter contains ONLY
        # titles that still need some component. Fully-ready titles are verified
        # with lookup-only HDD checks and never enter the artwork/metadata/adaptive
        # worker again. A 68-title folder with 2 incomplete titles therefore runs
        # 0/2 -> 2/2, not 0/68 -> 68/68.
        self._folder_artwork_fast_art_only=True
        all_rows=[dict(x) for x in (rows or []) if isinstance(x,dict)]
        todo=[];hot=0
        for item in all_rows:
            if cancel_event is not None and cancel_event.is_set():break
            if self._cin_blue_preflight_ready(item):hot+=1
            else:todo.append(item)
        if not todo:
            return {"total":len(all_rows),"done":len(all_rows),"work_total":0,"downloaded":0,"hot":hot,"failed":0,
                    "poster_missing":0,"backdrop_missing":0,"poster_recovered":0,"backdrop_recovered":0,
                    "poster_failed":0,"backdrop_failed":0,"backdrop_upgrade_candidates":0,"backdrop_upgraded":0,
                    "recovered":0,"presentation_total":len(all_rows),"presentation_ready":len(all_rows),
                    "preflight_ready":hot}
        result=us_func(PremiumGridBase._cache_folder_artwork_worker)(self,todo,cancel_event) or {}
        # Keep final folder status truthful while the progress counter represented
        # only actual work. Base result counts apply to todo; total is the folder.
        result=dict(result);result["total"]=len(all_rows);result["work_total"]=len(todo);result["preflight_ready"]=hot
        result["hot"]=int(result.get("hot",0) or 0)+hot
        try:
            result["presentation_total"]=len(all_rows)
            result["presentation_ready"]=hot+max(0,len(todo)-int(result.get("failed",0) or 0))
        except Exception:pass
        return result

    def _apply_folder_artwork_result(self,result):
        try:return us_func(PremiumGridBase._apply_folder_artwork_result)(self,result)
        finally:self._cin_leave_cache_exclusive()

    def cache_folder_artwork(self):
        """Cache the current category posters and backdrops through the shared worker."""
        return us_func(PremiumGridBase.cache_folder_artwork)(self)
