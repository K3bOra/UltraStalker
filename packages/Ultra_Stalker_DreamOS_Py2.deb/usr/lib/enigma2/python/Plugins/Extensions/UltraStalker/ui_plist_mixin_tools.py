# -*- coding: utf-8 -*-
"""Shown/diagnostics/tools menu, integration export and device selection.

Methods moved verbatim out of ``PortalListScreen`` (ui_screens_portallist.py); behaviour is unchanged.
This module is imported by ui_screens_portallist.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, max, min, us_text_callback, native_text
from .ui_screens_portallist import (
    InputBox,
    LOG,
    MessageBox,
    PortalManagerPremiumScreen,
    SettingsGlassChoiceScreen,
    _,
    time,
)


class PortalListToolsMixin(object):
    """Shown/diagnostics/tools menu, integration export and device selection."""

    def _portal_list_shown(self):
        _perf_t0 = time.monotonic()
        LOG.info("PERF25 portals shown_enter mono_ms=%d", int(_perf_t0 * 1000))
        # External edits to portals.txt must become visible the first time the
        # user returns to this screen. Reloading this tiny local config is cheap
        # and deliberately does not touch channel/VOD/artwork caches.
        try:
            current_key=None
            idx=self._index()
            if idx is not None and self.profiles:
                p=self.profiles[idx];current_key=(str(p.get("portal") or "").rstrip("/").lower(),str(p.get("mac") or "").upper())
            fresh=load_profiles()
            if fresh != self.profiles:
                self.profiles=fresh
                target=0
                if current_key:
                    for pos,p in enumerate(self.profiles):
                        if (str(p.get("portal") or "").rstrip("/").lower(),str(p.get("mac") or "").upper())==current_key:
                            target=pos;break
                self._render_portal_rows(target)
                if self.profiles:self["list"].moveToIndex(target)
            elif self.profiles:
                self["list"].moveToIndex(max(0,min(getattr(self,"_portal_visual_index",0),len(self.profiles)-1)))
        except Exception as exc:optional_failure("ui.portal_fresh_import",exc)
        try:self._selection_changed()
        except Exception as exc:optional_failure("ui",exc)
        LOG.info("PERF25 portals shown_done elapsed_ms=%d", int((time.monotonic() - _perf_t0) * 1000))

    def _restore_background_service(self):
        restore_plugin_service(self.session)

    def open_diagnostics(self):
        idx = self._index()
        profile = self.profiles[idx] if idx is not None else None
        self.session.open(DiagnosticsScreen, profile)

    def open_portal_tools(self):
        # Premium Test8-style Portal Manager.  The screen returns the exact same
        # action tuple as the legacy ChoiceBox, so all proven portal operations
        # below remain untouched.
        self.session.openWithCallback(self._portal_tool_selected, PortalManagerPremiumScreen, self)

    def _portal_tool_selected(self,choice):
        if not choice:return
        action=choice[1];idx=self._index();profile=self.profiles[idx] if idx is not None else None
        if action=="backup_restore":return self._portal_backup_restore()
        if action=="enable_disabled":return self._choose_disabled_portal()
        if not profile:return
        if action=="rename":
            self._editing_profile=profile;self.session.openWithCallback(us_text_callback(self._portal_renamed),InputBox,title=native_text(_("Portal name")),text=native_text(str(profile.get("name") or _("Portal Server"))),maxSize=80)
        elif action=="edit":
            self._editing_profile=profile;self.session.openWithCallback(us_text_callback(self._portal_edit_url),InputBox,title=native_text(_("Portal / M3U URL")),text=native_text(str(profile.get("portal") or "https://")),maxSize=250)
        elif action=="device_profile":
            self._editing_profile=profile
            self.session.openWithCallback(
                self._portal_device_selected,
                SettingsGlassChoiceScreen,
                _("MAG device profile"),
                [(_("Auto"),"auto"),("MAG250","mag250"),("MAG254","mag254"),("MAG256","mag256")],
                subtitle=_("Choose the device profile for this portal")
            )
        elif action=="export_bouquet":
            self._export_live_integration(profile)
        elif action=="unexport_bouquet":
            try:
                result=unexport_live_integration(profile,reload=True)
                self["status"].setText(_("Exported bouquet and EPG removed"))
            except Exception as exc:
                self["status"].setText(_("Remove export failed: %s")%exc)
        elif action=="duplicate":
            self._duplicating_profile=profile;self.session.openWithCallback(us_text_callback(self._portal_duplicate_mac),InputBox,title=native_text(_("MAC for duplicate")),text=native_text("00:1A:79:"),maxSize=17)
        elif action == "move_selected":
            self["status"].setText(_("Select portals first, then MENU → Move"))
        elif action=="disable":self._request_disable_portals()
        elif action=="purge_data":
            self._purge_profile=profile;self.session.openWithCallback(self._purge_profile_confirmed,MessageBox,_("Clear plugin-owned data for this portal?\n\nThis removes its exported bouquet/EPG, matching recording refresh jobs/timers, Favorites, History and Resume data, but keeps the portal itself."),MessageBox.TYPE_YESNO)
        elif action=="delete_permanent":
            self._permanent_profile=profile;self.session.openWithCallback(self._permanent_delete_confirmed,MessageBox,_("Permanently delete this portal and its plugin-owned data?\n\nThis removes its exported bouquet/EPG, recording refresh jobs, Favorites, History and Resume data. Any matching Stalker recording timers will also be removed."),MessageBox.TYPE_YESNO)
        elif action=="diagnostics":self.session.open(DiagnosticsScreen,profile)

    def _portal_backup_restore(self):
        self.session.openWithCallback(self._portal_tool_selected,PortalManagerPremiumScreen,self,initial_action="backup_restore")

    def _portal_device_selected(self,choice):
        if not choice:return
        old=getattr(self,"_editing_profile",None) or {};new=dict(old);new["device_profile"]=choice[1]
        try:replace_profile(old,new,session=self.session);self.profiles=load_profiles();self.refresh();self["status"].setText(_("MAG profile saved: %s")%choice[1])
        except Exception as exc:self["status"].setText(_("MAG profile save failed: %s")%exc)
