# -*- coding: utf-8 -*-
"""XMLTV Live guide, provider/native fallbacks and Xtream catch-up.

Live XMLTV indexes are shared across channels; native reads require an explicit service reference.
This module is imported by m3u_adapter.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str, int, max, min, InterruptedError, us_casefold, us_isprintable
from .m3u_adapter import (
    LOG,
    _safe_int,
    base64,
    time,
    urllib,
)


class M3UEpgMixin(object):
    """Xtream EPG and catch-up."""

    def _start_epg_prepare(self):
        from .xmltv_source import start_prepare
        start_prepare(self)

    def _remember_epg_channels(self,rows):
        from .receiver_epg import reference_from_row
        for row in rows or []:
            if not isinstance(row,dict):continue
            cid=str(row.get('id') or row.get('ch_id') or '')
            if cid:
                ref=reference_from_row(row)
                if ref:self._live_native_refs[cid]=ref
                else:self._live_native_refs.pop(cid,None)
                self._live_epg_map[cid]=(str(row.get('stream_id') or ''),
                    str(row.get('tvg_id') or row.get('epg_channel_id') or ''),str(row.get('name') or row.get('title') or ''))

    def _xmltv_epg_rows(self,channel_id,hours=10,cancel_event=None,cache_only=False):
        from .xmltv_source import guide_rows, source_urls, prepare_header, client_event
        cancel_event=client_event(self,cancel_event)
        if cancel_event.is_set():return []
        if not cache_only:
            try:prepare_header(self,cancel_event)
            except InterruptedError:return []
        if not source_urls(self):return []
        text=str(channel_id or '').strip();mapping=getattr(self,'_live_epg_map',{}) or {}
        mapped=mapping.get(text)
        if mapped is None and self._xtream:
            sid=text[8:] if text.startswith('xt-live-') else text
            # The already-loaded category row normally owns this mapping. Only
            # export/standalone callers need the fallback all-stream index.
            for value in mapping.values():
                if value[0]==sid:mapped=value;break
            if mapped is None and not cache_only:
                index=self._ensure_xtream_live_art_index(cancel_event)
                row=(index.get('sid') or {}).get(sid) or {}
                if row:
                    mapped=(sid,str(row.get('epg_channel_id') or row.get('tvg_id') or ''),str(row.get('name') or ''))
                    self._remember_epg_channels([dict(row,id=text)])
        if mapped:
            _sid,tvg,name=mapped
            ids=[tvg] if tvg else []
        else:
            ids=[] if text.startswith(('m3u-live-','xt-live-')) or text.isdigit() else [text]
            name=''
        if not ids and not name:return []
        return guide_rows(self,ids,name,hours,cancel_event,cache_only)

    def _receiver_epg_rows(self,channel_id,hours=10,cancel_event=None):
        from .receiver_epg import guide_rows
        refs=getattr(self,'_live_native_refs',{}) or {}
        text=str(channel_id or '').strip()
        ref=refs.get(text)
        if not ref and self._xtream:
            sid=text[8:] if text.startswith('xt-live-') else text
            for cid,value in (getattr(self,'_live_epg_map',{}) or {}).items():
                if value[0]==sid and refs.get(cid):ref=refs[cid];break
        return guide_rows(ref,hours,cancel_event) if ref else []

    @staticmethod
    def _xtream_epg_text(value):
        text=str(value or "").strip()
        if not text:return ""
        # Xtream panels commonly base64-encode EPG title/description. Keep
        # ordinary plain-text providers intact and only accept a clean UTF-8
        # decode when it looks meaningful.
        try:
            raw=base64.b64decode(text+"="*((4-len(text)%4)%4),validate=False)
            decoded=raw.decode("utf-8","strict").strip()
            if decoded and sum(us_isprintable(ch) or ch.isspace() for ch in decoded)>=max(1,int(len(decoded)*0.9)):
                return decoded
        except Exception:
            pass
        return text

    @staticmethod
    def _xtream_epg_timestamp(value,timezone=None):
        if value in (None,""):return 0
        try:
            n=int(float(value))
            if n>1000000000:
                if len(str(n))==14 and str(n).startswith(('19','20')):
                    from .xmltv_source import timestamp
                    return timestamp(str(n))
                while n>100000000000:n//=1000
                return n
        except Exception:
            pass
        text=str(value or "").strip()
        try:
            aware=_us_env.us_iso_timestamp(text)
            if aware is not None:return int(aware)
            if timezone:
                from zoneinfo import ZoneInfo
                from datetime import datetime
                parsed=datetime.fromisoformat(text.replace('Z','+00:00'))
                from zoneinfo import ZoneInfo
                return int(parsed.replace(tzinfo=ZoneInfo(str(timezone))).timestamp())
        except (ValueError,TypeError,KeyError,ImportError,OverflowError):pass
        for fmt in ("%Y-%m-%d %H:%M:%S","%Y-%m-%dT%H:%M:%S","%Y%m%d%H%M%S"):
            try:return int(time.mktime(time.strptime(text,fmt)))
            except Exception:pass
        return 0

    def _xtream_epg_stream_id(self,channel_id,cancel_event=None):
        text=str(channel_id or "").strip()
        if text.startswith("xt-live-"):
            tail=text[8:].strip()
            if tail:return tail
        if text.isdigit():return text
        mapped=(getattr(self,'_live_epg_map',{}) or {}).get(text)
        if mapped and str(mapped[0]).isdigit():return str(mapped[0])
        try:
            index=self._ensure_xtream_live_art_index(cancel_event)
            mapped=(getattr(self,"_live_epg_map",None) or {}).get(text)
            if mapped:
                # R5.512: parsed-M3U channel (m3u-live-...): resolve its Xtream
                # stream via the URL id, then tvg-id, then a unique clean name.
                msid,mtvg,mname=mapped
                sid_index=index.get("sid") or {}
                if msid and msid in sid_index:return msid
                key=us_casefold(str(mtvg or "").strip())
                rows=(index.get("epg") or {}).get(key,[]) if key else []
                if rows:return str((rows[0] or {}).get("stream_id") or "").strip() or msid
                nrows=(index.get("name") or {}).get(self._live_match_key(mname),[])
                if len(nrows)==1:return str((nrows[0] or {}).get("stream_id") or "").strip() or msid
                if msid:return msid
            epg=(index.get("epg") or {}).get(us_casefold(text),[]) if isinstance(index,dict) else []
            if len(epg)==1 and isinstance(epg[0],dict):
                sid=str(epg[0].get("stream_id") or "").strip()
                if sid:return sid
        except Exception as exc:
            LOG.debug("Xtream EPG stream-id lookup failed: %s",exc)
        return ""

    def _xtream_epg_siblings(self,sid,limit=2,cancel_event=None):
        """Other stream ids of the same channel (same epg id or same clean name)."""
        try:
            index=self._ensure_xtream_live_art_index(cancel_event)
            me=(index.get("sid") or {}).get(str(sid)) or {}
            if not me:return []
            found=[]
            epg=us_casefold(str(me.get("epg_channel_id") or me.get("tvg_id") or "").strip())
            groups=[]
            if epg:groups.append((index.get("epg") or {}).get(epg,[]))
            key=self._live_match_key(me.get("name") or me.get("title") or "")
            if key:groups.append((index.get("name") or {}).get(key,[]))
            for rows in groups:
                for row in rows:
                    alt=str((row or {}).get("stream_id") or "").strip()
                    if alt and alt!=str(sid) and alt not in found:found.append(alt)
            # Streams that carry an epg id are the only ones likely to answer.
            by_id=(index.get("sid") or {})
            found.sort(key=lambda a:0 if str((by_id.get(a) or {}).get("epg_channel_id") or "").strip() else 1)
            return found[:limit]
        except Exception as exc:
            LOG.debug("Xtream EPG sibling lookup failed: %s",exc)
            return []

    def _xtream_epg_rows(self,channel_id,hours=4,cancel_event=None,limit=None,prefer_table=False):
        from .provider_requests import ProviderBusyError,account_gate
        if not self._xtream:return []
        gate=account_gate(self);gate.raise_if_deferred()
        sid=self._xtream_epg_stream_id(channel_id,cancel_event)
        # Stream-index enrichment may have observed 429/469 itself.
        gate.raise_if_deferred()
        if not sid:return []
        try:count=int(limit or max(12,min(96,int(hours or 4)*8)))
        except Exception:count=32
        payload=None
        _epg_actions=(
            ("get_short_epg",{"stream_id":sid,"limit":count}),
            ("get_simple_data_table",{"stream_id":sid}),
        )
        if prefer_table:
            # Catch-up needs the full table (past programmes + has_archive flag);
            # get_short_epg only returns upcoming programmes.
            _epg_actions=tuple(reversed(_epg_actions))
        for action,extra in _epg_actions:
            if cancel_event is not None and cancel_event.is_set():return []
            try:
                data=self._xtream_request(action,extra=extra,timeout=min(8,self.full_timeout),cancel_event=cancel_event)
            except ProviderBusyError:raise
            except Exception as exc:
                LOG.debug("Xtream EPG action=%s stream=%s failed: %s",action,sid,exc);continue
            if isinstance(data,dict):
                rows=data.get("epg_listings") or data.get("listings") or data.get("epg") or data.get("data")
            else:rows=data
            if isinstance(rows,list):
                payload=rows
                if rows:break
        if not payload and not prefer_table:
            # R5.512: the provider has no guide for THIS stream (empty
            # epg_channel_id on one quality/variant) but often has it for the
            # same channel under another stream id. Try those siblings.
            siblings=self._xtream_epg_siblings(sid,cancel_event=cancel_event)
            gate.raise_if_deferred()
            for alt in siblings:
                if cancel_event is not None and cancel_event.is_set():return []
                try:
                    data=self._xtream_request("get_short_epg",extra={"stream_id":alt,"limit":count},timeout=min(8,self.full_timeout),cancel_event=cancel_event)
                except ProviderBusyError:raise
                except Exception as exc:
                    LOG.debug("Xtream EPG sibling stream=%s failed: %s",alt,exc);continue
                rows=(data.get("epg_listings") or data.get("listings") or data.get("epg") or data.get("data")) if isinstance(data,dict) else data
                if isinstance(rows,list) and rows:
                    payload=rows
                    LOG.info("Xtream EPG sibling used: stream=%s -> %s",sid,alt)
                    break
            else:
                LOG.info("Xtream EPG empty: stream=%s (no guide from provider)",sid)
        out=[]
        timezone=((getattr(self,'_xtream_account',{}) or {}).get('server_info') or {}).get('timezone')
        for row in payload or []:
            if not isinstance(row,dict):continue
            start=next((v for v in (self._xtream_epg_timestamp(row.get(k),timezone) for k in ('start_timestamp','start','time')) if v>0),0)
            stop=next((v for v in (self._xtream_epg_timestamp(row.get(k),timezone) for k in ('stop_timestamp','end_timestamp','end','stop','time_to')) if v>0),0)
            try:duration=int(float(row.get("duration") or 0))
            except Exception:duration=0
            if not stop and start and duration:stop=start+max(60,duration)
            if not duration and start and stop>start:duration=stop-start
            title=self._xtream_epg_text(row.get("title") or row.get("name") or row.get("programme") or row.get("program"))
            desc=self._xtream_epg_text(row.get("description") or row.get("descr") or row.get("plot"))
            item=dict(row)
            item.update({"name":title or "Programme","title":title or "Programme","descr":desc,"description":desc,
                         "start_timestamp":start,"stop_timestamp":stop,"time":start,"time_to":stop,"duration":duration})
            out.append(item)
        return out

    def epg(self,channel_id,hours=4,cancel_event=None,use_cache=True):
        from .xmltv_source import client_event
        cancel_event=client_event(self,cancel_event)
        if cancel_event.is_set():return []
        self._start_epg_prepare()
        cached=self._xmltv_epg_rows(channel_id,hours,cancel_event,cache_only=True) if use_cache else []
        if cached:return cached
        # Whole-guide XMLTV is primary. The shared lock joins an in-flight
        # preparation instead of sending API requests for every visible channel.
        rows=self._xmltv_epg_rows(channel_id,hours,cancel_event)
        if rows:return rows
        if cancel_event.is_set():return []
        from .provider_requests import ProviderBusyError
        try:rows=self._xtream_epg_rows(channel_id,hours,cancel_event=cancel_event)
        except ProviderBusyError:
            # A valid local guide remains usable without a provider connection.
            fallback=self._receiver_epg_rows(channel_id,hours,cancel_event)
            if fallback:return fallback
            raise
        if cancel_event.is_set():return []
        now=int(time.time())
        usable=any(r.get('start_timestamp') and (not r.get('stop_timestamp') or r['stop_timestamp']>now) for r in rows)
        if usable:return rows
        fallback=self._receiver_epg_rows(channel_id,hours,cancel_event)
        return fallback or rows

    def epg_many(self, channel_ids, hours=10, cancel_event=None, on_each=None):
        ids=[]
        seen=set()
        for raw in channel_ids or []:
            cid=str(raw or "").strip()
            if cid and cid not in seen:
                seen.add(cid)
                ids.append(cid)
        if not ids:
            return {}
        from .xmltv_source import client_event
        from .provider_requests import ProviderBusyError
        cancel_event=client_event(self,cancel_event)
        out={}
        def publish(cid,rows):
            out[cid]=rows
            if callable(on_each):
                try:on_each(cid,rows)
                except Exception:pass
        def cached_pass(pending):
            missing=[]
            for cid in pending:
                if cancel_event.is_set():return []
                try:rows=self._xmltv_epg_rows(cid,hours,cancel_event,cache_only=True)
                except Exception:rows=[]
                if rows:publish(cid,rows)
                else:missing.append(cid)
            return missing
        self._start_epg_prepare()
        pending=cached_pass(ids)
        if pending and not cancel_event.is_set():
            try:self._xmltv_epg_rows(pending[0],hours,cancel_event)
            except Exception:pass
            pending=cached_pass(pending)
        # The old per-batch executor had one worker, so it was serial anyway.
        # Iterate here on the calling worker and stop account requests after the
        # first busy result; None is a transient failure, [] is a real empty guide.
        busy=False
        for cid in pending:
            if cancel_event.is_set():break
            try:
                if busy:
                    rows=self._receiver_epg_rows(cid,hours,cancel_event) or None
                else:rows=self.epg(cid,hours,cancel_event=cancel_event)
            except ProviderBusyError:
                busy=True;rows=None
            except Exception:rows=None
            if cancel_event.is_set():break
            publish(cid,rows)
        return out

    def full_epg(self,channel_id,from_ts=None,to_ts=None,page=1,max_pages=120,cancel_event=None):
        from .xmltv_source import client_event
        cancel_event=client_event(self,cancel_event)
        if cancel_event.is_set():return []
        rows=self._xmltv_epg_rows(channel_id,24,cancel_event)
        if not rows and not cancel_event.is_set():
            from .provider_requests import ProviderBusyError
            try:rows=self._xtream_epg_rows(channel_id,24,cancel_event=cancel_event,limit=160)
            except ProviderBusyError:
                rows=self._receiver_epg_rows(channel_id,24,cancel_event)
                if not rows:raise
        if not rows and not cancel_event.is_set():rows=self._receiver_epg_rows(channel_id,24,cancel_event)
        if cancel_event.is_set():return []
        result=[]
        for row in rows:
            start=self._xtream_epg_timestamp(row.get("start_timestamp") or row.get("start"))
            stop=self._xtream_epg_timestamp(row.get("stop_timestamp") or row.get("end"))
            if from_ts is not None and stop and stop<int(from_ts):continue
            if to_ts is not None and start and start>int(to_ts):continue
            result.append(row)
        return result

    # ---- Xtream catch-up (timeshift) -------------------------------------
    @staticmethod
    def _xtream_truthy(value):
        return str(value if value is not None else "").strip().lower() in ("1","true","yes","y","on")

    def catchup_channels(self,genre="*",page=1,max_pages=None,cancel_event=None):
        """Live channels whose provider advertises an archive (tv_archive=1)."""
        if not self._xtream:return []
        rows=self.ordered_all("itv",genre,cancel_event=cancel_event)
        out=[]
        for row in rows:
            if not isinstance(row,dict):continue
            try:days=int(float(row.get("tv_archive_duration") or 0))
            except Exception:days=0
            if self._xtream_truthy(row.get("allow_archive")) or days>0:
                out.append(row)
        LOG.info("Xtream catch-up channels: total=%d archive=%d",len(rows),len(out))
        return out

    def catchup_programs(self,channel_id,hours=72,cancel_event=None):
        """Past programmes of a channel that the provider still has in archive."""
        if not self._xtream:return []
        rows=self._xtream_epg_rows(channel_id,24,cancel_event=cancel_event,limit=500,prefer_table=True)
        now=int(time.time())
        try:floor=now-max(1,int(hours or 72))*3600
        except Exception:floor=now-72*3600
        flagged=any(isinstance(r,dict) and "has_archive" in r for r in rows)
        out=[]
        for row in rows:
            if not isinstance(row,dict):continue
            start=_safe_int(row.get("start_timestamp"),0)
            if not start or start>=now or start<floor:continue
            if flagged and not self._xtream_truthy(row.get("has_archive")):continue
            out.append(row)
        out.sort(key=lambda r:-_safe_int(r.get("start_timestamp"),0))
        LOG.info("Xtream catch-up programmes: channel=%s rows=%d usable=%d",channel_id,len(rows),len(out))
        return out

    def create_catchup_link(self,channel,program,cancel_event=None):
        """Build the standard Xtream timeshift URL for one archived programme."""
        if not self._xtream:return ""
        channel=channel if isinstance(channel,dict) else {}
        program=program if isinstance(program,dict) else {}
        sid=str(channel.get("stream_id") or "").strip() or self._xtream_epg_stream_id(channel.get("id") or channel.get("ch_id"))
        if not sid:raise ValueError("Catch-up channel has no stream id")
        # Timeshift URLs expect the start time in the *provider's* timezone.
        # The panel's own "start" string is already in that timezone, so use it
        # verbatim and only fall back to the receiver clock when it is missing.
        stamp=""
        raw=str(program.get("start") or "").strip()
        try:stamp=time.strftime("%Y-%m-%d:%H-%M",time.strptime(raw[:19],"%Y-%m-%d %H:%M:%S"))
        except Exception:stamp=""
        start=_safe_int(program.get("start_timestamp"),0)
        if not stamp:
            if not start:raise ValueError("Programme has no start time")
            stamp=time.strftime("%Y-%m-%d:%H-%M",time.localtime(start))
        stop=_safe_int(program.get("stop_timestamp"),0)
        try:seconds=int(program.get("duration") or 0)
        except Exception:seconds=0
        if seconds<=0 and stop>start>0:seconds=stop-start
        minutes=max(1,int((seconds+59)//60)) if seconds>0 else 60
        base=self._xtream["base"]
        username=urllib.parse.quote(self._xtream["username"],safe="")
        password=urllib.parse.quote(self._xtream["password"],safe="")
        return "%s/timeshift/%s/%s/%d/%s/%s.ts"%(base,username,password,minutes,stamp,sid)
