# -*- coding: utf-8 -*-
"""Focus update, movement and opening items.

Methods moved verbatim out of ``PortalHomeScreen`` (ui_screens_home.py); behaviour is unchanged.
This module is imported by ui_screens_home.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, round, max, min
from .ui_screens_home import (
    LOG,
    LocalLibraryScreen,
    NovaSettingsScreen,
    PortalBrowserScreen,
    PortalGlobalSearchScreen,
    _,
    _mem34,
    ePoint,
    optional_failure,
    os,
    time,
)


class HomeNavMixin(object):
    """Focus update, movement and opening items."""

    def _update_focus(self):
        try:
            sx=float(getattr(self,"_home_sx",1.0) or 1.0);sy=float(getattr(self,"_home_sy",1.0) or 1.0)
            if self.focus_row=="recent":
                self._home_card_emphasis(-1)
                self["selection"].hide();self._set_recent_row_focus(self.recent_index);self._home_focus_drawn_row="recent"
                group=self._recent_group(self.recent_index);self._bind_recent_group_art(group,self.recent_index)
                try:
                    _packed=self._recent_entries[self.recent_index] if self.recent_index<len(self._recent_entries) else None
                    label=self._recent_row_text(self.recent_index,_packed)[0] or _("Recent")
                except Exception:label=_("Recent")
                self._queue_home_focus_state(home_index=self.index,home_recent_index=self.recent_index,home_focus_row=self.focus_row,home_recent_grid_v1=1)
                self["status"].setText(_("%s • LEFT / RIGHT section • UP / DOWN item • OK resume")%label)
            else:
                self._set_recent_row_focus(None);self["selection"].show();self._home_focus_drawn_row="menu"
                self._ensure_menu_window();slot=self._menu_slot();self["selection"].instance.move(ePoint(int((self.CARD_X[slot]-8)*sx),int(526*sy)))
                self._home_card_emphasis(slot)
                if getattr(self,"_sc_mode",False):
                    self._sc_status();return
                action=self.CARDS[self.index][2]
                self._queue_home_focus_state(home_key=action,home_index=self.index,home_recent_index=self.recent_index,home_focus_row=self.focus_row,home_recent_grid_v1=1)
                self["status"].setText(_("%s • DOWN recent • OK open • BACK portals")%_(self.CARDS[self.index][0]))
        except Exception as exc:optional_failure("ui",exc)

    def move_left(self):
        if getattr(self,"_sc_mode",False):return self._sc_horizontal(-1)
        if self.focus_row=="recent":
            group=self._recent_group(self.recent_index);row=self._recent_row(self.recent_index)
            target=max(0,group-1)*3+row
            if target==self.recent_index:return
            self.recent_index=target
        else:
            target=max(0,self.index-1)
            if target==self.index:return
            self.index=target
            if self._ensure_menu_window():self._render_menu_window(load_icons=True)
        self._update_focus()

    def move_right(self):
        if getattr(self,"_sc_mode",False):return self._sc_horizontal(1)
        if self.focus_row=="recent":
            group=self._recent_group(self.recent_index);row=self._recent_row(self.recent_index)
            target=min(2,group+1)*3+row
            if target==self.recent_index:return
            self.recent_index=target
        else:
            target=min(len(self.CARDS)-1,self.index+1)
            if target==self.index:return
            self.index=target
            if self._ensure_menu_window():self._render_menu_window(load_icons=True)
        self._update_focus()

    def move_down(self):
        if getattr(self,"_sc_mode",False):return self._sc_change(1)
        if self.focus_row=="menu":
            self.focus_row="recent";slot=self._menu_slot();group=min(2,max(0,int(round(slot*2.0/max(1,self.VISIBLE_CARD_COUNT-1)))));self.recent_index=group*3;self._update_focus();return
        row=self._recent_row(self.recent_index)
        if row<2:self.recent_index+=1;self._update_focus()

    def move_up(self):
        if getattr(self,"_sc_mode",False):return self._sc_change(-1)
        if self.focus_row!="recent":return
        row=self._recent_row(self.recent_index);group=self._recent_group(self.recent_index)
        if row>0:self.recent_index-=1;self._update_focus();return
        self.focus_row="menu";slot=min(self.VISIBLE_CARD_COUNT-1,int(round(group*(self.VISIBLE_CARD_COUNT-1)/2.0)));self.index=min(len(self.CARDS)-1,int(getattr(self,"_menu_window_start",0) or 0)+slot);self._update_focus()

    def _current_category_adaptive_source(self):
        """Return the exact Home hero artwork currently on screen.

        Categories must not guess a different palette by media type.  The first
        working Series implementation inherited the visible Home hero palette;
        pass that same concrete source to Series, Movies and Live so all three
        execute one identical adaptive pipeline.
        """
        hero = self._hero_data if isinstance(getattr(self, "_hero_data", None), dict) else None
        if not hero:
            try: hero = self._read_hero_cache()
            except Exception: hero = None
        if not isinstance(hero, dict):
            return None
        for key in ("display_backdrop_local", "backdrop_local", "prepared", "display_poster_local", "poster_local"):
            src = hero.get(key)
            try:
                if src and os.path.isfile(str(src)) and os.path.getsize(str(src)) > 4096:
                    return str(src)
            except Exception as exc:
                optional_failure("ui.silent_guard",exc)
        return None

    def open_selected(self):
        if getattr(self,"_sc_mode",False):return self._sc_ok()
        if self.focus_row=="recent":return self._open_recent(self.recent_index)
        action=self.CARDS[self.index][2]
        self._mem34_last_action=action
        self._perf59_cycle=int(getattr(self,"_perf59_cycle",0) or 0)+1
        if LOG is not None:LOG.info("PERF59 nav_open cycle=%d action=%s",self._perf59_cycle,str(action))
        _mem34("home_before_open", action=action, cycle=self._perf59_cycle)
        _perf29_t0=time.monotonic()
        if LOG is not None: LOG.info("PERF29 home card_open_begin action=%s mono_ms=%d",action,int(_perf29_t0*1000))
        if action=="search":self.session.open(PortalGlobalSearchScreen,self.profile,self.client)
        elif action=="settings":self.session.open(NovaSettingsScreen,self.profile,self.client)
        elif action=="local" and LocalLibraryScreen is not None:self.session.open(LocalLibraryScreen,self.profile)
        elif action=="itv" and self._live_columns_direct():pass
        else:self.session.open(PortalBrowserScreen,self.profile,action,self.client,self._current_category_adaptive_source())
        if LOG is not None: LOG.info("PERF29 home card_open_return action=%s elapsed_ms=%d",action,int((time.monotonic()-_perf29_t0)*1000))

    def _live_columns_direct(self):
        """R5.67: new Live look opens directly from Home (no Categories page)."""
        try:
            from .storage import load_settings as _ls
            if str((_ls() or {}).get("live_view_mode") or "columns").lower()!="columns":
                return False
            from .ui import _load_screen_group
            _load_screen_group("grids")
            from .ui_live_columns import open_live_direct
            src=self._current_category_adaptive_source()
            def fallback(scr=self,src=src):
                try:scr.session.open(PortalBrowserScreen,scr.profile,"itv",scr.client,src)
                except Exception as exc:
                    if LOG is not None:LOG.warning("live direct fallback failed: %s",exc)
            return bool(open_live_direct(self.session,self.profile,self.client,fallback))
        except Exception as exc:
            if LOG is not None:LOG.warning("live direct open failed: %s",exc)
            return False

    def open_search_shortcut(self):
        """Home yellow-key shortcut: open the exact same global Search screen as the Search card.

        Do not mutate Home selection/focus and do not route through Menu. This keeps the
        shortcut visually and behaviorally identical to opening the Search card itself.
        """
        try:
            if PortalGlobalSearchScreen is not None:
                self.session.open(PortalGlobalSearchScreen,self.profile,self.client)
        except Exception as exc:
            optional_failure("ui.home_search_shortcut",exc)
