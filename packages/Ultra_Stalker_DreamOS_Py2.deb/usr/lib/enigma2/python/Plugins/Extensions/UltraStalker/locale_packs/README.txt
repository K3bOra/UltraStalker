Ultra Stalker interface language packs

Each pack is independent Ultra Stalker UTF-8 JSON named <language-code>.json.

Format:
{
  "_meta": {"schema": 1, "code": "es", "complete": true},
  "translations": {"Settings": "Ajustes", "...": "..."}
}

A pack is selectable only when it is marked complete and passes the pack validator.
Bundled language packs track the current V9.1.3 interface strings.
Provider titles/content are never routed through interface translation packs.
Description Language is a separate setting and does not change Title Logo or artwork authority.
