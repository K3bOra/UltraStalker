# -*- coding: utf-8 -*-
"""Selection handling, saving credentials/PIN, backups and support bundle.

Methods moved verbatim out of ``NovaSettingsScreen`` (ui_screens_settings.py); behaviour is unchanged.
This module is imported by ui_screens_settings.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, us_casefold
from .ui_screens_settings import (
    Input,
    SettingsGlassInputScreen,
    SettingsWebCleanerReadyScreen,
    _authorize_parental_change,
    default_description_for_interface,
    description_language_choices,
    interface_language_choices,
    set_plugin_language,
)


class SettingsActionsMixin(object):
    """Selection handling, saving credentials/PIN, backups and support bundle."""

    def select(self):
        if getattr(self,"_pane","groups")=="groups":
            self._set_pane("options");return
        idx=int(getattr(self,"_opt_idx",0) or 0)
        if not (0 <= idx < len(self.opt_entries)): return
        action=self.opt_entries[idx][1]
        cfg=load_settings()
        if action == "service":
            from . import us_env as _us_env
            if _us_env.IS_DREAMOS:
                choices=[("DreamOS Stream Player (8193)",8193),("DreamOS GStreamer (4097)",4097),("DreamOS DVB / Live TS (1)",1)]
                if _us_env.os.path.exists("/usr/bin/gstplayer"):choices.append(("GstPlayer (5001)",5001))
                if _us_env.os.path.exists("/usr/bin/exteplayer3"):choices.append(("ExtePlayer3 (5002)",5002))
            else:
                choices=[("DVB / native (1)",1),("IPTV / GStreamer (4097)",4097),("GstPlayer (5001)",5001),("ExtePlayer3 (5002)",5002),("ServiceApp / DreamOS (8193)",8193)]
            current=int(cfg.get("service_type",4097) or 4097)
            selection=next((i for i,c in enumerate(choices) if c[1]==current),0)
            self._context_open_choice(lambda c:self._save_choice("service_type",c),_("Playback engine"),choices,selection,_("Choose the Enigma2 playback service"))
        elif action == "live_zap_direction":
            current = str(cfg.get("live_zap_direction") or "up_down")
            self._context_open_choice(lambda c:self._save_choice("live_zap_direction",c),_("Live Channel Keys"),[(_("Up / Down (default)"),"up_down"),(_("Left / Right"),"left_right")],1 if current=="left_right" else 0,_("Choose the arrows used to change channels during full-screen Live TV."))
        elif action == "live_view_mode":
            current=str(cfg.get("live_view_mode") or "columns").lower();selection={"classic":1,"wall":2}.get(current,0)
            self._context_open_choice(lambda c:self._save_choice("live_view_mode",c),_("Live TV View"),[(_("3 Columns"),"columns"),(_("Classic list"),"classic"),(_("Logo wall"),"wall")],selection,_("Live TV screen layout"))
        elif action == "player_view_mode":
            current=str(cfg.get("player_view_mode") or "old").lower();selection={"new":1,"new2":2}.get(current,0)
            self._context_open_choice(lambda c:self._save_choice("player_view_mode",c),_("Player View"),[("Player Old","old"),("Player New","new"),("Player New 2","new2")],selection)
        elif action in ("movies_view_mode","series_view_mode"):
            current=str(cfg.get(action) or "cinematic").lower();_view_values=["poster_legacy","poster","poster3","cinematic","backdrop","backdrop2"];selection=_view_values.index(current) if current in _view_values else 0
            title=_("Movies View") if action=="movies_view_mode" else _("Series View")
            self._context_open_choice(lambda c,k=action:self._save_choice(k,c),title,[(_("Poster Grid"),"poster_legacy"),(_("Poster Grid V2"),"poster"),(_("Poster Grid 3"),"poster3"),(_("Cinematic"),"cinematic"),(_("Backdrop Grid"),"backdrop"),(_("Backdrop Grid 2"),"backdrop2")],selection,_("Both views read the same single Global TMDB Library record"))
        elif action == "playback_retry_limit":
            current = int(cfg.get("playback_retry_limit",3))
            self._context_open_choice(lambda c:self._save_choice("playback_retry_limit",c),_("Recovery Attempts"),[(str(x),x) for x in (0,1,2,3)],current,_("Maximum automatic recovery attempts. Zero disables retries. The default is three."))
        elif action == "timeout":
            self._context_open_choice(lambda c:self._save_choice("timeout",c),_("Portal timeout"),[(_("%d seconds")%x,x) for x in (5,8,10,15,20,30)])
        elif action == "proxy_port":
            self.session.openWithCallback(self._save_proxy_port,SettingsGlassInputScreen,title=_("Bouquet proxy port (1024-65535)"),text=str(cfg.get("proxy_port",17999)),maxSize=5)
        elif action == "refresh_content":
            self._refresh_current_content()
        elif action == "resume_behavior":
            self._context_open_choice(lambda c:self._save_choice("resume_behavior",c),_("Resume behavior"),[(_("Ask every time"),"ask"),(_("Always resume"),"always"),(_("Always start from beginning"),"start")])
        elif action == "progress_save_seconds":
            self._context_open_choice(lambda c:self._save_choice("progress_save_seconds",c),_("Progress save interval"),list((_("%d seconds")%x,x) for x in (3,5,10,15,30)))
        elif action == "infobar_timeout":
            try:current=int(cfg.get("infobar_timeout",10))
            except Exception:current=10
            values=(3,6,10,15,30,0)
            self._context_open_choice(lambda c:self._save_choice("infobar_timeout",c),_("Info Bar Timeout"),list(((_("Always On") if x==0 else _("%d seconds")%x),x) for x in values),values.index(current) if current in values else 2)
        elif action == "next_episode_countdown":
            self._context_open_choice(lambda c:self._save_choice("next_episode_countdown",c),_("Next episode countdown"),list((_("%d seconds")%x,x) for x in (5,10,15,20,30)))
        elif action == "completion_threshold":
            self._context_open_choice(lambda c:self._save_choice("completion_threshold",c),_("Completion threshold"),list((_("%d%%")%x,x) for x in (85,90,93,95,97)))
        elif action == "completion_remaining_seconds":
            self._context_open_choice(lambda c:self._save_choice("completion_remaining_seconds",c),_("Completion remaining time"),list((_("%d seconds")%x,x) for x in (60,120,180,240,300)))
        elif action == "epg":
            self._context_open_choice(lambda c:self._save_choice("epg_hours",c),_("EPG window"),list((_("%d hours")%x,x) for x in (2,4,6,8,12,24)))
        elif action == "epg_refresh_budget":
            self._context_open_choice(lambda c:self._save_choice("epg_refresh_budget",c),_("EPG refresh budget"),list((_("%d seconds")%x,x) for x in (15,30,45,60,90,120,180)))
        elif action in ("smart_recovery","images","parental","clean_titles","quality_badges","adaptive_colors","multi_portal_search","diagnostic_logging","show_watched","tmdb_enabled","crash_safe_progress","remember_track_language","auto_remove_completed","show_main_menu","category_preview_posters","hide_adult"):
            key={"images":"load_images","preview":"live_preview","parental":"parental_lock","quality_badges":"show_quality_badges"}.get(action,action)
            current=bool(cfg.get(key,True))
            title=self.opt_entries[idx][0]
            self._context_open_choice(lambda c,a=action,k=key:self._save_toggle_choice(a,k,c),title,[(_("ON"),True),(_("OFF"),False)],0 if current else 1,_("Choose ON or OFF"))
        elif action == "clear_temp_cache":
            self._clear_temporary_cache()
        elif action == "reset_settings":
            self._context_open_choice(self._confirm_reset_settings,_("Reset Settings?"),[(_("CANCEL"),"cancel"),(_("RESET OPTIONS"),"reset")],0,_("Options return to defaults. Portals, API keys, PIN, favorites and history are kept."))
        elif action == "clear_persistent_artwork":
            self._context_open_choice(
                self._confirm_clear_persistent_artwork,
                _("Delete Persistent Artwork?"),
                [(_("CANCEL"),"cancel"),(_("DELETE ARTWORK"),"delete")],
                0,
                _("This removes saved HDD artwork only. Settings, portals, watch history and metadata indexes are kept.")
            )
        elif action == "global_artwork_preload":
            self._start_global_artwork_preload()
        elif action == "persistent_cache_mb":
            self._context_open_choice(lambda c:self._save_choice("persistent_cache_mb",c),_("Artwork cache size"),list((_("%d GB")%(x//1024),x) for x in (2048,5120,10240,20480,40960,65536)))
        elif action == "image_cache_mb":
            self._context_open_choice(lambda c:self._save_choice("image_cache_mb",c),_("Image cache limit"),list((_("%d MB")%x,x) for x in (40,80,128,180,256,512,1024)))
        elif action == "download_reserve_mb":
            self._context_open_choice(lambda c:self._save_choice("download_reserve_mb",c),_("Download disk safety reserve"),list((_("%d MB")%x,x) for x in (256,512,1024,2048,4096,8192)))
        elif action == "content_page_size":
            self._context_open_choice(lambda c:self._save_choice("content_page_size",c),_("Search results per portal"),list((str(x),x) for x in (20,30,50,80,120,200)))
        elif action == "search_max_pages":
            self._context_open_choice(lambda c:self._save_choice("search_max_pages",c),_("Maximum search scan pages"),list((str(x),x) for x in (25,50,100,150,250)))
        elif action == "search_time_budget":
            self._context_open_choice(lambda c:self._save_choice("search_time_budget",c),_("Search time budget per portal"),list((_("%d seconds")%x,x) for x in (5,8,12,15,20,30)))
        elif action == "playback_buffer_mb":
            self._context_open_choice(lambda c:self._save_choice("playback_buffer_mb",c),_("Playback buffer"),[(_("Off"),0)]+list((_("%d MB")%x,x) for x in (8,16,32,64,128,256,512)))
        elif action == "parental_mode":
            self._context_open_choice(lambda c:self._save_choice("parental_mode",c),_("Parental mode"),[(_("PIN protect"),"pin"),(_("Hide sensitive categories"),"hide")])
        elif action == "parental_session":
            self._context_open_choice(lambda c:self._save_choice("parental_session_minutes",c),_("Parental unlock duration"),[(_("One action"),0),(_("15 minutes"),15),(_("30 minutes"),30),(_("60 minutes"),60),(_("120 minutes"),120)])
        elif action == "adult_keywords":
            self.session.openWithCallback(self._save_adult_keywords,SettingsGlassInputScreen,title=_("Adult keywords (comma separated)"),text=", ".join(cfg.get("adult_keywords",[])),maxSize=240)
        elif action == "parental_lock_now":
            parental_lock_now();self.refresh();self["status"].setText(_("Parental session locked"))
        elif action == "pin":
            self.session.openWithCallback(self._save_pin, SettingsGlassInputScreen, title=_("New parental PIN (4-8 digits)"), text="", maxSize=8, type=Input.PIN)
        elif action == "api_keys_file":
            self._context_open_notice(_("API Keys"),_("Put long credentials in:\n/etc/enigma2/ultrastalker/api_keys.conf\n\nTMDB_API_KEY=...\nTMDB_READ_TOKEN=...\nIMDB_API_KEY=...\nIMDB_API_ENDPOINT=... (generic mode)\nSUBDL_API_KEY=...\nSUBSOURCE_API_KEY=...\nFANART_API_KEY=...\n\nOfficial IMDb/AWS Data Exchange:\nIMDB_ACCESS_KEY_ID=...\nIMDB_SECRET_ACCESS_KEY=...\nIMDB_SESSION_TOKEN=... (optional)\nIMDB_REGION=us-east-1\nIMDB_DATASET_ID=...\nIMDB_REVISION_ID=...\nIMDB_ASSET_ID=..."))
        elif action == "tmdb_credential":
            self.session.openWithCallback(self._save_tmdb_credential, SettingsGlassInputScreen, title=_("TMDB API key or Read Access Token"), text=("" if cfg.get("tmdb_credential_source")=="builtin" else str(cfg.get("tmdb_credential") or "")), maxSize=512)
        elif action == "plugin_language":
            current=str(cfg.get("plugin_language") or "en")
            choices=interface_language_choices()
            selection=next((i for i,x in enumerate(choices) if x[1]==current),0)
            self._context_open_choice(self._plugin_language_selected,_("Interface Language"),choices,selection,_("Choose the language used by Ultra Stalker menus and controls. Portal, M3U and Xtream content is never translated."))
        elif action == "font_scale":
            current=str(cfg.get("font_scale") or "normal")
            choices=[(_("Normal"),"normal"),(_("Large"),"large"),(_("Larger"),"larger"),(_("Extra Large"),"xlarge")]
            selection=next((i for i,x in enumerate(choices) if x[1]==current),0)
            self._context_open_choice(self._font_scale_selected,_("Font Size"),choices,selection,_("Choose the text size used across Ultra Stalker. Restart Enigma2 to apply it everywhere."))
        elif action == "overview_font_scale":
            current=str(cfg.get("overview_font_scale") or "normal")
            choices=[(_("Normal"),"normal"),(_("Large"),"large"),(_("Larger"),"larger"),(_("Extra Large"),"xlarge")]
            selection=next((i for i,x in enumerate(choices) if x[1]==current),0)
            self._context_open_choice(lambda c:self._save_choice("overview_font_scale",c),(_("Movies") + "/" + _("Series") + " • " + _("Font Size")),choices,selection,(_("Information") + " • " + _("Font Size")))
        elif action == "description_language":
            current=str(cfg.get("description_language") or "ar-en")
            choices=[(_(label),code) for code,label in description_language_choices()]
            selection=next((i for i,x in enumerate(choices) if x[1]==current),0)
            self._context_open_choice(lambda c:self._save_choice("description_language",c),_("TMDb Information Language"),choices,selection,_("This controls movie and series TMDb information. The selected language is requested first and missing fields fall back to English. Clean Names and artwork/title-logo language are separate."))
        elif action == "fanart_api_key":
            self.session.openWithCallback(self._save_fanart_api_key, SettingsGlassInputScreen, title=_("Fanart.tv API key"), text=str(cfg.get("fanart_api_key") or ""), maxSize=512)
        elif action == "subdl_api_key":
            self.session.openWithCallback(self._save_subdl_api_key, SettingsGlassInputScreen, title=_("SubDL API key"), text=("" if cfg.get("subdl_api_key_source")=="builtin" else str(cfg.get("subdl_api_key") or "")), maxSize=512)
        elif action == "subsource_api_key":
            self.session.openWithCallback(self._save_subsource_api_key, SettingsGlassInputScreen, title=_("SubSource API key"), text=("" if cfg.get("subsource_api_key_source")=="builtin" else str(cfg.get("subsource_api_key") or "")), maxSize=512)
        elif action == "tmdb_test":
            credential=str(cfg.get("tmdb_credential") or "").strip()
            if not credential:
                self._context_open_notice(_("TMDB"),_("Add a TMDB API key or Read Access Token first."))
            else:
                self["status"].setText(_("Testing TMDB connection..."))
                def _ok(value):
                    self._context_open_notice(_("TMDB"),_("TMDB connection successful."))
                    self["status"].setText(_("TMDB ready"))
                self._run_async(lambda: TMDBClient(credential,cfg.get("tmdb_language","ar-EG"),cfg.get("timeout",10)).test(), _ok, lambda e:self._context_open_notice(_("TMDB"),_("TMDB test failed: %s")%e))
        elif action == "tmdb_credits":
            self._context_open_notice(_("TMDB Metadata"),_("This product uses the TMDB API but is not endorsed or certified by TMDB.\n\nTMDB data/images are used only when you configure your own credential."))
        elif action == "backup_restore":
            self._open_backup_restore()
        elif action == "support_bundle":
            self._export_support_bundle()
        elif action == "web_cleaner_access":
            current=str(cfg.get("web_cleaner_access") or "easy")
            selection=1 if current=="protected" else 0
            self._context_open_choice(self._web_cleaner_access_selected,_("Web Cleaner Access"),[(_("Easy - LAN direct"),"easy"),(_("Protected - PIN / QR"),"protected")],selection,_("Choose how devices on your network open Web Cleaner"))
        elif action == "web_cleaner":
            mode=_("Easy LAN access") if cfg.get("web_cleaner_access","easy")=="easy" else _("PIN / QR protected")
            self._context_open_choice(self._web_cleaner_action,_("Web Cleaner"),[(_("Start / Show Link"),"start"),(_("Stop Service"),"stop"),(_("Start automatically: %s") % (_("On") if cfg.get("web_cleaner_autostart",False) else _("Off")),"autostart")],0,_("Premium Cleaner + Deep Check • %s")%mode)
        elif action == "online_update":
            self["status"].setText(_("Checking the official Ultra Stalker update channel..."))
            def _update_checked(info):
                info=dict(info or {})
                if not info.get("ok"):
                    if not info.get("configured"):
                        self._context_open_notice(_("Online Update"),_("The updater engine is ready, but the official release URL has not been linked to this build yet."))
                    else:
                        self._context_open_notice(_("Online Update"),_("Could not check for updates right now. Your installed version is unchanged."))
                    self["status"].setText(_("Update check finished safely"));return
                if not info.get("available"):
                    self._context_open_notice(_("Ultra Stalker is up to date"),_("You already have the latest official version: V%s")%str(info.get("current_label") or PLUGIN_VERSION))
                    self["status"].setText(_("Ultra Stalker is up to date"));return
                try:
                    from .updater import show_update_notice
                    show_update_notice(self.session,info)
                    self["status"].setText(_("Update available: V%s")%str(info.get("version_label") or info.get("version") or ""))
                except Exception as exc:
                    optional_failure("ui.online_update_notice",exc)
                    self._context_open_notice(_("Online Update"),_("Update V%s is available, but the premium update screen could not open.")%str(info.get("version_label") or info.get("version") or ""))
            def _update_failed(error):
                optional_failure("ui.online_update_check",error)
                self._context_open_notice(_("Online Update"),_("Could not check for updates right now. Your installed version is unchanged."))
                self["status"].setText(_("Update check failed safely"))
            try:
                from .updater import check_for_update
                self._run_async(lambda:check_for_update(timeout=10),_update_checked,_update_failed)
            except Exception as exc:
                _update_failed(exc)
        elif action == "about":
            _about_body = (_("Version: %s\nBuild: %s\nPython support: 3.12 / 3.13 / 3.14 / 3.15\nInterface: Full HD • Adaptive 3D Glass UI")%(PLUGIN_VERSION,BUILD_NAME)).replace("3.12 / 3.13 / 3.14 / 3.15", "2.7 (DreamOS OE2.5)")
            self._context_open_notice(_("Ultra Stalker Information"),_about_body + "\n" + (_("Developer: %s") % "Ahmed L-HadarY"))
        elif action == "diagnostics":
            self.open_diagnostics()

    def _save_proxy_port(self,value):
        if value is None:return
        try:
            port=int(str(value).strip())
            if not 1024 <= port <= 65535:raise ValueError()
            save_settings({"proxy_port":port});self.refresh();self["status"].setText(_("Proxy port saved. Restart the plugin before exporting bouquets again."))
        except Exception:
            self._context_open_notice(_("Invalid port"),_("Enter a port number between 1024 and 65535."))

    def _web_cleaner_state(self):
        try:
            from .webcleaner import status
            info=status()
            if not info.get("running"):return _("STOPPED")
            return _("RUNNING EASY :7725") if info.get("access_mode")=="easy" else _("RUNNING PIN :7725")
        except Exception:
            return _("STOPPED")

    def _web_cleaner_access_selected(self, choice):
        if not choice:return
        mode="protected" if choice[1]=="protected" else "easy"
        save_settings({"web_cleaner_access":mode})
        stopped=False
        try:
            from . import webcleaner
            if webcleaner.status().get("running"):
                webcleaner.stop();stopped=True
        except Exception as exc:optional_failure("ui.webcleaner_access_stop",exc)
        self.refresh()
        self["status"].setText(_("Web Cleaner access: %s%s")%(_("PIN / QR") if mode=="protected" else _("EASY"),_(" • service stopped; start again") if stopped else ""))

    def _web_cleaner_action(self, choice):
        if not choice: return
        try:
            if choice[1]=="autostart":
                cfg=load_settings()
                save_settings({"web_cleaner_autostart":not bool(cfg.get("web_cleaner_autostart",False))})
                self.refresh()
                return
            from . import webcleaner
            if choice[1] == "stop":
                webcleaner.stop(); self.refresh(); self["status"].setText(_("Web Cleaner stopped"))
                self._context_open_notice(_("Web Cleaner"),_("Service stopped. Port 7725 is closed."))
                return
            info=webcleaner.start(); self.refresh(); self["status"].setText(_("Web Cleaner running on port 7725"))
            self.session.open(SettingsWebCleanerReadyScreen,info.get("url"),info.get("pair_code"),info.get("qr_path"),info.get("access_mode"))
        except Exception as exc:
            self._context_open_notice(_("Web Cleaner"),_("Could not start Web Cleaner:\n%s") % exc)

    def _plugin_language_selected(self, choice):
        if not choice:
            return
        code=str(choice[1] or "en")
        # Interface changes establish the matching TMDb Information Language as
        # the new default. The user can still override Information Language
        # independently afterwards.  AR + EN remains a manual special preset.
        description_code=default_description_for_interface(code)
        save_settings({"plugin_language":code,"description_language":description_code})
        set_plugin_language(code)
        # Refresh this screen immediately; other screens pick the language up
        # the next time they are opened. Layout geometry is intentionally unchanged.
        try:
            self["title"].setText(_("Settings"))
            self["info_title"].setText(_("Portal Settings"))
            self["info"].setText(_("Choose an option to configure playback, lists and privacy."))
            self["red"].setText(_("Back")); self["green"].setText(_("Change"))
            self["yellow"].setText(_("Diagnostics")); self["blue"].setText(_("Select"))
        except Exception:
            pass
        self.refresh()
        self["status"].setText(_("Language saved"))

    def _font_scale_selected(self,choice):
        if not choice:return
        save_settings({"font_scale":choice[1]});self.refresh()
        self["status"].setText(_("Font size saved. Restart Enigma2 to apply it everywhere."))
        self._context_open_notice(_("Font Size"),_("Font size saved. Restart Enigma2 to apply it everywhere."))

    def _save_choice(self,key,choice,_pin_authorized=False):
        if choice:
            if not _pin_authorized and key in ("parental_mode","parental_session_minutes"):
                _authorize_parental_change(self,lambda:self._save_choice(key,choice,True),SettingsGlassInputScreen)
                return
            save_settings({key:choice[1]}); self.refresh(); self["status"].setText(_("Setting saved"))

    def _save_pin(self,value,_pin_authorized=False):
        value=str(value or "")
        if value.isdigit() and 4 <= len(value) <= 8:
            if not _pin_authorized:
                _authorize_parental_change(self,lambda:self._save_pin(value,True),SettingsGlassInputScreen)
                return
            save_settings(parental_hash_pin(value))
            parental_lock_now()
            self.refresh()
            self["status"].setText(_("Parental PIN saved securely"))
        elif value:
            self._context_open_notice(_("Parental PIN"),_("PIN must contain 4-8 digits"))

    def _save_parental_pin_and_enable(self,value,_pin_authorized=False):
        value=str(value or "")
        if not value:
            self.refresh()
            self["status"].setText(_("Parental lock remains disabled"))
            return
        if not (value.isdigit() and 4 <= len(value) <= 8):
            self.refresh()
            self._context_open_notice(_("Parental PIN"),_("PIN must contain 4-8 digits. Parental Lock was not enabled."))
            return
        if not _pin_authorized:
            _authorize_parental_change(self,lambda:self._save_parental_pin_and_enable(value,True),SettingsGlassInputScreen)
            return
        payload=parental_hash_pin(value)
        payload["parental_lock"]=True
        save_settings(payload)
        parental_lock_now()
        self.refresh()
        self["status"].setText(_("Parental PIN saved • Parental lock enabled"))

    def _save_adult_keywords(self,value,_pin_authorized=False):
        if value is None:return
        if not _pin_authorized:
            _authorize_parental_change(self,lambda:self._save_adult_keywords(value,True),SettingsGlassInputScreen)
            return
        words=[]
        for part in str(value).split(","):
            word=us_casefold(part.strip())
            if word and word not in words:words.append(word[:40])
        save_settings({"adult_keywords":words});self.refresh();self["status"].setText(_("Adult keywords saved"))

    def _open_backup_restore(self):
        rows=[((_("Create portable backup") if action=="backup_all" else _("Restore backup")), action) for label, action in backup_choices()]
        self._context_open_choice(self._backup_action,_('Backup & Restore'),rows,0,_('Works on DreamOS and Open images'))

    def _backup_action(self,choice):
        if not choice:return
        action=choice[1]
        if action=='backup_all':
            self._create_backup_now()
        elif action=='restore':
            backups=list_backups()
            if not backups:
                self._context_open_notice(_('Backup & Restore'),_('No backups found on HDD.\n\nExpected folder: /media/hdd/UltraStalker/Backup/'))
                return
            rows=[]
            for path in backups:
                try:
                    manifest=inspect_backup(path)
                    kind='FULL' if manifest.get('contains_secrets') else 'LEGACY'
                    label=os.path.basename(path)+'  •  '+str(manifest.get('plugin_version') or 'unknown')+'  •  '+kind
                except Exception:
                    label=os.path.basename(path)+'  •  INVALID'
                rows.append((label,path))
            self._context_open_choice(self._restore_selected,_('Choose backup to restore'),rows,0,_('Available Ultra Stalker backups'))

    def _create_backup_now(self):
        self['status'].setText(_('Creating complete HDD backup…'))
        def work(): return create_backup()
        def done(result):
            self['status'].setText(_('Backup: %s')%result['path'])
            self._context_open_notice(_('Backup Created'),_('Complete backup created on HDD:\n%s\n\nPortals, settings and user API credentials are included. Artwork cache is not copied.')%result['path'])
        def failed(exc): self._context_open_notice(_('Backup Failed'),_('Backup failed: %s')%exc)
        self._run_async(work,done,failed)

    def _restore_selected(self,choice):
        if not choice:return
        self._restore_path=choice[1]
        try:inspect_backup(self._restore_path)
        except Exception as exc:self._context_open_notice(_('Invalid Backup'),_('Invalid backup: %s')%exc);return
        self._context_open_notice(_('Confirm Restore'),_('Restore this backup completely?\n\nThe selected backup will be restored directly. No additional backup copy will be created.'),self._restore_confirmed,True)

    def _restore_confirmed(self,answer):
        # The Yes/No card returns the whole (label, bool) row, which is truthy even
        # for "No"; only an explicit Yes may start a restore.
        if isinstance(answer,(tuple,list)):answer=answer[1] if len(answer)>1 else None
        if not answer:return
        path=self._restore_path
        self['status'].setText(_('Validating and restoring backup…'))
        def work(handle):
            return restore_backup(path,restore_secrets=True,cancel_event=handle.cancel_event)
        def done(result):
            self.refresh()
            message=_('Restore complete. Restart Enigma2/plugin before continuing.\n\nRestored: %s')%(', '.join(result.get('restored',[])))
            if result.get('adjusted_settings'):message+='\n\n'+_('Playback engine was adjusted to match this receiver.')
            self._context_open_notice(_('Restore Complete'),message)
        def failed(exc): self._context_open_notice(_('Restore Failed'),_('Restore failed: %s')%exc)
        self._run_async(work,done,failed)

    def _export_support_bundle(self):
        profile=dict(self.profile or {})
        def work(): return export_support_bundle('/tmp/ultrastalker-support.zip',profile)
        def done(path): self["status"].setText(_("Support bundle: %s")%path);self._context_open_notice(_("Support Bundle"),_("Redacted support bundle created:\n%s")%path)
        def failed(exc): self._context_open_notice(_("Support Bundle"),_("Support export failed: %s")%exc)
        self._run_async(work,done,failed)

    def _save_tmdb_credential(self, value):
        value=str(value or "").strip()
        try:
            save_tmdb_credential(value)
            self.refresh()
            self["status"].setText(_("TMDB credential saved privately in api_keys.conf") if value else _("TMDB credential cleared"))
        except Exception as exc:
            self._context_open_notice(_("TMDB"),_("TMDB credential save failed: %s")%exc)

    def _save_fanart_api_key(self, value):
        value=str(value or "").strip()[:4096]
        try:
            update_api_keys({"FANART_API_KEY":value})
            self.refresh()
            self["status"].setText(_("Fanart.tv API key saved privately in api_keys.conf") if value else _("Fanart.tv API key cleared"))
        except Exception as exc:
            self._context_open_notice(_("Fanart.tv"),_("Fanart.tv API key save failed: %s")%exc)

    def _save_subdl_api_key(self, value):
        value=str(value or "").strip()[:4096]
        try:
            from .storage import strip_builtin_value
            value=strip_builtin_value("SUBDL_API_KEY",value)
            update_api_keys({"SUBDL_API_KEY":value})
            self.refresh()
            self["status"].setText(_("SubDL API key saved privately in api_keys.conf") if value else _("SubDL API key cleared"))
        except Exception as exc:
            self._context_open_notice(_("Online Subtitles"),_("SubDL API key save failed: %s")%exc)

    def _save_subsource_api_key(self, value):
        value=str(value or "").strip()[:4096]
        try:
            from .storage import strip_builtin_value
            value=strip_builtin_value("SUBSOURCE_API_KEY",value)
            update_api_keys({"SUBSOURCE_API_KEY":value})
            self.refresh()
            self["status"].setText(_("SubSource API key saved privately in api_keys.conf") if value else _("SubSource API key cleared"))
        except Exception as exc:
            self._context_open_notice(_("Online Subtitles"),_("SubSource API key save failed: %s")%exc)

    def open_diagnostics(self):
        self.session.open(DiagnosticsScreen,self.profile)
