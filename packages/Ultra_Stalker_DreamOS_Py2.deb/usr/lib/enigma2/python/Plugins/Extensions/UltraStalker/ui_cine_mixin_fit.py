# -*- coding: utf-8 -*-
"""Font fitting.

Methods moved verbatim out of ``PremiumGlobalCinematicScreen`` (ui_cinematic_global.py); behaviour is unchanged.
This module is imported by ui_cinematic_global.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, max, min, us_func
from .wqhd_layout import responsive_font as _ultra_rfont, factors as _ultra_factors, _get_shared_probe

def _ultra_osd_scale():
    return _ultra_factors()[1]
from .ui_cinematic_global import (
    eLabel,
    gFont,
    load_settings,
    math,
    optional_failure,
    re,
)


class CineFitMixin(object):
    """Font fitting."""

    def _cin_fit_single_line_font(self, widget_name, text, max_size=42, min_size=9):
        """Conservative one-line fitter for very long titles/genres on OpenBH.

        OpenBH's calculateSize() can under-estimate mixed/Arabic glyph runs, so
        use a stronger width estimate first and only allow the native probe to
        reduce the font further.  The goal is simple: never let text escape its
        pill/title box, even for absurdly long provider/TMDB strings.
        """
        value=" ".join(str(text or "").replace("\n"," ").split()).strip()
        try:
            widget=self[widget_name];inst=widget.instance
            if inst is None:return
            width=max(70,int(inst.size().width())-36)
            try:
                if hasattr(inst,"setNoWrap"):inst.setNoWrap(1)
            except Exception as exc:optional_failure("cinematic.title_nowrap",exc)
            units=0.0;has_ar=False;has_latin=False
            for ch in value:
                code=ord(ch)
                if 0x0600<=code<=0x06ff:
                    has_ar=True;units+=0.86
                elif "A"<=ch<="Z":
                    has_latin=True;units+=0.78
                elif "a"<=ch<="z":
                    has_latin=True;units+=0.66
                elif ch.isdigit():units+=0.64
                elif ch.isspace():units+=0.38
                elif ch in ".,:;!?\'`-_/()[]{}":units+=0.42
                else:units+=0.72
            fcache=getattr(self,"_cin_font_fit_cache",None)
            if not isinstance(fcache,dict) or len(fcache)>512:
                fcache={};self._cin_font_fit_cache=fcache
            ckey=("single",widget_name,width,value,int(max_size),int(min_size))
            chosen=fcache.get(ckey)
            if chosen is None:
                safety=1.34 if has_ar and has_latin else (1.28 if has_ar else 1.22)
                units=max(1.0,units*safety)
                estimated=int(float(width)/(_ultra_osd_scale()*units))
                chosen=max(int(min_size),min(int(max_size),estimated))
                probe=_get_shared_probe()
                for size in range(chosen,int(min_size)-1,-1):
                    try:
                        if probe is not None:
                            probe.setFont(_ultra_rfont("Regular",size));probe.setText(value)
                            native=int(probe.calculateSize().width())
                        else:native=0
                    except Exception:native=0
                    if native>0 and int(native*1.10)>width:
                        chosen=max(int(min_size),size-1);continue
                    chosen=size;break
                fcache[ckey]=chosen
            inst.setFont(_ultra_rfont("Regular",chosen))
        except Exception as exc:optional_failure("cinematic.title_adaptive_font",exc)

    def _cin_fit_compact_text(self, widget_name, text=None, max_size=22, min_size=8, padding=6):
        """Keep every compact Cinematic metadata value on one adaptive line.

        Short values retain the generous native size. Longer/localized values
        shrink only enough to stay inside the existing pill. This changes text
        rendering only; geometry, metadata and provider/TMDB values are untouched.
        """
        try:
            widget=self[widget_name];inst=widget.instance
            if inst is None:return
            value=" ".join(str(widget.getText() if text is None else text or "").replace("\n"," ").split()).strip()
            if not value:return
            try:
                if hasattr(inst,"setNoWrap"):inst.setNoWrap(1)
            except Exception:pass
            width=max(24,int(inst.size().width())-int(padding))
            units=0.0;has_ar=False
            for ch in value:
                code=ord(ch)
                if 0x0600<=code<=0x06ff:
                    has_ar=True;units+=0.80
                elif "A"<=ch<="Z":units+=0.72
                elif "a"<=ch<="z":units+=0.59
                elif ch.isdigit():units+=0.58
                elif ch.isspace():units+=0.34
                elif ch in ".,:;!?\'`-_/()[]{}•":units+=0.36
                else:units+=0.68
            fcache=getattr(self,"_cin_font_fit_cache",None)
            if not isinstance(fcache,dict) or len(fcache)>512:
                fcache={};self._cin_font_fit_cache=fcache
            ckey=("compact",widget_name,width,value,int(max_size),int(min_size),int(padding))
            chosen=fcache.get(ckey)
            if chosen is None:
                safety=1.17 if has_ar else 1.10
                estimated=max(int(min_size),min(int(max_size),int(float(width)/max(1.0,_ultra_osd_scale()*units*safety))))
                chosen=int(min_size)
                probe=_get_shared_probe()
                for size in range(int(max_size),int(min_size)-1,-1):
                    if size>estimated+2:continue
                    try:
                        if probe is not None:
                            probe.setFont(_ultra_rfont("Regular",size));probe.setText(value)
                            native=int(probe.calculateSize().width())
                        else:native=0
                    except Exception:native=0
                    painted=max(native,int(units*size*safety*_ultra_osd_scale())) if native>0 else int(units*size*safety*_ultra_osd_scale())
                    if painted<=width:
                        chosen=size;break
                fcache[ckey]=chosen
            inst.setFont(_ultra_rfont("Regular",chosen))
        except Exception as exc:optional_failure("cinematic.compact_adaptive_font",exc)

    def _cin_fit_runtime_like_details(self):
        """Use the native Details compact-text fitter itself for seasons/runtime.

        This deliberately reuses the exact Details implementation instead of a
        Cinematic copy, so receiver font metrics and adaptive sizing stay identical.
        """
        try:
            from .ui import _load_screen_group
            _load_screen_group('details')
            from .ui_screens_details import ContentDetailsScreen
            us_func(ContentDetailsScreen._fit_compact_text)(self,"runtime_text",max_size=24,min_size=18,padding=4)
        except Exception as exc:
            optional_failure("cinematic.runtime_details_fit",exc)

    def _cin_fit_description_font(self):
        """Fill the Cinematic overview glass with the largest safe user-selected font.

        R70 only wired the new setting into Details; Cinematic still had a hard
        26px ceiling.  R71 applies the same preference here and trusts Enigma2's
        wrapped-height measurement first, so short overviews can genuinely grow
        while long ones still step down until every line fits.
        """
        try:
            value=str(self["description"].getText() or "").strip();widget=self["description"]
            inst=widget.instance
            try:
                from .ui_smooth_text import scroller as _smooth_scroller
                _scr=_smooth_scroller(self,"description","skin")
            except Exception:_scr=None
            if not value and _scr is not None:_scr.stop()
            if inst is None or not value:return
            width=max(200,int(inst.size().width()));height=max(40,int(inst.size().height()))
            try:mode=str((getattr(self,"_grid_settings",None) or load_settings() or {}).get("overview_font_scale") or "normal").strip().lower()
            except Exception:mode="normal"
            preferred={"normal":26,"large":34,"larger":42,"xlarge":52}.get(mode,26)
            desc_sig=(value,width,height,preferred)
            if getattr(self,"_cin_desc_fit_sig",None)==desc_sig:
                return
            self._cin_desc_fit_sig=desc_sig
            min_size=16
            is_ar=bool(re.search(r"[\u0600-\u06ff]",value))
            safe_height=max(40,int(height*(0.98 if is_ar else 0.99)))
            fallback_factor=0.50 if is_ar else 0.54
            chosen=min_size;fit_size=None
            for size in range(int(preferred),int(min_size)-1,-1):
                try:
                    inst.setFont(_ultra_rfont("Regular",size))
                    native_h=int(inst.calculateSize().height())
                except Exception:
                    native_h=0
                if native_h>0:
                    needed=int(native_h*(1.06 if is_ar else 1.03))
                else:
                    chars_per_line=max(10,int(width/max(1.0,size*_ultra_osd_scale()*fallback_factor)))
                    weighted=len(value)+value.count("\n")*chars_per_line
                    lines=max(1,int(math.ceil(float(weighted)/float(chars_per_line))))
                    needed=lines*int(size*_ultra_osd_scale()*1.18)
                if needed<=safe_height:
                    chosen=size;fit_size=size;break
            # Long text: keep a readable font and scroll it slowly instead of shrinking.
            comfort=22
            if _scr is not None:
                if fit_size is None or fit_size<comfort:
                    inst.setFont(_ultra_rfont("Regular",comfort))
                    if _scr.start(value,comfort):return
                _scr.stop()
            inst.setFont(_ultra_rfont("Regular",int(chosen)))
            try:widget.show()
            except Exception:pass
        except Exception as exc:optional_failure("cinematic.description_adaptive_font",exc)
