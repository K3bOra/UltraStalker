# -*- coding: utf-8 -*-
"""Track and retire only picon files that Ultra Stalker actually published."""
from __future__ import absolute_import, unicode_literals

import errno
import json
import os
import re
import stat
import threading
from ..us_env import os, open, str, OSError

_LOCK = threading.RLock()
_LAST_SCAN = None
_CHILD = re.compile(r'FROM BOUQUET "([^"\r\n]+)"')


def _journal(config_dir):
    return os.path.join(config_dir, "export_picons.jsonl")


def _stamp(path):
    value = os.lstat(path)
    return (value.st_dev, value.st_ino, value.st_size,
            getattr(value, "st_mtime_ns", int(value.st_mtime * 1000000000)))


def install(stage, target, records):
    """Install a finished PNG only when the receiver has no file at that name."""
    with _LOCK:
        if os.path.lexists(target):
            return False
        os.replace(stage, target)
        records.append((target, _stamp(target)))
        return True


def remember(config_dir, records):
    if not records:
        return
    from . import bouquets as b
    try:
        with _LOCK:
            os.makedirs(config_dir, mode=0o700, exist_ok=True)
            flags = os.O_WRONLY | os.O_APPEND | os.O_CREAT | getattr(os, "O_NOFOLLOW", 0)
            fd = os.open(_journal(config_dir), flags, 0o600)
            with os.fdopen(fd, "ab") as handle:
                payload = json.dumps(records, ensure_ascii=True, separators=(",", ":"))
                # The leading newline isolates any interrupted prior append.
                handle.write(("\n" + payload + "\n").encode("ascii"))
    except OSError as exc:
        b.LOG.warning("Export picon ownership could not be saved: %s", exc)


def _snapshot(b):
    paths = {}
    for name in os.listdir(b.ENIGMA2_DIR):
        if name.endswith((".tv", ".radio")):
            path = os.path.join(b.ENIGMA2_DIR, name)
            paths[name] = _stamp(path)
    return paths


def _referenced_names(b, files, registry, tracked):
    """Find every alias still used by a receiver bouquet or active series."""
    used = set()
    pending = ["bouquets.tv"]
    if "bouquets.radio" in files:
        pending.append("bouquets.radio")
    visited = set()

    def mark(ref, name=""):
        for alias in b._picon_filenames(ref, name):
            if alias in tracked:
                used.add(alias)
            if alias.lower() in tracked:
                used.add(alias.lower())

    def mark_episodes(fields):
        try:
            url = b.urllib.parse.urlsplit(b.urllib.parse.unquote(fields[10]))
        except ValueError:
            return
        parts = url.path.strip("/").split("/")
        if (url.hostname not in ("127.0.0.1", "localhost", "::1")
                or len(parts) not in (3, 4) or parts[0] != "stream"):
            return
        entry = registry.get(parts[-2]) or {}
        channels = entry.get("channels") or {}
        launcher = (channels.get(parts[-1]) or {}).get("_receiver_series_launcher") or {}
        for season in launcher.get("seasons") or []:
            for key in season.get("episode_keys") or []:
                row = channels.get(key)
                if isinstance(row, dict):
                    ref = b._service_ref("", fields[0], identity=key)
                    mark(ref, b._receiver_name(row, "episode"))

    while pending:
        name = pending.pop()
        if name in visited or name not in files:
            continue
        visited.add(name)
        ref = ""
        with open(os.path.join(b.ENIGMA2_DIR, name), "r", encoding="utf-8", errors="strict") as handle:
            if name in ("bouquets.tv", "bouquets.radio"):
                if not handle.readline().lstrip("\ufeff").startswith("#NAME "):
                    raise ValueError("Bouquet index is incomplete")
            for raw in handle:
                if raw.startswith("#SERVICE "):
                    ref = raw[9:].rstrip("\r\n")
                    child = _CHILD.search(ref)
                    if child:
                        filename = child.group(1)
                        # Internal season lists are indexed as hidden bookkeeping.
                        # A visible launcher or folder makes their artwork live.
                        if not (ref.startswith("1:519:") and "_native_series_" in filename
                                and filename.startswith("userbouquet.ultrastalker_")):
                            pending.append(filename)
                        else:
                            ref = ""
                            continue
                    fields = ref.split(":", 11)
                    if len(fields) >= 11:
                        mark(ref, fields[11] if len(fields) == 12 and not child else "")
                        if not child:
                            mark_episodes(fields)
                elif ref and raw.startswith("#DESCRIPTION "):
                    mark(ref, raw[13:].rstrip("\r\n"))
                    ref = ""
    return used


def sweep():
    """Read actual bouquets and release unused aliases. Call off the GUI thread."""
    from . import bouquets as b
    global _LAST_SCAN
    journal = _journal(b.CONFIG_DIR)
    if not os.path.isfile(journal) or os.path.islink(journal):
        return 0
    if not b._REGISTRY_LOCK.acquire(False):
        return 0
    try:
        with _LOCK:
            files = _snapshot(b)
            if "bouquets.tv" not in files:
                return 0
            state = (files, _stamp(journal))
            if state == _LAST_SCAN:
                return 0
            records = {}
            with open(journal, "r", encoding="ascii") as handle:
                for line in handle:
                    if not line.strip():
                        continue
                    try:
                        for path, stamp in json.loads(line):
                            if os.path.dirname(path) in b._PICON_EXPORT_ROOTS and path.endswith(".png"):
                                if isinstance(stamp,(list,tuple)) and len(stamp)==4:
                                    records[path] = tuple(stamp)
                    except (ValueError, TypeError):
                        continue
            tracked = {os.path.basename(path) for path in records}
            used = _referenced_names(b, files, b._read_registry(), tracked)
            if files != _snapshot(b):
                return 0
            keep = {}
            removed = 0
            retry = False
            for path, stamp in records.items():
                if os.path.basename(path) in used:
                    keep[path] = stamp
                    continue
                try:
                    parent = os.path.dirname(path)
                    if not os.path.isdir(parent) or os.stat(parent).st_dev != stamp[0]:
                        # A removable disk can be offline while its bouquet is deleted.
                        keep[path] = stamp
                        retry = True
                    elif stat.S_ISREG(os.lstat(path).st_mode) and _stamp(path) == stamp:
                        os.unlink(path)
                        removed += 1
                except OSError as exc:
                    if exc.errno != errno.ENOENT:
                        keep[path] = stamp
                        retry = True
            if keep != records:
                content = "\n".join(json.dumps([record], ensure_ascii=True, separators=(",", ":"))
                                    for record in keep.items())
                b._atomic_text(journal, content + "\n" if content else "", 0o600)
            if not retry:
                _LAST_SCAN = (files, _stamp(journal))
            return removed
    except (OSError, ValueError) as exc:
        b.LOG.debug("Export picon cleanup deferred: %s", exc)
        return 0
    finally:
        b._REGISTRY_LOCK.release()
