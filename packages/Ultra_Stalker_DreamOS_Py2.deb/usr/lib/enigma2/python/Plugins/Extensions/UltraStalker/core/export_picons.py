# -*- coding: utf-8 -*-
"""Track and retire only picon files that Ultra Stalker actually published."""
from __future__ import absolute_import, unicode_literals

import errno
import json
import os
import re
import stat
import threading
from ..us_env import os, open, str, OSError

_LOCK = threading.RLock()
_LAST_SCAN = None
_CHILD = re.compile(r'FROM BOUQUET "([^"\r\n]+)"')


def _journal(config_dir):
    return os.path.join(config_dir, "export_picons.jsonl")


def _stamp(path):
    value = os.lstat(path)
    return (value.st_dev, value.st_ino, value.st_size,
            getattr(value, "st_mtime_ns", int(value.st_mtime * 1000000000)))


def install(stage, target, records):
    """Install a finished PNG only when the receiver has no file at that name."""
    with _LOCK:
        if os.path.lexists(target):
            return False
        os.replace(stage, target)
        records.append((target, _stamp(target)))
        return True


def remember(config_dir, records):
    if not records:
        return
    from . import bouquets as b
    try:
        with _LOCK:
            os.makedirs(config_dir, mode=0o700, exist_ok=True)
            flags = os.O_WRONLY | os.O_APPEND | os.O_CREAT | getattr(os, "O_NOFOLLOW", 0)
            fd = os.open(_journal(config_dir), flags, 0o600)
            with os.fdopen(fd, "ab") as handle:
                payload = json.dumps(records, ensure_ascii=True, separators=(",", ":"))
                # The leading newline isolates any interrupted prior append.
                handle.write(("\n" + payload + "\n").encode("ascii"))
    except OSError as exc:
        b.LOG.warning("Export picon ownership could not be saved: %s", exc)


def _snapshot(b):
    paths = {}
    try:
        names = os.listdir(b.ENIGMA2_DIR)
    except OSError:
        return paths
    for name in names:
        if name.endswith((".tv", ".radio")):
            path = os.path.join(b.ENIGMA2_DIR, name)
            try:
                paths[name] = _stamp(path)
            except OSError:
                continue
    return paths


def _reconcile_deleted_bouquets(b, files):
    """Synchronize bouquet_registry.json and orphaned sub-bouquets with bouquets.tv.

    When a user deletes an exported bouquet from Enigma2's ChannelSelection UI,
    bouquets.tv drops the reference to that bouquet, but orphaned sub-bouquets
    (such as native_series files) and stale registry entries would otherwise
    keep its picons referenced forever and resurrect the bouquet on restart.
    """
    if "bouquets.tv" not in files:
        return files, set()
    visible_bouquets = set()
    hidden_native_series = set()
    pending = ["bouquets.tv"]
    if "bouquets.radio" in files:
        pending.append("bouquets.radio")
    visited = set()
    stream_keys_by_profile = {}

    while pending:
        name = pending.pop()
        if name in visited or name not in files:
            continue
        visited.add(name)
        try:
            with open(os.path.join(b.ENIGMA2_DIR, name), "r", encoding="utf-8", errors="replace") as handle:
                for raw in handle:
                    if not raw.startswith("#SERVICE "):
                        continue
                    ref = raw[9:].rstrip("\r\n")
                    child = _CHILD.search(ref)
                    if child:
                        cname = child.group(1)
                        if ref.startswith("1:519:") and "_native_series_" in cname and cname.startswith("userbouquet.ultrastalker_"):
                            hidden_native_series.add(cname)
                            continue
                        if cname in files:
                            visible_bouquets.add(cname)
                            pending.append(cname)
                    fields = ref.split(":", 11)
                    if len(fields) >= 11:
                        try:
                            url = b.urllib.parse.urlsplit(b.urllib.parse.unquote(fields[10]))
                            parts = url.path.strip("/").split("/")
                            if url.hostname in ("127.0.0.1", "localhost", "::1") and len(parts) in (3, 4) and parts[0] == "stream":
                                stream_keys_by_profile.setdefault(parts[-2], set()).add(parts[-1])
                        except Exception:
                            pass
        except OSError:
            continue

    retired_picon_names = set()
    try:
        registry = b._read_registry()
    except Exception:
        return files, retired_picon_names
    if not isinstance(registry, dict):
        return files, retired_picon_names

    from .export_series import native_series_filename
    registry_changed = False
    active_native_series_all = set()
    owned_visible_bouquets = set()

    for pkey, entry in list(b._registry_entries(registry).items()):
        if not isinstance(entry, dict):
            continue
        profile = entry.get("profile") or {}
        channels = dict(entry.get("channels") or {})
        metadata_records = dict(entry.get("media_metadata") or {})
        port = int(entry.get("proxy_port") or b._registry_port(registry))
        token = str(entry.get("proxy_token") or "")
        stype = int(entry.get("service_type") or 4097)
        entry_changed = False
        had_deleted_export = False

        # 1. Reconcile category_exports, vod_category_exports, series_category_exports
        for export_group_key in ("category_exports", "vod_category_exports", "series_category_exports"):
            exports_dict = dict(entry.get(export_group_key) or {})
            for digest, exp_info in list(exports_dict.items()):
                bname = str((exp_info or {}).get("bouquet_name") or "")
                if bname and bname not in visible_bouquets:
                    exports_dict.pop(digest, None)
                    entry_changed = True
                    had_deleted_export = True
                elif bname:
                    owned_visible_bouquets.add(bname)
            if entry_changed:
                entry[export_group_key] = exports_dict

        # 2. Reconcile smart_exports
        smart_dict = dict(entry.get("smart_exports") or {})
        for group_name, s_info in list(smart_dict.items()):
            bname = str((s_info or {}).get("bouquet_name") or ("userbouquet.ultrastalker_%s_smart_%s.tv" % (pkey, group_name)))
            if bname not in visible_bouquets:
                smart_dict.pop(group_name, None)
                entry_changed = True
                had_deleted_export = True
            else:
                owned_visible_bouquets.add(bname)
        if entry_changed:
            entry["smart_exports"] = smart_dict

        # 3. Reconcile manual_exports
        manual_dict = dict(entry.get("manual_exports") or {})
        for bname in list(manual_dict.keys()):
            if bname not in visible_bouquets:
                manual_dict.pop(bname, None)
                entry_changed = True
                had_deleted_export = True
        if entry_changed:
            entry["manual_exports"] = manual_dict

        # 4. Check full live bouquet
        full_live_bname = str(entry.get("bouquet_name") or ("userbouquet.ultrastalker_%s_live.tv" % pkey))
        if full_live_bname in visible_bouquets:
            owned_visible_bouquets.add(full_live_bname)
        elif entry.get("bouquet_name"):
            entry.pop("bouquet_name", None)
            entry_changed = True
            had_deleted_export = True

        # 5. Collect active series native bouquet filenames and active channel keys
        active_keys = set(stream_keys_by_profile.get(pkey, set()))
        for exp_info in (entry.get("series_category_exports") or {}).values():
            for child in (exp_info or {}).get("children") or []:
                lkey = child.get("launcher_key")
                if lkey:
                    active_keys.add(lkey)
                    ns_file = native_series_filename(profile, lkey)
                    active_native_series_all.add(ns_file)
                for ep_key in child.get("episodes") or []:
                    active_keys.add(ep_key)
                for season in child.get("seasons") or []:
                    for ep_key in (season or {}).get("episode_keys") or []:
                        active_keys.add(ep_key)
        # Also check if any launcher_key in active_keys (e.g. in a custom bouquet) has seasons
        for ckey in list(active_keys):
            row = channels.get(ckey) or {}
            launcher = row.get("_receiver_series_launcher") or {}
            if launcher:
                ns_file = native_series_filename(profile, ckey)
                active_native_series_all.add(ns_file)
                for season in launcher.get("seasons") or []:
                    for ep_key in (season or {}).get("episode_keys") or []:
                        active_keys.add(ep_key)

        if had_deleted_export or (channels and not active_keys):
            for ckey in list(channels.keys()):
                if ckey not in active_keys:
                    row = channels.pop(ckey, None) or {}
                    entry_changed = True
                    kind = str(row.get("_receiver_media_type") or "itv").lower()
                    ref = b._service_ref(b._proxy_url(pkey, ckey, port, token), stype, identity=ckey)
                    rname = b._receiver_name(row, kind)
                    for alias in b._picon_filenames(ref, rname):
                        retired_picon_names.add(alias)
                        retired_picon_names.add(alias.lower())
            active_meta_keys = {
                (r.get("_receiver_metadata_key") or "")
                for r in channels.values()
                if isinstance(r, dict) and r.get("_receiver_metadata_key")
            }
            for mkey in list(metadata_records.keys()):
                if mkey not in active_meta_keys:
                    metadata_records.pop(mkey, None)
                    entry_changed = True
            entry["channels"] = channels
            entry["media_metadata"] = metadata_records

        if entry_changed:
            registry[pkey] = entry
            registry_changed = True

    if registry_changed:
        try:
            b._write_registry(registry)
        except Exception as exc:
            b.LOG.debug("Export registry reconciliation write skipped: %s", exc)

    # 6. Clean up orphaned userbouquet.ultrastalker_*.tv files on disk & hidden 1:519 refs in bouquets.tv
    orphaned_bouquet_files = set()
    for fname in list(files.keys()):
        if not (fname.startswith("userbouquet.ultrastalker_") and fname.endswith(".tv")):
            continue
        if "_native_series_" in fname:
            if fname not in active_native_series_all and fname not in visible_bouquets:
                orphaned_bouquet_files.add(fname)
        else:
            if fname not in visible_bouquets:
                orphaned_bouquet_files.add(fname)

    if orphaned_bouquet_files:
        for fname in orphaned_bouquet_files:
            fpath = os.path.join(b.ENIGMA2_DIR, fname)
            try:
                if os.path.isfile(fpath):
                    os.unlink(fpath)
                    b._fsync_parent_dir(fpath)
            except OSError:
                pass
        bouquet_index = os.path.join(b.ENIGMA2_DIR, "bouquets.tv")
        try:
            with open(bouquet_index, "r", encoding="utf-8", errors="replace", newline="") as handle:
                original_index = handle.read()
            def _is_orphaned_ref(service):
                m = _CHILD.search(service)
                return bool(m and m.group(1) in orphaned_bouquet_files)
            filtered_index = b._filter_export_services(original_index, _is_orphaned_ref)
            if filtered_index != original_index:
                b._atomic_text(bouquet_index, filtered_index, 0o644)
        except OSError:
            pass
        files = _snapshot(b)

    return files, retired_picon_names


def _referenced_names(b, files, registry, tracked):
    """Find every alias still used by a receiver bouquet or active series."""
    used = set()
    pending = ["bouquets.tv"]
    if "bouquets.radio" in files:
        pending.append("bouquets.radio")
    visited = set()

    def mark(ref, name=""):
        for alias in b._picon_filenames(ref, name):
            if alias in tracked:
                used.add(alias)
            if alias.lower() in tracked:
                used.add(alias.lower())

    def mark_episodes(fields):
        try:
            url = b.urllib.parse.urlsplit(b.urllib.parse.unquote(fields[10]))
        except ValueError:
            return
        parts = url.path.strip("/").split("/")
        if (url.hostname not in ("127.0.0.1", "localhost", "::1")
                or len(parts) not in (3, 4) or parts[0] != "stream"):
            return
        entry = registry.get(parts[-2]) or {}
        channels = entry.get("channels") or {}
        launcher = (channels.get(parts[-1]) or {}).get("_receiver_series_launcher") or {}
        for season in launcher.get("seasons") or []:
            for key in season.get("episode_keys") or []:
                row = channels.get(key)
                if isinstance(row, dict):
                    ref = b._service_ref("", fields[0], identity=key)
                    mark(ref, b._receiver_name(row, "episode"))

    while pending:
        name = pending.pop()
        if name in visited or name not in files:
            continue
        visited.add(name)
        ref = ""
        try:
            with open(os.path.join(b.ENIGMA2_DIR, name), "r", encoding="utf-8", errors="replace") as handle:
                for raw in handle:
                    if raw.startswith("#SERVICE "):
                        ref = raw[9:].rstrip("\r\n")
                        child = _CHILD.search(ref)
                        if child:
                            filename = child.group(1)
                            # Internal season lists are indexed as hidden bookkeeping.
                            # A visible launcher or folder makes their artwork live.
                            if not (ref.startswith("1:519:") and "_native_series_" in filename
                                    and filename.startswith("userbouquet.ultrastalker_")):
                                pending.append(filename)
                            else:
                                ref = ""
                                continue
                        fields = ref.split(":", 11)
                        if len(fields) >= 11:
                            mark(ref, fields[11] if len(fields) == 12 and not child else "")
                            if not child:
                                mark_episodes(fields)
                    elif ref and raw.startswith("#DESCRIPTION "):
                        mark(ref, raw[13:].rstrip("\r\n"))
                        ref = ""
        except OSError:
            continue
    return used


def sweep():
    """Read actual bouquets and release unused aliases. Call off the GUI thread."""
    from . import bouquets as b
    global _LAST_SCAN
    journal = _journal(b.CONFIG_DIR)
    has_journal = os.path.isfile(journal) and not os.path.islink(journal)
    if not b._REGISTRY_LOCK.acquire(False):
        return 0
    try:
        with _LOCK:
            files = _snapshot(b)
            if "bouquets.tv" not in files:
                return 0
            journal_stamp = _stamp(journal) if has_journal else None
            state = (files, journal_stamp)
            if state == _LAST_SCAN:
                return 0
            files, retired_names = _reconcile_deleted_bouquets(b, files)
            records = {}
            valid_roots = {os.path.abspath(r) for r in b._PICON_EXPORT_ROOTS}
            if has_journal:
                with open(journal, "r", encoding="ascii", errors="replace") as handle:
                    for line in handle:
                        if not line.strip():
                            continue
                        try:
                            for path, stamp in json.loads(line):
                                if os.path.abspath(os.path.dirname(path)) in valid_roots and path.endswith(".png"):
                                    if isinstance(stamp, (list, tuple)) and len(stamp) == 4:
                                        records[path] = tuple(stamp)
                        except (ValueError, TypeError):
                            continue
            tracked = {os.path.basename(path) for path in records} | set(retired_names)
            used = _referenced_names(b, files, b._read_registry(), tracked) if tracked else set()
            if files != _snapshot(b):
                return 0
            keep = {}
            removed = 0
            retry = False
            for path, stamp in records.items():
                bname = os.path.basename(path)
                if bname in used or bname.lower() in used:
                    keep[path] = stamp
                    continue
                try:
                    parent = os.path.dirname(path)
                    if not os.path.isdir(parent) or os.stat(parent).st_dev != stamp[0]:
                        # A removable disk can be offline while its bouquet is deleted.
                        keep[path] = stamp
                        retry = True
                    else:
                        st = os.lstat(path)
                        if stat.S_ISREG(st.st_mode) and (st.st_dev, st.st_ino, st.st_size) == (stamp[0], stamp[1], stamp[2]):
                            os.unlink(path)
                            removed += 1
                except OSError as exc:
                    if exc.errno != errno.ENOENT:
                        keep[path] = stamp
                        retry = True
            if has_journal and keep != records:
                content = "\n".join(json.dumps([record], ensure_ascii=True, separators=(",", ":"))
                                     for record in keep.items())
                b._atomic_text(journal, content + "\n" if content else "", 0o600)
            if not retry:
                _LAST_SCAN = (files, _stamp(journal) if os.path.isfile(journal) else None)
            return removed
    except (OSError, ValueError) as exc:
        b.LOG.debug("Export picon cleanup deferred: %s", exc)
        return 0
    finally:
        b._REGISTRY_LOCK.release()
