# -*- coding: utf-8 -*-
"""Grid artwork mixin extracted from ui.py without changing behavior."""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str, int, max, OSError, us_clear, us_acquire
__metaclass__ = type
threading = _us_env.threading
os = _us_env.os
time = _us_env.time
from .core.runtime_log import diagnostic_breadcrumb as _ui_diag
from .persistent_cache import durable_view_path
from .adaptive_mode import adaptive_enabled as _grid_adaptive_on
from .core.shared_executors import LIVE_PICON_EXECUTOR as _LIVE_PICON_EXECUTOR

def configure_grid_artwork(**deps):
    globals().update(deps)

def _live_picon_candidates(item, profile=None):
    """Return ordered usable Live logo fields without placeholder values.

    Some providers publish a dead stream_icon while a working picon/logo field is
    present on the same row.  The old first-field-only path then painted the
    placeholder forever.  Keep this Live-only and bounded.
    """
    from .provider_art import picon_urls
    return picon_urls(item, profile)

class GridArtworkMixin:
    """Bounded three-page artwork cache with one sequential OpenBH decoder."""

    def _grid_art_init(self, slot_names, image_size, profile, client):
        self._grid_slot_names = list(slot_names)
        self._grid_image_size = tuple(image_size)
        self._grid_profile = profile
        self._grid_client = client
        self._grid_generation = 0
        self._grid_download_jobs = queue.Queue()
        self._grid_decode_queue = []
        self._grid_decode_busy = False
        self._grid_decode_active = None
        self._grid_closed = False
        self._grid_slots = threading.BoundedSemaphore(6)
        self._grid_decode_cache = OrderedDict()
        self._grid_decode_cache_limit = max(self.page_size + 2, 14)
        global _GLOBAL_GRID_PIXMAP_CACHE_LIMIT
        try:
            _GLOBAL_GRID_PIXMAP_CACHE_LIMIT = 2 if _available_memory_mb() < 220 else 6
        except Exception:
            _GLOBAL_GRID_PIXMAP_CACHE_LIMIT = 2
        self._grid_waiting = {}
        self._grid_queued = set()
        self._grid_slot_paths = {}
        self._grid_slot_identities = {}
        self._grid_palette_sources = {}
        self._grid_accent_jobs = queue.Queue()
        self._grid_accent_pending = set()
        self._grid_download_inflight = {}
        self._grid_download_futures = {}
        self._grid_poster_thumb_pending = set()
        self._grid_download_lock = threading.Lock()
        try:
            _native_image_pressure_relief(force=False)
        except Exception as exc:
            optional_failure('ui.grid_pressure_relief_init', exc)
        self._grid_picload = ePicLoad()
        self._grid_pic_connection = None
        try:
            self._grid_picload.PictureData.get().append(self._grid_picture_ready)
        except Exception:
            try:
                self._grid_pic_connection = self._grid_picload.PictureData.connect(self._grid_picture_ready)
            except Exception as exc:
                optional_failure('ui', exc)

    def _grid_art_layout_ready(self):
        try:
            from .wqhd_layout import wh as _wqhd_wh
            pw, ph = _wqhd_wh(self._grid_image_size[0], self._grid_image_size[1])
            self._grid_picload.setPara((pw, ph, 1, 1, False, 1, '#000000'))
        except Exception as exc:
            optional_failure('ui', exc)

    def _grid_thumbnail_size(self):
        from .wqhd_layout import wh
        return tuple(wh(self._grid_image_size[0], self._grid_image_size[1]))

    def _grid_cache_key(self, path):
        # One source can be decoded at several sizes across grid presentations.
        from .wqhd_layout import wh
        width,height=wh(self._grid_image_size[0],self._grid_image_size[1])
        try:
            st=os.stat(path)
            stamp=(getattr(st,"st_ino",0),st.st_size,getattr(st,"st_mtime_ns",st.st_mtime))
        except OSError:
            stamp=None
        return (path,int(width),int(height),stamp)

    def _grid_cache_get(self, path):
        key=self._grid_cache_key(path)
        ptr=self._grid_decode_cache.get(key)
        if ptr is not None:
            self._grid_decode_cache.move_to_end(key)
            return ptr
        try:
            with _GLOBAL_GRID_PIXMAP_CACHE_LOCK:
                ptr=_GLOBAL_GRID_PIXMAP_CACHE.get(key)
                if ptr is not None:_GLOBAL_GRID_PIXMAP_CACHE.move_to_end(key)
            if ptr is not None:
                # Apply the same local bound on a process-cache hit as on decode.
                self._grid_cache_put(path,ptr)
                return ptr
        except Exception as exc:optional_failure("ui.grid_global_cache_get",exc)
        return None

    def _grid_cache_put(self, path, ptr):
        if ptr is None:return
        key=self._grid_cache_key(path)
        self._grid_decode_cache[key]=ptr
        self._grid_decode_cache.move_to_end(key)
        while len(self._grid_decode_cache)>self._grid_decode_cache_limit:
            self._grid_decode_cache.popitem(last=False)
        try:
            with _GLOBAL_GRID_PIXMAP_CACHE_LOCK:
                _GLOBAL_GRID_PIXMAP_CACHE[key]=ptr
                _GLOBAL_GRID_PIXMAP_CACHE.move_to_end(key)
                while len(_GLOBAL_GRID_PIXMAP_CACHE)>_GLOBAL_GRID_PIXMAP_CACHE_LIMIT:
                    _GLOBAL_GRID_PIXMAP_CACHE.popitem(last=False)
        except Exception as exc:optional_failure("ui.grid_global_cache_put",exc)

    def _grid_set_local(self, slot, path):
        try:
            widget = self[self._grid_slot_names[slot]]
            png = cached_png(path)
            if widget.instance is not None:
                if png is not None:
                    widget.instance.setPixmap(png)
                else:
                    widget.instance.setPixmapFromFile(path)
            widget.show()
        except Exception as exc:
            optional_failure('ui', exc)

    def _grid_set_ptr(self, slot, ptr):
        try:
            widget = self[self._grid_slot_names[slot]]
            if widget.instance is not None and ptr is not None:
                widget.instance.setPixmap(ptr)
            widget.show()
        except Exception as exc:
            optional_failure('ui', exc)

    def _grid_absolute_url(self, value, item=None):
        from .provider_art import absolute_url
        return absolute_url(value, self._grid_profile, item)

    def _ui_diag_first_real_art(self, path, slot):
        try:
            if getattr(self, '_ui_diag_first_poster_logged', False):
                return
            value = str(path or '')
            name = os.path.basename(value).lower()
            if not value or 'placeholder' in name or name.startswith(('poster_movie', 'poster_series', 'placeholder_live')):
                return
            self._ui_diag_first_poster_logged = True
            started = float(getattr(self, '_ui_diag_page_request_mono', time.monotonic()) or time.monotonic())
            _ui_diag('ui_first_art', screen='grid', media_type=getattr(self, 'media_type', ''), page=getattr(self, 'page', 0), slot=int(slot), elapsed_ms=int(max(0.0, (time.monotonic() - started) * 1000.0)))
        except Exception:
            pass

    def _grid_queue_decode(self, generation, slot, path):
        try:
            locked = str((getattr(self, '_grid_visual_locks', {}) or {}).get(slot) or '')
            current = str((getattr(self, '_grid_slot_paths', {}) or {}).get(slot) or '')
            if locked and current and (str(path) != current):
                return
        except Exception as exc:
            optional_failure('ui.grid_visual_lock_check', exc)
        self._grid_waiting.setdefault(path, set()).add((generation, slot))
        self._grid_slot_paths[slot] = path
        palette_path = getattr(self, '_grid_palette_sources', {}).get(slot) or path
        try:
            if hasattr(self, '_remember_grid_visual'):
                self._remember_grid_visual(slot, display=path, poster=palette_path, palette=palette_path)
        except Exception as exc:
            optional_failure('ui.grid_visual_ram_decode', exc)
        if getattr(self, 'media_type', None) in ('vod', 'series'):
            self._grid_schedule_adaptive_selector(generation, slot, palette_path)
        if slot == getattr(self, 'index', -1):
            self._grid_schedule_page_mood(palette_path)
        ptr = self._grid_cache_get(path)
        if ptr is not None:
            self._grid_set_ptr(slot, ptr)
            self._ui_diag_first_real_art(path, slot)
            try:
                if getattr(self, 'media_type', None) in ('vod', 'series') and hasattr(self, '_grid_is_m3u_source') and self._grid_is_m3u_source():
                    name = os.path.basename(str(path or '')).lower()
                    if not ('placeholder' in name or name.startswith(('poster_movie', 'poster_series'))):
                        self._grid_visual_locks.setdefault(slot, str(path))
            except Exception as exc:
                optional_failure('ui.grid_visual_lock_cached', exc)
            return
        active_path = self._grid_decode_active[1] if self._grid_decode_active else None
        if path not in self._grid_queued and path != active_path:
            if slot == getattr(self, 'index', -1):
                self._grid_decode_queue.insert(0, (generation, path))
            else:
                self._grid_decode_queue.append((generation, path))
            self._grid_queued.add(path)
            self._grid_start_decode()
        elif path in self._grid_queued and slot == getattr(self, 'index', -1):
            self._grid_decode_queue[:] = [(gen, value) for gen, value in self._grid_decode_queue if value != path]
            self._grid_decode_queue.insert(0, (generation, path))

    def _grid_schedule_adaptive_selector(self, generation, slot, path):
        if getattr(self, 'media_type', None) not in ('vod', 'series') or not path or (not os.path.isfile(path)):
            return
        if not _grid_adaptive_on():
            return
        selected_now = slot == getattr(self, 'index', -1)
        cached_card = None
        try:
            cached_card = _grid_card_chrome_cached(path, selected=False, geometry=getattr(self, 'card_chrome_geometry', None))
            if cached_card:
                if not hasattr(self, '_grid_card_paths'):
                    self._grid_card_paths = {}
                self._grid_card_paths[slot] = cached_card
                try:
                    if hasattr(self, '_remember_grid_visual'):
                        self._remember_grid_visual(slot, palette=path, card=cached_card)
                except Exception as exc:
                    optional_failure('ui.grid_cached_card_ram', exc)
                widget = self['card_chrome%d' % slot]
                if widget.instance is not None:
                    widget.instance.setPixmap(None)
                    widget.instance.setPixmapFromFile(cached_card)
                widget.show()
        except Exception as exc:
            optional_failure('ui.grid_cached_card_first_paint', exc)
        if cached_card:
            return
        token = (generation, slot, path, selected_now)
        if token in self._grid_accent_pending:
            return
        self._grid_accent_pending.add(token)
        geom = getattr(self, 'card_chrome_geometry', None)

        def worker():
            if self._grid_closed or generation != self._grid_generation:
                self._grid_accent_pending.discard(token)
                return
            card = cached_card or _grid_card_chrome_from_poster(path, selected=False, geometry=geom)
            result = ''
            try:
                self._grid_accent_jobs.put((generation, slot, path, result, card, None))
            except Exception as exc:
                optional_failure('ui.silent_guard', exc)
        try:
            _GRID_ACCENT_EXECUTOR.submit(worker, priority=0 if selected_now else 2)
        except Exception:
            self._grid_accent_pending.discard(token)

    def _grid_drain_adaptive_selector(self):
        changed = False
        while True:
            try:
                job = self._grid_accent_jobs.get_nowait()
                generation, slot, path, result = job[:4]
                card = job[4] if len(job) > 4 else None
                focus_card = job[5] if len(job) > 5 else None
            except queue.Empty:
                break
            try:
                self._grid_accent_pending.discard((generation, slot, path, False))
                self._grid_accent_pending.discard((generation, slot, path, True))
            except Exception as exc:
                optional_failure('ui.grid_accent_pending_cleanup', exc)
            if generation != self._grid_generation:
                continue
            if card and slot != getattr(self, 'index', -1) and ((getattr(self, '_grid_palette_sources', {}).get(slot) or self._grid_slot_paths.get(slot)) == path):
                try:
                    if not hasattr(self, '_grid_card_paths'):
                        self._grid_card_paths = {}
                    self._grid_card_paths[slot] = card
                    try:
                        if hasattr(self, '_remember_grid_visual'):
                            self._remember_grid_visual(slot, palette=path, card=card)
                    except Exception as exc:
                        optional_failure('ui.grid_visual_ram_card', exc)
                    name = 'card_chrome%d' % slot
                    widget = self[name]
                    if widget.instance is not None:
                        widget.instance.setPixmapFromFile(card)
                        widget.show()
                except Exception as exc:
                    optional_failure('ui.grid_adaptive_card_apply', exc)
            if result and slot == getattr(self, 'index', -1) and ((getattr(self, '_grid_palette_sources', {}).get(slot) or self._grid_slot_paths.get(slot)) == path):
                try:
                    if self['selection_adaptive'].instance is not None:
                        self['selection_adaptive'].instance.setPixmap(None)
                        self['selection_adaptive'].instance.setPixmapFromFile(result)
                    self._grid_selection_adaptive_visual_path = result
                    changed = True
                    self['selection_adaptive'].show()
                    self['selection'].show()
                    self._grid_focus_chrome_slot = slot
                except Exception as exc:
                    optional_failure('ui.grid_adaptive_selector_apply', exc)
        return changed

    def _grid_apply_current_selector(self, allow_build=False):
        if getattr(self, 'media_type', None) not in ('vod', 'series'):
            return
        slot = getattr(self, 'index', 0)
        path = getattr(self, '_grid_palette_sources', {}).get(slot) or self._grid_slot_paths.get(slot)
        try:
            stable = asset(getattr(self, 'selection_asset', 'poster_cursor_g1_252x434.png'))
            if getattr(self, '_grid_selection_visual_path', '') != stable:
                self['selection'].instance.setPixmapFromFile(stable)
                self._grid_selection_visual_path = stable
            self['selection'].show()
        except Exception as exc:
            optional_failure('ui.grid_selector_stable', exc)
        self._grid_show_static_bg()
        try:
            self['selection_adaptive'].hide()
        except Exception:
            pass

    def _grid_show_static_bg(self):
        """R5.190: Poster Grid / Grid 3 page background = the plugin's one bundled static
        background.  Painted once; no per-poster blur, no cache file, no repaint on navigation."""
        if getattr(self, 'media_type', None) not in ('vod', 'series'):
            return
        try:
            w = self['page_adaptive_bg']
            if w.instance is None:
                return
            if self.__class__.__name__ in ('PremiumPosterGridScreen', 'PremiumPosterGrid3Screen'):
                if getattr(self, '_grid_mood_source', '') != '__skin_z0__':
                    w.instance.setPixmap(None)
                    self._grid_mood_source = '__skin_z0__'
                w.hide()
                return
            bg = asset('ultra_bg_clean_1920x1080.png')
            if not os.path.isfile(bg):
                return
            if getattr(self, '_grid_mood_source', '') != bg:
                w.instance.setPixmap(None)
                w.instance.setPixmapFromFile(bg)
                self._grid_mood_source = bg
            w.show()
        except Exception as exc:
            optional_failure('ui.grid_static_bg', exc)

    def _grid_schedule_page_mood(self, path):
        self._grid_show_static_bg()

    def _grid_drain_page_mood(self):
        try:
            while True:
                self._grid_mood_jobs.get_nowait()
        except Exception:
            pass

    def _grid_download_future_done(self, future):
        try:
            lock = getattr(self, '_grid_download_lock', None)
            if lock is None:
                return
            with lock:
                futures = getattr(self, '_grid_download_futures', None)
                inflight = getattr(self, '_grid_download_inflight', None)
                key = futures.pop(future, None) if futures is not None else None
                if key is not None and inflight is not None and (future.cancelled() or future.exception() is not None):
                    inflight.pop(key, None)
        except Exception as exc:
            optional_failure('ui.silent_guard', exc)

    def _grid_cancel_queued_downloads(self):
        """Cancel old page downloads that have not started yet.

        Running downloads are allowed to finish into the HDD cache; generation
        guards prevent them from repainting the new page. This keeps the global
        executor queue bounded during rapid page flipping without corrupting
        shared URL waiters.
        """
        try:
            lock = getattr(self, '_grid_download_lock', None)
            futures = getattr(self, '_grid_download_futures', None)
            inflight = getattr(self, '_grid_download_inflight', None)
            if lock is None or futures is None:
                return
            with lock:
                pending = list(futures.items())
            for future, url in pending:
                try:
                    cancelled = future.cancel()
                except Exception:
                    cancelled = False
                if cancelled:
                    with lock:
                        futures.pop(future, None)
                        if inflight is not None:
                            inflight.pop(url, None)
        except Exception as exc:
            optional_failure('ui.grid_cancel_queued', exc)

    def _grid_poster_thumb_path(self, source_path):
        try:
            st = os.stat(source_path)
            if getattr(self, '_poster_small_fill', False):
                mode_tag = 'us-card-smallfill-hq-v2'
            else:
                mode_tag = 'us-card-cover-hq-v5' if getattr(self, '_poster_cover_mode', False) else 'us-card-fit-hq-v2'
            raw = '%s|%s|%s|%s|%sx%s|%s' % (source_path, getattr(st,'st_mtime_ns',st.st_mtime), int(st.st_size), getattr(st,'st_ino',0), int(self._grid_thumbnail_size()[0]), int(self._grid_thumbnail_size()[1]), mode_tag)
            digest = hashlib.sha1(raw.encode('utf-8', 'ignore')).hexdigest()
            return durable_view_path('gridposter_%s_%dx%d.png' % (digest, int(self._grid_thumbnail_size()[0]), int(self._grid_thumbnail_size()[1])), source=source_path)
        except Exception:
            return None

    def _grid_use_persistent_poster(self, generation, slot, source_path):
        """Use/build one sharp poster representation for every grid lifecycle.

        Canonical TMDB posters survive restarts, but us199 decoded the larger
        w500 JPEG again for all 12 cards every time a grid screen was reopened.
        The tiny persistent thumb makes cold/reopen grids cheap while keeping
        network resolution completely out of the hot path.
        """
        if getattr(self, 'media_type', None) in ('vod', 'series'):
            if not hasattr(self, '_grid_palette_sources'):
                self._grid_palette_sources = {}
            self._grid_palette_sources[slot] = source_path
        thumb = self._grid_poster_thumb_path(source_path)
        if thumb and _valid_cache_file(thumb, ttl=0):
            self._grid_queue_decode(generation, slot, thumb)
            return True
        if _PILImage is None or not thumb:
            self._grid_queue_decode(generation, slot, source_path)
            return True
        self._grid_queue_decode(generation, slot, source_path)
        token = (generation, slot, thumb)
        pending = getattr(self, '_grid_poster_thumb_pending', None)
        if pending is None:
            self._grid_poster_thumb_pending = set()
            pending = self._grid_poster_thumb_pending
        if token in pending:
            return True
        pending.add(token)

        def worker():
            out = None
            try:
                if self._grid_closed or generation != self._grid_generation:
                    return
                out = _build_cover_thumbnail(source_path, thumb, self._grid_thumbnail_size()) if getattr(self, '_poster_small_fill', False) or getattr(self, '_poster_cover_mode', False) else _build_thumbnail(source_path, thumb, self._grid_thumbnail_size())
            finally:
                try:
                    pending.discard(token)
                except Exception as exc:
                    optional_failure('ui.grid_pending_cleanup', exc)
        try:
            _POSTER_THUMB_EXECUTOR.submit(worker, priority=2)
        except Exception:
            pending.discard(token)
            self._grid_queue_decode(generation, slot, source_path)
        return True

    def _shared_tmdb_poster(self, item):
        """One already-downloaded poster for every portal copy of the same TMDB id."""
        if getattr(self, 'media_type', None) not in ('vod', 'series') or not isinstance(item, dict):
            return ''
        tid = item.get('_locked_tmdb_id') or item.get('_ultra_search_verified_tmdb_id') or item.get('tmdb_id') or item.get('tmdb')
        if not tid:
            try:
                tid = (getattr(self, '_grid_item_state', {}) or {}).get(id(item), {}).get('tmdb_id')
            except Exception:
                tid = ''
        if not tid:
            return ''
        try:
            from .artwork_v2 import canonical_art_paths
            mt = item.get('_locked_tmdb_type') or ('tv' if self.media_type == 'series' else 'movie')
            poster = str((canonical_art_paths(mt, tid) or {}).get('poster') or '')
            if poster and os.path.isfile(poster) and (os.path.getsize(poster) > 512):
                return poster
        except Exception:
            return ''
        return ''

    def _grid_request_art(self, slot, item, placeholder):
        generation = self._grid_generation
        if not getattr(self, '_grid_settings', {}).get('load_images', True):
            self._grid_set_local(slot, asset(placeholder))
            return None
        if getattr(self, 'media_type', None) in ('vod', 'series'):
            prepared_map = getattr(self, '_grid_prepared_art', {}) or {}
            prepared_seen = slot in prepared_map
            if prepared_seen:
                prepared = prepared_map.get(slot) or {}
                display = str(prepared.get('display') or '')
                poster = str(prepared.get('poster') or '')
                palette = str(prepared.get('palette') or '')
                card = self._grid_compatible_card(prepared.get('card'))
                if display and os.path.isfile(display):
                    if palette:
                        self._grid_palette_sources[slot] = palette
                    if prepared.get('visual_locked'):
                        self._grid_visual_locks[slot] = display
                    self._grid_queue_decode(generation, slot, display)
                    if card and os.path.isfile(card):
                        self._grid_card_paths[slot] = card
                        try:
                            self['card_chrome%d' % slot].instance.setPixmapFromFile(card)
                            self['card_chrome%d' % slot].show()
                        except Exception as exc:
                            optional_failure('ui.grid_prepared_card', exc)
                    return None
                if poster and os.path.isfile(poster):
                    if prepared.get('visual_locked'):
                        self._grid_visual_locks[slot] = poster
                    self._grid_use_persistent_poster(generation, slot, poster)
                    return None
                self._grid_set_local(slot, asset(placeholder))
            if not prepared_seen:
                try:
                    snap = load_shared_detail_snapshot(self.profile, self.media_type, item) if isinstance(item, dict) and item.get('_xtream') else load_detail_snapshot(self.profile, self.media_type, item)
                    bundle = _load_visual_bundle(self.profile, self.media_type, item, snap)
                    bundled = str((bundle or {}).get('grid_thumb') or (bundle or {}).get('poster') or '')
                    if bundled and os.path.isfile(bundled):
                        palette = str((bundle or {}).get('poster') or bundled)
                        if not hasattr(self, '_grid_palette_sources'):
                            self._grid_palette_sources = {}
                        self._grid_palette_sources[slot] = palette
                        self._grid_queue_decode(generation, slot, bundled)
                        card = self._grid_compatible_card((bundle or {}).get('grid_card'))
                        if card and os.path.isfile(card):
                            self._grid_card_paths[slot] = card
                            try:
                                self['card_chrome%d' % slot].instance.setPixmapFromFile(card)
                                self['card_chrome%d' % slot].show()
                            except Exception as exc:
                                optional_failure('ui.silent_guard', exc)
                        return None
                except Exception as exc:
                    optional_failure('ui.grid_visual_bundle', exc)
                try:
                    snap = load_artwork_v2_manifest(self.profile, self.media_type, item)
                    if (not isinstance(snap, dict) or not snap.get('poster_local')) and isinstance(item, dict) and item.get('_xtream'):
                        snap = load_shared_detail_snapshot(self.profile, self.media_type, item)
                    local = str((snap or {}).get('poster_local') or '')
                    if local and os.path.isfile(local) and (os.path.getsize(local) > 100):
                        self._grid_use_persistent_poster(generation, slot, local)
                        return None
                except Exception as exc:
                    optional_failure('ui.grid_hdd_poster_v2', exc)
            if slot not in getattr(self, '_grid_slot_paths', {}):
                self._grid_set_local(slot, asset(placeholder))
            shared = self._shared_tmdb_poster(item) if self.media_type in ('vod', 'series') else ''
            if shared:
                if not hasattr(self, '_grid_canonical_poster_slots'):
                    self._grid_canonical_poster_slots = {}
                self._grid_canonical_poster_slots[slot] = shared
                self._grid_use_persistent_poster(generation, slot, shared)
                return None
        if self.media_type in ('vod', 'series'):
            raw_art = None if item.get('_generic_provider_art') else item.get('_visible_provider_art_url') or _image_url(item)
            live_candidates = []
        else:
            live_candidates = _live_picon_candidates(item, self._grid_profile)
            raw_art = live_candidates[0] if live_candidates else _image_url(item)
        if self.media_type == 'itv':
            cached_live = _cached_live_picon_path(raw_art, self._grid_profile, item)
            if cached_live:
                if not hasattr(self, '_grid_live_picon_sources'):
                    self._grid_live_picon_sources = {}
                self._grid_live_picon_sources[slot] = (generation, cached_live)
                self._grid_slot_paths[slot] = cached_live
                self._grid_palette_sources[slot] = cached_live
                self._grid_set_local(slot, cached_live)
                return None
        if slot not in getattr(self, '_grid_slot_paths', {}):
            self._grid_set_local(slot, asset(placeholder))
        url = _optimized_artwork_url(self._grid_absolute_url(raw_art, item), False)
        live_urls = []
        if self.media_type == 'itv':
            for _raw_live in live_candidates or [raw_art]:
                try:
                    _resolved = _optimized_artwork_url(self._grid_absolute_url(_raw_live, item), False)
                except Exception:
                    _resolved = None
                if _resolved and _resolved not in live_urls:
                    live_urls.append(_resolved)
            if live_urls:
                url = live_urls[0]
            try:
                LOG.info('Live picon route channel=%r raw=%r resolved=%r candidates=%d', str((item or {}).get('name') or (item or {}).get('title') or ''), raw_art, url, len(live_urls))
            except Exception:
                pass
            if not url:
                try:
                    LOG.warning('Live picon TEMP portal has no URL channel=%r raw=%r', str((item or {}).get('name') or ''), raw_art)
                except Exception:
                    pass
                return None
            live_key = ('live-picons', tuple(live_urls or [url]), str(item.get('id') or item.get('ch_id') or item.get('stream_id') or id(item)))
            if generation != getattr(self, '_live_picon_retry_gen', None):
                self._live_picon_retry_gen = generation
                self._live_picon_retry_at = {}
            self._live_picon_retry_at[slot] = time.monotonic() + 30
            _dl_lock = getattr(self, '_grid_download_lock', None)
            _dl_inflight = getattr(self, '_grid_download_inflight', None)
            _dl_futures = getattr(self, '_grid_download_futures', None)
            _dl_jobs = getattr(self, '_grid_download_jobs', None)
            _dl_slots = getattr(self, '_grid_slots', None)
            _dl_profile = getattr(self, '_grid_profile', None)
            _dl_client = getattr(self, '_grid_client', None)
            if _dl_lock is None or _dl_inflight is None or _dl_slots is None:
                return None
            with _dl_lock:
                waiters = _dl_inflight.get(live_key)
                if waiters is not None:
                    waiters.add((generation, slot))
                    return None
                _dl_inflight[live_key] = set([(generation, slot)])

            def live_worker():
                acquired = False
                channel = str((item or {}).get('name') or '')
                _live_restart_trace('picon_worker_begin', channel=channel, slot=int(slot), generation=int(generation), url=url)
                try:
                    acquired = us_acquire(_dl_slots, 12)
                    if not acquired or getattr(self, '_grid_closed', True) or getattr(self, '_screen_closed', False) or (generation != getattr(self, '_grid_generation', -1)):
                        return
                    path = None
                    path = _download_live_portal_temp_picon(url, _dl_profile, _dl_client, item=item, timeout=2.5)
                    _live_restart_trace('picon_worker_result', channel=channel, slot=int(slot), generation=int(generation), ok=bool(path and os.path.isfile(path)), path=path or '')
                    if not path or not os.path.isfile(path):
                        _live_restart_trace('picon_worker_missing', channel=channel, slot=int(slot), generation=int(generation))
                        return
                    with _dl_lock:
                        completed = list(_dl_inflight.pop(live_key, set([(generation, slot)])))
                    if not getattr(self, '_grid_closed', True) and (not getattr(self, '_screen_closed', False)) and (_dl_jobs is not None):
                        for waiter_generation, waiter_slot in completed:
                            _dl_jobs.put((waiter_generation, waiter_slot, path))
                except Exception as exc:
                    _live_restart_trace('picon_worker_error', channel=channel, slot=int(slot), generation=int(generation), error=repr(exc))
                    try:
                        LOG.exception('Live picon TEMP portal worker failed channel=%r url=%r error=%s', channel, url, exc)
                    except Exception:
                        pass
                finally:
                    try:
                        with _dl_lock:
                            _dl_inflight.pop(live_key, None)
                    except Exception:
                        pass
                    if acquired:
                        try:
                            _dl_slots.release()
                        except Exception:
                            pass
                    _live_restart_trace('picon_worker_end', channel=channel, slot=int(slot), generation=int(generation))
            try:
                future = _LIVE_PICON_EXECUTOR.submit(live_worker, priority=0 if slot == getattr(self, 'index', 0) else 1)
                if _dl_futures is not None:
                    with _dl_lock:
                        _dl_futures[future] = live_key
                future.add_done_callback(self._grid_download_future_done)
            except Exception:
                with _dl_lock:
                    _dl_inflight.pop(live_key, None)
            return None
        if not url or not _artwork_attempt_allowed(url):
            if self.media_type == 'itv':
                try:
                    LOG.warning('Live picon unavailable/blocked channel=%r raw=%r resolved=%r', str((item or {}).get('name') or ''), raw_art, url)
                except Exception:
                    pass
            return None
        digest = hashlib.sha1(url.encode('utf-8', 'ignore')).hexdigest()
        thumb = _thumb_path(digest, self._grid_thumbnail_size())
        if _valid_cache_file(thumb):
            if self.media_type == 'itv':
                try:
                    LOG.info('Live picon cache hit channel=%r path=%s', str((item or {}).get('name') or ''), thumb)
                except Exception:
                    pass
            self._grid_queue_decode(generation, slot, thumb)
            return None
        original = _find_original_artwork(digest)
        if original:
            if self.media_type in ('vod', 'series'):
                self._grid_use_persistent_poster(generation, slot, original)
                return None
            self._grid_queue_decode(generation, slot, original)
            _queue_thumbnail_build(original, thumb, self._grid_thumbnail_size())
            return None
        _dl_lock = getattr(self, '_grid_download_lock', None)
        _dl_inflight = getattr(self, '_grid_download_inflight', None)
        _dl_futures = getattr(self, '_grid_download_futures', None)
        _dl_jobs = getattr(self, '_grid_download_jobs', None)
        _dl_slots = getattr(self, '_grid_slots', None)
        _dl_profile = getattr(self, '_grid_profile', None)
        _dl_client = getattr(self, '_grid_client', None)
        _dl_img_size = self._grid_thumbnail_size()
        _dl_media_type = getattr(self, 'media_type', None)
        if _dl_lock is None or _dl_inflight is None or _dl_slots is None:
            return None
        with _dl_lock:
            waiters = _dl_inflight.get(url)
            if waiters is not None:
                waiters.add((generation, slot))
                return None
            _dl_inflight[url] = set([(generation, slot)])

        def worker():
            temp = None
            acquired = False
            completed_waiters = None
            file_lock = None
            try:
                acquired = us_acquire(_dl_slots, 12)
                if not acquired or getattr(self, '_grid_closed', True) or getattr(self, '_screen_closed', False):
                    return
                file_lock = _artwork_file_lock(digest)
                file_lock.acquire()
                existing = _find_original_artwork(digest)
                if existing:
                    if _dl_media_type in ('vod', 'series') and (getattr(self, '_poster_cover_mode', False) or getattr(self, '_poster_small_fill', False)):
                        display_path = existing
                    else:
                        display_path = _build_thumbnail(existing, thumb, _dl_img_size) or existing
                    if _dl_media_type == 'itv':
                        try:
                            LOG.info('Live picon ready channel=%r path=%s', str((item or {}).get('name') or ''), display_path)
                        except Exception:
                            pass
                    with _dl_lock:
                        completed_waiters = list(_dl_inflight.pop(url, set([(generation, slot)])))
                    if not getattr(self, '_grid_closed', True) and (not getattr(self, '_screen_closed', False)) and (_dl_jobs is not None):
                        for waiter_generation, waiter_slot in completed_waiters:
                            _dl_jobs.put((waiter_generation, waiter_slot, display_path))
                    return
                if _dl_media_type == 'itv':
                    path = _download_portal_artwork(raw_art, _dl_profile, _dl_client, False, 5.5, item=item)
                    if not path or not os.path.isfile(path):
                        _record_artwork_failure(url)
                        return
                    display_path = _build_thumbnail(path, thumb, _dl_img_size) or path
                    _clear_artwork_failure(url)
                else:
                    path = _download_portal_artwork(raw_art, _dl_profile, _dl_client, False, 2.5, item=item)
                    if not path or not os.path.isfile(path):
                        _record_artwork_failure(url)
                        return
                    if _dl_media_type in ('vod', 'series') and (getattr(self, '_poster_cover_mode', False) or getattr(self, '_poster_small_fill', False)):
                        display_path = path
                    else:
                        display_path = _build_thumbnail(path, thumb, _dl_img_size) or path
                    _clear_artwork_failure(url)
                with _dl_lock:
                    completed_waiters = list(_dl_inflight.pop(url, set([(generation, slot)])))
                if not getattr(self, '_grid_closed', True) and (not getattr(self, '_screen_closed', False)) and (_dl_jobs is not None):
                    for waiter_generation, waiter_slot in completed_waiters:
                        _dl_jobs.put((waiter_generation, waiter_slot, display_path, 'provider' if _dl_media_type in ('vod', 'series') else 'plain'))
            except Exception as exc:
                if acquired:
                    _record_artwork_failure(url)
                if _dl_media_type == 'itv':
                    LOG.exception('Live picon download failed channel=%r raw=%r resolved=%r error=%s', str((item or {}).get('name') or ''), _image_url(item), url, exc)
                else:
                    LOG.exception('grid artwork download failed: %s', url)
            finally:
                try:
                    with _dl_lock:
                        _dl_inflight.pop(url, None)
                except Exception:
                    pass
                if file_lock is not None:
                    try:
                        file_lock.release()
                    except Exception as exc:
                        optional_failure('ui.grid_file_lock_release', exc)
                if acquired:
                    try:
                        _dl_slots.release()
                    except Exception as exc:
                        optional_failure('ui.grid_slot_release', exc)
                if temp:
                    try:
                        if _persistent_write_ok(temp):
                            os.unlink(temp)
                    except OSError:
                        pass
        try:
            executor = _VISIBLE_PROVIDER_POSTER_EXECUTOR if self.media_type in ('vod', 'series') else _IMAGE_EXECUTOR
            future = executor.submit(worker)
            with self._grid_download_lock:
                self._grid_download_futures[future] = url
            future.add_done_callback(self._grid_download_future_done)
        except Exception:
            with self._grid_download_lock:
                self._grid_download_inflight.pop(url, None)

    def _grid_retry_live_picons(self):
        """Recover missing visible logos without reloading the page or pressing a key."""
        if getattr(self, 'media_type', None) != 'itv' or getattr(self, '_screen_closed', False) or self._grid_closed or getattr(self, '_grid_images_suspended', False) or (not getattr(self, '_grid_settings', {}).get('load_images', True)):
            return
        now = time.monotonic()
        if now < getattr(self, '_live_picon_poll_at', 0):
            return
        self._live_picon_poll_at = now + 2
        generation = self._grid_generation
        from .live_picon_download import cached_file
        if generation != getattr(self, '_live_picon_retry_gen', None):
            self._live_picon_retry_gen = generation
            self._live_picon_retry_at = {}
        for slot, item in enumerate((getattr(self, 'grid_items', []) or [])[:self.page_size]):
            path = (getattr(self, '_grid_slot_paths', {}) or {}).get(slot)
            source = (getattr(self, '_grid_live_picon_sources', {}) or {}).get(slot)
            if source and source[0] == generation:
                path = source[1]
            if path and os.path.isfile(path) and ('placeholder' not in os.path.basename(path).lower()) and cached_file(path):
                continue
            if now < self._live_picon_retry_at.get(slot, 0):
                continue
            self._live_picon_retry_at[slot] = now + 30
            self._grid_request_art(slot, item, self.placeholder)

    def _grid_drain_art_jobs(self, limit=None):
        count = 0
        while True:
            if limit is not None and count >= max(1, int(limit)):
                break
            try:
                job = self._grid_download_jobs.get_nowait()
                generation, slot, path = (job[0], job[1], job[2])
                kind = job[3] if len(job) > 3 else 'plain'
            except queue.Empty:
                break
            if generation != self._grid_generation:
                continue
            if getattr(self, 'media_type', None) == 'itv' and kind != 'live_fit':
                if not hasattr(self, '_grid_live_picon_sources'):
                    self._grid_live_picon_sources = {}
                self._grid_live_picon_sources[slot] = (generation, path)
            if kind == 'provider' and getattr(self, 'media_type', None) in ('vod', 'series') and path and os.path.isfile(path):
                canonical = (getattr(self, '_grid_canonical_poster_slots', {}) or {}).get(slot)
                if canonical and os.path.isfile(str(canonical)):
                    count += 1
                    continue
                self._grid_palette_sources[slot] = path
                try:
                    self._remember_grid_visual(slot, poster=path, palette=path, provider_locked=True)
                except Exception:
                    pass
                if getattr(self, '_poster_cover_mode', False) or getattr(self, '_poster_small_fill', False):
                    self._grid_use_persistent_poster(generation, slot, path)
                else:
                    self._grid_queue_decode(generation, slot, path)
            else:
                self._grid_queue_decode(generation, slot, path)
            count += 1
        self._grid_start_decode()
        self._grid_retry_live_picons()

    def _grid_start_decode(self):
        if self._grid_closed or self._grid_decode_busy:
            return
        while self._grid_decode_queue:
            generation, path = self._grid_decode_queue.pop(0)
            self._grid_queued.discard(path)
            if generation != self._grid_generation:
                continue
            self._grid_decode_busy = True
            self._grid_decode_active = (generation, path)
            try:
                self._grid_decode_source_key = self._grid_cache_key(path)
                result = self._grid_picload.startDecode(path)
                if result not in (None, 0):
                    self._grid_decode_busy = False
                    self._grid_decode_active = None
                    continue
                return
            except Exception as _us_decode_error:
                self._grid_decode_busy = False
                self._grid_decode_active = None

    def _grid_picture_ready(self, *args):
        active = self._grid_decode_active
        try:
            if active:
                _generation, path = active
                ptr = self._grid_picload.getData()
                if ptr is not None and getattr(self,"_grid_decode_source_key",None) != self._grid_cache_key(path):
                    ptr=None
                    if not self._grid_closed and self._grid_waiting.get(path):
                        self._grid_decode_queue.insert(0,(self._grid_generation,path))
                        self._grid_queued.add(path)
                if ptr is not None:
                    self._grid_cache_put(path, ptr)
                    waiting = list(self._grid_waiting.pop(path, set()))
                    for item_generation, slot in waiting:
                        if item_generation == self._grid_generation:
                            self._grid_set_ptr(slot, ptr)
                            self._ui_diag_first_real_art(path, slot)
                            try:
                                if getattr(self, 'media_type', None) in ('vod', 'series') and hasattr(self, '_grid_is_m3u_source') and self._grid_is_m3u_source():
                                    name = os.path.basename(str(path or '')).lower()
                                    if not ('placeholder' in name or name.startswith(('poster_movie', 'poster_series'))):
                                        self._grid_visual_locks.setdefault(slot, str(path))
                            except Exception as exc:
                                optional_failure('ui.grid_visual_lock_set', exc)
        except Exception as exc:
            optional_failure('ui', exc)
        self._grid_decode_busy = False
        self._grid_decode_active = None
        self._grid_start_decode()

    def _grid_art_stop(self):
        self._grid_closed = True
        self._grid_generation += 1
        try:
            cancel = getattr(self, '_page_prefetch_cancel', None)
            if cancel is not None:
                cancel.set()
        except Exception as exc:
            optional_failure('ui.grid_prefetch_cancel_close', exc)
        self._grid_cancel_queued_downloads()
        self._grid_decode_queue = []
        self._grid_waiting = {}
        self._grid_queued = set()
        self._grid_slot_paths = {}
        self._grid_slot_identities = {}
        self._grid_accent_jobs = queue.Queue()
        self._grid_accent_pending = set()
        self._grid_poster_thumb_pending = set()
        with self._grid_download_lock:
            us_clear(self._grid_download_inflight)
        us_clear(self._grid_decode_cache)
        for _name in ('selection', 'page_adaptive_bg'):
            _release_pixmap_widget(self, _name)
        self._grid_mood_source = ''
        for _slot in range(int(getattr(self, 'page_size', 0) or 0)):
            _release_pixmap_widget(self, 'card_chrome%d' % _slot)
        for name in getattr(self, '_grid_slot_names', []):
            try:
                widget = self[name]
                if widget.instance is not None:
                    widget.instance.setPixmap(None)
                widget.hide()
            except Exception as exc:
                optional_failure('ui', exc)
        try:
            while True:
                self._grid_download_jobs.get_nowait()
        except queue.Empty:
            pass
        for queue_name in ('_grid_accent_jobs', '_grid_mood_jobs', '_art_prefetch_jobs', '_quality_prefetch_jobs', '_folder_artwork_progress', '_epg_jobs', '_live_chrome_jobs'):
            q = getattr(self, queue_name, None)
            if q is None:
                continue
            try:
                while True:
                    q.get_nowait()
            except queue.Empty:
                pass
            except Exception as exc:
                optional_failure('ui.grid_queue_drain', exc)
        try:
            if self._grid_pic_connection is not None:
                self._grid_pic_connection.disconnect()
        except Exception as exc:
            optional_failure('ui', exc)
        try:
            callbacks = self._grid_picload.PictureData.get() if self._grid_picload is not None and hasattr(self._grid_picload.PictureData, 'get') else ()
            if self._grid_picture_ready in callbacks:
                callbacks.remove(self._grid_picture_ready)
        except Exception as exc:
            optional_failure('ui.grid_picload_callback_remove', exc)
        try:
            self._grid_picload = None
        except Exception as exc:
            optional_failure('ui.silent_guard', exc)
        _native_image_pressure_relief(force=True)
