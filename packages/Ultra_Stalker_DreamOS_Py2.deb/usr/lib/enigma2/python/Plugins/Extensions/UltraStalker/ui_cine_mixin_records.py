# -*- coding: utf-8 -*-
"""Item titles, quality, record building and page indexing.

Methods moved verbatim out of ``PremiumGlobalCinematicScreen`` (ui_cinematic_global.py); behaviour is unchanged.
This module is imported by ui_cinematic_global.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, round, max, min, us_clear
from .ui_cinematic_global import (
    _catalogue_title,
    _cinematic_row_progress_cached,
    _cinematic_row_progress_frame,
    adaptive_enabled,
    load_detail_snapshot,
    load_detail_snapshot_by_tmdb,
    load_manifest,
    optional_failure,
    os,
)


class CineRecordsMixin(object):
    """Item titles, quality, record building and page indexing."""

    def _item_fallback_title(self,item):
        if not isinstance(item,dict):return ""
        clean=bool((self._grid_settings or {}).get("clean_titles",True))
        raw=item.get("_raw_name") or item.get("name") or item.get("title") or item.get("series_name") or ""
        return str(raw or "").strip()

    def _display_rail_title(self,value):
        raw=str(value or "").strip()
        if not raw:return ""
        return (_catalogue_title(raw) or raw) if bool((self._grid_settings or {}).get("clean_titles",True)) else raw

    def _rail_title(self,item,row=None):
        """Always show a clean catalogue title on the left rail, aligned left.

        The visible rail never prefers a localized title merely because TMDB returned
        one.  It first cleans the provider/catalogue name so routing prefixes, quality
        tags and decorative junk cannot leak into either display or identity matching.
        No network work is allowed here.
        """
        row=row if isinstance(row,dict) else {}
        provider=self._display_rail_title(self._item_fallback_title(item))
        original=self._display_rail_title(row.get("original_title") or "")
        saved=self._display_rail_title(row.get("title") or row.get("name") or "")
        return provider or original or saved

    def _quality(self,item):
        try:
            row=self._grid_item_state.get(id(item),{}) or {};q=str(row.get("quality") or "").strip()
            if q:return q
        except Exception:pass
        try:
            badges=str(quality_badges(self._item_fallback_title(item)) or "").strip()
            if badges:return badges.split(" • ")[0]
        except Exception:pass
        name=self._item_fallback_title(item).upper()
        if "4K" in name or "2160" in name:return "4K"
        if "FHD" in name or "1080" in name:return "FHD"
        if "HD" in name or "720" in name:return "HD"
        return "AUTO"

    def _record(self,item):
        """Return the same final HDD state used by Native Details.

        Cinematic never resolves metadata itself.  It merges the global artwork
        manifest with the Details pointer/global snapshot so outside and inside
        cannot disagree about overview, seasons or credits.  Both readers are
        HDD-only and ultimately point at the same TMDB library identity.
        """
        try:
            from .artwork_v2 import load_fast_local_poster
            from .persistent_cache import detail_snapshot_path
            art=load_fast_local_poster(self.profile,self.media_type,item) or {}
            detail={}
            if art.get("tmdb_id"):
                if art.get("_details_authority_ready"):
                    try:
                        from .shared_metadata import enrich_shared_metadata
                        detail=enrich_shared_metadata(art,self._grid_settings)
                    except Exception:
                        detail=dict(art)
                else:
                    detail=load_detail_snapshot_by_tmdb(art.get("media_type") or self.media_type,art.get("tmdb_id")) or {}
            else:
                dpath=detail_snapshot_path(self.profile,self.media_type,item)
                if dpath and os.path.isfile(dpath):
                    detail=load_detail_snapshot(self.profile,self.media_type,item) or {}
            # Native Details owns every information field once its verified raw
            # TMDb snapshot is ready.  Clear artwork/provider metadata first so a
            # field that TMDb genuinely lacks cannot resurrect from an older
            # manifest; Clean Names/title identity remains completely separate.
            row=dict(art)
            if detail.get("_details_authority_ready"):
                for _meta_key in ('overview','overview_language','description','plot','descr','genres','genre','cast','actors','actor','crew','directors','director','writers','writer','runtime','duration','time','length','number_of_seasons','seasons_count','season_count','number_of_episodes','episodes_count','episode_count','release_date','first_air_date','year','release_year','releaseDate','countries','country','country_code','production_country','production_countries','origin_country','rating','vote_count','original_language','certification','age_rating'):
                    row.pop(_meta_key,None)
            row.update(detail)
            for _visual_key in ("poster_local","backdrop_local","poster_url","backdrop_url",
                                "poster_source","backdrop_source","backdrop_state",
                                "clean_backdrop_selector_version","manual_rescue_poster_locked",
                                "manual_rescue_backdrop_locked","provider_bootstrap"):
                _visual_value=art.get(_visual_key)
                if _visual_value not in (None,"",[],{}):row[_visual_key]=_visual_value
            # Focused provider artwork is a verified local handoff, not a second
            # metadata authority. Keep it visible for this screen lifetime and
            # let Details/Player reuse the same exact HDD files.
            if isinstance(item,dict):
                pp=str(item.get("_cin_provider_poster_local") or item.get("_ultra_poster_source") or item.get("_player_poster") or "")
                pb=str(item.get("_cin_provider_backdrop_local") or item.get("_backdrop_source_local") or "")
                if pp and os.path.isfile(pp):row["poster_local"]=pp
                if pb and os.path.isfile(pb):row["backdrop_local"]=pb
            # Preserve the newest timestamp so the HDD poll notices metadata
            # completed by Native Details while Cinematic remains open.
            try:row["updated_at"]=max(int(detail.get("updated_at") or 0),int(art.get("updated_at") or 0))
            except Exception:pass
            return row
        except Exception as exc:
            optional_failure("cinematic.global_record",exc);return {}

    def _record_key(self,row,item):
        tid=row.get("tmdb_id") if isinstance(row,dict) else None
        if tid:return "%s-%s"%("tv" if self.media_type=="series" else "movie",tid)
        return self._page_visual_key(item)

    def _cin_list_row(self, pos, selected=False, record=None, allow_progress_build=True):
        item=self.grid_items[pos]
        record=record if isinstance(record,dict) else self._record(item)
        title=self._rail_title(item,record)
        # Cinematic rail deliberately reserves the entire second line for watched
        # progress. Quality/year already exist in the full Details cluster.
        # Keep the key-repeat path RAM-only: the old implementation recalculated
        # quality/year and re-probed/generated the laser PNG every time the
        # selected row changed, even though neither value is rendered here.
        value=""
        state=self._grid_item_state.get(id(item),{}) or {}
        progress_pct=0
        if self.media_type=="vod":
            try:
                play_pos=float(state.get("position") or 0);dur=float(state.get("duration") or 0)
                if int(state.get("completed") or 0):progress_pct=100
                elif play_pos>0 and dur>0:progress_pct=max(1,min(99,int(round((play_pos*100.0)/dur))))
            except Exception:progress_pct=0
        accent=str(getattr(self,"_cin_progress_accent","#75d2ab") or "#75d2ab")
        progress_neon=""
        if progress_pct>0:
            try:
                frame_cache=getattr(self,"_cin_progress_frame_ram",None)
                if not isinstance(frame_cache,dict):
                    frame_cache={};self._cin_progress_frame_ram=frame_cache
                # R5.178: the flat bar has no accent, so the key must not depend on
                # it; the old key changed with every selected title and made the
                # bar vanish/reappear while navigating.
                frame_key=("flat",int(progress_pct),300)
                progress_neon=str(frame_cache.get(frame_key) or "")
                if not progress_neon:
                    progress_neon=_cinematic_row_progress_cached(progress_pct) or ""
                if not progress_neon and allow_progress_build:
                    progress_neon=_cinematic_row_progress_frame(accent,progress_pct) or ""
                if progress_neon:frame_cache[frame_key]=progress_neon
            except Exception as exc:optional_failure("cinematic.row_progress_neon",exc)
        cache=getattr(self,"_cin_hot_row_cache",None)
        if not isinstance(cache,dict):
            cache={};self._cin_hot_row_cache=cache
        cache_key=(id(item),bool(selected),title,int(progress_pct),progress_neon,
                   str(self._settings_row_asset or ""),str(self._settings_row_selected_asset or ""))
        cached=cache.get(cache_key)
        if cached is not None:return cached
        meta={
            "selected":bool(selected),
            "value":value,
            "row_asset":self._settings_row_asset,
            "row_selected_asset":self._settings_row_selected_asset,
            # R5.232: fixed Premium Dark (OFF, or ON before first adaptive commit)
            # keeps the unified Poster ring. Once ON has a real per-title row pair,
            # expose the original adaptive selected-row material instead.
            "edge_cursor":not (adaptive_enabled() and bool(getattr(self,"_cin_adaptive_rows_active",False))),
            "value_color":0xFFFFFF,
            "watch_progress":progress_pct,
            "watch_progress_neon":progress_neon,
            "watch_progress_full_line":True,
            # text-only polish on the stable row renderer.
            # Remove the catalogue icon so names start from the left edge,
            # and enable adaptive title sizing without touching row assets.
            "hide_icon":True,
            "adaptive_title":True,
            "compact_row":True,
        }
        row=(title,self._cin_list_icon,item,meta);cache[cache_key]=row;return row

    def _cin_index_current_page(self):
        """Build the page-local index from async-prepared RAM rows.

        Normal page loads arrive with ``_cin_index_ready`` rows produced by
        ``_prepare_grid_page`` off the GUI thread.  The fallback path exists only
        for legacy/injected payloads and preserves previous behaviour.
        """
        self._cin_hot_row_cache={}
        us_clear(self._cin_row_complete);self._cin_page_records={};self._cin_page_packages={};self._cin_page_backdrops={}
        prepared=(getattr(self,"_prepared_art_for_render",[]) or [])
        for pos in range(min(self.page_size,len(self.grid_items))):
            item=self.grid_items[pos]
            ram=prepared[pos] if pos<len(prepared) and isinstance(prepared[pos],dict) else {}
            if ram.get("_cin_index_ready"):
                record=ram.get("cin_record") if isinstance(ram.get("cin_record"),dict) else {}
                package=ram.get("cin_package") if isinstance(ram.get("cin_package"),dict) else {}
                self._cin_page_records[pos]=record
                if package:self._cin_page_packages[pos]=package
                bd=str(ram.get("cin_backdrop") or ram.get("backdrop") or "")
                if bd:self._cin_page_backdrops[pos]=bd
                continue
            # Rare compatibility fallback for an old/prepared payload that did
            # not carry the R99 background index.
            try:
                ram_bd=str(ram.get("backdrop") or "")
                if ram_bd:self._cin_page_backdrops[pos]=ram_bd
            except Exception:pass
            try:
                alias={} if pos in self._cin_page_backdrops else (self._cin_load_nav_alias(item) or {});abd=str(alias.get("backdrop") or "")
                if abd and os.path.isfile(abd):self._cin_page_backdrops[pos]=abd
                elif pos not in self._cin_page_backdrops:
                    blue=self._cin_read_blue_lock(item) or {};blue_bd=str(blue.get("backdrop_fast") or "")
                    if blue_bd and os.path.isfile(blue_bd) and os.path.getsize(blue_bd)>4096:self._cin_page_backdrops[pos]=blue_bd
            except Exception as exc:optional_failure("cinematic.page_nav_alias_fallback",exc)
            try:self._cin_page_records[pos]=self._record(item) or {}
            except Exception:self._cin_page_records[pos]={}
            try:
                pkg=self._cin_load_canonical_package_fast(item,self._cin_page_records.get(pos,{}) or {}) or {}
                if pkg:
                    self._cin_page_packages[pos]=pkg
                    bd=str(pkg.get("backdrop_fast") or pkg.get("backdrop") or "")
                    if bd and os.path.isfile(bd):self._cin_page_backdrops[pos]=bd
            except Exception as exc:optional_failure("cinematic.page_backdrop_index_fallback",exc)
