# -*- coding: utf-8 -*-
"""OK handling, backup menu/restore, notices, edit callbacks and colour/number keys.

Methods moved verbatim out of ``PortalManagerPremiumScreen`` (ui_screens_portallist.py); behaviour is unchanged.
This module is imported by ui_screens_portallist.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, min
from .ui_screens_portallist import (
    _,
    os,
)


class PortalManagerKeysMixin(object):
    """OK handling, backup menu/restore, notices, edit callbacks and colour/number keys."""

    def _backup_menu(self):
        self._context_open_choice(self._backup_restore_selected,_('Backup & Restore'),[(_("Create portable backup"),"backup_all"),(_("Restore backup"),"restore")],0,_('Works on DreamOS and Open images'))

    def _backup_restore_selected(self,choice):
        if not choice:return
        action=choice[1]
        if action=="backup_all":
            self._create_backup_inline();return
        backups=list_backups()
        if not backups:
            self._context_open_notice(_('Backup & Restore'),_('No backups found on HDD.\n\nExpected folder: /media/hdd/UltraStalker/Backup/'));return
        rows=[]
        for path in backups:
            try:
                manifest=inspect_backup(path);kind='FULL' if manifest.get('contains_secrets') else 'LEGACY'
                label=os.path.basename(path)+'  •  '+str(manifest.get('plugin_version') or 'unknown')+'  •  '+kind
            except Exception:label=os.path.basename(path)+'  •  INVALID'
            rows.append((label,path))
        self._context_open_choice(self._restore_backup_selected,_('Choose backup to restore'),rows,0,_('Select a saved Ultra Stalker backup'))

    def _restore_backup_selected(self,choice):
        if not choice:return
        path=choice[1]
        try:inspect_backup(path)
        except Exception as exc:
            self._context_open_notice(_('Invalid Backup'),_('Invalid backup: %s')%exc);return
        self._restore_path=path
        self._context_open_choice(self._restore_backup_confirmed,_('Restore backup'),[(_('Yes'),True),(_('No'),False)],1,_('Restore this backup completely? The selected backup will be restored directly. No additional backup copy will be created.'),show_text=True)

    def _restore_backup_confirmed(self,choice):
        if not choice or not bool(choice[1]) or self._backup_busy:return
        path=self._restore_path
        self._backup_busy=True
        self["status"].setText(_("Validating and restoring backup…"))
        def work(handle):return restore_backup(path,restore_secrets=True,cancel_event=handle.cancel_event)
        def done(result):
            self._backup_busy=False
            try:self.parent._sync_profiles_from_disk();self.parent.refresh()
            except Exception as exc:optional_failure("ui.portal_restore_refresh",exc)
            self["status"].setText("")
            message=_("Restore complete. Restart Enigma2/plugin before continuing.\n\nRestored: %s")%(', '.join(result.get('restored',[])))
            if result.get("adjusted_settings"):message+="\n\n"+_("Playback engine was adjusted to match this receiver.")
            self._context_open_notice(_("Restore Complete"),message)
        def failed(exc):
            self._backup_busy=False;self["status"].setText("")
            self._context_open_notice(_("Restore Failed"),_("Restore failed: %s")%exc)
        self._run_async(work,done,failed)

    def _create_backup_inline(self):
        if self._backup_busy:return
        self._backup_busy=True
        self["status"].setText(_("Creating complete HDD backup…"))
        def done(result):
            self._backup_busy=False;self["status"].setText("")
            self._context_open_notice(_("Backup Created"),_("Complete backup created on HDD:\n%s\n\nPortals, settings and user API credentials are included. Artwork cache is not copied.")%str(result.get("path") or ""))
        def failed(exc):
            self._backup_busy=False;self["status"].setText("")
            self._context_open_notice(_("Backup Failed"),_("Backup failed: %s")%exc)
        self._run_async(lambda:create_backup(),done,failed)

    def _context_open_notice(self,title,message):
        try:
            from .ui import _ensure_settings_screens
            _ensure_settings_screens()
        except Exception:
            pass
        from .ui_screens_settings import _settings_notice_pages
        self._context_hide_widgets()
        self._context_active=True;self._context_mode="notice";self._context_callback=None;self._context_choices=[]
        self._notice_title=str(title or "Information")
        self._notice_pages=_settings_notice_pages(str(message or ""),20,488,6)
        self._notice_page=0
        self._context_geom("context_panel",1352,812,560,260)
        self._context_geom("context_title",1388,828,488,40)
        self._context_geom("context_message",1388,880,488,174)
        self["context_panel"].instance.setPixmapFromFile(asset("settings_clean_r5390/panel_560x260.png"))
        self._context_notice_page(0)
        for name in ("context_panel","context_title","context_message"):self[name].show()

    def _context_notice_page(self,step):
        try:
            from .ui import _ensure_settings_screens
            _ensure_settings_screens()
        except Exception:
            pass
        from .ui_screens_settings import _settings_notice_title
        pages=self._notice_pages
        self._notice_page=(self._notice_page+int(step))%len(pages)
        self["context_title"].setText(_settings_notice_title(self._notice_title,self._notice_page,len(pages)))
        self["context_message"].setText(pages[self._notice_page])

    def _enable_disabled_selected(self,choice):
        if choice:
            current=self._safe_index()
            self.parent._disabled_portal_selected(choice)
            self._last_summary=_("Portal enabled")
            self._render_actions(current)

    def _device_profile_selected(self,choice):
        if choice:self.parent._portal_device_selected(choice);self._last_summary=_("Portal updated");self._update_status()

    def _rename_finished(self,value):
        self.parent._portal_renamed(value);self._last_summary=_("Portal renamed") if value is not None else '';self._update_status()

    def _edit_url_finished(self,value):
        self.parent._portal_edit_url(value);self._update_status()

    def _duplicate_finished(self,value):
        self.parent._portal_duplicate_mac(value);self._last_summary=_("Portal duplicated") if value else '';self._update_status()

    def _purge_selected(self,choice):
        if choice and bool(choice[1]):self.parent._purge_profile_confirmed(True);self._last_summary=_("Portal data cleared; portal profile kept");self._update_status()

    def _render_multi_row(self, idx):
        if not (0 <= idx < len(self._multi_profiles)):
            return
        profile = self._multi_profiles[idx]; picked = idx in self._multi_selected
        is_m3u = str(profile.get("source_type") or "").lower() == "m3u"
        value = (((_("SELECTED") + " • ") if picked else "") + str(profile.get("mac") or "M3U"))[:32]
        meta = {"level":"groups", "count":value, "selected": idx == self._safe_index(), "value": value, "row_asset": self._row_asset, "row_selected_asset": self._row_selected_asset, "value_color": self._value_color, "utility_accent_strong": True}
        icon_rel = "settings_icons_40/multi_search.png" if picked else ("settings_icons_40/web_access.png" if not is_m3u else "settings_icons_40/channel_list.png")
        self["list"].update_icon_row(idx, (self._portal_name(profile, idx), self._settings_icon(icon_rel), profile, meta))

    def _menu(self):
        if self._context_active:
            return
        # Move portals is now a single flow: select targets, then MENU starts
        # placement directly instead of bouncing back through a second row.
        if self._mode == "multi":
            if not self._multi_selected:
                self._last_summary = _("Select portals first, then MENU → Move")
                self._update_status()
                return
            targets = [self._multi_profiles[i] for i in sorted(self._multi_selected) if 0 <= i < len(self._multi_profiles)]
            if not targets:
                self._last_summary = _("No selected portals are available to move")
                self._update_status()
                return
            try:
                self.parent._begin_bulk_move(targets)
            except Exception as exc:
                optional_failure("ui.portal_manager_begin_bulk_move", exc)
                self._last_summary = _("No selected portals are available to move")
                self._update_status()
                return
            self.close(None)
            return
        self._cancel()

    def _local_m3u_ok(self):
        entries = list(getattr(self, "_local_m3u_entries", []) or [])
        idx = self._safe_index()
        if not (0 <= idx < len(entries)):
            return
        kind, target, _title, _sub, _icon = entries[idx]
        if kind == "scan":
            self._render_local_m3u_scan_results(0)
            return
        if kind == "up_roots":
            self._render_local_m3u_roots(0)
            return
        if kind == "root":
            self._local_m3u_root_dir = target
            self._render_local_m3u_dir(target, 0)
            return
        if kind == "dir":
            self._render_local_m3u_dir(target, 0)
            return
        if kind == "up":
            if target is None:
                self._render_local_m3u_roots(0)
            else:
                self._render_local_m3u_dir(target, 0)
            return
        if kind == "file" and target:
            try:
                imported = import_local_m3u_file(target)
                if hasattr(self.parent, "_switch_to_category"):
                    self.parent._switch_to_category("m3u", focus_profile=imported, enter_grid=True)
                else:
                    self.parent.profiles = load_profiles()
                    self.parent.refresh()
                self.close(None)
                show_notice(self.session, _("Local M3U playlist added: %s") % str(imported.get("name") or ""), timeout=5, owner=self.parent)
            except Exception as exc:
                self._context_open_notice(_("Import Failed"), _("Could not import local M3U file:\n%s") % exc)
            return

    def _cancel(self):
        if self._context_active:
            self._context_close(None,True);return
        if self._mode == "local_m3u":
            cur_dir = getattr(self, "_local_m3u_current_dir", None)
            root_dir = getattr(self, "_local_m3u_root_dir", None)
            if cur_dir is not None:
                if cur_dir == "__scan__" or cur_dir == "/" or (root_dir and os.path.normpath(cur_dir) == os.path.normpath(root_dir)):
                    self._render_local_m3u_roots(0)
                else:
                    self._render_local_m3u_dir(os.path.dirname(cur_dir) or "/", 0)
                return
            imp_idx = next((i for i, row in enumerate(self._visible_actions) if len(row) > 1 and row[1] == "import_local_m3u"), 0)
            self._render_actions(imp_idx)
            return
        if self._mode == "multi":
            self._multi_selected = set()
            move_idx=next((i for i,row in enumerate(self._visible_actions) if len(row)>1 and row[1]=="move_portals"),0)
            self._render_actions(move_idx); return
        self.close(None)

    def _yellow(self):
        if self._context_active:
            return
        if self._mode == "multi":
            self._multi_selected = set(range(len(self._multi_profiles))); self._render_multi(self._safe_index())

    def _red(self):
        if self._context_active:
            self._context_close(None,True);return
        if self._mode == "multi":
            self._multi_selected = set(); self._render_multi(self._safe_index())
        elif self._mode == "actions":
            self.close(None)

    def _green(self):
        if self._context_active:
            self._context_accept();return
        if self._mode in ("multi", "local_m3u"):
            self._ok()

    def _number(self, digit):
        if self._context_active:
            return
        if self._mode != "actions":
            return
        # Preserve the old ChoiceBox shortcut contract: 1..9 select rows 1..9,
        # 0 selects row 10.  Actions beyond ten remain available by scrolling.
        idx = 9 if int(digit) == 0 else int(digit) - 1
        if 0 <= idx < min(10, len(self._visible_actions)):
            try: self["list"].moveToIndex(idx)
            except Exception as exc: optional_failure("ui.portal_manager_number", exc)
            self._ok()
