# -*- coding: utf-8 -*-
"""Movies / Series category page: cache-only poster preview (R5.66).

Everything here runs on a worker thread and reads ONLY data that already
exists on this receiver: the portal page cache (RAM / SQLite), the Xtream
per-category cache, artwork manifests and poster files on disk.  Nothing in
this module opens a socket, calls the portal or downloads artwork.

build_preview() returns a small dict; the fan of up to five posters is
composited here (PIL, worker thread) into ONE ready PNG that the GUI just
binds to a single Pixmap widget.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str, int, open, zip, max, OSError

hashlib = _us_env.hashlib
json = _us_env.json
os = _us_env.os
threading = _us_env.threading
time = _us_env.time

from .log import optional_failure

try:
    from PIL import Image as _Img, ImageDraw as _Draw, ImageFilter as _Filt, ImageOps as _Ops
except Exception:  # pragma: no cover - Pillow is a hard dependency elsewhere
    _Img = _Draw = _Filt = _Ops = None

FAN_W, FAN_H = 720, 392
# (dx from centre, top y, width, height, dim) - drawn outer -> inner
_SLOTS = {
    "outer_l": (-250, 52, 190, 280, 0.46),
    "outer_r": (250, 52, 190, 280, 0.46),
    "mid_l": (-125, 34, 210, 310, 0.30),
    "mid_r": (125, 34, 210, 310, 0.30),
    "centre": (0, 22, 240, 350, 0.0),
}
# which slots a poster count fills (centre always present)
_LAYOUT = {
    1: ("centre",),
    2: ("mid_r", "centre"),
    3: ("mid_l", "mid_r", "centre"),
    4: ("outer_r", "mid_l", "mid_r", "centre"),
    5: ("outer_l", "outer_r", "mid_l", "mid_r", "centre"),
}
_ORDER = ("outer_l", "outer_r", "mid_l", "mid_r", "centre")
_CHIP_TAGS = ()
_LOCK = threading.Lock()
_NET_TRIED = set()  # categories already fetched once this session (no retry storms)


def _ui():
    from . import ui as _u
    return _u


def preview_key(profile, media, gid):
    p = profile or {}
    raw = "|".join((str(p.get("portal") or "").rstrip("/").lower(), str(p.get("mac") or "").upper(), str(media or ""), str(gid or "")))
    return hashlib.sha1(raw.encode("utf-8", "ignore")).hexdigest()[:20]


def category_id(entry):
    g = entry if isinstance(entry, dict) else {}
    return str(g.get("id") or g.get("genre_id") or g.get("category_id") or g.get("name") or g.get("title") or "*")


def entry_count(entry):
    """Item count ONLY if the category record itself carries one."""
    if not isinstance(entry, dict):
        return None
    for key in ("count", "items_count", "item_count", "total_items", "total", "num_items", "titles_count", "movies_count", "series_count"):
        value = entry.get(key)
        if value in (None, "", False):
            continue
        try:
            n = int(float(str(value).replace(",", "").strip()))
        except (TypeError, ValueError):
            continue
        if n >= 0:
            return n
    return None


# ---------------------------------------------------------------- cache reads
def _stalker_params(media, gid, compat):
    params = {"type": media, "action": "get_ordered_list", "p": 1, "JsHttpRequest": "1-xml"}
    if media == "vod":
        params["category"] = gid
    else:
        params.update({"movie_id": "0", "season_id": "0", "episode_id": "0", "category": gid})
    if compat:
        params["sortby"] = "number"
    return params


def _cached_rows(client, media, gid):
    """Return (rows, total, saved_epoch) from caches only, or (None, 0, 0)."""
    # Xtream / M3U adapter
    reader = getattr(client, "_read_xtream_category_cache", None)
    if callable(reader):
        try:
            if str(getattr(client, "_mode", "") or "") == "xtream":
                cid = client._xtream_category_id(media, gid)
                if gid not in (None, "", "*") and not cid:
                    return None, 0, 0
                shared = getattr(client, "_read_xtream_category_cache_shared", None)
                rows = (shared or reader)(media, cid or "*")
                if isinstance(rows, list) and rows:
                    saved = 0
                    try:
                        saved = os.path.getmtime(client._xtream_category_cache_path(media, cid or "*"))
                    except Exception:
                        saved = 0
                    return list(r for r in rows if isinstance(r, dict)), len(rows), saved
                return None, 0, 0
            if getattr(client, "_loaded", False):
                items = list((getattr(client, "_items", {}) or {}).get(media, []) or [])
                if gid not in ("*", "", None):
                    items = [x for x in items if str(x.get("category_id") or x.get("category") or "") == str(gid)]
                if items:
                    return list(r for r in items[:40] if isinstance(r, dict)), len(items), 0
        except Exception as exc:
            optional_failure("ui.category_pv_adapter", exc)
        return None, 0, 0
    # Stalker portal client: the exact params ordered_page() caches under
    getter = getattr(client, "_cache_get", None)
    keyer = getattr(client, "_cache_key", None)
    if not (callable(getter) and callable(keyer)):
        return None, 0, 0
    for compat in (False, True):
        try:
            params = _stalker_params(media, gid, compat)
            value = getter(params)
            if value is None:
                continue
            js = client._unwrap(value)
            rows = list(r for r in client._as_list(js) if isinstance(r, dict) and r)
            if not rows:
                continue
            meta = js if isinstance(js, dict) else {}
            try:
                total = int(meta.get("total_items") or meta.get("total") or 0)
            except (TypeError, ValueError):
                total = 0
            saved = 0
            try:
                from .repositories.database import DB
                from .core.cache import CachePolicy
                entry = DB.cache_get_entry(keyer(params))
                if entry is not None and entry[1] is not None:
                    saved = time.time() - max(0, CachePolicy.ttl("get_ordered_list", 90) - int(entry[1]))
            except Exception:
                saved = 0
            return rows, total, saved
        except Exception as exc:
            optional_failure("ui.category_pv_page_cache", exc)
    return None, 0, 0


def _abs_url(value, profile):
    text = str(value or "").strip()
    if not text:
        return ""
    if text.startswith(("http://", "https://")):
        return text
    urllib = _us_env.urllib
    portal = str((profile or {}).get("portal") or "")
    if text.startswith("//"):
        return (urllib.parse.urlsplit(portal or "http://").scheme or "http") + ":" + text
    return urllib.parse.urljoin(portal.rstrip("/") + "/", text.lstrip("/"))


def _valid(path):
    try:
        return bool(path and os.path.isfile(str(path)) and os.path.getsize(str(path)) > 100)
    except Exception:
        return False


def _poster_paths(rows, profile, media, adapter, limit=5, is_current=None, allow_network=False):
    """Local poster files for these rows; downloads only when ``allow_network``."""
    u = _ui()
    isolated = None
    placeholder = "us81_placeholder_movies_480x345.png"
    ph_path = ""
    try:
        ph_path = u.asset(placeholder)
    except Exception:
        pass
    out = []
    for item in [dict(r) if isinstance(r, dict) else r for r in rows[:14]]:
        if len(out) >= limit:
            break
        if is_current is not None and not is_current():
            return out
        path = ""
        try:
            got = u._home_cached_art(item, profile, (230, 345), placeholder, media)
            if got and got != ph_path and _valid(got):
                path = got
        except Exception as exc:
            optional_failure("ui.category_pv_cached_art", exc)
        if not path and (adapter or item.get("_xtream")):
            try:
                raw = u._image_url(item)
                url = u._optimized_artwork_url(_abs_url(raw, profile), False) if raw else ""
                if url:
                    got = u._find_original_artwork(hashlib.sha1(url.encode("utf-8", "ignore")).hexdigest())
                    if got and _valid(got):
                        path = got
            except Exception as exc:
                optional_failure("ui.category_pv_provider_art", exc)
        if not path and allow_network:
            # Category was never opened on this receiver: fetch just the few
            # posters the fan needs (bounded, one isolated client, short timeout).
            try:
                raw = u._image_url(item)
                if raw:
                    if isolated is None:
                        isolated = u._new_isolated_source_client(profile, timeout=6)
                    got = u._download_portal_artwork(raw, profile, isolated, False, 5.0, None, item=item)
                    if got and _valid(got):
                        path = got
            except Exception as exc:
                optional_failure("ui.category_pv_download_art", exc)
        if path and path not in out:
            out.append(path)
    if isolated is not None:
        try:
            isolated.close()
        except Exception:
            pass
    return out


def _chips(rows):
    try:
        from .ultra import quality_badges
    except Exception:
        return {}
    counts = {}
    for item in rows:
        try:
            tags = quality_badges(item.get("name") or item.get("title") or item.get("o_name") or "")
        except Exception:
            continue
        for tag in str(tags).split(" • "):
            if tag in _CHIP_TAGS:
                counts[tag] = counts.get(tag, 0) + 1
                break  # one tier per title
    return {k: counts[k] for k in _CHIP_TAGS if counts.get(k)}


# ---------------------------------------------------------------- persisted record
def _gen_dir():
    return str(_ui().PERSISTENT_GENERATED_DIR)


def _record_path(key):
    return os.path.join(_gen_dir(), "cat_pv_%s.json" % key)


def _load_record(key):
    try:
        path = _record_path(key)
        if not os.path.isfile(path):
            return None
        with open(path, "r", encoding="utf-8") as fh:
            data = json.load(fh)
        if not isinstance(data, dict) or int(data.get("v") or 0) != 1:
            return None
        posters = [p for p in (data.get("posters") or []) if _valid(p)]
        data["posters"] = posters
        return data
    except Exception:
        return None


def _save_record(key, record):
    u = _ui()
    path = _record_path(key)
    temp = path + ".tmp.%d.%d" % (os.getpid(), threading.get_ident())
    try:
        if not u.hdd_ready() or not u.ensure_persistent_dirs(os.path.dirname(path)):
            return False
        if not u._persistent_write_ok(temp):
            return False
        u._persistent_write_require(temp)
        with open(temp, "w", encoding="utf-8") as fh:
            json.dump(record, fh, ensure_ascii=False, separators=(",", ":"))
        if not u._persistent_write_ok(path):
            raise OSError("write gate closed")
        os.replace(temp, path)
        return True
    except Exception as exc:
        optional_failure("ui.category_pv_record_save", exc)
        try:
            if os.path.exists(temp):
                os.unlink(temp)
        except OSError:
            pass
        return False


# ---------------------------------------------------------------- fan compositing
def _cover(path, w, h):
    with _Img.open(path) as im:
        try:
            im.draft("RGB", (w * 2, h * 2))
        except Exception:
            pass
        im = im.convert("RGB")
        resample = getattr(getattr(_Img, "Resampling", _Img), "LANCZOS", 1)
        return _Ops.fit(im, (w, h), resample, 0, (0.5, 0.35))


def _poster_tile(path, w, h, dim):
    tile = _cover(path, w, h).convert("RGBA")
    shade = _Img.new("RGBA", (w, 80), (0, 0, 0, 0))
    sd = _Draw.Draw(shade)
    for yy in range(80):
        sd.line([(0, yy), (w, yy)], fill=(0, 0, 0, int(190 * yy / 80)))
    tile.alpha_composite(shade, (0, h - 80))
    if dim > 0:
        tile.alpha_composite(_Img.new("RGBA", (w, h), (0, 0, 0, int(255 * dim))))
    mask = _Img.new("L", (w * 3, h * 3), 0)
    _Draw.Draw(mask).rounded_rectangle([0, 0, w * 3 - 1, h * 3 - 1], radius=14 * 3, fill=255)
    tile.putalpha(mask.resize((w, h), getattr(getattr(_Img, "Resampling", _Img), "BOX", 4)))
    return tile


def _shadow(canvas, rects):
    layer = _Img.new("RGBA", canvas.size, (0, 0, 0, 0))
    d = _Draw.Draw(layer)
    for x, y, w, h in rects:
        d.rounded_rectangle([x, y + 14, x + w, y + h + 14], radius=16, fill=(0, 0, 0, 150))
    canvas.alpha_composite(layer.filter(_Filt.GaussianBlur(12)))


def compose_fan(paths):
    """One ready 840x392 PNG for these poster files (cached by content key)."""
    if _Img is None or not paths:
        return ""
    u = _ui()
    paths = list(paths)[:5]
    sig = hashlib.sha1()
    for p in paths:
        try:
            st = os.stat(p)
            sig.update(("%s|%d|%d;" % (p, int(st.st_mtime), int(st.st_size))).encode("utf-8", "ignore"))
        except OSError:
            return ""
    sig.update(b"cat-fan-v2-720")
    out = os.path.join(_gen_dir(), "cat_fan_%s.png" % sig.hexdigest()[:24])
    if _valid(out):
        return out
    temp = out + ".tmp.%d.%d" % (os.getpid(), threading.get_ident())
    try:
        if not u.hdd_ready() or not u.ensure_persistent_dirs(os.path.dirname(out)):
            return ""
        if not u._persistent_write_ok(temp):
            return ""
        slots = _LAYOUT[len(paths)]
        placed = []
        for slot, path in zip(slots, paths):
            dx, y, w, h, dim = _SLOTS[slot]
            placed.append((slot, path, FAN_W // 2 + dx - w // 2, y, w, h, dim))
        placed.sort(key=lambda t: _ORDER.index(t[0]))
        canvas = _Img.new("RGBA", (FAN_W, FAN_H), (0, 0, 0, 0))
        back = list(t for t in placed if t[0] != "centre")
        if back:
            _shadow(canvas, list((t[2], t[3], t[4], t[5]) for t in back))
            for _slot, path, x, y, w, h, dim in back:
                canvas.alpha_composite(_poster_tile(path, w, h, dim), (x, y))
        front = list(t for t in placed if t[0] == "centre")
        if front:
            _slot, path, x, y, w, h, dim = front[0]
            _shadow(canvas, [(x, y, w, h)])
            canvas.alpha_composite(_poster_tile(path, w, h, 0.0), (x, y))
            frame = u.asset("cat_fan_frame_256x366.png")
            if _valid(frame):
                with _Img.open(frame) as fr:
                    canvas.alpha_composite(fr.convert("RGBA"), (x - 8, y - 8))
        u._persistent_write_require(temp)
        canvas.save(temp, "PNG", optimize=False)
        if not u._persistent_write_ok(out):
            raise OSError("write gate closed")
        os.replace(temp, out)
        return out if _valid(out) else ""
    except Exception as exc:
        optional_failure("ui.category_pv_fan", exc)
        try:
            if os.path.exists(temp):
                os.unlink(temp)
        except OSError:
            pass
        return ""


# ---------------------------------------------------------------- entry point
def build_preview(client, profile, media, entry, is_current=None):
    """Preview for one category: caches first, one bounded fetch if never opened."""
    gid = category_id(entry)
    key = preview_key(profile, media, gid)
    result = {"key": key, "total": None, "chips": {}, "saved": 0, "fan": "", "posters": 0, "cached": False}
    adapter = callable(getattr(client, "_read_xtream_category_cache", None))
    rows, total, saved = _cached_rows(client, media, gid)
    if is_current is not None and not is_current():
        return None
    fetched = False
    if not rows and not _load_record(key) and str(gid) not in ("*", "", "None") and key not in _NET_TRIED:
        # Never opened on this receiver: fetch page 1 once (this also warms the
        # page cache, so opening the category afterwards is instant).
        _NET_TRIED.add(key)
        try:
            page = client.ordered_page(media, gid, 1)
            got = [r for r in (page.get("items") or []) if isinstance(r, dict)] if isinstance(page, dict) else []
            if got:
                rows = got
                try:
                    total = int(page.get("total") or len(got))
                except (TypeError, ValueError):
                    total = len(got)
                saved = time.time()
                fetched = True
        except Exception as exc:
            optional_failure("ui.category_pv_fetch", exc)
        if is_current is not None and not is_current():
            return None
    posters = []
    if rows:
        result["cached"] = True
        result["total"] = total if total > 0 else None
        result["chips"] = _chips(rows)
        result["saved"] = saved or 0
        posters = _poster_paths(rows, profile, media, adapter, 5, is_current, allow_network=True)
        if is_current is not None and not is_current():
            return None
        _save_record(key, {"v": 1, "saved": int(saved or time.time()), "total": result["total"], "chips": result["chips"], "posters": posters})
    else:
        record = _load_record(key)
        if record:
            result["cached"] = True
            result["total"] = record.get("total")
            result["chips"] = record.get("chips") or {}
            result["saved"] = record.get("saved") or 0
            posters = list(record.get("posters") or [])[:5]
    if posters:
        result["posters"] = len(posters)
        result["fan"] = compose_fan(posters)
    return result
