# -*- coding: utf-8 -*-
"""Exact-TMDb and provider trailer helpers for Ultra Stalker."""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, max, min
import re

_YT_ID_RE = re.compile(r"^[A-Za-z0-9_-]{11}$")
_YT_URL_RE = re.compile(
    r"(?:youtube(?:-nocookie)?\.com/(?:watch\?(?:[^#&\s]*&)*v=|embed/|v/|shorts/)|youtu\.be/)([A-Za-z0-9_-]{11})",
    re.I,
)


def extract_youtube_key(value):
    """Extract an 11-character YouTube video ID from a key or URL string."""
    raw = str(value or "").strip()
    if not raw:
        return ""
    if _YT_ID_RE.match(raw):
        return raw
    match = _YT_URL_RE.search(raw)
    if match:
        return str(match.group(1)).strip()
    return ""


def youtube_watch_url(video_key):
    key = extract_youtube_key(video_key) or str(video_key or "").strip()
    return ("https://www.youtube.com/watch?v=" + key) if key else ""


def trailer_from_rows(*rows):
    """Return the first cached or provider trailer descriptor from metadata rows."""
    for row in rows:
        if not isinstance(row, dict):
            continue
        key = extract_youtube_key(row.get("trailer_key"))
        site = str(row.get("trailer_site") or "").strip().lower()
        if key and site in ("youtube", ""):
            return {
                "site": "YouTube",
                "key": key,
                "name": str(row.get("trailer_name") or "Trailer").strip() or "Trailer",
                "url": str(row.get("trailer_url") or youtube_watch_url(key)).strip(),
                "official": bool(row.get("trailer_official")),
                "language": str(row.get("trailer_language") or "").strip(),
            }
    for row in rows:
        if not isinstance(row, dict):
            continue
        for field in ("youtube_trailer", "trailer", "trailer_url", "trailer_id", "youtube_id"):
            key = extract_youtube_key(row.get(field))
            if key:
                return {
                    "site": "YouTube",
                    "key": key,
                    "name": str(row.get("trailer_name") or "Trailer").strip() or "Trailer",
                    "url": youtube_watch_url(key),
                    "official": bool(row.get("trailer_official", True)),
                    "language": str(row.get("trailer_language") or "").strip(),
                    "from_provider": True,
                }
    return {}


def fast_resolve_tmdb_id(credential, media, item, language="ar-EG", timeout=4, cancel_event=None):
    """Fast lightweight TMDb ID lookup (~250ms) without blocking on heavy artwork/identity locks."""
    if not isinstance(item, dict):
        return None
    for key in ("_locked_tmdb_id", "_ultra_search_verified_tmdb_id", "tmdb_id", "tmdbid", "tmdb", "id_tmdb"):
        val = item.get(key)
        if val not in (None, ""):
            sval = str(val).strip()
            if sval.isdigit() and int(sval) > 0:
                return int(sval)
    cred = str(credential or "").strip()
    if not cred:
        return None
    if cancel_event is not None and cancel_event.is_set():
        return None

    queries = []
    try:
        from .title_clean import clean_title, tmdb_search_title
    except Exception:
        clean_title = None
        tmdb_search_title = None

    for field in ("o_name", "original_title", "original_name", "name", "title", "movie_name", "series_name"):
        raw = str(item.get(field) or "").strip()
        if not raw:
            continue
        for fn in (tmdb_search_title, clean_title):
            if callable(fn):
                try:
                    cleaned = str(fn(raw) or "").strip()
                    if cleaned and cleaned not in queries:
                        queries.append(cleaned)
                except Exception:
                    pass
        simple = re.sub(r"[\[(]\s*(?:19|20)\d{2}\s*[\])]", " ", raw)
        simple = re.sub(r"\s+", " ", simple).strip(" -_|:")
        if simple and simple not in queries:
            queries.append(simple)

    if not queries:
        return None

    year_val = None
    for yfield in ("year", "release_year", "releaseDate", "release_date", "first_air_date", "name", "title"):
        yraw = str(item.get(yfield) or "")
        ym = re.search(r"\b((?:19|20)\d{2})\b", yraw)
        if ym:
            try:
                year_val = int(ym.group(1))
                break
            except Exception:
                pass

    try:
        from .tmdb import TMDBClient
        from .tmdb_impl import _identity_match_evidence
        client = TMDBClient(cred, language or "ar-EG", max(3, min(5, int(timeout or 4))))
    except Exception:
        return None

    endpoint = "/search/tv" if media == "tv" else "/search/movie"
    year_param = "first_air_date_year" if media == "tv" else "primary_release_year"

    for q in queries[:2]:
        if cancel_event is not None and cancel_event.is_set():
            return None
        search_Attempts = [{"query": q, "language": language or "ar-EG"}]
        if year_val:
            with_year = dict(search_Attempts[0])
            with_year[year_param] = str(year_val)
            search_Attempts = [with_year, search_Attempts[0]]
        for params in search_Attempts:
            if cancel_event is not None and cancel_event.is_set():
                return None
            try:
                res = client._get(endpoint, params) or {}
                rows = res.get("results") if isinstance(res, dict) else None
                if not isinstance(rows, list):
                    continue
                for row in rows:
                    if not isinstance(row, dict):
                        continue
                    evidence = _identity_match_evidence(q, row, media, wanted_year=year_val, aliases=queries)
                    tid = str(row.get("id") or "").strip()
                    if evidence.get("trusted") and tid.isdigit() and int(tid) > 0:
                        return int(tid)
            except Exception:
                continue
    return None


def resolve_youtube_trailer_candidates(video_key, timeout=8, cancel_event=None):
    """Return ordered playable URLs for an exact YouTube key."""
    key = extract_youtube_key(video_key) or str(video_key or "").strip()
    if not key:
        return []
    if cancel_event is not None:
        try:
            if cancel_event.is_set():
                return []
        except Exception:
            pass
    try:
        from .services.ultrastalker_youtube import UltraYouTubeResolver
        urls = UltraYouTubeResolver().extract_candidates(
            key, timeout=max(4, min(8, int(timeout or 8))), cancel_event=cancel_event
        ) or []
    except Exception:
        urls = []
    if cancel_event is not None:
        try:
            if cancel_event.is_set():
                return []
        except Exception:
            pass
    return [str(u).strip() for u in urls if str(u or "").strip().startswith(("http://", "https://"))]


def _resolve_with_ultrastalker(video_key, timeout=8, cancel_event=None):
    urls = resolve_youtube_trailer_candidates(video_key, timeout=timeout, cancel_event=cancel_event)
    return urls[0] if urls else ""


def resolve_youtube_trailer(video_key, timeout=8, cancel_event=None):
    """Resolve an exact TMDb YouTube key to an Enigma2-playable media URL."""
    return _resolve_with_ultrastalker(video_key, timeout=timeout, cancel_event=cancel_event)
