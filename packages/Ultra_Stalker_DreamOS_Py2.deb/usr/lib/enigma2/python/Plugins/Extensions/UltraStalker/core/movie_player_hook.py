"""Compatibility entry point; bouquet exports are owned by UltraStalkerPlayer.

The bouquet proxy binds the receiver session and dispatches exported movies and
episodes itself. Installing a navigation hook here duplicates that player and
can break receiver startup callbacks.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
_HOOK = None


def start_movie_player_hook(session):
    return None
