# -*- coding: utf-8 -*-
"""Search history menu.

Methods moved verbatim out of ``PortalGlobalSearchScreen`` (ui_screens_search.py); behaviour is unchanged.
This module is imported by ui_screens_search.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, round, max, min


class SearchHistoryMixin(object):
    """Search history menu."""

    def _stop_history_open_timer(self):
        try:self._history_open_timer.stop()
        except Exception:pass
        try:
            if self._history_open_timer_conn is not None:
                self._history_open_timer_conn.disconnect()
        except Exception:pass
        try:
            if self._history_open_deferred in self._history_open_timer.callback:
                self._history_open_timer.callback.remove(self._history_open_deferred)
        except Exception:pass
        self._history_pending = None

    def _history_hide(self):
        self._history_visible = False
        self._history_pending = None
        try:self._history_open_timer.stop()
        except Exception:pass
        try:
            if getattr(self, "_history_overlay", None) is not None:
                self._history_overlay.hide()
        except Exception:
            pass

    def _history_closed(self):
        self._history_visible = False

    def _history_status_left(self):
        """Anchor History 15px after the *rendered* green status text.

        The old probe label slightly overestimated the on-screen text width on
        receiver builds, leaving a visibly large empty gap.  Prefer the real
        skinned label instance so the overlay follows the actual Sources text,
        while the existing 654 bottom anchor keeps the exact 10px poster gap.
        """
        try:
            text = str(self["search_status"].getText() or "")
        except Exception:
            try:text = str(getattr(self["search_status"], "text", "") or "")
            except Exception:text = ""
        width = 0
        try:
            from .wqhd_layout import design_pixels as _wqhd_design_px
            inst = self["search_status"].instance
            if inst is not None:
                size = inst.calculateSize()
                width = int(round(_wqhd_design_px(int(size.width()))))
        except Exception:
            width = 0
        if width <= 0:
            try:
                # The detached eLabel probe is consistently wider than the real
                # skinned label on FHD receivers; compensate only in fallback.
                width = int(round(float(self._history_overlay._measure(text, 18)) * 0.78))
            except Exception:
                width = int(len(text) * 8)
        # search_status begins at x=560.  Keep a deliberate 15px visual gap
        # before Recent searches, without changing its vertical/poster spacing.
        return max(720, min(1280, 560 + max(0, width) + 15))

    def _history_selected(self, choice):
        self._history_visible = False
        term = ""
        try:
            if isinstance(choice, (tuple, list)) and len(choice) > 1:
                term = str(choice[1] or "").strip()
            else:
                term = str(choice or "").strip()
        except Exception:
            term = ""
        if term:
            self._search(term)

    def _history_open_deferred(self):
        pending=self._history_pending
        self._history_pending=None
        if not pending or getattr(self,"_screen_closed",False):return
        overlay=getattr(self,"_history_overlay",None)
        if overlay is None:return
        choices,selected=pending
        try:
            shown=overlay.show(
                choices, selection=selected, left_x=max(960,self._history_status_left()), anchor_bottom=654,
                on_accept=self._history_selected, on_close=self._history_closed,
                min_card_w=240, max_card_w=520, padding=56,
                visual_style="home_utility", row_h=76, max_visible=5,
            )
            self._history_visible=bool(shown)
        except Exception:
            self._history_visible=False

    def _toggle_history(self):
        overlay = getattr(self, "_history_overlay", None)
        if overlay is None:
            return
        if self._history_visible or getattr(overlay, "active", False):
            try:overlay.close()
            except Exception:self._history_hide()
            return
        if self._history_pending is not None:
            self._history_pending=None
            try:self._history_open_timer.stop()
            except Exception:pass
            return
        try:terms=[str(x).strip() for x in (_load_recent_searches() or []) if str(x or "").strip()]
        except Exception:terms=[]
        if not terms:return
        self._history_terms=terms[:100]
        try:selected=self._history_terms.index(self.query) if self.query in self._history_terms else 0
        except Exception:selected=0
        self._history_pending=([(term,term) for term in self._history_terms],selected)
        # MENU is both the opener and an overlay-owned close key. Deferring one
        # event-loop turn prevents a single physical press from being consumed
        # twice by receiver images that re-evaluate ActionMaps mid-dispatch.
        try:self._history_open_timer.start(1,True)
        except Exception:self._history_open_deferred()

    def _history_move(self,delta):
        if not self._history_visible:return False
        try:return bool(self._history_overlay.move("up" if int(delta)<0 else "down"))
        except Exception:return False

    def _history_pick(self):
        if not self._history_visible:return False
        try:return bool(self._history_overlay.accept())
        except Exception:
            self._history_hide();return True
