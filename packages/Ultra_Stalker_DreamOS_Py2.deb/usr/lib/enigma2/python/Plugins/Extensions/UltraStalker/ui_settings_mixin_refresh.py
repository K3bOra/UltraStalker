# -*- coding: utf-8 -*-
"""Content refresh, cache clearing and confirmations.

Methods moved verbatim out of ``NovaSettingsScreen`` (ui_screens_settings.py); behaviour is unchanged.
This module is imported by ui_screens_settings.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int, max, min
from .ui_screens_settings import (
    _shutil,
    content_refresh_failure,
    content_refresh_feedback,
    description_language_name,
    language_name,
)


class SettingsRefreshMixin(object):
    """Content refresh, cache clearing and confirmations."""

    def _refresh_current_content(self):
        """Refresh only the selected source's catalogue/index data."""
        self["status"].setText(_("Refreshing current source content…"))
        profile=dict(self.profile or {})
        client=self.client
        def work(handle):
            method=getattr(client,"refresh_content",None)
            if not callable(method):
                raise RuntimeError(_("This source does not support content refresh."))
            result=method(cancel_event=handle.cancel_event)
            if handle.cancelled():
                raise RuntimeError(_("Content refresh cancelled"))
            try:
                _invalidate_source_navigation_cache(profile)
            except Exception as exc:
                optional_failure("ui.content_refresh_navigation_cache",exc)
            return result or {}
        def done(result):
            message=content_refresh_feedback(result, _)
            self.refresh()
            self["status"].setText(message)
            self._context_open_notice(_("Refresh Content"),message)
        def failed(exc):
            message=content_refresh_failure(exc, _)
            self["status"].setText(message)
            self._context_open_notice(_("Refresh Content"),message)
        self._run_async(work,done,failed)

    @staticmethod
    def _engine_label(value):
        from . import us_env as _us_env
        names={1:"DVB / Native",4097:"DreamOS GStreamer" if _us_env.IS_DREAMOS else "GStreamer",5001:"GstPlayer",5002:"ExtePlayer3",8193:"DreamOS Player" if _us_env.IS_DREAMOS else "ServiceApp"}
        try:v=int(value or 4097)
        except Exception:v=4097
        return "%s (%d)"%(names.get(v,"Custom"),v)

    def refresh(self):
        cfg = load_settings()

        # Settings is now a compact ten-section navigator.  Everyday users see
        # the ten clear groups first; pressing OK swaps this same left rail to
        # the group's options.  No extra Screen is created and the adaptive
        # background/materials stay resident.
        sections = [
            ("playback", _("Playback"), _("Playback engine, resume and watch-progress behaviour."), "settings_icons_40/playback.png"),
            ("live", _("Live & EPG"), _("Live list, preview, EPG and catch-up controls."), "settings_icons_40/epg.png"),
            ("media", _("Movies & Series"), _("Views, artwork and catalogue presentation."), "settings_icons_40/artwork.png"),
            ("search", _("Search & Metadata"), _("Search scope, TMDB and external artwork/subtitle sources."), "settings_icons_40/multi_search.png"),
            ("language_metadata", _("Language & Metadata"), _("Interface language and movie/series description language."), "settings_icons_40/language.png"),
            ("parental", _("Parental Control"), _("PIN, sensitive categories and temporary unlock."), "settings_icons_40/parental.png"),
            ("appearance", _("Appearance"), _("Font size and main-menu entry."), "settings_icons_40/theme.png"),
            ("storage", _("Storage & Maintenance"), _("Refresh, caches, artwork storage and backups."), "settings_icons_40/cache.png"),
            ("portal", _("Portal / Network / Advanced"), _("Portal timeout, proxy and low-frequency tuning."), "settings_icons_40/advanced.png"),
            ("tools", _("Tools & About"), _("Diagnostics, cleaner, updates and build information."), "settings_icons_40/diagnostics.png"),
        ]

        by_section = {
            "playback": [
                (_("Playback Engine"), "service", self._engine_label(cfg.get("service_type",4097)), _("Choose the Enigma2 playback service used for streams.")),
                (_("Smart Recovery"), "smart_recovery", _("ON") if cfg.get("smart_recovery",True) else _("OFF"), _("Reconnect with a fresh provider link when playback fails, using the selected engine.")),
                (_("Recovery Attempts"), "playback_retry_limit", str(cfg.get("playback_retry_limit",3)), _("Maximum automatic recovery attempts. Zero disables retries. The default is three.")),
                (_("Resume Behavior"), "resume_behavior", _({"ask":"ASK","always":"ALWAYS","start":"FROM START"}.get(str(cfg.get("resume_behavior","ask")),"ASK")), _("Ask, always resume, or always start from the beginning.")),
                (_("Crash-Safe Progress"), "crash_safe_progress", _("ON") if cfg.get("crash_safe_progress",True) else _("OFF"), _("Save VOD/episode progress frequently and on pause/engine changes.")),
                (_("Remember Audio & Subtitle Language"), "remember_track_language", _("ON") if cfg.get("remember_track_language",True) else _("OFF"), _("Reuse the audio and subtitle language you chose for a movie or series, once at the start.")),
                (_("Progress Save Interval"), "progress_save_seconds", _("%ss")%cfg.get("progress_save_seconds",10), _("Crash-safe bookmark interval for movies and episodes.")),
                (_("Next Episode Countdown"), "next_episode_countdown", _("%ss")%cfg.get("next_episode_countdown",10), _("Choose the cancelable autoplay countdown after an episode ends.")),
                (_("Auto Remove Completed"), "auto_remove_completed", _("ON") if cfg.get("auto_remove_completed",True) else _("OFF"), _("Automatically remove titles from Continue Watching after the completion threshold.")),
                (_("Completion Threshold"), "completion_threshold", _("%s%%")%cfg.get("completion_threshold",93), _("Percentage at which a title is considered completed and removed from Continue Watching.")),
                (_("Completion Remaining Time"), "completion_remaining_seconds", _("%ss")%cfg.get("completion_remaining_seconds",180), _("Also mark a title completed when this little time remains.")),
            ],
            "live": [
                (_("Live Channel Keys"), "live_zap_direction", _("Left / Right") if cfg.get("live_zap_direction")=="left_right" else _("Up / Down (default)"), _("Choose the arrows used to change channels during full-screen Live TV.")),
                (_("EPG Window"), "epg", _("%sh") % cfg.get("epg_hours",4), _("How much EPG data to request for live channels.")),
                (_("EPG Refresh Budget"), "epg_refresh_budget", _("%ss") % cfg.get("epg_refresh_budget",45), _("Maximum background XMLTV refresh time budget.")),
            ],
            "media": [
                (_("Poster Loading"), "images", _("ON") if cfg.get("load_images",True) else _("OFF"), _("Enable or disable remote poster and logo artwork.")),
                (_("Movies View"), "movies_view_mode", _("CINEMATIC") if cfg.get("movies_view_mode","cinematic")=="cinematic" else (_("BACKDROP GRID 2") if cfg.get("movies_view_mode","cinematic")=="backdrop2" else (_("BACKDROP GRID") if cfg.get("movies_view_mode","cinematic")=="backdrop" else (_("POSTER GRID") if cfg.get("movies_view_mode","cinematic")=="poster_legacy" else (_("POSTER GRID 3") if cfg.get("movies_view_mode","cinematic")=="poster3" else _("POSTER GRID V2"))))), _("Choose Poster Grid, Cinematic, Backdrop Grid, or Backdrop Grid 2 for Movies.")),
                (_("Series View"), "series_view_mode", _("CINEMATIC") if cfg.get("series_view_mode","cinematic")=="cinematic" else (_("BACKDROP GRID 2") if cfg.get("series_view_mode","cinematic")=="backdrop2" else (_("BACKDROP GRID") if cfg.get("series_view_mode","cinematic")=="backdrop" else (_("POSTER GRID") if cfg.get("series_view_mode","cinematic")=="poster_legacy" else (_("POSTER GRID 3") if cfg.get("series_view_mode","cinematic")=="poster3" else _("POSTER GRID V2"))))), _("Choose Poster Grid, Cinematic, Backdrop Grid, or Backdrop Grid 2 for Series.")),
                (_("Live TV View"), "live_view_mode", {"classic":_("CLASSIC LIST"),"wall":_("LOGO WALL")}.get(str(cfg.get("live_view_mode","columns")),_("3 COLUMNS")), _("Choose the 3-column Live screen (categories, channels with NOW, preview and schedule), the logo wall (24 channel cards, OK opens full screen) or the classic list.")),
                (_("Player View"), "player_view_mode", {"new":"PLAYER NEW","new2":"PLAYER NEW 2"}.get(str(cfg.get("player_view_mode","old")).lower(),"PLAYER OLD"), _("Player Old keeps the classic Player. Player New shows one info bar for Live, Movies and Series. Player New 2 uses floating panels with a key dock. Used the next time the Player opens.")),
                (_("Info Bar Timeout"), "infobar_timeout", (_("Always On") if int(cfg.get("infobar_timeout",10) or 0)==0 else _("%ss") % cfg.get("infobar_timeout",10)), _("How long the Player info bar stays on screen before it hides. Always On keeps it until you press OK. Applies to Live, Movies and Series. Used the next time the Player opens.")),
                (_("Watched Badges"), "show_watched", _("ON") if cfg.get("show_watched",True) else _("OFF"), _("Show WATCHED state on movie and series cards.")),
                (_("Clean Display Names"), "clean_titles", _("ON") if cfg.get("clean_titles",True) else _("OFF"), _("ON shows the cleaned Ultra Stalker names across Movies, Series, Live and Player screens. OFF shows the provider names as received; TMDB matching and artwork lookup stay unchanged.")),
                (_("Category Preview Posters"), "category_preview_posters", _("ON") if cfg.get("category_preview_posters",True) else _("OFF"), _("Show a poster fan for the focused category in Movies and Series category lists.")),
                (_("Quality Badges"), "quality_badges", _("ON") if cfg.get("show_quality_badges",True) else _("OFF"), _("Show 4K/HD and similar quality metadata when detected.")),
                (_("Adaptive Colors"), "adaptive_colors", _("ON") if cfg.get("adaptive_colors",False) else _("OFF"), _("ON enables poster-adaptive branding in Cinematic, Backdrop Grids and the Player. OFF keeps the fixed Ultra Stalker branding there; the Details, Seasons and Episodes HUD colours remain poster-adaptive by design. Re-open a screen to apply.")),
                (_("Preload Current Artwork"), "global_artwork_preload", self._global_artwork_value(), _("Prepare Movies/Series artwork for the current Portal/Xtream source; shared HDD-ready items are skipped.")),
            ],
            "search": [
                (_("Multi-Portal Search"), "multi_portal_search", _("ON") if cfg.get("multi_portal_search",True) else _("OFF"), _("Global Search checks every enabled portal, not only the current one.")),
                (_("Search Limit / Portal"), "content_page_size", str(cfg.get("content_page_size",50)), _("Maximum Global Search results returned from each portal.")),
                (_("Search Scan Pages"), "search_max_pages", str(cfg.get("search_max_pages",250)), _("Maximum catalogue pages scanned when native portal search is unavailable.")),
                (_("Search Time Budget"), "search_time_budget", _("%ss") % cfg.get("search_time_budget",12), _("Maximum time spent searching one portal before partial results are returned.")),
                (_("TMDB Metadata"), "tmdb_enabled", _("ON") if cfg.get("tmdb_enabled",True) else _("OFF"), _("Use TMDB to enrich movie/series metadata and artwork.")),
                (_("TMDB API Key / Token"), "tmdb_credential", (_("BUILT-IN") if cfg.get("tmdb_credential_source")=="builtin" else (_("FILE ••••") if cfg.get("tmdb_credential") else _("NOT SET"))), _("Stored privately in api_keys.conf; never copied into settings.json.")),
                (_("TMDB Connection Test"), "tmdb_test", _("TEST"), _("Validate the saved TMDB credential against the official API.")),
                (_("Fanart.tv API Key"), "fanart_api_key", (_("FILE ••••") if cfg.get("fanart_api_key") else _("NOT SET")), _("Optional second-source artwork fallback used only when TMDB leaves a poster or backdrop missing.")),
                (_("Online Subtitles • SubDL"), "subdl_api_key", (_("BUILT-IN") if cfg.get("subdl_api_key_source")=="builtin" else (_("FILE ••••") if cfg.get("subdl_api_key") else _("NOT SET"))), _("SubDL API key for online movie and episode subtitles.")),
                (_("Online Subtitles • SubSource"), "subsource_api_key", (_("BUILT-IN") if cfg.get("subsource_api_key_source")=="builtin" else (_("FILE ••••") if cfg.get("subsource_api_key") else _("NOT SET"))), _("SubSource API key for online movie and episode subtitles.")),
            ],
            "language_metadata": [
                (_("Interface Language"), "plugin_language", language_name(cfg.get("plugin_language","en")), _("Choose the language used by Ultra Stalker menus and controls. Portal, M3U and Xtream content is never translated.")),
                (_("TMDb Information Language"), "description_language", _(description_language_name(cfg.get("description_language","ar-en"))), _("Choose movie and series TMDb information language independently from the interface. Missing fields fall back to English; Clean Names is separate.")),
            ],
            "parental": [
                (_("Parental Lock"), "parental", _("ON") if cfg.get("parental_lock",False) else _("OFF"), _("Protect configured/adult content categories.")),
                (_("Parental Mode"), "parental_mode", _("PIN") if cfg.get("parental_mode","pin")=="pin" else _("HIDE"), _("PIN-protect sensitive categories or hide them completely.")),
                (_("Parental Unlock"), "parental_session", _("%d min") % cfg.get("parental_session_minutes",30), _("Keep a correct PIN unlocked for this session duration.")),
                (_("Parental PIN"), "pin", _("CHANGE"), _("Set a 4–8 digit parental-control PIN.")),
                (_("Adult Keywords"), "adult_keywords", _("%d words") % len(cfg.get("adult_keywords",[])), _("Comma-separated words used to detect sensitive categories.")),
                (_("Hide Adult Categories"), "hide_adult", _("ON") if cfg.get("hide_adult",True) else _("OFF"), _("Hide categories matching adult keywords when Parental Lock is disabled.")),
                (_("Lock Parental Session"), "parental_lock_now", (_("UNLOCKED %d min")%parental_remaining_minutes()) if parental_is_unlocked() else _("LOCKED"), _("Immediately clear the temporary parental unlock.")),
            ],
            "appearance": [
                (_("Font Size"), "font_scale", _({"normal":"Normal","large":"Large","larger":"Larger","xlarge":"Extra Large"}.get(str(cfg.get("font_scale","normal")),"Normal")), _("Choose the text size used across Ultra Stalker. Restart Enigma2 to apply it everywhere.")),
                ((_("Movies") + "/" + _("Series") + " • " + _("Font Size")), "overview_font_scale", _({"normal":"Normal","large":"Large","larger":"Larger","xlarge":"Extra Large"}.get(str(cfg.get("overview_font_scale","normal")),"Normal")), (_("Information") + " • " + _("Font Size"))),
                (_("Show in Main Menu"), "show_main_menu", _("ON") if cfg.get("show_main_menu",True) else _("OFF"), _("Show Ultra Stalker directly in the Enigma2 Main Menu.")),
            ],
            "storage": [
                (_("Refresh Content"), "refresh_content", _("REFRESH"), _("Reload fresh Portal, Xtream or M3U catalogue data for the currently selected source without deleting persistent artwork.")),
                (_("Temporary Cache"), "clear_temp_cache", _("CLEAR"), _("Clear only temporary Ultra Stalker files under /tmp. Persistent HDD artwork is kept.")),
                (_("Persistent Artwork"), "clear_persistent_artwork", _("PROTECTED"), _("Delete saved posters, backdrops, generated artwork, Home artwork and Live picons from the HDD. Confirmation is required.")),
                (_("Artwork Cache Size"), "persistent_cache_mb", _("%d GB") % max(1,int(cfg.get("persistent_cache_mb",20480) or 20480)//1024), _("Cleanup budget for managed artwork caches. Saved backdrops and durable artwork are protected and can exceed this budget. Diagnostics shows total artwork use.")),
                (_("Image Cache Limit"), "image_cache_mb", _("%d MB") % cfg.get("image_cache_mb",128), _("Image cache size when no HDD is available. With an HDD, Artwork Cache Size applies.")),
                (_("Download Disk Reserve"), "download_reserve_mb", _("%d MB") % cfg.get("download_reserve_mb",1024), _("Keep this much disk space free while downloads are running.")),
                (_("Backup & Restore"), "backup_restore", _("OPEN"), _("Backup or restore portals, settings, favorites, history and resume state.")),
                (_("Reset Settings"), "reset_settings", _("RESET"), _("Return the options on this page to their defaults. Portals, API keys, PIN, favorites and history are kept.")),
            ],
            "portal": [
                (_("Portal Timeout"), "timeout", _("%ss") % cfg.get("timeout",10), _("Network timeout for portal API calls.")),
                (_("Bouquet Proxy Port"), "proxy_port", str(cfg.get("proxy_port",17999)), _("Local loopback port used by dynamic bouquet playback and XMLTV integration.")),
                (_("Playback Buffer"), "playback_buffer_mb", (_("Off") if int(cfg.get("playback_buffer_mb") or 0) <= 0 else _("%d MB") % int(cfg.get("playback_buffer_mb") or 0)), _("The movie or episode starts straight away. This is how far ahead the download stays while it plays. Live TV and HLS are not buffered.")),
                (_("Diagnostic Logging"), "diagnostic_logging", _("ON") if cfg.get("diagnostic_logging",False) else _("OFF"), _("Enable verbose rotating diagnostic logs after plugin restart.")),
            ],
            "tools": [
                (_("Support Bundle"), "support_bundle", _("EXPORT"), _("Create a redacted diagnostics ZIP for troubleshooting.")),
                (_("Web Cleaner Access"), "web_cleaner_access", _("EASY") if cfg.get("web_cleaner_access","easy")=="easy" else _("PIN / QR"), _("Choose how devices on your network open Web Cleaner")),
                (_("Web Cleaner"), "web_cleaner", self._web_cleaner_state(), _("Start/stop the Premium Web Cleaner and Deep Check service on port 7725.")),
                (_("Online Update"), "online_update", _("CHECK"), _("Check the official Ultra Stalker release channel and install a verified update safely.")),
                (_("About"), "about", PLUGIN_VERSION, _("Version, build identity and runtime information.")),
                (_("Diagnostics"), "diagnostics", _("OPEN"), _("View package, database, cache and portal diagnostic information.")),
            ],
        }

        self._settings_sections = sections
        self._settings_entries_by_section = by_section
        self._settings_icons = {
            "section:playback":"settings_icons_40/playback.png", "section:live":"settings_icons_40/epg.png",
            "section:media":"settings_icons_40/artwork.png", "section:search":"settings_icons_40/multi_search.png",
            "section:language_metadata":"settings_icons_40/language.png",
            "section:parental":"settings_icons_40/parental.png", "section:appearance":"settings_icons_40/theme.png",
            "section:storage":"settings_icons_40/cache.png", "section:portal":"settings_icons_40/advanced.png",
            "section:tools":"settings_icons_40/diagnostics.png",
            "smart_recovery":"settings_icons_40/recovery.png", "playback_retry_limit":"settings_icons_40/recovery.png", "live_zap_direction":"settings_icons_40/channel_list.png", "service":"settings_icons_40/playback.png", "plugin_language":"settings_icons_40/language.png",
            "font_scale":"settings_icons_40/advanced.png", "timeout":"settings_icons_40/timeout.png",
            "refresh_content":"settings_icons_40/cache.png", "epg":"settings_icons_40/epg.png",
            "catchup_hours":"settings_icons_40/catchup.png", "images":"settings_icons_40/artwork.png",
            "movies_view_mode":"settings_icons_40/channel_list.png", "live_view_mode":"settings_icons_40/channel_list.png", "series_view_mode":"settings_icons_40/channel_list.png", "player_view_mode":"settings_icons_40/playback.png", "infobar_timeout":"settings_icons_40/playback.png",
            "clear_temp_cache":"settings_icons_40/cache.png", "clear_persistent_artwork":"settings_icons_40/cache.png",
            "download_reserve_mb":"settings_icons_40/disk.png", "image_cache_mb":"settings_icons_40/cache.png", "persistent_cache_mb":"settings_icons_40/cache.png", "category_preview_posters":"settings_icons_40/artwork.png", "reset_settings":"settings_icons_40/recovery.png",
            "global_artwork_preload":"settings_icons_40/prefetch.png", "show_watched":"settings_icons_40/watched.png",
            "preview":"settings_icons_40/preview.png", "parental":"settings_icons_40/parental.png",
            "parental_mode":"settings_icons_40/parental_mode.png", "parental_session":"settings_icons_40/session.png",
            "pin":"settings_icons_40/pin.png", "adult_keywords":"settings_icons_40/keywords.png",
            "parental_lock_now":"settings_icons_40/lock.png", "hide_adult":"settings_icons_40/parental.png",
            "clean_titles":"settings_icons_40/clean.png", "quality_badges":"settings_icons_40/quality.png", "adaptive_colors":"settings_icons_40/preview.png",
            "channel_list_mode":"settings_icons_40/channel_list.png", "show_channel_numbers":"settings_icons_40/channel_list.png",
            "resume_behavior":"settings_icons_40/resume.png", "crash_safe_progress":"settings_icons_40/progress_safe.png", "remember_track_language":"settings_icons_40/resume.png",
            "progress_save_seconds":"settings_icons_40/session.png", "next_episode_countdown":"settings_icons_40/next_episode.png",
            "auto_remove_completed":"settings_icons_40/auto_remove.png", "completion_threshold":"settings_icons_40/threshold.png",
            "completion_remaining_seconds":"settings_icons_40/remaining.png", "multi_portal_search":"settings_icons_40/multi_search.png",
            "content_page_size":"settings_icons_40/search_limit.png", "search_max_pages":"settings_icons_40/search_limit.png",
            "search_time_budget":"settings_icons_40/search_limit.png", "tmdb_enabled":"settings_icons_40/tmdb.png",
            "tmdb_credential":"settings_icons_40/tmdb.png", "description_language":"settings_icons_40/tmdb.png",
            "tmdb_test":"settings_icons_40/tmdb.png", "fanart_api_key":"settings_icons_40/artwork.png",
            "subdl_api_key":"settings_icons_40/subtitles.png", "subsource_api_key":"settings_icons_40/subtitles.png", "backup_restore":"settings_icons_40/backup.png",
            "support_bundle":"settings_icons_40/support.png",
            "web_cleaner_access":"settings_icons_40/web_access.png", "web_cleaner":"settings_icons_40/web_cleaner.png",
            "online_update":"settings_icons_40/recovery.png", "about":"settings_icons_40/about.png",
            "diagnostics":"settings_icons_40/diagnostics.png", "proxy_port":"settings_icons_40/web_access.png",
            "hide_empty_categories":"settings_icons_40/channel_list.png", "epg_refresh_budget":"settings_icons_40/epg.png", "xtream_refresh_mode":"settings_icons_40/epg.png", "xtream_refresh_hour":"settings_icons_40/epg.png", "playback_buffer_mb":"settings_icons_40/playback.png",
            "diagnostic_logging":"settings_icons_40/diagnostics.png", "show_main_menu":"settings_icons_40/advanced.png",
        }

        self.entries=[(title,"section:"+key,_('%d options')%len(by_section.get(key,[])),desc) for key,title,desc,_icon in sections]
        selected=max(0,min(int(getattr(self,"_settings_root_last_idx",0) or 0),len(self.entries)-1))
        self._settings_section=sections[selected][0]
        self._settings_root_last_idx=selected
        self.opt_entries=list(by_section.get(self._settings_section,[]))
        self._pv_rows={};self._pv_shown=None
        self._render_settings_rows(selected)
        self._selection_changed()
        if getattr(self,"_pane","groups")=="options" and not getattr(self,"_context_active",False):
            self._update_preview(selected);self._opt_selection_changed(force=True)

    @staticmethod
    def _safe_clear_dir_contents(path):
        removed_files=0
        removed_bytes=0
        try:
            if not path or not os.path.isdir(path):
                return removed_files,removed_bytes
            for name in os.listdir(path):
                target=os.path.join(path,name)
                try:
                    if os.path.islink(target) or os.path.isfile(target):
                        try:removed_bytes+=int(os.path.getsize(target) or 0)
                        except Exception:pass
                        os.unlink(target);removed_files+=1
                    elif os.path.isdir(target):
                        for base,_dirs,files in os.walk(target):
                            for fn in files:
                                fp=os.path.join(base,fn)
                                try:removed_bytes+=int(os.path.getsize(fp) or 0);removed_files+=1
                                except Exception:pass
                        _shutil.rmtree(target)
                except Exception as exc:
                    optional_failure("ui.cache_clear_item",exc)
        except Exception as exc:
            optional_failure("ui.cache_clear_dir",exc)
        return removed_files,removed_bytes

    def _confirm_reset_settings(self,choice):
        if not choice or choice[1]!="reset":
            self["status"].setText(_("Settings were not changed"));return
        try:
            from .storage import DEFAULT_SETTINGS
            payload={k:DEFAULT_SETTINGS[k] for k in self._RESETTABLE_SETTINGS if k in DEFAULT_SETTINGS}
            save_settings(payload);self.refresh()
            self._context_open_notice(_("Reset Settings"),_("Options were reset to defaults. Restart Enigma2 to apply font size and main-menu changes."))
        except Exception as exc:
            self._context_open_notice(_("Reset Settings"),_("Reset failed: %s")%exc)

    def _clear_temporary_cache(self):
        def work(handle):
            files=0;size=0
            for path in ("/tmp/UltraStalker","/tmp/ultrastalker","/tmp/UltraStalker-subtitles"):
                if handle.cancelled():break
                f,b=self._safe_clear_dir_contents(path);files+=f;size+=b
            return files,size
        def done(result):
            files,size=result;self.refresh()
            self["status"].setText(_("Temporary cache cleared • %d files • %.1f MB. Persistent HDD artwork kept.")%(files,size/(1024.0*1024.0)))
        def failed(exc):self["status"].setText(_("Cache clear failed: %s")%exc)
        if self._run_async(work,done,failed):
            self["status"].setText(_("Clearing temporary cache…"))

    def _confirm_clear_persistent_artwork(self,choice):
        if isinstance(choice,(tuple,list)):choice=choice[1] if len(choice)>1 else None
        if choice!="delete":
            self["status"].setText(_("Persistent artwork was not changed"));return
        def work(handle):
            if not hdd_read_ready(force=True):return False,0,0
            files=0;size=0
            for path in PERSISTENT_ARTWORK_DIRS:
                if handle.cancelled():return True,files,size
                f,b=self._safe_clear_dir_contents(path);files+=f;size+=b
            try:
                state_path=self._global_artwork_state_path()
                if state_path and os.path.isfile(state_path):os.remove(state_path)
            except Exception as exc:optional_failure("ui.global_artwork_state_clear",exc)
            return True,files,size
        def done(result):
            ready,files,size=result
            if not ready:
                self["status"].setText(_("Persistent HDD is not available; nothing was deleted"));return
            self._global_artwork_last={};self.refresh()
            self["status"].setText(_("Persistent artwork cleared • %d files • %.1f MB. Settings and metadata kept.")%(files,size/(1024.0*1024.0)))
        def failed(exc):self["status"].setText(_("Cache clear failed: %s")%exc)
        if self._run_async(work,done,failed):
            self["status"].setText(_("Clearing persistent artwork…"))
