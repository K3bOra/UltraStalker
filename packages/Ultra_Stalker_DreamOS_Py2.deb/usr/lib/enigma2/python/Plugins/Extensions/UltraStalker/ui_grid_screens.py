# -*- coding: utf-8 -*-
"""Poster and Live grid screens extracted from ui.py without changing class behavior."""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str, int, open, max, min, OSError, us_clear, us_func

from . import _
from .ui_floating_notice import show_notice
from .ui_grid_base import PremiumGridBase
from .live_folder_tools import LiveFolderToolsMixin, lft_menu_choices, LFT_ACTIONS
from .ui_dynamic_palette import _dynamic_palette
from .ui_helpers import _lift_dynamic_accent
re = _us_env.re
json = _us_env.json
threading = _us_env.threading
time = _us_env.time
os = _us_env.os
hashlib = _us_env.hashlib
queue = _us_env.queue

from Components.MenuList import MenuList
from Components.MultiContent import MultiContentEntryText
from enigma import eListboxPythonMultiContent, gFont, ePoint, eSize, RT_HALIGN_LEFT, RT_HALIGN_CENTER, RT_VALIGN_CENTER
from .wqhd_layout import scale_multicontent_row as _wqhd_list_row, font_size as _wqhd_font, wh as _wqhd_wh
from .core.shared_executors import LIVE_PICON_RENDER_EXECUTOR as _LIVE_ROW_FIT_EXECUTOR
try:
    from PIL import Image as _PILImage, ImageDraw as _ImageDraw, ImageFilter as _PILImageFilter
except Exception:
    _PILImage = None
    _ImageDraw = None
    _PILImageFilter = None

POSTER_GRID_SKIN = ""
POSTER_GRID_V2_SKIN = ""
LIVE_GRID_SKIN = ""

def _live_preview_cover_skin(skin):
    """Add a cover over the mini-TV area, shown while a new channel starts.

    Until the stream decodes, the video plane under the preview is black; the
    cover shows the channel logo on a dark panel there instead."""
    text=str(skin or "")
    if 'name="preview_cover"' in text or '<widget name="preview_frame"' not in text:
        return text
    from .wqhd_layout import scale_skin as _scale_new_widgets
    cover=_scale_new_widgets('<widget name="preview_cover" position="870,55" size="900,506" font="Regular;1" backgroundColor="#05090f" zPosition="3" />\n '
           '<widget name="preview_cover_art" position="1210,242" size="220,132" alphatest="blend" scale="1" transparent="1" zPosition="4" />\n ')
    return text.replace('<widget name="preview_frame"',cover+'<widget name="preview_frame"',1)


def _poster_menu_overlay_skin(skin):
    value=str(skin or "")
    if 'name="poster_menu_scrim"' in value and 'name="poster_menu_list"' in value:
        return value
    from .wqhd_layout import scale_skin as _scale_new_widgets
    widget='\n <widget name="poster_menu_scrim" position="0,0" size="1920,1080" alphatest="blend" scale="1" transparent="1" zPosition="40"/>\n <widget name="poster_menu_list" position="510,360" size="900,462" scrollbarMode="showNever" transparent="1" zPosition="41"/>\n'
    return value.replace('</screen>',_scale_new_widgets(widget)+'</screen>',1)


def configure_grid_screens(**deps):
    globals().update(deps)
    if "POSTER_GRID_SKIN" in deps:
        PremiumPosterGridScreen.skin = _poster_menu_overlay_skin(deps["POSTER_GRID_SKIN"])
    if "POSTER_GRID_V2_SKIN" in deps:
        PremiumPosterGridV2Screen.skin = _poster_menu_overlay_skin(deps["POSTER_GRID_V2_SKIN"])
    if "LIVE_GRID_SKIN" in deps:
        PremiumLiveGridScreen.skin = _live_preview_cover_skin(deps["LIVE_GRID_SKIN"])


_LIVE_FIT_FAILED=set()
_LIVE_FIT_RAM={}

def _live_fit_ready(source,size):
    """RAM-first lookup of an already written row derivative (no repeated stat/hash)."""
    key=(source,tuple(size))
    hit=_LIVE_FIT_RAM.get(key)
    if hit:return hit
    try:
        from .ui_artwork_helpers import _live_row_fit_cached
        ready=_live_row_fit_cached(source,PERSISTENT_GENERATED_DIR,tuple(size))
    except Exception:
        ready=""
    if ready:
        if len(_LIVE_FIT_RAM)>4096:us_clear(_LIVE_FIT_RAM)
        _LIVE_FIT_RAM[key]=ready
    return ready


class LiveFocusTextList(MenuList):
    """Ultra-light Live MENU: text only, no card pixmaps or adaptive assets."""
    def __init__(self, choices=None, width=900, item_height=66):
        self.row_width=int(width)
        self.row_height=int(item_height)
        self._rows=list(choices or [])
        self._rendering=False
        us_func(MenuList.__init__)(self,[],enableWrapAround=True,content=eListboxPythonMultiContent)
        # Category-style emphasis: bright white idle, slightly larger green focus.
        self.l.setFont(0,gFont("Regular",_wqhd_font(30)))
        self.l.setFont(1,gFont("Regular",_wqhd_font(34)))
        self.l.setItemHeight(_wqhd_font(self.row_height))

    def set_width(self,width):
        self.row_width=max(320,int(width or 900))

    def set_choices(self,choices,selected=0):
        self._rows=list(choices or [])
        self._render(selected)

    def _render(self,selected=None):
        if self._rendering:return
        self._rendering=True
        try:
            if selected is None:
                selected=self.getSelectedIndex() if self._rows else 0
            rows=[]
            for idx,choice in enumerate(self._rows):
                label=str(choice[0] if isinstance(choice,(tuple,list)) and choice else choice or "")
                focused=(idx==selected)
                rows.append([
                    choice,
                    MultiContentEntryText(
                        pos=(0,0),size=(self.row_width,self.row_height),
                        font=(1 if focused else 0),
                        flags=RT_HALIGN_CENTER|RT_VALIGN_CENTER,
                        text=label,
                        color=(0x00E676 if focused else 0x00FFFFFF),
                        color_sel=(0x00E676 if focused else 0x00FFFFFF),
                    )
                ])
            self.setList(list(_wqhd_list_row(r) for r in rows))
            if rows:
                try:self.moveToIndex(max(0,min(int(selected),len(rows)-1)))
                except Exception:pass
        finally:
            self._rendering=False

    def selection_changed(self):
        if not self._rendering:self._render(self.getSelectedIndex())

    def selected_choice(self):
        idx=self.getSelectedIndex()
        return self._rows[idx] if 0<=idx<len(self._rows) else None


def _pgv2_clean_title_detached(item):
    raw=(item or {}).get("name") or (item or {}).get("title") or ""
    try:return _clean_display_text(raw,80) or str(raw or "")
    except Exception:return str(raw or "")[:80]


def _pgv2_cinematic_title_detached(media_type,item,row=None):
    try:
        from .ui_cinematic_global import PremiumGlobalCinematicScreen
        proxy=object.__new__(PremiumGlobalCinematicScreen);proxy.media_type=media_type
        return PremiumGlobalCinematicScreen._rail_title(proxy,item,row if isinstance(row,dict) else {}) or ""
    except Exception:
        try:
            from .title_clean import display_title
            return display_title((item or {}).get("name") or (item or {}).get("title") or "") or ""
        except Exception:return ""


def _pgv2_logo_seal_path_detached(profile,media_type,item,row=None):
    try:
        from .persistent_cache import BLUE_CACHE,content_cache_key
        folder=os.path.join(BLUE_CACHE,"pgv2_title_logo_ready")
        if not os.path.isdir(folder):os.makedirs(folder,mode=0o700,exist_ok=True)
        tid=_pgv2_known_tmdb_id_detached(item,row)
        if tid:
            mt="tv" if str(media_type or "").lower() in ("series","tv","episode") else "movie"
            return os.path.join(folder,"tmdb_%s_%s.json"%(mt,str(tid).strip()))
        key=str(content_cache_key(profile,media_type,item) or "")
        if not key:return ""
        return os.path.join(folder,hashlib.sha1(key.encode("utf-8","ignore")).hexdigest()+".json")
    except Exception:return ""


def _pgv2_read_logo_seal_detached(profile,media_type,item,row=None):
    try:
        candidates=[]
        primary=_pgv2_logo_seal_path_detached(profile,media_type,item,row=row)
        if primary:candidates.append(primary)
        fallback=_pgv2_logo_seal_path_detached(profile,media_type,item,row=None)
        if fallback and fallback not in candidates:candidates.append(fallback)
        for path in candidates:
            cached=_TITLE_LOGO_SEAL_RAM.get(path) if "_TITLE_LOGO_SEAL_RAM" in globals() else None
            if isinstance(cached,dict) and int(cached.get("schema") or 0)>=3 and cached.get("checked"):
                return dict(cached)
            if not os.path.isfile(path):continue
            with open(path,"r",encoding="utf-8") as h:data=json.load(h)
            if isinstance(data,dict) and int(data.get("schema") or 0)>=3 and data.get("checked"):
                try:_pgv2_logo_seal_ram_put(path,data)
                except Exception:pass
                return data
        return {}
    except Exception:return {}


def _pgv2_write_logo_seal_detached(profile,media_type,item,row,logo_path):
    try:
        resolved_tmdb_id=(row or {}).get("tmdb_id") or _pgv2_known_tmdb_id_detached(item,row)
        if not logo_path and not resolved_tmdb_id:return False
        path=_pgv2_logo_seal_path_detached(profile,media_type,item,row=row if row else {"tmdb_id":resolved_tmdb_id,"identity_verified":True})
        if not path:return False
        payload={"schema":5,"logo_policy":2,"tmdb_id":resolved_tmdb_id,"title_logo_local":str(logo_path or ""),"checked":True,"updated_at":int(time.time())}
        tmp=path+".tmp.%s.%s"%(os.getpid(),threading.get_ident())
        with open(tmp,"w",encoding="utf-8") as h:
            json.dump(payload,h,ensure_ascii=False,separators=(",",":"))  # rebuildable title-logo cache seal
        os.chmod(tmp,0o600);os.replace(tmp,path)
        try:_pgv2_logo_seal_ram_put(path,payload)
        except Exception:pass
        return True
    except Exception:
        try:
            if "tmp" in locals() and os.path.exists(tmp):os.unlink(tmp)
        except OSError:pass
        return False


# R228: one tiny shared title-logo state for PG2 / Cinematic / BG1 / BG2.
# Positive logo seals are durable while the source file exists. A negative seal is
# intentionally short-lived so remote artwork can recover later without making every
# focus pay the same expensive discovery path.
_TITLE_LOGO_SEAL_RAM = {}
_TITLE_LOGO_SEAL_RAM_MAX = 512
_TITLE_LOGO_NEGATIVE_TTL = 6 * 60 * 60

def _pgv2_logo_seal_ram_put(path,data):
    try:
        key=str(path or "")
        if not key or not isinstance(data,dict):return
        _TITLE_LOGO_SEAL_RAM[key]=dict(data)
        while len(_TITLE_LOGO_SEAL_RAM)>_TITLE_LOGO_SEAL_RAM_MAX:
            _TITLE_LOGO_SEAL_RAM.pop(next(iter(_TITLE_LOGO_SEAL_RAM)))
    except Exception:
        pass

def _pgv2_known_tmdb_id_detached(item,row=None):
    item=item if isinstance(item,dict) else {}
    row=row if isinstance(row,dict) else {}
    for obj,key in ((item,"_player_title_logo_tmdb_id"),(row,"_player_title_logo_tmdb_id"),
                    (item,"_locked_tmdb_id"),(row,"_locked_tmdb_id"),
                    (item,"_ultra_search_verified_tmdb_id"),(row,"_ultra_search_verified_tmdb_id")):
        value=obj.get(key)
        if value not in (None,""):return str(value)
    if row.get("identity_verified") or row.get("identity_pointer_verified"):
        value=row.get("tmdb_id")
        if value not in (None,""):return str(value)
    if item.get("identity_verified") or item.get("identity_pointer_verified"):
        value=item.get("tmdb_id")
        if value not in (None,""):return str(value)
    return ""

def _pgv2_title_logo_probe_missing_detached(item,row=None):
    """Zero-network hint: current hydrated row already checked and found no logo.

    It is presentation-only, not a permanent negative cache. The background resolver
    may still promote a later TMDb/Fanart hit if this hint was stale.
    """
    sources=[]
    if isinstance(row,dict):sources.append(row)
    if isinstance(item,dict):sources.append(item)
    checked=False
    for src in sources:
        if any(bool(src.get(k)) for k in ("title_logo_probe_v2_checked","title_logo_probe_checked","title_logo_checked")):
            checked=True
        for key in ("title_logo_local","logo_local"):
            path=str(src.get(key) or "")
            if path and os.path.isfile(path) and os.path.getsize(path)>256:return False
        if str(src.get("logo_url") or "").strip():return False
    return bool(checked)

def _pgv2_logo_seal_state_detached(profile,media_type,item,row=None):
    """Return (state, path, seal) where state is logo/missing/unknown.

    This is HDD/RAM only and never decodes an image or touches the network.
    """
    seal=_pgv2_read_logo_seal_detached(profile,media_type,item,row=row) or {}
    if not seal:return ("unknown","",{})
    current_id=_pgv2_known_tmdb_id_detached(item,row)
    seal_id=str(seal.get("tmdb_id") or "")
    if current_id and (not seal_id or current_id!=seal_id):return ("unknown","",seal)
    if not seal_id and not str(seal.get("title_logo_local") or ""):return ("unknown","",seal)
    path=str(seal.get("title_logo_local") or "")
    if path and os.path.isfile(path) and os.path.getsize(path)>256:return ("logo",path,seal)
    if path:return ("unknown","",seal)
    try:age=max(0,int(time.time())-int(seal.get("updated_at") or 0))
    except Exception:age=_TITLE_LOGO_NEGATIVE_TTL+1
    # R230: a pre-policy negative seal may only mean "no Arabic/English logo".
    # Re-open it once under the new any-language fallback policy. Positive old
    # seals above remain valid and fast.
    if seal.get("checked") and int(seal.get("logo_policy") or 0)>=2 and age<=_TITLE_LOGO_NEGATIVE_TTL:return ("missing","",seal)
    return ("unknown","",seal)

def _pgv2_logo_canvas_matches_detached(path,canvas_size):
    try:
        w,h=int(canvas_size[0]),int(canvas_size[1])
        return bool(str(path or "").endswith("_%sx%s.png"%(w,h)))
    except Exception:return False

def _pgv2_bridge_logo_from_seal_detached(profile,media_type,item,row=None,canvas_size=(900,125),cancel_event=None):
    """Worker-only cross-view bridge from any already-verified logo seal.

    A 900x125 PG2 hit can therefore become BG/Cinematic locally in milliseconds
    instead of repeating Details/TMDb/Fanart discovery.
    """
    state,source,seal=_pgv2_logo_seal_state_detached(profile,media_type,item,row)
    if state!="logo" or not source:return (state,"",seal)
    if cancel_event is not None and cancel_event.is_set():return ("unknown","",seal)
    if _pgv2_logo_canvas_matches_detached(source,canvas_size):return ("logo",source,seal)
    try:
        st=os.stat(source);w,h=int(canvas_size[0]),int(canvas_size[1])
        from .persistent_cache import durable_view_path
        sig="%s|%s|%s|%sx%s"%(source,int(getattr(st,"st_mtime_ns",int(st.st_mtime*1e9))),int(st.st_size),w,h)
        target=durable_view_path(hashlib.sha1(sig.encode("utf-8","ignore")).hexdigest()[:28]+".png","title_logo_bridge_v1",source=source)
        folder=os.path.dirname(target)
        if not os.path.isdir(folder):os.makedirs(folder,mode=0o700,exist_ok=True)
        if os.path.isfile(target) and os.path.getsize(target)>256:return ("logo",target,seal)
        from .title_logo_runtime import prepare_title_logo_file
        margins={(900,70):(16,3),(900,125):(40,13),(420,144):(16,12),(432,210):(28,24)}
        mx,my=margins.get((w,h),(max(12,int(w*0.045)),max(6,int(h*0.08))))
        path=prepare_title_logo_file(source,target,canvas_size=(w,h),margin_x=mx,margin_y=my) or ""
        if path and os.path.isfile(path) and os.path.getsize(path)>256:return ("logo",path,seal)
    except Exception:
        pass
    return ("unknown","",seal)




def _pgv2_authoritative_logo_row_detached(profile,media_type,item,row,cancel_event=None,settings=None):
    """Exact PGV2 identity gate, shared by every title-logo presentation.

    Poster Grid V2 is the receiver-proven path: consume its current HDD row, and
    when canonical identity is not already sealed, hydrate through Details
    Authority before logo discovery.  Keeping this tiny gate shared prevents
    Cinematic/BG from drifting back to a weaker resolver path.
    """
    fresh=dict(row or {}) if isinstance(row,dict) else {}
    if cancel_event is not None and cancel_event.is_set():return fresh
    try:
        identity_ready=bool(
            fresh.get("identity_verified") or fresh.get("identity_pointer_verified") or
            fresh.get("_details_authority_ready") or fresh.get("_locked_tmdb_id") or
            (isinstance(item,dict) and item.get("_locked_tmdb_id"))
        )
        if not identity_ready:
            from .details_authority import load_canonical, resolve_metadata_fast
            cached_row=load_canonical(profile,media_type,dict(item or {})) or {}
            if cached_row:
                for k,v in cached_row.items():
                    if v not in (None,"",[],{}):fresh[k]=v
            identity_ready=bool(
                fresh.get("identity_verified") or fresh.get("identity_pointer_verified") or
                fresh.get("_details_authority_ready") or fresh.get("_locked_tmdb_id")
            )
            if not identity_ready or not (fresh.get("original_language") and (fresh.get("countries") or fresh.get("origin_country") or fresh.get("production_countries"))):
                authoritative=resolve_metadata_fast(
                    profile,media_type,dict(item or {}),current=fresh,
                    cancel_event=cancel_event,settings=(settings or {})
                ) or {}
                if cancel_event is not None and cancel_event.is_set():return fresh
                if authoritative:
                    merged=dict(fresh)
                    for k,v in authoritative.items():
                        if v not in (None,"",[],{}):merged[k]=v
                    fresh=merged
    except Exception as exc:
        try:optional_failure("ui.pgv2_logo_authoritative_row",exc)
        except Exception:pass
    return fresh


def _pgv2_resolve_title_logo_detached(profile,media_type,item,row,cancel_event=None,settings=None,canvas_size=(900,125)):
    """Resolve through the receiver-proven Poster Grid V2 logo authority.

    Discovery/identity/language/neutral/Fanart/cache policy is identical for all
    views.  Only the final presentation canvas differs per screen.
    """
    fresh=dict(row or {}) if isinstance(row,dict) else {}
    if cancel_event is not None and cancel_event.is_set():return ("",fresh)
    try:
        from .title_logo_ultra import resolve_ultra_title_logo
        visible=_pgv2_cinematic_title_detached(media_type,item,fresh) or _pgv2_clean_title_detached(item)
        return resolve_ultra_title_logo(
            profile,media_type,dict(item or {}),fresh,
            canvas_size=canvas_size,visible_title=visible,
            cancel_event=cancel_event,settings=settings,
        )
    except Exception as exc:
        try:optional_failure("ui.pgv2_logo_shared_authority",exc)
        except Exception:pass
        return ("",fresh)


class _PosterCenteredTextMenuMixin(object):
    """Poster Grid 1/2 MENU: exact R116 Live text grammar, centered."""
    def _poster_menu_init(self):
        from Components.ActionMap import ActionMap
        self._poster_menu_active=False
        self._poster_menu_choices=[]
        self._poster_menu_accept_callback=None;self._poster_menu_close_callback=None
        self["poster_menu_scrim"]=Pixmap()
        self["poster_menu_list"]=LiveFocusTextList([],width=900,item_height=66)
        try:self["poster_menu_scrim"].hide()
        except Exception:pass
        try:self["poster_menu_list"].hide()
        except Exception:pass
        self["poster_menu_actions"]=ActionMap(
            ["OkCancelActions","DirectionActions","MenuActions","UltraStalkerMenuActions","ColorActions","InfoActions"],
            {"ok":self._poster_menu_accept,"cancel":self._poster_menu_close,"menu":self._poster_menu_close,
             "up":self._poster_menu_up,"down":self._poster_menu_down,
             "left":self._poster_menu_page_up,"right":self._poster_menu_page_down,
             "red":self._poster_menu_noop,"green":self._poster_menu_noop,
             "yellow":self._poster_menu_noop,"blue":self._poster_menu_noop,"info":self._poster_menu_noop},
            -1000,
        )
        try:self["poster_menu_actions"].setEnabled(False)
        except Exception:pass

    def _poster_menu_noop(self):
        return None

    def _poster_menu_layout(self):
        if not getattr(self,"_poster_menu_active",False):return
        try:
            from enigma import ePoint,eSize
            count=max(1,min(len(getattr(self,"_poster_menu_choices",[]) or []),7))
            row_w=900;row_h=66
            self["poster_menu_list"].set_width(row_w)
            phys_w,phys_row_h=_wqhd_wh(row_w,row_h)
            group_h=count*phys_row_h
            try:
                size=self.instance.size();screen_w=int(size.width());screen_h=int(size.height())
            except Exception:
                screen_w,screen_h=_wqhd_wh(1920,1080)
            x=max(0,int((screen_w-phys_w)/2));y=max(0,int((screen_h-group_h)/2))
            inst=self["poster_menu_list"].instance
            if inst is not None:
                inst.resize(eSize(phys_w,group_h));inst.move(ePoint(x,y))
        except Exception as exc:optional_failure("ui.poster_menu_center",exc)

    def _poster_menu_show(self,choices,on_accept=None,on_close=None):
        self._poster_menu_accept_callback=on_accept;self._poster_menu_close_callback=on_close
        self._poster_menu_choices=list(choices or [])
        if not self._poster_menu_choices:return
        try:
            dim=asset("us88_focus_dim_scrim.png")
            if dim and os.path.isfile(dim) and self["poster_menu_scrim"].instance is not None:
                self["poster_menu_scrim"].instance.setPixmapFromFile(dim)
        except Exception as exc:optional_failure("ui.poster_menu_scrim",exc)
        try:
            if self["poster_menu_list"].instance is not None:self["poster_menu_list"].instance.setSelectionEnable(0)
        except Exception:pass
        try:self["poster_menu_list"].set_choices(self._poster_menu_choices,0)
        except Exception as exc:optional_failure("ui.poster_menu_text",exc)
        self._poster_menu_active=True
        self._poster_menu_layout()
        try:self["poster_menu_scrim"].show()
        except Exception:pass
        try:self["poster_menu_list"].show()
        except Exception:pass
        try:self["poster_menu_actions"].setEnabled(True)
        except Exception:pass

    def _poster_menu_close(self,notify=True):
        if not getattr(self,"_poster_menu_active",False):return
        callback=getattr(self,'_poster_menu_close_callback',None)
        self._poster_menu_accept_callback=None;self._poster_menu_close_callback=None
        self._poster_menu_active=False
        try:self["poster_menu_actions"].setEnabled(False)
        except Exception:pass
        try:self["poster_menu_list"].hide()
        except Exception:pass
        try:self["poster_menu_scrim"].hide()
        except Exception:pass
        if notify and callback is not None:callback()

    def _poster_menu_up(self):
        if not getattr(self,"_poster_menu_active",False):return
        try:self["poster_menu_list"].up();self["poster_menu_list"].selection_changed()
        except Exception:pass

    def _poster_menu_down(self):
        if not getattr(self,"_poster_menu_active",False):return
        try:self["poster_menu_list"].down();self["poster_menu_list"].selection_changed()
        except Exception:pass

    def _poster_menu_page_up(self):
        if not getattr(self,"_poster_menu_active",False):return
        try:self["poster_menu_list"].pageUp();self["poster_menu_list"].selection_changed()
        except Exception:pass

    def _poster_menu_page_down(self):
        if not getattr(self,"_poster_menu_active",False):return
        try:self["poster_menu_list"].pageDown();self["poster_menu_list"].selection_changed()
        except Exception:pass

    def _poster_menu_accept(self):
        if not getattr(self,"_poster_menu_active",False):return
        try:choice=self["poster_menu_list"].selected_choice()
        except Exception:choice=None
        callback=getattr(self,'_poster_menu_accept_callback',None)
        self._poster_menu_close(notify=False)
        if callback is not None:callback(choice)
        elif choice is not None:us_func(PremiumGridBase._menu_selected)(self,choice)

    def open_menu(self):
        if getattr(self,"_poster_menu_active",False):
            self._poster_menu_close();return
        choices=[(_("Refresh page"),"refresh"),(_("First page"),"first"),(_("Toggle favorite"),"favorite")]
        if self.media_type in ("vod","series") and self.grid_items:
            from .ui_manual_match import menu_choices
            choices.extend(menu_choices())
            choices.append((_("Trailer"),"trailer"))
            choices.append((_("Export this to channel list"),"export_one"))
        if self.media_type=="vod" and self.grid_items:
            safe_idx=max(0,min(int(self.index or 0),len(self.grid_items)-1))
            state=self._grid_item_state.get(id(self.grid_items[safe_idx]),{})
            choices.append((_('Mark unwatched') if state.get('completed') else _('Mark watched'),'unwatch' if state.get('completed') else 'watch'))
        self._poster_menu_show(choices)


class PremiumPosterGridScreen(_PosterCenteredTextMenuMixin, PremiumGridBase):
    wide_section_path=True
    # This skin visibly renders YEAR + TMDb score on every card.  Cold identity
    # hydration can finish just after the first metadata pass, so two bounded
    # missing-only sweeps finish all 14 visible cards without requiring focus.
    visible_card_rating_prefetch=True
    visible_card_age_prefetch=True
    visible_card_rating_retry_delays=(1.60,3.20)
    skin=POSTER_GRID_SKIN;columns=7;page_size=14;image_size=(236,354);placeholder="grid_placeholder_movie_921.png";selection_asset="poster_cursor_g1_252x434.png"
    card_chrome_geometry=(236,418,354)
    # R5.20 full-height layout: 7x2 cards of 236x418 (poster 236x354 + 64px title tray).
    card_positions=[(x,y) for y in (26,504) for x in (32,299,566,833,1100,1367,1634)]
    # The top HUD (folder/title/clock/counter glass) is retired in this layout;
    # folder + counter live in the bottom bar defined by the skin.
    poster_hud_disabled=True
    def __init__(self,session,profile,client,media_type,genre,category_title="",initial_search=""):
        self.placeholder="grid_placeholder_series_921.png" if media_type=="series" else "grid_placeholder_movie_921.png"
        self.selection_asset="poster_cursor_g1_252x434.png"
        self._poster_neutral_card_asset="state_blank.png"
        # Keep the proven catalogue/navigation behavior.  Small-card
        # poster fill is handled by a dedicated thumbnail flag so it cannot
        # change paging/catalogue semantics.
        self._poster_cover_mode=False
        self._poster_small_fill=True
        us_func(PremiumGridBase.__init__)(self,session,profile,client,media_type,genre,category_title,initial_search)
        if self.__class__.__name__ == "PremiumPosterGridScreen":
            self._poster_menu_init()


class PremiumPosterGridV2Screen(_PosterCenteredTextMenuMixin, PremiumGridBase):
    """Static poster wall with immediate title text; no title-logo pipeline."""
    visible_card_rating_prefetch=True
    visible_card_age_prefetch=True
    visible_card_rating_retry_delays=(1.60,3.20)
    premium_v2_badges=True
    skin=POSTER_GRID_V2_SKIN;columns=9;page_size=27;image_size=(206,309)
    placeholder="grid_placeholder_movie_921.png";selection_asset="poster_cursor_v2_206x309.png"
    card_positions=[(x,y) for y in (4,319,634) for x in (9,221,433,645,857,1069,1281,1493,1705)]

    def __init__(self,session,profile,client,media_type,genre,category_title="",initial_search=""):
        self.placeholder="grid_placeholder_series_921.png" if media_type=="series" else "grid_placeholder_movie_921.png"
        self.selection_asset="poster_cursor_v2_206x309.png"
        self._poster_neutral_card_asset="poster_card_full_neutral_small.png"
        self._poster_cover_mode=False;self._poster_small_fill=True
        us_func(PremiumGridBase.__init__)(self,session,profile,client,media_type,genre,category_title,initial_search)
        self["hero_clean_title"]=Label("")
        if self.__class__.__name__ == "PremiumPosterGridV2Screen":self._poster_menu_init()
        self.onLayoutFinish.append(self._show_selected_name)

    def _show_selected_name(self):
        try:widget=self["hero_clean_title"]
        except Exception:return
        title=""
        if self.grid_items:
            item=self.grid_items[max(0,min(int(self.index),len(self.grid_items)-1))]
            title=self._display_item_title(item,"Item")
        widget.setText(title)
        widget.show()

    def _update_header(self,item):
        return us_func(PremiumGridBase._update_header)(self,item)

    def _update_selection(self):
        us_func(PremiumGridBase._update_selection)(self)
        self._show_selected_name()

    def _apply_debounced_grid_focus(self):
        if not self._screen_closed and self.grid_items:
            try:
                from .core.shared_executors import METADATA_EXECUTOR
                key = self._page_visual_key(self.grid_items[self.index])
                generation = int(getattr(self, "_page_prefetch_generation", 0) or 0)
                METADATA_EXECUTOR.reprioritize("grid-tmdb:%x:%s:%s" % (id(self), generation, key), 0)
            except Exception:
                pass
            self._grid_apply_current_selector(allow_build=False)
            try:
                self._prefetch_focused_artwork()
            except Exception:
                pass

    def _refresh_search_sort_controls(self):
        super(PremiumPosterGridV2Screen,self)._refresh_search_sort_controls()
        for name in ("red","green","yellow","blue"):
            try:
                inst=self[name].instance
                if inst is not None:inst.setFont(gFont("Regular",_wqhd_font(20)))
            except Exception as exc:optional_failure("ui.pgv2_footer_font",exc)

    def _update_page_counter(self):
        us_func(PremiumGridBase._update_page_counter)(self)
        empty_sig = (int(getattr(self, "_grid_generation", 0) or 0), len(self.grid_items))
        if getattr(self, "_pgv2_empty_hidden_sig", None) != empty_sig:
            self._pgv2_empty_hidden_sig = empty_sig
            for pos in range(len(self.grid_items),self.page_size):
                for key in ("seasons", "seasons_icon", "seasons_bg"):
                    try:self["item_%s%d"%(key,pos)].hide()
                    except Exception:pass

    def _grid_schedule_adaptive_selector(self,generation,slot,path):
        return

    def _grid_schedule_page_mood(self,path):
        return

    def _apply_poster_live_hud(self,item=None):
        return

    def _card_rating_layout(self,item,pos,meta_text=None):
        # Local text + resident Premium badges only; never discover metadata here.
        from .ui_grid_v2_premium import paint_badges
        return paint_badges(self,item,pos)

    def _grid_apply_current_selector(self,allow_build=False):
        # One reusable static focus, identical for every title.
        try:self["selection_adaptive"].hide()
        except Exception:pass
        try:
            stable=asset(self.selection_asset)
            if getattr(self,"_grid_selection_visual_path","")!=stable:
                if self["selection"].instance is not None:
                    self["selection"].instance.setPixmap(None)
                    self["selection"].instance.setPixmapFromFile(stable)
                self._grid_selection_visual_path=stable
            self["selection"].show()
        except Exception as exc:optional_failure("ui.pgv2_static_selector",exc)




class PremiumLiveGridScreen(LiveFolderToolsMixin, PremiumGridBase):
    shared_footer=True
    wide_section_path=True
    skin=LIVE_GRID_SKIN;columns=1;page_size=17;image_size=(64,36);placeholder="us168_live_placeholder_220x132.png";selection_asset="live_clean_r376/selected_748x58.png"
    card_positions=[(58,8+i*58) for i in range(17)]
    PREVIEW_RECT=(870,55,900,506)

    def __init__(self,session,profile,client,media_type,genre,category_title="",live_categories=None,initial_search=""):
        # R66: keep the already-filtered browser category rows with the Live
        # screen.  The Player drawer can then switch between Channels and
        # Categories in-place without opening another screen or re-fetching the
        # browser's category menu.
        self._live_categories=[dict(x) for x in (live_categories or []) if isinstance(x,dict)]
        # Live picons persist on HDD and are reused before any network request.
        # This compact Live screen intentionally has no clock/date HUD or timer.
        self.disable_grid_clock=True
        self._preview_old_service=None
        try:self._preview_old_service=session.nav.getCurrentlyPlayingServiceReference()
        except Exception as exc:optional_failure("ui",exc)
        self._active_preview_key=None;self._active_preview_url=None;self._active_preview_item=None;self._active_preview_engine=None
        self._preview_token=0;self._preview_jobs=queue.Queue();self._preview_handle=None;self._preview_task_id=None;self._pending_preview_key=None
        self._preview_pending_url=None;self._preview_pending_item=None;self._preview_pending_engine=None;self._preview_engine_candidates=[];self._preview_engine_pos=0
        self._preview_poll_count=0;self._preview_restore_state=None;self._main_preview_reference=None
        # OpenATV 8.0 compatibility: never run Pillow picon fitting on the
        # Enigma2 GUI thread.  Raw/cached picons paint immediately; the exact
        # trimmed 64x36 derivative is prepared on the bounded cache-I/O lane
        # and swapped in through the existing grid result queue.
        self._live_row_fit_pending=set()
        us_func(PremiumGridBase.__init__)(self,session,profile,client,media_type,genre,category_title,initial_search)
        # R116: same-screen Live MENU, now text-only for zero card/adaptive overhead.
        # Keep the exact Details Information dim scrim behind it.
        from Components.ActionMap import ActionMap
        self._live_menu_active=False
        self._live_menu_choices=[]
        self["live_menu_scrim"]=Pixmap()
        self["live_menu_list"]=LiveFocusTextList([],width=900,item_height=66)
        try:self["live_menu_scrim"].hide()
        except Exception:pass
        try:self["live_menu_list"].hide()
        except Exception:pass
        self["live_menu_actions"]=ActionMap(
            ["OkCancelActions","DirectionActions","MenuActions","UltraStalkerMenuActions","ColorActions","InfoActions"],
            {"ok":self._live_menu_accept,"cancel":self._live_menu_close,"menu":self._live_menu_close,
             "up":self._live_menu_up,"down":self._live_menu_down,"left":self._live_menu_page_up,"right":self._live_menu_page_down,
             "red":self._live_menu_noop,"green":self._live_menu_noop,"yellow":self._live_menu_noop,"blue":self._live_menu_noop,
             "info":self._live_menu_noop},
            -1000,
        )
        try:self["live_menu_actions"].setEnabled(False)
        except Exception:pass
        try:self._last_fullscreen_key=str((_GRID_NAV_STATE.get(self._session_nav_key,{}) or {}).get("last_fullscreen_key") or "")
        except Exception:self._last_fullscreen_key=""
        self._preview_ready_timer=eTimer();self._preview_ready_conn=None
        try:self._preview_ready_conn=self._preview_ready_timer.timeout.connect(self._check_preview_ready)
        except Exception:self._preview_ready_timer.callback.append(self._check_preview_ready)
        self["channel_name"]=Label("");self["preview_status"]=Label("")
        self["preview_cover"]=Label("");self["preview_cover_art"]=Pixmap()
        self.onLayoutFinish.append(self._hide_preview_cover_on_layout)
        self["page_adaptive_bg"]=Pixmap();self["preview_frame"]=Pixmap();self["live_info_bg"]=Pixmap();self["page_label_bg"]=Pixmap()
        self["tech_bg1"]=Pixmap();self["tech_bg2"]=Pixmap();self["tech_bg3"]=Pixmap();self["tech_bg4"]=Pixmap()
        for _ri in range(self.page_size):self["row_adaptive%d"%_ri]=Pixmap()
        self._em_init()
        self._live_static_chrome_bound=False
        self["epg_hint"]=Label(_("NOW / NEXT"));self["tech1"]=Label(_("AUTO"));self["tech2"]=Label(_("LIVE"));self["tech3"]=Label(_("CHANNEL"));self["tech4"]=Label(_("OK Preview"))
        self["now_progress"]=ProgressBar()
        try:self["now_progress"].setValue(0)
        except Exception as exc:optional_failure("ui",exc)
        self.onLayoutFinish.append(self._prepare_preview_window);self.onLayoutFinish.append(self._apply_live_static_chrome);self.onLayoutFinish.append(self._apply_live_action_footer_geometry);self.onClose.append(self._stop_live_preview);self.onClose.append(self._stop_live_grid_hooks)
        try:self.onShown.append(self._apply_live_action_footer_geometry)
        except Exception:pass
        self["red"].setText(_("Back"));self["green"].setText(_("Favorite"));self["yellow"].setText(_("Previous page"));self["blue"].setText(_("Next page"));self["brand"].setText("")
        try:force_session_silence(self.session,"",force=False)
        except Exception as exc:optional_failure("ui",exc)


    def _apply_live_action_footer_geometry(self):
        self._apply_shared_footer_geometry()

    @staticmethod
    def _bouquet_channel_key(item):
        row=item if isinstance(item,dict) else {}
        raw="%s|%s|%s"%(
            str(row.get("id") or row.get("ch_id") or ""),
            str(row.get("cmd") or row.get("command") or row.get("url") or ""),
            str(row.get("name") or row.get("title") or ""),
        )
        return hashlib.sha1(raw.encode("utf-8","ignore")).hexdigest()[:20]

    def _displayed_live_picon_for_item(self,item):
        """Return the exact local artwork file currently backing a visible Live row.

        Receiver export must reuse the artwork that Ultra Stalker has already
        proven it can render.  Looking only at provider URL fields can miss a
        cached/redirected logo even though the channel visibly has a picon in
        the Live grid.
        """
        try:
            wanted=self._bouquet_channel_key(item)
            slots=getattr(self,"_grid_slot_paths",{}) or {}
            palettes=getattr(self,"_grid_palette_sources",{}) or {}
            for slot,visible in enumerate(getattr(self,"grid_items",[]) or []):
                if not isinstance(visible,dict) or self._bouquet_channel_key(visible)!=wanted:
                    continue
                for source in (slots.get(slot),palettes.get(slot)):
                    source=str(source or "")
                    if source and os.path.isfile(source) and os.path.getsize(source)>256:
                        return source
        except Exception as exc:
            optional_failure("ui.live_bouquet_displayed_picon",exc)
        return ""

    def _capture_receiver_picon_from_slot(self,row,slot):
        """Attach the exact visible Live artwork before menu/selection state changes."""
        if not isinstance(row,dict):return row
        try:
            candidates=[]
            for mapping_name in ("_grid_palette_sources","_grid_slot_paths"):
                value=str((getattr(self,mapping_name,{}) or {}).get(int(slot)) or "")
                if value and os.path.isfile(value) and os.path.getsize(value)>256 and value not in candidates:
                    candidates.append(value)
            try:
                visual=self._page_visual_get(self.grid_items[int(slot)]) or {}
                for key in ("palette","poster","display"):
                    value=str(visual.get(key) or "")
                    if value and os.path.isfile(value) and os.path.getsize(value)>256 and value not in candidates:
                        candidates.append(value)
            except Exception:pass
            if candidates:
                row["_receiver_picon_displayed_local"]=candidates[0]
                row["_receiver_picon_source_local"]=candidates[0]
        except Exception as exc:optional_failure("ui.live_bouquet_capture_picon",exc)
        return row

    def _prepare_live_bouquet_row(self,item,allow_fetch=False):
        """Prepare receiver export from the exact displayed or best provider logo and EPG identity."""
        row=dict(item or {}) if isinstance(item,dict) else {}
        raw_name=row.get("name") or row.get("title") or row.get("id") or _("Channel")
        try:row["_receiver_name"]=_clean_live_channel_name(raw_name)
        except Exception:row["_receiver_name"]=str(raw_name or _("Channel"))

        epg_ids=[]
        for key in ("ch_id","channel_id","id","stream_id","epg_id","tvg_id","xmltv_id"):
            value=row.get(key)
            if value in (None,""):continue
            value=str(value).strip()
            if value and value not in epg_ids:epg_ids.append(value)
        if epg_ids:row["_receiver_epg_candidates"]=epg_ids

        try:
            candidates=[]
            for key in ("_receiver_picon_displayed_local","_receiver_picon_source_local","_receiver_picon_local"):
                value=row.get(key)
                if isinstance(value,str):
                    value=value.strip()
                    if value and os.path.isfile(value) and value not in candidates:candidates.append(value)
            displayed=self._displayed_live_picon_for_item(row)
            if displayed and displayed not in candidates:candidates.insert(0,displayed)
            for key in ("stream_icon","picon","logo","logo_url","image","img","pic","cover","cover_url","hd","_visible_provider_art_url"):
                value=row.get(key)
                if isinstance(value,str):
                    value=value.strip()
                    if value and value.lower() not in ("null","none") and value not in candidates:candidates.append(value)
            fallback=_image_url(row)
            if fallback and fallback not in candidates:candidates.append(fallback)
            best="";best_area=-1
            # Do not cap candidates. Some providers populate several stale logo
            # aliases before the one that actually rendered in the plugin.
            for source in candidates:
                local=source if os.path.isfile(str(source or "")) else (_cached_live_picon_path(source,self.profile,row) or "")
                if (not local or not os.path.isfile(local)) and allow_fetch:
                    local=_download_live_portal_temp_picon(source,self.profile,self.client,item=row,timeout=5.5) or ""
                    if not local:local=_download_public_live_picon(source,self.profile,item=row,timeout=5.5) or ""
                if not local or not os.path.isfile(local):continue
                area=0;large=False
                try:
                    if _PILImage is not None:
                        with _PILImage.open(local) as im:
                            w,h=im.size;area=max(1,int(w))*max(1,int(h));large=(int(w)>=220 and int(h)>=132)
                except Exception:pass
                if area>best_area:best=local;best_area=area
                if large and source==displayed:break
            if best and os.path.isfile(best):
                fitted=_fit_live_picon_canvas(best,PERSISTENT_GENERATED_DIR,(220,132)) if callable(_fit_live_picon_canvas) else best
                row["_receiver_picon_local"]=fitted if fitted and os.path.isfile(fitted) else best
                row["_receiver_picon_source_local"]=best
        except Exception as exc:optional_failure("ui.live_bouquet_picon_prepare",exc)
        return row

    def _bouquet_selection_mark(self,slot,item,selected=None):
        try:
            if not (0<=int(slot)<len(self.grid_items or [])):return
            if selected is None:
                selected=self._bouquet_channel_key(item) in (getattr(self,"_bouquet_selected_rows",{}) or {})
            title=str((getattr(self,"_grid_display_titles",{}) or {}).get(int(slot)) or item.get("name") or item.get("title") or _("Channel"))
            title=title.replace("✓ ","",1) if title.startswith("✓ ") else title
            self["item_title%d"%int(slot)].setText(("✓ "+title) if selected else title)
        except Exception as exc:
            optional_failure("ui.live_bouquet_selection_mark",exc)

    def _refresh_bouquet_selection_marks(self):
        if self.media_type!="itv":return
        selected_rows=getattr(self,"_bouquet_selected_rows",{}) or {}
        for slot,item in enumerate(self.grid_items or []):
            if not isinstance(item,dict):continue
            self._bouquet_selection_mark(slot,item,self._bouquet_channel_key(item) in selected_rows)

    def _live_menu_noop(self):
        return

    def _live_menu_layout(self):
        if not getattr(self,"_live_menu_active",False):return
        try:
            from enigma import ePoint,eSize
            count=max(1,min(len(getattr(self,"_live_menu_choices",[]) or []),9))
            row_w=900; row_h=66
            self["live_menu_list"].set_width(row_w)
            phys_w,phys_row_h=_wqhd_wh(row_w,row_h)
            group_h=count*phys_row_h
            try:
                size=self.instance.size();screen_w=int(size.width());screen_h=int(size.height())
            except Exception:
                screen_w,screen_h=_wqhd_wh(1920,1080)
            x=max(0,int((screen_w-phys_w)/2));y=max(0,int((screen_h-group_h)/2))
            inst=self["live_menu_list"].instance
            if inst is not None:
                inst.resize(eSize(phys_w,group_h));inst.move(ePoint(x,y))
        except Exception as exc:optional_failure("ui.live_menu_center",exc)

    def _live_menu_show(self,choices):
        self._live_menu_choices=list(choices or [])
        if not self._live_menu_choices:return
        try:
            # Exact copy/paste of the Details Information dim asset.
            dim=asset("us88_focus_dim_scrim.png")
            if dim and os.path.isfile(dim) and self["live_menu_scrim"].instance is not None:
                self["live_menu_scrim"].instance.setPixmapFromFile(dim)
        except Exception as exc:optional_failure("ui.live_menu_scrim",exc)
        try:
            # Pure text rows only: no glass PNGs, no adaptive generation, no extra frame.
            try:
                if self["live_menu_list"].instance is not None:self["live_menu_list"].instance.setSelectionEnable(0)
            except Exception:pass
            self["live_menu_list"].set_choices(self._live_menu_choices,0)
        except Exception as exc:optional_failure("ui.live_menu_text",exc)
        self._live_menu_active=True
        self._live_menu_layout()
        try:self["live_menu_scrim"].show()
        except Exception:pass
        try:self["live_menu_list"].show()
        except Exception:pass
        try:self["live_menu_actions"].setEnabled(True)
        except Exception:pass

    def _live_menu_close(self):
        if not getattr(self,"_live_menu_active",False):return
        self._live_menu_active=False
        try:self["live_menu_actions"].setEnabled(False)
        except Exception:pass
        try:self["live_menu_list"].hide()
        except Exception:pass
        try:self["live_menu_scrim"].hide()
        except Exception:pass

    def _live_menu_up(self):
        if not getattr(self,"_live_menu_active",False):return
        try:self["live_menu_list"].up();self["live_menu_list"].selection_changed()
        except Exception:pass

    def _live_menu_down(self):
        if not getattr(self,"_live_menu_active",False):return
        try:self["live_menu_list"].down();self["live_menu_list"].selection_changed()
        except Exception:pass

    def _live_menu_page_up(self):
        if not getattr(self,"_live_menu_active",False):return
        try:self["live_menu_list"].pageUp();self["live_menu_list"].selection_changed()
        except Exception:pass

    def _live_menu_page_down(self):
        if not getattr(self,"_live_menu_active",False):return
        try:self["live_menu_list"].pageDown();self["live_menu_list"].selection_changed()
        except Exception:pass

    def _live_menu_accept(self):
        if not getattr(self,"_live_menu_active",False):return
        try:choice=self["live_menu_list"].selected_choice()
        except Exception:choice=None
        self._live_menu_close()
        if choice is not None:self._menu_selected(choice)

    def open_menu(self):
        if self.media_type!="itv":
            return us_func(PremiumGridBase.open_menu)(self)
        if getattr(self,"_live_menu_active",False):
            self._live_menu_close();return
        if getattr(self,"_bouquet_select_mode",False):
            choices=[
                (_("Add selected channels to Bouquet"),"bouquet_add_selected"),
                (_("Select all visible channels"),"bouquet_select_all"),
                (_("Clear channel selection"),"bouquet_clear_selection"),
                (_("Cancel channel selection"),"bouquet_cancel_selection"),
                (_("Refresh page"),"refresh"),
                (_("First page"),"first"),
            ]
        else:
            choices=[
                (_("Add this channel to Bouquet"),"bouquet_add_one"),
                (_("Select channels for Bouquet"),"bouquet_select_mode"),
                (_("Refresh page"),"refresh"),
                (_("First page"),"first"),
                (_("Toggle favorite"),"favorite"),
            ]
            choices[2:2]=lft_menu_choices()
        self._live_menu_show(choices)

    def _menu_selected(self,choice):
        if not choice:return
        action=choice[1]
        if action in LFT_ACTIONS:return self._lft_dispatch(action)
        if action=="bouquet_add_one":return self.add_current_channel_to_bouquet()
        if action=="bouquet_select_mode":return self._start_bouquet_channel_selection()
        if action=="bouquet_add_selected":return self.add_selected_channels_to_bouquet()
        if action=="bouquet_select_all":return self._select_all_visible_bouquet_channels()
        if action=="bouquet_clear_selection":return self._clear_bouquet_channel_selection()
        if action=="bouquet_cancel_selection":return self._cancel_bouquet_channel_selection()
        return us_func(PremiumGridBase._menu_selected)(self,choice)

    def _start_bouquet_channel_selection(self):
        if self.media_type!="itv":return
        self._bouquet_select_mode=True
        self._bouquet_selected_rows={}
        self._refresh_bouquet_selection_marks()
        self["status"].setText(_("Channel selection • OK select/unselect • MENU add to Bouquet"))

    def _select_all_visible_bouquet_channels(self):
        if not getattr(self,"_bouquet_select_mode",False):return
        rows=getattr(self,"_bouquet_selected_rows",None)
        if not isinstance(rows,dict):rows={};self._bouquet_selected_rows=rows
        for slot,item in enumerate(self.grid_items or []):
            if isinstance(item,dict):
                prepared=self._prepare_live_bouquet_row(item,False)
                self._capture_receiver_picon_from_slot(prepared,slot)
                rows[self._bouquet_channel_key(item)]=prepared
        self._refresh_bouquet_selection_marks()
        self["status"].setText(_("%d channel(s) selected • MENU to add")%len(rows))

    def _clear_bouquet_channel_selection(self):
        if not getattr(self,"_bouquet_select_mode",False):return
        self._bouquet_selected_rows={}
        self._refresh_bouquet_selection_marks()
        self["status"].setText(_("Selection cleared • OK selects channels"))

    def _cancel_bouquet_channel_selection(self):
        self._bouquet_select_mode=False
        self._bouquet_selected_rows={}
        self._refresh_bouquet_selection_marks()
        self["status"].setText(_("Ready"))

    def add_current_channel_to_bouquet(self):
        if self._busy or self.media_type!="itv" or not self.grid_items:return
        item=self.grid_items[self.index]
        if not isinstance(item,dict):return
        row=self._prepare_live_bouquet_row(item,False)
        self._capture_receiver_picon_from_slot(row,self.index)
        self._choose_target_bouquet([row],False)

    def add_selected_channels_to_bouquet(self):
        if not getattr(self,"_bouquet_select_mode",False):return
        rows=list((getattr(self,"_bouquet_selected_rows",{}) or {}).values())
        if not rows:
            self["status"].setText(_("Select at least one channel first"));return
        self._choose_target_bouquet(rows,True)

    def _choose_target_bouquet(self,rows,multi):
        try:
            from .core.bouquets import list_tv_bouquets
            bouquets=list_tv_bouquets() or []
        except Exception as exc:
            self["status"].setText(_("Could not read TV bouquets: %s")%exc);return
        if not bouquets:
            try:
                from Screens.MessageBox import MessageBox
                show_notice(self.session, _("No TV bouquets were found on the receiver."), timeout=7, owner=self)
            except Exception:pass
            return
        try:from Screens.ChoiceBox import ChoiceBox
        except Exception:return
        choices=[(str(row.get("name") or row.get("filename")),str(row.get("filename"))) for row in bouquets]
        self._pending_bouquet_rows=[dict(x) for x in rows if isinstance(x,dict)]
        self._pending_bouquet_multi=bool(multi)
        self.session.openWithCallback(self._target_bouquet_chosen,ChoiceBox,title=_("Choose target Bouquet"),list=choices)

    def _target_bouquet_chosen(self,choice):
        if not choice:return
        filename=str(choice[1] if isinstance(choice,(tuple,list)) and len(choice)>1 else "")
        label=str(choice[0] if isinstance(choice,(tuple,list)) and choice else filename)
        rows=[self._prepare_live_bouquet_row(x,False) for x in list(getattr(self,"_pending_bouquet_rows",[]) or []) if isinstance(x,dict)]
        if not filename or not rows:return
        multi=bool(getattr(self,"_pending_bouquet_multi",False))
        cfg=load_settings()
        self["status"].setText(_("Adding %d channel(s) to %s")%(len(rows),label))
        def work(handle):
            if handle.cancelled():return {}
            prepared=[]
            for row in rows:
                if handle.cancelled():return {}
                prepared.append(self._prepare_live_bouquet_row(row,True))
            from .core.bouquets import append_receiver_items_to_bouquet
            return append_receiver_items_to_bouquet(self.profile,prepared,"itv",filename,cfg.get("service_type",4097))
        def ok(result):
            try:
                from .core.bouquets import reload_bouquets,_queue_receiver_epg_seed
                reload_bouquets()
                _queue_receiver_epg_seed((result or {}).get("epg_seed") or [])
            except Exception as exc:optional_failure("ui.live_bouquet_reload",exc)
            added=int((result or {}).get("added") or 0)
            picon_missing=int((result or {}).get("picons_missing") or 0)
            epg_channels=int((result or {}).get("epg_seed_channels") or 0)
            if multi:
                self._bouquet_select_mode=False;self._bouquet_selected_rows={};self._refresh_bouquet_selection_marks()
            self["status"].setText(_("Bouquet updated • %d new channel(s)")%added)
            try:
                LOG.info("Manual bouquet export added=%s picons_missing=%s epg_seed_channels=%s",added,picon_missing,epg_channels)
            except Exception:pass
            try:
                from Screens.MessageBox import MessageBox
                show_notice(self.session, _("Added to Bouquet: %s\n\n%d new channel(s)")%(label,added), timeout=7, owner=self)
            except Exception:pass
        def failed(exc):
            self["status"].setText(_("Bouquet update failed: %s")%exc)
        self._run_async(work,ok,failed)

    def _render_grid(self):
        result=us_func(PremiumGridBase._render_grid)(self)
        if getattr(self,"_bouquet_select_mode",False):
            self._refresh_bouquet_selection_marks()
        try:
            self._em_paint();self._em_schedule()
        except Exception as exc:optional_failure("ui.live_epg_mark_render",exc)
        return result

    # ------------------------------------------------------------------
    # R5.508: "EPG" mark at the right end of every Live row that has a guide.
    # Shares the 3-column/wall EPG cache; the page's guide is fetched in the
    # background (never on the GUI thread) so every row can be marked, not
    # only the focused channel.
    EPG_MARKS=True
    _EM_TTL=15*60
    _EM_NONE_TTL=60
    _EM_KEEP=30*60

    def _em_init(self):
        self._em_known={};self._em_jobs=queue.Queue();self._em_cancel=None;self._em_gen=0
        self._em_future=None;self._em_sig=None;self._em_fetch_timer=None;self._em_drain_timer=None;self._em_refresh_timer=None
        self._em_conns=[]
        if not self.EPG_MARKS:return
        for _i in range(self.page_size):self["epg_mark%d"%_i]=Pixmap()
        def make(callback,name):
            timer=eTimer()
            try:self._em_conns.append(timer.timeout.connect(callback))
            except Exception:timer.callback.append(callback)
            setattr(self,name,timer)
        make(self._em_start,"_em_fetch_timer");make(self._em_drain,"_em_drain_timer");make(self._em_schedule,"_em_refresh_timer")
        self.onLayoutFinish.append(self._em_layout_ready)
        self.onClose.append(self._em_stop)

    def _em_layout_ready(self):
        self._em_hide_all()
        try:self._em_refresh_timer.start(2000,False)
        except Exception:pass

    def _em_hide_all(self):
        for _i in range(self.page_size):
            try:self["epg_mark%d"%_i].hide()
            except Exception:pass

    def _em_portal(self):
        p=getattr(self,"profile",None) or {}
        return "%s|%s"%(str(p.get("portal") or p.get("url") or "").rstrip("/").lower(),str(p.get("mac") or p.get("username") or ""))

    @staticmethod
    def _em_cid(item):
        return str((item or {}).get("id") or (item or {}).get("ch_id") or (item or {}).get("stream_id") or "")

    def _em_note(self,portal,cid,has):
        """Remember whether a channel has a guide (also called by the columns screen)."""
        try:self._em_known[(portal,cid)]=(bool(has),time.monotonic())
        except Exception:pass

    def _em_has_guide(self,item):
        cid=self._em_cid(item)
        if not cid:return False
        portal=self._em_portal()
        try:
            from .ui_live_columns import _cache_get
            hit,data=_cache_get((portal,cid))
            if hit:
                return bool(data and (data.get("events") or (data.get("summary") or {}).get("now")))
        except Exception:pass
        try:
            if (getattr(self,"_epg_cache",{}) or {}).get(cid,{}).get("now"):return True
        except Exception:pass
        known=self._em_known.get((portal,cid))
        if known and time.monotonic()-known[1]<self._EM_KEEP:return bool(known[0])
        return False

    def _em_paint(self):
        if not self.EPG_MARKS or getattr(self,"_screen_closed",False):return
        items=list(getattr(self,"grid_items",None) or [])
        for pos in range(self.page_size):
            try:
                widget=self["epg_mark%d"%pos]
                if pos<len(items) and self._em_has_guide(items[pos]):widget.show()
                else:widget.hide()
            except Exception:pass

    def _em_schedule(self):
        if (not self.EPG_MARKS or getattr(self,"_screen_closed",False)
                or getattr(self,"_grid_images_suspended",False) or not getattr(self,"grid_items",None)):return
        try:
            self._em_fetch_timer.stop();self._em_fetch_timer.start(450,True)
        except Exception:self._em_start()

    def _em_start(self):
        if (not self.EPG_MARKS or getattr(self,"_screen_closed",False)
                or getattr(self,"_grid_images_suspended",False) or self.media_type!="itv"):return
        items=list(getattr(self,"grid_items",None) or [])[:self.page_size]
        portal=self._em_portal()
        from .ui_live_columns import _cache_get, _refresh_ready_epg
        _refresh_ready_epg(self)
        sig=(portal,tuple(self._em_cid(item) for item in items))
        if sig != getattr(self,'_em_retry_page',None):
            self._em_retry_page=sig;self._em_retry_after={}
        future=self._em_future
        if sig==self._em_sig and future is not None and not future.done():return
        if sig!=self._em_sig and future is not None and not future.done():
            if self._em_cancel is not None:self._em_cancel.set()
            future.cancel();self._em_gen+=1
        misses=[];by_cid={}
        for item in items:
            cid=self._em_cid(item)
            if (cid and cid not in misses and time.monotonic()>=self._em_retry_after.get(cid,0)
                    and not _cache_get((portal,cid))[0]):
                misses.append(cid);by_cid[cid]=item
        if not misses:
            self._em_paint();return
        self._em_sig=sig;self._em_gen+=1;gen=self._em_gen
        try:
            if self._em_cancel is not None:self._em_cancel.set()
        except Exception:pass
        ev=threading.Event();self._em_cancel=ev
        client=self.client;jobs=self._em_jobs
        def on_each(cid,rows):
            if ev.is_set() or rows is None:return
            try:self._em_store(portal,cid,rows)
            except Exception as exc:optional_failure("ui.live_epg_mark_store",exc)
            jobs.put((gen,cid))
        def worker():
            try:
                many=getattr(client,"epg_many",None)
                if callable(many):
                    from .ui_live_columns import tiered_epg_many
                    tiered_epg_many(client,dict(by_cid),10,ev,on_each)
                else:
                    for cid in misses:
                        if ev.is_set():return
                        try:rows=client.epg(cid,10,cancel_event=ev) or []
                        except Exception:continue
                        on_each(cid,rows)
            finally:
                jobs.put((gen,None))
        try:
            from .core.shared_executors import METADATA_EXECUTOR
            self._em_future=METADATA_EXECUTOR.submit(worker,_task_key="live-epg-marks:%x"%id(self),_replace_task_key=True)
            self._em_drain_timer.start(300,False)
        except Exception as exc:
            optional_failure("ui.live_epg_mark_submit",exc)

    def _em_store(self,portal,cid,rows):
        from .ui_live_columns import _events_from_rows,_cache_put
        from .ultra import epg_summary
        events=_events_from_rows(rows or [])
        try:summary=epg_summary(rows or []) or {}
        except Exception:summary={}
        if events or summary.get("now"):
            _cache_put((portal,cid),{"events":events[:24],"summary":summary},self._EM_TTL)
            self._em_note(portal,cid,True)
        else:
            _cache_put((portal,cid),None,self._EM_NONE_TTL)
            self._em_note(portal,cid,False)

    def _em_drain(self):
        if getattr(self,"_screen_closed",False):
            self._em_stop();return
        changed=False;done=False
        while True:
            try:gen,cid=self._em_jobs.get_nowait()
            except queue.Empty:break
            if gen!=self._em_gen:continue
            if cid is None:done=True
            else:changed=True
        if changed:self._em_paint()
        if done:
            from .ui_live_columns import _cache_get
            now=time.monotonic();portal=self._em_portal()
            for item in (self.grid_items or [])[:self.page_size]:
                cid=self._em_cid(item)
                if cid and not _cache_get((portal,cid))[0]:self._em_retry_after[cid]=now+15
            try:self._em_drain_timer.stop()
            except Exception:pass

    def _em_stop(self):
        try:
            if self._em_cancel is not None:self._em_cancel.set()
        except Exception:pass
        for name,cb in (("_em_fetch_timer",self._em_start),("_em_drain_timer",self._em_drain),("_em_refresh_timer",self._em_schedule)):
            try:
                timer=getattr(self,name,None)
                if timer is not None:
                    timer.stop()
                    try:
                        if cb in timer.callback:timer.callback.remove(cb)
                    except Exception:pass
            except Exception:pass
        for conn in list(getattr(self,"_em_conns",[]) or []):
            try:
                if conn is not None:conn.disconnect()
            except Exception:pass
        self._em_conns=[]

    def _grid_set_local(self,slot,path):
        """Paint Live picons without ever blocking the Enigma2 GUI thread.

        Older code trimmed/scaled provider picons with Pillow synchronously here.
        OpenATV 8.0 can spend long enough inside those image operations that the
        whole GUI appears frozen and BACK cannot be processed.  Paint the local
        source immediately, then prepare the exact fitted derivative off-thread.
        """
        source=str(path or "")
        render_path=source
        try:
            is_placeholder=(not source or os.path.basename(source)==os.path.basename(asset(self.placeholder)))
            is_fitted=(source and os.path.basename(os.path.dirname(source))=="live_row_picon_fit")
            # First paint must be GUI-cheap.  If the exact 64x36 derivative is
            # already on disk (stat + hash only) paint THAT, so the row is crisp
            # 1:1 immediately; otherwise paint the source and fit it off-thread.
            try:
                from .ui_artwork_helpers import _live_row_fit_cached
                if is_placeholder:
                    try:self._live_row_src.pop(int(slot),None)
                    except Exception:pass
                if not is_placeholder and not is_fitted and source:
                    try:self._live_row_src[int(slot)]=source
                    except AttributeError:self._live_row_src={int(slot):source}
                    ready=_live_fit_ready(source,(64,36))
                    if ready:
                        render_path=ready;is_fitted=True
                    elif source not in _LIVE_FIT_FAILED:
                        # R5.170: never flash the raw oversized provider picon while the
                        # exact row derivative is being prepared; keep the placeholder.
                        render_path=asset(self.placeholder)
            except Exception as exc:optional_failure("ui.live_row_cached_fit",exc)
            result=us_func(PremiumGridBase._grid_set_local)(self,slot,render_path)
            if is_placeholder or is_fitted or not os.path.isfile(source):
                return result

            generation=int(getattr(self,"_grid_generation",0) or 0)
            token=(generation,int(slot),source)
            pending=getattr(self,"_live_row_fit_pending",None)
            if pending is None:
                self._live_row_fit_pending=set();pending=self._live_row_fit_pending
            if token in pending or getattr(self,"_screen_closed",False) or getattr(self,"_grid_closed",False):
                return result
            pending.add(token)

            def worker(gen=generation,pos=int(slot),src=source,key=token):
                fitted=src
                try:
                    if getattr(self,"_screen_closed",False) or getattr(self,"_grid_closed",False):
                        return
                    fitted=_fit_live_row_picon_canvas(src,PERSISTENT_GENERATED_DIR,(64,36)) or src
                    if fitted==src:_LIVE_FIT_FAILED.add(src);self._grid_download_jobs.put((gen,pos,str(src),"live_fit"))
                    if (fitted!=src and os.path.isfile(str(fitted))
                            and gen==int(getattr(self,"_grid_generation",0) or 0)
                            and not getattr(self,"_screen_closed",False)
                            and not getattr(self,"_grid_closed",False)):
                        self._grid_download_jobs.put((gen,pos,str(fitted),"live_fit"))
                except Exception as exc:
                    optional_failure("ui.live_row_render_fit_async",exc)
                finally:
                    try:pending.discard(key)
                    except Exception:pass
            try:
                _LIVE_ROW_FIT_EXECUTOR.submit(worker)
            except Exception as exc:
                pending.discard(token)
                optional_failure("ui.live_row_render_fit_submit",exc)
            return result
        except Exception as exc:
            optional_failure("ui.live_row_render_fit",exc)
            return us_func(PremiumGridBase._grid_set_local)(self,slot,render_path)

    def _stop_live_grid_hooks(self):
        for result_queue_name in ("_preview_jobs",):
            result_queue=getattr(self,result_queue_name,None)
            if result_queue is None:continue
            try:
                while True:result_queue.get_nowait()
            except queue.Empty:
                pass
            except Exception as exc:
                optional_failure("ui.live_grid_queue_cleanup",exc)
        for hook_name,callback in (
            ("onLayoutFinish",self._prepare_preview_window),
            ("onLayoutFinish",self._apply_live_static_chrome),
        ):
            try:
                hooks=getattr(self,hook_name,None)
                if hooks is not None and callback in hooks:hooks.remove(callback)
            except Exception as exc:
                optional_failure("ui.live_grid_hook_cleanup",exc)

    def _prepare_preview_window(self):
        # session.VideoPicture + Renderer/Pig owns decoder-0 geometry.
        # eVideoWidget applies the preview rectangle when shown and restores full
        # screen automatically when the screen/renderer is hidden.
        try:LOG.info("Live preview Pig renderer ready rect=%s", self.PREVIEW_RECT)
        except Exception as exc:optional_failure("ui",exc)

    def _apply_live_static_chrome(self):
        """Bind the approved Cinematic Details master material, prebuilt locally."""
        try:
            chrome={
                "page":asset("ultra_bg_clean_1920x1080.png"),
                "selected":asset("live_clean_r376/selected_748x58.png"),
                "preview":asset("live_static_preview_purple.png"),
                "info":asset("live_clean_r376/info_940x244.png"),
                "tech":asset("live_clean_r376/tech_205x46.png"),
                # Normal rows are drawn once by the skin; avoid double shading.
                "counter":asset("live_clean_r376/counter_575x54.png"),
                "accent":(0,230,118),
            }
            self._apply_live_chrome(chrome)
            for index in range(self.page_size):
                self["row_adaptive%d" % index].hide()
            self._live_static_chrome_bound=True
        except Exception as exc:optional_failure("ui.live_static_chrome",exc)

    # Compatibility alias for any older return/rebind path. It is static now.

    def _apply_live_chrome(self,chrome):
        if not isinstance(chrome,dict):return
        # Retain bundled/last-good chrome. An unchanged native widget keeps its
        # pixmap; only a new path or explicit decoder-return recovery rereads it.
        try:self._live_last_chrome=dict(chrome)
        except Exception:self._live_last_chrome={}
        try:
            bound=getattr(self,"_live_chrome_bindings",None)
            if bound is None:
                bound=self._live_chrome_bindings={}
            def bind(widget,path):
                inst=self[widget].instance
                if not path or inst is None:return
                signature=(id(inst),path)
                if bound.get(widget)!=signature:
                    if not os.path.isfile(path):return
                    # Reuse small immutable chrome across the three Live modes.
                    # The full-screen background stays widget-owned to avoid
                    # keeping another large native surface in the icon cache.
                    if widget!='page_adaptive_bg':
                        from .ui import cached_png
                        pointer=cached_png(path)
                    else:pointer=None
                    if pointer is not None:inst.setPixmap(pointer)
                    else:inst.setPixmapFromFile(path)
                    bound[widget]=signature
                self[widget].show()
            for key,widget in (("page","page_adaptive_bg"),("selected","selection"),("preview","preview_frame"),("info","live_info_bg"),("counter","page_label_bg")):
                path=chrome.get(key)
                if path:bind(widget,path)
            tech=chrome.get("tech")
            if tech and os.path.isfile(tech):
                for name in ("tech_bg1","tech_bg2","tech_bg3","tech_bg4"):
                    bind(name,tech)
            rowglass=chrome.get("row")
            if rowglass and os.path.isfile(rowglass):
                for _ri in range(self.page_size):
                    bind("row_adaptive%d"%_ri,rowglass)
            accent=chrome.get("accent")
            if accent:
                color="#%02x%02x%02x"%tuple(accent[:3])
                try:self["now_progress"].instance.setForegroundColor(parseColor(color))
                except Exception as exc:optional_failure("ui.silent_guard",exc)
                try:self["channel_name"].instance.setForegroundColor(parseColor(color))
                except Exception as exc:optional_failure("ui.silent_guard",exc)
        except Exception as exc:optional_failure("ui.live211_apply",exc)

    def _force_live_visual_rebind(self):
        """Restore fixed Live chrome plus retained picons after Full Screen."""
        if getattr(self,"_screen_closed",False):return
        _r58_rebind_mono=time.monotonic()
        self._live_chrome_bindings={}
        try:self._apply_live_static_chrome()
        except Exception as exc:optional_failure("ui.live_force_static",exc)
        for slot,path in list((getattr(self,"_grid_slot_paths",{}) or {}).items()):
            if slot >= len(getattr(self,"grid_items",[]) or []):continue
            try:
                ptr=self._grid_cache_get(path) if path else None
                if ptr is not None:self._grid_set_ptr(slot,ptr)
                elif path and os.path.isfile(path):self._grid_set_local(slot,path)
            except Exception as exc:optional_failure("ui.live_force_art",exc)
        try:self._update_selection()
        except Exception as exc:optional_failure("ui.live_force_selection",exc)
        try:
            LOG.info("PERF58 live_return_rebind page=%s index=%s slots=%s elapsed_ms=%s",self.page,self.index,len(getattr(self,"_grid_slot_paths",{}) or {}),int((time.monotonic()-_r58_rebind_mono)*1000.0))
        except Exception:pass

    def _grid_queue_decode(self,generation,slot,path):
        # Live picons are tiny, already-local display assets. On OpenBH
        # the shared ePicLoad queue used for large posters can complete without a
        # usable Live pixmap callback on some image/provider combinations. Render
        # the prepared local picon directly into artN and keep ePicLoad for VOD/
        # Series only. This also makes the final Live stage deterministic: once
        # download/cache produced a valid file, the row gets that exact file.
        if generation!=getattr(self,"_grid_generation",generation):
            _live_picon_diag("RENDER_STALE slot=%r generation=%r current=%r path=%r"%(slot,generation,getattr(self,"_grid_generation",None),path))
            return
        _live_picon_diag("RENDER_ENTER slot=%r path=%r exists=%r size=%r"%(slot,path,bool(path and os.path.isfile(path)),(os.path.getsize(path) if path and os.path.isfile(path) else -1)))
        if path and os.path.isfile(path):
            try:
                self._grid_slot_paths[slot]=path
                self._grid_palette_sources[slot]=path
                self._grid_set_local(slot,path)
                _live_picon_diag("RENDER_SET_LOCAL_OK slot=%r channel=%r path=%r widget_instance=%r"%(slot,str((self.grid_items[slot] if self.grid_items and 0<=slot<len(self.grid_items) else {}).get("name") or ""),path,getattr(self["art%d"%slot],"instance",None) is not None))
                if self.media_type=="itv":
                    try:LOG.info("Live picon direct render slot=%s channel=%r path=%s",slot,str((self.grid_items[slot] if self.grid_items and 0<=slot<len(self.grid_items) else {}).get("name") or ""),path)
                    except Exception:pass
                return
            except Exception as exc:
                optional_failure("ui.live_direct_picon_render",exc)
        # Defensive fallback only; valid Live cache files should never need it.
        us_func(PremiumGridBase._grid_queue_decode)(self,generation,slot,path)

    @staticmethod
    def _preview_key(item):
        return str((item or {}).get("id") or (item or {}).get("ch_id") or (item or {}).get("cmd") or (item or {}).get("name") or "")

    def _drain_jobs(self):
        us_func(PremiumGridBase._drain_jobs)(self)
        if self._screen_closed:return
        while True:
            try:
                job=self._preview_jobs.get_nowait();callback,value,is_error=job[:3];task_id=job[3] if len(job)>3 else None
            except queue.Empty:break
            except Exception:continue
            if task_id is not None and self._preview_task_id is not None and task_id!=self._preview_task_id:continue
            self._preview_handle=None;self._preview_task_id=None
            if callback:
                try:callback(value)
                except Exception:
                    try:self["preview_status"].setText(_("Preview unavailable"))
                    except Exception as exc:optional_failure("ui",exc)
            elif is_error:
                try:self["preview_status"].setText(_("Preview unavailable"))
                except Exception as exc:optional_failure("ui",exc)

    def _cancel_preview_request(self):
        handle=self._preview_handle;self._preview_handle=None;self._preview_task_id=None;self._pending_preview_key=None
        try:self._preview_ready_timer.stop()
        except Exception as exc:optional_failure("ui",exc)
        self._preview_pending_url=None;self._preview_pending_item=None;self._preview_pending_engine=None;self._preview_engine_candidates=[];self._preview_engine_pos=0;self._preview_poll_count=0
        if handle is not None:
            try:handle.cancel()
            except Exception as exc:optional_failure("ui",exc)

    def _fit_live_epg_line(self,name,max_size=21,min_size=11):
        """Keep complete NOW/NEXT text visible inside the fixed Live info card."""
        try:
            widget=self[name];inst=widget.instance
            if inst is None:return
            # Live Wall/Columns park these two labels off-screen at 1x1; fitting an
            # invisible label forced ~24 relayouts per key press for nothing.
            try:
                if int(inst.size().width())<=2:return
            except Exception:pass
            value=" ".join(str(widget.getText() or "").replace("\n"," ").split())
            if hasattr(inst,"setNoWrap"):inst.setNoWrap(1)
            width=max(120,int(inst.size().width())-12)
            chosen=int(max_size)
            for size in range(int(max_size),int(min_size)-1,-1):
                inst.setFont(gFont("Regular",_wqhd_font(size)))
                try:measured=int(inst.calculateSize().width())
                except Exception:measured=0
                # OpenBH can under-estimate mixed-script shaping a little.
                if measured<=0 or int(measured*1.08)<=width:
                    chosen=size;break
                chosen=max(int(min_size),size-1)
            inst.setFont(gFont("Regular",_wqhd_font(chosen)))
        except Exception as exc:optional_failure("ui.live_epg_font_fit",exc)

    def _update_header(self,item):
        us_func(PremiumGridBase._update_header)(self,item)
        try:
            self._fit_live_epg_line("rating",21,11)
            self._fit_live_epg_line("meta1",19,11)
            cid=str(item.get("id") or item.get("ch_id") or "");epg=self._epg_cache.get(cid,{})
            self["now_progress"].setValue(int(epg.get("percent") or 0))
        except Exception as exc:optional_failure("ui",exc)

    def _update_selection(self):
        us_func(PremiumGridBase._update_selection)(self)
        if not self.grid_items:return
        item=self.grid_items[self.index];raw=item.get("name") or item.get("title") or "Channel"
        clean_name=_clean_display_text(_clean_live_channel_name(raw,bool((self._grid_settings or {}).get("clean_titles",True))),80)
        self["channel_name"].setText(clean_name)
        # Responsive one-line title. Keep short names bold/large, reduce only when
        # the actual label gets long enough to risk clipping its 820px card.
        try:
            units=sum(1.65 if ord(ch)>0x2ff else (0.58 if ch in " ilI1|.,:'" else 1.0) for ch in clean_name)
            font_size=32 if units<=26 else (29 if units<=34 else (26 if units<=43 else (23 if units<=53 else 20)))
            if self["channel_name"].instance is not None:self["channel_name"].instance.setFont(gFont("Regular",_wqhd_font(font_size)))
        except Exception as exc:optional_failure("ui.live_title_font",exc)
        q=quality_badges(raw) or _("AUTO");self["tech1"].setText(q[:16])
        self["tech2"].setText(_("Catch-up") if (item.get("allow_archive") or item.get("tv_archive_duration") or item.get("archive")) else _("LIVE"))
        self["tech3"].setText(_("Channel %d")%max(1,(int(self.page or 1)-1)*int(self.page_size or 1)+int(self.index)+1))
        key=self._preview_key(item)
        if self._pending_preview_key:
            self["preview_status"].setText(_("Loading preview..."));self["tech4"].setText(_("Loading...") if key==self._pending_preview_key else _("OK Preview"))
        elif self._active_preview_key:
            self["preview_status"].setText("");self["tech4"].setText(_("OK Full Screen") if key==self._active_preview_key else _("OK Preview"))
        else:
            self["preview_status"].setText("");self["tech4"].setText(_("OK Preview"))

    def _live_nav_total(self):
        try:return max(len(self.grid_items or []),int(self._portal_total or 0))
        except Exception:return len(self.grid_items or [])

    def _live_nav_absolute(self):
        return max(0,(int(self.page or 1)-1)*int(self.page_size or 1)+int(self.index or 0))

    def _live_nav_go_absolute(self,absolute):
        total=self._live_nav_total()
        if total<=0:return
        absolute=max(0,min(total-1,int(absolute)))
        target_page=absolute//self.page_size+1
        target_index=absolute%self.page_size
        if target_page==self.page and self.grid_items:
            self.index=min(target_index,max(0,len(self.grid_items)-1))
            self._update_selection();self._update_page_counter()
        else:
            self.load_page(target_page,target_index)

    def move_up(self):
        """Exact Mini List rule: previous item globally; #1 wraps to final channel."""
        if not self.grid_items or not self._nav_allowed():return
        total=self._live_nav_total()
        if total<=0:return
        current=self._live_nav_absolute()
        self._live_nav_go_absolute((current-1)%total)

    def move_down(self):
        """Exact Mini List rule: next item globally; final channel wraps to #1."""
        if not self.grid_items or not self._nav_allowed():return
        total=self._live_nav_total()
        if total<=0:return
        current=self._live_nav_absolute()
        self._live_nav_go_absolute((current+1)%total)

    def _live_page_shift(self,direction):
        """Exact Mini List LEFT/RIGHT page rule with the same row preserved."""
        if not self.grid_items or not self._nav_allowed():return
        total=self._live_nav_total()
        if total<=0:return
        page_size=max(1,int(self.page_size or 1))
        current_abs=self._live_nav_absolute()
        current_page=current_abs//page_size
        row=current_abs%page_size
        last_page=max(0,(total-1)//page_size)

        if int(direction)<0:
            if current_page<=0:
                target=0
            else:
                target=(current_page-1)*page_size+row
        else:
            if current_page>=last_page:
                target=total-1
            else:
                target=min(total-1,(current_page+1)*page_size+row)
        self._live_nav_go_absolute(target)

    def move_left(self):
        self._live_page_shift(-1)

    def move_right(self):
        self._live_page_shift(1)

    def open_selected(self):
        if self._busy or not self.grid_items:return
        item=self.grid_items[self.index]
        if getattr(self,"_bouquet_select_mode",False):
            if not isinstance(item,dict):return
            key=self._bouquet_channel_key(item)
            rows=getattr(self,"_bouquet_selected_rows",None)
            if not isinstance(rows,dict):
                rows={};self._bouquet_selected_rows=rows
            if key in rows:
                rows.pop(key,None);selected=False
            else:
                prepared=self._prepare_live_bouquet_row(item,False)
                self._capture_receiver_picon_from_slot(prepared,self.index)
                rows[key]=prepared;selected=True
            self._bouquet_selection_mark(self.index,item,selected)
            self["status"].setText(_("%d channel(s) selected • MENU to add")%len(rows))
            return
        key=self._preview_key(item)
        if self._active_preview_key==key and self._active_preview_url:
            self._open_preview_fullscreen(item)
        elif key and key==getattr(self,"_last_fullscreen_key",""):
            # Returning to the same folder/channel should not force the viewer
            # through Preview again. Resolve a fresh link and go straight back
            # to Full Screen.
            self._open_direct_fullscreen(item)
        else:
            self._start_preview_request(item)

    def _open_direct_fullscreen(self,item):
        if not isinstance(item,dict) or self._screen_closed:return
        self._preview_token+=1;token=self._preview_token;self._cancel_preview_request()
        self["preview_status"].setText(_("Opening channel..."));self["tech4"].setText(_("Opening..."))
        def work():return self.client.create_link(item,"itv")
        def ok(url):
            if token!=self._preview_token or self._screen_closed:return
            url=url.strip() if isinstance(url,str) else ""
            if not url:
                try:self["preview_status"].setText(_("Stream unavailable"));self["tech4"].setText(_("OK Preview"))
                except Exception as exc:optional_failure("ui",exc)
                return
            cfg=load_settings();engine=_configured_playback_engine(cfg)
            self._launch_live_fullscreen(item,url,engine,False)
        def fail(err):
            if token==self._preview_token and not self._screen_closed:
                try:self["preview_status"].setText(_("Stream unavailable"));self["tech4"].setText(_("OK Preview"))
                except Exception as exc:optional_failure("ui",exc)
        try:
            handle=TASKS.submit(work,self._preview_jobs,ok=ok,fail=fail);self._preview_handle=handle;self._preview_task_id=getattr(handle,"task_id",None) if handle is not None else None
        except Exception:fail(None)

    def _start_preview_request(self,item):
        if not isinstance(item,dict) or self._screen_closed:return
        self._us_preview_cover(True,item)
        self._preview_token+=1;token=self._preview_token;self._cancel_preview_request();key=self._preview_key(item);self._pending_preview_key=key
        self._perf58_preview_req_mono=time.monotonic()
        try:LOG.info("PERF58 live_preview_request page=%s index=%s key=%s",self.page,self.index,key)
        except Exception:pass
        self["preview_status"].setText(_("Loading preview..."));self["tech4"].setText(_("Loading..."))
        def work():return self.client.create_link(item,"itv")
        def ok(url):
            if token!=self._preview_token or self._screen_closed:return
            if not isinstance(url,str) or not url.strip():
                self._pending_preview_key=None;self["preview_status"].setText(_("Preview unavailable"));self["tech4"].setText(_("OK Preview"));return
            try:LOG.info("PERF58 live_preview_link_ready page=%s index=%s elapsed_ms=%s",self.page,self.index,int((time.monotonic()-getattr(self,"_perf58_preview_req_mono",time.monotonic()))*1000.0))
            except Exception:pass
            self._begin_preview_video(url.strip(),item,key)
        def fail(err):
            if token==self._preview_token:
                self._pending_preview_key=None
                try:self["preview_status"].setText(_("Preview unavailable"));self["tech4"].setText(_("OK Preview"))
                except Exception as exc:optional_failure("ui",exc)
        try:
            handle=TASKS.submit(work,self._preview_jobs,ok=ok,fail=fail);self._preview_handle=handle;self._preview_task_id=getattr(handle,"task_id",None) if handle is not None else None
        except Exception:fail(None)

    def _preview_main_engines(self,url):
        cfg=load_settings()
        try:engine=int(cfg.get("service_type",4097))
        except Exception:engine=4097
        if engine not in (1,4097,5001,5002,8193):engine=4097
        return [engine]


    def _begin_preview_video(self,url,item,key):
        self._perf58_preview_video_mono=time.monotonic()
        self._preview_restore_state=(self._active_preview_key,self._active_preview_url,self._active_preview_item,self._active_preview_engine)
        self._preview_pending_url=url;self._preview_pending_item=dict(item);self._pending_preview_key=key;self._preview_engine_candidates=self._preview_main_engines(url);self._preview_engine_pos=0
        self._try_preview_engine()

    def _try_preview_engine(self):
        try:self._preview_ready_timer.stop()
        except Exception as exc:optional_failure("ui",exc)
        if self._screen_closed:return
        if self._preview_engine_pos>=len(self._preview_engine_candidates):self._preview_failed_restore();return
        engine=self._preview_engine_candidates[self._preview_engine_pos];self._preview_engine_pos+=1;self._preview_pending_engine=engine;self._preview_poll_count=0
        url=self._preview_pending_url or "";item=self._preview_pending_item or {}
        try:
            play_url=url
            if int(engine) in (4097, 8193):
                try:
                    from .stream_relay import wrap as _relay_wrap
                    play_url=_relay_wrap(url)
                except Exception as exc:optional_failure("ui.stream_relay",exc)
            ref=eServiceReference(int(engine),0,play_url);ref.setName(str(item.get("name") or item.get("title") or _("Live preview")))
            result=self.session.nav.playService(ref)
            if result is False:raise RuntimeError("engine %s rejected preview"%engine)
            self._main_preview_reference=ref
            self["preview_status"].setText(_("Starting preview..."))
            try:LOG.info("Live preview Pig/decoder0 start engine=%s",engine)
            except Exception as exc:optional_failure("ui",exc)
            self._preview_ready_timer.start(250,True)
        except Exception as exc:
            try:LOG.exception("Live preview decoder0 start failed: %s",exc)
            except Exception as exc:optional_failure("ui",exc)
            self._try_preview_engine()

    @staticmethod
    def _read_decoder_dimension(path):
        try:
            with open(path,"r") as handle:
                raw=handle.read().strip().lower()
            if not raw:return 0
            if raw.startswith("0x"):raw=raw[2:]
            try:return int(raw,16)
            except Exception:return int(raw,10)
        except Exception:return 0

    def _main_video_size(self):
        width=height=0
        try:
            current=self.session.nav.getCurrentlyPlayingServiceReference()
            if current is None:return 0,0
            service=self.session.nav.getCurrentService();info=service and service.info()
            if info is not None:
                width=int(info.getInfo(iServiceInformation.sVideoWidth) or 0);height=int(info.getInfo(iServiceInformation.sVideoHeight) or 0)
        except Exception:width=height=0
        if width<=0 or height<=0:
            for base in ("/proc/stb/vmpeg/0","/proc/stb/video/0"):
                w=self._read_decoder_dimension(base+"/xres");h=self._read_decoder_dimension(base+"/yres")
                if w>0 and h>0:width,height=w,h;break
        return width,height

    def _check_preview_ready(self):
        if self._screen_closed:return
        width,height=self._main_video_size()
        current_ok=False
        try:
            cur=self.session.nav.getCurrentlyPlayingServiceReference()
            current_ok=(cur is not None and self._main_preview_reference is not None and cur.toString()==self._main_preview_reference.toString())
        except Exception:current_ok=False
        if current_ok and width>0 and height>0:
            key=self._pending_preview_key;item=self._preview_pending_item or {};url=self._preview_pending_url or ""
            self._active_preview_key=key;self._active_preview_url=url;self._active_preview_item=dict(item);self._active_preview_engine=self._preview_pending_engine
            self._pending_preview_key=None;self._preview_pending_url=None;self._preview_pending_item=None;self._preview_restore_state=None
            self["preview_status"].setText("");current=self.grid_items[self.index] if self.grid_items else {}
            self["tech4"].setText(_("OK Full Screen") if self._preview_key(current)==self._active_preview_key else _("OK Preview"))
            self._us_preview_cover(False)
            try:LOG.info("Live preview Pig/decoder0 ready %sx%s",width,height)
            except Exception as exc:optional_failure("ui",exc)
            try:
                _r58_now=time.monotonic()
                LOG.info("PERF58 live_preview_ready page=%s index=%s size=%sx%s video_ms=%s total_ms=%s",self.page,self.index,width,height,int((_r58_now-getattr(self,"_perf58_preview_video_mono",_r58_now))*1000.0),int((_r58_now-getattr(self,"_perf58_preview_req_mono",_r58_now))*1000.0))
            except Exception:pass
            return
        self._preview_poll_count+=1
        if self._preview_poll_count<24:self._preview_ready_timer.start(250,True);return
        try:LOG.warning("Live preview Pig/decoder0 engine %s never reported video",self._preview_pending_engine)
        except Exception as exc:optional_failure("ui",exc)
        self._try_preview_engine()

    def _preview_failed_restore(self):
        # Deterministic preview: one start attempt for the requested channel.
        # Never recreate the previous decoder/service automatically when a new
        # preview fails; repeated hidden restore cycles were visible in dmesg as
        # VIDEO_STOP/VIDEO_PLAY churn and can leak Broadcom native memory.
        self._pending_preview_key=None
        failed_url=self._preview_pending_url or ""
        self._preview_pending_url=None;self._preview_pending_item=None;self._preview_pending_engine=None
        self._preview_restore_state=None;self._main_preview_reference=None
        self._preview_engine_candidates=[];self._preview_engine_pos=0
        self["preview_status"].setText(_("Preview unavailable"));self["tech4"].setText(_("OK Preview"))
        try:force_session_silence(self.session,failed_url,force=True)
        except Exception as exc:optional_failure("ui.preview_failed_stop",exc)


    def _open_preview_fullscreen(self,item):
        url=self._active_preview_url
        if not url:return self._start_preview_request(item)
        cfg=load_settings();engine=_configured_playback_engine(cfg)
        self._launch_live_fullscreen(item,url,engine,True)

    def _resolve_live_epg_summary(self, row):
        if not isinstance(row, dict):
            return {}
        cid = str(row.get("id") or row.get("ch_id") or row.get("channel_id") or row.get("stream_id") or "")
        if not cid:
            return {}
        summary = (getattr(self, "_epg_cache", {}) or {}).get(cid, {})
        if isinstance(summary, dict) and (summary.get("now") or summary.get("next")):
            return summary
        try:
            from .ui_live_columns import _cache_get, _now_state
            hit, data = _cache_get((self._em_portal(), cid))
            if hit and isinstance(data, dict):
                summ = data.get("summary")
                if isinstance(summ, dict) and (summ.get("now") or summ.get("next")):
                    return summ
                events = data.get("events") or []
                if events:
                    now_ts = int(time.time())
                    pos, _pct = _now_state(data, now_ts)
                    current = events[pos] if pos >= 0 else None
                    future = next((ev for ev in events if ev[0] > now_ts and ev is not current), None)
                    out = {}
                    if current and len(current) > 2 and current[2]:
                        out["now"] = str(current[2])
                    if future and len(future) > 2 and future[2]:
                        out["next"] = str(future[2])
                    return out
        except Exception:
            pass
        return {}

    def _launch_live_fullscreen(self,item,url,engine,reuse_current):
        name=str(item.get("name") or item.get("title") or "Live channel")
        key=self._preview_key(item);selected_index=self.index
        try:
            recent_item=dict(item)
            recent_item["_live_category_id"]=str(self.genre or "*")
            recent_item["_live_folder_title"]=str(self.category_title or _("Live TV"))
            recent_item["_live_absolute_index"]=max(0,(int(self.page)-1)*int(self.page_size)+int(selected_index))
            recent_item["_live_folder_page"]=int(self.page)
            recent_item["_live_page_size"]=int(self.page_size)
            recent_item["_live_folder_total"]=int(self._portal_total or len(self.grid_items or []))
        except Exception:
            recent_item=item
        add_recently_played(self.profile,"itv",recent_item)
        try:LOG.info("PERF58 live_fullscreen_launch page=%s index=%s reuse=%s engine=%s",self.page,selected_index,bool(reuse_current),engine)
        except Exception:pass
        self._last_fullscreen_key=key
        try:
            _state=dict(_GRID_NAV_STATE.get(self._session_nav_key,{}) or {})
            _state["last_fullscreen_key"]=key
            _GRID_NAV_STATE[self._session_nav_key]=_state
        except Exception as exc:optional_failure("ui.silent_guard",exc)
        def returned(result=None):
            if self._screen_closed:return

            # UltraStalkerPlayer EXIT already hard-stops the owned IPTV service
            # and restores the receiver service captured at the plugin boundary.
            # Do NOT call force_session_silence() here: its native stop would kill
            # that just-restored TV service. Do NOT auto-start the portal preview
            # either: that was recreating the fullscreen channel behind the UI,
            # leaving its audio alive until another service replaced it.
            self._main_preview_reference=None
            self._active_preview_key=None;self._active_preview_url=None;self._active_preview_item=None;self._active_preview_engine=None
            self._pending_preview_key=None;self._preview_pending_url=None;self._preview_pending_item=None
            self._preview_pending_engine=None;self._preview_engine_candidates=[];self._preview_engine_pos=0
            self["preview_status"].setText("");self["tech4"].setText(_("OK Preview"))
            self.index=max(0,min(selected_index,len(self.grid_items)-1)) if self.grid_items else 0

            # The restored receiver TV remains the service shown by the Pig/video
            # window. Rebind all Ultra Stalker adaptive/glass layers around it.
            _r58_return_mono=time.monotonic()
            try:self._force_live_visual_rebind()
            except Exception as exc:optional_failure("ui.live_return_chrome",exc)
            try:LOG.info("PERF58 live_fullscreen_return page=%s index=%s rebind_total_ms=%s",self.page,self.index,int((time.monotonic()-_r58_return_mono)*1000.0))
            except Exception:pass
        payload=_player_payload(item,self.profile,media_type="itv")
        payload["_player_client_ref"]=self.client;payload["_live_client_ref"]=self.client
        try:
            _summary=self._resolve_live_epg_summary(item)
            if isinstance(_summary,dict):
                if _summary.get("now"):payload["now"]=str(_summary.get("now"))
                if _summary.get("next"):payload["next"]=str(_summary.get("next"))
        except Exception as exc:optional_failure("ui.live_player_epg_payload",exc)
        snapshot=[]
        for _src in list(self.grid_items or []):
            if not isinstance(_src,dict):continue
            _row=dict(_src)
            try:
                _summary=self._resolve_live_epg_summary(_row)
                if isinstance(_summary,dict):
                    if _summary.get("now"):_row["now"]=str(_summary.get("now"))
                    if _summary.get("next"):_row["next"]=str(_summary.get("next"))
            except Exception:pass
            snapshot.append(_row)
        absolute_index=max(0,(int(self.page)-1)*int(self.page_size)+int(selected_index))
        payload["_live_folder_channels"]=snapshot
        payload["_live_absolute_index"]=absolute_index
        payload["_live_folder_total"]=int(self._portal_total or len(snapshot))
        payload["_live_page_size"]=int(self.page_size)
        payload["_live_folder_page"]=int(self.page)
        payload["_live_folder_title"]=str(self.category_title or _("Live TV"))
        payload["_live_category_id"]=str(self.genre or "*")
        payload["_live_categories"]=[dict(x) for x in (getattr(self,"_live_categories",[]) or []) if isinstance(x,dict)]
        payload["_live_page_loader"]=self._grid_page_data
        payload["_live_client_ref"]=self.client
        _r58_open_mono=time.monotonic()
        self.session.openWithCallback(returned,UltraStalkerPlayer,url,name,"itv",engine,payload,bool(reuse_current))
        try:LOG.info("PERF58 live_fullscreen_open_return page=%s index=%s elapsed_ms=%s",self.page,selected_index,int((time.monotonic()-_r58_open_mono)*1000.0))
        except Exception:pass

    def _stop_live_preview(self):
        try:self._preview_ready_timer.stop()
        except Exception as exc:optional_failure("ui",exc)
        try:
            if self._preview_ready_conn is not None:self._preview_ready_conn.disconnect()
        except Exception as exc:optional_failure("ui",exc)
        try:
            if self._check_preview_ready in self._preview_ready_timer.callback:self._preview_ready_timer.callback.remove(self._check_preview_ready)
        except Exception as exc:optional_failure("ui.preview_timer_callback",exc)
        preview_url=self._active_preview_url or self._preview_pending_url or ""
        self._preview_token+=1;self._cancel_preview_request()
        self._main_preview_reference=None
        self._active_preview_key=None;self._active_preview_url=None;self._active_preview_item=None;self._active_preview_engine=None
        # R5.68: leaving Live must silence any portal preview AND give the
        # receiver its own TV service back (it used to stay silent, or keep the
        # portal stream running).  The receiver's channel is never stopped.
        try:
            nav=getattr(self.session,"nav",None)
            cur=nav.getCurrentlyPlayingServiceReference() if nav is not None else None
            cur_s=cur.toString() if cur is not None else ""
            try:
                from . import ui as _u
                orig=_u._plugin_original_service_string()
            except Exception:
                orig=""
            low=cur_s.lower()
            portal_stream=bool(preview_url) or (bool(cur_s) and cur_s!=orig and ("http" in low or "%3a//" in low))
            if portal_stream:
                force_session_silence(self.session,preview_url,force=True)
                if orig and nav is not None:
                    try:
                        from enigma import eServiceReference as _ESR
                        nav.playService(_ESR(orig))
                    except Exception as exc:optional_failure("ui.preview_close_restore",exc)
        except Exception as exc:optional_failure("ui.preview_close_stop",exc)

    def _hide_preview_cover_on_layout(self):
        # DreamOS: GUISkin cannot exec a lambda callback here.
        self._us_preview_cover(False)

    def _us_preview_cover(self,show,item=None):
        try:
            if not show:
                self["preview_cover"].hide();self["preview_cover_art"].hide();return
            path=""
            try:
                pos=self.grid_items.index(item) if (isinstance(item,dict) and item in self.grid_items) else self.index
                path=str((getattr(self,"_grid_slot_paths",{}) or {}).get(pos) or "")
            except Exception:path=""
            self["preview_cover"].show()
            art=self["preview_cover_art"]
            if path and os.path.isfile(path) and art.instance is not None:
                art.instance.setPixmapFromFile(path);art.show()
            else:
                art.hide()
        except Exception as exc:
            optional_failure("ui.live_preview_cover",exc)
