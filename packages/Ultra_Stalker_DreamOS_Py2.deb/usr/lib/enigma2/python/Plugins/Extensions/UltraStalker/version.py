from __future__ import absolute_import, division, print_function, unicode_literals
PLUGIN_VERSION = '9.3.2'
PLUGIN_BUILD = 997
PLUGIN_REVISION = 581
BUILD_NAME = 'Ultra Stalker V9.3.2 - DreamOS'
PACKAGE_VERSION = '9.3.2'
DREAMOS_BUILD = 'V9.3.2 / DreamOS'
