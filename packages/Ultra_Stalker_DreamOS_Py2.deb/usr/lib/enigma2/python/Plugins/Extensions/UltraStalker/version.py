from __future__ import absolute_import, division, print_function, unicode_literals
PLUGIN_VERSION = '9.3.1'
PLUGIN_BUILD = 992
PLUGIN_REVISION = 576
BUILD_NAME = 'Ultra Stalker V9.3.1 - DreamOS'
PACKAGE_VERSION = '9.3.1'
DREAMOS_BUILD = 'V9.3.1 / DreamOS'
