from __future__ import absolute_import, division, print_function, unicode_literals
PLUGIN_VERSION = '9.3.3'
PLUGIN_BUILD = 1003
PLUGIN_REVISION = 582
BUILD_NAME = 'Ultra Stalker V9.3.3 - DreamOS'
PACKAGE_VERSION = '9.3.3'
DREAMOS_BUILD = 'V9.3.3 / DreamOS'
