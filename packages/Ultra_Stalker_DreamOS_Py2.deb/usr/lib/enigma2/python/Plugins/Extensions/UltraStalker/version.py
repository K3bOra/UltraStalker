from __future__ import absolute_import, division, print_function, unicode_literals
PLUGIN_VERSION = '9.3.7'
PLUGIN_BUILD = 1006
PLUGIN_REVISION = 586
BUILD_NAME = 'Ultra Stalker V9.3.7 - DreamOS'
PACKAGE_VERSION = '9.3.7'
DREAMOS_BUILD = 'V9.3.7 / DreamOS'
