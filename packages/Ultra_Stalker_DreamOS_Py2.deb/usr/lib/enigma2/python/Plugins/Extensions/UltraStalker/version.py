from __future__ import absolute_import, division, print_function, unicode_literals
PLUGIN_VERSION = '9.3.4'
PLUGIN_BUILD = 1004
PLUGIN_REVISION = 583
BUILD_NAME = 'Ultra Stalker V9.3.4 - DreamOS'
PACKAGE_VERSION = '9.3.4'
DREAMOS_BUILD = 'V9.3.4 / DreamOS'
