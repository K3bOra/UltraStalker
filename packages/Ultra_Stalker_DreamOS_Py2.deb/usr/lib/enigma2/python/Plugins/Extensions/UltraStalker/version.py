from __future__ import absolute_import, division, print_function, unicode_literals
PLUGIN_VERSION = '9.3.5'
PLUGIN_BUILD = 1005
PLUGIN_REVISION = 584
BUILD_NAME = 'Ultra Stalker V9.3.5 - DreamOS'
PACKAGE_VERSION = '9.3.5'
DREAMOS_BUILD = 'V9.3.5 / DreamOS'
