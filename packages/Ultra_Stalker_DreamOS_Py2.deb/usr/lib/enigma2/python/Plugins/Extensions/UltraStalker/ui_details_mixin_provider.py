# -*- coding: utf-8 -*-
"""Provider metadata, Xtream retry, provider art and series count.

Methods moved verbatim out of ``ContentDetailsScreen`` (ui_screens_details.py); behaviour is unchanged.
This module is imported by ui_screens_details.py once its module-level helpers exist, so the names below are taken from that module
(partially initialised at this point) on purpose. Never import this module directly.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .us_env import str, int
from .ui_screens_details import (
    _,
    _age_rating_display,
    _clean_person_name,
    _clean_year_value,
    _detail_genre_value,
    _details_backdrop_truth,
    call_compatible,
    diagnostic_failure,
    os,
    re,
)


class DetailsProviderMixin(object):
    """Provider metadata, Xtream retry, provider art and series count."""

    def _provider_metadata_allowed(self, item=None):
        from .manual_identity import selected,cache_token
        current=getattr(self,"_portal_item",getattr(self,"item",{})) or {}
        row=current if item is None else item
        if selected(current) or selected(row):return False
        revision=str(current.get('_manual_identity_revision') or '')
        if item is not None and '_manual_identity_revision' in row and str(row.get('_manual_identity_revision') or '')!=revision:return False
        return cache_token(self.profile,self.media_type,current)==revision

    def _apply_provider_metadata(self, enriched):
        """Merge provider/Xtream metadata into the visible Details screen.

        Provider data is first-paint truth. TMDB may upgrade individual fields later,
        but a TMDB miss must never blank valid server metadata.
        """
        if not isinstance(enriched,dict) or not self._provider_metadata_allowed(enriched):return
        try:
            # Keep the enriched row as the current portal item so subsequent artwork,
            # playback and TMDB resolution see structured ids/titles returned by server.
            current=dict(getattr(self,"_portal_item",{}) or {})
            current.update({k:v for k,v in enriched.items() if v not in (None,"",[],{})})
            self._portal_item=current
            self.item.update({k:v for k,v in current.items() if v not in (None,"",[],{})})
        except Exception as exc:diagnostic_failure("ui.details.failsoft.448",exc)

        def first(*keys):
            for key in keys:
                value=enriched.get(key)
                if value not in (None,"",[],{}):return value
            return ""

        # Provider metadata is allowed as instant first paint only.  Once a
        # verified TMDb snapshot owns this screen, do not let a later provider
        # callback repaint its description/genres/cast/runtime/rating with a
        # cleaned or differently-localized copy.  Clean Names remains independent.
        _tmdb_owner=getattr(self,"_tmdb_data",None)
        tmdb_owns_metadata=bool(isinstance(_tmdb_owner,dict) and _tmdb_owner.get("matched") and
                                (_tmdb_owner.get("identity_verified") or _tmdb_owner.get("identity_pointer_verified")) and
                                _tmdb_owner.get("tmdb_id"))

        def tmdb_has(*keys):
            row=_tmdb_owner if tmdb_owns_metadata else {}
            provisional=set(row.get("_details_provider_fields") or [])
            return any(row.get(key) not in (None,"",[],{},0) and key not in provisional for key in keys)

        title=first("name","title","movie_name")
        if title:
            try:
                # Provider metadata may repeat the raw catalogue decoration.
                # Keep the same cleaned title used on first paint so late
                # metadata cannot re-introduce AR-AS-D / year / country tags.
                cleaned=(_catalogue_title(str(title)) if load_settings().get("clean_titles",True) else str(title or "").strip())
                visible=_clean_display_text(cleaned or str(title),120)
                self._server_display_name=visible or getattr(self,"_server_display_name","")
                if str(self["name"].getText() or "")!=visible:
                    self["name"].setText(visible)
                    self._fit_single_line_font("name",visible,42,14);self._schedule_title_fit()
            except Exception as exc:diagnostic_failure("ui.details.failsoft.459",exc)

        overview=first("description","plot","descr","overview")
        try:
            # Same Arabic-first pick Cinematic/grids/Search use for provider text,
            # so a title TMDb never matches reads the same on every screen.
            from .details_authority import provider_description_for_display
            overview=provider_description_for_display(enriched,getattr(self,"_portal_item",None),getattr(self,"item",None)) or overview
        except Exception as exc:diagnostic_failure("ui.details_provider_description_authority",exc)
        _tmdb_ov_fallback = bool(
            isinstance(_tmdb_owner, dict) and
            ("overview" in (_tmdb_owner.get("_details_metadata_fallback_fields") or []) or
             not re.search(r"[\u0600-\u06ff]", str(_tmdb_owner.get("overview") or ""))) and
            str(load_settings().get("description_language") or load_settings().get("tmdb_language") or "ar").lower().startswith("ar") and
            bool(re.search(r"[\u0600-\u06ff]", str(overview or "")))
        )
        if overview and (not tmdb_has("overview") or _tmdb_ov_fallback):
            try:
                self._set_description_source(str(overview));self._provider_description_painted=True
            except Exception as exc:diagnostic_failure("ui.details.failsoft.464",exc)

        year=first("year","release_year","releaseDate","release_date")
        if year and not tmdb_has("year","release_date","first_air_date"):
            try:
                m=re.search(r"(?:19|20)\\d{2}",str(year))
                self["year_text"].setText(_clean_year_value(year))
            except Exception as exc:diagnostic_failure("ui.details.failsoft.471",exc)

        country=first("country","country_code","countries","origin_country","production_country","production_countries")
        if country and not tmdb_has("countries","country","production_countries"):
            try:
                code=self._country_code(country)
                self._country_raw=code or str(country).strip()
                self["country_text"].setText(self._normalized_country(self._country_raw))
                self._refresh_detail_visuals()
            except Exception as exc:optional_failure("ui.details_provider_country",exc)

        genre=_detail_genre_value(enriched)
        if genre and not tmdb_has("genres","genre"):
            try:self["genre_text"].setText(str(genre)[:54]);self["subtitle"].setText(str(genre)[:78])
            except Exception as exc:diagnostic_failure("ui.details.failsoft.477",exc)
        if not tmdb_has("certification","age_rating"):
            try:
                _provider_age=first("certification","age_rating")
                if _provider_age:self["age_rating_text"].setText(_age_rating_display(_provider_age))
            except Exception as exc:optional_failure("ui.details.provider_age_rating",exc)

        actors=first("actors","cast","actor")
        if isinstance(actors,(list,tuple)):actors=", ".join([str(x) for x in actors[:8]])
        if actors and not tmdb_has("cast"):
            try:self["cast_text"].setText(_clean_person_name(actors)[:220])
            except Exception as exc:diagnostic_failure("ui.details.failsoft.483",exc)

        rating=first("rating_imdb","imdb_rating","rating")
        if rating and not tmdb_has("rating"):
            try:
                score=float(rating)
                self["imdb_text"].setText("★ %.1f"%score)
                self["poster_imdb_value"].setText("%.1f"%score)
                self["rating_source"].setText(_("Provider rating"))
            except Exception:
                try:self["imdb_text"].setText(str(rating)[:24])
                except Exception as exc:diagnostic_failure("ui.details.failsoft.507",exc)

        runtime=first("time","duration","runtime","length")
        if runtime and self.media_type=="vod" and not tmdb_has("runtime"):
            try:self["runtime_text"].setText(str(runtime)[:14]);self._fit_compact_text("runtime_text",max_size=24,min_size=18,padding=4)
            except Exception as exc:diagnostic_failure("ui.details.failsoft.512",exc)

        seasons=first("number_of_seasons","seasons_count","season_count")
        if seasons and self.media_type=="series" and not tmdb_has("number_of_seasons"):
            try:self["runtime_text"].setText(self._season_count_text(seasons));self._fit_compact_text("runtime_text",max_size=24,min_size=18,padding=4)
            except Exception as exc:diagnostic_failure("ui.details.failsoft.517",exc)

        try:
            if not tmdb_owns_metadata:
                self["poster_match_text"].setText(_("Server • TMDb enrichment"))
                self["status"].setText(_("Server metadata loaded"))
            self._sync_detail_text_direction()
            self._refresh_detail_visuals()
        except Exception as exc:diagnostic_failure("ui.details.failsoft.524",exc)

    def _stop_xtream_auto_retry(self):
        try:self._xtream_auto_retry_timer.stop()
        except Exception:pass
        try:
            if self._xtream_auto_retry_conn is not None:self._xtream_auto_retry_conn.disconnect()
        except Exception:pass
        try:
            if self._xtream_auto_retry in self._xtream_auto_retry_timer.callback:self._xtream_auto_retry_timer.callback.remove(self._xtream_auto_retry)
        except Exception:pass

    def _schedule_xtream_auto_retry(self):
        if self._screen_closed or not getattr(self,"_is_xtream_item",False) or not self._provider_metadata_allowed():return
        if int(getattr(self,"_xtream_auto_retry_count",0) or 0)>=1:return
        self._xtream_auto_retry_count=1
        try:self._xtream_auto_retry_timer.start(1100,True)
        except Exception:self._xtream_auto_retry()

    def _xtream_auto_retry(self):
        if self._screen_closed or not getattr(self,"_is_xtream_item",False) or not self._provider_metadata_allowed():return
        # If the first TMDb pass could not resolve from the visible row, allow the
        # deferred provider-info request now and retry TMDb once with the enriched
        # ids/title. Provider networking never competes with a successful first
        # backdrop paint.
        self._start_deferred_provider_enrichment(retry_tmdb=True)

    def _start_deferred_provider_enrichment(self, retry_tmdb=False):
        if self._screen_closed or not self._provider_metadata_allowed():return
        base_item=dict(getattr(self,"_provider_enrich_deferred_item",{}) or {})
        if not base_item:return
        if getattr(self,"_provider_enrich_started",False):return
        if not (hasattr(self.client,"enrich_provider_artwork") and base_item.get("_xtream")):return
        self._provider_enrich_retry_tmdb=bool(retry_tmdb)

        def work(handle):
            if handle.cancel_event.is_set() or not self._provider_metadata_allowed(base_item):return None
            enriched=dict(base_item)
            try:
                enriched=call_compatible(
                    self.client.enrich_provider_artwork,
                    (((enriched,self.media_type,handle.cancel_event), {"force":True}),
                     ((enriched,self.media_type,handle.cancel_event), {})),
                ) or enriched
            except Exception as exc:diagnostic_failure("ui.details.failsoft.546",exc)
            if handle.cancel_event.is_set() or not self._provider_metadata_allowed(base_item):return None
            return enriched

        def ok(enriched):
            if self._screen_closed or enriched is None or not self._provider_metadata_allowed(base_item):return
            provider=enriched if isinstance(enriched,dict) else base_item
            self._apply_provider_metadata(provider)
            self._load_provider_art(provider)
            if bool(getattr(self,"_provider_enrich_retry_tmdb",False)):
                self._provider_enrich_retry_tmdb=False
                self._load_tmdb_metadata()

        def fail(_error):
            if self._screen_closed or not self._provider_metadata_allowed(base_item):return
            self._apply_provider_metadata(base_item)

        # Mark "started" only once the job was really accepted; a busy screen
        # rejects it and a later call must be able to retry.
        if self._run_async(work,ok,fail):
            self._provider_enrich_started=True

    def _load_provider_metadata(self):
        """TMDb has first refusal; catalogue/provider values are fallback only."""
        if self._screen_closed:return
        if not self._provider_metadata_allowed():
            self._provider_enrich_deferred_item={}
            self._provider_enrich_started=False;self._provider_enrich_retry_tmdb=False
            self._load_tmdb_metadata()
            return
        base_item=dict(getattr(self,"_portal_item",self.item) or {})
        can_enrich=bool(hasattr(self.client,"enrich_provider_artwork") and base_item.get("_xtream"))
        self._provider_enrich_deferred_item=dict(base_item) if can_enrich else {}
        self._provider_enrich_started=False
        self._provider_enrich_retry_tmdb=False
        cfg=load_settings()
        available=bool(cfg.get("tmdb_enabled",True) and str(cfg.get("tmdb_credential") or "").strip())
        if not available:
            self._apply_provider_metadata(base_item)
            if can_enrich:self._start_deferred_provider_enrichment(retry_tmdb=False)
            self._load_provider_art(base_item)
        self._load_tmdb_metadata()

    def _load_provider_art(self, provider=None):
        """Display a provisional landscape only after the TMDb attempt.

        No provider bytes are promoted to canonical artwork or visual locks.
        A later verified TMDb backdrop can replace this rank-2 fallback.
        """
        if self._screen_closed or getattr(self,"_provider_backdrop_pending",False) or not self._provider_metadata_allowed():return
        if getattr(self,"_details_backdrop_authority_locked",False) or int(getattr(self,"_backdrop_rank",0) or 0)>=4:return
        from .details_authority import _provider_backdrop_ok
        from .ui_artwork_helpers import _backdrop_candidates
        row=dict(provider or getattr(self,"_portal_item",self.item) or {})
        local=str(row.get("_details_provider_backdrop_local") or "")
        candidates=([local] if local and _provider_backdrop_ok(local) else [])+_backdrop_candidates(row)
        if not candidates:return
        def work(handle):
            for url in candidates[:3]:
                if handle.cancel_event.is_set() or not self._provider_metadata_allowed(row):return None
                source=url if os.path.isfile(str(url)) else _download_portal_artwork(url,self.profile,self.client,landscape=True,
                    timeout=3.5,cancel_event=handle.cancel_event,item=row)
                if not _details_backdrop_truth(source):continue
                target=self._backdrop_presentation_target(source)
                prepared=target if target and _valid_cache_file(target) else _build_integrated_backdrop(source,target,(1620,620))
                if prepared and _valid_cache_file(prepared):return source,prepared
            return None
        def ok(result):
            self._provider_backdrop_pending=False
            if self._screen_closed or not result or getattr(self,"_details_images_suspended",False) or not self._provider_metadata_allowed(row):return
            if getattr(self,"_details_backdrop_authority_locked",False) or int(getattr(self,"_backdrop_rank",0) or 0)>=4:return
            source,prepared=result
            if self["cinematic_bg"].instance is not None:
                self["cinematic_bg"].instance.setPixmapFromFile(prepared);self["cinematic_bg"].show()
                self._provider_backdrop_fallback_path=source
                self._backdrop_displayed_path=prepared;self._backdrop_rank=2
        def fail(error):
            self._provider_backdrop_pending=False
        # Pending is set only after the job is accepted (a busy screen refuses
        # it), otherwise the flag stuck True with no job and blocked every retry.
        if self._run_async(work,ok,fail):
            self._provider_backdrop_pending=True

    def _stop_series_count_timer(self):
        try:self._series_count_timer.stop()
        except Exception as exc:optional_failure("ui.series_count_timer_stop",exc)
        try:
            if getattr(self,"_series_count_conn",None) is not None:
                self._series_count_conn.disconnect()
                self._series_count_conn=None
        except Exception:pass
        try:
            if self._ensure_series_count_late in self._series_count_timer.callback:
                self._series_count_timer.callback.remove(self._ensure_series_count_late)
        except Exception:pass

    def _apply_series_count_cached(self,count):
        if not self._provider_metadata_allowed():return
        _owner=(getattr(self,"_tmdb_data",None) if isinstance(getattr(self,"_tmdb_data",None),dict) else None) or (getattr(self,"_local_detail_cache",None) if isinstance(getattr(self,"_local_detail_cache",None),dict) else {})
        if isinstance(_owner,dict) and _owner.get("_details_authority_ready") and _owner.get("tmdb_id"):
            return
        try:count=int(count or 0)
        except Exception:count=0
        if count<=0 or self._screen_closed:return
        try:self["runtime_text"].setText(self._season_count_text(count));self._fit_compact_text("runtime_text",max_size=24,min_size=18,padding=4)
        except Exception:return
        try:
            self.item["number_of_seasons"]=count
            if isinstance(getattr(self,"_portal_item",None),dict):self._portal_item["number_of_seasons"]=count
            snap=dict(getattr(self,"_local_detail_cache",{}) or {})
            overlay=dict(snap.get("item_overlay") or {})
            overlay["number_of_seasons"]=count
            snap["item_overlay"]=overlay
            from .core.snapshot_writer import queue_detail_snapshot
            queue_detail_snapshot(self.profile,self.media_type,getattr(self,"_portal_item",self.item),snap)
            self._local_detail_cache=snap
        except Exception as exc:optional_failure("ui.series_count_cache_save",exc)

    def _ensure_series_count_late(self):
        if self._screen_closed or self.media_type!="series" or self._series_count_pending or not self._provider_metadata_allowed():return
        _owner=(getattr(self,"_tmdb_data",None) if isinstance(getattr(self,"_tmdb_data",None),dict) else None) or (getattr(self,"_local_detail_cache",None) if isinstance(getattr(self,"_local_detail_cache",None),dict) else {})
        if isinstance(_owner,dict) and _owner.get("_details_authority_ready") and _owner.get("tmdb_id"):
            return
        # The provider season browser is authoritative.  TMDB/cache may report
        # seasons that the IPTV portal does not actually expose, so always verify
        # the displayed count asynchronously against series_seasons().
        if not hasattr(self.client,"series_seasons"):return
        self._series_count_pending=True
        portal_item=dict(getattr(self,"_portal_item",self.item) or {})
        def work(handle):
            try:
                rows=self.client.series_seasons(portal_item,cancel_event=handle.cancel_event)
            except TypeError:
                rows=self.client.series_seasons(portal_item)
            rows=[dict(x) for x in (rows or []) if isinstance(x,dict)] if isinstance(rows,list) else []
            # Persist the single seasons catalogue while already off the GUI
            # thread. Embedded episode lists remain inside these rows, so the
            # child browser can open a season instantly without N extra writes.
            if rows and not handle.cancel_event.is_set():
                try:
                    from .ui_screens_series import _series_cache_write
                    _series_cache_write(self.profile,portal_item,"seasons",rows)
                except Exception as exc:optional_failure("ui.series_hierarchy_prefetch_cache",exc)
            return rows
        def ok(rows):
            self._series_count_pending=False
            rows=[dict(x) for x in (rows or []) if isinstance(x,dict)]
            self._prefetched_series_seasons=rows
            self._apply_series_count_cached(len(rows))
        def fail(exc):
            self._series_count_pending=False
            optional_failure("ui.series_count_late",exc)
        self._run_async(work,ok,fail)
