# -*- coding: utf-8 -*-
"""Settings screens extracted from ui.py without changing class behavior."""
from __future__ import absolute_import, division, print_function, unicode_literals
from . import us_env as _us_env
from .us_env import str, int, round, max, min, us_func

from .core.parental import authorize_settings_change as _authorize_parental_change

from Screens.Screen import Screen
from Screens.InputBox import InputBox
from Components.Input import Input
from enigma import gFont
from skin import parseColor
from .ui_async import AsyncScreenMixin
from .ui_image_loader import ImageLoaderMixin
from .ui_transition import TransitionMixin
from .ui_fixed_adaptive import fixed_settings_rows, fixed_value_color, fixed_settings_chrome, cleanup_legacy_application_outputs
from .ui_helpers import content_refresh_feedback, content_refresh_failure
from .ui_floating_notice import show_notice
from .ui_settings_glass import (SettingsGlassList, build_skin as _settings_glass_skin,
    classify as _settings_classify, group_icon as _settings_group_icon)
from .localization import set_plugin_language, language_name
from .language_catalog import interface_language_choices, description_language_choices, description_language_name, default_description_for_interface
from .category_visibility import category_id as _visibility_category_id, hidden_ids as _profile_hidden_ids
_queue = _us_env.queue
_time = _us_env.time
from .log import memory_snapshot as _mem34, optional_failure
os = _us_env.os
_shutil = _us_env.shutil
from . import _
from .asset_paths import asset_path as asset
from .wqhd_layout import responsive_font as _ultra_rfont

BROWSER_SKIN = ""

def _settings_text_width_px(text, font_size=24):
    return max(0, int(len(str(text or "")) * int(font_size or 24) * 0.56))


# Settings message-card authority.  The approved About card is the single
# visual master for passive informational text throughout Settings and any
# Settings-owned popup reused by Browser/Portal List.  Long copy is paged
# inside the same card instead of growing a giant one-off rectangle.
_SETTINGS_NOTICE_MASTER_W = 560
_SETTINGS_NOTICE_MASTER_H = 260
_SETTINGS_NOTICE_INNER_W = _SETTINGS_NOTICE_MASTER_W - 72
_SETTINGS_NOTICE_FONT = 20
_SETTINGS_NOTICE_MAX_LINES = 6

def _settings_notice_wrap_line(line, font_size=_SETTINGS_NOTICE_FONT, max_px=_SETTINGS_NOTICE_INNER_W):
    text=str(line or "")
    if not text:
        return [""]
    words=text.split(" ")
    out=[]; current=""
    for word in words:
        candidate=word if not current else current+" "+word
        try: fits=_settings_text_width_px(candidate,font_size)<=max_px
        except Exception: fits=len(candidate)<=48
        if fits:
            current=candidate
            continue
        if current:
            out.append(current);current=""
        # Very long paths/tokens still stay inside the master card.  Split only
        # when a token cannot fit by itself; normal prose remains word-wrapped.
        token=str(word or "")
        while token:
            take=len(token)
            while take>1:
                part=token[:take]
                try: part_fits=_settings_text_width_px(part,font_size)<=max_px
                except Exception: part_fits=len(part)<=48
                if part_fits: break
                take-=1
            part=token[:max(1,take)]
            out.append(part)
            token=token[len(part):]
        current=""
    if current or not out: out.append(current)
    return out

def _settings_notice_pages(message, font_size=_SETTINGS_NOTICE_FONT, max_px=_SETTINGS_NOTICE_INNER_W, max_lines=_SETTINGS_NOTICE_MAX_LINES):
    wrapped=[]
    for raw in str(message or "").splitlines() or [""]:
        wrapped.extend(_settings_notice_wrap_line(raw,font_size,max_px))
    # Trim useless page-edge blank lines while preserving intentional paragraph
    # spacing inside a page.
    pages=[]
    step=max(1,int(max_lines or 1))
    for i in range(0,len(wrapped),step):
        chunk=list(wrapped[i:i+step])
        while chunk and chunk[0]=="": chunk.pop(0)
        while chunk and chunk[-1]=="": chunk.pop()
        pages.append("\n".join(chunk) if chunk else "")
    return pages or [""]

def _settings_notice_title(base,index,total):
    title=str(base or "Information")
    return ("%s  •  %d/%d"%(title,int(index)+1,int(total))) if int(total or 0)>1 else title

SETTINGS_HOME_GRID_SKIN = _settings_glass_skin()

def configure_settings_screens(**deps):
    globals().update(deps)
    for _mixin_module in _MIXIN_MODULES:
        _mixin_module.__dict__.update(deps)
    if "BROWSER_SKIN" in deps:
        scaler=deps.get("font_scale_skin")
        NovaSettingsScreen.skin = scaler(SETTINGS_HOME_GRID_SKIN) if callable(scaler) else SETTINGS_HOME_GRID_SKIN
        # Apply the same global readability setting to settings-owned popup skins.
        if callable(scaler):
            for cls in (SettingsGlassChoiceScreen,SettingsGlassNoticeScreen,SettingsWebCleanerReadyScreen,SettingsGlassInputScreen):
                try:
                    raw=getattr(cls,"_ultra_fhd_skin",None)
                    if raw is None:
                        raw=getattr(cls,"skin","")
                        cls._ultra_fhd_skin=raw
                    if isinstance(raw,str) and raw:cls.skin=scaler(raw)
                except Exception:
                    pass


def _settings_category_backdrop():
    """Return the shared bundled background used across the approved pages."""
    fallback = asset("ultra_bg_flag_1920x1080.png")
    return fallback if fallback and os.path.isfile(fallback) else ""


class _UsPopupParentMixin(object):
    def _us_popup_parent(self):
        """DreamOS hides the screen below a dialog and draws a transparent window
        as plain black, so give the popup the soft blurred application backdrop."""
        if not _us_env.IS_DREAMOS:return
        try:
            inst=self["background"].instance
            if inst is None:return
            path=_settings_popup_backdrop(_settings_popup_source())
            if not path or not os.path.isfile(path):return
            desktop=getDesktop(0).size()
            inst.move(ePoint(0,0))
            inst.resize(eSize(int(desktop.width()),int(desktop.height())))
            inst.setPixmapFromFile(path)
            self["background"].show()
        except Exception as exc:optional_failure("ui.popup_backdrop",exc)


class SettingsGlassChoiceScreen(_UsPopupParentMixin, Screen):
    skin = """<screen name="SettingsGlassChoiceScreen" position="0,0" size="1920,1080" backgroundColor="#00000000" flags="wfNoBorder">
      <widget name="background" position="0,0" size="1,1" alphatest="blend" scale="1" transparent="1" zPosition="0"/>
      <widget name="panel" position="680,650" size="1040,300" alphatest="blend" scale="1" transparent="1" zPosition="2"/>
      <widget name="header_icon" position="0,0" size="1,1" alphatest="blend" scale="1" transparent="1" zPosition="4"/>
      <widget name="title" position="730,665" size="940,42" font="Regular;30" foregroundColor="#ffffff" transparent="1" zPosition="5" shadowColor="#000000" shadowOffset="1,1"/>
      <widget name="subtitle" position="730,704" size="940,26" font="Regular;17" foregroundColor="#91b7ca" transparent="1" zPosition="5" shadowColor="#000000" shadowOffset="1,1"/>
      <widget name="list" position="730,742" size="940,160" transparent="1" zPosition="6"/>
      <widget name="hint" position="730,910" size="940,30" font="Regular;17" halign="center" valign="center" foregroundColor="#a9c1d0" transparent="1" zPosition="6" shadowColor="#000000" shadowOffset="1,1"/>
    </screen>"""
    def __init__(self,session,title,choices,selection=0,subtitle="Choose an option"):
        us_func(Screen.__init__)(self,session)
        self._choices=[(_(str(c[0])),c[1]) if isinstance(c,(tuple,list)) and len(c)>1 else c for c in list(choices or [])]
        self._initial_selection=int(selection or 0)
        self._choice_chrome={}
        self["background"]=Pixmap();self["panel"]=Pixmap();self["header_icon"]=Pixmap()
        self["title"]=Label(_(str(title or "Settings")));self["subtitle"]=Label(_(str(subtitle or "")))
        self["hint"]=Label(_("OK  Select   •   BACK  Cancel"))
        self["list"]=IconMenuList([],width=980,item_height=76,icon_size=0,primary_font=24,secondary_font=17,row_style="settings_dialog")
        self["actions"]=ActionMap(["OkCancelActions","DirectionActions"],{
            "cancel":lambda:self.close(None),"ok":self._accept,
            "up":lambda:self["list"].wrap_up(),"down":lambda:self["list"].wrap_down(),
            "left":lambda:self["list"].page_left(),"right":lambda:self["list"].page_right(),
        },-1)
        self.onLayoutFinish.append(self._us_popup_parent)
        self.onLayoutFinish.append(self._finish)

    def _geom(self,name,x,y,w,h):
        try:
            desktop=getDesktop(0).size();sx=float(desktop.width())/1920.0;sy=float(desktop.height())/1080.0
            inst=self[name].instance
            if inst is not None:
                inst.move(ePoint(int(round(x*sx)),int(round(y*sy))))
                inst.resize(eSize(int(round(w*sx)),int(round(h*sy))))
        except Exception as exc:optional_failure("ui.settings_choice_geom",exc)

    def _finish(self):
        count=max(1,len(self._choices))
        labels=list(str(c[0]) if isinstance(c,(tuple,list)) and c else str(c) for c in self._choices)
        numeric_like=bool(labels) and all(
            len(x)<=16 and (
                not any(ch.isalpha() for ch in x)
                or x.upper().endswith(("MB","GB","MS","S","%"))
            ) for x in labels
        )
        label_px=max(list(_settings_text_width_px(x,23) for x in labels) or [120])
        title_px=_settings_text_width_px(self["title"].getText(),30)
        subtitle_px=_settings_text_width_px(self["subtitle"].getText(),17)
        row_pad=52 if numeric_like else 70
        list_w=1000
        row_h=58
        visible=min(4,count)
        list_h=max(row_h,visible*row_h)

        # Right-side context panel: the full-screen layer is transparent, so
        # the Settings rail and the untouched hero stay visible behind it.
        region_x,region_y,region_w,region_h=560,590,1290,390
        heading_w=max(title_px,subtitle_px)+76
        panel_w=1120
        panel_h=390
        panel_x=region_x+max(0,(region_w-panel_w)//2)
        panel_y=max(560,1000-panel_h)
        list_x=panel_x+(panel_w-list_w)//2
        list_y=panel_y+82
        list_h=min(list_h,max(row_h,panel_h-132))

        if not _us_env.IS_DREAMOS:self._geom("background",0,0,1,1)
        self._geom("panel",panel_x,panel_y,panel_w,panel_h)
        self._geom("header_icon",0,0,1,1)
        self._geom("title",panel_x+38,panel_y+16,panel_w-76,38)
        self._geom("subtitle",panel_x+38,panel_y+52,panel_w-76,24)
        self._geom("list",list_x,list_y,list_w,list_h)
        self._geom("hint",panel_x+42,panel_y+panel_h-38,panel_w-84,28)
        try:
            (None if _us_env.IS_DREAMOS else self["background"].hide());self["header_icon"].hide()
        except Exception as exc:optional_failure("ui.settings_choice_context_hide",exc)

        chrome=fixed_settings_chrome(panel_w,panel_h,list_w,max(40,row_h-8))
        self._choice_chrome=chrome
        panel=chrome.get("panel")
        if panel and os.path.isfile(panel):
            self["panel"].instance.setPixmapFromFile(panel);self["panel"].show()
        try:
            if self["list"].instance is not None:
                self["list"].instance.setSelectionEnable(0)
                self["list"].instance.setTransparent(1)
                self["list"].instance.setScrollbarMode(2)
            self["list"].row_width=list_w
            self["list"].set_layout(row_h,0,23,16,row_style="settings_dialog")
        except Exception as exc:optional_failure("ui.settings_choice_context_list",exc)
        selection=max(0,min(self._initial_selection,len(self._choices)-1)) if self._choices else 0
        row_asset=chrome.get("row")
        selected_asset=chrome.get("selected")
        self._choice_row_asset=row_asset; self._choice_selected_asset=selected_asset
        rows=[]
        for i,c in enumerate(self._choices):
            label=labels[i]
            details={"selected":i==selection,"row_asset":row_asset,"row_selected_asset":selected_asset,"meta":"","settings_compact":numeric_like}
            rows.append((label,None,c,details))
        self["list"].set_icon_rows(rows)
        try:self["list"].moveToIndex(selection)
        except Exception as exc:optional_failure("ui.settings_choice_index",exc)
        self._last_idx=selection;self["list"].onSelectionChanged.append(self._selection_changed)

    def _selection_changed(self):
        try:idx=self["list"].getSelectedIndex()
        except Exception:return
        old=getattr(self,"_last_idx",idx)
        if old==idx:return
        self._last_idx=idx
        chrome=getattr(self,"_choice_chrome",{}) or {}
        for j in set((old,idx)):
            if 0<=j<len(self._choices):
                c=self._choices[j]
                label=str(c[0]) if isinstance(c,(tuple,list)) and c else str(c)
                details={"selected":j==idx,"row_asset":getattr(self,"_choice_row_asset",chrome.get("row")),"row_selected_asset":getattr(self,"_choice_selected_asset",chrome.get("selected")),"meta":"","settings_compact":False}
                self["list"].update_icon_row(j,(label,None,c,details))
        try:self["list"].l.invalidate()
        except Exception as exc:optional_failure("ui.settings_choice_refresh",exc)

    def _accept(self):
        try:idx=self["list"].getSelectedIndex()
        except Exception:idx=-1
        self.close(self._choices[idx] if 0<=idx<len(self._choices) else None)


class SettingsGlassNoticeScreen(_UsPopupParentMixin, Screen):
    skin = """<screen name="SettingsGlassNoticeScreen" position="0,0" size="1920,1080" backgroundColor="#00000000" flags="wfNoBorder">
      <widget name="background" position="0,0" size="1,1" alphatest="blend" transparent="1" zPosition="0"/>
      <widget name="panel" position="720,680" size="1000,260" alphatest="blend" transparent="1" zPosition="2"/>
      <widget name="header_icon" position="0,0" size="1,1" alphatest="blend" scale="1" transparent="1" zPosition="4"/>
      <widget name="title" position="760,695" size="920,42" font="Regular;30" halign="left" foregroundColor="#ffffff" transparent="1" zPosition="5" shadowColor="#000000" shadowOffset="1,1"/>
      <widget name="info_bg" position="0,0" size="1,1" alphatest="blend" transparent="1" zPosition="3"/>
      <widget name="message" position="770,745" size="900,110" font="Regular;22" halign="left" valign="top" noWrap="0" foregroundColor="#f4f8fb" transparent="1" zPosition="6" shadowColor="#000000" shadowOffset="1,1"/>
      <widget name="button1" position="900,865" size="280,52" alphatest="blend" transparent="1" zPosition="3"/>
      <widget name="button2" position="0,0" size="1,1" alphatest="blend" transparent="1" zPosition="3"/>
      <widget name="yes" position="900,865" size="280,52" font="Regular;20" halign="center" valign="center" foregroundColor="#ffffff" transparent="1" zPosition="6" shadowColor="#000000" shadowOffset="1,1"/>
      <widget name="no" position="0,0" size="1,1" font="Regular;20" halign="center" valign="center" foregroundColor="#ffffff" transparent="1" zPosition="6" shadowColor="#000000" shadowOffset="1,1"/>
    </screen>"""
    def __init__(self,session,title,message,yesno=False):
        us_func(Screen.__init__)(self,session);self._yesno=bool(yesno);self._answer=True
        self._notice_title_base=_(str(title or "Information"))
        self._notice_message=_(str(message or ""))
        self._notice_pages=_settings_notice_pages(self._notice_message) if not self._yesno else [self._notice_message]
        self._notice_page_idx=0
        self["background"]=Pixmap();self["panel"]=Pixmap();self["header_icon"]=Pixmap();self["info_bg"]=Pixmap();self["button1"]=Pixmap();self["button2"]=Pixmap()
        self["title"]=Label(self._notice_title_base);self["message"]=Label(self._notice_pages[0])
        self["yes"]=Label(_("Yes") if self._yesno else "");self["no"]=Label(_("No") if self._yesno else "")
        self["actions"]=ActionMap(["OkCancelActions","DirectionActions"],{
            "cancel":lambda:self.close(False if self._yesno else None),
            "ok":lambda:self.close(self._answer if self._yesno else None),
            "left":lambda:self._choose_answer(True) if self._yesno else self._notice_page(-1),
            "right":lambda:self._choose_answer(False) if self._yesno else self._notice_page(1),
            "up":lambda:self._notice_page(-1) if not self._yesno else None,
            "down":lambda:self._notice_page(1) if not self._yesno else None,
        },-1)
        self.onLayoutFinish.append(self._us_popup_parent)
        self.onLayoutFinish.append(self._finish)

    def _notice_page(self,step):
        if self._yesno or len(self._notice_pages)<=1:return
        self._notice_page_idx=(self._notice_page_idx+int(step or 0))%len(self._notice_pages)
        self["title"].setText(_settings_notice_title(self._notice_title_base,self._notice_page_idx,len(self._notice_pages)))
        self["message"].setText(self._notice_pages[self._notice_page_idx])

    def _geom(self,name,x,y,w,h):
        try:
            desktop=getDesktop(0).size();sx=float(desktop.width())/1920.0;sy=float(desktop.height())/1080.0
            inst=self[name].instance
            if inst is not None:
                inst.move(ePoint(int(round(x*sx)),int(round(y*sy))))
                inst.resize(eSize(max(1,int(round(w*sx))),max(1,int(round(h*sy)))))
        except Exception as exc:optional_failure("ui.settings_notice_geom",exc)

    def _choose_answer(self,answer):
        if not self._yesno:return
        self._answer=bool(answer);self._paint_buttons()

    def _paint_buttons(self):
        chrome=getattr(self,"_notice_chrome",{}) or {}
        normal=chrome.get("row");selected=chrome.get("selected") or normal
        try:
            p1=selected if (not self._yesno or self._answer) else normal
            if p1 and os.path.isfile(p1):self["button1"].instance.setPixmapFromFile(p1);self["button1"].show()
            if self._yesno:
                p2=selected if not self._answer else normal
                if p2 and os.path.isfile(p2):self["button2"].instance.setPixmapFromFile(p2);self["button2"].show()
        except Exception as exc:optional_failure("ui.settings_notice_buttons",exc)

    def _finish(self):
        title=str(self["title"].getText() or "")
        message=str(self["message"].getText() or "")

        # Issue 6: About is the one passive-message master.  Do not resize the
        # glass around each sentence; wrap/page the sentence inside the approved
        # 560x260 card instead.  Confirmations retain room for their controls.
        if self._yesno:
            raw_lines=message.splitlines() or [""]
            title_px=_settings_text_width_px(title,30)
            max_line_px=max(list(_settings_text_width_px(line,22) for line in raw_lines) or [280])
            panel_w=max(700,min(900,max(title_px+105,min(max_line_px+120,900))))
            message_w=max(420,panel_w-96)
            wrapped=0
            for line in raw_lines:
                px=max(1,_settings_text_width_px(line,22))
                wrapped+=max(1,int((px+message_w-1)//message_w))
            msg_font=22 if wrapped<=5 else (19 if wrapped<=9 else 17)
            line_h=30 if msg_font>=22 else (26 if msg_font>=19 else 23)
            footer_h=76
            message_h=max(70,min(330,wrapped*line_h+16))
            panel_h=max(220,min(470,82+message_h+footer_h))
            available=max(70,panel_h-82-footer_h)
            message_h=min(message_h,available)
        else:
            panel_w=_SETTINGS_NOTICE_MASTER_W
            panel_h=_SETTINGS_NOTICE_MASTER_H
            message_w=_SETTINGS_NOTICE_INNER_W
            msg_font=_SETTINGS_NOTICE_FONT
            footer_h=20
            message_h=174
            self["title"].setText(_settings_notice_title(self._notice_title_base,self._notice_page_idx,len(self._notice_pages)))
            self["message"].setText(self._notice_pages[self._notice_page_idx])
        panel_x=1850-panel_w
        panel_y=max(500,998-panel_h)

        if not _us_env.IS_DREAMOS:self._geom("background",0,0,1,1)
        self._geom("panel",panel_x,panel_y,panel_w,panel_h)
        self._geom("header_icon",0,0,1,1)
        self._geom("title",panel_x+36,panel_y+16,panel_w-72,42)
        self._geom("message",panel_x+36,panel_y+66,panel_w-72,message_h)
        self._geom("info_bg",0,0,1,1)
        try:
            from enigma import gFont
            if self["message"].instance is not None:self["message"].instance.setFont(_ultra_rfont("Regular",msg_font))
        except Exception as exc:optional_failure("ui.settings_notice_context_font",exc)

        if self._yesno:
            by=panel_y+panel_h-62
            gap=28;bw=260;total=bw*2+gap;bx=panel_x+(panel_w-total)//2
            self._geom("button1",bx,by,bw,50);self._geom("yes",bx,by,bw,50)
            self._geom("button2",bx+bw+gap,by,bw,50);self._geom("no",bx+bw+gap,by,bw,50)
        else:
            # Informational notices are text-only.  The removed Close button
            # lane is returned to the message so long status text does not clip.
            for name in ("button1","button2","yes","no"):
                self._geom(name,0,0,1,1)

        try:
            (None if _us_env.IS_DREAMOS else self["background"].hide());self["header_icon"].hide();self["info_bg"].hide()
        except Exception as exc:optional_failure("ui.settings_notice_context_hide",exc)

        chrome=fixed_settings_chrome(panel_w,panel_h,270,50)
        self._notice_chrome=chrome
        try:
            panel=chrome.get("panel")
            if panel and os.path.isfile(panel):self["panel"].instance.setPixmapFromFile(panel);self["panel"].show()
        except Exception as exc:optional_failure("ui.settings_notice_context_panel",exc)
        if self._yesno:
            self._paint_buttons()
        else:
            for name in ("button1","button2","yes","no"):
                try:self[name].hide()
                except Exception as exc:optional_failure("ui.settings_notice_hide",exc)

class SettingsWebCleanerReadyScreen(Screen):
    """Short-URL pairing screen with optional one-scan QR bootstrap."""
    skin = """<screen name="SettingsWebCleanerReadyScreen" position="0,0" size="1920,1080" backgroundColor="#02060b" flags="wfNoBorder">
      <widget name="background" position="0,0" size="1920,1080" alphatest="off" scale="1" transparent="0" zPosition="0"/>
      <widget name="panel" position="390,180" size="1140,720" alphatest="blend" scale="1" transparent="1" zPosition="2"/>
      <widget name="title" position="460,214" size="1000,56" font="Regular;34" foregroundColor="#ffffff" transparent="1" zPosition="5" shadowColor="#000000" shadowOffset="1,1"/>
      <widget name="info_bg" position="470,305" size="980,425" alphatest="blend" scale="1" transparent="1" zPosition="3"/>
      <widget name="lead" position="515,345" size="525,55" font="Regular;22" foregroundColor="#edf5f8" transparent="1" zPosition="6" shadowColor="#000000" shadowOffset="1,1"/>
      <widget name="url" position="515,410" size="525,55" font="Regular;25" foregroundColor="#7ed8ff" transparent="1" zPosition="6" shadowColor="#000000" shadowOffset="1,1"/>
      <widget name="code_title" position="515,500" size="525,38" font="Regular;20" foregroundColor="#a8c5d4" transparent="1" zPosition="6" shadowColor="#000000" shadowOffset="1,1"/>
      <widget name="code" position="515,540" size="525,75" font="Regular;44" foregroundColor="#ffffff" transparent="1" zPosition="6" shadowColor="#000000" shadowOffset="1,1"/>
      <widget name="note" position="515,625" size="525,70" font="Regular;18" foregroundColor="#a8c5d4" transparent="1" zPosition="6" shadowColor="#000000" shadowOffset="1,1"/>
      <widget name="qr" position="1090,350" size="300,300" alphatest="blend" scale="1" transparent="1" zPosition="6"/>
      <widget name="scan" position="1060,665" size="360,34" font="Regular;18" halign="center" foregroundColor="#a8c5d4" transparent="1" zPosition="6" shadowColor="#000000" shadowOffset="1,1"/>
      <widget name="button" position="810,790" size="300,58" alphatest="blend" transparent="1" zPosition="3"/>
      <widget name="close" position="810,790" size="300,58" font="Regular;21" halign="center" valign="center" foregroundColor="#ffffff" transparent="1" zPosition="6" shadowColor="#000000" shadowOffset="1,1"/>
    </screen>"""
    def __init__(self,session,url,pair_code="",qr_path="",access_mode="protected"):
        us_func(Screen.__init__)(self,session)
        self._access_mode="protected" if str(access_mode or "").lower()=="protected" else "easy"
        self._qr_path=str(qr_path or "") if self._access_mode=="protected" else ""
        self["background"]=Pixmap();self["panel"]=Pixmap();self["info_bg"]=Pixmap();self["qr"]=Pixmap();self["button"]=Pixmap()
        self["title"]=Label(_("Web Cleaner Ready"))
        self["lead"]=Label(_("Open this address on the same local network:"))
        self["url"]=Label(str(url or ""))
        if self._access_mode=="protected":
            self["code_title"]=Label(_("PAIRING CODE"))
            self["code"]=Label(str(pair_code or "------"))
            self["note"]=Label(_("Enter the code once. Your browser keeps the secure session until Web Cleaner is stopped."))
            self["scan"]=Label(_("Scan QR for instant access") if self._qr_path else _("QR unavailable • use the 6-digit code"))
        else:
            self["code_title"]=Label(_("EASY ACCESS"))
            self["code"]=Label(_("NO PIN"))
            self["note"]=Label(_("Direct access is limited to devices on the local network. Use Stop Service when finished."))
            self["scan"]=Label(_("PIN / QR protection can be enabled from Settings"))
        self["close"]=Label(_("Close"))
        self["actions"]=ActionMap(["OkCancelActions"],{"cancel":self.close,"ok":self.close},-1)
        self.onLayoutFinish.append(self._finish)

    def _finish(self):
        source=_settings_popup_source()
        try:
            popup_bg=_settings_popup_backdrop(source)
            if popup_bg and os.path.isfile(popup_bg):self["background"].instance.setPixmapFromFile(popup_bg);self["background"].show()
        except Exception as exc:optional_failure("ui.webcleaner_ready_bg",exc)
        try:
            outer=fixed_settings_chrome(1140,720,300,58)
            inner=fixed_settings_chrome(980,425,300,58)
            mapping=(("panel",outer.get("panel")),("info_bg",inner.get("panel")),("button",outer.get("selected")))
            for name,path in mapping:
                if path and os.path.isfile(path):self[name].instance.setPixmapFromFile(path);self[name].show()
        except Exception as exc:optional_failure("ui.webcleaner_ready_chrome",exc)
        try:
            if self._qr_path and os.path.isfile(self._qr_path):
                self["qr"].instance.setPixmapFromFile(self._qr_path);self["qr"].show()
            else:self["qr"].hide()
        except Exception as exc:
            optional_failure("ui.webcleaner_ready_qr",exc)
            try:self["qr"].hide()
            except Exception:pass


class SettingsGlassInputScreen(_UsPopupParentMixin, InputBox):
    TEXT = Input.TEXT
    PIN = Input.PIN
    NUMBER = Input.NUMBER
    skin = """<screen name="SettingsGlassInputScreen" position="0,0" size="1920,1080" backgroundColor="#00000000" flags="wfNoBorder">
      <widget name="background" position="0,0" size="1,1" alphatest="blend" transparent="1" zPosition="0"/>
      <widget name="panel" position="700,690" size="1040,250" alphatest="blend" scale="1" transparent="1" zPosition="2"/>
      <widget name="header_icon" position="0,0" size="1,1" alphatest="blend" scale="1" transparent="1" zPosition="4"/>
      <widget name="text" position="750,710" size="940,48" font="Regular;28" foregroundColor="#ffffff" transparent="1" zPosition="5" shadowColor="#000000" shadowOffset="1,1"/>
      <widget name="input_bg" position="750,785" size="940,64" alphatest="blend" scale="1" transparent="1" zPosition="3"/>
      <widget name="input" position="775,794" size="890,46" font="Regular;23" foregroundColor="#ffffff" backgroundColor="#00000000" transparent="1" zPosition="6" shadowColor="#000000" shadowOffset="1,1"/>
      <widget name="hint" position="750,880" size="940,30" font="Regular;17" halign="center" valign="center" foregroundColor="#a9c1d0" transparent="1" zPosition="6" shadowColor="#000000" shadowOffset="1,1"/>
    </screen>"""
    def __init__(self,session,title="",windowTitle=None,useableChars=None,**kwargs):
        safe_title = str(_(str(title or "")) or str(title or ""))
        safe_window_title = str(windowTitle or safe_title or "Ultra Stalker")
        us_func(InputBox.__init__)(self,session,title=safe_title,windowTitle=safe_window_title,useableChars=useableChars,**kwargs)
        self["background"]=Pixmap();self["panel"]=Pixmap();self["header_icon"]=Pixmap();self["input_bg"]=Pixmap()
        self["hint"]=Label(_("OK  Save   •   BACK  Cancel"))
        self.onLayoutFinish.append(self._us_popup_parent)
        self.onLayoutFinish.append(self._glass_finish)

    def _geom(self,name,x,y,w,h):
        try:
            desktop=getDesktop(0).size();sx=float(desktop.width())/1920.0;sy=float(desktop.height())/1080.0
            inst=self[name].instance
            if inst is not None:
                inst.move(ePoint(int(round(x*sx)),int(round(y*sy))))
                inst.resize(eSize(max(1,int(round(w*sx))),max(1,int(round(h*sy)))))
        except Exception as exc:optional_failure("ui.settings_input_geom",exc)

    def _glass_finish(self):
        title=str(self["text"].getText() or "")
        title_px=_settings_text_width_px(title,28)
        region_x,region_y,region_w,region_h=560,620,1290,350
        panel_w=900
        input_w=panel_w-100;panel_h=270
        panel_x=region_x+max(0,(region_w-panel_w)//2)
        panel_y=max(560,1000-panel_h)
        if _us_env.IS_DREAMOS:
            panel_x=(1920-panel_w)//2;panel_y=150
        if not _us_env.IS_DREAMOS:self._geom("background",0,0,1,1)
        self._geom("panel",panel_x,panel_y,panel_w,panel_h)
        self._geom("header_icon",0,0,1,1)
        self._geom("text",panel_x+44,panel_y+22,panel_w-88,46)
        self._geom("input_bg",panel_x+50,panel_y+92,input_w,66)
        self._geom("input",panel_x+74,panel_y+102,input_w-48,46)
        self._geom("hint",panel_x+50,panel_y+panel_h-48,input_w,30)
        try:
            (None if _us_env.IS_DREAMOS else self["background"].hide());self["header_icon"].hide()
        except Exception as exc:optional_failure("ui.settings_input_context_hide",exc)
        chrome=fixed_settings_chrome(panel_w,panel_h,input_w,64)
        for name,keyname in (("panel","panel"),("input_bg","row")):
            path=chrome.get(keyname)
            try:
                if path and os.path.isfile(path):
                    self[name].instance.setPixmapFromFile(path);self[name].show()
            except Exception as exc:optional_failure("ui.settings_input_context_chrome",exc)


# Split: related method groups live in ui_settings_mixin_*.py modules. They are imported here, after every module-level helper above exists,
# and listed BEFORE the other bases so they override them exactly like the methods that used to sit in this class body.
from .ui_settings_mixin_context import SettingsContextMixin
from .ui_settings_mixin_chrome import SettingsChromeMixin
from .ui_settings_mixin_artwork import SettingsArtworkMixin
from .ui_settings_mixin_refresh import SettingsRefreshMixin
from .ui_settings_mixin_layout import SettingsLayoutMixin
from .ui_settings_mixin_actions import SettingsActionsMixin
import sys as _split_sys
_MIXIN_MODULES = tuple(_split_sys.modules[_m.__module__] for _m in (SettingsContextMixin, SettingsChromeMixin, SettingsArtworkMixin, SettingsRefreshMixin, SettingsLayoutMixin, SettingsActionsMixin,))


class NovaSettingsScreen(
    SettingsContextMixin,
    SettingsChromeMixin,
    SettingsArtworkMixin,
    SettingsRefreshMixin,
    SettingsLayoutMixin,
    SettingsActionsMixin,
    Screen,
    AsyncScreenMixin,
    ImageLoaderMixin,
    TransitionMixin,
):
    """Full-HD settings surface; sub-pickers intentionally use native Enigma2 dialogs."""
    skin = SETTINGS_HOME_GRID_SKIN
    SETTINGS_ROW_W = 440
    SETTINGS_ROW_H = 98
    SETTINGS_VISIBLE_ROWS = 10

    def __init__(self, session, profile, client=None):
        us_func(Screen.__init__)(self, session)
        self._async_init(); self.onClose.append(self._stop_async); self.onClose.append(self._image_stop)
        self.profile = profile or {}
        self.client = client or PortalSession(self.profile, timeout=load_settings().get("timeout", 10)).client
        self.entries = []
        self._global_artwork_running=False
        self._global_artwork_progress=_queue.Queue()
        self._global_artwork_last={}
        # Main Settings deliberately reuses the approved floating episode-row
        # grammar: one narrow rail below the Ultra Stalker logo, leaving the hero
        # artwork unobstructed on the right.
        self["title"] = Label(_("Settings"))
        self["counter"] = Label("")
        self["section"] = Label("")
        self["list"] = SettingsGlassList([], width=self.SETTINGS_ROW_W, item_height=self.SETTINGS_ROW_H)
        # Glass header + live preview of the focused group (read-only, group level only).
        self["page_title"] = Label(_("Settings")); self["page_sub"] = Label("")
        self["page_dot"] = Label("\u25cf"); self["page_state"] = Label("")
        self["pv_panel"] = Pixmap(); self["pv_tile"] = Pixmap(); self["pv_icon"] = Pixmap(); self["pv_hair"] = Pixmap(); self["pv_hair_bottom"] = Pixmap()
        self["pv_title"] = Label(""); self["pv_desc"] = Label("")
        self["opt_list"] = SettingsGlassList([], width=500, item_height=66)
        self._pane = "groups"; self.opt_entries = []; self._opt_idx = 0; self._opt_visual = -1; self._opt_rebuilding = False
        self._pv_rows = {}; self._pv_shown = None; self._level_applied = None
        self["preview"] = Pixmap(); self["accent_frame"] = Pixmap()
        self["info_title"] = Label(_("Portal Settings"))
        self["info"] = Label(_("Choose an option to configure playback, lists and privacy."))
        self["status"] = Label(_("ARROWS Navigate  •  OK Select  •  BACK Home"))
        self["description"] = Label("")
        self["red"] = Label(_("Home")); self["green"] = Label(_("Open"))
        self["yellow"] = Label(_("Diagnostics")); self["blue"] = Label(_("Select"))
        self["ambient_bg"] = Pixmap(); self["hero_backdrop"] = Pixmap()
        # Inline Right Context Panel lives on this same Settings screen.  It is
        # hidden until OK is pressed, so opening a setting never creates a new
        # full-screen Screen and can never replace the hero with a black layer.
        self["context_panel"] = Pixmap()
        self["context_title"] = Label("")
        self["context_subtitle"] = Label("")
        self["context_message"] = Label("")
        self["context_hint"] = Label("")
        self["context_list"] = IconMenuList([], width=650, item_height=58, icon_size=0, primary_font=22, secondary_font=16, row_style="settings_dialog")
        self._context_active = False
        self._context_mode = None
        self._context_callback = None
        self._context_choices = []
        self._context_last_idx = 0
        self._context_row_asset = None
        self._context_selected_asset = None
        self._settings_row_asset = asset("series_floating_row.png")
        self._settings_row_selected_asset = asset("series_floating_row_selected.png")
        self._settings_value_color = int("74d8ff",16)
        try:
            _fixed=fixed_settings_rows() or {}
            _n=str(_fixed.get("normal") or "");_s=str(_fixed.get("selected") or "")
            if _n and os.path.isfile(_n):self._settings_row_asset=_n
            if _s and os.path.isfile(_s):self._settings_row_selected_asset=_s
            self._settings_value_color=int(_fixed.get("value_color") or fixed_value_color(self._settings_value_color))
        except Exception as exc:optional_failure("ui.settings_fixed_init",exc)
        self._settings_visual_index = -1
        self._settings_rebuilding = False
        self._settings_section = None
        self._settings_root_last_idx = 0
        self._settings_section_last_idx = {}
        # Preserve the proven 5.0.2 lifecycle and action plumbing.
        self._image_init("preview", (1,1), self.profile, self.client)
        self["list"].onSelectionChanged.append(self._selection_changed)
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "MenuActions","UltraStalkerMenuActions", "DirectionActions"], {
            "cancel": self._settings_cancel, "red": self._settings_cancel,
            "ok": self._settings_ok, "blue": self._settings_ok, "green": self._settings_ok,
            "yellow": self._settings_diagnostics, "menu": self._settings_diagnostics,
            "up": lambda: self._settings_move("up"), "down": lambda: self._settings_move("down"),
            "left": lambda: self._settings_move("left"), "right": lambda: self._settings_move("right"),
        }, -1)
        self.onLayoutFinish.append(self._layout_ready)
        self.onClose.append(self._mem34_settings_close)
        self.refresh()
        _mem34("settings_init_done")


    _RESETTABLE_SETTINGS=("live_zap_direction","smart_recovery","playback_retry_limit","service_type","resume_behavior","crash_safe_progress","remember_track_language","progress_save_seconds","next_episode_countdown","auto_remove_completed","completion_threshold","completion_remaining_seconds","channel_list_mode","show_channel_numbers","live_preview","epg_hours","catchup_hours","epg_refresh_budget","load_images","movies_view_mode","series_view_mode","live_view_mode","player_view_mode","infobar_timeout","show_watched","clean_titles","show_quality_badges","adaptive_colors","category_preview_posters","multi_portal_search","content_page_size","search_max_pages","search_time_budget","tmdb_enabled","hide_adult","font_scale","overview_font_scale","show_main_menu","image_cache_mb","persistent_cache_mb","download_reserve_mb","timeout","hide_empty_categories","xtream_refresh_mode","xtream_refresh_hour","playback_buffer_mb","diagnostic_logging")


# R5.245: plugin-owned front-panel identity.
try:
    from .frontpanel_plugin import bind_plugin_front_summary as _bind_plugin_front_summary
    _bind_plugin_front_summary(SettingsGlassChoiceScreen, SettingsGlassNoticeScreen, SettingsWebCleanerReadyScreen, SettingsGlassInputScreen, NovaSettingsScreen)
except Exception:
    pass

