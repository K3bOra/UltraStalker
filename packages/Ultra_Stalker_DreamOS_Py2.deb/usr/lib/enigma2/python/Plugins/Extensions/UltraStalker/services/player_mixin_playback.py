# -*- coding: utf-8 -*-
"""Stream start, service events, retry and smart recovery.

Methods moved verbatim out of ``UltraStalkerPlayer`` (player_native.py); behaviour is unchanged.
This module is imported by player_native.py once its module-level helpers exist, so the
names below are taken from that module (partially initialised at this point) on purpose.
"""
from __future__ import absolute_import, division, print_function, unicode_literals
from .. import us_env as _us_env
from ..us_env import str, int, max, us_clear, us_func
from .player_native import iServiceInformation, sane_play_pts, InfoBarSeek, MessageBox, UltraInfobarVisibility, _, _PLAYER_BG_EXECUTOR, _all_external_player_pids, _engine_label, normalize_dreamos_engine, _matching_external_player_pids, add_recently_played, eServiceReference, force_session_silence, load_settings, optional_failure, queue, runtime_breadcrumb, time, touch_recently_played

class PlayerPlaybackMixin(object):
    """Stream start, service events, retry and smart recovery."""

    def _schedule_startup_guard(self, reason):
        """Debounce stale EOF/tune-failed events from ServiceApp/ExtePlayer/DreamOS.

        VOD and episodes sometimes decode a second of video and then emit a stale
        startup event for the previous engine/service. Never restart immediately;
        verify the active reference and advancing play position first.
        """
        if self.media_type not in ('vod', 'series', 'episode', 'catchup', 'itv', 'live'):
            return False
        self._early_eof_pending = True
        self._startup_guard_reason = str(reason or 'startup interruption')
        self._startup_guard_checks = 0
        try:
            service = self.session.nav.getCurrentService()
            seekable = service.seek() if service else None
            pos = seekable.getPlayPosition() if seekable else None
            self._startup_guard_last_position = sane_play_pts(pos[1]) if pos and (not pos[0]) else -1
        except Exception:
            self._startup_guard_last_position = -1
        try:
            self.eof_guard_timer.stop()
            self.eof_guard_timer.start(1100, True)
            return True
        except Exception as exc:
            optional_failure('player', exc)
            return False

    def _make_relay_link_refresher(self):
        client = self.item.get('_live_client_ref') or self.item.get('_player_client_ref') if isinstance(self.item, dict) else None
        if client is None or not hasattr(client, 'create_link'):
            return None
        item = dict(self._history_item if isinstance(self._history_item, dict) else self.item if isinstance(self.item, dict) else {})
        media = str(self.media_type or 'itv')

        def _refresh():
            if getattr(self, 'restored', False) or getattr(self, '_closing_playback', False):
                return ''
            if media in ('itv', 'live'):
                return str(client.create_link(item, 'itv') or '')
            elif media == 'episode':
                episode_id = item.get('id') or item.get('episode_id') or item.get('series') or item.get('number')
                return str(client.create_link(item, 'series', episode_id) or '')
            elif media == 'series':
                sid = item.get('series_id') or item.get('id')
                return str(client.create_link(item, 'series', sid) or '')
            else:
                return str(client.create_link(item, 'vod') or '')
        return _refresh

    def _category_label(self):
        return {'itv': _('LIVE'), 'live': _('LIVE'), 'vod': _('MOVIE'), 'series': _('SERIES'), 'episode': _('EPISODE'), 'catchup': _('CATCH-UP')}.get(self.media_type, self.media_type.upper()[:10])

    def playStream(self, servicetype, streamurl):
        runtime_breadcrumb('player_start_request', media_type=self.media_type, engine=int(servicetype or 0))
        if self.restored or self._closing_playback:
            return None
        if not streamurl:
            self._final_failure('Empty stream URL')
            return None
        bypass = bool(getattr(self, '_buffer_bypass', False))
        self._buffer_bypass = False
        if not bypass and self.media_type in ('vod', 'series', 'episode'):
            try:
                buffer_mb = int(load_settings().get('playback_buffer_mb') or 0)
            except Exception:
                buffer_mb = 0
            if buffer_mb > 0 and (not str(streamurl).startswith('http://127.0.0.1')):
                path = str(streamurl).split('?', 1)[0].lower()
                if not path.endswith('.m3u8'):
                    self._arm_playback_buffer(servicetype, streamurl, buffer_mb)
                    return None
        try:
            service_value = int(servicetype)
        except Exception:
            service_value = 4097
        service_value = normalize_dreamos_engine(service_value, self.media_type, streamurl)
        self.servicetype = service_value
        if self.media_type in ('vod', 'series', 'episode', 'catchup'):
            pending = int(getattr(self, '_resume_target', 0) or 0)
            if pending > 0:
                self.item['_resume_position'] = pending
                self._recovery_resume_pending = True
            self._resume_target = 0
            self._resume_seek_count = 0
            self._native_resume_started = False
            self.resume_prompted = False
            try:
                self.resume_verify_timer.stop()
            except Exception:
                pass
        if self._play_generation > 0:
            self._subtitle_session_capture()
            self._disable_online_subtitles()
            self._external_subtitle_stop()
        self._subtitle_source = ''
        self._subtitle_session_restore_done = False
        self._subtitle_session_restore_attempts = 0
        self._reset_vod_quality_probe()
        self._reset_vod_audio_probe()
        self._play_generation += 1
        self.started = False
        self.failed = False
        self._early_eof_pending = False
        self._startup_guard_checks = 0
        self._startup_guard_last_position = -1
        self._startup_guard_reason = ''
        self._startup_guard_until = time.monotonic() + (8.0 if self.media_type in ('vod', 'series', 'episode', 'catchup') else 0.0)
        self._video_guard_misses = 0
        self._video_guard_last_engine = int(service_value)
        self._engine_video_confirmed = False
        self._subtitle_user_override = False
        self._subtitle_manual_override = False
        self._subtitle_disable_attempts = 0
        self._embedded_subtitle_probe_pending = False
        self._embedded_subtitle_probe_attempts = 0
        try:
            self.embedded_subtitle_probe_timer.stop()
        except Exception:
            pass
        try:
            self.subtitle_default_timer.stop()
        except Exception as exc:
            optional_failure('player', exc)
        try:
            self.eof_guard_timer.stop()
        except Exception as exc:
            optional_failure('player', exc)
        self.start_attempt = time.monotonic()
        self._startup_deadline = self.start_attempt + 12.0
        self._startup_probe_position = -1
        self._startup_confirmed = False
        self._startup_live_pair = None
        self._startup_live_pair_hits = 0
        self.streamurl = str(streamurl or '')
        try:
            self['engine'].setText(_engine_label(self.servicetype))
        except Exception:
            pass
        try:
            self['connection'].setText('')
        except Exception:
            pass
        self['extension'].setText(_('STREAM'))
        try:
            self._sync_typographic_technical_row()
        except Exception:
            pass
        try:
            play_url = str(streamurl)
            if int(self.servicetype) in (4097, 8193) or _us_env.IS_DREAMOS:
                try:
                    from ..stream_relay import wrap as _relay_wrap
                    play_url = _relay_wrap(play_url, refresher=self._make_relay_link_refresher())
                except Exception as exc:
                    optional_failure('player.stream_relay', exc)
            self.reference = eServiceReference(self.servicetype, 0, play_url)
            self.reference.setName(self.name)
            try:
                self._owned_reference_string = self.reference.toString()
            except Exception:
                self._owned_reference_string = ''
            result = self.session.nav.playService(self.reference)
            try:
                self._owned_external_pids.update(set(_matching_external_player_pids(self.streamurl)) - set(self._external_player_baseline))
            except Exception as exc:
                optional_failure('player.capture_external', exc)
            if result is False:
                raise RuntimeError('service engine rejected the stream')
            self.startup_timer.stop()
            self.startup_timer.start(750, True)
        except Exception as exc:
            self._try_next_engine(_('engine %s rejected stream: %s') % (self.servicetype, exc))

    def _service_started(self):
        if self.restored or self._closing_playback or getattr(self, '_auto_retry_inflight', False):
            return None
        try:
            if not self._event_matches_current_reference(ignore_suppress=True):
                return None
        except Exception:
            pass
        already_started = bool(self.started)
        self.started = True
        if self.media_type in ('vod', 'series', 'episode', 'catchup'):
            if _us_env.IS_DREAMOS:
                try:
                    self.resume_timer.stop()
                    self.resume_timer.start(1400, True)
                except Exception:
                    self._reference_resume()
            else:
                self._reference_resume()
        if not already_started or not self._watch_started_at:
            self._watch_started_at = time.monotonic()
        try:
            self.startup_timer.stop()
            self.startup_timer.start(750, True)
        except Exception as exc:
            optional_failure('player', exc)
        self['connection'].setText('')
        if not getattr(self, '_retry_visual_hold', False):
            self._auto_retry_deferred_reason = ''
            self._auto_retry_next_allowed_at = 0.0
            try:
                self.auto_retry_delay_timer.stop()
            except Exception:
                pass
            try:
                self['retry_status'].setText('')
            except Exception:
                pass
        else:
            try:
                self['retry_status'].show()
            except Exception:
                pass
            try:
                self.retry_visual_success_timer.stop()
            except Exception:
                pass
            if self.media_type in ('itv', 'live'):
                try:
                    self.retry_visual_success_timer.start(1500, True)
                except Exception as exc:
                    optional_failure('player.retry_visual_success_timer', exc)
            else:
                self._retry_visual_progress_last = -1
                self._retry_visual_progress_advances = 0
        if self.media_type in ('itv', 'live'):
            try:
                self._refresh_live_epg()
            except Exception as exc:
                optional_failure('player.live_epg_started', exc)
        runtime_breadcrumb('player_started', media_type=self.media_type, engine=int(self.servicetype or 0))
        try:
            self._owned_external_pids.update(set(_all_external_player_pids()) - set(self._external_player_baseline))
        except Exception as exc:
            optional_failure('player.capture_external_started', exc)
        self._last_network_activity = time.monotonic()
        try:
            self._schedule_subtitle_session_restore(0)
        except Exception:
            pass
        try:
            bridge = getattr(self, '_external_subtitle_bridge', None)
            if bridge is not None:
                bridge.service_started()
        except Exception as exc:
            optional_failure('player.external_subtitle_started', exc)
        try:
            self.memory_fuse_timer.stop()
            self.memory_fuse_timer.start(5000, False)
        except Exception as exc:
            optional_failure('player.silent_guard', exc)
        try:
            if not getattr(self, '_startup_confirmed', False):
                self.stable_timer.stop()
        except Exception as exc:
            optional_failure('player', exc)
        if not already_started:
            try:
                self.subtitle_default_timer.stop()
                self._enforce_default_subtitles_off()
            except Exception as exc:
                optional_failure('player', exc)
        if self.media_type in ('vod', 'series', 'episode', 'catchup'):
            try:
                profile = self._history_profile
                history_item = self._history_item
                touch_recently_played(profile, self.media_type, history_item)
            except Exception as exc:
                optional_failure('player', exc)
        elif self.media_type in ('itv', 'live'):
            pending = getattr(self, '_pending_live_recent_item', None)
            if isinstance(pending, dict):
                try:
                    add_recently_played(self._history_profile, 'itv', pending)
                    self._history_item = pending
                    self._pending_live_recent_item = None
                except Exception as exc:
                    optional_failure('player.live_recent_after_zap', exc)
        if self.media_type in ('vod', 'series', 'episode') and (not already_started):
            self._arm_vod_quality_probe()
            self._arm_vod_audio_probe()
        self._update_stream_info()
        if self.media_type in ('vod', 'series', 'episode', 'catchup'):
            try:
                self.progress_timer.stop()
                self.progress_timer.start(self._cfg_progress_interval_ms, False)
            except Exception as exc:
                optional_failure('player', exc)
            if not self.resume_prompted:
                self.resume_prompted = True
        if self.media_type in ('vod', 'series', 'episode', 'catchup', 'trailer'):
            try:
                self.progress_visual_timer.stop()
                self._update_progress_visual()
                self.progress_visual_timer.start(1000, False)
            except Exception as exc:
                optional_failure('player.trailer_progress_visual', exc)
        if not already_started:
            self._schedule_buffer_after_start()
        timer = getattr(self, '_next_episode_timer', None)
        if timer is not None:
            try:
                timer.stop()
                timer.start(250, True)
            except Exception as exc:
                optional_failure('player.next_episode_watch_start', exc)

    def _suppress_service_events(self, seconds=1.25):
        self._event_suppress_until = max(float(getattr(self, '_event_suppress_until', 0.0) or 0.0), time.monotonic() + max(0.0, float(seconds or 0.0)))

    def _event_matches_current_reference(self, ignore_suppress=False):
        if not ignore_suppress and time.monotonic() < float(getattr(self, '_event_suppress_until', 0.0) or 0.0):
            return False
        try:
            current = self.session.nav.getCurrentlyPlayingServiceReference()
            if current is None or self.reference is None:
                return True
            s_cur = current.toString()
            s_ref = self.reference.toString()
            if s_cur == s_ref:
                return True
            p_cur = s_cur.split(':', 10)
            p_ref = s_ref.split(':', 10)
            if len(p_cur) >= 11 and len(p_ref) >= 11 and p_cur[10] and (p_cur[10] == p_ref[10]):
                return True
            return False
        except Exception:
            return True

    def _service_failed(self):
        if self.restored or self._closing_playback or getattr(self, '_auto_retry_inflight', False):
            return
        if not self._event_matches_current_reference():
            return
        elapsed = time.monotonic() - self.start_attempt if self.start_attempt else 999
        if self.media_type in ('vod', 'series', 'episode', 'catchup') and elapsed < 8.0:
            if not getattr(self, '_retry_visual_hold', False):
                self['connection'].setText(_('PLAYING  •  verifying startup') if self.started else _('CONNECTING  •  verifying startup'))
            self._schedule_startup_guard('transient tune failed')
            return
        if self.started and self.media_type in ('itv', 'live'):
            if self._handle_runtime_interruption('tune failed during playback'):
                return
        self._try_next_engine('tune failed')

    def _next_episode_paused(self):
        state = getattr(self, 'seekstate', None)
        pause = getattr(InfoBarSeek, 'SEEK_STATE_PAUSE', None)
        if pause is not None and state == pause:
            return True
        return str(getattr(self, '_last_play_state_value', '') or '') == '||'

    def _dismiss_next_episode_card(self, reason='reset'):
        dialog = getattr(self, '_next_card_dialog', None)
        self._next_card_dialog = None
        self._next_card_open = False
        self._next_card_live = False
        if dialog is not None:
            try:
                dialog._finish(reason)
            except Exception as exc:
                optional_failure('player.next_episode_dismiss', exc)

    def _next_episode_watch_cleanup(self):
        try:
            self._recent_next_cancel.set()
        except Exception:
            pass
        future = getattr(self, '_recent_next_future', None)
        if future is not None:
            try:
                future.cancel()
            except Exception:
                pass
        self._recent_next_future = None
        pending = getattr(self, '_recent_live_context_future', None)
        if pending is not None:
            try:
                pending[1].cancel()
            except Exception:
                pass
        self._recent_live_context_future = None
        self._dismiss_next_episode_card('owner_close')
        timer = getattr(self, '_next_episode_timer', None)
        if timer is None:
            return
        try:
            timer.stop()
        except Exception:
            pass
        conn = getattr(self, '_next_episode_timer_conn', None)
        try:
            if conn is not None:
                conn.disconnect()
        except Exception:
            pass
        self._next_episode_timer_conn = None
        try:
            if self._next_episode_watch_tick in timer.callback:
                timer.callback.remove(self._next_episode_watch_tick)
        except Exception:
            pass

    def _finish_next_episode(self, next_item):
        if self.restored or self._closing_playback or getattr(self, '_next_episode_transitioning', False):
            return
        if not isinstance(next_item, dict) or not next_item:
            return
        self._next_episode_transitioning = True
        self._dismiss_next_episode_card('owner_close')
        timer = getattr(self, '_next_episode_timer', None)
        if timer is not None:
            timer.stop()
        try:
            self.progress_timer.stop()
        except Exception:
            pass
        if not getattr(self, '_next_episode_at_eof', False):
            self._save_history_progress(force=True, completed_override=True)
        self._close_player({'next_episode': dict(next_item)}, save_progress=False)

    def _mark_stream_stable(self):
        if self.restored or not self.started or (not getattr(self, '_startup_confirmed', False)):
            return
        self._runtime_reconnects = 0
        self._recovery_attempts = 0
        self._auto_retry_next_allowed_at = 0.0
        self._auto_retry_deferred_reason = ''
        try:
            self.auto_retry_delay_timer.stop()
        except Exception:
            pass
        self._retry_visual_clear(force=True)

    def _handle_runtime_interruption(self, reason):
        if self.restored or self._closing_playback:
            return False
        try:
            self.stable_timer.stop()
        except Exception as exc:
            optional_failure('player.silent_guard', exc)
        try:
            self.retry_visual_success_timer.stop()
        except Exception:
            pass
        self.started = False
        return self._begin_smart_recovery(reason)

    def _verify_early_eof(self):
        if not self._early_eof_pending or self.restored or self.failed:
            return
        now = time.monotonic()
        ref_ok = self._event_matches_current_reference()
        position = -1
        try:
            service = self.session.nav.getCurrentService()
            seekable = service.seek() if service else None
            pos = seekable.getPlayPosition() if seekable else None
            position = sane_play_pts(pos[1]) if pos and (not pos[0]) else -1
            info = service.info() if service else None
            elapsed_now = now - self.start_attempt if self.start_attempt else 999
            if info is not None and ref_ok and (elapsed_now < 8.0 or self.media_type in ('itv', 'live')):
                width = int(info.getInfo(iServiceInformation.sVideoWidth) or 0)
                height = int(info.getInfo(iServiceInformation.sVideoHeight) or 0)
                if width > 16 and height > 16:
                    self._early_eof_pending = False
                    self['connection'].setText('')
                    return
        except Exception:
            position = -1
        previous = self._startup_guard_last_position
        self._startup_guard_last_position = position
        self._startup_guard_checks += 1
        if ref_ok and position >= 0 and (previous >= 0) and (position > previous + 9000):
            self._early_eof_pending = False
            self['connection'].setText('')
            return
        if ref_ok and now - float(getattr(self, '_us_last_buffering', 0.0) or 0.0) < 4.0 and self.start_attempt and (now - self.start_attempt < 45.0):
            try:
                self.eof_guard_timer.start(1000, True)
            except Exception as exc:
                optional_failure('player', exc)
            return
        if ref_ok and (now < self._startup_guard_until or self._startup_guard_checks < 2) and (self._startup_guard_checks < 7):
            try:
                self.eof_guard_timer.start(1000, True)
            except Exception as exc:
                optional_failure('player', exc)
            return
        self._early_eof_pending = False
        if self._fallback_from_buffer():
            return
        if self.started:
            self._handle_runtime_interruption(self._startup_guard_reason or 'playback stopped')
            return
        self._try_next_engine(self._startup_guard_reason or 'stream stopped during startup verification')

    def _startup_timeout(self):
        if self.restored or self._closing_playback or self.failed:
            return
        if getattr(self, '_startup_confirmed', False):
            self._playback_health_tick()
            return
        now = time.monotonic()
        deadline = float(getattr(self, '_startup_deadline', self.start_attempt + 12.0))
        if self.started and (str(getattr(self, '_last_play_state_value', '') or '') == '||' or getattr(self, '_resume_prompt_open', False)):
            self._startup_deadline = now + 12.0
            self.startup_timer.start(750, True)
            return
        position = -1
        seekable = None
        service = None
        try:
            service = self.session.nav.getCurrentService()
            seekable = service.seek() if service else None
            value = seekable.getPlayPosition() if seekable else None
            if value and (not value[0]):
                position = max(0, sane_play_pts(value[1]))
        except Exception as exc:
            optional_failure('player.startup.position_probe', exc)
        previous = int(getattr(self, '_startup_probe_position', -1))
        self._startup_probe_position = position
        confirmed = self.started and previous >= 0 and (position > previous + 9000)
        if not confirmed and self.started and (self.media_type in ('itv', 'live') or _us_env.IS_DREAMOS):
            try:
                info = service.info() if service else None
                iw = int(self._info_number(info, 'sVideoWidth', 0) or 0) if info else 0
                ih = int(self._info_number(info, 'sVideoHeight', 0) or 0) if info else 0
                pw = int(self._read_proc_number(('/proc/stb/vmpeg/0/xres',), 16) or 0)
                ph = int(self._read_proc_number(('/proc/stb/vmpeg/0/yres',), 16) or 0)
                pair = (iw, ih) if iw > 16 and ih > 16 else (pw, ph) if pw > 16 and ph > 16 else (0, 0)
                previous_pair = getattr(self, '_startup_live_pair', None)
                hits = int(getattr(self, '_startup_live_pair_hits', 0) or 0) + 1 if pair == previous_pair else 1
                self._startup_live_pair = pair
                self._startup_live_pair_hits = hits
                confirmed = bool(pair[0] > 0 and pair[1] > 0 and (hits >= 2) and (now - self.start_attempt >= 2.0))
            except Exception as exc:
                optional_failure('player.startup.live_pair', exc)
        if not confirmed and self.started and (self.media_type in ('itv', 'live')) and self._event_matches_current_reference() and (now - self.start_attempt >= 4.0):
            confirmed = True
        if confirmed and (not self._resume_target):
            self._startup_confirmed = True
            self.stable_timer.stop()
            self.stable_timer.start(30000, True)
            self._health_position = position
            self._health_changed_at = now
            runtime_breadcrumb('player_first_progress', media_type=self.media_type, elapsed_ms=int((now - self.start_attempt) * 1000))
            self.startup_timer.start(2000, True)
            return
        if self._resume_target:
            deadline = max(deadline, float(self._resume_grace_until or 0.0) + 1.0)
        if now >= deadline and now - float(getattr(self, '_us_last_buffering', 0.0) or 0.0) < 4.0 and (now - self.start_attempt < 45.0):
            self.startup_timer.start(750, True)
            return
        if now >= deadline:
            self.started = False
            if self._fallback_from_buffer():
                return
            self._try_next_engine('startup produced no advancing playback')
            return
        self.startup_timer.start(750, True)

    def _playback_health_tick(self):
        """Recover a prolonged silent VOD stall; never override user transport/UI."""
        if self.restored or self._closing_playback or self.failed:
            return
        now = time.monotonic()
        self.startup_timer.start(2000, True)
        if self.media_type not in ('vod', 'series', 'episode'):
            return
        held = any((bool(getattr(self, name, False)) for name in ('_subtitle_inline_locked', '_subtitle_native_selector_hold', '_external_subtitle_ui_hold', '_resume_prompt_open', '_resume_target', '_auto_retry_inflight')))
        if held or not self._transport_is_playing() or (not self.started):
            self._health_changed_at = now
            return
        position, duration = self._service_progress_snapshot()
        previous = int(getattr(self, '_health_position', -1))
        self._health_position = position
        if position <= 0 or position != previous or (duration and duration - position <= 10 * 90000):
            self._health_changed_at = now
            return
        changed = float(getattr(self, '_health_changed_at', now))
        if now - changed < 30.0:
            return
        self._health_changed_at = now
        runtime_breadcrumb('player_silent_stall', media_type=self.media_type)
        self._begin_smart_recovery('playback position stopped advancing')

    def _try_next_engine(self, reason):
        if self.restored or self._closing_playback or self.failed:
            return None
        try:
            self.startup_timer.stop()
        except Exception as exc:
            optional_failure('player.silent_guard', exc)
        if self._begin_smart_recovery(reason):
            return None
        self._final_failure(reason)

    def _retry_visual_set(self, text):
        """Hold one retry status line steady while only its text changes."""
        first = not bool(getattr(self, '_retry_visual_hold', False))
        self._retry_visual_hold = True
        if first:
            self._retry_visual_progress_last = -1
            self._retry_visual_progress_advances = 0
        try:
            self['retry_status'].setText(str(text or ''))
            if self._lb_active():
                self._lb_fit_status('retry_status')
                self._lb_langs_update(force=True)
            self['retry_status'].show()
        except Exception:
            pass
        if first:
            try:
                us_func(UltraInfobarVisibility.lockShow)(self)
            except Exception:
                pass
            try:
                self.doShow()
            except Exception:
                pass

    def _retry_visual_clear(self, force=False):
        """Release the held retry line once real playback is confirmed."""
        try:
            self.retry_visual_success_timer.stop()
        except Exception:
            pass
        if not force and (not bool(getattr(self, '_retry_visual_hold', False))):
            return
        was_held = bool(getattr(self, '_retry_visual_hold', False))
        self._retry_visual_hold = False
        self._retry_visual_progress_last = -1
        self._retry_visual_progress_advances = 0
        try:
            self['retry_status'].setText('')
            if self._lb_active():
                self._lb_langs_update(force=True)
        except Exception:
            pass
        if was_held:
            try:
                us_func(UltraInfobarVisibility.unlockShow)(self)
            except Exception:
                pass

    def _confirm_retry_visual_success(self):
        """Release a held retry line only after the retry candidate stays alive."""
        if self.restored or self._closing_playback:
            return
        if not getattr(self, '_retry_visual_hold', False):
            return
        if self.media_type not in ('itv', 'live'):
            return
        if not self.started:
            return
        if getattr(self, '_auto_retry_inflight', False):
            return
        if str(getattr(self, '_auto_retry_deferred_reason', '') or ''):
            return
        self._retry_visual_clear(force=True)

    def _retry_visual_note_vod_progress(self, position):
        """Confirm a VOD/episode retry only from real advancing playback.

        Two advancing one-second samples on the current replacement reference are
        stronger evidence than evStart/resolution metadata and avoid visual
        hide/show loops on ServiceApp/exteplayer handoffs.
        """
        if self.media_type not in ('vod', 'series', 'episode', 'catchup'):
            return
        if not getattr(self, '_retry_visual_hold', False) or not self.started:
            return
        if getattr(self, '_auto_retry_inflight', False) or str(getattr(self, '_auto_retry_deferred_reason', '') or ''):
            return
        try:
            if not self._event_matches_current_reference():
                return
        except Exception:
            return
        try:
            p = max(0, int(position or 0))
        except Exception:
            return
        if p <= 0:
            return
        last = int(getattr(self, '_retry_visual_progress_last', -1) or -1)
        if last >= 0 and p > last + 18000:
            self._retry_visual_progress_advances = int(getattr(self, '_retry_visual_progress_advances', 0) or 0) + 1
        elif last >= 0 and p < last:
            self._retry_visual_progress_advances = 0
        self._retry_visual_progress_last = p
        if int(getattr(self, '_retry_visual_progress_advances', 0) or 0) >= 2:
            self._retry_visual_clear(force=True)

    def _run_deferred_auto_retry(self):
        if self.restored or self._closing_playback or self.started:
            self._auto_retry_deferred_reason = ''
            return
        reason = str(self._auto_retry_deferred_reason or self._auto_retry_reason or 'retry failed')
        self._auto_retry_deferred_reason = ''
        self._begin_smart_recovery(reason)

    def _begin_smart_recovery(self, reason):
        """Resolve a fresh provider link and retry at most three times."""
        if self.restored or self._closing_playback:
            return False
        if self._auto_retry_inflight or str(getattr(self, '_auto_retry_deferred_reason', '') or ''):
            return True
        retry_limit = int(getattr(self, '_cfg_retry_limit', 3))
        if not getattr(self, '_cfg_smart_recovery', True) or retry_limit <= 0:
            return False
        if self.media_type not in ('itv', 'live', 'vod', 'series', 'episode'):
            return False
        self._dismiss_next_episode_card('reset')
        self._subtitle_session_capture()
        if self.started:
            self._arm_recovery_resume()
        self.started = False
        try:
            self.stable_timer.stop()
            self.startup_timer.stop()
        except Exception as exc:
            optional_failure('player.recovery.stop_timers', exc)
        now = time.monotonic()
        if int(self._recovery_attempts or 0) > 0 and now < float(self._auto_retry_next_allowed_at or 0.0):
            self._auto_retry_deferred_reason = str(reason or 'retry failed')
            remaining = max(0.05, float(self._auto_retry_next_allowed_at) - now)
            try:
                self.auto_retry_delay_timer.stop()
                self.auto_retry_delay_timer.start(int(remaining * 1000.0), True)
            except Exception as exc:
                optional_failure('player.auto_retry_delay', exc)
            return True
        if int(self._recovery_attempts or 0) >= retry_limit:
            self._retry_visual_set(_('Stream unavailable'))
            self.failed = True
            runtime_breadcrumb('player_auto_retry_exhausted', media_type=self.media_type, reason=str(reason or ''))
            return True
        client = self.item.get('_live_client_ref') or self.item.get('_player_client_ref') if isinstance(self.item, dict) else None
        if client is None or not hasattr(client, 'create_link'):
            return False
        try:
            self.retry_visual_success_timer.stop()
        except Exception as exc:
            optional_failure('player.recovery.stop_visual_timer', exc)
        self._recovery_attempts = int(self._recovery_attempts or 0) + 1
        attempt = self._recovery_attempts
        self._auto_retry_inflight = True
        self._auto_retry_generation += 1
        generation = self._auto_retry_generation
        self._suppress_service_events(1.5)
        try:
            self.session.nav.stopService()
        except Exception:
            pass
        self._auto_retry_reason = str(reason or '')
        self._auto_retry_next_allowed_at = time.monotonic() + float(self._auto_retry_min_interval or 2.0)
        self._retry_visual_set(_('Retrying stream • %d/%d') % (attempt, retry_limit))
        try:
            self['connection'].setText('')
        except Exception:
            pass
        item = dict(self._history_item if isinstance(self._history_item, dict) else self.item)
        media = self.media_type
        q = self._recovery_queue

        def worker():
            try:
                if media in ('itv', 'live'):
                    url = client.create_link(item, 'itv')
                elif media == 'episode':
                    episode_id = item.get('id') or item.get('episode_id') or item.get('series') or item.get('number')
                    url = client.create_link(item, 'series', episode_id)
                elif media == 'series':
                    sid = item.get('series_id') or item.get('id')
                    url = client.create_link(item, 'series', sid)
                else:
                    url = client.create_link(item, 'vod')
                q.put((generation, str(url or ''), None))
            except Exception as exc:
                q.put((generation, '', exc))
        try:
            self._auto_retry_future = _PLAYER_BG_EXECUTOR.submit(worker)
            self.recovery_timer.stop()
            self.recovery_timer.start(100, False)
            runtime_breadcrumb('player_auto_retry', media_type=media, attempt=attempt, reason=self._auto_retry_reason)
            return True
        except Exception as exc:
            self._auto_retry_inflight = False
            optional_failure('player.auto_retry_start', exc)
            return False

    def _cancel_smart_recovery(self):
        self._recovery_inflight = False
        self._auto_retry_inflight = False
        self._auto_retry_generation += 1
        self._auto_retry_deferred_reason = ''
        self._auto_retry_next_allowed_at = 0.0
        try:
            self.auto_retry_delay_timer.stop()
        except Exception as exc:
            optional_failure('player.recovery.cancel_timer', exc)
        future = getattr(self, '_auto_retry_future', None)
        if future is not None:
            try:
                future.cancel()
            except Exception as exc:
                optional_failure('player.recovery.cancel_future', exc)
        self._auto_retry_future = None
        if self.restored or self._closing_playback:
            self._retry_visual_clear(force=True)

    def _drain_recovery_result(self):
        if self.restored or self._closing_playback:
            try:
                self.recovery_timer.stop()
            except Exception as exc:
                optional_failure('player.recovery.drain_timer', exc)
            return
        try:
            generation, url, error = self._recovery_queue.get_nowait()
        except queue.Empty:
            return
        if generation != self._auto_retry_generation:
            if not self._auto_retry_inflight:
                try:
                    self.recovery_timer.stop()
                except Exception as exc:
                    optional_failure('player.recovery.drain_timer', exc)
            return
        try:
            self.recovery_timer.stop()
        except Exception as exc:
            optional_failure('player.recovery.drain_timer', exc)
        self._auto_retry_inflight = False
        self._auto_retry_future = None
        if error or not url:
            if int(self._recovery_attempts or 0) < 3:
                self._begin_smart_recovery(str(error or self._auto_retry_reason or 'retry failed'))
                return
            self._retry_visual_set(_('Stream unavailable'))
            self.failed = True
            return
        self._arm_recovery_resume()
        old_url = str(self.streamurl or '')
        self.streamurl = url
        self._suppress_service_events(0.8)
        try:
            force_session_silence(self.session, old_url, force=True, stop_native=True, exclude_pids=self._external_player_baseline, owned_pids=self._owned_external_pids)
        except Exception as exc:
            optional_failure('player.auto_retry_stop_old', exc)
        us_clear(self._owned_external_pids)
        self._retry_visual_progress_last = -1
        self._retry_visual_progress_advances = 0
        self._arm_recovery_resume(preserve=True)
        self.playStream(self.servicetype, url)

    def _final_failure(self, reason):
        if self.failed:
            return None
        if 0 < int(getattr(self, '_cfg_retry_limit', 3)) <= int(getattr(self, '_recovery_attempts', 0) or 0):
            self.failed = True
            self._retry_visual_set(_('Stream unavailable'))
            try:
                self['connection'].setText('')
            except Exception:
                pass
            return None
        self.failed = True
        self['connection'].setText(_('PLAYBACK FAILED'))
        text = _('The stream could not start with the configured Enigma2 engine.\n\n%s\n\nTried: %s') % (_(str(reason)), ', '.join((str(x) for x in self.engines)))
        try:
            self.session.openWithCallback(lambda answer=None: self.back() if getattr(self, 'failed', False) and (not getattr(self, 'started', False)) and (not getattr(self, '_auto_retry_inflight', False)) else None, MessageBox, text, MessageBox.TYPE_ERROR, timeout=10)
        except Exception:
            self.back()

    def _arm_recovery_resume(self, preserve=False):
        """Re-seek to the last known position after a retry/restart of VOD content.

        Without this the restarted stream begins at 0 and the periodic progress
        writer would overwrite the saved bookmark with the first seconds.
        """
        if self.media_type not in ('vod', 'series', 'episode'):
            return
        try:
            captured = getattr(self, '_recovery_resume_snapshot', None)
            if preserve and captured and getattr(self, '_recovery_resume_pending', False):
                position, duration = captured
            else:
                position = 0
                duration = 0
                try:
                    position, duration = self._service_progress_snapshot()
                except Exception:
                    position = duration = 0
                if position <= 0 and captured and getattr(self, '_recovery_resume_pending', False):
                    position, duration = captured
                position = int(self._resume_target or position or self._last_progress_position or 0)
                duration = int(duration or self._last_progress_duration or 0)
            if position < 10 * 90000:
                return
            if duration and max(0, duration - position) <= 10 * 90000:
                return
            if isinstance(self.item, dict):
                self.item['_resume_position'] = position
                if duration:
                    self.item['_resume_duration'] = duration
            self._native_resume_started = False
            self.resume_prompted = False
            self._recovery_resume_pending = True
            self._recovery_resume_snapshot = (position, duration)
        except Exception as exc:
            optional_failure('player.arm_recovery_resume', exc)

    def restartStream(self):
        self._save_history_progress()
        self._arm_recovery_resume()
        self.playStream(self.servicetype, self.streamurl)
